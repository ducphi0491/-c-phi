package duc_phi.music

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.app.FragmentActivity
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.QueryProductDetailsParams

/** IDs MUST match the subscription and prepaid base plans in Google Play Console. */
private const val PREMIUM_PRODUCT_ID = "meloware_premium"
private const val PREMIUM_6M_BASE_PLAN = "premium-6m"
private const val PREMIUM_12M_BASE_PLAN = "premium-12m"

private data class PremiumDisplayOffer(
    val formattedPrice: String,
    val billingPeriod: String
)

/**
 * Stage 2: safe catalog/UI preparation. NO charge, NO unlock and NO trial start here.
 * Checkout is deliberately deferred until purchase verification / acknowledgement
 * and paid feature gates are implemented and tested in Stage 3.
 * Never flip a local boolean to grant paid entitlement.
 */
private class PremiumCatalogReader(private val activity: FragmentActivity) {
    var loading by mutableStateOf(true)
        private set
    var connected by mutableStateOf(false)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var sixMonth by mutableStateOf<PremiumDisplayOffer?>(null)
        private set
    var twelveMonth by mutableStateOf<PremiumDisplayOffer?>(null)
        private set

    private var closed = false
    private val billingClient = BillingClient.newBuilder(activity.applicationContext)
        .setListener { _, _ -> /* Stage 2 cannot accept payments. */ }
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .enablePrepaidPlans()
                .build()
        )
        .enableAutoServiceReconnection()
        .build()

    fun start() {
        if (closed) return
        loading = true
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (closed) return
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    connected = true
                    refresh()
                } else {
                    connected = false
                    loading = false
                    errorMessage = result.debugMessage
                }
            }

            override fun onBillingServiceDisconnected() {
                if (closed) return
                connected = false
                loading = false
            }
        })
    }

    fun refresh() {
        if (closed) return
        if (!billingClient.isReady) {
            start()
            return
        }
        loading = true
        errorMessage = null
        val query = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PREMIUM_PRODUCT_ID)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                )
            )
            .build()
        billingClient.queryProductDetailsAsync(query) { result, response ->
            if (closed) return@queryProductDetailsAsync
            activity.runOnUiThread {
                if (closed) return@runOnUiThread
                loading = false
                if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                    errorMessage = result.debugMessage
                    sixMonth = null
                    twelveMonth = null
                    return@runOnUiThread
                }
                val details: ProductDetails? = response.productDetailsList
                    .firstOrNull { it.productId == PREMIUM_PRODUCT_ID }
                sixMonth = details?.subscriptionOfferDetails
                    ?.firstOrNull { it.basePlanId == PREMIUM_6M_BASE_PLAN && it.offerId == null }
                    ?.let { offer ->
                        PremiumDisplayOffer(
                            formattedPrice = offer.pricingPhases.pricingPhaseList.lastOrNull()?.formattedPrice.orEmpty(),
                            billingPeriod = offer.pricingPhases.pricingPhaseList.lastOrNull()?.billingPeriod.orEmpty()
                        )
                    }
                twelveMonth = details?.subscriptionOfferDetails
                    ?.firstOrNull { it.basePlanId == PREMIUM_12M_BASE_PLAN && it.offerId == null }
                    ?.let { offer ->
                        PremiumDisplayOffer(
                            formattedPrice = offer.pricingPhases.pricingPhaseList.lastOrNull()?.formattedPrice.orEmpty(),
                            billingPeriod = offer.pricingPhases.pricingPhaseList.lastOrNull()?.billingPeriod.orEmpty()
                        )
                    }
            }
        }
    }

    fun close() {
        closed = true
        billingClient.endConnection()
    }
}

@Composable
internal fun MeloWarePremiumDialog(activity: FragmentActivity, onDismiss: () -> Unit) {
    val colors = LocalMusicColors.current
    val catalog = remember(activity) { PremiumCatalogReader(activity) }

    DisposableEffect(catalog) {
        catalog.start()
        onDispose { catalog.close() }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .heightIn(max = 700.dp),
            color = colors.card,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(48.dp)
                            .background(colors.purple.copy(alpha = 0.20f), RoundedCornerShape(15.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.WorkspacePremium, contentDescription = null,
                            tint = colors.purpleBright, modifier = Modifier.size(29.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mwString("premium.title", "MeloWare Premium"),
                            color = colors.textPrimary, fontSize = 20.sp,
                            fontWeight = FontWeight.Bold)
                        Text(mwString("premium.subtitle", "Mở khóa các tính năng nâng cao"),
                            color = colors.textSecondary, fontSize = 12.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close,
                            contentDescription = mwString("common.close", "Đóng"),
                            tint = colors.textSecondary)
                    }
                }

                Surface(
                    color = colors.purple.copy(alpha = 0.10f),
                    border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(mwString("premium.trial", "Dùng thử 30 ngày miễn phí"),
                            color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
                        Text(mwString("premium.trial_pending",
                            "Thời gian dùng thử sẽ được kích hoạt sau khi hoàn thiện quản lý quyền Premium."),
                            color = colors.textSecondary, fontSize = 12.sp)
                    }
                }

                Text(mwString("premium.plans", "Chọn thời hạn Premium"),
                    color = colors.textPrimary, fontSize = 15.sp,
                    fontWeight = FontWeight.Bold)

                PremiumPlanCard(
                    title = mwString("premium.plan6", "Premium 6 tháng"),
                    expectedPrice = mwString("premium.expected1", "Dự kiến 1 USD"),
                    displayOffer = catalog.sixMonth,
                    loading = catalog.loading
                )
                PremiumPlanCard(
                    title = mwString("premium.plan12", "Premium 12 tháng"),
                    expectedPrice = mwString("premium.expected2", "Dự kiến 2 USD"),
                    displayOffer = catalog.twelveMonth,
                    loading = catalog.loading
                )

                Surface(
                    color = colors.backgroundSoft,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(mwString("premium.prepaid", "Trả trước một lần, không tự gia hạn"),
                            color = colors.textPrimary, fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp)
                        Text(mwString("premium.not_ready",
                            "Thanh toán chưa mở: cần tạo hai gói trên Google Play và tích hợp xác minh giao dịch an toàn trước khi thu tiền."),
                            color = colors.textSecondary, fontSize = 12.sp)
                    }
                }

                if (catalog.loading) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp, color = colors.purpleBright)
                        Text(mwString("premium.loading", "Đang đọc thông tin từ Google Play..."),
                            color = colors.textSecondary, fontSize = 12.sp)
                    }
                } else if (catalog.errorMessage != null) {
                    Text(mwString("premium.play_unavailable", "Chưa kết nối được Google Play."),
                        color = colors.textSecondary, fontSize = 12.sp)
                }

                // Checkout is intentionally disabled until server-side verification,
                // entitlement and acknowledgement are implemented. Never collect
                // payments while the premium service is unfinished.
                Button(
                    onClick = {},
                    enabled = false,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                ) {
                    Icon(Icons.Rounded.CreditCard, contentDescription = null,
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(mwString("premium.activate_wait", "Kích hoạt Premium — sắp ra mắt"))
                }

                OutlinedButton(
                    onClick = { catalog.refresh() },
                    enabled = !catalog.loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(mwString("premium.reload", "Kiểm tra lại gói Google Play"),
                        color = colors.textPrimary)
                }

                Text(mwString("premium.price_note",
                    "Giá hiển thị thực tế sẽ lấy từ Google Play theo quốc gia và đơn vị tiền tệ."),
                    fontSize = 11.sp,
                    color = colors.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun PremiumPlanCard(
    title: String,
    expectedPrice: String,
    displayOffer: PremiumDisplayOffer?,
    loading: Boolean
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.backgroundSoft,
        border = BorderStroke(1.dp, colors.border),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = colors.textPrimary,
                    fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    if (loading) mwString("premium.checking", "Đang kiểm tra gói")
                    else if (displayOffer == null) mwString("premium.unpublished", "Chưa mở bán trên Google Play")
                    else mwString("premium.ready_but_locked", "Đã tìm thấy gói · chờ hoàn thiện thanh toán"),
                    color = colors.textSecondary, fontSize = 11.sp
                )
            }
            Text(
                displayOffer?.formattedPrice?.takeIf { it.isNotBlank() } ?: expectedPrice,
                fontWeight = FontWeight.Bold,
                color = colors.purpleBright,
                fontSize = 14.sp
            )
        }
    }
}
