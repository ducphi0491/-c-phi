# MeloWare Premium - Stage 2 (Settings UI + Google Play price lookup)

Baseline: meloware15.10.zip supplied by the user (14/10/2026).

## Files to copy

1. `MainActivity.kt` -> `app/src/main/java/duc_phi/music/MainActivity.kt`
2. `MeloWarePremium.kt` (NEW) -> `app/src/main/java/duc_phi/music/MeloWarePremium.kt`
3. `meloware_languages.json` -> `app/src/main/assets/meloware_languages.json`

If you did not apply Google Play Billing Stage 1, copy the `build.gradle.kts` from the complete package to `app/build.gradle.kts`. Otherwise, keep your Stage 1 Gradle file unchanged. The complete Gradle has Billing 9.1.0 and versionCode 28.

## What Stage 2 does

- Adds "Kich hoat MeloWare Premium" / Premium menu entry to Settings.
- Opens a Premium dialog with proposed 30-day trial, 6-month plan, 12-month plan.
- Reads product details (subscription `meloware_premium`, base plans `premium-6m` and `premium-12m`) and localized prices via Google Play Billing 9.1.0.
- Shows "not yet available" while subscription products have not been created/activated in Play Console.
- Adds 21 strings per locale in the existing 15-language JSON. Existing keys and behavior stay intact.
- Does NOT ask for payment, start trials, acknowledge purchases, store purchase tokens, or unlock any paid feature. The Buy button is intentionally disabled until payment verification and entitlement logic are complete; this avoids charging customers for unavailable features.

## Next steps to activate real payments

1. Upload a new AAB on the Internal testing track, including Billing 9.1.0.
2. Configure subscription product `meloware_premium` with prepaid base plans `premium-6m` and `premium-12m` in Play Console, choose local pricing and activate products.
3. Implement Play Billing purchase + lifecycle handling, secure server-side verification (Android Publisher API `purchases.subscriptionsv2.get`), purchase acknowledgement, and trial/paid-entitlement checks. Add feature gates only after deciding which features are Premium.
4. Test with Play license testers before enabling public checkout. Prepaid subscriptions are not auto-renewing; the 30-day trial is separate and not activated in Stage 2.

## Build

Android Studio: Sync Gradle, then Build > Rebuild Project.

This package was checked for structure and JSON completeness, but was NOT built as an Android APK/AAB in this environment.
