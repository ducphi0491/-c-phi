DocFlow Offline - Ban cap nhat PDF -> EXCEL (v0.7)
==================================================

GOC PHAT TRIEN
- DocumentEngines.kt tu du an DocFlow v0.6 (5 Kotlin).
- MainActivity.kt la ban moi nhat da cap nhat giao dien 2 tab Chuyen doi / Cong cu.

FILE CAN THAY THE (CHI HAI FILE)
1. MainActivity.kt
2. DocumentEngines.kt

Chep vao:
app/src/main/java/com/docflowoffline/

Khong can them file Kotlin moi, khong can sua AndroidManifest.xml hoac build.gradle.kts.
Library PDFBox-Android 2.0.27.0 da co san trong Gradle cua DocFlow v0.6.

CACH SU DUNG
1. Mo app DocFlow -> tab "Chuyen doi".
2. Chon muc "PDF sang Excel".
3. Chon tep .pdf tren dien thoai.
4. Chon ten/thu muc luu tep XLSX moi.
5. Ung dung chuyen doi offline, sau khi luu se mo tep Excel ket qua.

PHAI LUU Y
- Chi PDF co lop chu (selectable text) duoc trich xuat. PDF scan hoac anh chup can OCR offline chua duoc tich hop.
- PDF khong luu cau truc o Excel: phan bo cot bang toa do chu la uoc luong, khong dam bao giong 100% bang goc.
- Moi trang PDF thanh mot sheet Excel (Trang 1, Trang 2...).
- File goc khong bi thay doi, luu thanh ban XLSX moi.
- Hien gioi han de bao ve bo nho: 100 trang, 100.000 o, 100.000 ky tu cho moi trang PDF.
- So co dau cham/phay mo ho duoc giu nguyen dang chu de tranh doi gia tri sai.
- Van giu 5 Kotlin trong du an, khong tich hop may chu va khong dung SDK Office thuong mai.

KIEM THU DA THUC HIEN
- Bo thuat toan xac dinh dong/cot thu nghiem voi file PDF co bang 4 cot, ket qua dung 3 dong x 4 cot.
- XLSX ket qua duoc mo lai bang OfficeOoxml.readWorkbook cua DocFlow.
- Kotlin xu ly DOCX/XLSX da duoc test doc lap; ma moi da duoc kiem tra bien dich voi stub API.
- Chua build APK bang Android Studio/SDK that trong moi truong nay.

NEU GAP LOI
- Android Studio: Build -> Rebuild Project.
- Gui lai Build Output hoac anh man hinh loi.
- Neu PDF scan khong chuyen duoc, ban cap nhat OCR offline se can model Tesseract va bo may nhan dang bang, lam rieng.
