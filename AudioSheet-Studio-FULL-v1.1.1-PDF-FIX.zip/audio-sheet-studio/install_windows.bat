@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo =============================================
echo  AudioSheet Studio 1.1.1 - Cai dat Windows
echo =============================================
echo.

py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo [LOI] Khong tim thay Python 3.11.
  echo Tai Python 3.11 tai https://www.python.org/downloads/
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Tao moi truong Python cho website...
  py -3.11 -m venv .venv
  if errorlevel 1 exit /b 1
)

set "PROJECT_PYTHON=%CD%\.venv\Scripts\python.exe"
echo [2/5] Cai Basic Pitch, MusicXML va PDF du phong...
"%PROJECT_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip wheel "setuptools==80.9.0"
if errorlevel 1 exit /b 1
"%PROJECT_PYTHON%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1

echo [3/5] Cai bo PDF Verovio tuy chon...
"%PROJECT_PYTHON%" -m pip install --disable-pip-version-check -r requirements_pdf_optional.txt
if errorlevel 1 (
  echo [CANH BAO] Khong cai duoc Verovio. PDF van xuat duoc bang ReportLab.
)

echo [4/5] Tai bo hien thi sheet OSMD...
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\download_osmd.ps1

echo [5/5] Kiem tra thanh phan cot loi va xuat PDF thu...
"%PROJECT_PYTHON%" scripts\check_install.py
if errorlevel 1 exit /b 1

where ffmpeg >nul 2>&1
if errorlevel 1 (
  echo.
  echo [CANH BAO] Chua tim thay FFmpeg trong PATH.
  echo Dat ffmpeg.exe va ffprobe.exe vao PATH truoc khi xu ly audio.
)

echo.
echo [OK] Da cai xong website va bo xuat PDF.
exit /b 0
