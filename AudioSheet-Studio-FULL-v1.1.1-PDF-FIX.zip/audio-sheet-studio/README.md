# AudioSheet Studio 1.1.1 - Demucs, 3 pipelines and reliable PDF

AudioSheet Studio converts audio or supported YouTube sources into three synchronized arrangements:

- A: vocal melody
- B: easy piano arrangement
- C: fuller stem-based transcription

Each arrangement can be played with piano samples and exported as MIDI, MusicXML and PDF.

## PDF engines

1. MuseScore when installed.
2. Verovio when available.
3. Built-in ReportLab notation fallback.

The third engine ensures that PDF download still works when Verovio SVG conversion fails on Windows. Run `SUA_PDF_VA_CHAY.bat` after copying this version over the old folder.
