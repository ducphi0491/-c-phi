from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

from app import pdf_export
from app.live_score import create_arrangement_xml


class FakeToolkit:
    def setOptions(self, options):
        self.options = options

    def setInputFrom(self, value):
        self.input_from = value

    def setResourcePath(self, value):
        self.resource_path = value

    def loadData(self, xml):
        return bool(xml)

    def getPageCount(self):
        return 1

    def renderToSVG(self, page, xml_declaration):
        return '''<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1100" viewBox="0 0 800 1100">
        <rect x="1" y="1" width="798" height="1098" fill="white" stroke="black"/>
        <text x="60" y="90" font-size="28">AudioSheet PDF test</text>
        <line x1="60" y1="160" x2="740" y2="160" stroke="black"/>
        </svg>'''


def sample_xml() -> bytes:
    return create_arrangement_xml(
        [
            {"start": 0, "end": 0.8, "pitch": 60, "velocity": 80, "staff": "upper"},
            {"start": 0, "end": 1.2, "pitch": 43, "velocity": 68, "staff": "lower"},
        ],
        "light",
        "PDF demo",
        100,
        "4/4",
        16,
        60,
        2.0,
    )


def assert_pdf(path: Path) -> None:
    data = path.read_bytes()
    assert data.startswith(b"%PDF-")
    assert b"%%EOF" in data[-2048:]
    assert path.stat().st_size > 900


def test_verovio_pdf_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setitem(sys.modules, "verovio", SimpleNamespace(toolkit=lambda: FakeToolkit(), __file__=__file__))
    monkeypatch.setattr(pdf_export, "find_musescore", lambda: None)
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(sample_xml())
    pdf_path = tmp_path / "score.pdf"
    engine = pdf_export.export_musicxml_to_pdf(xml_path, pdf_path)
    assert engine == "verovio"
    assert_pdf(pdf_path)


def test_reportlab_fallback_uses_real_musicxml(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(pdf_export, "find_musescore", lambda: None)
    monkeypatch.setattr(pdf_export, "_verovio_available", lambda: False)
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(sample_xml())
    pdf_path = tmp_path / "score.pdf"
    engine = pdf_export.export_musicxml_to_pdf(xml_path, pdf_path)
    assert engine == "reportlab"
    assert_pdf(pdf_path)


def test_reportlab_fallback_after_verovio_error(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(pdf_export, "find_musescore", lambda: None)
    monkeypatch.setattr(pdf_export, "_verovio_available", lambda: True)
    monkeypatch.setattr(pdf_export, "_export_with_verovio", lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("SVG failure")))
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(sample_xml())
    pdf_path = tmp_path / "score.pdf"
    engine = pdf_export.export_musicxml_to_pdf(xml_path, pdf_path)
    assert engine == "reportlab"
    assert_pdf(pdf_path)
