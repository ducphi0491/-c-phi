@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PROJECT_PYTHON=%CD%\.venv\Scripts\python.exe"

echo ==================================================
echo  AudioSheet Studio 1.1.1 - Sua va kiem tra PDF
echo ==================================================
echo.

if not exist "%PROJECT_PYTHON%" (
  echo [CAI DAT] Chua co moi truong website. Dang cai...
  call "%~dp0install_windows.bat"
  if errorlevel 1 goto :failure
)

echo [1/3] Kiem tra ReportLab...
"%PROJECT_PYTHON%" -c "import reportlab" >nul 2>&1
if errorlevel 1 (
  echo [CAI DAT] Dang cai ReportLab...
  "%PROJECT_PYTHON%" -m pip install --disable-pip-version-check "reportlab>=4,<5"
  if errorlevel 1 goto :failure
)

echo [2/3] Tao file PDF kiem tra thuc te...
"%PROJECT_PYTHON%" scripts\check_pdf.py
if errorlevel 1 goto :failure

echo [3/3] Mo thu muc file PDF kiem tra...
start "" "%CD%\data\pdf_test"

echo.
echo [OK] Neu thay AudioSheet_PDF_TEST.pdf, bo xuat PDF da hoat dong.
echo Dang khoi dong website...
call "%~dp0run_windows.bat"
exit /b %ERRORLEVEL%

:failure
echo.
echo [LOI] Sua PDF that bai. Gui anh cua so nay de kiem tra.
pause
exit /b 1
