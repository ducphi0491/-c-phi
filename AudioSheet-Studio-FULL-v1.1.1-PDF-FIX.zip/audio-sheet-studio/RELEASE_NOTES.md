# AudioSheet Studio 1.1.1 - 2026-11-03

## PDF reliability fix

- Corrected the Verovio MusicXML input format from `musicxml` to `xml`.
- Configured the Verovio resource path before rendering.
- Added a built-in ReportLab MusicXML-to-PDF fallback.
- Added real PDF signature and EOF validation.
- Added a browser download handler that shows the actual server error instead of silently failing.
- Added `SUA_PDF_VA_CHAY.bat` and `scripts/check_pdf.py`.
- Made Verovio optional; PDF remains available with ReportLab.
- Added a real MusicXML PDF self-test to startup diagnostics.

Demucs, Basic Pitch, A/B/C arrangements and piano playback are unchanged.
