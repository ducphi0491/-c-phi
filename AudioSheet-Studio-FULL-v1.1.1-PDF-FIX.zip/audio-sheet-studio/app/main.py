from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import mimetypes
import platform
import threading
from pathlib import Path
from typing import Annotated, Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .audio_tools import command_exists
from .config import APP_VERSION, settings
from .demo_score import create_demo_musicxml, demo_note_events
from .job_store import JobNotFoundError, job_store
from .live_score import create_arrangement_xml
from .pdf_export import PDFExportError, export_musicxml_to_pdf, is_valid_pdf, pdf_engine_status
from .playback_modes import (
    apply_reference_to_payload,
    midi_to_events,
    prepare_variants,
    write_mode_midi,
)
from .processor import submit_job
from .security import validate_audio_filename, validate_youtube_url
from .stem_separator import demucs_info


app = FastAPI(
    title="AudioSheet Studio",
    version=APP_VERSION,
    description="Local-first audio-to-sheet transcription with stem separation and PDF export.",
)
app.mount("/static", StaticFiles(directory=settings.web_dir), name="static")
_score_cache_lock = threading.RLock()
PIANO_SAMPLES = (
    "A0", "C1", "Ds1", "Fs1", "A1", "C2", "Ds2", "Fs2", "A2", "C3",
    "Ds3", "Fs3", "A3", "C4", "Ds4", "Fs4", "A4", "C5", "Ds5", "Fs5",
    "A5", "C6", "Ds6", "Fs6", "A6", "C7", "Ds7", "Fs7", "A7", "C8",
)
VARIANTS = {"melody", "light", "full"}
VARIANT_LETTERS = {"melody": "A", "light": "B", "full": "C"}


async def _save_upload(upload: UploadFile, destination: Path, limit_bytes: int) -> int:
    total = 0
    try:
        with destination.open("wb") as handle:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit_bytes:
                    raise ValueError(
                        f"Upload is larger than the configured {settings.max_upload_mb} MB limit"
                    )
                handle.write(chunk)
    finally:
        await upload.close()
    if total == 0:
        raise ValueError("The uploaded file is empty")
    return total


def _get_public_job(job_id: str) -> dict[str, Any]:
    try:
        return job_store.public(job_store.get(job_id))
    except JobNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Job not found") from exc


def _path_identity(path: Path) -> str:
    if not path.is_file():
        return "missing"
    stat = path.stat()
    return f"{stat.st_mtime_ns}:{stat.st_size}"


def _load_reference(directory: Path) -> list[dict[str, Any]] | None:
    reference_file = directory / "reference.mid"
    if not reference_file.is_file():
        return None
    try:
        return midi_to_events(str(reference_file))
    except (ValueError, OSError, EOFError) as exc:
        raise HTTPException(status_code=422, detail="Invalid reference MIDI: " + str(exc)[:180]) from exc


def _load_arrangements(job_id: str, job: dict[str, Any]) -> dict[str, Any]:
    directory = job_store.job_dir(job_id)
    arrangements_file = directory / "arrangements.json"
    payload: dict[str, Any]
    if arrangements_file.is_file():
        try:
            raw = json.loads(arrangements_file.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise HTTPException(status_code=422, detail="Could not read arrangements.json") from exc
        if not isinstance(raw, dict) or not isinstance(raw.get("modes"), dict):
            raise HTTPException(status_code=422, detail="Invalid arrangements.json")
        payload = copy.deepcopy(raw)
    else:
        note_file = directory / "note_events.json"
        if note_file.is_file():
            try:
                notes = json.loads(note_file.read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                raise HTTPException(status_code=422, detail="Could not read note_events.json") from exc
            if not isinstance(notes, list):
                raise HTTPException(status_code=422, detail="Invalid note_events.json")
        elif job.get("source_type") == "demo":
            notes = [
                {"start": start, "end": end, "pitch": pitch, "velocity": round(velocity * 127)}
                for start, end, pitch, velocity, _ in demo_note_events()
            ]
        else:
            raise HTTPException(status_code=404, detail="This job does not have note data")
        payload = prepare_variants(
            notes,
            bpm=float(job.get("bpm_used") or 100),
            time_signature=str(job.get("time_signature") or "4/4"),
            split_pitch=int(job.get("split_pitch") or 60),
        )
    return apply_reference_to_payload(payload, _load_reference(directory))


def _playback_for_job(job_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    job = _get_public_job(job_id)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail="The transcription is not finished yet")
    return _load_arrangements(job_id, job), job


def _score_parameters(payload: dict[str, Any], job: dict[str, Any]) -> dict[str, Any]:
    analysis = payload.get("analysis") if isinstance(payload.get("analysis"), dict) else {}
    key = analysis.get("key") if isinstance(analysis.get("key"), dict) else {}
    chords = analysis.get("chords") if isinstance(analysis.get("chords"), list) else []
    return {
        "title": str(job.get("title") or job.get("source_name") or "AudioSheet Studio"),
        "bpm": float(job.get("bpm_used") or 100),
        "time_signature": str(job.get("time_signature") or "4/4"),
        "quantization": int(job.get("quantization") or 16),
        "split_pitch": int(job.get("split_pitch") or 60),
        "duration_seconds": float(payload.get("duration_seconds") or job.get("duration_seconds") or 0),
        "key_fifths": int(key.get("fifths") or 0),
        "chords": chords,
    }


def _ensure_score_file(job_id: str, variant: str) -> tuple[Path, dict[str, Any], dict[str, Any]]:
    if variant not in VARIANTS:
        raise HTTPException(status_code=400, detail="Unknown sheet arrangement")
    payload, job = _playback_for_job(job_id)
    notes = payload.get("modes", {}).get(variant, {}).get("notes", [])
    if not notes:
        raise HTTPException(status_code=422, detail="No notes in this arrangement")
    directory = job_store.job_dir(job_id)
    source = directory / "arrangements.json"
    legacy = directory / "note_events.json"
    reference = directory / "reference.mid"
    params = _score_parameters(payload, job)
    signature = "|".join(
        [
            "score_v111",
            variant,
            _path_identity(source if source.is_file() else legacy),
            _path_identity(reference) if variant == "full" else "no_reference",
            json.dumps(params, ensure_ascii=False, sort_keys=True, default=str),
        ]
    )
    checksum = hashlib.sha256(signature.encode("utf-8")).hexdigest()[:16]
    destination = directory / f"piano_mode_{variant}_{checksum}.musicxml"
    with _score_cache_lock:
        if not destination.is_file():
            try:
                xml = create_arrangement_xml(notes, variant, **params)
            except (TypeError, ValueError) as exc:
                raise HTTPException(
                    status_code=422, detail="Could not arrange MusicXML: " + str(exc)[:180]
                ) from exc
            temporary = destination.with_suffix(".musicxml.tmp")
            temporary.write_bytes(xml)
            temporary.replace(destination)
            for stale in directory.glob(f"piano_mode_{variant}_*.musicxml"):
                if stale != destination:
                    stale.unlink(missing_ok=True)
            for stale in directory.glob(f"piano_mode_{variant}_*.pdf"):
                if stale.stem != destination.stem:
                    stale.unlink(missing_ok=True)
    return destination, payload, job


def _ensure_pdf_file(job_id: str, variant: str) -> Path:
    score_file, _, _ = _ensure_score_file(job_id, variant)
    destination = score_file.with_suffix(".pdf")
    with _score_cache_lock:
        needs_export = (
            not is_valid_pdf(destination)
            or destination.stat().st_mtime_ns < score_file.stat().st_mtime_ns
        )
        if needs_export:
            destination.unlink(missing_ok=True)
            try:
                export_musicxml_to_pdf(score_file, destination)
            except PDFExportError as exc:
                raise HTTPException(status_code=503, detail=str(exc)[:400]) from exc
        if not is_valid_pdf(destination):
            destination.unlink(missing_ok=True)
            raise HTTPException(status_code=503, detail="PDF renderer did not create a valid file")
    return destination


@app.get("/api/health")
def health() -> dict[str, Any]:
    demucs = demucs_info()
    pdf = pdf_engine_status()
    return {
        "status": "ok",
        "version": APP_VERSION,
        "pipelines": {
            "A": "vocal_melody",
            "B": "easy_piano_arrangement",
            "C": "stem_full_transcription",
        },
        "piano_playback_modes": ["melody", "light", "full"],
        "dynamic_musicxml": True,
        "dynamic_pdf": True,
        "sampled_piano_files": sum(
            (settings.web_dir / "piano_samples" / f"{name}.mp3").is_file()
            for name in PIANO_SAMPLES
        ),
        "sampled_piano_expected": len(PIANO_SAMPLES),
        "python": platform.python_version(),
        "ffmpeg": command_exists("ffmpeg") and command_exists("ffprobe"),
        "basic_pitch": importlib.util.find_spec("basic_pitch") is not None,
        "music21": importlib.util.find_spec("music21") is not None,
        "yt_dlp": importlib.util.find_spec("yt_dlp") is not None,
        "demucs": demucs,
        "pdf": pdf,
        "youtube_enabled": settings.allow_youtube,
        "local_osmd": (settings.web_dir / "vendor" / "opensheetmusicdisplay.min.js").exists(),
        "limits": {
            "max_upload_mb": settings.max_upload_mb,
            "max_audio_seconds": settings.max_audio_seconds,
            "workers": settings.worker_count,
        },
    }


@app.post("/api/jobs", status_code=202)
async def create_job(
    audio_file: Annotated[UploadFile | None, File()] = None,
    youtube_url: Annotated[str | None, Form()] = None,
    title: Annotated[str, Form()] = "",
    mode: Annotated[str, Form()] = "piano",
    bpm: Annotated[float, Form()] = 0,
    time_signature: Annotated[str, Form()] = "4/4",
    quantization: Annotated[int, Form()] = 16,
    split_pitch: Annotated[int, Form()] = 60,
    minimum_midi: Annotated[int, Form()] = 36,
    maximum_midi: Annotated[int, Form()] = 96,
    onset_threshold: Annotated[float, Form()] = 0.5,
    frame_threshold: Annotated[float, Form()] = 0.3,
    minimum_note_length_ms: Annotated[float, Form()] = 127.7,
    separate_stems: Annotated[bool, Form()] = False,
    accepted_rights: Annotated[bool, Form()] = False,
) -> dict[str, Any]:
    has_file = audio_file is not None and bool(audio_file.filename)
    has_url = bool((youtube_url or "").strip())
    if has_file == has_url:
        raise HTTPException(status_code=400, detail="Choose exactly one input: audio file or YouTube URL")
    if not accepted_rights:
        raise HTTPException(status_code=400, detail="You must confirm that you have the right to process this audio")
    if mode not in {"piano", "lead", "raw"}:
        raise HTTPException(status_code=400, detail="Mode must be piano, lead, or raw")
    if time_signature not in {"4/4", "3/4", "6/8"}:
        raise HTTPException(status_code=400, detail="Unsupported time signature")
    if quantization not in {8, 16, 32}:
        raise HTTPException(status_code=400, detail="Quantization must be 8, 16, or 32")
    if bpm != 0 and not 40 <= bpm <= 240:
        raise HTTPException(status_code=400, detail="BPM must be 0 or between 40 and 240")
    if not 36 <= split_pitch <= 84:
        raise HTTPException(status_code=400, detail="Piano split pitch must be between MIDI 36 and 84")
    if not 0 <= minimum_midi < maximum_midi <= 127:
        raise HTTPException(status_code=400, detail="Invalid MIDI note range")
    if not 0.05 <= onset_threshold <= 0.95 or not 0.05 <= frame_threshold <= 0.95:
        raise HTTPException(status_code=400, detail="Detection thresholds must be between 0.05 and 0.95")
    if not 20 <= minimum_note_length_ms <= 1000:
        raise HTTPException(status_code=400, detail="Minimum note length must be between 20 and 1000 ms")

    if separate_stems and not demucs_info().get("available"):
        raise HTTPException(
            status_code=503,
            detail=(
                "Demucs chưa sẵn sàng. Đóng website, chạy CAI_DEMUCS_AI.bat rồi mở lại; "
                "hoặc bỏ chọn mục tự động tách giọng và nhạc cụ để dùng chế độ dự phòng."
            ),
        )

    clean_title = title.strip()[:200]
    payload: dict[str, Any] = {
        "source_type": "upload" if has_file else "youtube",
        "source_name": "",
        "title": clean_title,
        "mode": mode,
        "bpm_requested": float(bpm),
        "bpm_used": None,
        "time_signature": time_signature,
        "quantization": int(quantization),
        "split_pitch": int(split_pitch),
        "minimum_midi": int(minimum_midi),
        "maximum_midi": int(maximum_midi),
        "onset_threshold": float(onset_threshold),
        "frame_threshold": float(frame_threshold),
        "minimum_note_length_ms": float(minimum_note_length_ms),
        "separate_stems": bool(separate_stems),
        "duration_seconds": None,
    }

    if has_url:
        if not settings.allow_youtube:
            raise HTTPException(status_code=403, detail="YouTube input is disabled by the server")
        try:
            payload["youtube_url"] = validate_youtube_url(youtube_url or "")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    job = job_store.create(payload)
    try:
        if has_file and audio_file is not None:
            safe_name = validate_audio_filename(audio_file.filename or "audio")
            suffix = Path(safe_name).suffix.lower()
            stored_name = f"source{suffix}"
            destination = job_store.job_dir(job["id"]) / stored_name
            await _save_upload(audio_file, destination, settings.max_upload_mb * 1024 * 1024)
            source_name = Path(safe_name).stem[:200]
            job = job_store.update(
                job["id"],
                source_filename=stored_name,
                source_name=source_name,
                title=clean_title or source_name,
            )
        submit_job(job["id"])
        return job_store.public(job)
    except ValueError as exc:
        job_store.delete(job["id"])
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:
        job_store.delete(job["id"])
        raise


@app.post("/api/demo", status_code=201)
def create_demo(mode: str = "piano") -> dict[str, Any]:
    if mode not in {"piano", "lead", "raw"}:
        raise HTTPException(status_code=400, detail="Mode must be piano, lead, or raw")
    job = job_store.create(
        {
            "source_type": "demo",
            "source_name": "Built-in C major demo",
            "title": "AudioSheet Studio Demo",
            "mode": mode,
            "bpm_requested": 100.0,
            "bpm_used": 100.0,
            "time_signature": "4/4",
            "quantization": 16,
            "split_pitch": 60,
            "separate_stems": False,
            "duration_seconds": 9.6,
        }
    )
    directory = job_store.job_dir(job["id"])
    try:
        notes = [
            {"start": start, "end": end, "pitch": pitch, "velocity": round(velocity * 127)}
            for start, end, pitch, velocity, _ in demo_note_events()
        ]
        (directory / "note_events.json").write_text(
            json.dumps(notes, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        arrangements = prepare_variants(notes, bpm=100, time_signature="4/4", split_pitch=60)
        (directory / "arrangements.json").write_text(
            json.dumps(arrangements, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        create_demo_musicxml(directory / "sheet.musicxml", mode=mode)
        job = job_store.update(
            job["id"],
            status="done",
            progress=100,
            message="Demo score is ready",
            pipeline="demo",
            detected_key="C major",
            artifacts=[
                {
                    "filename": "sheet.musicxml",
                    "label": "Demo MusicXML sheet",
                    "kind": "musicxml",
                    "url": f"/api/jobs/{job['id']}/files/sheet.musicxml",
                }
            ],
        )
        return job_store.public(job)
    except Exception as exc:
        job_store.update(job["id"], status="failed", progress=100, error=str(exc), message="Demo failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/jobs/{job_id}/playback")
def get_job_playback(job_id: str) -> dict[str, Any]:
    return _playback_for_job(job_id)[0]


@app.get("/api/jobs/{job_id}/playback-midi/{variant}")
def download_playback_midi(job_id: str, variant: str) -> FileResponse:
    if variant not in VARIANTS:
        raise HTTPException(status_code=400, detail="Unknown playback arrangement")
    payload, job = _playback_for_job(job_id)
    notes = payload["modes"][variant]["notes"]
    if not notes:
        raise HTTPException(status_code=422, detail="There are no notes in this arrangement")
    destination = job_store.job_dir(job_id) / f"piano_{variant}.mid"
    write_mode_midi(notes, str(destination), bpm=float(job.get("bpm_used") or 100))
    return FileResponse(
        destination,
        media_type="audio/midi",
        filename=f"AudioSheet_{VARIANT_LETTERS[variant]}_{variant}.mid",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/api/jobs/{job_id}/playback-score/{variant}")
def download_playback_score(job_id: str, variant: str) -> FileResponse:
    destination, _, _ = _ensure_score_file(job_id, variant)
    return FileResponse(
        destination,
        media_type="application/vnd.recordare.musicxml+xml",
        filename=f"AudioSheet_{VARIANT_LETTERS[variant]}_{variant}.musicxml",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/api/jobs/{job_id}/playback-pdf/{variant}")
def download_playback_pdf(job_id: str, variant: str) -> FileResponse:
    if variant not in VARIANTS:
        raise HTTPException(status_code=400, detail="Unknown PDF arrangement")
    destination = _ensure_pdf_file(job_id, variant)
    return FileResponse(
        destination,
        media_type="application/pdf",
        filename=f"AudioSheet_{VARIANT_LETTERS[variant]}_{variant}.pdf",
        headers={"Cache-Control": "no-store"},
    )


@app.post("/api/jobs/{job_id}/reference-midi")
async def upload_reference_midi(job_id: str, midi_file: Annotated[UploadFile, File()]) -> dict[str, Any]:
    job = _get_public_job(job_id)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail="Choose a completed transcription")
    source_name = Path(midi_file.filename or "").name
    if Path(source_name).suffix.lower() not in {".mid", ".midi"}:
        await midi_file.close()
        raise HTTPException(status_code=400, detail="Please select a .mid or .midi file")
    destination = job_store.job_dir(job_id) / "reference.mid"
    temp = destination.with_suffix(".mid.upload")
    try:
        await _save_upload(midi_file, temp, limit_bytes=4 * 1024 * 1024)
        with temp.open("rb") as handle:
            if handle.read(4) != b"MThd":
                raise ValueError("Not a valid MIDI file")
        midi_to_events(str(temp))
        temp.replace(destination)
    except ValueError as exc:
        temp.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc)[:260]) from exc
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    return _playback_for_job(job_id)[0]


@app.delete("/api/jobs/{job_id}/reference-midi", status_code=204)
def delete_reference_midi(job_id: str) -> None:
    job = _get_public_job(job_id)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail="Choose a completed transcription")
    (job_store.job_dir(job_id) / "reference.mid").unlink(missing_ok=True)


@app.get("/api/jobs")
def list_jobs(limit: int = 20) -> list[dict[str, Any]]:
    return [job_store.public(job) for job in job_store.list_recent(limit)]


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    return _get_public_job(job_id)


@app.delete("/api/jobs/{job_id}", status_code=204)
def delete_job(job_id: str) -> None:
    try:
        job_store.delete(job_id)
    except JobNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Job not found") from exc


@app.get("/api/jobs/{job_id}/files/{filename}")
def get_job_file(job_id: str, filename: str) -> FileResponse:
    job = _get_public_job(job_id)
    safe_name = Path(filename).name
    if safe_name != filename:
        raise HTTPException(status_code=404, detail="Artifact not found")
    allowed = {Path(artifact["filename"]).name for artifact in job.get("artifacts", [])}
    if safe_name not in allowed:
        raise HTTPException(status_code=404, detail="Artifact not found")
    path = job_store.job_dir(job_id) / safe_name
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Artifact not found")
    media_type, _ = mimetypes.guess_type(path.name)
    if path.suffix.lower() in {".musicxml", ".xml"}:
        media_type = "application/vnd.recordare.musicxml+xml"
    elif path.suffix.lower() == ".mid":
        media_type = "audio/midi"
    return FileResponse(path, media_type=media_type or "application/octet-stream", filename=path.name)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(settings.web_dir / "index.html", headers={"Cache-Control": "no-cache"})
