from __future__ import annotations

import io
import os
import shutil
from pathlib import Path
from typing import Any

from .audio_tools import run_command
from .config import settings
from .simple_pdf import SimplePDFError, export_simple_musicxml_pdf


class PDFExportError(RuntimeError):
    pass


def is_valid_pdf(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size < 900:
        return False
    try:
        data = path.read_bytes()
    except OSError:
        return False
    return data.startswith(b"%PDF-") and b"%%EOF" in data[-2048:]


def find_musescore() -> str | None:
    candidates: list[str] = [
        settings.musescore_bin,
        "MuseScore4",
        "musescore4",
        "mscore4",
        "MuseScore3",
        "musescore3",
        "mscore",
    ]
    if os.name == "nt":
        for base_name in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
            base = os.getenv(base_name)
            if not base:
                continue
            candidates.extend(
                [
                    str(Path(base) / "MuseScore 4" / "bin" / "MuseScore4.exe"),
                    str(Path(base) / "MuseScore 4" / "bin" / "MuseScore.exe"),
                    str(Path(base) / "MuseScore 3" / "bin" / "MuseScore3.exe"),
                ]
            )
    for candidate in candidates:
        if not candidate:
            continue
        explicit = Path(candidate)
        if explicit.is_file():
            return str(explicit)
        located = shutil.which(candidate)
        if located:
            return located
    return None


def _export_with_musescore(musicxml_path: Path, pdf_path: Path) -> bool:
    executable = find_musescore()
    if not executable:
        return False
    temporary = pdf_path.with_suffix(".musescore.tmp.pdf")
    temporary.unlink(missing_ok=True)
    try:
        run_command([executable, "-o", str(temporary), str(musicxml_path)], timeout=300)
        if not is_valid_pdf(temporary):
            return False
        temporary.replace(pdf_path)
        return True
    except Exception:
        return False
    finally:
        temporary.unlink(missing_ok=True)


def _verovio_available() -> bool:
    try:
        import verovio  # noqa: F401
        from reportlab.graphics import renderPDF  # noqa: F401
        from svglib.svglib import svg2rlg  # noqa: F401
        return True
    except Exception:
        return False


def _configure_verovio_resource_path(toolkit: Any, module: Any) -> None:
    module_path = Path(getattr(module, "__file__", "")).resolve().parent
    candidates = [module_path / "data", module_path / "resources"]
    for candidate in candidates:
        if candidate.is_dir() and hasattr(toolkit, "setResourcePath"):
            toolkit.setResourcePath(str(candidate))
            return


def _export_with_verovio(musicxml_path: Path, pdf_path: Path) -> bool:
    import verovio
    from reportlab.graphics import renderPDF
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from svglib.svglib import svg2rlg

    xml = musicxml_path.read_text(encoding="utf-8")
    toolkit = verovio.toolkit()
    _configure_verovio_resource_path(toolkit, verovio)
    if hasattr(toolkit, "setInputFrom"):
        toolkit.setInputFrom("xml")
    toolkit.setOptions(
        {
            "inputFrom": "xml",
            "pageWidth": 2100,
            "pageHeight": 2970,
            "scale": 38,
            "adjustPageHeight": False,
            "breaks": "auto",
            "pageMarginTop": 70,
            "pageMarginBottom": 70,
            "pageMarginLeft": 70,
            "pageMarginRight": 70,
        }
    )
    loaded = toolkit.loadData(xml)
    if loaded is False:
        raise PDFExportError("Verovio could not load the MusicXML")
    page_count = max(1, int(toolkit.getPageCount()))
    page_width, page_height = A4
    margin = 24.0
    temporary = pdf_path.with_suffix(".verovio.tmp.pdf")
    temporary.unlink(missing_ok=True)
    pdf = canvas.Canvas(str(temporary), pagesize=A4, pageCompression=1)
    pdf.setTitle(musicxml_path.stem)
    try:
        for page_number in range(1, page_count + 1):
            svg = toolkit.renderToSVG(page_number, False)
            if not svg or "<svg" not in svg:
                raise PDFExportError(f"Verovio returned no SVG for page {page_number}")
            drawing = svg2rlg(io.BytesIO(svg.encode("utf-8")))
            if drawing is None or not drawing.width or not drawing.height:
                raise PDFExportError(f"Could not convert Verovio SVG page {page_number}")
            factor = min(
                (page_width - margin * 2) / float(drawing.width),
                (page_height - margin * 2) / float(drawing.height),
            )
            drawing.scale(factor, factor)
            x = (page_width - float(drawing.width) * factor) / 2
            y = page_height - margin - float(drawing.height) * factor
            renderPDF.draw(drawing, pdf, x, max(margin, y))
            pdf.showPage()
        pdf.save()
    except Exception:
        try:
            pdf.save()
        except Exception:
            pass
        temporary.unlink(missing_ok=True)
        raise
    if not is_valid_pdf(temporary):
        temporary.unlink(missing_ok=True)
        raise PDFExportError("Verovio produced an invalid PDF")
    temporary.replace(pdf_path)
    return True


def _reportlab_available() -> bool:
    try:
        import reportlab  # noqa: F401
        return True
    except Exception:
        return False


def _export_with_reportlab(musicxml_path: Path, pdf_path: Path) -> bool:
    temporary = pdf_path.with_suffix(".reportlab.tmp.pdf")
    temporary.unlink(missing_ok=True)
    try:
        export_simple_musicxml_pdf(musicxml_path, temporary)
        if not is_valid_pdf(temporary):
            return False
        temporary.replace(pdf_path)
        return True
    finally:
        temporary.unlink(missing_ok=True)


def export_musicxml_to_pdf(musicxml_path: Path, pdf_path: Path) -> str:
    """Export MusicXML to PDF with three independent engines.

    MuseScore gives the highest fidelity when installed. Verovio is the next
    choice. A ReportLab notation renderer is always attempted last so PDF
    download still works when Verovio or its SVG conversion fails on Windows.
    """
    if not musicxml_path.is_file():
        raise PDFExportError(f"MusicXML file not found: {musicxml_path}")
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    pdf_path.unlink(missing_ok=True)
    errors: list[str] = []

    if _export_with_musescore(musicxml_path, pdf_path):
        return "musescore"

    if _verovio_available():
        try:
            if _export_with_verovio(musicxml_path, pdf_path):
                return "verovio"
        except Exception as exc:
            errors.append(f"Verovio: {exc}")
            pdf_path.unlink(missing_ok=True)

    if _reportlab_available():
        try:
            if _export_with_reportlab(musicxml_path, pdf_path):
                return "reportlab"
        except (SimplePDFError, Exception) as exc:
            errors.append(f"ReportLab: {exc}")
            pdf_path.unlink(missing_ok=True)

    detail = "; ".join(errors[-2:]) if errors else "No PDF renderer is available"
    raise PDFExportError(f"PDF export failed. {detail}")


def pdf_engine_status() -> dict[str, Any]:
    musescore = find_musescore()
    verovio = _verovio_available()
    reportlab = _reportlab_available()
    preferred = "musescore" if musescore else "verovio" if verovio else "reportlab" if reportlab else None
    return {
        "available": bool(musescore or verovio or reportlab),
        "preferred": preferred,
        "musescore": bool(musescore),
        "verovio": verovio,
        "reportlab": reportlab,
        "fallback": "reportlab" if reportlab else None,
    }
