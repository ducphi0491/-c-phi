# Third-party notices

AudioSheet Studio is an independent implementation and does not include or copy code from ledutu.com.

Major installed or loaded components include:

- Spotify Basic Pitch 0.4.0 - Apache License 2.0
- TensorFlow 2.15.x - Apache License 2.0
- Demucs 4.1.0 - MIT License
- PyTorch / TorchAudio - BSD-style license
- music21 10.5.2 - BSD 3-Clause License
- Verovio 6.3.0 - LGPL-3.0-or-later
- ReportLab - BSD License
- svglib - LGPL-3.0-or-later
- OpenSheetMusicDisplay 2.1.3 - BSD 3-Clause License
- FastAPI - MIT License
- yt-dlp - The Unlicense; optional components may use other licenses
- FFmpeg - license depends on the selected build and enabled codecs

## Salamander Grand Piano V3 samples

Alexander Holm - Creative Commons Attribution 3.0 Unported.
Source: https://github.com/sfzinstruments/SalamanderGrandPiano
MP3 distribution used by the downloader: https://tonejs.github.io/audio/salamander/
See `LICENSE_PIANO_SAMPLES.txt`.
