# Hướng dẫn vận hành AudioSheet Studio 1.1.0

## Khởi động

Nhấp đúp `CHAY_WEBSITE.bat`. Ở lần đầu, chương trình cài hai môi trường riêng:

- `.venv`: FastAPI, Basic Pitch, TensorFlow, MusicXML và bộ xuất PDF.
- `.demucs-venv`: PyTorch CPU và Demucs.

Không đóng cửa sổ CMD khi đang dùng website.

## Tạo bản nhạc

1. Chọn file âm thanh hoặc link YouTube được phép xử lý.
2. Giữ bật **Tự động tách giọng và nhạc cụ bằng Demucs** cho một bài hát đầy đủ.
3. Nhập BPM nếu biết; để `0` để ước lượng.
4. Xác nhận quyền sử dụng rồi nhấn **Tạo sheet nhạc**.

Tiến trình gồm: lấy nguồn, chuẩn hóa, tách stem, nhận dạng, phối A/B/C và xuất file.

## Ba kết quả

- **A - Giai điệu hát:** một khuông, ưu tiên tuyến vocal.
- **B - Piano dễ chơi:** hai khuông, melody và tay trái đơn giản.
- **C - Phiên âm đầy đủ:** hai khuông, giữ nhiều thông tin từ vocal/bass/other hơn.

Khi chọn A/B/C, sheet, piano playback, MIDI, MusicXML và PDF cùng chuyển theo.

## PDF

Mỗi chế độ có nút PDF riêng. AudioSheet ưu tiên MuseScore khi `MUSESCORE_BIN` được khai báo; nếu không, dùng Verovio + ReportLab đã cài kèm.

## Khi Demucs lỗi hoặc chưa tải được model

Bỏ chọn **Tự động tách giọng và nhạc cụ bằng Demucs** để chạy pipeline dự phòng trên bản phối đầy đủ, hoặc chạy lại `CAI_DEMUCS_AI.bat` khi mạng ổn định.

## Kiểm tra hệ thống

Nhấp đúp `KIEM_TRA_HE_THONG.bat`. Trạng thái cần có:

- FFmpeg / FFprobe: OK
- Basic Pitch: OK
- Verovio / ReportLab / svglib: OK
- Demucs isolated environment: OK

## Dữ liệu

Kết quả nằm trong `data/jobs/<job_id>/`. Các file quan trọng gồm:

- `arrangements.json`
- `pipeline_manifest.json`
- `sheet_A_melody.pdf`
- `sheet_B_light.pdf`
- `sheet_C_full.pdf`
- `stem_vocals.wav`, `stem_bass.wav`, `stem_other.wav`, `stem_drums.wav`
