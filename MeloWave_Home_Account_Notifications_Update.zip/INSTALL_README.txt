MeloWave - HOME layout update (2026-10-16)

Changed Kotlin files (only):
  app/src/main/java/duc_phi/music/HomeScreen.kt
  app/src/main/java/duc_phi/music/MainActivity.kt

Installation:
1. Back up your original HomeScreen.kt and MainActivity.kt.
2. Copy the two .kt files from this ZIP over the existing files in your
   Android Studio project at the matching paths.
3. Keep all 16 WebP hero_headphones_*.webp images from the PREVIOUS
   MeloWave_Home_Banner_WebP_16_Mau release in:
   app/src/main/res/drawable-nodpi/
   Images are unchanged and intentionally omitted from this update ZIP.
4. Sync/Build/Run from Android Studio.

Changes:
- Home header: bell -> settings -> actual Google account avatar.
- Tapping avatar shows account information, login/Drive/settings actions.
- Bell shows local notification history and links to Android notification settings.
  Currently records daily music reminder notifications after this update.
  It does not fetch new server notifications or read other apps' notifications.
- LAN/Internet transfer is inside the banner ABOVE the three music sources.
- Audio conversion/video extraction panel follows directly after music sources.
- Recent songs appear below the audio tools.
- Original Google Drive/Link Drive icons, callbacks, player and themes remain.

No Gradle/dependency/manifest changes needed (project already has Coil).
Note: Project could not be built in this environment (no Android Gradle SDK).
