#!/usr/bin/env python3
"""TunerTools AI Drive incremental uploader. Python 3.10+, standard library.

The AI server writes append-only JSONL events after a file has been completed.
This tool folds new events into an atomic local JSON index, uploads pending
files ONLY, and does a full Server/Drive reconciliation once a day (or forced).
A cold start also performs a full reconciliation to seed the index.

No recursive Google Drive scans. No Drive deletion or overwrite. Two exact
remote folders: TunerTools_AppBackup/AI_Music/{stream_cache, lyrics}.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
import uuid
from contextlib import contextmanager
from urllib import error

from DOI_CHIEU_AI_DRIVE import (SOURCE_DEFAULT, TOKEN_DEFAULTS, FOLDER_MIME,
                                GoogleReader, valid_json)
from SYNC_AI_DRIVE import (choose_files, check_stable, remote_by_name,
                            remote_content_equal, upload_one, state_path,
                            acquire_lock, short_error, stamp, AUDIO_EXTS)

INDEX_NAME = 'AI_DRIVE_SYNC_INDEX.json'
QUEUE_NAME = 'AI_DRIVE_SYNC_QUEUE.jsonl'
QUEUE_LOCK_NAME = 'AI_DRIVE_SYNC_QUEUE.lock'
SCHEMA = 2
DEFAULT_FULL_INTERVAL = 24 * 3600
SOURCE_DIRS = {'ZING_AUDIO', 'ZING_JSON', 'YOUTUBE_CACHE'}
DEST_BUCKETS = {'audio': 'stream_cache', 'lyrics': 'lyrics'}


def ident(kind: str, filename: str) -> str:
    return kind + ':' + filename


def new_index() -> dict:
    return {'schema': SCHEMA, 'queue_offset': 0, 'last_full_scan_utc': '', 'files': {}}


def load_index(index_path: Path) -> dict:
    if not index_path.is_file():
        return new_index()
    obj = json.loads(index_path.read_text(encoding='utf-8-sig'))
    if not isinstance(obj, dict) or obj.get('schema') != SCHEMA or not isinstance(obj.get('files'), dict):
        raise RuntimeError('Sync index schema invalid; do NOT delete it. Use full reconciliation after backup')
    if not isinstance(obj.get('queue_offset'), int) or obj['queue_offset'] < 0:
        raise RuntimeError('Sync queue offset invalid')
    return obj


def write_index(path: Path, obj: dict) -> None:
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with tmp.open('w', encoding='utf-8', newline='\n') as stream:
            json.dump(obj, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


@contextmanager
def queue_lock(root: Path):
    """Matches the lock used by app.py (Windows msvcrt / Unix flock)."""
    with (root / QUEUE_LOCK_NAME).open('a+b') as fp:
        locked = False
        for _ in range(100):
            try:
                if os.name == 'nt':
                    import msvcrt
                    fp.seek(0)
                    if fp.read(1) == b'':
                        fp.seek(0)
                        fp.write(b'0')
                        fp.flush()
                    fp.seek(0)
                    msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
                break
            except (OSError, IOError):
                time.sleep(0.05)
        if not locked:
            raise RuntimeError('AI queue is busy; retry on next run')
        try:
            yield
        finally:
            if os.name == 'nt':
                fp.seek(0)
                msvcrt.locking(fp.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fp.fileno(), fcntl.LOCK_UN)


def candidate_path(root: Path, entry: dict) -> Path:
    """Never use arbitrary filesystem paths provided by queue events."""
    folder, filename, kind = entry.get('source'), entry.get('filename'), entry.get('kind')
    if folder not in SOURCE_DIRS or kind not in DEST_BUCKETS:
        raise RuntimeError('Invalid queue source/kind')
    if not isinstance(filename, str) or not filename or filename in ('.', '..') or Path(filename).name != filename:
        raise RuntimeError('Invalid queue filename')
    from SYNC_AI_DRIVE import ZING_JSON, YOUTUBE_JSON
    from DOI_CHIEU_AI_DRIVE import ZING_AUDIO_PATTERN, YT_AUDIO_PATTERN
    valid = ((folder == 'ZING_AUDIO' and kind == 'audio' and ZING_AUDIO_PATTERN.fullmatch(filename)) or
             (folder == 'YOUTUBE_CACHE' and kind == 'audio' and YT_AUDIO_PATTERN.fullmatch(filename)) or
             (folder == 'ZING_JSON' and kind == 'lyrics' and ZING_JSON.fullmatch(filename)) or
             (folder == 'YOUTUBE_CACHE' and kind == 'lyrics' and YOUTUBE_JSON.fullmatch(filename)))
    if not valid:
        raise RuntimeError('Invalid queue file type/name')
    return root / folder / filename


def apply_event(index: dict, entry: dict, root: Path) -> None:
    p = candidate_path(root, entry)
    # Never trust stored absolute paths; use known root and folders only.
    kind = entry['kind']
    key = ident(kind, p.name)
    previous = index['files'].get(key, {})
    # AI may enqueue the same file again after a harmless cache hit/rewrite.
    size, mtime = entry.get('size'), entry.get('mtime_ns')
    if not isinstance(size, int) or size <= 0 or not isinstance(mtime, int) or mtime <= 0:
        raise RuntimeError('Invalid queue file size/mtime')
    if (previous.get('status') == 'synced' and previous.get('size') == size
            and previous.get('mtime_ns') == mtime):
        return
    index['files'][key] = {
        'kind': kind, 'source': entry['source'], 'filename': p.name,
        'size': size, 'mtime_ns': mtime, 'status': 'pending',
        'queued_utc': entry.get('queued_utc', 0), 'updated_utc': stamp(),
    }


def fold_queue(root: Path, index: dict) -> int:
    """Consume only complete event lines; index+offset are saved atomically."""
    queue = root / QUEUE_NAME
    if not queue.exists():
        return 0
    consumed = 0
    with queue_lock(root):
        with queue.open('rb') as fp:
            total = queue.stat().st_size
            offset = index['queue_offset']
            if offset > total:
                # Queue was externally truncated/rotated: read what remains, no loss.
                offset = 0
            fp.seek(offset)
            while True:
                before = fp.tell()
                line = fp.readline()
                if not line or not line.endswith(b'\n'):
                    fp.seek(before)
                    break
                try:
                    record = json.loads(line.decode('utf-8-sig'))
                    if not isinstance(record, dict):
                        raise ValueError('Event must be JSON object')
                    apply_event(index, record, root)
                except Exception as exc:
                    raise RuntimeError('Invalid queue at byte %d (%s); fix queue before syncing' %
                                       (before, short_error(exc))) from exc
                consumed += 1
            index['queue_offset'] = fp.tell()
    return consumed


def full_scan_due(index: dict, hours: int) -> bool:
    last = index.get('last_full_scan_utc', '')
    if not last:
        return True
    try:
        last_time = datetime.fromisoformat(last.replace('Z', '+00:00'))
        return (datetime.now(timezone.utc) - last_time).total_seconds() >= hours * 3600
    except (TypeError, ValueError):
        return True


def collect_drive_folders(drive: GoogleReader) -> dict:
    root_id = drive.folder('root', 'TunerTools_AppBackup')
    ai_id = drive.folder(root_id, 'AI_Music')
    return {
        'audio': drive.folder(ai_id, 'stream_cache'),
        'lyrics': drive.folder(ai_id, 'lyrics'),
    }


def reconcile_full(root: Path, index: dict, drive: GoogleReader, ids: dict) -> dict:
    """Daily/cold-start inventory. No Drive writes, no remote audio downloads."""
    files, info = choose_files(root, None)
    remote = {
        'audio': remote_by_name(drive.list_files(ids['audio']), AUDIO_EXTS),
        'lyrics': remote_by_name(drive.list_files(ids['lyrics']), {'.json'}),
    }
    touched: set[str] = set()
    counts = {'audio_local': len(files['audio']), 'lyrics_local': len(files['lyrics']),
              'audio_drive': len(remote['audio']), 'lyrics_drive': len(remote['lyrics']),
              'pending': 0, 'synced_existing': 0, 'conflicts': 0}
    for kind in ('audio', 'lyrics'):
        for path in files[kind]:
            st = path.stat()
            key = ident(kind, path.name)
            touched.add(key)
            matches = remote[kind].get(path.name, [])
            old = index['files'].get(key) or {}
            rec = {
                'kind': kind, 'source': path.parent.name, 'filename': path.name,
                'size': st.st_size, 'mtime_ns': st.st_mtime_ns,
                'updated_utc': stamp(),
            }
            if len(matches) > 1:
                rec.update(status='conflict', error='Duplicate Drive filename')
                counts['conflicts'] += 1
            elif len(matches) == 1:
                other = matches[0]
                if str(other.get('size')) == str(st.st_size):
                    # New/replaced files must be checked by MD5, even if name
                    # and size match. Historical files are bootstrapped using
                    # size-only metadata to avoid thousands of API requests.
                    changed = bool(old) and (
                        old.get('status') != 'synced' or old.get('size') != st.st_size or
                        old.get('mtime_ns') != st.st_mtime_ns)
                    if changed:
                        rec.update(status='pending')
                        counts['pending'] += 1
                    else:
                        rec.update(status='synced', drive_id=str(other.get('id') or ''),
                                   verification=old.get('verification', 'size'),
                                   verified_utc=old.get('verified_utc', stamp()))
                        counts['synced_existing'] += 1
                else:
                    rec.update(status='conflict', error='Different Drive file size; no overwrite')
                    counts['conflicts'] += 1
            else:
                rec['status'] = 'pending'
                counts['pending'] += 1
            index['files'][key] = rec
    for key, entry in index['files'].items():
        if key not in touched and entry.get('status') != 'absent_local':
            entry['status'] = 'absent_local'
            entry['updated_utc'] = stamp()
    index['last_full_scan_utc'] = stamp()
    if info.get('issues'):
        print('FULL SCAN WARNINGS:', len(info['issues']))
        for warn in info['issues'][:4]: print('  -', warn)
    if info.get('invalid'):
        print('INVALID JSON SKIPPED:', len(info['invalid']))
    if info.get('unrecognized_audio'):
        print('UNRECOGNIZED AUDIO SKIPPED:', len(info['unrecognized_audio']))
    return counts


def process_one(root: Path, report: Path, index: dict, record: dict,
                drive: GoogleReader, ids: dict, args: argparse.Namespace) -> str:
    path = candidate_path(root, record)
    if not path.is_file():
        record.update(status='absent_local', error='Local file removed', updated_utc=stamp())
        return 'ABSENT'
    try:
        size, mtime = check_stable(path, args.min_age)
    except Exception as exc:
        record.update(status='not_ready', error=short_error(exc), updated_utc=stamp())
        return 'NOT_READY'
    if record.get('size') != size or record.get('mtime_ns') != mtime:
        # File was replaced after AI enqueued it; verify latest content.
        record.update(size=size, mtime_ns=mtime, status='pending')
    if record['kind'] == 'lyrics' and not valid_json(path):
        record.update(status='not_ready', error='Invalid or incomplete JSON', updated_utc=stamp())
        return 'NOT_READY'
    kind = record['kind']
    # Required even with a fresh local manifest: Drive may have received an
    # upload before a crash. Only this exact filename in the exact destination.
    exact = [x for x in drive.list_files(ids[kind], path.name)
             if x.get('name') == path.name and x.get('mimeType') != FOLDER_MIME]
    if len(exact) > 1:
        record.update(status='conflict', error='Duplicate Drive filename', updated_utc=stamp())
        return 'CONFLICT'
    if len(exact) == 1:
        try:
            if remote_content_equal(drive, exact[0], path, require_md5=True):
                record.update(status='synced', drive_id=str(exact[0].get('id') or ''),
                              verification='md5', verified_utc=stamp(), updated_utc=stamp())
                state_path(report, kind, path, ids[kind]).unlink(missing_ok=True)
                record.pop('error', None)
                return 'ALREADY_PRESENT'
        except Exception as exc:
            record.update(status='conflict', error=short_error(exc), updated_utc=stamp())
            return 'CONFLICT'
        record.update(status='conflict', error='Drive size mismatch', updated_utc=stamp())
        return 'CONFLICT'
    created_obj = None
    post_exception = None
    try:
        created_obj, sp = upload_one(drive, ids[kind], path, kind, report,
                                     args.chunk_kib * 1024, args.put_timeout)
    except Exception as exc:
        post_exception = exc
    confirmed = None
    for attempt in range(4):
        if attempt: time.sleep(1.0 + attempt * 1.2)
        exact = [x for x in drive.list_files(ids[kind], path.name)
                 if x.get('name') == path.name and x.get('mimeType') != FOLDER_MIME]
        if len(exact) == 1:
            confirmed = exact[0]
            break
        if len(exact) > 1:
            record.update(status='conflict', error='Duplicate filename after upload', updated_utc=stamp())
            return 'CONFLICT'
    if confirmed is None:
        record.update(status='failed', error='Upload unconfirmed: ' +
                      short_error(post_exception or RuntimeError('Not visible')),
                      updated_utc=stamp())
        return 'FAILED'
    newstat = path.stat()
    if newstat.st_size != size or newstat.st_mtime_ns != mtime:
        record.update(status='conflict', error='Source changed during upload', updated_utc=stamp())
        return 'CONFLICT'
    try:
        remote_content_equal(drive, confirmed, path, require_md5=True)
    except Exception as exc:
        record.update(status='conflict', error='MD5 verification failed: ' + short_error(exc), updated_utc=stamp())
        return 'CONFLICT'
    record.update(status='synced', drive_id=str(confirmed.get('id') or ''),
                  verification='md5', verified_utc=stamp(), updated_utc=stamp())
    record.pop('error', None)
    state_path(report, kind, path, ids[kind]).unlink(missing_ok=True)
    return 'UPLOADED'


def sync_locked(args: argparse.Namespace, root: Path, report: Path) -> int:
    index_path = root / INDEX_NAME
    index = load_index(index_path)
    events = fold_queue(root, index)
    due = args.full or full_scan_due(index, args.full_hours)
    print('===== TUNERTOOLS AI DRIVE INCREMENTAL SYNC =====')
    print('MODE:', 'APPLY / CREATE ONLY' if args.apply else 'PREVIEW ONLY')
    print('SOURCE:', root)
    print('DRIVE: AI_Music/{stream_cache,lyrics} ONLY')
    print('QUEUE EVENTS NEW:', events, 'INDEX ITEMS:', len(index['files']))
    print('RECONCILE:', 'YES (cold-start/daily/forced)' if due else 'NO (pending only)')
    print('UTC:', stamp())
    if args.apply:
        # Persist new pending entries and byte offset BEFORE touching Drive.
        # A crash will leave a resumable queue/index, not lose events.
        write_index(index_path, index)
    pending = [v for v in index['files'].values()
               if v.get('status') in ('pending', 'failed', 'not_ready')]
    if not due and not pending:
        print('FAST EXIT: no pending files. No Google Drive API calls needed.')
        return 0
    if not args.apply and not due:
        print('PREVIEW: %d pending, %d max per run' % (len(pending), args.max_files))
        for record in pending[:12]:
            print('  WOULD CHECK:', record['kind'].upper(), record['filename'])
        print('PREVIEW: no files uploaded and index unchanged')
        return 0

    token = Path(args.token) if args.token else next((Path(x) for x in TOKEN_DEFAULTS if Path(x).is_file()), None)
    if token is None or not token.is_file():
        raise RuntimeError('OAuth token not found; use existing drive_token.json')
    drive = GoogleReader(token)
    ids = collect_drive_folders(drive)
    if due:
        stats = reconcile_full(root, index, drive, ids)
        print('FULL RECONCILE:', stats)
        if args.apply:
            write_index(index_path, index)
    pending = [v for v in index['files'].values()
               if v.get('status') in ('pending', 'failed', 'not_ready')]
    pending.sort(key=lambda v: (v.get('queued_utc', 0), v['kind'], v['filename'].casefold()))
    print('PENDING:', len(pending), 'MAX THIS RUN:', args.max_files)
    if not args.apply:
        for record in pending[:12]: print('  WOULD CHECK:', record['kind'].upper(), record['filename'])
        return 0
    result = {'utc': stamp(), 'mode': 'incremental', 'full_reconcile': due, 'new_queue_events': events,
              'pending_before': len(pending), 'uploaded': [], 'present': [],
              'failed': [], 'conflict': [], 'not_ready': [], 'absent': [], 'remaining': 0}
    for number, record in enumerate(pending[:args.max_files], 1):
        filename, kind = record['filename'], record['kind']
        print('[%d/%d] %s %s' % (number, min(len(pending), args.max_files), kind.upper(), filename))
        try:
            outcome = process_one(root, report, index, record, drive, ids, args)
        except Exception as exc:
            record.update(status='failed', error=short_error(exc), updated_utc=stamp())
            outcome = 'FAILED'
        key = {'UPLOADED': 'uploaded', 'ALREADY_PRESENT': 'present', 'FAILED': 'failed',
               'CONFLICT': 'conflict', 'NOT_READY': 'not_ready', 'ABSENT': 'absent'}[outcome]
        result[key].append({'file': filename, 'kind': kind, 'error': record.get('error', '')})
        print('  ' + outcome + (': ' + record['error'] if record.get('error') else ''))
        write_index(index_path, index)
        if args.pause and outcome == 'UPLOADED': time.sleep(args.pause)
    result['remaining'] = sum(v.get('status') in ('pending','failed','not_ready') for v in index['files'].values())
    path = report / 'AI_DRIVE_SYNC_LAST_RUN.json'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('===== COMPLETE =====')
    print('UPLOADED:',len(result['uploaded']), 'PRESENT:',len(result['present']),
          'FAILED:',len(result['failed']), 'CONFLICT:',len(result['conflict']),
          'WAITING:',len(result['not_ready']), 'QUEUED:',result['remaining'])
    print('REPORT:', path)
    print('No Drive files were overwritten, renamed or deleted.')
    return 1 if result['failed'] or result['conflict'] else 0


def main() -> int:
    parser = argparse.ArgumentParser(description='TunerTools incremental AI Drive uploader')
    parser.add_argument('--source', default=SOURCE_DEFAULT)
    parser.add_argument('--token', default='')
    parser.add_argument('--report', default='')
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--full', action='store_true', help='Force complete Server/Drive reconciliation')
    parser.add_argument('--full-hours', type=int, default=24)
    parser.add_argument('--min-age', type=int, default=120)
    parser.add_argument('--max-files', type=int, default=200)
    parser.add_argument('--pause', type=float, default=1.5)
    parser.add_argument('--chunk-kib', type=int, default=1024)
    parser.add_argument('--put-timeout', type=int, default=300)
    args = parser.parse_args()
    if not (1 <= args.full_hours <= 720): parser.error('--full-hours must be 1..720')
    if not (0 <= args.min_age <= 86400): parser.error('--min-age must be 0..86400')
    if not (1 <= args.max_files <= 1000): parser.error('--max-files must be 1..1000')
    if args.chunk_kib not in (256,512,1024,2048,4096): parser.error('--chunk-kib must be 256..4096')
    if not (30 <= args.put_timeout <= 1800): parser.error('--put-timeout must be 30..1800')
    if not (0 <= args.pause <= 30): parser.error('--pause must be 0..30')
    try: sys.stdout.reconfigure(errors='replace')
    except AttributeError: pass
    root = Path(args.source)
    if not root.is_dir(): parser.error('AI_Music source not found: ' + str(root))
    report = Path(args.report) if args.report else root / 'Reports' / 'Drive_AutoSync'
    report.mkdir(parents=True, exist_ok=True)
    try:
        lock = acquire_lock(report)
        try:
            return sync_locked(args, root, report)
        finally:
            lock.close()
    except Exception as exc:
        print('ERROR:', short_error(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
