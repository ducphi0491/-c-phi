#!/usr/bin/env python3
"""Read-only local status (NO Drive API / NO changes to queue)."""
from pathlib import Path
import json
import os
from collections import Counter
from SYNC_AI_DRIVE_INCREMENTAL import load_index, INDEX_NAME, QUEUE_NAME

def main():
    root = Path(os.environ.get('TUNERTOOLS_AI_MUSIC_ROOT', r'C:\TunerTools\Audio\AI_Music'))
    index = load_index(root / INDEX_NAME)
    statuses = Counter(x.get('status', 'unknown') for x in index['files'].values())
    queue = root / QUEUE_NAME
    print('SOURCE:', root)
    print('QUEUE:', queue.name, 'bytes=', queue.stat().st_size if queue.exists() else 0)
    print('QUEUE OFFSET:', index['queue_offset'])
    print('FULL RECONCILE UTC:', index['last_full_scan_utc'] or '(not done)')
    print('INDEX FILES:', len(index['files']))
    for status, count in sorted(statuses.items()):
        print('  %-16s %d' % (status, count))
    active = [x for x in index['files'].values() if x.get('status') in ('pending','failed','not_ready','conflict')]
    for record in active[:15]: print(' ', record['kind'], record['filename'], record['status'])

if __name__ == '__main__': main()
