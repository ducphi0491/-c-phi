$ErrorActionPreference = 'Stop'
$script = Join-Path $PSScriptRoot 'KIEM_TRA_HANG_DOI.py'
$cfg = Join-Path $PSScriptRoot 'python_path.txt'
if (Test-Path $cfg) {
    $python = (Get-Content $cfg -Raw -Encoding UTF8).Trim()
    & $python $script
} elseif (Get-Command py.exe -ErrorAction SilentlyContinue) {
    & py.exe -3 $script
} else { & python.exe $script }
if ($LASTEXITCODE -ne 0) { throw "Check queue failed: $LASTEXITCODE" }
