param(
    [string]$TargetApp = 'C:\TunerTools\Audio\AI_Music\app.py',
    [switch]$AllowDifferentSource
)
$ErrorActionPreference = 'Stop'
$patched = Join-Path $PSScriptRoot 'APP_AI_PATCHED\app.py'
$expectedOriginalHash = '65dec21b56461949ab19849af260ffdbda5117ca31170f90cda0351794ce8551'
if (-not (Test-Path -LiteralPath $patched -PathType Leaf)) { throw "Missing patch: $patched" }
if (-not (Test-Path -LiteralPath $TargetApp -PathType Leaf)) {
    Write-Host 'Khong thay app.py tai duong dan du kien. Cac file Python trong AI_Music:' -ForegroundColor Yellow
    Get-ChildItem 'C:\TunerTools\Audio\AI_Music' -Filter '*.py' -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
    throw 'Chi dinh lai -TargetApp theo file Python dang chay; chua thay doi gi.'
}
$installedHash = (Get-FileHash -LiteralPath $TargetApp -Algorithm SHA256).Hash.ToLowerInvariant()
$patchedHash = (Get-FileHash -LiteralPath $patched -Algorithm SHA256).Hash.ToLowerInvariant()
if ($installedHash -eq $patchedHash) {
    Write-Host 'app.py da la ban co hang doi. Khong can ghi de.' -ForegroundColor Green
    exit 0
}
if ($installedHash -ne $expectedOriginalHash -and -not $AllowDifferentSource) {
    Write-Host 'File Python dang chay KHAC ban app (2).py ban da gui.' -ForegroundColor Red
    Write-Host ('Hien tai: ' + $TargetApp)
    Write-Host ('SHA256: ' + $installedHash)
    Write-Host 'Vi an toan, chua ghi de. Kiem tra dung file, hoac dung -AllowDifferentSource neu chap nhan thay bang app.py da gui.'
    exit 2
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = "$TargetApp.bak_$stamp"
Copy-Item -LiteralPath $TargetApp -Destination $backup -ErrorAction Stop
Copy-Item -LiteralPath $patched -Destination $TargetApp -Force -ErrorAction Stop
$written = (Get-FileHash -LiteralPath $TargetApp -Algorithm SHA256).Hash.ToLowerInvariant()
if ($written -ne $patchedHash) { throw 'New app.py checksum mismatch; please restore backup: ' + $backup }
Write-Host ('BACKUP: ' + $backup) -ForegroundColor Green
Write-Host ('PATCHED: ' + $TargetApp) -ForegroundColor Green
Write-Host 'QUAN TRONG: KHOI DONG LAI Python AI server. Khi chua restart, tien trinh cu chua ghi queue.' -ForegroundColor Yellow
Write-Host 'KHONG xoa backup, token Google Drive hoac AI_Music data.' -ForegroundColor Yellow
