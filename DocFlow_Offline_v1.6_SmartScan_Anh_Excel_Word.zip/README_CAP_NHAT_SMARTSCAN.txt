DOCFLOW OFFLINE - SMART SCAN v1.6 (Anh -> Excel / Word)
====================================================

1) NHUNG GI DA BO SUNG
- Trong tab Tai lieu: nut Scan nam canh o tim kiem va icon Thu muc.
- Trong tab Chuyen doi: Anh -> Excel; Anh -> Word.
- Trong tab Cong cu: Smart Scan.
- Chup anh bang ung dung Camera cua dien thoai (TakePicture / FileProvider).
- Chon nhieu anh JPG/PNG tu dien thoai (toi da 6 anh mot lan).
- OCR tieng Viet + tieng Anh hoat dong offline tu lan quet dau tien.
- Tu khoi phuc bang: uu tien duong ke, neu khong co thi tach theo toa do chu.
- Xem anh, sua tung o truoc khi xuat XLSX; sua van ban truoc khi xuat DOCX.
- XLSX co sheet "Trang 1" (du lieu sua duoc) va sheet "Goc 1" (anh tham chieu).
- DOCX la van ban OCR sua duoc; khi khong nhan dang duoc chu thi xuat anh.
- Xoay 90 do, tang tuong phan va nhan dang lai.
- Khong tai anh len may chu; khong yeu cau INTERNET hoac CAMERA permission.

2) CAC FILE CAN CHEN / THAY
app/src/main/java/com/docflowoffline/MainActivity.kt
app/src/main/java/com/docflowoffline/DocumentScreens.kt
app/src/main/java/com/docflowoffline/DocumentEngines.kt
app/src/main/res/xml/docflow_file_paths.xml
app/src/main/assets/tessdata/vie.traineddata
app/src/main/assets/tessdata/eng.traineddata

3) THU VIEN / GRADLE
app/build.gradle.kts can them vao dependencies:
  implementation("cz.adaptech.tesseract4android:tesseract4android:4.9.0")
  implementation("androidx.exifinterface:exifinterface:1.3.7")

settings.gradle.kts can them Maven JitPack (trong repositories cua dependencyResolutionManagement):
  maven { url = uri("https://jitpack.io") }

Hai file Gradle da cung cap kem trong ZIP de doi chieu. Neu du an cua ban da
tuy chinh applicationId, versionCode, Gradle/AGP hoac cac thu vien khac,
CHI MERGE DONG MOI thay vi thay the nguyen file Gradle.

4) ANDROIDMANIFEST.XML
Ban dang dung phien ban co FileProvider tu v1.1 de chia se file Excel.
Khong can doi AndroidManifest.xml neu provider van ton tai:
  <provider
      android:name="androidx.core.content.FileProvider"
      android:authorities="${applicationId}.files"
      android:exported="false"
      android:grantUriPermissions="true">
      <meta-data android:name="android.support.FILE_PROVIDER_PATHS"
                 android:resource="@xml/docflow_file_paths" />
  </provider>

KHONG THAY ANDROIDMANIFEST DA DUNG logo moi cua ban de tranh mat launcher icon.
Thu muc res/xml/docflow_file_paths.xml chi duoc them duong dan cache "smartscan/".

5) SU DUNG
- Mo DocFlow -> nut icon Scan ben canh o tim kiem (hoac vao Chuyen doi).
- Chup anh / chon anh -> cho OCR hoan tat -> xem ket qua.
- Tab Bang Excel: sua cac gia tri bi OCR nham.
- Tab Van ban Word: sua chu viet.
- Bam Xuat Excel / Xuat Word -> Android hoi ten va noi luu file.
- Nen kiem tra cac so lieu tien, so luong, ngay thang truoc khi su dung.

6) GIOI HAN CUA BAN DAU
- Chua tu dong cat goc giay hoac chinh phoi canh/khung hinh theo 4 dinh.
- Bang co o gop, chu viet tay, anh mo/nghieng hoac nhieu cot phuc tap
  co the nhan dang sai va can sua thu cong truoc khi xuat.
- Khong the cam ket giu 100% dinh dang anh thanh file Excel/Word.
- Quet nhieu trang gioi han 6 trang; OCR chay tuan tu tren may.
- Khong tu tinh lai cong thuc Excel tu anh, vi anh khong chua cong thuc goc.
- Camera hien mo bang ung dung camera he thong, chua phai man hinh CameraX tuy bien.
- Chua bao gom luong PDF scan -> OCR truc tiep; hien co the chon anh/chup anh.

7) KIEM THU / XAC NHAN
- Thu OCR tieng Viet/Anh bang Tesseract CLI voi model bundle: dat.
- Thu bang ke toan co duong ke: dat ket qua 4 cot x 5 hang tren du lieu mau.
- Thu xuat XLSX voi anh goc, doc bang openpyxl: dat.
- Thu xuat DOCX va doc bang python-docx: dat.
- Chua build APK / Gradle Sync duoc o moi truong nay (khong co Android SDK).
  Neu Android Studio bao loi, gui Build Output, khong tu y thay cac file Excel khac.

8) GIAY PHEP
Tesseract4Android va bo OCR engine/model tessdata_fast dung Apache License 2.0.
Kem cac thong bao ban quyen tai docs/OCR_LICENSES.txt va docs/Apache-2.0.txt.
Noi dung OCR duoc xu ly tren may, khong su dung dich vu cloud tra phi.

Trang thong tin Tesseract4Android: https://github.com/adaptech-cz/Tesseract4Android
Trang du lieu model: https://github.com/tesseract-ocr/tessdata_fast
