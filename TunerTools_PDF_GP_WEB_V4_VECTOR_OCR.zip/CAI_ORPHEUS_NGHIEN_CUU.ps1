param(
    [Parameter(Mandatory=$true)][string]$ModelZip
)
# Optional local diagnosis only. Does NOT grant rights to use or redistribute models.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dst = Join-Path $Root 'local_models\orpheus'
$Python = Join-Path $Root '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $Python)) {
    Write-Host 'Hay chay CHAY_WEB.bat truoc de tao moi truong Python.' -ForegroundColor Yellow
    exit 1
}
if (-not (Test-Path -LiteralPath $ModelZip)) { throw ('Khong tim thay ZIP: ' + $ModelZip) }
New-Item -ItemType Directory -Path $Dst -Force | Out-Null
& $Python -m pip install --disable-pip-version-check 'onnxruntime>=1.20,<2'
if ($LASTEXITCODE -ne 0) { throw 'Cai onnxruntime that bai.' }
$src = (Resolve-Path -LiteralPath $ModelZip).Path
$env:TT_OMR_MODELZIP = $src
$env:TT_OMR_DEST = $Dst
& $Python -c @'
import os,zipfile,pathlib
src=os.environ['TT_OMR_MODELZIP']; dst=pathlib.Path(os.environ['TT_OMR_DEST']); dst.mkdir(parents=True,exist_ok=True)
needed=['layout.onnx','encoder.onnx','decoder.onnx','orpheus.json']
with zipfile.ZipFile(src) as z:
    members={pathlib.PurePosixPath(x.filename).name:x for x in z.infolist() if not x.is_dir()}
    for name in needed:
        if name not in members: raise RuntimeError('Thieu ' + name)
        info=members[name]
        if info.file_size>32*1024*1024: raise RuntimeError('Model qua lon: '+name)
        (dst/name).write_bytes(z.read(info))
        print('[OK]',name, info.file_size,'bytes')
print('Chi cai tren may nay de nghien cuu. Khong phan phoi lai.')
'@
if ($LASTEXITCODE -ne 0) {throw 'Khong giai nen duoc mo hinh.'}
Write-Host 'Da cai Orpheus vao local_models\orpheus; khoi dong lai web de xem trang phan vung.' -ForegroundColor Green
