"""Optional *research-only* Orpheus layout preview for locally supplied weights.

This module does NOT decode notes, beat durations, or MusicXML. No model weights
or proprietary EZMusic source code are bundled in this project.
"""
from __future__ import annotations

import io
import json
import time
from collections import Counter
from functools import lru_cache
from pathlib import Path

import fitz
from PIL import Image, ImageOps

ROOT=Path(__file__).resolve().parent
MODEL_DIR=ROOT/'local_models'/'orpheus'


def available():
    try:
        import numpy,onnxruntime  # noqa: F401
    except ImportError:
        return False
    return all((MODEL_DIR/x).is_file() for x in ('layout.onnx','orpheus.json'))


def _get_gray(data,filename,page):
    if filename.lower().endswith('.pdf'):
        with fitz.open(stream=data,filetype='pdf') as doc:
            if not 0<=page<len(doc):raise IndexError('Trang khong ton tai')
            pix=doc[page].get_pixmap(matrix=fitz.Matrix(2,2),colorspace=fitz.csGRAY,alpha=False)
            return Image.frombytes('L',(pix.width,pix.height),pix.samples)
    with Image.open(io.BytesIO(data)) as image:
        image.load()
        return ImageOps.exif_transpose(image).convert('L')


@lru_cache(maxsize=1)
def _session():
    import onnxruntime as ort
    return ort.InferenceSession(str(MODEL_DIR/'layout.onnx'),providers=['CPUExecutionProvider'])


def analyze_layout(data:bytes, filename:str, page:int) -> dict:
    import numpy as np
    if not available():
        raise RuntimeError('Chua cai Orpheus trong local_models/orpheus va onnxruntime; day chi la che do nghien cuu.')
    config=json.loads((MODEL_DIR/'orpheus.json').read_text(encoding='utf-8-sig'))
    long_side=min(2048,max(256,int(config.get('layout_long_side',1536))))
    multiple=min(128,max(16,int(config.get('layout_multiple',32))))
    original=_get_gray(data,filename,page)
    scale=long_side/max(original.size)
    shape=(max(1,round(original.width*scale)),max(1,round(original.height*scale)))
    resized=original.resize(shape,Image.Resampling.BILINEAR)
    h=int((shape[1]+multiple-1)//multiple*multiple)
    w=int((shape[0]+multiple-1)//multiple*multiple)
    # On-device inference uses dark-ink=1, white=0 convention.
    inp=np.zeros((1,1,h,w),dtype=np.float32)
    inp[0,0,:shape[1],:shape[0]]=1-np.asarray(resized,dtype=np.float32)/255.0
    start=time.perf_counter()
    out=_session().run(['classes'],{'page':inp})[0][0,:shape[1],:shape[0]]
    elapsed=round((time.perf_counter()-start)*1000)
    counts={str(int(v)):int(c) for v,c in zip(*np.unique(out,return_counts=True))}
    palette=np.zeros((shape[1],shape[0],4),dtype=np.uint8)
    colors=[(0,0,0,0),(22,128,220,140),(0,164,114,140),(232,84,72,140),
            (187,112,217,140),(241,185,65,160)]
    for label in np.unique(out):
        label=int(label)
        if label==0:continue
        palette[out==label]=colors[label%len(colors)] if label%len(colors) else (94,132,224,145)
    overlay=Image.fromarray(palette,'RGBA')
    base=resized.convert('RGBA')
    base.alpha_composite(overlay)
    mem=io.BytesIO();base.convert('RGB').save(mem,format='PNG')
    return {'image':mem.getvalue(),'classes':counts,'width':shape[0], 'height':shape[1],
            'inference_ms':elapsed,'background_pct':round(float((out==0).mean())*100,1),
            'warning':'Chi phan vung pixel. KHONG phai nhan dang not, nhip hay MusicXML.'}
