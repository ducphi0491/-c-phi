"""A decoded GP note must drive BOTH five-line notation and guitar tab."""
from types import SimpleNamespace as S
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app


def test_extract_score_keeps_durations_and_pitch():
    note = S(string=2, value=3, velocity=90)
    note2 = S(string=3, value=0, velocity=95)
    duration = S(value=8, isDotted=True, isDoubleDotted=False, tuplet=S(enters=1, times=1))
    beat = S(duration=duration, notes=[note,note2])
    rest = S(duration=S(value=4, isDotted=False, isDoubleDotted=False,tuplet=S(enters=1,times=1)),notes=[])
    measure = S(header=S(timeSignature=S(numerator=6,denominator=S(value=8)),keySignature=0),voices=[S(beats=[beat,rest])])
    track = S(name='Guitar 6/8',strings=[S(number=i,value=v) for i,v in enumerate([64,59,55,50,45,40],start=1)],measures=[measure])
    song = S(tempo=120,title='Bai kiem thu',artist='TunerTools',tracks=[track])
    orig = app.load_song
    try:
        app.load_song = lambda _:song
        data=app.extract_score(b'fake')
    finally:
        app.load_song = orig
    assert data['tracks'][0]['clef']=='treble'
    assert data['tracks'][0]['notation_transposition']==12
    assert data['tracks'][0]['measures'][0]['time']=='6/8'
    assert data['tracks'][0]['measures'][0]['length']==3.0
    notes=data['tracks'][0]['measures'][0]['beats'][0]
    assert notes['duration']==8 and notes['dotted'] is True and notes['length']==0.75
    assert notes['notes'][0]['pitch']==62  # string 2 open B3=59 + fret3
    assert notes['notes'][1]['pitch']==55  # string 3 open G3
    assert data['tracks'][0]['measures'][0]['beats'][1]['rest'] is True


def test_staff_assets_referenced():
    html=(Path(__file__).resolve().parents[1]/'static/index.html').read_text()
    assert 'alphaTabNotation' in html
    assert 'notation.js' in html
    assert 'notationZoom' in html
    assert 'data-mode="both"' in html
    assert 'data-mode="tabs"' in html
    assert 'data-mode="score"' in html
