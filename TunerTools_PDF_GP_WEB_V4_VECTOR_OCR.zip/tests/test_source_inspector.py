from pathlib import Path
import io
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import fitz
import pytest
from fastapi.testclient import TestClient
import app
from source_inspector import inspect_document, parse_page_selection, subset_pdf


def sample_pdf():
    d=fitz.open()
    for _ in range(2):
        page=d.new_page(width=595,height=841)
        for i in range(5):
            page.draw_rect(fitz.Rect(60,70+i*5.4,530,70+i*5.4+.65),color=None,fill=(0,0,0))
        for i in range(6):
            y=140+i*7.8
            page.draw_rect(fitz.Rect(60,y,530,y+.65),color=None,fill=(0,0,0))
            page.insert_text((85+i*25,y+5),str(i%4),fontsize=10)
    b=d.tobytes();d.close();return b


def test_vector_inspection_and_page_selection():
    data=sample_pdf()
    r=inspect_document(data,'score.pdf')
    assert r['pages']==2
    assert r['format']=='pdf'
    assert r['staff_groups']>=2
    assert r['tab_groups']>=2
    assert r['fret_candidates']>=4
    assert r['_renders'][0]['overlay'] != r['_renders'][0]['original']
    assert parse_page_selection('2,1-2',2)==[0,1]
    assert parse_page_selection('2',2)==[1]
    with pytest.raises(ValueError):parse_page_selection('3',2)
    with fitz.open(stream=subset_pdf(data,[1]),filetype='pdf') as doc:assert len(doc)==1


def test_inspection_api_and_preview():
    c=TestClient(app.app)
    data=sample_pdf()
    r=c.post('/api/inspect',files={'file':('song.pdf',data,'application/pdf')})
    assert r.status_code==200,r.text
    body=r.json();assert body['pages']==2 and body['fret_candidates']>=4
    sid=body['id']
    pic=c.get(f'/api/source-preview/{sid}/1?overlay=1')
    assert pic.status_code==200 and pic.content.startswith(b'\x89PNG')
    assert c.get(f'/api/source-preview/{sid}/3').status_code==404
    assert c.post(f'/api/orpheus-layout/{sid}/1').status_code==503
    assert c.post('/api/convert',data={'pages':'9'},files={'file':('song.pdf',data,'application/pdf')}).status_code==422
    assert c.post('/api/inspect',files={'file':('invalid.pdf',b'not pdf','application/pdf')}).status_code==422


def test_health_v3():
    v=TestClient(app.app).get('/api/health').json()
    assert v['version']=='0.4.0' and v['inspect'] and v['local_only']
