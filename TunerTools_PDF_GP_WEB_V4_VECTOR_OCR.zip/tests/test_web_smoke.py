"""Basic local smoke tests; engine inference remains untested until installed on Windows."""
import io
import os
import sys
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient
import app as backend


def test_health_and_static():
    client = TestClient(backend.app)
    assert client.get('/').status_code == 200
    assert 'TAB &amp;' not in client.get('/').text  # static HTML, not a transformed text response
    assert client.get('/static/app.js').status_code == 200
    assert client.get('/api/health').json()['local_only'] is True


def test_validation():
    client = TestClient(backend.app)
    assert client.post('/api/convert', files={'file':('a.exe',b'test')}).status_code == 415
    assert client.post('/api/convert', files={'file':('a.pdf',b'')}).status_code == 413


def test_download_routes():
    backend.STORE['test']={'created': __import__('time').time(),'name':'vi_du',
                           'score': {}, 'report': {},'export_warnings':{},
                           'files': {'gp5':b'GP5-demo'}}
    client = TestClient(backend.app)
    r=client.get('/api/download/test/gp5')
    assert r.status_code == 200 and r.content == b'GP5-demo'
    assert client.get('/api/download/test/gp4').status_code == 404
    z=client.get('/api/download-all/test')
    assert z.status_code == 200
    with zipfile.ZipFile(io.BytesIO(z.content)) as archive:
        assert archive.read('vi_du.gp5') == b'GP5-demo'
    backend.STORE.pop('test')


if __name__=='__main__':
    test_health_and_static();test_validation();test_download_routes();print('smoke tests passed')


def test_preview_score_model():
    from types import SimpleNamespace as S
    note = S(string=1, value=3, velocity=92)
    beat = S(duration=S(value=8, isDotted=False, isDoubleDotted=False, tuplet=S(enters=1,times=1)), notes=[note])
    beat2 = S(duration=S(value=4, isDotted=False, isDoubleDotted=False, tuplet=S(enters=1,times=1)), notes=[])
    measure = S(header=S(timeSignature=S(numerator=4,denominator=S(value=4))), voices=[S(beats=[beat,beat2])])
    song = S(tempo=110,title='Test TAB',artist='Test',tracks=[S(name='Steel Guitar',strings=[S(number=i,value=v) for i,v in enumerate([64,59,55,50,45,40],start=1)],measures=[measure])])
    load_before=backend.load_song
    try:
        backend.load_song=lambda data: song
        score=backend.extract_score(b'fake')
        assert score['total_notes'] == 1
        assert score['tracks'][0]['measures'][0]['beats'][0]['notes'][0]['pitch'] == 67
        assert score['tracks'][0]['measures'][0]['beats'][0]['length'] == 0.5
    finally:
        backend.load_song=load_before
