"""Independent visual audit for uploaded PDF and score images.

Detects *candidate* staff/TAB lines and fret numerals in vector PDFs.
This is not optical music recognition and NEVER claims accurate GP transcription.
"""
from __future__ import annotations

import io
import re
from collections import Counter
from hashlib import sha256
from typing import Any

import fitz
from PIL import Image, ImageDraw, ImageOps, UnidentifiedImageError

MAX_PAGES = 40
PREVIEW_LIMIT = 12
MAX_PIXELS = 38_000_000
Image.MAX_IMAGE_PIXELS = MAX_PIXELS


def parse_page_selection(text: str | None, total: int) -> list[int]:
    if not text or not text.strip():
        return list(range(total))
    found: list[int] = []
    for piece in text.split(','):
        piece = piece.strip()
        if not piece:
            raise ValueError('Danh sach trang khong hop le. Vi du: 1-3,5')
        match = re.fullmatch(r'(\d+)\s*-\s*(\d+)', piece)
        if match:
            a, b = map(int, match.groups())
            if b < a:
                raise ValueError('Khoang trang phai tu nho den lon.')
            if b-a > MAX_PAGES:
                raise ValueError('Khong duoc chon qua 40 trang.')
            pages = range(a, b+1)
        elif piece.isdecimal():
            pages = [int(piece)]
        else:
            raise ValueError('Trang phai la so nguyen, vi du 1-3,5.')
        for n in pages:
            if n < 1 or n > total:
                raise ValueError(f'Trang {n} ngoai gioi han 1-{total}.')
            if n-1 not in found:
                found.append(n-1)
    if not found or len(found)>MAX_PAGES:
        raise ValueError('Khong co trang hop le.')
    return sorted(found)


def subset_pdf(data: bytes, pages: list[int]) -> bytes:
    with fitz.open(stream=data, filetype='pdf') as doc:
        if not pages or pages == list(range(len(doc))):
            return data
        with fitz.open() as result:
            for n in pages:
                result.insert_pdf(doc, from_page=n, to_page=n)
            return result.tobytes(garbage=3, deflate=True)


def _line_candidates(page: fitz.Page) -> list[tuple[float, float, float]]:
    # Repeated horizontal *rectangles* are often exported as music staves.
    # A horizontal-line PDF can also use the line path operator.
    lines = []
    minwidth = max(35.0, page.rect.width * .07)
    for drawing in page.get_drawings():
        for item in drawing['items']:
            if item[0] == 're':
                rect = item[1]
                if rect.width >= minwidth and 0 < rect.height < 1.6:
                    lines.append((float(rect.y0 + rect.height/2), float(rect.x0), float(rect.x1)))
            elif item[0] == 'l':
                a,b = item[1:3]
                if abs(a.y-b.y) <= .65 and abs(a.x-b.x) >= minwidth:
                    lines.append(((a.y+b.y)/2, min(a.x,b.x), max(a.x,b.x)))
    return lines


def _systems(lines: list[tuple[float,float,float]], width: float) -> list[dict[str, Any]]:
    # Group by y and horizontal coverage; reject short stems/barlines.
    buckets: list[dict[str, Any]] = []
    for y,x0,x1 in sorted(lines):
        if buckets and abs(y - buckets[-1]['y']) < .85:
            b = buckets[-1]
            b['segments'].append((x0,x1))
            b['y'] = (b['y'] * b['n'] + y) / (b['n']+1)
            b['n'] += 1
        else:
            buckets.append({'y':y,'segments':[(x0,x1)],'n':1})
    eligible=[]
    for b in buckets:
        segs=sorted(b['segments'])
        merged=[]
        for lo,hi in segs:
            if merged and lo <= merged[-1][1]+1:
                merged[-1]=(merged[-1][0],max(hi,merged[-1][1]))
            else:
                merged.append((lo,hi))
        coverage=sum(hi-lo for lo,hi in merged)
        if coverage > max(55.0, width*.14):
            eligible.append({'y':b['y'],'coverage':round(coverage,1)})
    values=[b['y'] for b in eligible]
    result=[]
    used=set()
    for i,y in enumerate(values):
        if i in used: continue
        best=None
        for count in (6,5):
            for j in range(i+1,len(values)):
                step=(values[j]-y)
                if not 3.0 <= step <= 12.5:continue
                indices=[i]
                for k in range(1,count):
                    target=y+step*k
                    closest=min((m for m in range(j,len(values)) if m not in indices),
                                key=lambda m:abs(values[m]-target),default=None)
                    if closest is None or abs(values[closest]-target)>max(.7,step*.13):
                        break
                    indices.append(closest)
                if len(indices)==count and not (set(indices)&used):
                    candidate=(count,step,indices)
                    if best is None or count>best[0]:best=candidate
                if best and best[0]==6: break
            if best:break
        if best:
            count,step,indices=best
            used.update(indices)
            result.append({'kind':'tab' if count==6 or step>=6.5 else 'staff',
                           'lines':[round(values[n],2) for n in indices],
                           'partial':bool(count==5 and step>=6.5),
                           'spacing':round(step,2)})
    return sorted(result,key=lambda x:x['lines'][0])


def _frets(page: fitz.Page, systems: list[dict[str, Any]]) -> list[dict]:
    tab_systems=[s for s in systems if s['kind']=='tab']
    found=[]
    for word in page.get_text('words'):
        x0,y0,x1,y1,txt=word[:5]
        if not re.fullmatch(r'\d{1,2}',txt):continue
        fret=int(txt)
        if fret>36:continue
        mid=(y0+y1)/2
        nearest=None
        for system in tab_systems:
            for string, y in enumerate(system['lines'],start=1):
                d=abs(mid-y)
                if nearest is None or d<nearest[0]:nearest=(d,string,system)
        if nearest and nearest[0]<4.2:
            found.append({'x':round((x0+x1)/2,1),'y':round(mid,1),
                          'string':nearest[1],'fret':fret,'line_error':round(nearest[0],1)})
    return found


def _render(page: fitz.Page, systems: list[dict], frets: list[dict], overlay: bool) -> bytes:
    scale=min(1.7,1200/max(1,page.rect.width))
    pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),colorspace=fitz.csRGB,alpha=False)
    picture=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
    if overlay:
        draw=ImageDraw.Draw(picture,'RGBA')
        for system in systems:
            ink=(26,124,226,210) if system['kind']=='staff' else (17,158,107,215)
            for y in system['lines']:
                draw.line((16*scale,y*scale,(page.rect.width-16)*scale,y*scale),fill=ink,width=2)
            draw.text((4*scale,(system['lines'][0]-11)*scale),
                      'TAB 6' if system['kind']=='tab' else 'STAFF 5',fill=ink)
        for f in frets:
            x,y=f['x']*scale,f['y']*scale
            r=5*scale
            draw.ellipse((x-r,y-r,x+r,y+r),outline=(236,90,64,240),width=2)
    target=io.BytesIO()
    picture.save(target,format='PNG',optimize=True)
    return target.getvalue()


def inspect_document(data: bytes, filename: str) -> dict:
    ext=filename.rsplit('.',1)[-1].lower()
    if ext=='pdf':
        if not data.lstrip()[:5]==b'%PDF-':
            raise ValueError('File khong co dau hieu PDF hop le.')
        with fitz.open(stream=data,filetype='pdf') as doc:
            if doc.needs_pass:
                raise ValueError('PDF co mat khau: hay mo khoa tren may cua ban truoc.')
            if len(doc)>MAX_PAGES:
                raise ValueError('Chi phan tich toi da 40 trang PDF.')
            pages=[];renders={}
            for i,page in enumerate(doc):
                candidates=_line_candidates(page)
                systems=_systems(candidates,page.rect.width)
                frets=_frets(page,systems)
                pages.append({'page':i+1,'kind':'vector' if len(candidates)>15 else 'scan_or_mixed',
                              'staff_groups':sum(s['kind']=='staff' for s in systems),
                              'tab_groups':sum(s['kind']=='tab' for s in systems),
                              'fret_candidates':len(frets),'drawing_paths':len(page.get_drawings()),
                              'detected_frets':frets[:120],
                              'systems':systems[:30]})
                if i<PREVIEW_LIMIT:
                    renders[i]={'original':_render(page,systems,frets,False),
                                'overlay':_render(page,systems,frets,True)}
            return {'format':'pdf','pages':len(doc),'items':pages,
                    'fret_candidates':sum(x['fret_candidates'] for x in pages),
                    'tab_groups':sum(x['tab_groups'] for x in pages),
                    'staff_groups':sum(x['staff_groups'] for x in pages),
                    'preview_limit':min(len(doc),PREVIEW_LIMIT),
                    '_renders':renders,'_digest':sha256(data).hexdigest()}
    try:
        with Image.open(io.BytesIO(data)) as img:
            img.load();img=ImageOps.exif_transpose(img)
            if img.width*img.height>MAX_PIXELS:
                raise ValueError('Anh qua lon: gioi han 38 trieu pixel.')
            prev=img.convert('RGB');prev.thumbnail((1300,1600))
            bio=io.BytesIO();prev.save(bio,format='PNG')
            return {'format':'image','pages':1,'items':[{'page':1,'kind':'raster_image',
                  'staff_groups':0,'tab_groups':0,'fret_candidates':0,'drawing_paths':0,
                  'systems':[],'detected_frets':[]}],
                  'fret_candidates':0,'tab_groups':0,'staff_groups':0,'preview_limit':1,
                  '_renders':{0:{'original':bio.getvalue(),'overlay':bio.getvalue()}},
                  '_digest':sha256(data).hexdigest()}
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError('Khong mo duoc anh. Kiem tra dinh dang hoac noi dung file.') from exc


def public_analysis(analysis:dict)->dict:
    return {k:v for k,v in analysis.items() if not k.startswith('_')}
