"""TunerTools PDF/IMG -> GP Web (local-only).

Recognition is delegated to F100Pilot PDF-to-GP5 (MIT); writing GP3/4/5 uses
PyGuitarPro (LGPL-3.0). No proprietary EZMusic model is bundled or called.
"""
from __future__ import annotations

import io
import hashlib
import json
import logging
import re
import tempfile
import time
import uuid
import unicodedata
import zipfile
from pathlib import Path
from threading import RLock
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from source_inspector import inspect_document, public_analysis, parse_page_selection, subset_pdf
from vector_draft import extract_vector_draft, build_song
from omr_research import available as orpheus_available, analyze_layout

ROOT = Path(__file__).resolve().parent
DATA_LIMIT = 35 * 1024 * 1024
ALLOWED_EXT = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".gp3", ".gp4", ".gp5"}
EXPORTS = ("gp3", "gp4", "gp5")
app = FastAPI(title="TunerTools PDF/IMG to Guitar Pro", version="0.4.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
STORE: dict[str, dict[str, Any]] = {}
STORE_LOCK = RLock()
SOURCE_STORE: dict[str, dict[str, Any]] = {}
LOG = logging.getLogger("tunertools_gp_web")


class EditRequest(BaseModel):
    track: int = Field(ge=0)
    measure: int = Field(ge=0)
    voice: int = Field(ge=0)
    beat: int = Field(ge=0)
    note: int = Field(ge=0)
    fret: int = Field(ge=0, le=36)
    string: int | None = Field(default=None, ge=1, le=8)


def safe_stem(value: str) -> str:
    normalized = unicodedata.normalize('NFKD',Path(value).stem)
    normalized = ''.join(c for c in normalized if not unicodedata.combining(c))
    text = re.sub(r"[^a-zA-Z0-9_-]+", "_", normalized).strip("_-")
    return text[:80] or "ban_nhac"


def get_job(job_id: str) -> dict[str, Any]:
    with STORE_LOCK:
        job = STORE.get(job_id)
    if job is None:
        raise HTTPException(404, "Không tìm thấy phiên làm việc. Hãy chọn lại file.")
    return job


def cleanup_store() -> None:
    now = time.time()
    with STORE_LOCK:
        for key in list(STORE):
            if now - STORE[key]["created"] > 3600:
                del STORE[key]
        for key in list(SOURCE_STORE):
            if now - SOURCE_STORE[key]["created"] > 3600:
                del SOURCE_STORE[key]
        while len(SOURCE_STORE) > 8:
            oldest = min(SOURCE_STORE, key=lambda k: SOURCE_STORE[k]["created"])
            del SOURCE_STORE[oldest]
        while len(STORE) > 15:
            first = min(STORE, key=lambda k: STORE[k]["created"])
            del STORE[first]


def import_guitarpro():
    try:
        import guitarpro
    except ImportError as exc:
        raise RuntimeError("Chưa cài PyGuitarPro. Chạy lại CHAY_WEB.bat để cài thư viện.") from exc
    return guitarpro


def load_song(data: bytes):
    return import_guitarpro().parse(io.BytesIO(data))


def write_song(song: Any, fmt: str) -> bytes:
    gp = import_guitarpro()
    with tempfile.TemporaryDirectory(prefix="ttgp_") as tmp:
        filename = Path(tmp) / f"output.{fmt}"
        versions={"gp3":(3,0,0),"gp4":(4,0,6),"gp5":(5,1,0)}
        gp.write(song, str(filename), version=versions[fmt])
        value = filename.read_bytes()
        if len(value) < 50:
            raise RuntimeError(f"Kết quả .{fmt} quá nhỏ, từ chối xuất")
        gp.parse(io.BytesIO(value))  # ensure it opens, not just a renamed extension
        return value


def signature(song: Any) -> tuple[tuple[int, int, int, int, int, int, int], ...]:
    items = []
    for it, track in enumerate(song.tracks):
        for im, measure in enumerate(track.measures):
            for iv, voice in enumerate(measure.voices):
                for ib, beat in enumerate(voice.beats):
                    for note in beat.notes:
                        items.append((it, im, iv, ib, int(note.string), int(note.value), int(getattr(note, 'velocity', 95))))
    return tuple(items)


def rhythm_signature(song: Any) -> tuple:
    """Check number of bars/voices, time signature, and rhythmic beat patterns."""
    track_sigs = []
    for track in song.tracks:
        bars = []
        for measure in track.measures:
            header = getattr(measure, "header", None)
            ts = getattr(header, "timeSignature", None)
            top = int(getattr(ts, "numerator", 4) or 4)
            bottom = int(getattr(getattr(ts, "denominator", None), "value", 4) or 4)
            voices = []
            for voice in measure.voices:
                durations = []
                for beat in voice.beats:
                    d = getattr(beat, "duration", None)
                    t = getattr(d, "tuplet", None)
                    durations.append((int(getattr(d, "value", 4) or 4),
                                      bool(getattr(d, "isDotted", False)),
                                      bool(getattr(d, "isDoubleDotted", False)),
                                      int(getattr(t, "enters", 1) or 1),
                                      int(getattr(t, "times", 1) or 1)))
                voices.append(tuple(durations))
            bars.append((top, bottom, tuple(voices)))
        track_sigs.append(tuple(bars))
    return tuple(track_sigs)


def build_exports(gp5: bytes) -> tuple[dict[str, bytes], dict[str, str]]:
    song = load_song(gp5)
    baseline = signature(song)
    baseline_rhythm = rhythm_signature(song)
    results = {"gp5": gp5}
    warnings: dict[str, str] = {}
    for fmt in ("gp4", "gp3"):
        try:
            data = write_song(song, fmt)
            actual = signature(load_song(data))
            if tuple((x[:6] for x in actual)) != tuple((x[:6] for x in baseline)):
                warnings[fmt] = "Dây/ngăn hoặc số nốt khác GP5. Cần xem lại trước khi dùng."
                continue  # don't offer mismatched output as correct
            if rhythm_signature(load_song(data)) != baseline_rhythm:
                warnings[fmt] = "Ô nhịp hoặc trường độ khác GP5. Không cho xuất để tránh sai nhạc."
                continue
            results[fmt] = data
        except Exception as exc:
            LOG.exception("Export %s failed", fmt)
            warnings[fmt] = str(exc)
    return results, warnings


def extract_score(gp5: bytes) -> dict[str, Any]:
    song = load_song(gp5)
    tempo = int(getattr(song, "tempo", 120) or 120)
    tracks: list[dict[str, Any]] = []
    note_total = 0
    for it, track in enumerate(song.tracks):
        strings = list(getattr(track, "strings", []))
        tuning = {int(s.number): int(s.value) for s in strings}
        if not tuning:
            tuning = {1: 64, 2: 59, 3: 55, 4: 50, 5: 45, 6: 40}
        strings_count = len(tuning)
        measures = []
        # GP model provides pitch as tuning + fret. Notate guitar one octave
        # above its sounding pitch, without changing exported GP playback.
        # Bass is also shifted one octave; notation renderer documents this.
        clef = "bass" if strings_count <= 4 and min(tuning.values()) < 40 else "treble"
        total_quarters = 0.0
        for im, measure in enumerate(track.measures):
            header = getattr(measure, "header", None)
            timesig = getattr(header, "timeSignature", None)
            numerator = int(getattr(timesig, "numerator", 4) or 4)
            denominator = getattr(getattr(timesig, "denominator", None), "value", 4)
            denominator = int(denominator or 4)
            measure_quarters = float(numerator * 4 / denominator)
            key_sig_obj = getattr(header, "keySignature", 0)
            # PyGuitarPro encodes a conventional -7..7 key signature.
            try:
                key_fifths = int(getattr(key_sig_obj, "value", key_sig_obj))
            except (ValueError, TypeError):
                key_fifths = 0
            key_fifths = max(-7, min(7, key_fifths))
            beats = []
            for iv, voice in enumerate(measure.voices):
                position = 0.0
                for ib, beat in enumerate(voice.beats):
                    dur = getattr(beat, "duration", None)
                    val = int(getattr(dur, "value", 4) or 4)
                    length = 4.0 / max(1, val)
                    if bool(getattr(dur, "isDotted", False)):
                        length *= 1.5
                    if bool(getattr(dur, "isDoubleDotted", False)):
                        length *= 1.75
                    tuplet = getattr(dur, "tuplet", None)
                    enters, times = int(getattr(tuplet, "enters", 1) or 1), int(getattr(tuplet, "times", 1) or 1)
                    length = length * times / enters
                    notes = []
                    for i, note in enumerate(beat.notes):
                        string = int(note.string)
                        fret = int(note.value)
                        pitch = tuning.get(string, 40) + fret
                        notes.append({"note": i, "string": string, "fret": fret, "pitch": pitch,
                                      "velocity": int(getattr(note, "velocity", 95))})
                    note_total += len(notes)
                    beats.append({"voice": iv, "beat": ib, "position": round(position, 5),
                                  "length": round(length, 5), "duration": val,
                                  "dotted": bool(getattr(dur, "isDotted", False)),
                                  "double_dotted": bool(getattr(dur, "isDoubleDotted", False)),
                                  "tuplet_enters": enters, "tuplet_times": times,
                                  "rest": not bool(notes), "notes": notes})
                    position += length
            measures.append({"index": im, "number": im + 1, "start": round(total_quarters, 5),
                             "length": round(measure_quarters, 5), "time": f"{numerator}/{denominator}",
                             "key_fifths": key_fifths, "beats": beats})
            total_quarters += measure_quarters
        tracks.append({"index": it, "name": str(getattr(track, "name", "Guitar") or "Guitar"),
                       "strings": strings_count, "tuning": tuning, "clef": clef,
                       "notation_transposition": 12, "measures": measures,
                       "duration_quarters": round(total_quarters, 5)})
    return {"title": str(getattr(song, "title", "") or "Bản nhạc"),
            "artist": str(getattr(song, "artist", "") or ""), "tempo": tempo,
            "tracks": tracks, "total_notes": note_total,
            "total_measures": max((len(t["measures"]) for t in tracks), default=0)}


def recognize(data: bytes, *, filename: str, bpm: int | None) -> tuple[bytes, dict]:
    try:
        from pdf_to_gp5 import i18n
        from pdf_to_gp5.converter import ConversionOptions, TrackOptions
        from pdf_to_gp5.sandbox import run_isolated
    except ImportError as exc:
        raise RuntimeError("Chưa cài bộ nhận diện PDF-to-GP5. Chạy CHAY_WEB.bat để cài đặt.") from exc
    i18n.use("en")
    options = ConversionOptions(
        title="",  # let the converter read the song title from the source PDF
        tempo=bpm,
        tracks=(TrackOptions(filename=filename, name="Guitar"),),
        max_pages=40,
        max_image_pages=15,
    )
    result = run_isolated([data], options, timeout_s=240, total_s=600, memory_mb=2048)
    if not result.gp5:
        raise RuntimeError("Bộ nhận diện không tạo ra dữ liệu GP5.")
    return result.gp5, result.report


def conversion_pipeline(data: bytes, filename: str, bpm: int | None,
                        pages: str = "", mode: str = "auto", time_sig: str = "6/8") -> dict:
    ext = Path(filename).suffix.lower()
    selected_pages = []
    if mode not in ('auto','vector','engine'):
        raise ValueError('Chế độ không hợp lệ.')
    if ext == '.pdf' and pages.strip():
        import fitz
        with fitz.open(stream=data, filetype='pdf') as pdf:
            selected_pages = parse_page_selection(pages, len(pdf))
    elif ext == '.pdf':
        import fitz
        with fitz.open(stream=data,filetype='pdf') as pdf:
            selected_pages = list(range(len(pdf)))
    if ext in {'.gp3','.gp4','.gp5'}:
        song=load_song(data)
        gp5 = data if ext=='.gp5' else write_song(song,'gp5')
        report: dict[str,Any]={"mode":"existing_gp", "warnings":[]}
    else:
        use_vector = mode=='vector'
        if mode=='auto' and ext=='.pdf':
            # Explicit preflight: use vector path only with real TAB groups,
            # never silently treat staff-only PDFs or raster scans as vector TAB.
            from source_inspector import _systems, _line_candidates
            import fitz
            with fitz.open(stream=data,filetype='pdf') as pdf:
                selected=selected_pages or list(range(len(pdf)))
                use_vector=any(any(s['kind']=='tab' for s in _systems(_line_candidates(pdf[i]),pdf[i].rect.width)) for i in selected)
        if use_vector:
            if ext !='.pdf':
                raise ValueError('Chế độ TAB vector chỉ dành cho PDF vector có 6 dòng TAB. Chọn OCR/OMR cho ảnh scan.')
            draft=extract_vector_draft(data,selected_pages,time_sig, int(bpm or 80))
            song=build_song(draft)
            gp5=write_song(song,'gp5')
            report={"mode":"vector_draft", "warnings":draft['warnings'],
                    "draft_summary":{k:v for k,v in draft.items() if k not in ('bars','warnings','preview')},
                    "preview":draft['preview']}
        else:
            payload=subset_pdf(data,selected_pages) if ext=='.pdf' and selected_pages else data
            gp5,report=recognize(payload,filename=filename,bpm=bpm)
            if not isinstance(report,dict):report={"upstream_report":str(report)}
            report['mode']='ocr_engine'
    files,export_warnings=build_exports(gp5)
    return {"gp5":gp5,"files":files,"score":extract_score(gp5),
            "report":report,"export_warnings":export_warnings,
            "selected_pages":[i+1 for i in selected_pages] if ext=='.pdf' else None}


def as_public(job_id: str, job: dict) -> dict:
    report = job.get("report") or {}
    warnings = report.get("warnings", []) if isinstance(report, dict) else []
    if not isinstance(warnings, list):
        warnings = [str(warnings)]
    return {"id": job_id, "name": job["name"], "score": job["score"],
            "formats": list(job["files"]), "warnings": [str(w) for w in warnings][:30],
            "export_warnings": job["export_warnings"],
            "verification": "Cần đối chiếu lại từng ô nhịp với PDF/ảnh gốc; OCR chưa bảo đảm chính xác.",
            "selected_pages": job.get("selected_pages"),
            "source_audit": job.get("source_audit"),
            "recognition_mode":report.get('mode','unknown'),
            "draft_summary":report.get('draft_summary'),
            "draft_preview":report.get('preview') }


@app.get("/")
async def root():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/api/health")
async def health():
    try:
        import guitarpro
        gp = True
    except ImportError:
        gp = False
    try:
        import pdf_to_gp5
        engine = True
    except ImportError:
        engine = False
    try:
        import rapidocr_onnxruntime
        ocr = True
    except ImportError:
        ocr = False
    return {"ok": True, "engine": engine, "guitarpro": gp, "ocr": ocr,
            "local_only": True, "version": "0.4.0", "vector_draft":True, "inspect": True,
            "orpheus_research": orpheus_available()}


@app.post("/api/inspect")
async def inspect(file: UploadFile = File(...)):
    filename = Path(file.filename or "unknown").name
    if Path(filename).suffix.lower() not in {".pdf", ".png", ".jpg", ".jpeg", ".webp"}:
        raise HTTPException(415, "Phan tich nguon chi danh cho PDF/anh.")
    data = await file.read(DATA_LIMIT+1)
    await file.close()
    if not data or len(data)>DATA_LIMIT:
        raise HTTPException(413, "File trong hoac qua 35 MB.")
    try:
        analysis = await run_in_threadpool(inspect_document, data, filename)
    except Exception as exc:
        raise HTTPException(422, f"Khong phan tich duoc nguon: {str(exc)[:300]}") from exc
    sid = str(uuid.uuid4())
    cleanup_store()
    with STORE_LOCK:
        SOURCE_STORE[sid] = {"created":time.time(), "file":data,
                             "filename":filename, "analysis":analysis, "orpheus":{}}
    summary = None
    if filename.lower().endswith('.pdf') and analysis['fret_candidates']>=4:
        try:
            draft=await run_in_threadpool(extract_vector_draft,data,[0],'6/8',80)
            summary={"available":True,"bars_first_page":len(draft['bars']),
                     "frets_first_page":draft['total_notes'],
                     "aligned_staff_columns":draft['staff_aligned_columns'],
                     "columns":draft['all_columns'], "preview":draft['preview'][:8]}
        except Exception as exc:
            summary={"available":False,"reason":str(exc)[:150]}
    return {"id":sid, **public_analysis(analysis), "vector_summary":summary,
            "note":"Dòng khuông/TAB và số ngăn chỉ là ứng viên trích từ PDF vector; chưa xác nhận trường độ, nhịp hay MusicXML."}


def get_source(source_id: str) -> dict:
    with STORE_LOCK:
        source = SOURCE_STORE.get(source_id)
    if not source:
        raise HTTPException(404, "Phien phan tich da het han; hay tai lai PDF/anh.")
    return source


@app.get("/api/source-preview/{source_id}/{page}")
async def preview_source(source_id: str, page: int, overlay: int = 0):
    source=get_source(source_id)
    images=source['analysis']['_renders'].get(page-1)
    if images is None:
        raise HTTPException(404,"Khong co anh xem truoc trang nay (gioi han 12 trang).")
    return Response(images['overlay' if overlay else 'original'],
                    media_type='image/png',headers={'Cache-Control':'no-store'})


@app.post("/api/orpheus-layout/{source_id}/{page}")
async def orpheus_layout(source_id: str, page: int):
    source=get_source(source_id)
    if not 1<=page<=source['analysis']['pages']:
        raise HTTPException(404, "Trang khong hop le")
    if not orpheus_available():
        raise HTTPException(503,"Chua cai mo hinh Orpheus do ban tu cung cap (che do nghien cuu).")
    try:
        result=await run_in_threadpool(analyze_layout, source['file'],source['filename'],page-1)
    except Exception as exc:
        LOG.exception('Orpheus layout research failed')
        raise HTTPException(422, 'Khong chay duoc Orpheus layout: '+str(exc)[:250]) from exc
    source['orpheus'][page]=result
    return {k:v for k,v in result.items() if k!='image'} | {'preview_url':f'/api/orpheus-preview/{source_id}/{page}'}


@app.get("/api/orpheus-preview/{source_id}/{page}")
async def orpheus_preview(source_id: str, page: int):
    data=get_source(source_id)['orpheus'].get(page)
    if not data:raise HTTPException(404,'Can chay kiem thu layout truoc.')
    return Response(data['image'], media_type='image/png',headers={'Cache-Control':'no-store'})


@app.post("/api/convert")
async def convert(file: UploadFile = File(...), bpm: int | None = Form(None),
                  pages: str = Form(""), source_id: str = Form(""),
                  mode: str = Form("auto"), time_sig: str = Form("6/8")):
    filename = Path(file.filename or "unknown").name
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(415, "Chỉ hỗ trợ PDF, PNG/JPG/WebP, GP3, GP4, GP5.")
    if bpm is not None and (bpm < 30 or bpm > 300):
        raise HTTPException(422, "BPM phải trong khoảng 30–300")
    data = await file.read(DATA_LIMIT + 1)
    await file.close()
    if len(data) == 0 or len(data) > DATA_LIMIT:
        raise HTTPException(413, "File rỗng hoặc lớn hơn 35 MB.")
    if pages.strip() and ext != '.pdf':
        raise HTTPException(422,'Chon trang chi ap dung voi file PDF.')
    try:
        job = await run_in_threadpool(conversion_pipeline, data, filename, bpm, pages, mode, time_sig)
    except Exception as exc:
        LOG.exception("Conversion error")
        raise HTTPException(422, f"Không chuyển được file: {str(exc)[:400]}") from exc
    src = SOURCE_STORE.get(source_id) if source_id else None
    if src and hashlib.sha256(data).hexdigest()==src['analysis']['_digest']:
        info=src['analysis']
        checked_pages=job.get('selected_pages') or list(range(1,info['pages']+1))
        candidates=sum(info['items'][page-1]['fret_candidates'] for page in checked_pages)
        notes=int(job.get('score',{}).get('total_notes',0))
        job['source_audit']={'source_id':source_id,'pages':info['pages'],
                              'tab_groups':info['tab_groups'],'staff_groups':info['staff_groups'],
                              'fret_candidates':info['fret_candidates'],
                              'selected_fret_candidates':candidates,
                              'gp_note_count':notes,
                              'possible_omissions':bool(candidates>=30 and notes < candidates*.55),
                              'note_comparison':'So fret trich tu PDF khong tuong duong truc tiep so not GP.'}
    job_id = str(uuid.uuid4())
    job.update({"created": time.time(), "name": safe_stem(filename)})
    cleanup_store()
    with STORE_LOCK:
        STORE[job_id] = job
    return as_public(job_id, job)


@app.get("/api/download/{job_id}/{fmt}")
async def download(job_id: str, fmt: str):
    job = get_job(job_id)
    fmt = fmt.lower()
    data = job["files"].get(fmt)
    if data is None:
        raise HTTPException(404, f"Chưa có bản {fmt.upper()} được kiểm tra hợp lệ.")
    filename = f"{job['name']}.{fmt}"
    return Response(data, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"',
                             "Cache-Control": "no-store"})


@app.get("/api/download-all/{job_id}")
async def download_all(job_id: str):
    job = get_job(job_id)
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for ext, contents in job["files"].items():
            archive.writestr(f"{job['name']}.{ext}", contents)
        archive.writestr("README.txt", "Generated from user file by TunerTools PDF/IMG GP Web. Verify notes, rhythms and techniques against original before use.\n")
    filename = f"{job['name']}_GP.zip"
    return Response(bio.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/api/edit/{job_id}")
async def edit(job_id: str, payload: EditRequest):
    job = get_job(job_id)
    def update():
        gp5 = job["gp5"]
        song = load_song(gp5)
        try:
            target = song.tracks[payload.track].measures[payload.measure].voices[payload.voice].beats[payload.beat].notes[payload.note]
        except IndexError as exc:
            raise ValueError("Nốt nhạc không tồn tại") from exc
        target.value = payload.fret
        if payload.string is not None:
            track = song.tracks[payload.track]
            valid_strings = {int(s.number) for s in track.strings}
            if payload.string not in valid_strings:
                raise ValueError("Số dây không thuộc track này")
            beat_obj = track.measures[payload.measure].voices[payload.voice].beats[payload.beat]
            if any(n is not target and int(n.string) == payload.string for n in beat_obj.notes):
                raise ValueError("Phách này đã có nốt trên dây được chọn")
            target.string = payload.string
        new_gp5 = write_song(song, "gp5")
        files, warnings = build_exports(new_gp5)
        return new_gp5, files, warnings, extract_score(new_gp5)
    try:
        new_gp5, files, warnings, score = await run_in_threadpool(update)
    except Exception as exc:
        raise HTTPException(422, f"Không sửa được nốt: {exc}") from exc
    with STORE_LOCK:
        job.update(gp5=new_gp5, files=files, export_warnings=warnings, score=score)
    return as_public(job_id, job)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8021, workers=1)
