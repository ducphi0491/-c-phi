"""Experimental, traceable TAB extraction for *vector* PDFs.

Never claims that rhythms, rests, ties, effects, or pitches are fully recovered.
The supported output is a reviewable draft with source coordinates per note.
No EZMusic/Orpheus code or weights are included.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math
import re
from typing import Any

import fitz
from source_inspector import _line_candidates, _systems

TUNING = [64, 59, 55, 50, 45, 40]
SUPPORTED_TIMES = {(2,4), (3,4), (4,4), (6,8), (12,8)}
# each quarter note is 32 ticks in this working representation.
DURATIONS = [
    (1, 128, False), (2, 64, False), (3, 64, True),
    (4, 32, False), (6, 32, True), (8, 16, False),
    (12, 16, True), (16, 8, False), (24, 8, True),
    (32, 4, False), (48, 4, True), (64, 2, False),
    (96, 2, True), (128, 1, False),
]


def _tab_candidates(page: fitz.Page) -> list[dict[str, Any]]:
    candidates = []
    for original in _systems(_line_candidates(page), page.rect.width):
        if original['kind'] != 'tab':
            continue
        s=dict(original)
        if len(s['lines'])==5 and s.get('partial'):
            # A long ledger/barline can occasionally hide the sixth TAB line
            # in the vector PDF; extrapolate it but mark it for review.
            s['lines']=list(s['lines'])+[round(s['lines'][-1]+s['spacing'],2)]
            s['reconstructed_line']=True
        if len(s['lines'])==6:
            candidates.append(s)
    words = page.get_text('words')
    ranked = []
    for s in candidates:
        score = 0
        for w in words:
            if re.fullmatch(r'\d{1,2}', str(w[4])) and int(w[4]) <= 36:
                y = (w[1] + w[3]) / 2
                if min(abs(y - line) for line in s['lines']) <= 2.8:
                    score += 1
        ranked.append((score, s))
    ranked.sort(key=lambda item: (-item[0], item[1]['lines'][0]))
    unique = []
    for score, s in ranked:
        if score < 3:
            continue
        lo, hi = s['lines'][0], s['lines'][-1]
        if any(max(0, min(hi, r['lines'][-1]) - max(lo, r['lines'][0])) > 0.45 * (hi - lo)
               for r in unique):
            continue
        unique.append(s)
    return sorted(unique, key=lambda s: s['lines'][0])


def _barlines(page: fitz.Page, tab: dict[str, Any]) -> list[float]:
    lo, hi = tab['lines'][0], tab['lines'][-1]
    found = []
    for path in page.get_drawings():
        for item in path['items']:
            if item[0] == 're':
                r = item[1]
                if (0.15 <= r.width <= 3.5 and r.height >= 0.90 * (hi-lo)
                    and r.y0 <= lo + 2.5 and r.y1 >= hi - 2.5
                    and r.x0 > 20 and r.x0 < page.rect.width-15):
                    found.append((r.x0+r.x1)/2)
            elif item[0] == 'l':
                a,b = item[1:3]
                if abs(a.x-b.x)<1.1 and min(a.y,b.y)<=lo+2.5 and max(a.y,b.y)>=hi-2.5:
                    found.append((a.x+b.x)/2)
    ordered = []
    for x in sorted(found):
        if not ordered or abs(ordered[-1]-x)>1.5:
            ordered.append(x)
    return ordered


def _words_in_tab(page: fitz.Page, tab: dict[str, Any]) -> list[dict]:
    rows = tab['lines']
    found = []
    for w in page.get_text('words'):
        text = str(w[4]).strip()
        if not re.fullmatch(r'\d{1,2}', text) or int(text)>36:
            continue
        x=(w[0]+w[2])/2
        y=(w[1]+w[3])/2
        diffs=[abs(y-line) for line in rows]
        i=min(range(6),key=lambda i:diffs[i])
        if diffs[i] > 2.7 or w[0] < 10:
            continue
        found.append({'x':round(x,2),'y':round(y,2),'string':i+1,
                      'fret':int(text),'line_error':round(diffs[i],2)})
    return sorted(found, key=lambda f:(f['x'],f['string']))


def _merge_x_columns(notes: list[dict], tolerance: float=2.3) -> list[dict]:
    columns=[]
    for note in notes:
        if columns and abs(note['x']-columns[-1]['x']) <= tolerance:
            group=columns[-1]
            if any(n['string']==note['string'] for n in group['notes']):
                # Preserve the better aligned one for this string.
                old=next(n for n in group['notes'] if n['string']==note['string'])
                if note['line_error'] < old['line_error']:
                    group['notes'].remove(old)
                    group['notes'].append(note)
            else:
                group['notes'].append(note)
            group['x']=round(sum(n['x'] for n in group['notes'])/len(group['notes']),2)
        else:
            columns.append({'x':note['x'],'notes':[note]})
    return columns


def _rhythm_from_spacing(columns:list[dict], bar_end:float, numerator:int, denominator:int)->tuple[list[dict],bool]:
    """Estimate a mathematically valid measure, NEVER a ground-truth rhythm.

    DP selects supported note lengths minimizing difference from visual spacing,
    while ensuring that total measure duration is exact.
    """
    count=len(columns)
    if count == 0:return [],False
    ticks=numerator * 4 * 32 // denominator
    # No extraordinary 128th subdivisions beyond a sane bound.
    if count>ticks:
        return [], True
    xs=[x['x'] for x in columns]
    gaps=[]
    for a,b in zip(xs,xs[1:]):
        gaps.append(max(1.0,b-a))
    gaps.append(max(1.,bar_end-xs[-1]))
    if gaps and gaps[-1] > 2.5*sorted(gaps)[len(gaps)//2]:
        gaps[-1]=sorted(gaps)[len(gaps)//2]
    normal=sum(gaps)
    targets=[g/normal*ticks for g in gaps]
    choices=[(v,den,dotted) for v,den,dotted in DURATIONS if v<=ticks]
    # Dynamic programming O(n * ticks * variants); bounded to 40 pages.
    dp={0:(0.0,[])}
    for i,aim in enumerate(targets):
        nxt={}
        for used,(cost,path) in dp.items():
            for value,den,dotted in choices:
                total=used+value
                if total>ticks:continue
                remain=count-i-1
                if total+remain>ticks:continue
                diff=(value-aim)/max(1.0,aim)
                penalty=diff*diff + (0.055 if dotted else 0.)
                nc=cost+penalty
                if total not in nxt or nc<nxt[total][0]:
                    nxt[total]=(nc,path+[(value,den,dotted)])
        dp=nxt
        if not dp: break
    if ticks not in dp:return [],True
    cost,seq=dp[ticks]
    normalized=[]
    for col,(v,den,dot) in zip(columns,seq):
        normalized.append({'x':col['x'],'notes':col['notes'],
            'duration':den,'dotted':dot,'length':round(v/32,5),
            'source':'pdf_vector','rhythm_estimated':True})
    # Any more than a few discrepancies means extra caution.
    high_rhythm_uncertainty= cost/max(1,len(seq))>.36
    return normalized,high_rhythm_uncertainty


def extract_vector_draft(data: bytes, pages: list[int] | None = None,
                         time_sig: str='6/8', bpm:int=80)->dict:
    try:
        numer,denom=[int(s) for s in time_sig.split('/')]
    except Exception as e:
        raise ValueError('Nhịp không hợp lệ. Hãy chọn 2/4, 3/4, 4/4, 6/8 hoặc 12/8.') from e
    if (numer,denom) not in SUPPORTED_TIMES:
        raise ValueError('Nhịp chưa hỗ trợ trong chế độ vector thử nghiệm.')
    bars=[]; systems_count=0; source_notes=0; ungrouped=0; uncertain=0
    matched_columns=0; all_columns=0
    problems=[]; preview=[]
    with fitz.open(stream=data,filetype='pdf') as doc:
        if doc.needs_pass:raise ValueError('PDF có mật khẩu.')
        sel = pages if pages is not None else list(range(len(doc)))
        if not sel:raise ValueError('Chưa chọn trang PDF.')
        if len(sel)>40:raise ValueError('Tối đa 40 trang.')
        for page_index in sel:
            p=doc[page_index]
            tabs=_tab_candidates(p)
            staffs=[s for s in _systems(_line_candidates(p),p.rect.width) if s['kind']=='staff']
            glyphs=[]
            for block in p.get_text('rawdict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line.get('spans',[]):
                        for char in span.get('chars',[]):
                            if char['c']=='\ue0a4':
                                rect=char['bbox']
                                glyphs.append(((rect[0]+rect[2])/2, rect[1]))
            if not tabs:
                problems.append(f'Trang {page_index+1}: không tìm thấy nhóm TAB 6 dòng trong dữ liệu vector.')
            for si,tab in enumerate(tabs):
                notes=_words_in_tab(p,tab)
                source_notes += len(notes)
                barlines=_barlines(p,tab)
                if not notes:continue
                systems_count+=1
                if tab.get('reconstructed_line'):
                    problems.append(f'Trang {page_index+1}, hệ {si+1}: thiếu một đường TAB vector; đã nội suy, cần kiểm tra.')
                # Limit to barlines that partition actual notes; the barlines also
                # appear as tall vertical rectangle path operators in exported PDFs.
                left=min(n['x'] for n in notes)-max(7.0,tab['spacing']*1.0)
                right=max(n['x'] for n in notes)+max(7.0,tab['spacing']*1.0)
                edges=[left]+[x for x in barlines if left+3 < x < right+15]
                edges.sort()
                if edges[-1] < max(n['x'] for n in notes)+2:
                    edges.append(right)
                # Append trailing bar if its x-range is nonempty.
                for bi,(lo,hi) in enumerate(zip(edges,edges[1:])):
                    in_bar=[n for n in notes if lo-.5 <= n['x'] < hi-.5]
                    cols=_merge_x_columns(in_bar)
                    if not cols:continue
                    n_notes=sum(len(c['notes']) for c in cols)
                    nearest_staff=max((st for st in staffs if st['lines'][0]<tab['lines'][0]),
                                      key=lambda st:st['lines'][0],default=None)
                    valid_heads=[]
                    if nearest_staff and tab['lines'][0]-nearest_staff['lines'][0]<95:
                        sy0,sy1=nearest_staff['lines'][0],nearest_staff['lines'][-1]
                        valid_heads=[gx for gx,gy in glyphs if sy0-55<=gy<=sy1+15]
                    glyph_match=sum(any(abs(c['x']-gx)<=5.5 for gx in valid_heads) for c in cols)
                    all_columns+=len(cols)
                    matched_columns+=glyph_match
                    units,maybe_bad=_rhythm_from_spacing(cols,hi,numer,denom)
                    if not units:
                        problems.append(f'Trang {page_index+1}, hệ {si+1}: không gán được trường độ cho {len(cols)} cột.')
                        ungrouped+=n_notes
                        continue
                    if maybe_bad:uncertain+=1
                    bar={'number':len(bars)+1,'page':page_index+1,'system':si+1,
                         'x_range':[round(lo,2),round(hi,2)],
                         'notes_count':n_notes,'columns_count':len(cols),
                         'uncertain_rhythm':maybe_bad,'staff_aligned_columns':glyph_match,'beats':units}
                    bars.append(bar)
                    if len(preview)<16:
                        preview.append({'measure':bar['number'],'page':bar['page'],
                                        'notes':n_notes,'columns':len(cols),
                                        'first':[(b['notes'][0]['string'],b['notes'][0]['fret']) for b in units[:6]],
                                        'uncertain_rhythm':maybe_bad})
    if not bars:
        raise ValueError('Không đọc được số ngăn TAB từ PDF vector. Với PDF scan/ảnh, hãy dùng chế độ nhận diện OCR/OMR.')
    converted=sum(b['notes_count'] for b in bars)
    dropped=max(0,source_notes-converted)
    return {'mode':'vector_draft','time_signature':time_sig,'tempo':bpm,
            'bars':bars,'total_notes':converted,'source_frets':source_notes,
            'unmapped_frets':dropped,'systems':systems_count,'uncertain_bars':uncertain,
            'staff_aligned_columns':matched_columns,'all_columns':all_columns,
            'preview':preview,'problems':problems[:50],
            'warnings':[
                'BẢN NHÁP: Dây/ngăn đọc từ PDF vector; trường độ suy luận từ khoảng cách ngang, KHÔNG phải nhận diện OMR.',
                'Có thể chưa đúng vị trí ô nhịp, dấu lặng, bè, dấu nối, H/P, slide và tremolo. So sánh với bản gốc trước khi dùng.',
            ]}


def build_song(draft:dict):
    """Convert the reviewable draft to a real GP song using user's installed PyGuitarPro."""
    import guitarpro as gp
    numerator,denominator=(int(p) for p in draft['time_signature'].split('/'))
    song=gp.Song(title='TAB vector - CHUA DOI CHIEU', tempo=draft['tempo'])
    headers=[]; start=gp.Duration.quarterTime
    ts=gp.TimeSignature(numerator=numerator,denominator=gp.Duration(value=denominator))
    for i in range(len(draft['bars'])):
        h=gp.MeasureHeader(number=i+1,start=start,timeSignature=ts)
        start=h.end
        headers.append(h)
    song.measureHeaders=headers
    track=gp.Track(song,number=1,name='Guitar - ban nhap PDF',measures=[])
    track.settings.notation=True
    track.settings.tablature=True
    song.tracks=[track]
    for b,h in zip(draft['bars'],headers):
        m=gp.Measure(track,h)
        voice=m.voices[0]
        for cell in b['beats']:
            beat=gp.Beat(voice,duration=gp.Duration(value=int(cell['duration']),
                          isDotted=bool(cell['dotted'])),status=gp.BeatStatus.normal)
            for n in cell['notes']:
                beat.notes.append(gp.Note(beat,string=n['string'],value=n['fret'],
                                          type=gp.NoteType.normal))
            voice.beats.append(beat)
        track.measures.append(m)
    return song
