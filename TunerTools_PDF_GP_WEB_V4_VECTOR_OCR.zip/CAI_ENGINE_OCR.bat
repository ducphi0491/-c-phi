@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAI_ENGINE_OCR.ps1"
echo.
pause
