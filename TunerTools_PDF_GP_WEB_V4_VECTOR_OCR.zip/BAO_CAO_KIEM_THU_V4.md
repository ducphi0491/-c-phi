# TunerTools PDF/Ảnh → GP Web V4 — Báo cáo kỹ thuật

## Mục tiêu

Nâng cấp dự án Web V3 để **thử chuyển PDF vector thành bản nháp GP3/GP4/GP5** bằng việc đọc trực tiếp vị trí dây/ngăn từ PDF, hiển thị khuông nhạc + TAB, cho phát thử và sửa số ngăn/dây. Ảnh/PDF scan sử dụng engine OCR/OMR tùy chọn đã được người dùng cài riêng.

Không tích hợp mã hay trọng số EZMusic/Orpheus vào sản phẩm.

## Những gì đã thực hiện

1. `vector_draft.py`: xác định các nhóm TAB sáu dòng từ vector PDF, khớp chữ số ngăn vào dây theo tọa độ, phân nhóm các nốt cùng cột thành hợp âm, tìm đường gạch ô nhịp khi có, ước lượng trường độ bằng quy hoạch động để mỗi ô có tổng nhịp hợp lệ.
2. Đối chiếu đồ họa với ký tự notehead trên khuông: chỉ **so vị trí theo trục ngang**; không đọc chính xác cao độ nốt hoặc kỹ thuật chơi.
3. Tạo GP5 nháp (khi máy có PyGuitarPro), sau đó thử xuất GP4/GP3 bằng phiên bản file thực `(4,0,6)`/`(3,0,0)`. Mỗi file phải được parse lại để kiểm tra cấu trúc.
4. Bổ sung lựa chọn engine và thời gian 6/8, 4/4, 3/4, 2/4, 12/8 vào giao diện; cảnh báo rõ dữ liệu chưa xác minh.
5. Chia bộ cài thành **core** (PDF vector, GP) và **OCR/OMR tùy chọn**, tránh phụ thuộc vào tải GitHub trong bước mở web đầu tiên.

## Thử với PDF thực tế đã cung cấp

Đã dùng file `ban_nhac.pdf` sáu trang ở phiên kiểm thử trước. Không phân phối kèm bản nhạc đó trong ZIP này.

| Hạng mục | Trang 1 | Cả 6 trang |
|---|---:|---:|
| Ô nhịp **ước lượng** từ vạch vector | 20 | 89 |
| Chữ số TAB lấy được trong các vùng đã nhận diện | 184 | 962 |
| Cột TAB nằm gần notehead khuông | 126/126 | Chưa xác nhận từng nốt |

Dữ liệu vector của bản gốc bị giao nhau ở vùng tremolo dày và một vài đường TAB bị thiếu. **Số ô nhịp của cả sáu trang chưa đúng hoàn toàn**, nên phải đối chiếu từng trang và sửa. Giá trị 184 chữ số không tương đương 184 nốt đúng nhạc lý. Mọi trường độ đều được suy ra từ khoảng cách ngang nên chỉ để nghe thử bản nháp.

## Đã chạy kiểm tra

- **13/13 bài kiểm tra Python**: thành công (bao gồm phân tích PDF, kiểm tra API và bài dựng PDF vector thử nghiệm).
- **Kiểm tra JS bằng Node**: thành công.
- **Trình duyệt Chromium (giao diện demo + đổi chế độ)**: không có lỗi JS trong lượt thử tĩnh.
- **API `/api/inspect` với PDF thật**: HTTP 200, trả đủ thông tin trang, số ứng viên và ảnh gốc/overlay.

**Chưa kiểm thử end-to-end xuất GP5/GP4/GP3 trong môi trường tạo ZIP**, vì môi trường này không cài được PyGuitarPro từ Internet. Script dùng API PyGuitarPro đã tra cứu từ tài liệu chính thức và kiểm tra lại cú pháp; khả năng tạo và đọc lại GP thực tế cần chạy trên Windows của người dùng. Không được gọi đây là bản nhận diện chính xác.

## Hạn chế quan trọng

- Không nhận diện chắc chắn trường độ, nốt lặng, bè chồng, dấu nối, dấu luyến, hammer-on/pull-off, slide, bend, tremolo.
- Không xuất từ ảnh scan bằng vector; cần engine OCR/OMR bổ sung.
- Chưa giải mã Orpheus thành MusicXML.
- GP3/GP4/GP5 đã parse lại vẫn có thể khác PDF gốc.
- Với PDF không có line TAB ở dạng vector, chọn engine OCR/OMR.

## Lộ trình nâng độ chính xác

Bước tiếp theo về kỹ thuật nên làm là đọc thời lượng từ beam/stem/glyph hoặc bộ OMR chuyên dụng, xác định chính xác barlines trong trang dày ký hiệu, phục dựng các bè và kiểm tra pitch của notehead với dây/ngăn đã lấy ra. Không nên chỉ chỉnh độ phân giải ảnh hoặc tô overlay.
