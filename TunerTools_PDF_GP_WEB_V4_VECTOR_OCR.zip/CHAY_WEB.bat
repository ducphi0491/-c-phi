@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title TunerTools - PDF va Hinh sang GP3 GP4 GP5
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CHAY_WEB.ps1"
if errorlevel 1 (
 echo.
 echo Gap loi khi khoi dong. Hay chup lai ket qua cua so nay gui de kiem tra.
 pause
)
endlocal
