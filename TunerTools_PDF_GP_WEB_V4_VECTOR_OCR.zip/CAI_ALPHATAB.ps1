param([switch]$Force)
# Installs alphaTab 1.8.4 from npm registry into local static assets.
# This script downloads 3rd party open-source files on the user's Windows machine.
# The ZIP distributed with TunerTools contains no music fonts and no SoundFont.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $Root 'static\alphatab'
$Core = Join-Path $Dest 'alphaTab.min.js'
$Font = Join-Path $Dest 'font'
$Audio = Join-Path $Dest 'soundfont\sonivox.sf2'
if ((Test-Path $Core) -and (Test-Path $Font) -and (Test-Path $Audio) -and (-not $Force)) {
    Write-Host '[OK] alphaTab va SoundFont da cai san.' -ForegroundColor Green
    exit 0
}
$Temp = Join-Path $env:TEMP ('TunerAlphaTab_' + [Guid]::NewGuid().ToString('N'))
try {
    New-Item -ItemType Directory -Path $Temp -Force | Out-Null
    $Archive = Join-Path $Temp 'alphatab-1.8.4.tgz'
    $Uri = 'https://registry.npmjs.org/@coderline/alphatab/-/alphatab-1.8.4.tgz'
    Write-Host 'Dang tai alphaTab 1.8.4 (MPL-2.0) tu npm...' -ForegroundColor Cyan
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $Uri -OutFile $Archive -TimeoutSec 120 -UseBasicParsing
    if (-not (Test-Path $Archive) -or (Get-Item $Archive).Length -lt 100000) { throw 'File npm qua nho hoac khong hop le.' }
    & tar.exe -xzf $Archive -C $Temp
    if ($LASTEXITCODE -ne 0) { throw 'Khong giai nen duoc alphatab tgz bang tar.exe.' }
    $Src = Join-Path $Temp 'package\dist'
    if (-not (Test-Path (Join-Path $Src 'alphaTab.min.js'))) { throw 'Npm package thieu alphaTab.min.js.' }
    if (-not (Test-Path (Join-Path $Src 'font'))) { throw 'Npm package thieu Bravura font.' }
    if (-not (Test-Path (Join-Path $Src 'soundfont'))) { throw 'Npm package thieu SoundFont.' }
    if ((Test-Path $Dest)) { Remove-Item -LiteralPath $Dest -Recurse -Force }
    New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $Src 'alphaTab.min.js') -Destination $Dest -Force
    # Keep the accompanying files in their original folder names for alphaTab worker/font loading.
    Get-ChildItem -LiteralPath $Src -File -Filter 'alphaTab.*js' | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Dest -Force
    }
    Copy-Item -LiteralPath (Join-Path $Src 'font') -Destination $Dest -Recurse -Force
    Copy-Item -LiteralPath (Join-Path $Src 'soundfont') -Destination $Dest -Recurse -Force
    if (-not (Test-Path $Audio)) {
        $Other = Get-ChildItem -LiteralPath (Join-Path $Dest 'soundfont') -Filter '*.sf2' -Recurse -File | Select-Object -First 1
        if ($Other) { Copy-Item -LiteralPath $Other.FullName -Destination $Audio -Force }
    }
    $License = Join-Path $Temp 'package\LICENSE'
    if (Test-Path $License) { Copy-Item -LiteralPath $License -Destination (Join-Path $Dest 'LICENSE-alphaTab.txt') }
    if (-not (Test-Path $Core) -or -not (Test-Path $Audio)) {throw 'Thieu file js hoac sonivox.sf2 sau cai dat.'}
    Write-Host '[OK] Cai alphaTab + font + SoundFont thanh cong.' -ForegroundColor Green
    Write-Host 'Giu nguyen ten alphaTab trong ket qua; tuan thu yeu cau attribution cua du an.' -ForegroundColor Gray
    exit 0
} catch {
    Write-Warning ('Khong cai duoc alphaTab. Web van co che do SVG mac dinh. Chi tiet: '+ $_.Exception.Message)
    exit 2
} finally {
    if (Test-Path $Temp) { Remove-Item -LiteralPath $Temp -Recurse -Force -ErrorAction SilentlyContinue }
}
