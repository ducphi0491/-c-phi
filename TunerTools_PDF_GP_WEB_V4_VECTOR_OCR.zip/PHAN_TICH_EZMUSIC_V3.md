# TunerTools PDF/ảnh → Guitar Pro Web v0.3 — Phân tích mã giải biên dịch

## Nguồn kiểm tra

Người dùng cung cấp `base_1 (1).apk_Decompiler.com.zip` (nguồn Java/Smali đã giải biên dịch từ EZMusic APK), APK trước đó, các mô hình Orpheus riêng và PDF guitar tremolo 6 trang để kiểm thử. **Gói web này không chứa mã Java/Smali, tài nguyên hoặc trọng số mô hình độc quyền.**

## Phát hiện trong mã giải biên dịch

- `sources/defpackage/ol.java`: cấu hình tải **Orpheus** và **Echo** từ API EZMusic, lưu vào bộ nhớ riêng của ứng dụng Android.
- `sources/defpackage/vm.java`: yêu cầu các file `layout.onnx`, `encoder.onnx`, `decoder.onnx` và `orpheus.json`; có kiểm tra phiên bản schema.
- `sources/defpackage/i62.java`: chạy ONNX Runtime với đầu vào `page`, đầu ra `classes` (bản đồ vùng ảnh). Đây **không phải** bảng nốt nhạc.
- `sources/defpackage/v53.java`: tổ chức bước phân tích theo dải khuông và có các cảnh báo khi ảnh nghiêng, băng quá rộng, vượt giới hạn token. **Phương thức nhận diện chính `b(io1, rl)` không được JADX giải biên dịch thành Java hoàn chỉnh** (trả `UnsupportedOperationException` trong bản decompiler). Điều này ngăn việc khôi phục pipeline đầy đủ chỉ từ các file `.java`.
- `sources/defpackage/p84.java`: cấu trúc `SheetNotation` có trường `musicXML`, tempo, chỉ số nhịp, dấu hóa và trạng thái nhận diện.
- Không xác minh được phần xuất GP3/GP4/GP5 sẵn trong app; vì vậy web tiếp tục dùng `PyGuitarPro` để ghi GP thật.

## Đã tích hợp vào web v0.3

1. **Phân tích PDF nguồn trước khi chuyển**: tự đếm trang, dùng PyMuPDF lấy các đoạn kẻ vector, nhóm 5 dòng khuông/6 dòng TAB và các chữ số ngăn ứng viên. Kết quả là **gợi ý đối chiếu**, không phải OCR đủ nốt/nhịp.
2. **Đánh dấu trực quan**: khuông xanh dương, TAB xanh lá, chữ số ngăn được khoanh đỏ. Có thể đổi từng trang.
3. **So sánh hai bên**: nguồn PDF/ảnh và bản nhạc từ GP ở hai cột. Khuông nhạc được dựng từ cùng dữ liệu GP với TAB; phát thử từ GP.
4. **Chọn trang PDF** trước khi nhận diện (`1`, `1-3`, `1,3,5`). Bảo toàn nội dung vector bằng PyMuPDF khi trích trang.
5. **Kiểm thử tùy chọn Orpheus layout trên máy người dùng**: chỉ khi bạn tự cung cấp model ZIP để nghiên cứu và có quyền sử dụng; không tải mô hình từ máy chủ EZMusic, không đưa vào bản phân phối. Kết quả chỉ là bản đồ lớp pixel, **không tạo MusicXML hay Guitar Pro**.
6. **Bộ chuyển xuất GP3/GP4/GP5** và phát thử giữ theo bản trước. Các tệp GP được đọc lại để kiểm tra, nhưng không bảo đảm OCR đúng với bản gốc.

## Kết quả kiểm tra

- Tài liệu PDF tremolo 6 trang: trích xuất được tọa độ dòng khuông/TAB và khoanh các chữ số ngăn ứng viên. **Không có kiểm chứng tất cả các vị trí hoặc trường độ**.
- 9 bài kiểm thử Python/FastAPI đạt; kiểm tra giao diện JavaScript trên Chromium ở chế độ offline có không lỗi console; cửa sổ đối chiếu và lựa chọn trang hoạt động.
- **Chưa kiểm thử end-to-end PDF → GP với bộ nhận diện upstream trên Windows** trong môi trường tạo bản này, do thiếu phụ thuộc tải qua Internet. Muốn xác nhận khả năng đọc nốt đúng, phải chạy trên Windows có đủ engine và so sánh file GP với PDF.
- **Chưa tích hợp bộ giải mã MusicXML của Orpheus**: mã giải biên dịch không đầy đủ và quyền sử dụng mô hình chưa được xác minh. Hãy coi AI Orpheus trong v0.3 là công cụ nghiên cứu hình ảnh, không phải engine tạo GP.

## Kiểm thử thực tế tại Windows

1. Mở `CHAY_WEB.bat`; chọn PDF/ảnh. Chờ phần **Kiểm tra PDF/ảnh đầu vào** hoàn tất.
2. Nhấn **Xem vị trí nốt & đường khuông**, chuyển lần lượt các trang để kiểm tra ký hiệu khoanh đỏ có trùng số ngăn không.
3. Có thể điền `1` vào **Trang PDF** để thử nhận diện trang đầu; sau đó xóa nội dung để chuyển tất cả trang.
4. Nhấn **Nhận diện & chuyển GP**. Nếu nhận dạng thành công, tab **Đối chiếu 2 bên** hiện PDF và khuông+TAB GP để so từng ô nhịp, Play để nghe.
5. Xem các cảnh báo kỹ thuật (tremolo, slide, H/P, trường độ, bè...) và sửa số dây/ngăn khi cần. Chỉ tải GP để sử dụng chính thức sau khi kiểm tra.

## Giấy phép và bảo mật

EZMusic là phần mềm khác; mã và mô hình không tự động được phép sao chép/tái phân phối. Gói này thực hiện các thuật toán chẩn đoán và trình xem mới độc lập. PyMuPDF/alphaTab/PyGuitarPro/upstream OCR có giấy phép riêng; xem giấy phép trước khi phát hành ứng dụng thương mại. Web chỉ lắng nghe `127.0.0.1`, người dùng không cần upload bản nhạc ra máy chủ của chúng ta.
