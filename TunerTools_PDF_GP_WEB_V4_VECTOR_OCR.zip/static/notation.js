/*
 * TunerTools native SVG notation fallback.
 * Maps notes already decoded from the actual Guitar Pro binary to pitched
 * notation, rhythm and strings. It is NOT an OCR engine.
 * For full professional Guitar Pro engraving, use the optional alphaTab view.
 */
'use strict';
(function (root) {
  const stepGap = 6;
  const staffGap = 12;
  const keySharpOrder = ['F','C','G','D','A','E','B'];
  const keyFlatOrder = ['B','E','A','D','G','C','F'];
  const notesSharp = [['C',0],['C',1],['D',0],['D',1],['E',0],['F',0],['F',1],['G',0],['G',1],['A',0],['A',1],['B',0]];
  const notesFlat = [['C',0],['D',-1],['D',0],['E',-1],['E',0],['F',0],['G',-1],['G',0],['A',-1],['A',0],['B',-1],['B',0]];
  const letterStep = {C:0,D:1,E:2,F:3,G:4,A:5,B:6};
  const naturalPC = {C:0,D:2,E:4,F:5,G:7,A:9,B:11};
  const h = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
  const fix = x => Number(x.toFixed(2));

  function midiToSpelled(midi, key) {
    const value = Math.round(Math.max(0,Math.min(127,midi)));
    const pc = value % 12;
    const [letter, alter] = (key < 0 ? notesFlat : notesSharp)[pc];
    // Letter/alter normally maps to the pitch class. Account for enharmonic crossing at C.
    const octave = Math.round((value - naturalPC[letter] - alter) / 12) - 1;
    return {letter,alter,octave,step:octave*7+letterStep[letter]};
  }
  function keySignatureContains(letter,key) {
    if (key>0) return keySharpOrder.slice(0,Math.min(7,key)).includes(letter)?1:0;
    if (key<0) return keyFlatOrder.slice(0,Math.min(7,-key)).includes(letter)?-1:0;
    return 0;
  }
  function accidentalFor(note,key) {
    const a = keySignatureContains(note.letter,key);
    if(a===note.alter) return '';
    return note.alter===0?'♮':note.alter>0?'♯':'♭';
  }
  function rect(x,y,w,height,cls,attrs='') {return `<rect x="${fix(x)}" y="${fix(y)}" width="${fix(w)}" height="${fix(height)}" class="${cls}" ${attrs}/>`;}
  function line(x1,y1,x2,y2,cls='nt-rule',width=1) {return `<line x1="${fix(x1)}" y1="${fix(y1)}" x2="${fix(x2)}" y2="${fix(y2)}" class="${cls}" stroke-width="${width}"/>`;}
  function text(x,y,value,cls='',extra='') {return `<text x="${fix(x)}" y="${fix(y)}" class="${cls}" ${extra}>${h(value)}</text>`;}
  function staffPosition(pitch,top,clef,transpose=12) {
    const spelled=midiToSpelled(pitch+transpose,0);
    const bottomStep=clef==='bass' ? 2*7+4 : 4*7+2; // bass G2, treble E4
    return top+4*staffGap - (spelled.step-bottomStep)*stepGap;
  }
  function partPitch(pitch,top,clef,key,transpose) {
    const s=midiToSpelled(pitch+transpose,key);
    const base=clef==='bass'?2*7+4:4*7+2;
    return { ...s, y:top+4*staffGap-(s.step-base)*stepGap };
  }
  function durationDisplay(beat) {
    const value=Number(beat.duration||4);
    let flags=0;
    if(value>=8) flags=Math.max(1,Math.round(Math.log2(value/4)));
    return {filled:value>=4, stem:value>1, flags:Math.min(flags,4),dotted:!!beat.dotted,doubleDotted:!!beat.double_dotted};
  }
  function noteAttrs(trackId,measure,beat,n) {
    const start=measure.start+beat.position;
    return `data-track="${trackId}" data-measure="${measure.index}" data-voice="${beat.voice}" data-beat="${beat.beat}" data-note="${n.note}" data-string="${n.string}" data-fret="${n.fret}" data-start="${fix(start)}" data-length="${fix(beat.length)}"`;
  }
  function noteHead(x,y,filled,attrs='') {
    return `<ellipse cx="${fix(x)}" cy="${fix(y)}" rx="7.2" ry="4.6" transform="rotate(-18 ${fix(x)} ${fix(y)})" class="${filled?'nt-head':'nt-hollow'} staff-note" ${attrs}/>`;
  }
  function restGlyph(x,y,value) {
    if(value===1) return rect(x-8,y-2,17,4,'nt-fill')+line(x-8,y-3,x+9,y-3,'nt-stem',2);
    if(value===2) return rect(x-7,y-4,14,5,'nt-fill');
    if(value===4) return text(x,y+6,'𝄽','nt-rest-quarter','text-anchor="middle"');
    const amount=value>=8? Math.min(4,Math.round(Math.log2(value/4))) : 1;
    let result='<path d="M '+fix(x+3)+' '+fix(y-17)+' l -6 31" class="nt-stem" stroke-width="1.8"/>';
    for(let i=0;i<amount;i++) result+=`<path d="M ${fix(x+2)} ${fix(y-12+i*9)} q 16 -2 2 12" class="nt-flag"/>`;
    return result;
  }
  function measureSvg(track,measure,trackId,mode,zoom=1) {
    const hasScore=mode!=='tabs';
    const hasTab=mode!=='score';
    const count=Math.min(12,Math.max(1,track.strings||6));
    const staffTop=48;
    const tabTop=hasScore?158:58;
    const height=hasTab?tabTop+(count-1)*15+43:150;
    const beats=measure.beats.slice().sort((a,b)=>a.position-b.position||a.voice-b.voice||a.beat-b.beat);
    const unique=[...new Set(beats.map(b=>fix(b.position)))];
    const measureLength=Math.max(Number(measure.length)||4,0.25);
    const width=Math.max(610,Math.min(1550,155+Math.max(measureLength*122,(unique.length+1)*65)));
    const padStart=139;
    const end=width-25;
    const effective=end-padStart;
    const at = (p) => padStart+Math.max(0, Math.min(1, Number(p)/measureLength))*effective;
    const clef = track.clef==='bass'?'bass':'treble';
    const key=Math.max(-7,Math.min(7, Number(measure.key_fifths ?? track.key_fifths ?? 0)));
    const octaveTransposition = Number.isFinite(Number(track.notation_transposition)) ? Number(track.notation_transposition) : 12;
    let svg=`<svg class="notation-svg" viewBox="0 0 ${width} ${height}" width="${fix(width*zoom)}" height="${fix(height*zoom)}" role="img" aria-label="Ô nhịp ${measure.number}: khuông nhạc và TAB" xmlns="http://www.w3.org/2000/svg">`;
    svg+=rect(0,0,width,height,'nt-background');
    svg+=text(13,23,`Ô ${measure.number}`,'nt-bar-number');
    svg+=text(13,40,measure.time||'4/4','nt-bar-meter');
    if(hasScore){
      for(let i=0;i<5;i++) svg+=line(60,staffTop+i*staffGap,end,staffTop+i*staffGap,'nt-staff-line',1);
      svg+=line(end,staffTop,end,staffTop+4*staffGap,'nt-barline',1.5);
      svg+=text(60,staffTop+(clef==='treble'?47:29),clef==='bass'?'𝄢':'𝄞','nt-clef',`font-size="${clef==='treble'?66:44}"`);
      if (clef==='treble' && octaveTransposition!==0) svg+=text(78,staffTop+57,'8','nt-octave');
      let xKey=96;
      const keyOrder=key>0?keySharpOrder:keyFlatOrder;
      for (const letter of keyOrder.slice(0,Math.abs(key))){
        const sharpPositions={F:10,C:28,G:4,D:22,A:40,E:16,B:34};
        const flatPositions={B:30,E:12,A:36,D:18,G:42,C:24,F:46};
        svg+=text(xKey,staffTop+(key>0?sharpPositions[letter]:flatPositions[letter]),key>0?'♯':'♭','nt-accidental nt-key');
        xKey+=9;
      }
      const [num,den]=(measure.time||'4/4').split('/');
      svg+=text(123,staffTop+18,num,'nt-time','text-anchor="middle"');
      svg+=text(123,staffTop+42,den,'nt-time','text-anchor="middle"');
    }
    if(hasTab){
      const left=65;
      for (let i=0;i<count;i++) {
        const y=tabTop+i*15;
        svg+=line(left,y,end,y,'nt-tab-line',1);
        const pitch=Number(track.tuning?.[i+1]??40);
        const labels=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
        svg+=text(47,y+4,labels[((pitch%12)+12)%12],'nt-string-label','text-anchor="end"');
      }
      svg+=line(end,tabTop,end,tabTop+(count-1)*15,'nt-barline',1.5);
      svg+=text(72,tabTop+((count-1)*15)/2+6,'TAB','nt-tab-clef');
    }
    const measureNotesByBeat = beats.filter(b => b.notes?.length);
    // Note objects keep their own voice/beat identity; chords remain aligned.
    for(const beat of beats){
      const x=at(beat.position);
      const dur=durationDisplay(beat);
      if(!beat.notes || !beat.notes.length){
        if(hasScore) svg+=restGlyph(x,staffTop+24,Number(beat.duration||4));
        continue;
      }
      if(hasScore){
        const pitched=beat.notes.map(n=>({n,p:partPitch(n.pitch,staffTop,clef,key,octaveTransposition)})).sort((a,b)=>a.p.y-b.p.y);
        const ys=pitched.map(a=>a.p.y);
        const avg=ys.reduce((a,b)=>a+b,0)/ys.length;
        const stemUp=avg>=staffTop+24;
        const stemX=x+(stemUp?6.5:-6.5);
        const tipY=stemUp?Math.min(...ys)-35:Math.max(...ys)+35;
        for (const {n,p} of pitched) {
          const topY=staffTop,botY=staffTop+4*staffGap;
          if(p.y < topY-1){for(let yy=topY-staffGap;yy>=p.y-1; yy-=staffGap)svg+=line(x-12,yy,x+12,yy,'nt-ledger');}
          else if(p.y>botY+1){for(let yy=botY+staffGap;yy<=p.y+1;yy+=staffGap)svg+=line(x-12,yy,x+12,yy,'nt-ledger');}
          const acc=accidentalFor(p,key);
          if(acc) svg+=text(x-17,p.y+5,acc,'nt-accidental','text-anchor="middle"');
          svg+=noteHead(x,p.y,dur.filled,`data-start="${fix(measure.start+beat.position)}" data-length="${fix(beat.length)}"`);
          if(dur.dotted)svg+=`<circle cx="${fix(x+12)}" cy="${fix(p.y-2)}" r="2.1" class="nt-fill"/>`;
          if(dur.doubleDotted)svg+=`<circle cx="${fix(x+19)}" cy="${fix(p.y-2)}" r="1.7" class="nt-fill"/>`;
        }
        if(dur.stem) {
          svg+=line(stemX,stemUp?Math.max(...ys):Math.min(...ys),stemX,tipY,'nt-stem',1.8);
          for (let f=0;f<dur.flags;f++) {
            const flagY=tipY+(stemUp?f*10:-f*10);
            svg+=stemUp?
              `<path d="M ${fix(stemX)} ${fix(flagY)} q 18 6 10 23" class="nt-flag"/>`:
              `<path d="M ${fix(stemX)} ${fix(flagY)} q -20 -9 -9 -24" class="nt-flag"/>`;
          }
        }
        if(Number(beat.tuplet_enters||1)>1)svg+=text(x,staffTop-13,String(beat.tuplet_enters),'nt-tuplet','text-anchor="middle"');
      }
      if(hasTab){
        for (const n of beat.notes) {
          const idx=Math.round(n.string)-1;
          if(idx<0||idx>=count) continue;
          const y=tabTop+idx*15;
          const a=noteAttrs(trackId,measure,beat,n);
          const number=String(n.fret);
          const bgW=Math.max(18,number.length*9+7);
          svg+=rect(x-bgW/2,y-8.5,bgW,17,'nt-fret-background');
          svg+=text(x,y+4,number,'fret-note',`text-anchor="middle" role="button" tabindex="0" aria-label="Ô ${measure.number}, dây ${n.string}, ngăn ${number}. Nhấn để sửa" ${a}`);
        }
      }
    }
    svg+='</svg>';
    const title=mode==='score'?'Khuông nhạc':mode==='tabs'?'TAB':'Khuông nhạc + TAB';
    return `<div class="bar-score" data-measure="${measure.index}" data-mode="${h(mode)}" style="--notation-zoom:${fix(zoom)}"><div class="measure-header"><span>${h(title)} · Ô ${measure.number}</span><small>${h(measure.time||'4/4')}</small></div><div class="score-svg-wrap">${svg}</div></div>`;
  }
  function render(container,score,trackIndex=0,mode='both',zoom=1) {
    if(!container || !score?.tracks?.[trackIndex])return false;
    const track=score.tracks[trackIndex];
    container.innerHTML=track.measures.map(m=>measureSvg(track,m,trackIndex,mode,zoom)).join('')||'<p>Track này chưa có ô nhịp để hiển thị.</p>';
    return true;
  }
  root.TunerNativeNotation={render,midiToSpelled,partPitch};
})(window);
