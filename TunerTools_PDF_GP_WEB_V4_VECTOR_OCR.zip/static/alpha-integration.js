/* Optional professional alphaTab rendering and SoundFont playback.
 * Uses a locally downloaded, pinned alphaTab build; no CDN is needed at runtime.
 * Native SVG renderer remains fully functional when alphaTab is not installed.
 */
'use strict';
(function(root) {
  let api=null;
  let ready=false;
  let playerReady=false;
  let loadedId=null;
  let pendingId=null;
  let selectedTrack=0;
  let mode='both';
  let zoom=1;
  let callback=null;
  let timer=null;

  function status(msg){
    const el=document.getElementById('notationEngine');
    if(el)el.textContent=msg;
  }
  function nativeOnly(message){
    ready=false;playerReady=false;pendingId=null;
    const professional=document.getElementById('alphaTabNotation');
    const fallback=document.getElementById('nativeNotation');
    const edit=document.getElementById('editNotesDetails');
    professional?.classList.add('hidden');fallback?.classList.remove('hidden');edit?.classList.add('hidden');
    if(timer)clearTimeout(timer);timer=null;
    status(message||'Khuông nhạc SVG cơ bản (chưa cài alphaTab). Vẫn xem và chỉnh sửa được.');
    callback?.onMode?.(false);
  }
  function showProfessional(){
    ready=true;
    const professional=document.getElementById('alphaTabNotation');
    const fallback=document.getElementById('nativeNotation');
    const edit=document.getElementById('editNotesDetails');
    professional?.classList.remove('hidden');fallback?.classList.add('hidden');edit?.classList.remove('hidden');
    status('Khuông nhạc + TAB bằng alphaTab. Nhấn “Mở bảng TAB” bên dưới để sửa dây/ngăn.');
    callback?.onMode?.(true);
  }
  function applyStaves(){
    if(!api?.score)return;
    try {
      for(const track of api.score.tracks){
        for(const staff of track.staves){
          staff.showStandardNotation=mode!=='tabs';
          staff.showTablature=mode!=='score';
        }
      }
      api.settings.display.scale=zoom;
      api.updateSettings();
      const track=api.score.tracks[selectedTrack]||api.score.tracks[0];
      if(track)api.renderTracks([track]);
    }catch(e){ console.warn('alphaTab mode:',e);nativeOnly('Lỗi dựng alphaTab, đã chuyển về khuông nhạc SVG: '+e.message); }
  }
  function initialize(){
    if(api)return true;
    if(typeof root.alphaTab==='undefined')return false;
    try {
      const settings={
        core:{fontDirectory:'/static/alphatab/font/'},
        display:{scale:zoom},
        player:{enablePlayer:true,enableCursor:true,enableElementHighlighting:true,
          soundFont:'/static/alphatab/soundfont/sonivox.sf2'}
      };
      api=new root.alphaTab.AlphaTabApi(document.getElementById('alphaTabNotation'),settings);
      api.scoreLoaded.on(()=>{
        loadedId=pendingId;
        try{applyStaves()}catch(e){nativeOnly('Không thể hiển thị alphaTab: '+e.message)}
      });
      if(api.postRenderFinished?.on){api.postRenderFinished.on(()=>{
        if(loadedId && loadedId===pendingId){if(timer)clearTimeout(timer);showProfessional();}
      });}
      if(api.renderFinished?.on){api.renderFinished.on(()=>{
        if(loadedId && loadedId===pendingId){if(timer)clearTimeout(timer);showProfessional();}
      });}
      if(api.playerReady?.on){api.playerReady.on(()=>{
        playerReady=true;
        status('alphaTab đã sẵn sàng: hiển thị khuông nhạc và phát SoundFont đồng bộ với con trỏ.');
        callback?.onPlayerReady?.();
      });}
      if(api.playerPositionChanged?.on){api.playerPositionChanged.on(e=> callback?.onPosition?.(e));}
      if(api.playerFinished?.on){api.playerFinished.on(()=>callback?.onFinished?.());}
      if(api.error?.on){api.error.on(e=>{
        console.error('alphaTab error',e);
        nativeOnly('alphaTab gặp lỗi tải/render. Dùng khuông nhạc SVG cục bộ.');
      });}
      return true;
    }catch(err){console.warn('alphaTab init:',err);nativeOnly('Không thể khởi tạo alphaTab, dùng SVG: '+err.message);return false;}
  }
  function load(jobId,trackIndex,settings,events){
    callback=events||{};
    mode=settings.mode||'both';zoom=settings.zoom||1;
    selectedTrack=trackIndex||0;
    playerReady=false;ready=false;loadedId=null;
    if(!jobId){nativeOnly('Bản demo: khuông nhạc + TAB bằng SVG, nốt dùng để thử âm thanh.');return;}
    if(!initialize()){
      nativeOnly('Khuông nhạc SVG cơ bản. Chạy CAI_ALPHATAB.ps1 để sử dụng alphaTab đầy đủ.');
      return;
    }
    try{
      if(timer)clearTimeout(timer);
      pendingId=jobId;
      status('Đang nạp file GP5 vào alphaTab để dựng khuông nhạc và TAB...');
      const started=api.load(`/api/download/${encodeURIComponent(jobId)}/gp5`,[selectedTrack]);
      if(started===false)throw Error('alphaTab không chấp nhận file GP5.');
      timer=setTimeout(()=>{
        if(!ready)nativeOnly('alphaTab không phản hồi kịp, đã chuyển về khuông nhạc SVG.');
      },12000);
    }catch(e){nativeOnly('Không tải được bản nhạc trong alphaTab: '+e.message)}
  }
  function setTrack(trackIndex){selectedTrack=trackIndex;if(ready)applyStaves();}
  function setMode(nextMode){mode=nextMode;if(ready)applyStaves();}
  function setZoom(nextZoom){zoom=nextZoom;if(ready)applyStaves();}
  function stop(){try{api?.stop()}catch(e){}}
  function pause(){try{api?.pause()}catch(e){}}
  function play(){try{return !!api?.play()}catch(e){console.warn('alphaTab play:',e);return false}}
  function seek(progress){if(!api||!playerReady)return;
    const end=Number(api.endTick)||0;
    if(end>0)api.tickPosition=Math.round(Math.min(1,Math.max(0,progress))*end);
  }
  function speed(x){if(api && playerReady)api.playbackSpeed=Math.max(.25,Math.min(4,x));}
  function isReady(){return ready;}
  function canPlay(){return ready&&playerReady;}
  function time(){return api?{timeMs:Number(api.timePosition)||0,endMs:Number(api.endTime)||0}:null;}
  root.TunerAlpha={load,setTrack,setMode,setZoom,stop,pause,play,seek,speed,isReady,canPlay,time,nativeOnly};
})(window);
