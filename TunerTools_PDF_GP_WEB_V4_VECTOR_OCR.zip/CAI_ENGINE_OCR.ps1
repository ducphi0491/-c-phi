param()
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root
$Python=Join-Path $Root '.venv\Scripts\python.exe'
if(-not (Test-Path -LiteralPath $Python)) {
  Write-Host 'Loi: Chay CHAY_WEB.bat mot lan de tao moi truong Python truoc.' -ForegroundColor Red
  exit 1
}
Write-Host 'Cai thu vien OCR/OMR tuy chon (can Internet) ...' -ForegroundColor Cyan
& $Python -m pip install --disable-pip-version-check -r (Join-Path $Root 'requirements_ocr.txt')
if($LASTEXITCODE -ne 0) { Write-Host 'Loi cai OCR dependencies.' -ForegroundColor Red; exit 1 }
& $Python -c "import pdf_to_gp5"
if($LASTEXITCODE -eq 0) { Write-Host 'Da co engine OCR/OMR, khong can tai lai.' -ForegroundColor Green; exit 0 }
$Archive=Join-Path $Root '.pdf-to-gp5-v4.zip'
$EngineDir=Join-Path $Root '.pdf-to-gp5-source-v4'
$Manual=Join-Path $Root 'PDF-to-GP5-main.zip'
$ok=$false
if ((Test-Path -LiteralPath $Manual) -and (Get-Item -LiteralPath $Manual).Length -gt 1000) {
  Copy-Item -LiteralPath $Manual -Destination $Archive -Force
  $ok=$true
} else {
  $urls=@('https://codeload.github.com/F100Pilot/PDF-to-GP5/zip/refs/heads/main',
          'https://github.com/F100Pilot/PDF-to-GP5/archive/refs/heads/main.zip')
  foreach($url in $urls){
    try { Invoke-WebRequest -Uri $url -UseBasicParsing -OutFile $Archive -TimeoutSec 90
      if((Test-Path -LiteralPath $Archive) -and (Get-Item -LiteralPath $Archive).Length -gt 1000){$ok=$true;break}
    } catch { Write-Host ('Thu URL khac: '+$_.Exception.Message) -ForegroundColor Yellow }
  }
}
if(-not $ok){
  Write-Host 'Khong tai duoc engine. Co the tai GitHub ZIP thu cong vao file PDF-to-GP5-main.zip o thu muc nay.' -ForegroundColor Red
  exit 1
}
if(Test-Path -LiteralPath $EngineDir){Remove-Item -LiteralPath $EngineDir -Recurse -Force}
Expand-Archive -LiteralPath $Archive -DestinationPath $EngineDir -Force
$project=Get-ChildItem -LiteralPath $EngineDir -Directory | Where-Object {
  Test-Path -LiteralPath (Join-Path $_.FullName 'pyproject.toml')
} | Select-Object -First 1
if(-not $project){ Write-Host 'File engine khong dung cau truc.' -ForegroundColor Red; exit 1 }
& $Python -m pip install --disable-pip-version-check $project.FullName
if($LASTEXITCODE -ne 0){ Write-Host 'Loi cai engine.' -ForegroundColor Red; exit 1 }
& $Python -c "import pdf_to_gp5; from pdf_to_gp5.converter import ConversionOptions; print('OCR/OMR engine OK')"
if($LASTEXITCODE -ne 0){ Write-Host 'Loi import engine sau khi cai.' -ForegroundColor Red; exit 1 }
Write-Host 'OCR/OMR da san sang. Khoi dong lai CHAY_WEB.bat.' -ForegroundColor Green
