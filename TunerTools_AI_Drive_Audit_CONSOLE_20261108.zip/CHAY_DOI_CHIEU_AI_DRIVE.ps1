param(
    [string]$SourceDir = "C:\TunerTools\Audio\AI_Music",
    [string]$TokenFile = "",
    [string]$ReportDir = "C:\TunerTools\Audio\AI_Music\Reports\Drive_Audit"
)
$ErrorActionPreference = "Stop"
$pythonScript = Join-Path $PSScriptRoot 'DOI_CHIEU_AI_DRIVE.py'
if (-not (Test-Path -LiteralPath $pythonScript -PathType Leaf)) {
    throw "Missing script: $pythonScript"
}
$argsList = @($pythonScript, '--source', $SourceDir, '--report', $ReportDir)
if (-not [string]::IsNullOrWhiteSpace($TokenFile)) {
    $argsList += @('--token', $TokenFile)
}
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 @argsList
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python @argsList
} else {
    throw 'Python 3.10+ is not available in PATH.'
}
$exitCode = $LASTEXITCODE
if ($exitCode -eq 2) {
    Write-Warning 'Local source folders are missing; report created but counts are incomplete.'
} elseif ($exitCode -ne 0) {
    throw "Audit failed (exit code $exitCode)."
}
