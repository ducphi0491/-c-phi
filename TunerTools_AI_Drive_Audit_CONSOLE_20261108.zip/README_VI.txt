TunerTools AI Google Drive File Audit - REUPLOAD
==============================================
Cong cu chi doc, khong upload, xoa, ghi de file tren Google Drive.
Su dung token OAuth Google Drive hien co tren Windows Server.
Can Python 3.10+ (Python 3.11 OK), Windows PowerShell 5.1 OK.

Phan biet: so luong bai Android khong phai so luong file vat ly.
Audit quet:
 - C:\TunerTools\Audio\AI_Music\ZING_AUDIO: audio
 - C:\TunerTools\Audio\AI_Music\YOUTUBE_CACHE: audio va lyrics_*.json/meta_*.json
 - C:\TunerTools\Audio\AI_Music\ZING_JSON: lyrics
 - Google Drive My Drive/TunerTools_AppBackup/AI_Music/stream_cache
 - Google Drive My Drive/TunerTools_AppBackup/AI_Music/lyrics

SAU KHI GIAI NEN: Mo PowerShell tai thu muc chua 3 file script va chay:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\CHAY_VA_HIEN_KET_QUA.ps1

Hoac dung full path, vd:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_Audit\CHAY_VA_HIEN_KET_QUA.ps1"

Thu muc bao cao mac dinh:
C:\TunerTools\Audio\AI_Music\Reports\Drive_Audit\

Chuong trinh hien ket qua AUDIO va LYRICS ngay tren PowerShell:
LocalFiles, DriveFiles, SameNames, MissingOnDrive, OnlyOnDrive,
DifferentSize, DuplicateLocal, DuplicateDrive.
Va toi da 20 file thieu tren Drive cua moi nhom.

Néu da doi ten ZING_AUDIO thanh ZING_AUDIO2, phai doi lai
hoac su dung nguon co cau truc tuong duong de kiem tra day du.

Luu y:
- So sanh ten va kich thuoc file, khong kiem tra SHA-256 noi dung.
- Khong gui drive_token.json cho bat ky ai.
- Neu API bao loi, khong su dung bao cao cu lam ket qua hien tai.
