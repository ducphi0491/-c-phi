param(
    [string]$SourceDir = "C:\TunerTools\Audio\AI_Music",
    [string]$TokenFile = "",
    [string]$ReportDir = "C:\TunerTools\Audio\AI_Music\Reports\Drive_Audit",
    [int]$ShowFirst = 20
)
$ErrorActionPreference = 'Stop'
$base = Join-Path $PSScriptRoot 'CHAY_DOI_CHIEU_AI_DRIVE.ps1'
if (-not (Test-Path -LiteralPath $base -PathType Leaf)) {
    throw "Missing script: $base"
}
if ($ShowFirst -lt 0) { throw 'ShowFirst must be zero or greater' }
Write-Host '==== WINDOWS SERVER <-> GOOGLE DRIVE AI AUDIT ====' -ForegroundColor Cyan
& $base -SourceDir $SourceDir -TokenFile $TokenFile -ReportDir $ReportDir
$status = $LASTEXITCODE
if ($status -notin @(0, 2)) {
    throw "Audit failed with exit code $status. No stale report will be printed."
}
$summaryFile = Join-Path $ReportDir 'SUMMARY.json'
if (-not (Test-Path -LiteralPath $summaryFile -PathType Leaf)) {
    throw "Missing summary: $summaryFile"
}
$summary = Get-Content -LiteralPath $summaryFile -Raw -Encoding UTF8 | ConvertFrom-Json
Write-Host "`n========== SUMMARY FOR CHATGPT ==========" -ForegroundColor Cyan
Write-Host "AuditDateUTC : $($summary.date_utc)"
Write-Host "LocalRoot    : $($summary.local_root)"
Write-Host "DriveRoot    : $($summary.drive_root)"
foreach ($kind in @('audio', 'lyrics')) {
    $data = $summary.$kind
    Write-Host "`n==== $($kind.ToUpper()) ====" -ForegroundColor Yellow
    [PSCustomObject]@{
        LocalFiles      = $data.local_file_count
        DriveFiles      = $data.drive_file_count
        SameNames       = $data.same_filename
        MissingOnDrive  = $data.missing_on_drive
        OnlyOnDrive     = $data.only_on_drive
        DifferentSize   = $data.size_different
        DuplicateLocal = $data.duplicate_local_filenames
        DuplicateDrive = $data.duplicate_drive_filenames
        CaseDifference  = $data.case_only_difference
    } | Format-List | Out-Host
    $csv = Join-Path $ReportDir ($kind + '_missing_on_drive.csv')
    if ($ShowFirst -gt 0 -and (Test-Path -LiteralPath $csv -PathType Leaf)) {
        Write-Host "First $ShowFirst missing files on Drive:" -ForegroundColor Yellow
        $entries = @(Import-Csv -LiteralPath $csv -Encoding UTF8 | Select-Object -First $ShowFirst)
        if ($entries.Count -eq 0) { Write-Host '(none)' }
        foreach ($entry in $entries) { Write-Host ('- ' + $entry.filename) }
    }
}
Write-Host "`nLocalFoldersComplete : $($summary.local_folders_complete)"
if (-not $summary.local_folders_complete) {
    Write-Warning ('Missing local folders: ' + ($summary.local_scan.folders_missing -join '; '))
}
Write-Host "Reports: $ReportDir"
Write-Host 'Finished. Copy the SUMMARY FOR CHATGPT section to chat.' -ForegroundColor Green
