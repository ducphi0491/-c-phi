TUNERTOOLS - SUA GOOGLE ID TOKEN CHO DOCUMENTS DRIVE PRIMARY
=========================================================
Ngay dong goi: 2026-11-09

CO SO MA NGUON
- Dua tren 2 file Android/Gamefolder.kt va Android/admin.kt trong bo
  TunerTools_Documents_Drive_Primary_Admin_Gamefolder_FIX_20261108.zip.
- XML tt_documents_oauth.xml la file nguoi dung vua cung cap.
- Neu du an Android da sua them ke tu ban ZIP do, hay doi chieu va merge
  3 vung sua, khong ghi de cac thay doi moi cua ban.

NGUYEN NHAN CO THE GAY LOI
- XML them vao res/values chi duoc su dung khi build va cai APK moi.
- GoogleSignInAccount.idToken co the la token da cache tu Web Client cu.
- admin.kt chi co nut Thu lai; khong buoc Google signOut/login lai.
- Alwaysdata tra google_identity_not_verified khi tokeninfo nhan token,
  nhung it nhat mot truong aud/iss/email_verified/exp/sub khong hop le.
  Chua the ket luan 100% la aud khi chua do tren thiet bi.

FILE CAN THAY
1. Android/Gamefolder.kt
   - Kiem tra truong 'aud' tu JWT tren dien thoai TRUOC KHI GUI len server.
   - Chi chon token trung voi Web Client ID trong app; khong gui token cu.
   - Neu token khong dung audience, chuyen qua trang yeu cau login lai.
   - Khong dung JWT payload de cap quyen: ALWAYSdata van kiem tra chu ky
     va claims Google bang Google tokeninfo nhu truoc.
2. Android/admin.kt
   - Cho thay thong bao yeu cau dang nhap lai thay vi nuot loi.
   - Them nut 'Dang nhap lai Google' tai man hinh loi, co signOut thuc su.
   - Neu Google Sign-In fail, hien thi status code, vd 10 de tim loi SHA-1.
3. Android/tt_documents_oauth.xml
   - Dat tai app/src/main/res/values/tt_documents_oauth.xml
   - Neu resource ten tt_documents_web_client_id da ton tai, KHONG tao trung.

CAC BUOC CAI DAT
1. Sao luu Gamefolder.kt va admin.kt dang chay.
2. Thay 2 file Android vao dung vi tri cua chung trong du an.
3. Thay/sua tt_documents_oauth.xml trong app/src/main/res/values/.
4. Kiem tra cung Google Web Client ID dang duoc dung tai:
   /home/tuner/private/tt_documents_private.php
   Tuyet doi khong gui khoa bao mat hoac Google ID token cho nguoi khac.
5. Android Studio -> Build -> Rebuild Project -> cai BAN APK MOI.
6. Vao Admin -> Quyen tai lieu -> nhan 'Dang nhap lai Google'.
   Nhan Thu lai mot minh KHONG buoc Google tao ID token moi.
7. Thu doc danh sach quyen qua Drive; sau do thu tat IIS ngan han
   va mo tai lieu CHUA duoc luu cache.

RAT QUAN TRONG VE GOOGLE CLOUD
Neu Google Cloud project TunerTools-Drive chi co Desktop Uploader va
Web application, ban con can kiem tra client loai Android:
- Google Cloud Console -> Google Auth Platform -> Clients -> Create client.
- Application type: Android.
- Package name phai trung voi applicationId THUC TE cua app/build.gradle
  (khong chi dua vao package o dau file Kotlin).
- SHA-1: dung fingerprint cua keystore ky APK dang TEST.
  Debug APK: tai thu muc goc du an chay `.\\gradlew signingReport`.
  APK qua Play Store: dung SHA-1 App signing certificate trong Play Console.
- Android OAuth client va Web OAuth client phai thuoc du an Google Cloud
  phu hop voi dang nhap Google cua TunerTools.
- Chi truyen WEB Client ID vao requestIdToken; khong dung Android Client ID.

NEU VAN LOI
- 'Google chua cap ID token' hoac Google Sign-In ma 10: check Android
  OAuth client voi package/SHA-1 cua dung APK.
- 'ID token cua Web Client ID cu': nhan Dang nhap lai Google, cai APK moi,
  kiem tra XML va Web Client ID trong GoogleSignInOptions.
- 'google_identity_not_verified' DUNG Y HET sau khi audience tren Android
  da khop: so sanh Web Client ID trong private PHP va XML, sau do can
  chan doan cac claim Google ben PHP. Khong duoc bo qua buoc kiem tra token.
- Khong can chay lai IIS_Patch, khong can tao/upload lai JSON 93 tai khoan.

KIEM TRA DA THUC HIEN
- XML phan tich thanh cong.
- Test tinh huong JWT aud dung/sai/malformed cho helper Kotlin: DAT.
- Kiem tra thay doi Kotlin trong pham vi cac ham dang nhap + UI: DAT.
- CHUA build APK (khong co full Android project/Android SDK) va chua
  test OAuth thuc su tren thiet bi/Alwaysdata.
