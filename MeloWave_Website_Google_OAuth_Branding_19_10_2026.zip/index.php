<?php
declare(strict_types=1);
require_once __DIR__ . '/site-common.php';
mw_header(
    'home',
    'Ứng dụng nghe nhạc MeloWave',
    'MeloWave Music Player',
    'MeloWave giúp bạn nghe nhạc trên điện thoại, duyệt các tệp âm thanh Google Drive được cấp quyền, quản lý danh sách phát và điều chỉnh âm thanh.',
    'MeloWave lets you play music stored on your phone, access authorized Google Drive audio files, manage playlists, and fine-tune your listening experience.'
);
?>
<section class="hero" aria-labelledby="hero-heading">
  <div>
    <p class="eyebrow"><?= mw_t('Trình phát âm nhạc MeloWave', 'Meet MeloWave Music Player') ?></p>
    <h1 id="hero-heading"><?= mw_t('Âm nhạc của bạn.', 'Your music.') ?><br><span class="gradient-text"><?= mw_t('Một nơi để tận hưởng.', 'One place to enjoy it.') ?></span></h1>
    <p class="lead"><?= mw_t(
        'Nghe các bài hát trên điện thoại, kết nối những tệp âm thanh trong Google Drive mà bạn cho phép, tạo danh sách phát và tùy chỉnh âm thanh theo sở thích — tất cả trong giao diện MeloWave.',
        'Listen to music on your phone, connect to Google Drive audio files you authorize, build playlists and personalize your sound — all in the MeloWave interface.'
    ) ?></p>
    <div class="hero-cta">
      <a class="button button-primary" href="#features"><?= mw_t('Khám phá MeloWave →', 'Explore features →') ?></a>
      <a class="button button-secondary" href="<?= mw_e(mw_page('privacy-policy.php')) ?>"><?= mw_t('Cam kết quyền riêng tư', 'Privacy Policy') ?></a>
    </div>
  </div>
  <div class="player-preview" aria-label="<?= mw_t('Minh họa giao diện trình phát MeloWave', 'Illustration of the MeloWave audio player') ?>">
    <div class="preview-top"><span>MELOWAVE PLAYER</span><span class="preview-pip"><i></i><?= mw_t('Đang phát', 'Now playing') ?></span></div>
    <div class="preview-cover" aria-hidden="true">
      <svg viewBox="0 0 180 180" xmlns="http://www.w3.org/2000/svg">
        <defs><linearGradient id="preview-gradient" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#8ce4ff"/><stop offset=".56" stop-color="#d896ff"/><stop offset="1" stop-color="#fff"/></linearGradient></defs>
        <path d="M35 112V68 M58 133V48 M81 100V80 M104 140V40 M127 117V62 M150 105V75" stroke="url(#preview-gradient)" stroke-width="12" stroke-linecap="round"/>
      </svg>
    </div>
    <div class="preview-song"><?= mw_t('Giai điệu yêu thích', 'Your favorite sounds') ?></div>
    <div class="preview-sub"><?= mw_t('Bộ sưu tập của bạn', 'Your music collection') ?></div>
    <div class="preview-line" aria-hidden="true"></div>
    <div class="preview-actions" aria-hidden="true"><span>⤨</span><span>◀◀</span><span class="play-circle">▶</span><span>▶▶</span><span>↻</span></div>
  </div>
</section>
<div class="trust-strip" aria-label="<?= mw_t('Điểm nổi bật', 'Highlights') ?>">
  <div class="trust-item"><?= mw_t('Trình phát nhạc trên Android', 'Android music playback') ?></div>
  <div class="trust-item"><?= mw_t('Kết nối Google Drive theo quyền được cấp', 'Authorized Google Drive access') ?></div>
  <div class="trust-item"><?= mw_t('Bạn chủ động kiểm soát tệp nhạc', 'You control your audio files') ?></div>
</div>
<section id="features" class="section" aria-labelledby="features-heading">
  <p class="section-kicker"><?= mw_t('TÍNH NĂNG', 'FEATURES') ?></p>
  <h2 id="features-heading"><?= mw_t('Thư viện nhạc của bạn, theo cách của bạn', 'Your music library, your way') ?></h2>
  <p class="section-intro"><?= mw_t('MeloWave hỗ trợ các nguồn nhạc và công cụ thường dùng trong một ứng dụng, giúp bạn tập trung vào trải nghiệm nghe.', 'MeloWave brings your music sources and listening tools into one app.') ?></p>
  <div class="feature-grid">
    <article class="feature-card"><div class="feature-icon" aria-hidden="true">♫</div><h3><?= mw_t('Nhạc trên điện thoại', 'Music on your phone') ?></h3><p><?= mw_t('Xem, tìm và phát những tệp âm thanh được phép truy cập trên thiết bị Android.', 'Browse, search and play audio files you allow MeloWave to access on your Android device.') ?></p></article>
    <article class="feature-card"><div class="feature-icon" aria-hidden="true">☁</div><h3><?= mw_t('Google Drive', 'Google Drive') ?></h3><p><?= mw_t('Kết nối tài khoản Google theo sự đồng ý của bạn; phát những tệp âm thanh mà bạn có quyền truy cập và đã cấp cho ứng dụng.', 'Connect your Google account with your consent and play audio files that you can access and have authorized for the app.') ?></p></article>
    <article class="feature-card"><div class="feature-icon" aria-hidden="true">▤</div><h3><?= mw_t('Thư viện & danh sách phát', 'Library & playlists') ?></h3><p><?= mw_t('Sắp xếp bài hát, lưu danh sách yêu thích và chọn nhiều bài để phát nối tiếp.', 'Organize tracks, save favorites and play your selected songs in sequence.') ?></p></article>
    <article class="feature-card"><div class="feature-icon" aria-hidden="true">≋</div><h3><?= mw_t('Điều chỉnh âm thanh', 'Sound controls') ?></h3><p><?= mw_t('Tùy chỉnh Equalizer, âm lượng MeloWave và các chế độ tăng cường âm thanh theo thiết bị hỗ trợ.', 'Adjust the equalizer, MeloWave volume and sound enhancements on supported devices.') ?></p></article>
    <article class="feature-card"><div class="feature-icon" aria-hidden="true">⇄</div><h3><?= mw_t('Kết nối thiết bị', 'Device connections') ?></h3><p><?= mw_t('Các tính năng kết nối hoặc truyền file giữa thiết bị chỉ hoạt động khi bạn chủ động sử dụng.', 'Connection and file-transfer features operate when you choose to use them.') ?></p></article>
    <article class="feature-card"><div class="feature-icon" aria-hidden="true">◈</div><h3><?= mw_t('Quyền riêng tư', 'Privacy first') ?></h3><p><?= mw_t('MeloWave chỉ yêu cầu quyền cần cho tính năng bạn chọn. Bạn có thể thu hồi quyền Google trong cài đặt tài khoản.', 'MeloWave requests permissions needed for the features you choose. You can revoke Google access in your account settings.') ?></p></article>
  </div>
</section>
<section id="google-drive" class="section" aria-labelledby="drive-heading">
  <p class="section-kicker">GOOGLE DRIVE</p>
  <h2 id="drive-heading"><?= mw_t('Kết nối minh bạch, do bạn quyết định', 'Connected with your permission') ?></h2>
  <p class="section-intro"><?= mw_t('MeloWave không cần mật khẩu Google của bạn. Khi bạn chọn kết nối Drive, quyền được xử lý thông qua màn hình xác thực chính thức của Google.', 'MeloWave never needs your Google password. When you connect Drive, access is granted through Google’s official authorization flow.') ?></p>
  <div class="steps">
    <article class="step"><span class="step-num">01</span><h3><?= mw_t('Bạn chọn kết nối', 'You choose to connect') ?></h3><p><?= mw_t('Nhấn Google Drive trong MeloWave và đăng nhập hoặc đồng ý cấp quyền khi Google yêu cầu.', 'Open Google Drive in MeloWave and sign in or grant access when requested by Google.') ?></p></article>
    <article class="step"><span class="step-num">02</span><h3><?= mw_t('Ứng dụng đọc tệp được cấp quyền', 'Authorized files are listed') ?></h3><p><?= mw_t('MeloWave đọc thông tin thư mục và file âm thanh trong phạm vi được Google cho phép.', 'MeloWave lists folders and audio files within the access permitted by Google.') ?></p></article>
    <article class="step"><span class="step-num">03</span><h3><?= mw_t('Bạn nghe và quản lý nhạc', 'Play and manage music') ?></h3><p><?= mw_t('Chọn bài hát, phát và quản lý chúng bằng giao diện MeloWave. Có thể có bộ nhớ đệm tạm trên thiết bị.', 'Play and manage selected songs inside MeloWave. Temporary audio files may be cached on your device.') ?></p></article>
  </div>
  <p class="info-note"><?= mw_t('Thông tin quan trọng: MeloWave không tự động có quyền với toàn bộ Drive riêng tư. Các tệp mới hoặc quyền đã thu hồi có thể cần bạn xác nhận thêm theo quy định của Google.', 'Important: MeloWave does not automatically gain access to your entire private Drive. New files or revoked permissions may require additional authorization.') ?></p>
</section>
<section class="callout" aria-label="<?= mw_t('Thông tin pháp lý', 'Legal information') ?>">
  <div>
    <p class="section-kicker"><?= mw_t('MINH BẠCH', 'TRANSPARENCY') ?></p>
    <h2><?= mw_t('Kiểm soát dữ liệu của bạn', 'You stay in control of your data') ?></h2>
    <p><?= mw_t('Tìm hiểu MeloWave truy cập, sử dụng, lưu trữ và chia sẻ thông tin như thế nào trước khi liên kết Google Drive.', 'Learn exactly how MeloWave accesses, uses, stores and shares information before connecting your Google Drive.') ?></p>
  </div>
  <a class="button button-primary" href="<?= mw_e(mw_page('privacy-policy.php')) ?>"><?= mw_t('Đọc chính sách →', 'Read privacy policy →') ?></a>
</section>
<?php mw_footer(); ?>
