<?php
declare(strict_types=1);
require_once __DIR__ . '/site-common.php';
mw_header(
    'privacy',
    'Chính sách quyền riêng tư',
    'Privacy Policy',
    'Tìm hiểu MeloWave truy cập, sử dụng, lưu trữ và chia sẻ dữ liệu như thế nào, bao gồm dữ liệu Google Drive và thông tin liên quan đến Premium.',
    'Learn how MeloWave accesses, uses, stores and shares data, including Google Drive information and Premium-related data.'
);
?>
<header class="legal-head">
  <p class="eyebrow"><?= mw_t('MINH BẠCH & QUYỀN RIÊNG TƯ', 'TRANSPARENCY & PRIVACY') ?></p>
  <h1><?= mw_t('Chính sách ', 'Privacy ') ?><span class="gradient-text"><?= mw_t('quyền riêng tư', 'Policy') ?></span></h1>
  <p class="lead"><?= mw_t(
      'MeloWave tôn trọng quyền kiểm soát dữ liệu cá nhân của bạn. Chính sách này giải thích các quyền chúng tôi yêu cầu, những thông tin được xử lý và cách bạn có thể ngừng chia sẻ hoặc yêu cầu xóa dữ liệu.',
      'MeloWave respects your control over personal information. This policy describes the permissions we request, how information is processed, and how you can revoke access or request deletion.'
  ) ?></p>
  <p class="date-line"><?= mw_t('Ngày có hiệu lực / cập nhật: ' . MW_UPDATED_VI, 'Effective / last updated: ' . MW_UPDATED_EN) ?></p>
</header>
<div class="legal-grid">
  <aside class="toc" aria-label="<?= mw_t('Mục lục chính sách', 'Policy table of contents') ?>">
    <h2><?= mw_t('Nội dung', 'On this page') ?></h2>
    <div class="toc-links">
      <a href="#scope"><?= mw_t('1. Phạm vi áp dụng', '1. Scope') ?></a>
      <a href="#drive"><?= mw_t('2. Dữ liệu Google Drive', '2. Google Drive data') ?></a>
      <a href="#data"><?= mw_t('3. Thông tin khác', '3. Other information') ?></a>
      <a href="#use"><?= mw_t('4. Mục đích & chia sẻ', '4. Purposes & sharing') ?></a>
      <a href="#retention"><?= mw_t('5. Lưu trữ & thời hạn', '5. Storage & retention') ?></a>
      <a href="#third-parties"><?= mw_t('6. Dịch vụ bên thứ ba', '6. Third parties') ?></a>
      <a href="#security"><?= mw_t('7. Bảo mật', '7. Security') ?></a>
      <a href="#controls"><?= mw_t('8. Quyền của bạn', '8. Your choices') ?></a>
      <a href="#changes"><?= mw_t('9. Thay đổi chính sách', '9. Changes') ?></a>
      <a href="#contact"><?= mw_t('10. Liên hệ', '10. Contact') ?></a>
    </div>
  </aside>
  <article class="legal-paper">
    <section id="scope" class="legal-section">
      <h2><?= mw_t('1. Phạm vi áp dụng', '1. Scope') ?></h2>
      <p><?= mw_t(
          'Chính sách này áp dụng cho ứng dụng Android MeloWave (tên ứng dụng hiển thị: “MeloWave”, mã gói Android: duc_phi.music) và các trang hỗ trợ MeloWave trên tên miền tunertools.top. Người dùng có thể nghe nhạc trong bộ nhớ thiết bị mà không cần kết nối tài khoản Google Drive; các tính năng liên quan đến tài khoản hoặc Drive chỉ được kích hoạt khi bạn lựa chọn.',
          'This policy applies to the MeloWave Android application (display name: “MeloWave”, Android package: duc_phi.music) and the MeloWave support pages on tunertools.top. You can listen to music stored on your device without connecting Google Drive; account- or Drive-related features operate when you choose to use them.'
      ) ?></p>
      <p><?= mw_t('MeloWave là một ứng dụng độc lập, không phải sản phẩm được Google sở hữu hoặc tài trợ.', 'MeloWave is an independent application and is not owned or sponsored by Google.') ?></p>
    </section>

    <section id="drive" class="legal-section">
      <h2><?= mw_t('2. Truy cập và sử dụng dữ liệu Google Drive', '2. Access to and use of Google Drive data') ?></h2>
      <h3><?= mw_t('Cách cấp quyền', 'How authorization works') ?></h3>
      <p><?= mw_t(
          'Khi bạn kết nối Drive cá nhân, MeloWave sử dụng cơ chế đăng nhập và cấp quyền chính thức của Google (OAuth). Ứng dụng hiện yêu cầu phạm vi drive.file, dành cho các tệp Google Drive mà bạn chủ động chọn, mở hoặc cấp quyền cho ứng dụng. MeloWave không biết mật khẩu Google của bạn và không mặc nhiên được đọc mọi tài liệu riêng tư trong tài khoản.',
          'When you connect your personal Drive, MeloWave uses Google’s official sign-in and OAuth authorization process. The app currently requests the drive.file scope, covering Google Drive files you explicitly select, open or authorize for the app. MeloWave does not know your Google password or automatically gain access to all private documents in your account.'
      ) ?></p>
      <h3><?= mw_t('Những thông tin được truy cập', 'Data accessed') ?></h3>
      <ul>
        <li><?= mw_t('Thông tin nhận dạng tệp/thư mục như File ID, tên, loại MIME, dung lượng, thư mục chứa và thông tin cần thiết để liệt kê hoặc phát tệp được cấp quyền.', 'File and folder metadata such as file IDs, names, MIME types, sizes, parent folders and details required to list or play authorized files.') ?></li>
        <li><?= mw_t('Nội dung của tệp âm thanh bạn chọn phát, nhằm tạo luồng phát hoặc bản đệm tạm trong bộ nhớ ứng dụng trên thiết bị.', 'The contents of audio files you choose to play, for playback or temporary caching within the app on your device.') ?></li>
        <li><?= mw_t('Thông tin cần thiết để duy trì phiên được Google cấp quyền, được quản lý thông qua cơ chế xác thực của Google trên thiết bị.', 'Information needed to maintain Google-granted authorization, managed through Google’s authentication mechanisms on the device.') ?></li>
      </ul>
      <h3><?= mw_t('Giới hạn mục đích', 'Purpose limitation') ?></h3>
      <p><?= mw_t(
          'Dữ liệu từ Google Drive chỉ được sử dụng để thực hiện những chức năng hiển thị rõ cho người dùng, bao gồm duyệt file âm thanh, phát nhạc, tìm kiếm trong thư viện đã cấp quyền, lưu danh sách phát và tạo bộ nhớ đệm cục bộ. Trong luồng phát nhạc Drive hiện tại, MeloWave không tự động gửi nội dung tệp Drive tới máy chủ MeloWave để lưu trữ hoặc phân phối. Nếu bạn chủ động sử dụng tính năng truyền file giữa thiết bị, dữ liệu bạn chọn có thể được chuyển tới thiết bị nhận.',
          'Google Drive information is used only for user-facing features, including browsing authorized audio, playback, searching authorized music, saving playlists and maintaining a local playback cache. In the current Drive playback flow, MeloWave does not automatically upload Drive file contents to MeloWave servers for hosting or distribution. If you actively use a device-to-device transfer feature, the content you select may be sent to the receiving device.'
      ) ?></p>
      <p class="info-note"><?= mw_t('Đối với các liên kết Drive công khai, MeloWave có thể truy cập thông tin được chia sẻ công khai bằng Google Drive API. Liên kết công khai không đồng nghĩa ứng dụng được quyền truy cập những nội dung riêng tư khác của tài khoản.', 'For public Drive links, MeloWave may access publicly shared information through the Google Drive API. A public link does not grant access to other private information in the account.') ?></p>
    </section>

    <section id="data" class="legal-section">
      <h2><?= mw_t('3. Những loại thông tin khác được xử lý', '3. Other categories of information processed') ?></h2>
      <ul>
        <li><strong><?= mw_t('Nhạc trên thiết bị:', 'On-device music:') ?></strong> <?= mw_t('khi bạn cấp quyền Android, MeloWave đọc thông tin và nội dung tệp âm thanh để hiển thị/phát trên thiết bị. Thư viện, lịch sử, danh sách phát, thiết lập âm thanh và liên kết Drive gần đây có thể được lưu cục bộ.', 'with Android permission, MeloWave reads audio metadata and files for display/playback. Library entries, history, playlists, sound settings and recent Drive links may be saved locally.') ?></li>
        <li><strong><?= mw_t('Thông tin đăng nhập:', 'Sign-in information:') ?></strong> <?= mw_t('nếu bạn chọn đăng nhập Google, ứng dụng có thể nhận tên hiển thị, địa chỉ email, ảnh hồ sơ và định danh tài khoản theo quyền được cấp.', 'if you choose Google sign-in, the app may receive your display name, email address, profile image and account identifier as authorized.') ?></li>
        <li><strong><?= mw_t('Premium và dùng thử:', 'Premium and trials:') ?></strong> <?= mw_t('thông tin định danh tài khoản đã xác minh, mã biên nhận/token giao dịch Google Play, trạng thái quyền lợi, thời điểm hiệu lực và định danh thiết bị Android để kiểm soát việc dùng thử có thể được xử lý bởi ứng dụng và máy chủ MeloWave.', 'verified account identifiers, Google Play purchase tokens/receipts, entitlement status, validity dates and an Android device identifier used for trial eligibility may be processed by the app and MeloWave backend.') ?></li>
        <li><strong><?= mw_t('Kết nối giữa thiết bị:', 'Device connectivity:') ?></strong> <?= mw_t('khi bạn dùng tính năng kết nối, dữ liệu thiết lập kết nối (ví dụ mã ghép nối, thông tin tín hiệu mạng) có thể được xử lý bằng Firebase và các giao thức kết nối. Việc chuyển file thực tế phụ thuộc thao tác của bạn.', 'when you use device pairing, connection setup information (such as pairing codes and network signaling) may be processed through Firebase and connectivity protocols. Actual file transfer depends on your actions.') ?></li>
        <li><strong><?= mw_t('Microphone và mạng:', 'Microphone and network:') ?></strong> <?= mw_t('một số tính năng âm thanh có thể yêu cầu microphone hoặc quyền truy cập mạng. Quyền được quản lý trong phần Cài đặt của Android.', 'some audio tools may require microphone or network access. You can manage these permissions through Android Settings.') ?></li>
        <li><strong><?= mw_t('Dữ liệu kỹ thuật và quảng cáo:', 'Technical and advertising data:') ?></strong> <?= mw_t('các SDK tích hợp có thể xử lý thông tin thiết bị, mã quảng cáo (nếu có), chẩn đoán lỗi và sự kiện liên quan đến việc cung cấp dịch vụ.', 'integrated SDKs may process device information, an advertising ID (when available), diagnostics and service-related events.') ?></li>
      </ul>
    </section>

    <section id="use" class="legal-section">
      <h2><?= mw_t('4. Mục đích sử dụng và chia sẻ dữ liệu', '4. How data is used and shared') ?></h2>
      <p><?= mw_t('MeloWave xử lý dữ liệu trong phạm vi cần thiết để phát nhạc, đồng bộ trạng thái giao diện, duy trì những tính năng bạn chọn, xác minh quyền Premium, phòng chống gian lận và hỗ trợ kỹ thuật. Chúng tôi không sử dụng nội dung tệp Google Drive để nhắm mục tiêu quảng cáo, bán dữ liệu Drive, hoặc huấn luyện mô hình AI.', 'MeloWave processes information as needed to enable playback, maintain user-selected features, verify Premium entitlements, prevent abuse and provide support. We do not use the contents of your Google Drive files for ad targeting, sell Drive data or train AI models on them.') ?></p>
      <p><?= mw_t('Dữ liệu có thể được chia sẻ với đơn vị cung cấp hạ tầng/dịch vụ khi cần để thực hiện chức năng liên quan (ví dụ Google Drive, Google Play, Firebase hoặc dịch vụ quảng cáo), theo các điều khoản và chính sách riêng của họ. Nội dung các file Drive riêng tư không được cố ý chuyển tới đơn vị quảng cáo.', 'Information may be processed by infrastructure or service providers where needed for the related feature (such as Google Drive, Google Play, Firebase or advertising services), subject to their terms and policies. Private Drive file contents are not intentionally provided to advertising providers.') ?></p>
      <div class="policy-statement"><p><strong><?= mw_t('Cam kết Google API Services – Limited Use:', 'Google API Services – Limited Use:') ?></strong> <?= mw_t(
          'Việc MeloWave sử dụng và chuyển giao thông tin nhận được từ Google APIs sang ứng dụng khác sẽ tuân thủ Chính sách dữ liệu người dùng của Google API Services, bao gồm các yêu cầu Limited Use. Dữ liệu này chỉ phục vụ các chức năng hiển thị cho người dùng và không được sử dụng vào những mục đích không được phép.',
          "MeloWave's use and transfer to any other app of information received from Google APIs will adhere to the Google API Services User Data Policy, including the Limited Use requirements. Such data is used for visible user-facing features, not for prohibited secondary purposes."
      ) ?> <a href="https://developers.google.com/terms/api-services-user-data-policy" target="_blank" rel="noopener noreferrer"><?= mw_t('Xem chính sách Google', 'Google policy') ?></a>.</p></div>
      <p><?= mw_t('Chúng tôi không cung cấp dữ liệu Google Drive cho bên thứ ba để quảng cáo cá nhân hóa hoặc bán dữ liệu đó. Người dùng luôn quyết định việc cấp quyền và chia sẻ file qua các chức năng chủ động của ứng dụng.', 'We do not provide Google Drive data to third parties for personalized advertising or sell that data. Users remain responsible for granting access and for user-initiated file sharing.') ?></p>
    </section>

    <section id="retention" class="legal-section">
      <h2><?= mw_t('5. Lưu trữ, thời hạn lưu và xóa dữ liệu', '5. Storage, retention and deletion') ?></h2>
      <ul>
        <li><?= mw_t('Thông tin thư viện, danh sách phát, đường dẫn Drive và file nhạc đệm có thể tồn tại trong bộ nhớ ứng dụng cho đến khi bạn xóa chúng, xóa dữ liệu ứng dụng hoặc gỡ ứng dụng. Việc thu hồi OAuth không nhất thiết tự xóa các tệp đã đệm trên thiết bị.', 'Library metadata, playlists, Drive links and cached audio may remain in app storage until you remove them, clear app data or uninstall the app. Revoking OAuth access does not necessarily remove audio already cached on your device.') ?></li>
        <li><?= mw_t('Thông tin dùng thử, đối soát giao dịch hoặc quyền Premium có thể được lưu trên máy chủ MeloWave khi cần để vận hành dịch vụ và đáp ứng nghĩa vụ pháp lý liên quan.', 'Trial, purchase-verification and Premium entitlement records may be retained on MeloWave servers as needed to operate the service and meet applicable legal obligations.') ?></li>
        <li><?= mw_t('Một số bản ghi kỹ thuật của máy chủ có thể bao gồm thời điểm truy cập, địa chỉ IP hoặc thông tin trình duyệt/thiết bị phục vụ vận hành và an toàn hệ thống.', 'Technical server logs may include access times, IP addresses or browser/device data for operation and security.') ?></li>
      </ul>
      <p><?= mw_t('Các trang thông tin công khai này không yêu cầu đăng nhập, không đặt cookie theo dõi riêng và không nhúng mã quảng cáo.', 'These public information pages do not require sign-in, set their own tracking cookies or embed advertising scripts.') ?></p>
    </section>

    <section id="third-parties" class="legal-section">
      <h2><?= mw_t('6. Dịch vụ bên thứ ba', '6. Third-party services') ?></h2>
      <p><?= mw_t('Tùy chức năng bạn sử dụng, MeloWave có thể kết nối với các dịch vụ sau. Mỗi nhà cung cấp có chính sách quyền riêng tư riêng:', 'Depending on the features you use, MeloWave may interact with these services. Each provider has its own privacy policy:') ?></p>
      <ul>
        <li><strong>Google Drive / Google OAuth:</strong> <?= mw_t('cấp quyền và truy xuất các tệp được phép.', 'authorization and access to permitted files.') ?></li>
        <li><strong>Google Play:</strong> <?= mw_t('phân phối ứng dụng, cập nhật và thanh toán Premium.', 'app distribution, updates and Premium billing.') ?></li>
        <li><strong>Google AdMob:</strong> <?= mw_t('hiển thị quảng cáo và xử lý các thông tin kỹ thuật/quảng cáo theo thiết lập và chính sách liên quan; không sử dụng nội dung file Drive để nhắm mục tiêu quảng cáo.', 'advertising and related technical/ad data as described by Google; private Drive file content is not used for ad targeting.') ?></li>
        <li><strong>Google Firebase:</strong> <?= mw_t('xác thực ẩn danh và truyền tín hiệu phục vụ kết nối thiết bị trong tính năng liên quan.', 'anonymous authentication and connection signaling for relevant device-link features.') ?></li>
        <li><strong><?= mw_t('Nhà cung cấp nội dung trực tuyến:', 'Online content providers:') ?></strong> <?= mw_t('một số chức năng tùy chọn có thể kết nối tới nguồn tìm kiếm/preview nhạc hoặc lời bài hát bên ngoài.', 'optional features may contact external music-search, preview or lyrics providers.') ?></li>
      </ul>
      <p><?= mw_t('Bạn có thể xem chính sách dữ liệu của Google tại', 'You can review Google’s privacy policy at') ?> <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">policies.google.com/privacy</a>.</p>
    </section>

    <section id="security" class="legal-section">
      <h2><?= mw_t('7. Bảo mật và giới hạn', '7. Security and limitations') ?></h2>
      <p><?= mw_t('Các yêu cầu đến Google Drive và các API trực tuyến liên quan sử dụng các kết nối HTTPS trong luồng được hỗ trợ. MeloWave không yêu cầu bạn gửi mật khẩu Google cho chúng tôi. Việc truyền file giữa thiết bị trong mạng cục bộ phụ thuộc phương thức kết nối đã chọn và có thể hoạt động trên mạng nội bộ.', 'Requests to Google Drive and supported online APIs use HTTPS connections. MeloWave does not ask you to provide your Google password to us. Local device-to-device transfers depend on the connection method selected and may operate over a local network.') ?></p>
      <p><?= mw_t('Không hệ thống nào có thể bảo đảm an toàn tuyệt đối. Bạn nên bảo vệ thiết bị, không chia sẻ liên kết riêng tư bừa bãi và thu hồi các quyền không còn sử dụng.', 'No system can guarantee absolute security. Keep your device secure, avoid oversharing private links and revoke access that you no longer need.') ?></p>
    </section>

    <section id="controls" class="legal-section">
      <h2><?= mw_t('8. Quyền kiểm soát của bạn', '8. Your choices and controls') ?></h2>
      <h3><?= mw_t('Ngắt kết nối Google Drive', 'Disconnect Google Drive') ?></h3>
      <p><?= mw_t('Bạn có thể ngắt kết nối tài khoản trong ứng dụng nếu chức năng có sẵn, hoặc vào phần “Ứng dụng và dịch vụ bên thứ ba” của Tài khoản Google để thu hồi quyền truy cập của MeloWave.', 'You may disconnect within the app where supported, or revoke MeloWave access in your Google Account’s third-party app and service settings.') ?> <a href="https://myaccount.google.com/connections" target="_blank" rel="noopener noreferrer"><?= mw_t('Mở cài đặt Google', 'Open Google account settings') ?></a>.</p>
      <h3><?= mw_t('Xóa dữ liệu trên thiết bị', 'Remove locally stored data') ?></h3>
      <p><?= mw_t('Bạn có thể xóa tệp nhạc đã lưu tạm hoặc dùng Cài đặt Android → Ứng dụng → MeloWave → Bộ nhớ → Xóa dữ liệu. Thao tác này có thể làm mất thư viện và cài đặt đã lưu trên thiết bị. Việc gỡ ứng dụng thường xóa dữ liệu ứng dụng cục bộ, tùy cơ chế sao lưu của Android.', 'You can remove cached audio where supported, or use Android Settings → Apps → MeloWave → Storage → Clear data. This can erase local library information and preferences. Uninstalling generally deletes local app data, subject to Android backup behavior.') ?></p>
      <h3><?= mw_t('Yêu cầu truy cập, chỉnh sửa hoặc xóa bản ghi máy chủ', 'Request access, correction or deletion of server records') ?></h3>
      <p><?= mw_t('Gửi email yêu cầu đến địa chỉ hỗ trợ bên dưới, ghi rõ yêu cầu của bạn (ví dụ “Yêu cầu xóa dữ liệu MeloWave”). Chúng tôi có thể cần xác minh quyền sở hữu tài khoản trước khi xử lý. Một số thông tin giao dịch có thể phải được giữ lại theo quy định pháp luật.', 'Email the support address below with your request (for example, “MeloWave data deletion request”). We may need to verify account ownership before acting. Certain transaction records may need to be retained as required by law.') ?></p>
      <div class="support-card"><div><strong><?= mw_t('Yêu cầu về dữ liệu cá nhân', 'Personal data requests') ?></strong><small><?= mw_e(MW_SUPPORT_EMAIL) ?></small></div><a class="button button-secondary" href="<?= mw_e(mw_contact('MeloWave - Yeu cau xoa du lieu')) ?>"><?= mw_t('Gửi yêu cầu', 'Send a request') ?> →</a></div>
    </section>

    <section id="changes" class="legal-section">
      <h2><?= mw_t('9. Thay đổi chính sách', '9. Updates to this policy') ?></h2>
      <p><?= mw_t('Chính sách có thể được cập nhật khi MeloWave thay đổi tính năng, phạm vi Google API hoặc cách xử lý dữ liệu. Ngày cập nhật sẽ được công bố trên trang này. Nếu thay đổi liên quan đến mục đích sử dụng dữ liệu Google đã cấp quyền, MeloWave sẽ thông báo và xin sự đồng ý bổ sung khi cần thiết.', 'We may update this policy when MeloWave changes its features, Google API scopes or data practices. The latest revision date will appear here. Material changes to the purposes for which authorized Google data is used will be disclosed, and additional consent will be sought where required.') ?></p>
    </section>

    <section id="contact" class="legal-section">
      <h2><?= mw_t('10. Liên hệ', '10. Contact us') ?></h2>
      <p><?= mw_t('Đối với câu hỏi về quyền riêng tư, Google Drive, quyền tài khoản, dữ liệu đã lưu hoặc yêu cầu hỗ trợ:', 'For privacy, Google Drive access, account, stored-data or support questions, contact:') ?></p>
      <div class="support-card"><div><strong>MeloWave Support</strong><small><?= mw_e(MW_SUPPORT_EMAIL) ?></small></div><a class="button button-primary" href="<?= mw_e(mw_contact('MeloWave - Privacy')) ?>"><?= mw_t('Liên hệ qua email', 'Email support') ?> →</a></div>
    </section>
  </article>
</div>
<div class="notice-strip"><?= mw_t('Bạn cũng có thể xem', 'You may also review') ?> <a href="<?= mw_e(mw_page('terms-of-service.php')) ?>"><?= mw_t('Điều khoản sử dụng MeloWave', 'MeloWave Terms of Service') ?></a> <?= mw_t('để tìm hiểu quyền và trách nhiệm khi sử dụng ứng dụng.', 'for the rights and responsibilities associated with using the application.') ?></div>
<?php mw_footer(); ?>
