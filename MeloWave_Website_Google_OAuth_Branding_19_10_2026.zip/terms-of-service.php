<?php
declare(strict_types=1);
require_once __DIR__ . '/site-common.php';
mw_header(
    'terms',
    'Điều khoản sử dụng',
    'Terms of Service',
    'Điều khoản sử dụng ứng dụng nghe nhạc MeloWave, Google Drive, kết nối giữa thiết bị, Premium và nội dung do người dùng cung cấp.',
    'Terms governing MeloWave music playback, Google Drive integration, device connections, Premium and user-provided content.'
);
?>
<header class="legal-head">
  <p class="eyebrow"><?= mw_t('ĐIỀU KHOẢN SỬ DỤNG ỨNG DỤNG', 'APPLICATION TERMS') ?></p>
  <h1><?= mw_t('Điều khoản ', 'Terms of ') ?><span class="gradient-text"><?= mw_t('sử dụng', 'Service') ?></span></h1>
  <p class="lead"><?= mw_t('Các quy tắc và điều kiện cơ bản khi sử dụng ứng dụng nghe nhạc MeloWave. Vui lòng đọc cùng Chính sách quyền riêng tư.', 'The basic rules for using the MeloWave music player. Please read these terms together with our Privacy Policy.') ?></p>
  <p class="date-line"><?= mw_t('Ngày có hiệu lực / cập nhật: ' . MW_UPDATED_VI, 'Effective / last updated: ' . MW_UPDATED_EN) ?></p>
</header>
<div class="legal-grid">
  <aside class="toc" aria-label="<?= mw_t('Mục lục điều khoản', 'Terms table of contents') ?>">
    <h2><?= mw_t('Nội dung', 'On this page') ?></h2>
    <div class="toc-links">
      <a href="#acceptance"><?= mw_t('1. Chấp nhận', '1. Acceptance') ?></a>
      <a href="#features"><?= mw_t('2. Dịch vụ', '2. Service') ?></a>
      <a href="#content"><?= mw_t('3. Nội dung & bản quyền', '3. Content & rights') ?></a>
      <a href="#drive-terms"><?= mw_t('4. Google Drive', '4. Google Drive') ?></a>
      <a href="#devices"><?= mw_t('5. Kết nối thiết bị', '5. Device connections') ?></a>
      <a href="#premium"><?= mw_t('6. Premium', '6. Premium') ?></a>
      <a href="#third-party"><?= mw_t('7. Bên thứ ba', '7. Third parties') ?></a>
      <a href="#availability"><?= mw_t('8. Dịch vụ & trách nhiệm', '8. Availability & liability') ?></a>
      <a href="#termination"><?= mw_t('9. Ngừng sử dụng', '9. Termination') ?></a>
      <a href="#contact"><?= mw_t('10. Liên hệ', '10. Contact') ?></a>
    </div>
  </aside>
  <article class="legal-paper">
    <section id="acceptance" class="legal-section">
      <h2><?= mw_t('1. Chấp nhận điều khoản', '1. Acceptance of these terms') ?></h2>
      <p><?= mw_t('Khi tải xuống, cài đặt hoặc sử dụng MeloWave (mã gói Android: duc_phi.music), bạn xác nhận đã đọc và đồng ý tuân thủ những điều khoản này trong phạm vi pháp luật cho phép. Nếu không đồng ý, bạn có thể ngừng sử dụng ứng dụng và gỡ cài đặt.', 'By downloading, installing or using MeloWave (Android package: duc_phi.music), you acknowledge these terms and agree to follow them to the extent permitted by applicable law. If you disagree, you may stop using and uninstall the app.') ?></p>
    </section>
    <section id="features" class="legal-section">
      <h2><?= mw_t('2. MeloWave cung cấp những gì?', '2. What MeloWave provides') ?></h2>
      <p><?= mw_t('MeloWave là ứng dụng nghe nhạc, có thể hỗ trợ phát file âm thanh trên thiết bị, quản lý thư viện và danh sách phát, truy cập các file Google Drive được cấp quyền, điều chỉnh âm thanh, kết nối thiết bị và một số dịch vụ trực tuyến tùy chọn.', 'MeloWave is a music player that may provide on-device audio playback, library and playlist management, access to authorized Google Drive files, audio controls, device connectivity and optional online services.') ?></p>
      <p><?= mw_t('Một số chức năng yêu cầu kết nối Internet, quyền truy cập trên Android, tài khoản Google hoặc gói Premium. Tính năng cụ thể có thể khác nhau tùy phiên bản ứng dụng, thiết bị và khu vực.', 'Some features require internet access, Android permissions, a Google account or a Premium entitlement. Availability may vary by app version, device and region.') ?></p>
    </section>
    <section id="content" class="legal-section">
      <h2><?= mw_t('3. Tệp nhạc, quyền sử dụng và bản quyền', '3. Audio files, usage rights and copyright') ?></h2>
      <p><?= mw_t('Bạn chịu trách nhiệm bảo đảm có quyền hợp pháp đối với những file âm thanh mà mình truy cập, lưu, phát hoặc chủ động chia sẻ bằng MeloWave. Ứng dụng không chuyển quyền sở hữu hay cấp giấy phép bản quyền cho những nội dung của bên thứ ba.', 'You are responsible for ensuring that you have the necessary legal rights to access, store, play or intentionally share audio files through MeloWave. The app does not transfer ownership of or grant licenses to third-party content.') ?></p>
      <ul>
        <li><?= mw_t('Không sử dụng MeloWave để sao chép, phát tán hoặc chia sẻ nội dung trái phép.', 'Do not use MeloWave to copy, distribute or share content unlawfully.') ?></li>
        <li><?= mw_t('Không tìm cách vượt qua quyền truy cập, giới hạn phân phối, quota hoặc biện pháp bảo vệ kỹ thuật của Google Drive và các dịch vụ khác.', 'Do not attempt to bypass access permissions, distribution limits, quotas or technical protection measures of Google Drive or other services.') ?></li>
        <li><?= mw_t('Không sử dụng ứng dụng để thực hiện hành vi gây hại, xâm nhập trái phép hoặc lạm dụng tài nguyên hệ thống.', 'Do not use the app for harmful, unauthorized-access or abusive activity.') ?></li>
      </ul>
    </section>
    <section id="drive-terms" class="legal-section">
      <h2><?= mw_t('4. Kết nối Google Drive', '4. Google Drive integration') ?></h2>
      <p><?= mw_t('Tính năng Drive yêu cầu bạn có quyền hợp lệ với tệp hoặc thư mục muốn sử dụng. Khi chọn kết nối Drive cá nhân, bạn sẽ được Google yêu cầu cấp quyền theo phạm vi ứng dụng đang đề nghị. MeloWave không thể tự đọc những tài liệu riêng tư mà bạn chưa cho phép ứng dụng truy cập.', 'Google Drive features require that you have appropriate access to the files or folders you use. When you connect your personal Drive, Google asks you to authorize the requested access. MeloWave cannot automatically read private documents you have not authorized for the app.') ?></p>
      <p><?= mw_t('Google có thể giới hạn API, thu hồi token, thay đổi quyền file hoặc áp dụng quota. MeloWave không bảo đảm rằng tất cả liên kết Google Drive sẽ luôn phát được hoặc mọi tệp đều cho phép tải tạm. Bạn có thể thu hồi quyền truy cập của ứng dụng trong Tài khoản Google.', 'Google may impose API limits, revoke tokens, change file permissions or enforce quotas. MeloWave cannot guarantee that all Drive links will always play or that all files can be temporarily downloaded. You may revoke access in your Google Account.') ?></p>
      <p><?= mw_t('Việc sử dụng dịch vụ Google cũng chịu sự điều chỉnh của các điều khoản và chính sách riêng của Google.', 'Use of Google services is also subject to Google’s own terms and policies.') ?></p>
    </section>
    <section id="devices" class="legal-section">
      <h2><?= mw_t('5. Kết nối và truyền nội dung giữa thiết bị', '5. Connections and transfers between devices') ?></h2>
      <p><?= mw_t('Một số chức năng MeloWave cho phép kết nối nhiều thiết bị trong cùng mạng hoặc thông qua Internet. Khi bạn lựa chọn chia sẻ hoặc truyền file, bạn có trách nhiệm xác nhận thiết bị nhận và nội dung được chia sẻ. Tốc độ và tính khả dụng phụ thuộc đường truyền, cấu hình mạng và quyền truy cập file.', 'Some MeloWave features support device connections over a local network or the internet. When choosing to share or transfer files, you are responsible for confirming the recipient device and the content being shared. Performance and availability depend on network conditions and file permissions.') ?></p>
    </section>
    <section id="premium" class="legal-section">
      <h2><?= mw_t('6. Premium, dùng thử và thanh toán', '6. Premium, trials and billing') ?></h2>
      <p><?= mw_t('Một số tính năng có thể thuộc gói Premium hoặc giai đoạn dùng thử. Các điều kiện, mức giá, thời hạn và quyền lợi cụ thể được hiển thị trong ứng dụng tại thời điểm đăng ký. Giao dịch trong ứng dụng Android có thể được xử lý bằng Google Play Billing.', 'Some features may be part of a Premium plan or trial. Current pricing, duration and entitlements are shown in the app when you subscribe. In-app Android purchases may be processed through Google Play Billing.') ?></p>
      <p><?= mw_t('Trạng thái thanh toán và quyền lợi có thể được MeloWave xác minh với Google Play và máy chủ của ứng dụng để ngăn sử dụng không hợp lệ. Các yêu cầu hoàn tiền và tranh chấp thanh toán sẽ được xử lý theo điều kiện của Google Play và pháp luật áp dụng.', 'Payment and entitlement status may be verified with Google Play and the MeloWave backend to prevent unauthorized access. Refunds and payment disputes are handled under applicable Google Play terms and law.') ?></p>
      <p><?= mw_t('Gỡ ứng dụng không nhất thiết hủy những giao dịch hoặc gói đang hoạt động; hãy quản lý chúng tại Google Play khi cần.', 'Uninstalling the app does not necessarily cancel any active purchases or plans; manage them through Google Play where applicable.') ?></p>
    </section>
    <section id="third-party" class="legal-section">
      <h2><?= mw_t('7. Dịch vụ và nội dung của bên thứ ba', '7. Third-party services and content') ?></h2>
      <p><?= mw_t('MeloWave có thể sử dụng hoặc liên kết đến Google Drive, Google Play, Firebase, dịch vụ quảng cáo, nguồn preview âm nhạc, lời bài hát hoặc nội dung trực tuyến khác. Các dịch vụ và nội dung này do bên cung cấp tương ứng quản lý; quyền sử dụng và quyền riêng tư của họ có thể khác với MeloWave.', 'MeloWave may use or link to Google Drive, Google Play, Firebase, advertising services, music previews, lyrics or other online content providers. Their respective services and content are managed by those providers and may have separate usage and privacy terms.') ?></p>
      <p><?= mw_t('MeloWave là sản phẩm độc lập, không đại diện chính thức cho Google hoặc các nhà cung cấp nội dung bên ngoài.', 'MeloWave is an independent product and is not an official representative of Google or external content providers.') ?></p>
    </section>
    <section id="availability" class="legal-section">
      <h2><?= mw_t('8. Tính khả dụng, cập nhật và giới hạn trách nhiệm', '8. Availability, updates and limitation of liability') ?></h2>
      <p><?= mw_t('Chúng tôi có thể bảo trì, cập nhật hoặc điều chỉnh một số chức năng vì lý do kỹ thuật, bảo mật hoặc tuân thủ. Các dịch vụ phụ thuộc Internet, API hoặc tài khoản bên thứ ba có thể bị gián đoạn ngoài khả năng kiểm soát của MeloWave.', 'We may maintain, update or modify features for technical, security or compliance reasons. Features relying on internet access, APIs or third-party accounts may become unavailable for reasons outside MeloWave’s control.') ?></p>
      <p><?= mw_t('Trong phạm vi pháp luật cho phép, MeloWave được cung cấp theo tình trạng sẵn có; chúng tôi không bảo đảm mọi thiết bị và mọi nguồn nội dung đều hoạt động liên tục, không có lỗi. Điều khoản này không loại trừ các quyền hợp pháp mà bạn được hưởng theo luật bảo vệ người tiêu dùng.', 'To the extent permitted by law, MeloWave is provided on an as-available basis. We cannot guarantee uninterrupted or error-free operation across all devices and content sources. Nothing here limits mandatory consumer rights available under applicable law.') ?></p>
    </section>
    <section id="termination" class="legal-section">
      <h2><?= mw_t('9. Ngừng sử dụng và thay đổi điều khoản', '9. Ending use and changes to these terms') ?></h2>
      <p><?= mw_t('Bạn có thể ngừng sử dụng và gỡ MeloWave bất kỳ lúc nào. Bạn có thể thu hồi quyền Google Drive tại Tài khoản Google. Chúng tôi có thể cập nhật các điều khoản khi có thay đổi đáng kể về ứng dụng hoặc yêu cầu pháp lý và sẽ công bố ngày cập nhật trên trang này.', 'You may stop using and uninstall MeloWave at any time. Google Drive permissions can be revoked from your Google Account. We may update these terms to reflect material app or legal changes, and the updated date will appear on this page.') ?></p>
      <p><?= mw_t('Về cách truy cập, giữ lại hoặc yêu cầu xóa dữ liệu cá nhân, vui lòng xem', 'For information about accessing, retaining or requesting deletion of personal data, see our') ?> <a href="<?= mw_e(mw_page('privacy-policy.php')) ?>"><?= mw_t('Chính sách quyền riêng tư', 'Privacy Policy') ?></a>.</p>
    </section>
    <section id="contact" class="legal-section">
      <h2><?= mw_t('10. Thông tin liên hệ', '10. Contact') ?></h2>
      <p><?= mw_t('Nếu có câu hỏi về điều khoản, thanh toán hoặc dịch vụ MeloWave, vui lòng liên hệ qua email:', 'For questions about these terms, billing or MeloWave service, please contact:') ?></p>
      <div class="support-card"><div><strong>MeloWave Support</strong><small><?= mw_e(MW_SUPPORT_EMAIL) ?></small></div><a class="button button-primary" href="<?= mw_e(mw_contact('MeloWave - Terms of service')) ?>"><?= mw_t('Gửi email', 'Email support') ?> →</a></div>
    </section>
  </article>
</div>
<div class="notice-strip"><?= mw_t('Bạn nên đọc thêm', 'Please also review our') ?> <a href="<?= mw_e(mw_page('privacy-policy.php')) ?>"><?= mw_t('Chính sách quyền riêng tư', 'Privacy Policy') ?></a> <?= mw_t('để biết MeloWave sử dụng các dữ liệu và quyền Google Drive như thế nào.', 'to understand how MeloWave uses information and Google Drive access.') ?></div>
<?php mw_footer(); ?>
