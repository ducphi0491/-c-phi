<?php
declare(strict_types=1);

/*
 * MeloWave public OAuth verification website.
 * Uploaded under https://tunertools.top/melowave/
 * Public pages contain no credentials, sessions, database connections or tracking scripts.
 */
const MW_SITE_BASE = 'https://tunertools.top/melowave/';
const MW_SUPPORT_EMAIL = 'ducphi0491@gmail.com';
const MW_UPDATED_VI = '19/10/2026';
const MW_UPDATED_EN = 'October 19, 2026';

function mw_lang(): string {
    return isset($_GET['lang']) && $_GET['lang'] === 'en' ? 'en' : 'vi';
}
function mw_t(string $vi, string $en): string {
    return mw_lang() === 'en' ? $en : $vi;
}
function mw_e(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function mw_page(string $slug = '', ?string $lang = null): string {
    $path = MW_SITE_BASE . ltrim($slug, '/');
    return $lang === 'en' ? $path . '?lang=en' : $path;
}
function mw_contact(string $subject = ''): string {
    return 'mailto:' . MW_SUPPORT_EMAIL . ($subject === '' ? '' : '?subject=' . rawurlencode($subject));
}

function mw_header(string $active, string $titleVi, string $titleEn, string $descVi, string $descEn): void {
    $lang = mw_lang();
    $title = $lang === 'en' ? $titleEn : $titleVi;
    $description = $lang === 'en' ? $descEn : $descVi;
    $page = $active === 'home' ? '' : ($active === 'privacy' ? 'privacy-policy.php' : 'terms-of-service.php');
    if (!headers_sent()) {
        header('Content-Type: text/html; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }
    ?>
<!doctype html>
<html lang="<?= mw_e($lang) ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#090d1e">
  <meta name="description" content="<?= mw_e($description) ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="MeloWave">
  <meta property="og:title" content="<?= mw_e($title) ?>">
  <meta property="og:description" content="<?= mw_e($description) ?>">
  <meta property="og:url" content="<?= mw_e(mw_page($page, $lang)) ?>">
  <link rel="canonical" href="<?= mw_e(mw_page($page)) ?>">
  <link rel="alternate" hreflang="vi" href="<?= mw_e(mw_page($page)) ?>">
  <link rel="alternate" hreflang="en" href="<?= mw_e(mw_page($page, 'en')) ?>">
  <link rel="stylesheet" href="style.css?v=1">
  <title><?= mw_e($title) ?> | MeloWave</title>
</head>
<body>
<a class="skip-link" href="#main"><?= mw_t('Đến nội dung chính', 'Skip to main content') ?></a>
<div class="background-orb orb-one" aria-hidden="true"></div>
<div class="background-orb orb-two" aria-hidden="true"></div>
<div class="page-shell">
<header class="header">
    <a class="brand" href="<?= mw_e(mw_page()) ?>" aria-label="MeloWave - <?= mw_t('Trang chủ', 'Home') ?>">
      <span class="brand-icon" aria-hidden="true">
        <svg viewBox="0 0 44 44" role="img" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
          <path d="M7 27V17M14 32V12M21 24V20M28 35V9M35 29V15" stroke="#fff" stroke-width="4.3" stroke-linecap="round" />
        </svg>
      </span>
      <span>Melo<span class="brand-accent">Wave</span></span>
    </a>
    <nav class="main-nav" aria-label="<?= mw_t('Điều hướng trang', 'Site navigation') ?>">
      <a <?= $active === 'home' ? 'aria-current="page"' : '' ?> href="<?= mw_e(mw_page()) ?>"><?= mw_t('Trang chủ', 'Home') ?></a>
      <a <?= $active === 'privacy' ? 'aria-current="page"' : '' ?> href="<?= mw_e(mw_page('privacy-policy.php')) ?>"><?= mw_t('Quyền riêng tư', 'Privacy') ?></a>
      <a <?= $active === 'terms' ? 'aria-current="page"' : '' ?> href="<?= mw_e(mw_page('terms-of-service.php')) ?>"><?= mw_t('Điều khoản', 'Terms') ?></a>
    </nav>
    <div class="language-switch" aria-label="Language">
      <a href="<?= mw_e(mw_page($page)) ?>" <?= $lang === 'vi' ? 'aria-current="true"' : '' ?>>VI</a>
      <span aria-hidden="true">/</span>
      <a href="<?= mw_e(mw_page($page, 'en')) ?>" <?= $lang === 'en' ? 'aria-current="true"' : '' ?>>EN</a>
    </div>
</header>
<main id="main">
    <?php
}

function mw_footer(): void {
    ?>
</main>
<footer class="footer">
  <div class="footer-primary">
    <div>
      <strong class="footer-brand">MeloWave</strong>
      <p><?= mw_t('Âm nhạc của bạn, theo cách của bạn.', 'Your music, your way.') ?></p>
    </div>
    <div class="footer-links">
      <a href="<?= mw_e(mw_page()) ?>"><?= mw_t('Trang chủ', 'Home') ?></a>
      <a href="<?= mw_e(mw_page('privacy-policy.php')) ?>"><?= mw_t('Chính sách quyền riêng tư', 'Privacy Policy') ?></a>
      <a href="<?= mw_e(mw_page('terms-of-service.php')) ?>"><?= mw_t('Điều khoản sử dụng', 'Terms of Service') ?></a>
      <a href="<?= mw_e(mw_contact()) ?>"><?= mw_t('Liên hệ hỗ trợ', 'Contact support') ?></a>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© <?= date('Y') ?> MeloWave.</span>
    <span><?= mw_t('Cập nhật: ' . MW_UPDATED_VI, 'Updated: ' . MW_UPDATED_EN) ?></span>
  </div>
</footer>
</div>
</body>
</html>
    <?php
}
