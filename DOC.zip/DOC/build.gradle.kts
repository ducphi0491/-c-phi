plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    // Đã đổi từ com.example.docflowoffline sang com.docflowoffline
    namespace = "com.docflowoffline"
    compileSdk = 35 // Đưa về 35 để khớp với targetSdk (hoặc giữ 36 nếu máy bạn đã cài SDK 36)

    defaultConfig {
        // Đã đổi applicationId khớp với package mới
        applicationId = "com.docflowoffline.dev"
        minSdk = 26
        targetSdk = 34
        versionCode = 16
        versionName = "1.6.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1,DEPENDENCIES,LICENSE,LICENSE.txt,NOTICE,NOTICE.txt}"
        }
    }
}

dependencies {
    // Hạ từ 2025.12.00 về 2024.12.01 (tương thích SDK 35)
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Hạ từ 1.11.0 về 1.9.3 và 1.17.0 về 1.15.0 (tương thích SDK 35 & AGP 8.7.3)
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // OCR offline: no Internet permission or cloud account required at runtime
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.9.0")
    // Respect rotation stored in camera / gallery photos
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}