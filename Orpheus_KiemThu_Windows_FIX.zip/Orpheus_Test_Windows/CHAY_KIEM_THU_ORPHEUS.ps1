param(
    [string]$ZipFile = "",
    [string]$ImageFile = "",
    [ValidateSet(512, 768, 1024, 1280, 1664)]
    [int]$Width = 512,
    [switch]$CheckOnly
)

# Windows PowerShell 5.1 can turn Python stderr into a terminating error
# when ErrorActionPreference is Stop. All external commands run through
# Invoke-External to preserve the real exit code and useful diagnostics.
$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$testScript = Join-Path $scriptDir "kiem_thu_orpheus.py"

function Invoke-External {
    param(
        [Parameter(Mandatory = $true)][string]$Executable,
        [string[]]$Arguments = @(),
        [switch]$Quiet
    )
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        if ($Quiet) {
            $outputLines = @(& $Executable @Arguments 2>&1 | ForEach-Object { [string]$_ })
        } else {
            & $Executable @Arguments 2>&1 | ForEach-Object { Write-Host ([string]$_) }
            $outputLines = @()
        }
        $exitCode = $LASTEXITCODE
        if ($null -eq $exitCode) { $exitCode = 0 }
        return [pscustomobject]@{ ExitCode = [int]$exitCode; Lines = $outputLines }
    }
    finally {
        $ErrorActionPreference = $oldPreference
    }
}

if (-not (Test-Path -LiteralPath $testScript -PathType Leaf)) {
    throw "Khong tim thay kiem_thu_orpheus.py. Giai nen day du bo kiem thu."
}

if ([string]::IsNullOrWhiteSpace($ZipFile)) {
    $candidate1 = Join-Path $scriptDir "orpheus-android-1-2026-10-27.zip"
    $candidate2 = Join-Path (Split-Path -Parent $scriptDir) "orpheus-android-1-2026-10-27.zip"
    if (Test-Path -LiteralPath $candidate1 -PathType Leaf) {
        $ZipFile = $candidate1
    } elseif (Test-Path -LiteralPath $candidate2 -PathType Leaf) {
        $ZipFile = $candidate2
    } else {
        throw "Khong tim thay ZIP Orpheus. Hay copy vao cung thu muc voi file .ps1."
    }
}
$ZipFile = (Resolve-Path -LiteralPath $ZipFile).Path

$venv = Join-Path $scriptDir ".venv"
$python = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    Write-Host "Dang tao moi truong Python rieng: $venv"
    $pyLauncher = Get-Command py -ErrorAction SilentlyContinue
    $pyExe = Get-Command python -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        $result = Invoke-External -Executable $pyLauncher.Source -Arguments @("-3", "-m", "venv", $venv)
    } elseif ($pyExe) {
        $result = Invoke-External -Executable $pyExe.Source -Arguments @("-m", "venv", $venv)
    } else {
        throw "Chua cai Python. Hay cai Python 3.11/3.12 64-bit tu python.org."
    }
    if ($result.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $python -PathType Leaf)) {
        throw "Khong tao duoc Python virtual environment. Kiem tra Python, pip va venv."
    }
}

$pyInfo = Invoke-External -Executable $python -Arguments @("-c", "import sys,platform;print(sys.version.split()[0] + ' / ' + platform.architecture()[0])") -Quiet
if ($pyInfo.ExitCode -ne 0) {
    foreach ($line in $pyInfo.Lines) { Write-Host $line }
    throw "Python trong .venv khong khoi dong duoc. Can tao lai .venv."
}
Write-Host ("Python: " + ($pyInfo.Lines -join " "))

if (-not $CheckOnly) {
    Write-Host "Dang kiem tra numpy, pillow va onnxruntime ..."
    $checkArgs = @("-c", "import numpy; import PIL; import onnxruntime; print('DEPENDENCIES_OK')")
    $check = Invoke-External -Executable $python -Arguments $checkArgs -Quiet
    if ($check.ExitCode -ne 0) {
        Write-Host "Chua nap duoc thu vien. Thong tin kiem tra:"
        foreach ($line in $check.Lines) { Write-Host ("  " + $line) }
        Write-Host "Dang cai thu vien Python can thiet (co the can Internet) ..."
        $install = Invoke-External -Executable $python -Arguments @(
            "-m", "pip", "install", "--disable-pip-version-check",
            "--only-binary=:all:", "numpy", "pillow", "onnxruntime"
        )
        if ($install.ExitCode -ne 0) {
            throw "pip install that bai. Kiem tra Internet, Python 3.11/3.12 64-bit va loi pip phia tren."
        }
        $check = Invoke-External -Executable $python -Arguments $checkArgs -Quiet
        if ($check.ExitCode -ne 0) {
            Write-Host "Van khong import duoc sau khi cai:"
            foreach ($line in $check.Lines) { Write-Host ("  " + $line) }
            throw "Python dependency import failed. Hay gui toan bo thong bao tren de chan doan."
        }
    }
    Write-Host "[OK] numpy, pillow, onnxruntime da san sang."
}

$testArgs = @(
    $testScript, "--zip", $ZipFile,
    "--out", (Join-Path $scriptDir "KET_QUA_KIEM_THU"),
    "--width", [string]$Width
)
if (-not [string]::IsNullOrWhiteSpace($ImageFile)) {
    $ImageFile = (Resolve-Path -LiteralPath $ImageFile).Path
    $testArgs += @("--image", $ImageFile)
}
if ($CheckOnly) { $testArgs += "--only-check" }

Write-Host "Bat dau kiem tra mo hinh Orpheus ..."
$testResult = Invoke-External -Executable $python -Arguments $testArgs
if ($testResult.ExitCode -ne 0) {
    throw "Kiem thu that bai. Xem KET_QUA_KIEM_THU\ket_qua.txt va thong bao phia tren."
}
Write-Host "HOAN TAT. Xem KET_QUA_KIEM_THU\ket_qua.txt"
