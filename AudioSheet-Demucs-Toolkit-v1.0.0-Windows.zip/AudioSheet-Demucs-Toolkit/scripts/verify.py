"""Readiness check for the separate Demucs environment; no network or model load."""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import importlib.util
import platform
import shutil
import struct
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def check(label: str, ok: bool, detail: str = "") -> int:
    print(("[OK] " if ok else "[THIEU/LOI] ") + label + (" : " + detail if detail else ""))
    return int(not ok)


def run_checks(deep: bool = False) -> int:
    errors = 0
    print("=== AUDIO SHEET - DEMUCS DIAGNOSTICS ===")
    errors += check("Python 3.11 64-bit", sys.version_info[:2] == (3, 11) and struct.calcsize("P") == 8, sys.version.split()[0])
    errors += check("FFmpeg", bool(shutil.which("ffmpeg")), shutil.which("ffmpeg") or "not in PATH")
    errors += check("FFprobe", bool(shutil.which("ffprobe")), shutil.which("ffprobe") or "not in PATH")
    errors += check("Python environment separate", Path(sys.prefix).resolve() == (ROOT / ".venv-demucs").resolve(), sys.prefix)
    for package in ("numpy", "torch", "torchaudio", "demucs", "soundfile"):
        try:
            version = importlib.metadata.version(package)
            exists = importlib.util.find_spec("soundfile" if package == "soundfile" else package) is not None
        except (importlib.metadata.PackageNotFoundError, ModuleNotFoundError):
            version = "not installed"
            exists = False
        errors += check(package, exists, version)
    if deep and errors == 0:
        for package in ("torch", "torchaudio", "demucs.separate"):
            try:
                mod = importlib.import_module(package)
                errors += check("import " + package, True, str(getattr(mod, "__version__", "loaded")))
            except Exception as exc:
                errors += check("import " + package, False, str(exc)[:350])
        if errors == 0:
            import torch
            errors += check("Torch CPU", torch.tensor([1, 2]).sum().item() == 3)
    (ROOT / "output").mkdir(exist_ok=True)
    (ROOT / "models").mkdir(exist_ok=True)
    print("=== KET QUA: " + ("DU THANH PHAN (CHUA THU TAI MODEL/SEPARATION)" if errors == 0 else f"CON {errors} MUC CAN XU LY") + " ===")
    print("Neu model chua tung chay, can Internet o lan tach giong dau tien.")
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--deep", action="store_true", help="Test real imports and Torch CPU")
    args = parser.parse_args()
    raise SystemExit(run_checks(deep=args.deep))
