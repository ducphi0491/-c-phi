$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$venv = Join-Path $root '.venv-demucs'
$venvPython = Join-Path $venv 'Scripts\python.exe'
$logdir = Join-Path $root 'logs'
New-Item -ItemType Directory -Path $logdir -Force | Out-Null
$logfile = Join-Path $logdir 'install.log'

function Select-Python311 {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        try {
            & py -3.11 -c "import sys,struct;sys.exit(0 if sys.version_info[:2] == (3,11) and struct.calcsize('P') == 8 else 1)" 2>$null
            if ($LASTEXITCODE -eq 0) { return @{Exe='py'; Prefix=@('-3.11')} }
        } catch { }
    }
    $candidates = @('C:\Program Files\Python311\python.exe', 'python')
    foreach ($exe in $candidates) {
        try {
            & $exe -c "import sys,struct;sys.exit(0 if sys.version_info[:2] == (3,11) and struct.calcsize('P') == 8 else 1)" 2>$null
            if ($LASTEXITCODE -eq 0) { return @{Exe=$exe; Prefix=@()} }
        } catch { }
    }
    throw 'Khong tim thay Python 3.11 64-bit. Hay kiem tra lai bo cai Python hoac PATH.'
}

function Run-Step([string]$title, [string]$exe, [string[]]$cmdargs) {
    Write-Host "`n[BUOC] $title" -ForegroundColor Cyan
    & $exe @cmdargs
    if ($LASTEXITCODE -ne 0) {
        throw "$title that bai. Ma loi: $LASTEXITCODE. Chi tiet: $logfile"
    }
}

$transcriptStarted = $false
$installationSuccessful = $false
try {
    Start-Transcript -Path $logfile -Force | Out-Null
    $transcriptStarted = $true
    Write-Host '=======================================================' -ForegroundColor Green
    Write-Host ' AudioSheet Demucs Toolkit - CAI DAT RIENG (CPU)' -ForegroundColor Green
    Write-Host ' Khong sua thu muc project AudioSheet Studio hien tai.'
    Write-Host '=======================================================' -ForegroundColor Green
    $base = Select-Python311
    Write-Host "Python: $($base.Exe) $($base.Prefix -join ' ')" -ForegroundColor Green
    if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -or
        -not (Get-Command ffprobe -ErrorAction SilentlyContinue)) {
        throw 'Chua tim thay FFmpeg hoac FFprobe trong PATH. Hay kiem tra lenh ffmpeg -version va ffprobe -version.'
    }
    if (-not (Test-Path $venvPython)) {
        $baseArgs = @($base.Prefix) + @('-m', 'venv', $venv)
        Run-Step 'Tao .venv-demucs rieng' $base.Exe $baseArgs
    }
    Run-Step 'Cap nhat pip' $venvPython @('-m', 'pip', 'install', '--upgrade', 'pip')
    Run-Step 'Ghim NumPy 1.26 + setuptools cho tuong thich' $venvPython @('-m', 'pip', 'install', 'numpy==1.26.4', 'setuptools==70.3.0', 'wheel')
    Run-Step 'Cai PyTorch CPU va Torchaudio 2.1.2' $venvPython @('-m', 'pip', 'install', '--index-url', 'https://download.pytorch.org/whl/cpu', 'torch==2.1.2', 'torchaudio==2.1.2')
    Run-Step 'Cai Demucs 4.0.1 va soundfile' $venvPython @('-m', 'pip', 'install', 'demucs==4.0.1', 'soundfile==0.12.1', 'numpy==1.26.4', 'setuptools==70.3.0')
    Run-Step 'Kiem tra phu thuoc pip' $venvPython @('-m', 'pip', 'check')
    Run-Step 'Kiem tra import thu vien & Torch CPU' $venvPython @((Join-Path $root 'scripts\verify.py'), '--deep')
    Write-Host "`n[THANH CONG] Da cai xong. Chay 02_TACH_GIONG.bat" -ForegroundColor Green
    Write-Host 'Lan tach dau tien se tai model Demucs tu Internet.' -ForegroundColor Yellow
    $installationSuccessful = $true
} catch {
    Write-Host "`n[THAT BAI] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Gui file nhat ky sau: $logfile" -ForegroundColor Yellow
} finally {
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
}

if ($installationSuccessful) { exit 0 }
exit 1
