"""AudioSheet Demucs bridge: local file -> isolated Demucs CPU -> two WAV stems.

All heavy ML processing happens in a separate Python subprocess. This module
uses only the Python standard library and does not import AudioSheet's packages.
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import re
import shutil
import subprocess
import sys
import threading
import uuid
from pathlib import Path
from typing import Callable

ROOT = Path(__file__).resolve().parents[1]
SUPPORTED_SUFFIXES = {".mp3", ".wav", ".m4a", ".flac", ".aac", ".ogg", ".opus", ".wma", ".mp4", ".webm"}
MAX_SECONDS = 1800  # Guard against accidentally passing many-hour recordings.
MAX_BYTES = 1024 * 1024 * 1024
MODELS = ("htdemucs", "htdemucs_ft")


class SeparationError(RuntimeError):
    """A failure whose message can be shown directly to the user."""


class Cancelled(SeparationError):
    pass


def safe_filename_stem(stem: str) -> str:
    # Windows prohibits several characters and reserved device names.
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", stem).strip(" .")
    stem = re.sub(r"\s+", " ", stem)
    stem = stem[:55].rstrip(" .") or "audio"
    return "bai_hat_" + stem


def make_output_directory(out_root: Path, stem: str, when: dt.datetime | None = None) -> Path:
    stamp = (when or dt.datetime.now()).strftime("%Y%m%d_%H%M%S")
    folder = out_root / f"{safe_filename_stem(stem)}_{stamp}_{uuid.uuid4().hex[:5]}"
    folder.mkdir(parents=True, exist_ok=False)
    return folder


def probe_duration(ffprobe: str, file: Path) -> float:
    args = [ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(file)]
    try:
        proc = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60, check=False)
    except FileNotFoundError as exc:
        raise SeparationError("Khong tim thay FFprobe. Hay kiem tra FFmpeg trong PATH cua Windows.") from exc
    except subprocess.TimeoutExpired as exc:
        raise SeparationError("FFprobe khong phan hoi khi doc file am thanh.") from exc
    if proc.returncode:
        raise SeparationError("FFprobe khong doc duoc file nay: " + (proc.stderr.strip()[-300:] or str(file)))
    try:
        seconds = float(proc.stdout.strip().splitlines()[0])
    except (ValueError, IndexError) as exc:
        raise SeparationError("Khong phat hien duoc thoi luong track am thanh.") from exc
    if not (0.1 < seconds < float("inf")):
        raise SeparationError("Thoi luong file khong hop le.")
    return seconds


class Separator:
    def __init__(
        self,
        root: Path = ROOT,
        python: str | Path = sys.executable,
        model: str = "htdemucs",
        on_update: Callable[[str], None] | None = None,
    ) -> None:
        if model not in MODELS:
            raise ValueError("Unsupported Demucs model")
        self.root = Path(root).resolve()
        self.python = str(python)
        self.model = model
        self.on_update = on_update or print
        self.logfile = self.root / "logs" / "last_run.log"
        self.active_process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()
        self.cancel_event = threading.Event()

    def update(self, line: str) -> None:
        # All messages are persisted so errors are inspectable after closing GUI.
        with self.logfile.open("a", encoding="utf-8", errors="replace") as handle:
            handle.write(line.rstrip("\r\n") + "\n")
        self.on_update(line.rstrip("\r\n"))

    def cancel(self) -> None:
        self.cancel_event.set()
        with self._lock:
            proc = self.active_process
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass

    def _run(self, args: list[str], stage: str, env: dict[str, str] | None = None) -> None:
        if self.cancel_event.is_set():
            raise Cancelled("Da huy xu ly.")
        self.update(stage)
        options = {
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "text": True,
            "encoding": "utf-8",
            "errors": "replace",
            "bufsize": 1,
            "env": env,
            "stdin": subprocess.DEVNULL,
        }
        if os.name == "nt":
            options["creationflags"] = subprocess.CREATE_NO_WINDOW
        try:
            proc = subprocess.Popen(args, **options)
        except FileNotFoundError as exc:
            raise SeparationError(f"Khong tim thay lenh: {args[0]}") from exc
        with self._lock:
            self.active_process = proc
        try:
            assert proc.stdout is not None
            with proc.stdout:
                for line in proc.stdout:
                    if line.strip():
                        self.update(line)
            code = proc.wait()
        finally:
            with self._lock:
                self.active_process = None
        if self.cancel_event.is_set():
            raise Cancelled("Da huy xu ly.")
        if code != 0:
            raise SeparationError(f"Buoc '{stage}' that bai (ma {code}). Mo logs/last_run.log de xem chi tiet.")

    def run(self, input_file: Path, output_root: Path | None = None) -> Path:
        self.root.joinpath("logs").mkdir(parents=True, exist_ok=True)
        self.root.joinpath("models").mkdir(parents=True, exist_ok=True)
        self.root.joinpath("work").mkdir(parents=True, exist_ok=True)
        output_root = Path(output_root).resolve() if output_root else self.root / "output"
        output_root.mkdir(parents=True, exist_ok=True)
        self.logfile.write_text("AUDIO SHEET - DEMUCS RUN\n", encoding="utf-8")

        src = Path(input_file).expanduser().resolve()
        if not src.is_file():
            raise SeparationError("File am thanh khong ton tai: " + str(src))
        if src.suffix.lower() not in SUPPORTED_SUFFIXES:
            raise SeparationError("Dinh dang khong ho tro: " + src.suffix)
        size = src.stat().st_size
        if size == 0 or size > MAX_BYTES:
            raise SeparationError("File rong hoac qua 1 GB. Hay cat gon file truoc khi xu ly.")
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            raise SeparationError("Thieu FFmpeg/FFprobe trong PATH. Hay chay 03_KIEM_TRA.bat.")
        duration = probe_duration("ffprobe", src)
        if duration > MAX_SECONDS:
            raise SeparationError("File dai hon 30 phut. Hay cat thanh cac doan nho de xu ly.")
        self.update(f"Nguon: {src.name} | {duration:.1f} giay | {size / 1048576:.1f} MB")
        self.update("Che do: " + self.model + " / CPU / tach vocals")
        if duration > 600:
            self.update("[LUU Y] AudioSheet Studio v1.0.7 chi xu ly file toi da 600 giay. Hay cat ngan de tai len website.")

        task_dir = self.root / "work" / ("job_" + uuid.uuid4().hex[:12])
        task_dir.mkdir(parents=True, exist_ok=False)
        normalized = task_dir / "input.wav"
        separated = task_dir / "separated"
        destination: Path | None = None
        try:
            ffmpeg_args = [
                "ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
                "-i", str(src), "-map", "0:a:0", "-vn",
                "-ac", "2", "-ar", "44100", "-c:a", "pcm_s16le", str(normalized),
            ]
            self._run(ffmpeg_args, "[1/4] Dang chuan hoa WAV 44.1 kHz stereo...")
            if not normalized.exists() or normalized.stat().st_size < 1000:
                raise SeparationError("FFmpeg khong tao duoc WAV chuan hoa.")

            env = os.environ.copy()
            # Keep torch model cache isolated from the existing AudioSheet environment.
            env["TORCH_HOME"] = str(self.root / "models")
            env["PYTHONUTF8"] = "1"
            demucs_args = [
                self.python, "-m", "demucs", "-n", self.model,
                "--two-stems=vocals", "-d", "cpu", "-j", "1",
                "--segment", "7", "-o", str(separated), str(normalized),
            ]
            self._run(demucs_args, "[2/4] Demucs dang tach giong (model tu tai trong lan dau)...", env=env)
            stem_dir = separated / self.model / "input"
            vocals = stem_dir / "vocals.wav"
            instrumental = stem_dir / "no_vocals.wav"
            for stem in (vocals, instrumental):
                if not stem.is_file() or stem.stat().st_size <= 1000:
                    raise SeparationError(f"Khong tim thay dau ra Demucs: {stem.name}")
                stem_seconds = probe_duration("ffprobe", stem)
                if abs(duration - stem_seconds) > max(1.5, duration * 0.01):
                    raise SeparationError(f"Thoi luong {stem.name} bat thuong: {stem_seconds:.2f}s")

            if self.cancel_event.is_set():
                raise Cancelled("Da huy xu ly.")
            self.update("[3/4] Tao WAV nhe de tai len AudioSheet (mono 22050 Hz)...")
            sheet_sources = ((vocals, task_dir / "vocals_cho_sheet.wav"),
                             (instrumental, task_dir / "no_vocals_cho_sheet.wav"))
            for source_wav, target_wav in sheet_sources:
                self._run(["ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
                           "-i", str(source_wav), "-vn", "-ac", "1", "-ar", "22050",
                           "-c:a", "pcm_s16le", str(target_wav)],
                          "Tao " + target_wav.name)
                if not target_wav.exists() or target_wav.stat().st_size <= 1000:
                    raise SeparationError("Khong tao duoc " + target_wav.name)

            if self.cancel_event.is_set():
                raise Cancelled("Da huy xu ly.")
            self.update("[4/4] Dang luu 4 file WAV ket qua...")
            destination = make_output_directory(output_root, src.stem)
            shutil.copy2(vocals, destination / "vocals.wav")
            shutil.copy2(instrumental, destination / "no_vocals.wav")
            for _, temp_sheet_wav in sheet_sources:
                shutil.copy2(temp_sheet_wav, destination / temp_sheet_wav.name)
            (destination / "HUONG_DAN_KET_QUA.txt").write_text(
                "AUDIO SHEET STUDIO - KET QUA DEMUCS\n\n"
                f"Nguon: {src}\nModel: {self.model}\nThoi luong: {duration:.2f} giay\n\n"
                "vocals.wav: Giong hat da tach - chat luong nghe stereo.\n"
                "no_vocals.wav: Nhac dem da tach - chat luong nghe stereo.\n"
                "vocals_cho_sheet.wav: Giong hat mono/22050 Hz de tai len AudioSheet.\n"
                "no_vocals_cho_sheet.wav: Nhac dem mono/22050 Hz de tai len AudioSheet.\n"
                "Co the con tieng nhac lan hoac artifact cua AI.\n\n"
                "3 che do A/B/C trong website hien tai la 3 cach sap xep MIDI;\n"
                "bo cong cu nay KHONG tu dong tao 3 track dung y nhu ban goc.\n"
                "Khong can sua file code AudioSheet Studio ban dang chay.\n",
                encoding="utf-8",
            )
            self.update("HOAN TAT. Thu muc ket qua: " + str(destination))
            return destination
        except Exception:
            if destination is not None:
                shutil.rmtree(destination, ignore_errors=True)
            raise
        finally:
            shutil.rmtree(task_dir, ignore_errors=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Tach vocals bang Demucs CPU, khong can sua AudioSheet Studio")
    parser.add_argument("--input", help="File MP3/WAV/FLAC/M4A local. Neu bo trong se duoc hoi duong dan.")
    parser.add_argument("--model", choices=MODELS, default="htdemucs")
    parser.add_argument("--output-dir", help="Thu muc ket qua rieng (tuy chon)")
    args = parser.parse_args(argv)
    if not args.input:
        try:
            args.input = input("Dan duong dan file MP3/WAV va Enter: ").strip().strip('"')
        except EOFError:
            print("Chua nhap file am thanh.")
            return 2
    try:
        runner = Separator(model=args.model)
        dest = runner.run(Path(args.input), Path(args.output_dir) if args.output_dir else None)
        print("\nDA TACH XONG. MO THU MUC:", dest)
        return 0
    except (SeparationError, OSError, ValueError) as exc:
        print("\n[LOI]", str(exc))
        return 1
    except KeyboardInterrupt:
        print("\nDA HUY.")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
