"""Small Windows-friendly Tkinter UI for testing Demucs without changing AudioSheet."""
from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except ImportError as exc:
    print("Python may chua co Tkinter; hay su dung che do dong lenh.", exc)
    raise SystemExit(2)

from separator import ROOT, MODELS, SUPPORTED_SUFFIXES, Separator, SeparationError, Cancelled

BG = "#081612"
PANEL = "#10251e"
ACCENT = "#19cf90"
TEXT = "#ecf7f0"
MUTED = "#b3cfc0"


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("AudioSheet - Tach giong hat Demucs")
        self.root.geometry("780x570")
        self.root.minsize(680, 515)
        self.root.configure(bg=BG)
        self.path = tk.StringVar(value="")
        self.model = tk.StringVar(value=MODELS[0])
        self.accept = tk.BooleanVar(value=False)
        self.info = tk.StringVar(value="San sang. Chon file am thanh co tren may cua ban.")
        self.events: queue.Queue[tuple[str, str]] = queue.Queue()
        self.runner: Separator | None = None
        self.worker: threading.Thread | None = None
        self.latest_output: Path | None = None
        self.busy = False

        shell = tk.Frame(root, bg=BG, padx=24, pady=18)
        shell.pack(fill="both", expand=True)
        tk.Label(shell, text="AUDIO SHEET  /  VOICE SPLITTER", fg=ACCENT, bg=BG,
                 font=("Segoe UI", 11, "bold"), anchor="w").pack(fill="x")
        tk.Label(shell, text="Tach giong hat de AI nhan dung giai dieu hon", fg=TEXT, bg=BG,
                 font=("Segoe UI", 17, "bold"), anchor="w").pack(fill="x", pady=(5, 4))
        tk.Label(shell, text="Demucs hoat dong tren CPU. Khong can Node.js; khong sua project AudioSheet Studio.",
                 fg=MUTED, bg=BG, font=("Segoe UI", 10), anchor="w").pack(fill="x", pady=(0, 18))

        frm = tk.Frame(shell, bg=PANEL, padx=16, pady=14)
        frm.pack(fill="x")
        tk.Label(frm, text="1   CHON FILE MP3 / WAV / M4A / FLAC ...", fg=ACCENT,
                 bg=PANEL, font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x")
        row = tk.Frame(frm, bg=PANEL)
        row.pack(fill="x", pady=(8, 10))
        self.path_entry = tk.Entry(row, textvariable=self.path, font=("Segoe UI", 10),
                                   bg="#18342a", fg=TEXT, insertbackground=TEXT,
                                   relief="flat", highlightthickness=0)
        self.path_entry.pack(side="left", fill="x", expand=True, ipady=8)
        self.select_btn = tk.Button(row, text="Chon file...", command=self.choose, bg=ACCENT,
                                    fg="#041811", relief="flat", font=("Segoe UI", 10, "bold"), padx=14, pady=7)
        self.select_btn.pack(side="left", padx=(8, 0))
        model_row = tk.Frame(frm, bg=PANEL)
        model_row.pack(fill="x", pady=(2, 9))
        tk.Label(model_row, text="Model tach nguon:", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 10)).pack(side="left")
        self.model_box = ttk.Combobox(model_row, textvariable=self.model, values=MODELS,
                                      width=20, state="readonly")
        self.model_box.pack(side="left", padx=12)
        tk.Label(model_row, text="htdemucs_ft cham hon, co the tach ro hon", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left")
        self.accept_box = tk.Checkbutton(frm, text="Toi co quyen su dung va xu ly file am thanh nay.",
                                          variable=self.accept, fg=TEXT, bg=PANEL, selectcolor=PANEL,
                                          activebackground=PANEL, activeforeground=TEXT,
                                          font=("Segoe UI", 10))
        self.accept_box.pack(anchor="w")

        controls = tk.Frame(shell, bg=BG)
        controls.pack(fill="x", pady=(15, 4))
        self.start_btn = tk.Button(controls, text="2   TACH GIONG HAT", command=self.start,
                                    bg=ACCENT, fg="#031b12", relief="flat", padx=19,
                                    pady=9, font=("Segoe UI", 11, "bold"))
        self.start_btn.pack(side="left")
        self.cancel_btn = tk.Button(controls, text="Huy", command=self.cancel,
                                     bg="#26362f", fg=TEXT, relief="flat", padx=18,
                                     pady=9, font=("Segoe UI", 10), state="disabled")
        self.cancel_btn.pack(side="left", padx=8)
        self.open_btn = tk.Button(controls, text="3   MO KET QUA", command=self.open_output,
                                   bg="#26362f", fg=TEXT, relief="flat", padx=18,
                                   pady=9, font=("Segoe UI", 10))
        self.open_btn.pack(side="right")

        self.progress = ttk.Progressbar(shell, mode="indeterminate")
        self.progress.pack(fill="x", pady=(12, 5))
        tk.Label(shell, textvariable=self.info, fg=MUTED, bg=BG,
                 font=("Segoe UI", 10), anchor="w").pack(fill="x", pady=(0, 6))
        tk.Label(shell, text="NHAT KY XU LY", fg=ACCENT, bg=BG,
                 font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x")
        logframe = tk.Frame(shell, bg=BG)
        logframe.pack(fill="both", expand=True, pady=(4, 8))
        self.log = tk.Text(logframe, height=8, bg=PANEL, fg=TEXT, relief="flat",
                           wrap="word", font=("Consolas", 9), state="disabled", padx=10, pady=8)
        self.log.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(logframe, orient="vertical", command=self.log.yview)
        sb.pack(side="right", fill="y")
        self.log.config(yscrollcommand=sb.set)
        tk.Label(shell, text="Sau khi tach: tai vocals_cho_sheet.wav vao 127.0.0.1:8000 de tao sheet.",
                 fg=ACCENT, bg=BG, font=("Segoe UI", 10), anchor="w").pack(fill="x")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(150, self.pump)

    def choose(self) -> None:
        types = [("Audio files", "*.mp3 *.wav *.m4a *.flac *.ogg *.aac *.opus *.wma *.mp4 *.webm"),
                 ("All files", "*.*")]
        filename = filedialog.askopenfilename(title="Chon bai hat can tach giong", filetypes=types)
        if filename:
            self.path.set(filename)

    def append_log(self, line: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", line.strip() + "\n")
        if int(self.log.index("end-1c").split(".")[0]) > 300:
            self.log.delete("1.0", "80.0")
        self.log.see("end")
        self.log.configure(state="disabled")

    def start(self) -> None:
        if self.busy:
            return
        file = Path(self.path.get().strip().strip('"'))
        if not file.is_file() or file.suffix.lower() not in SUPPORTED_SUFFIXES:
            messagebox.showwarning("Chua chon file", "Hay chon file am thanh co tren may (MP3/WAV/M4A/FLAC...).")
            return
        if not self.accept.get():
            messagebox.showwarning("Quyen su dung", "Hay xac nhan ban duoc phep xu ly file am thanh nay.")
            return
        self.busy = True
        self.start_btn.config(state="disabled")
        self.select_btn.config(state="disabled")
        self.cancel_btn.config(state="normal")
        self.model_box.config(state="disabled")
        self.path_entry.config(state="disabled")
        self.progress.start(18)
        self.info.set("Dang xu ly tren CPU... Xem nhat ky ben duoi.")
        self.append_log("--- BAT DAU ---")
        self.runner = Separator(model=self.model.get(), on_update=lambda s: self.events.put(("log", s)))

        def task() -> None:
            try:
                path = self.runner.run(file)
                self.events.put(("done", str(path)))
            except Cancelled as exc:
                self.events.put(("cancelled", str(exc)))
            except (SeparationError, OSError, ValueError) as exc:
                self.events.put(("error", str(exc)))
            except Exception as exc:
                self.events.put(("error", "Loi khong du kien: " + str(exc)))

        self.worker = threading.Thread(target=task, name="demucs-worker", daemon=True)
        self.worker.start()

    def cancel(self) -> None:
        if self.busy and self.runner:
            self.info.set("Dang huy... kieu du lieu cu se duoc giu nguyen.")
            self.runner.cancel()

    def pump(self) -> None:
        try:
            while True:
                kind, msg = self.events.get_nowait()
                if kind == "log":
                    self.append_log(msg)
                else:
                    self.busy = False
                    self.progress.stop()
                    self.start_btn.config(state="normal")
                    self.select_btn.config(state="normal")
                    self.cancel_btn.config(state="disabled")
                    self.model_box.config(state="readonly")
                    self.path_entry.config(state="normal")
                    if kind == "done":
                        self.latest_output = Path(msg)
                        self.info.set("Da tach thanh cong! Bam MO KET QUA.")
                        messagebox.showinfo("Da tach xong", "Da tao 4 WAV: 2 ban nghe va 2 ban de tai len sheet.\n\n" + msg)
                    elif kind == "cancelled":
                        self.info.set("Da huy xu ly.")
                    else:
                        self.info.set("Co loi. Kiem tra logs/last_run.log.")
                        messagebox.showerror("Tach giong khong thanh cong", msg + "\n\nXem logs/last_run.log")
        except queue.Empty:
            pass
        self.root.after(150, self.pump)

    def open_output(self) -> None:
        folder = self.latest_output if self.latest_output and self.latest_output.is_dir() else ROOT / "output"
        folder.mkdir(parents=True, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(str(folder))
        else:
            subprocess.Popen(["xdg-open", str(folder)])

    def on_close(self) -> None:
        if self.busy:
            if not messagebox.askyesno("Dang xu ly", "Ban muon huy tac vu va dong chuong trinh?"):
                return
            self.cancel()
        self.root.destroy()


def main() -> int:
    root = tk.Tk()
    App(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
