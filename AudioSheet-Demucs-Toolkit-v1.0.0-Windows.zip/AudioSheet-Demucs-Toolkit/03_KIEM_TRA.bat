@echo off
setlocal
cd /d "%~dp0"
title AudioSheet Demucs - Kiem tra
if not exist "%~dp0.venv-demucs\Scripts\python.exe" (
    echo [CHUA CAI] Chay 01_CAI_DAT.bat truoc.
    pause
    exit /b 1
)
"%~dp0.venv-demucs\Scripts\python.exe" "%~dp0scripts\verify.py" --deep
set "CODE=%ERRORLEVEL%"
echo.
pause
exit /b %CODE%
