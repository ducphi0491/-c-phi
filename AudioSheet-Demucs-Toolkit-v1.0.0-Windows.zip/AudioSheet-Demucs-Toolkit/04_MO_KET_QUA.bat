@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0output" mkdir "%~dp0output"
start "" explorer.exe "%~dp0output"
exit /b 0
