# AudioSheet - Demucs Voice Splitter (Windows)

**Bộ công cụ thử nghiệm độc lập** dành cho AudioSheet Studio v1.0.7, dùng Demucs nguồn mở để tách âm thanh thành hai bản WAV. Chạy trên CPU; không ghi đè mã nguồn hoặc `.venv` của website hiện tại.

## Bắt đầu nhanh

1. Giải nén toàn bộ thư mục `AudioSheet-Demucs-Toolkit` ra `C:\AudioSheet-Demucs-Toolkit`.
2. Chạy `01_CAI_DAT.bat` (máy đã có Python 3.11 và FFmpeg; phải có Internet để tải thư viện).
3. Chạy `03_KIEM_TRA.bat`. Nếu tất cả `[OK]`, chạy `02_TACH_GIONG.bat`.
4. Chọn một **file âm thanh trên máy** mà bạn được phép xử lý. Giữ model mặc định `htdemucs`, bấm **TÁCH GIỌNG HÁT**.
5. Mở thư mục `output\...\`. Sẽ có **4 file WAV**: `vocals.wav` và `no_vocals.wav` (2 bản stereo để nghe); `vocals_cho_sheet.wav` và `no_vocals_cho_sheet.wav` (2 bản mono nhỏ hơn, 22.05 kHz, phù hợp tải lên website).
6. Mở trang AudioSheet Studio hiện có tại `http://127.0.0.1:8000`, tải lên `vocals_cho_sheet.wav`, chọn tạo sheet, rồi so sánh giai điệu ở các chế độ phát A/B/C. Thử tiếp `no_vocals_cho_sheet.wav` trong một lượt mới để kiểm tra phần đệm.

## Khác với tính năng 3 chế độ của website

- **Demucs** là mô hình *tách nguồn âm thanh*, không phải mô hình nhận dạng bản nhạc.
- **Basic Pitch** trong AudioSheet Studio mới là bộ chuyển âm thanh sang các nốt MIDI. Sau khi tách giọng, bạn **cần tải file vocals.wav lên website** để tạo sheet.
- Các chế độ A/B/C trong AudioSheet v1.0.7 vẫn chỉ là ba phương án *lọc và phối lại nốt đã nhận dạng*; gói này không tự sửa các chế độ đó hay tự tạo ba bè độc lập.
- Vì vậy đây là bước kiểm chứng chất lượng giai điệu trước khi cân nhắc tích hợp vào website. Không bảo đảm kết quả giống bản gốc 100%.

## Yêu cầu

- Windows x64, Python **3.11 x64**, FFmpeg và FFprobe có trong `PATH`. Không cần Node.js.
- Internet để cài thư viện và tải trọng số mô hình ở **lần tách đầu tiên**.
- Ổ đĩa trống nhiều GB và nên có RAM **ít nhất 8 GB** để chạy nhạc dài. Máy yếu nên thử đoạn ngắn hơn.
- Phiên bản cài đặt được khóa: **Demucs 4.0.1**, **torch/torchaudio CPU 2.1.2**, NumPy 1.26.4, setuptools 70.3.0; dùng một virtual environment **`.venv-demucs` riêng**.

## Nội dung ZIP

| File | Vai trò |
| --- | --- |
| `01_CAI_DAT.bat` | Tạo môi trường riêng và cài thư viện |
| `02_TACH_GIONG.bat` | Mở giao diện chọn file và tách giọng |
| `03_KIEM_TRA.bat` | Kiểm tra Python, FFmpeg, model imports, Torch CPU |
| `04_MO_KET_QUA.bat` | Mở thư mục `output` |
| `05_TACH_BANG_LENH.bat` | Dự phòng khi Windows không chạy Tkinter |
| `HUONG_DAN_TUNG_BUOC.txt` | Các bước vận hành, lỗi thường gặp |
| `scripts/*` | Mã nguồn Python + PowerShell |
| `logs/*` | Nhật ký cài đặt và tách nhạc sau khi chạy |
| `models/*` | Trọng số Demucs tự tải, **không có sẵn trong ZIP** |

## Lệnh chạy không dùng GUI

```bat
.venv-demucs\Scripts\python.exe scripts\separator.py --input "D:\Music\sample.mp3"
```

Bạn có thể chọn model `htdemucs_ft` bằng `--model htdemucs_ft`; model này tiêu thụ nhiều tài nguyên hơn. Đầu ra của mỗi lần chạy được đặt vào thư mục mới, không ghi đè file kết quả cũ.

## Khắc phục lỗi

- `No module named demucs` hoặc `[CHUA CAI]`: chạy lại `01_CAI_DAT.bat`.
- `FFmpeg` không tìm thấy: kiểm tra `ffmpeg -version`, `ffprobe -version` trong PowerShell mới mở.
- Thiếu `torch/torchaudio`, lỗi DLL: xem `logs\install.log`, cài Microsoft Visual C++ Redistributable x64 nếu thông báo DLL yêu cầu.
- Model không tải được: kiểm tra Internet, firewall/SSL; chạy lại `02_TACH_GIONG.bat` sau khi khắc phục.
- Màn hình không mở: dùng `05_TACH_BANG_LENH.bat`.
- CPU xử lý bị chậm: sử dụng một đoạn nhạc ngắn; tác vụ tách nhiều phút có thể tốn tài nguyên.
- File WAV quá lớn không upload được lên website: ưu tiên dùng `vocals_cho_sheet.wav`, hoặc cắt ngắn đoạn. AudioSheet Studio v1.0.7 mặc định giới hạn **600 giây/80 MB**. Có thể chuyển file dài sang MP3 bằng FFmpeg, ví dụ:

```bat
ffmpeg -i "vocals.wav" -codec:a libmp3lame -b:a 192k "vocals.mp3"
```

## Bản quyền và nguồn

- Demucs: https://github.com/facebookresearch/demucs (mã nguồn MIT). Repo gốc được lưu trữ và không còn duy trì chủ động; chương trình ghim bản tương thích 4.0.1.
- PyTorch (CPU): https://pytorch.org/get-started/previous-versions/
- **Không kèm** file nhạc gốc, model weights, bản ghi có bản quyền hoặc thư viện nhị phân lớn. Script tải qua nguồn chính thức khi cài.
- Chỉ dùng bản ghi có quyền khai thác. Việc tách giọng **không** làm thay đổi bản quyền bài hát.
