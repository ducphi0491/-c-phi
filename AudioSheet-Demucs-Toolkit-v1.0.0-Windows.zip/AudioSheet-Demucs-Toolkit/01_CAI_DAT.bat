@echo off
setlocal
cd /d "%~dp0"
title AudioSheet Demucs - Cai dat
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1"
set "CODE=%ERRORLEVEL%"
echo.
if "%CODE%"=="0" (
    echo [OK] Hoan thanh. Hay mo 02_TACH_GIONG.bat
) else (
    echo [LOI] Cai dat chua xong. Xem logs\install.log
)
pause
exit /b %CODE%
