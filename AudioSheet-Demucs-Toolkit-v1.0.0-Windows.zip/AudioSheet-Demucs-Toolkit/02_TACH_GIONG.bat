@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title AudioSheet Demucs - Tach giong
if not exist "%~dp0.venv-demucs\Scripts\python.exe" (
    echo [CHUA CAI] Chay 01_CAI_DAT.bat truoc.
    pause
    exit /b 1
)
"%~dp0.venv-demucs\Scripts\python.exe" "%~dp0scripts\gui.py"
set "CODE=%ERRORLEVEL%"
if "%CODE%"=="2" (
    echo [THONG BAO] Tkinter khong hoat dong, su dung che do dong lenh.
    "%~dp0.venv-demucs\Scripts\python.exe" "%~dp0scripts\separator.py"
    set "CODE=!ERRORLEVEL!"
)
if not "%CODE%"=="0" (
    echo [LOI] Xem logs\last_run.log de biet chi tiet.
    pause
)
exit /b %CODE%
