from __future__ import annotations

import sys
from types import SimpleNamespace
from pathlib import Path

from app import pdf_export
from app.live_score import create_arrangement_xml


class FakeToolkit:
    def setOptions(self, options):
        self.options = options

    def loadData(self, xml):
        return bool(xml)

    def getPageCount(self):
        return 1

    def renderToSVG(self, page, xml_declaration):
        return '''<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1100" viewBox="0 0 800 1100">
        <rect x="1" y="1" width="798" height="1098" fill="white" stroke="black"/>
        <text x="60" y="90" font-size="28">AudioSheet PDF test</text>
        <line x1="60" y1="160" x2="740" y2="160" stroke="black"/>
        </svg>'''


def test_verovio_pdf_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setitem(sys.modules, 'verovio', SimpleNamespace(toolkit=lambda: FakeToolkit()))
    monkeypatch.setattr(pdf_export, 'find_musescore', lambda: None)
    xml_path = tmp_path / 'score.musicxml'
    xml_path.write_bytes(create_arrangement_xml(
        [{'start': 0, 'end': .8, 'pitch': 60, 'velocity': 80}],
        'melody', 'PDF demo', 100, '4/4', 16, 60, 1.0,
    ))
    pdf_path = tmp_path / 'score.pdf'
    engine = pdf_export.export_musicxml_to_pdf(xml_path, pdf_path)
    assert engine == 'verovio'
    assert pdf_path.read_bytes().startswith(b'%PDF')
    assert pdf_path.stat().st_size > 500
