from __future__ import annotations

import importlib
import importlib.metadata
import platform
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "installed"


def check_import(name: str, package_name: str | None = None) -> bool:
    try:
        importlib.import_module(name)
        print(f"[OK] {name}: {package_version(package_name or name.split('.')[0])}")
        return True
    except Exception as exc:
        print(f"[THIEU/LOI] {name}: {exc}")
        return False


def check_demucs_optional() -> bool:
    candidates = [
        ROOT / ".demucs-venv" / "Scripts" / "python.exe",
        ROOT / ".demucs-venv" / "bin" / "python",
    ]
    python = next((item for item in candidates if item.is_file()), None)
    if not python:
        print("[TUY CHON] Demucs chua cai; CHAY_WEBSITE.bat se tu cai khi can")
        return False
    try:
        completed = subprocess.run(
            [str(python), str(ROOT / "scripts" / "check_demucs.py")],
            capture_output=True,
            text=True,
            timeout=30,
            check=True,
        )
        print("[OK] Demucs isolated environment")
        print(completed.stdout.strip())
        return True
    except Exception as exc:
        print(f"[CANH BAO] Demucs environment loi: {exc}")
        return False


def main() -> int:
    print(f"Python: {platform.python_version()} ({sys.executable})")
    py_ok = sys.version_info[:2] == (3, 11)
    print("[OK] Python 3.11" if py_ok else "[LOI] Can dung Python 3.11 cho Basic Pitch 0.4.0")

    ok = py_ok
    for command in ("ffmpeg", "ffprobe"):
        path = shutil.which(command)
        print(f"[OK] {command}: {path}" if path else f"[THIEU] {command}")
        ok = ok and bool(path)

    node = shutil.which("node")
    print(f"[OK] node: {node}" if node else "[TUY CHON] Node.js ho tro YouTube on dinh hon")

    required = (
        ("fastapi", "fastapi"),
        ("music21", "music21"),
        ("tensorflow", "tensorflow"),
        ("basic_pitch", "basic-pitch"),
        ("basic_pitch.inference", "basic-pitch"),
        ("yt_dlp", "yt-dlp"),
        ("resampy", "resampy"),
        ("pkg_resources", "setuptools"),
        ("pretty_midi", "pretty-midi"),
        ("verovio", "verovio"),
        ("reportlab", "reportlab"),
        ("svglib.svglib", "svglib"),
    )
    for module, package in required:
        ok = check_import(module, package) and ok

    osmd = ROOT / "web" / "vendor" / "opensheetmusicdisplay.min.js"
    print(f"[OK] local OSMD: {osmd}" if osmd.exists() else "[TUY CHON] OSMD local thieu; website se thu CDN")
    check_demucs_optional()
    print("[OK] Thanh phan cot loi san sang" if ok else "[LOI] Con thanh phan cot loi bi thieu")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
