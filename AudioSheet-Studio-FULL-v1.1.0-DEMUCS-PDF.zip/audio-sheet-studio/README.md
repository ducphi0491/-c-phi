# AudioSheet Studio 1.1.0 - Demucs, 3 pipelines and PDF

AudioSheet Studio is a local-first Windows web application that converts an authorized audio file or YouTube source into three related outputs:

- **A - Giai điệu hát:** vocal stem -> melody line -> one-staff score.
- **B - Piano dễ chơi:** melody plus generated bass/chord accompaniment -> two-staff piano score.
- **C - Phiên âm đầy đủ:** vocal, bass and pitched accompaniment stems -> fuller two-staff score.

Each mode has synchronized piano playback, MIDI, MusicXML and PDF export.

## One-click Windows start

1. Install Python 3.11 and FFmpeg.
2. Extract the project to `C:\audio-sheet-studio`.
3. Double-click `CHAY_WEBSITE.bat`.

The launcher installs the core Python environment, the isolated Demucs/PyTorch CPU environment, the PDF renderer and the 30 Salamander piano samples when they are missing. The first installation is large; the first stem-separation job also downloads the selected Demucs model.

## PDF export

MuseScore 4 is optional. When MuseScore is not configured, AudioSheet uses Verovio to engrave MusicXML and ReportLab to write the PDF. The result page exposes PDF A, PDF B and PDF C independently.

## Architecture

```text
Input audio / authorized YouTube
  -> FFmpeg normalization
  -> Demucs: vocals / bass / drums / other
  -> Basic Pitch per pitched stem
  -> note cleanup, key/chord analysis, A/B/C arrangements
  -> MusicXML + MIDI + PDF
  -> OSMD sheet view + sampled-piano playback
```

Demucs lives in `.demucs-venv`; Basic Pitch/TensorFlow lives in `.venv`. This separation avoids dependency conflicts.

## Important limitations

- AI transcription is an estimate and should be reviewed by ear.
- Full songs with reverb, backing vocals and dense production may still produce wrong notes.
- Mode B is an automatically generated playable reduction, not an exact human piano arrangement.
- Drum stems are not converted into pitched piano notes.
- Public Internet deployment still needs authentication, rate limiting, cleanup and a proper worker queue.
