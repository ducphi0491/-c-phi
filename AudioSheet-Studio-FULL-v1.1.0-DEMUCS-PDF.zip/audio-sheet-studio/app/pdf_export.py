from __future__ import annotations

import io
import os
import shutil
from pathlib import Path
from typing import Any

from .audio_tools import run_command
from .config import settings


class PDFExportError(RuntimeError):
    pass


def find_musescore() -> str | None:
    candidates: list[str] = [
        settings.musescore_bin,
        "MuseScore4",
        "musescore4",
        "mscore4",
        "MuseScore3",
        "musescore3",
        "mscore",
    ]
    if os.name == "nt":
        for base_name in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
            base = os.getenv(base_name)
            if not base:
                continue
            candidates.extend(
                [
                    str(Path(base) / "MuseScore 4" / "bin" / "MuseScore4.exe"),
                    str(Path(base) / "MuseScore 4" / "bin" / "MuseScore.exe"),
                    str(Path(base) / "MuseScore 3" / "bin" / "MuseScore3.exe"),
                ]
            )
    for candidate in candidates:
        if not candidate:
            continue
        explicit = Path(candidate)
        if explicit.is_file():
            return str(explicit)
        located = shutil.which(candidate)
        if located:
            return located
    return None


def _export_with_musescore(musicxml_path: Path, pdf_path: Path) -> bool:
    executable = find_musescore()
    if not executable:
        return False
    try:
        run_command([executable, "-o", str(pdf_path), str(musicxml_path)], timeout=300)
        return pdf_path.is_file() and pdf_path.stat().st_size > 500
    except Exception:
        pdf_path.unlink(missing_ok=True)
        return False


def _verovio_available() -> bool:
    try:
        import verovio  # noqa: F401
        from reportlab.graphics import renderPDF  # noqa: F401
        from svglib.svglib import svg2rlg  # noqa: F401
        return True
    except Exception:
        return False


def _export_with_verovio(musicxml_path: Path, pdf_path: Path) -> bool:
    try:
        import verovio
        from reportlab.graphics import renderPDF
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from svglib.svglib import svg2rlg

        xml = musicxml_path.read_text(encoding="utf-8")
        toolkit = verovio.toolkit()
        toolkit.setOptions(
            {
                "inputFrom": "musicxml",
                "pageWidth": 2100,
                "pageHeight": 2970,
                "scale": 38,
                "adjustPageHeight": False,
                "breaks": "auto",
                "header": "none",
                "footer": "none",
                "pageMarginTop": 70,
                "pageMarginBottom": 70,
                "pageMarginLeft": 70,
                "pageMarginRight": 70,
            }
        )
        loaded = toolkit.loadData(xml)
        if loaded is False:
            raise PDFExportError("Verovio could not load the MusicXML")
        page_count = max(1, int(toolkit.getPageCount()))
        page_width, page_height = A4
        margin = 24.0
        pdf_path.parent.mkdir(parents=True, exist_ok=True)
        pdf = canvas.Canvas(str(pdf_path), pagesize=A4)
        pdf.setTitle(musicxml_path.stem)
        for page_number in range(1, page_count + 1):
            svg = toolkit.renderToSVG(page_number, False)
            drawing = svg2rlg(io.BytesIO(svg.encode("utf-8")))
            if drawing is None or not drawing.width or not drawing.height:
                raise PDFExportError(f"Could not convert Verovio SVG page {page_number}")
            factor = min(
                (page_width - margin * 2) / float(drawing.width),
                (page_height - margin * 2) / float(drawing.height),
            )
            drawing.scale(factor, factor)
            x = (page_width - float(drawing.width) * factor) / 2
            y = page_height - margin - float(drawing.height) * factor
            renderPDF.draw(drawing, pdf, x, max(margin, y))
            pdf.showPage()
        pdf.save()
        return pdf_path.is_file() and pdf_path.stat().st_size > 500
    except Exception as exc:
        pdf_path.unlink(missing_ok=True)
        raise PDFExportError(f"Verovio PDF export failed: {exc}") from exc


def export_musicxml_to_pdf(musicxml_path: Path, pdf_path: Path) -> str:
    """Export an actual notation PDF and return the engine name.

    MuseScore is preferred when present. Otherwise the bundled Python stack
    uses Verovio to engrave MusicXML into SVG pages and ReportLab to write PDF.
    """
    if not musicxml_path.is_file():
        raise PDFExportError(f"MusicXML file not found: {musicxml_path}")
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    if _export_with_musescore(musicxml_path, pdf_path):
        return "musescore"
    if _export_with_verovio(musicxml_path, pdf_path):
        return "verovio"
    raise PDFExportError("No PDF renderer is available")


def pdf_engine_status() -> dict[str, Any]:
    musescore = find_musescore()
    verovio = _verovio_available()
    return {
        "available": bool(musescore or verovio),
        "preferred": "musescore" if musescore else "verovio" if verovio else None,
        "musescore": bool(musescore),
        "verovio": verovio,
    }
