# AudioSheet Studio 1.1.0 - 2026-11-03

## Main changes

- Integrates Demucs directly into the website processing pipeline.
- Runs Demucs in a separate `.demucs-venv` so PyTorch does not conflict with TensorFlow/Basic Pitch.
- Replaces the old three-filter behavior with three real processing pipelines for newly processed jobs:
  - A: vocal melody.
  - B: easy piano arrangement.
  - C: fuller stem-based transcription.
- Adds note sorting, fragment joining, conservative octave-harmonic suppression and dynamic-programming melody selection.
- Adds key estimation and chord timeline analysis.
- Uses one Piano part with two staves for B/C MusicXML.
- Exports MIDI, MusicXML and PDF for A, B and C.
- Adds dynamic PDF regeneration after importing a reference MIDI for mode C.
- Adds Verovio + ReportLab PDF fallback; MuseScore remains an optional preferred renderer.
- Exposes model/pipeline information in `pipeline_manifest.json`.
- Publishes safe root-level stem files instead of nested artifact paths.
- Keeps completed v1.0.x jobs usable through the legacy fallback pipeline.

## Verification in the build environment

- Python compilation: passed.
- JavaScript syntax: passed.
- Automated tests: 19 passed.
- Full mocked job flow: stem separation -> transcription -> A/B/C -> MIDI/MusicXML/PDF: passed.
- PDF fallback flow with a simulated Verovio SVG page: passed and produced a valid PDF.

## Not executed here

The build environment did not have Internet access or a Windows PyTorch/Demucs installation, so a real Demucs model download and real full-song inference were not executed here. The included Windows installer performs those steps on the target machine.
