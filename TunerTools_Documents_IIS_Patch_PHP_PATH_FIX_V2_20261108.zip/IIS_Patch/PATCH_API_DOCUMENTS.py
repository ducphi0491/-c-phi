#!/usr/bin/env python3
"""Patch the existing IIS PHP IN PLACE only with explicit operator flag.
Creates a full backup; NEVER packages or prints DB/session credentials.
"""
import argparse, datetime, hashlib, pathlib, shutil, subprocess, sys, os, tempfile
ROOT=pathlib.Path(__file__).resolve().parent
HELPER=(ROOT/'iis_helpers.php.fragment').read_text(encoding='utf-8')
TAG='// TT DOCUMENT PERMISSIONS IIS -> DRIVE ATOMIC SYNC v2'

def patched(s):
    if TAG in s:
        if s.count(TAG)!=1: raise ValueError('inconsistent patch markers')
        return s
    anchor='function permissionPayload(array $permission): array\n'
    if s.count(anchor)!=1: raise ValueError('permissionPayload anchor absent/changed')
    s=s.replace(anchor, HELPER+'\n\n'+anchor, 1)
    anchor="        $identity = resolveDocumentLoginIdentity();\n"
    if s.count(anchor)!=1: raise ValueError('auth_login anchor changed')
    s=s.replace(anchor,"""        // Secure new clients: never trust an email field if an ID token exists.
        $idTokenNew = requestValue('id_token','');
        $identity = $idTokenNew !== ''
            ? ttdIisGoogleIdentity($idTokenNew) : resolveDocumentLoginIdentity();
""",1)
    # Apply verified Google identity check only to dangerous mutation actions.
    for action,next_action in [('permission_save','permission_delete'),('permission_delete','')]:
        block_start=s.index("    if ($action === '%s') {"%action)
        block_end=s.index("    if ($action === '%s') {"%next_action,block_start) if next_action else s.index('    $instrumentKey = strtolower(',block_start)
        block=s[block_start:block_end]
        auth="        requirePermissionFlag($manager, 'can_manage', 'Bạn không có quyền quản lý tài liệu.');\n"
        if block.count(auth)!=1: raise ValueError('admin guard missing in '+action)
        block=block.replace(auth,auth+'        ttdIisRequireVerifiedManager($manager);\n',1)
        if action=='permission_save':
            tail="        $saved = findPermissionByEmail($db, $email);\n        sendJson([\n"
            if block.count(tail)!=1: raise ValueError('save success anchor changed')
            block=block.replace(tail,"""        $saved = findPermissionByEmail($db, $email);
        $driveSync = ttdIisPushPermissions($db);
        sendJson([
            'drive_sync_status' => $driveSync['code'],
""",1)
        else:
            tail="        mysqliExecuteNonQuery($db, 'DELETE FROM document_permissions WHERE id = ?', [$permissionId]);\n        sendJson(['success' => true, 'message' => 'Đã xóa quyền tài liệu.']);"
            if block.count(tail)!=1: raise ValueError('delete success anchor changed')
            block=block.replace(tail,"""        mysqliExecuteNonQuery($db, 'DELETE FROM document_permissions WHERE id = ?', [$permissionId]);
        $driveSync = ttdIisPushPermissions($db);
        sendJson(['success' => true, 'drive_sync_status' => $driveSync['code'],
            'message' => $driveSync['ok'] ? 'Đã xóa và đồng bộ quyền lên Drive.' :
                'Đã xóa MySQL; đồng bộ Drive chưa thành công, hãy nhấn Đồng bộ lại.']);""",1)
        s=s[:block_start]+block+s[block_end:]
    # Prevent the older email-only IIS sessions from leaking the whole user roster.
    for action in ('permission_list','permission_folder_options'):
        block_start=s.index("    if ($action === '%s') {"%action)
        block_end=s.index("    if ($action === '",block_start+1)
        block=s[block_start:block_end]
        needle="        requirePermissionFlag($manager, 'can_manage', "
        guard_start=block.find(needle)
        if guard_start<0: raise ValueError(action+' manager guard missing')
        guard_end=block.index('\n',guard_start)+1
        block=block[:guard_end]+"        ttdIisRequireVerifiedManager($manager);\n"+block[guard_end:]
        s=s[:block_start]+block+s[block_end:]
    # Admin explicit resync button, requires Google verification. Reuses original file ID.
    marker="    $instrumentKey = strtolower(requestValue('instrument', 'guitar'));\n"
    if s.count(marker)<1: raise ValueError('instrument dispatch anchor changed')
    index=s.rfind(marker)
    s=s[:index]+"""    if ($action === 'permission_sync_now') {
        if ($method !== 'POST') sendJson(['success'=>false,'code'=>'method_not_allowed'],405);
        $manager = requireDocumentSession($db);
        requirePermissionFlag($manager, 'can_manage', 'Chỉ Admin mới có thể đồng bộ quyền.');
        ttdIisRequireVerifiedManager($manager);
        $result = ttdIisPushPermissions($db);
        sendJson(['success'=>$result['ok'], 'code'=>$result['code'],
            'drive_sync_status'=>$result['code'],
            'message'=>$result['ok'] ? 'Đã đối chiếu quyền MySQL với Drive.' :
                'Drive chưa được cập nhật. Hãy kiểm tra cấu hình IIS và Alwaysdata.'],
            $result['ok'] ? 200 : 503);
    }
"""+s[index:]
    return s

def find_php_executable(hint=''):
    """PHP CLI might be available to IIS but missing from a PowerShell/Python PATH."""
    candidates = []
    if hint:
        requested = pathlib.Path(hint)
        if not requested.is_file():
            raise ValueError('The --php path does not exist: ' + hint)
        candidates.append(str(requested))
    else:
        for name in ('php.exe', 'php'):
            found = shutil.which(name)
            if found:
                candidates.append(found)
        if sys.platform == 'win32':
            for name in (
                r'C:\PHP\php.exe', r'C:\php\php.exe',
                r'C:\Program Files\PHP\php.exe',
                r'C:\Program Files (x86)\PHP\php.exe',
                r'C:\TunerTools\PHP\php.exe',
                r'C:\TunerTools\Web\PHP\php.exe',
                r'C:\inetpub\php\php.exe',
            ):
                if pathlib.Path(name).is_file():
                    candidates.append(name)
            # Reuse the same IIS FastCGI clue as the successful stage-1 export.
            appcmd = pathlib.Path(os.environ.get('WINDIR', r'C:\Windows')) / 'System32' / 'inetsrv' / 'appcmd.exe'
            if appcmd.is_file():
                try:
                    r = subprocess.run(
                        [str(appcmd), 'list', 'config', '-section:system.webServer/fastCgi'],
                        capture_output=True, text=True, timeout=8
                    )
                    import re
                    for match in re.finditer(r'[A-Za-z]:\\[^"\r\n]*?php-cgi\.exe', r.stdout, re.IGNORECASE):
                        php_exe = pathlib.Path(match.group(0)).parent / 'php.exe'
                        if php_exe.is_file():
                            candidates.append(str(php_exe))
                except (OSError, subprocess.TimeoutExpired):
                    pass
            for root in (
                pathlib.Path(r'C:\PHP'), pathlib.Path(r'C:\Program Files\PHP'),
                pathlib.Path(r'C:\Program Files (x86)\PHP'), pathlib.Path(r'C:\inetpub\php'),
            ):
                if root.is_dir():
                    try:
                        for path in root.glob('**/php.exe'):
                            candidates.append(str(path))
                            break
                    except OSError:
                        pass
    for candidate in dict.fromkeys(candidates):
        if pathlib.Path(candidate).name.lower() == 'php-cgi.exe':
            continue
        try:
            r = subprocess.run([candidate, '-v'], capture_output=True, text=True, timeout=8)
            if r.returncode == 0 and 'PHP' in r.stdout:
                return candidate
        except (OSError, subprocess.TimeoutExpired):
            continue
    raise ValueError('PHP CLI php.exe not found. Supply --php "C:\\path\\php.exe". '
                     'Stage 1 already used a PHP executable; check RUN_DOCUMENT_PERMISSIONS.ps1.')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',required=True)
    ap.add_argument('--php',default='',help='full path to PHP CLI php.exe, not php-cgi.exe')
    ap.add_argument('--check',action='store_true',help='lint the patched PHP without writing to the IIS source')
    ap.add_argument('--install',action='store_true')
    ap.add_argument('--out',help='write a patched copy instead of modifying IIS')
    args=ap.parse_args()
    src=pathlib.Path(args.source)
    if not src.is_file(): raise ValueError('api_documents.php original not found: '+str(src))
    original=src.read_bytes()
    if original.startswith(b'\xef\xbb\xbf'): raise ValueError('PHP UTF-8 BOM is unexpected')
    newline='\r\n' if b'\r\n' in original else '\n'
    s=original.decode('utf-8').replace('\r\n','\n')
    out=patched(s).replace('\n',newline).encode('utf-8')
    if out==original: print('ALREADY_PATCHED: nothing to do');return
    php=find_php_executable(args.php)
    print('PHP_CLI_FOUND:', php)
    if args.check:
        if args.install or args.out: raise ValueError('--check is incompatible with --install/--out')
        with tempfile.TemporaryDirectory(prefix='ttdocs_lint_') as td:
            preview = pathlib.Path(td) / 'api_documents_preview.php'
            preview.write_bytes(out)
            result = subprocess.run([php, '-l', str(preview)],capture_output=True,text=True)
            if result.returncode: raise ValueError('PHP lint failed: '+result.stdout+' '+result.stderr)
            print('PATCH_CHECK_OK: '+result.stdout.strip())
        return
    if args.install:
        if sys.platform != 'win32': raise ValueError('--install is intended for Windows Server')
        backup_dir=pathlib.Path(r'C:\TunerTools\Backups\Documents')
        backup_dir.mkdir(parents=True,exist_ok=True)
        acl=subprocess.run(['icacls',str(backup_dir),'/inheritance:r',
                            '/grant:r','Administrators:(OI)(CI)F','SYSTEM:(OI)(CI)F'],
                            capture_output=True,text=True)
        if acl.returncode != 0:
            raise ValueError('Cannot protect private PHP backup directory with icacls')
        backup=backup_dir/(src.name+'.backup_DrivePrimary_'+datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S')+'.bak')
        shutil.copy2(src,backup)
        file_acl=subprocess.run(['icacls',str(backup),'/inheritance:r',
                                 '/grant:r','Administrators:F','SYSTEM:F'],
                                capture_output=True,text=True)
        if file_acl.returncode != 0:
            backup.unlink(missing_ok=True)
            raise ValueError('Cannot secure private PHP backup file with icacls')
        print('SECURE_BACKUP:',backup)
        # Same-directory temporary PHP enables atomic replacement without ACL drift.
        handle,temp_path=tempfile.mkstemp(prefix='.ttd_patch_',suffix='.php',dir=str(src.parent))
        os.close(handle)
        dest=pathlib.Path(temp_path)
    elif args.out:
        dest=pathlib.Path(args.out)
    else:
        raise ValueError('Must specify --out for preview or --install for in-place patch')
    try:
        dest.write_bytes(out)
        r=subprocess.run([php,'-l',str(dest)],capture_output=True,text=True)
        if r.returncode:
            raise ValueError('PHP lint failed; original untouched: '+r.stdout+' '+r.stderr)
        print(r.stdout.strip())
        if args.install:
            os.replace(str(dest),str(src))
    finally:
        if args.install and dest.is_file(): dest.unlink()
    print('PATCH_OK; sha256='+hashlib.sha256(out).hexdigest()+'; no DB or Android changes made')

if __name__=='__main__':
    try: main()
    except Exception as e:
        print('PATCH_FAILED:',e)
        sys.exit(1)
