TUNERTOOLS - DOCUMENTS DRIVE PRIMARY - IIS PATCH PHP DISCOVERY FIX
=================================================================

VAN DE DA KHAC PHUC
  PATCH_FAILED: PHP CLI is required to check syntax before installation
Nguyen nhan: Python truoc do chi tim php trong PATH. Windows IIS co the
su dung PHP o vi tri rieng, khong nam trong PATH.

BAN NAY CHI SUA 1 FILE PYTHON; KHONG SUA MYSQL, JSON, ANDROID HAY ALWAYSdata.
File iis_helpers.php.fragment di kem van giu nguyen tu bo Drive Primary.

CACH THAY
  1. Giai nen vao C:\TunerTools\Tools\Documents_DrivePrimary\ (ghi de file
     IIS_Patch\PATCH_API_DOCUMENTS.py; fragment khong can thay neu da co).
  2. Mo PowerShell Administrator.
  3. Chay:

     cd C:\TunerTools\Tools\Documents_DrivePrimary\IIS_Patch
     python .\PATCH_API_DOCUMENTS.py --source "C:\TunerTools\Web\API\api_documents.php" --check

     Khi thay PHP CLI tu dong se in PHP_CLI_FOUND: <duong dan>.
     Thanh cong se in PATCH_CHECK_OK.
  4. CHI KHI Alwaysdata OAUTH_READY=True va da cau hinh bien moi truong
     o ca IIS/Alwaysdata, moi chay:

     python .\PATCH_API_DOCUMENTS.py --source "C:\TunerTools\Web\API\api_documents.php" --install

  5. Neu van khong tu tim PHP, hay tim bang PowerShell:
     Get-Command php.exe -ErrorAction SilentlyContinue
     Get-ChildItem -Path 'C:\PHP','C:\Program Files\PHP','C:\TunerTools\PHP','C:\inetpub\php' -Filter php.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 10 -ExpandProperty FullName

     Sau do chi dinh ro PHP CLI (VD, thay path bang duong dan THUC TE):
     python .\PATCH_API_DOCUMENTS.py --source "C:\TunerTools\Web\API\api_documents.php" --check --php "C:\PHP\php.exe"

OAUTH_READY=False
  health API hien tai kiem tra CA HAI bien:
  - TUNERTOOLS_DOCUMENTS_WEB_CLIENT_ID=...apps.googleusercontent.com
  - TUNERTOOLS_DOCUMENT_SESSION_SECRET=chuoi_bi_mat_dai_toi_thieu_48_ky_tu
  Them cac bien vao moi truong thuc thi PHP cua Alwaysdata, restart site,
  roi chay lai 02_KIEM_TRA_ALWAYS_DATA.ps1 de xac nhan DRIVE_PRIMARY_READY.

  IIS can:
  - TUNERTOOLS_DOCUMENTS_WEB_CLIENT_ID (giong Alwaysdata)
  - TUNERTOOLS_DOCUMENT_SYNC_SHARED_SECRET (giong Alwaysdata)

CANH BAO
  Hai khoa bao mat da dan vao hoi thoai truoc do phai BO va tao moi.
  Khong gui token/khoa bi mat/noi dung file JSON/roster nguoi dung.
  File JSON Drive da co khong bi tao lai; patch chi cap nhat cung file khi
  Admin cap/sua/xoa quyen sau khi trien khai.

KIEM TRA THUC HIEN
  - python -m py_compile: OK
  - --check tren api_documents (4).php + PHP CLI: OK
  - --out PHP da patch + php -l: OK
  - KHONG chay --install tren Windows that; can test sau khi cai.
