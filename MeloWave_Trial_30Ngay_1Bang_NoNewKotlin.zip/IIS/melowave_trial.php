<?php
/**
 * MeloWave: guest Premium trial API, exactly ONE MySQL table: mw_trial_devices.
 * Keep existing paid-premium API meloware_premium.php unchanged.
 * Anonymous trial eligibility is best-effort, NOT proof of physical device identity.
 * JSON actions: health, status, start. First playback triggers start, never status.
 */
declare(strict_types=1);
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
error_reporting(E_ALL);
require_once __DIR__ . '/melowave_trial_lib.php';

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
    mwt_json(['ok' => false, 'message' => 'POST required'], 405);
}
if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 4096) {
    mwt_json(['ok' => false, 'message' => 'Request too large'], 413);
}

try {
    $raw = (string) file_get_contents('php://input', false, null, 0, 4097);
    $input = json_decode($raw, true);
    if (!is_array($input)) mwt_json(['ok' => false, 'message' => 'JSON invalid'], 400);
    $action = (string) ($input['action'] ?? '');
    if (!in_array($action, ['health', 'status', 'start'], true)) {
        mwt_json(['ok' => false, 'message' => 'Unsupported action'], 400);
    }

    $config = mwt_config();
    if ($action === 'health') {
        // Verify that the SINGLE intended table and all needed columns exist.
        $db = mwt_db($config);
        $db->query('SELECT device_key, first_seen_at, last_seen_at, last_active_day, '
            . 'active_days, first_played_at, trial_expires_at, returned_d1, returned_d7, '
            . 'returned_d30 FROM mw_trial_devices LIMIT 0')->free();
        $db->close();
        mwt_json(['ok' => true, 'trialApi' => 'ready', 'trialEnabled' => $config['enabled']]);
    }

    // On Android >= 8, ANDROID_ID is scoped to device/user/app signing key.
    // Never store or log this input; it is HMAC-hashed with a SERVER-ONLY secret.
    $androidId = strtolower(trim((string) ($input['androidId'] ?? '')));
    if (!preg_match('/^[a-f0-9]{16,32}$/D', $androidId)) {
        mwt_json(['ok' => false, 'message' => 'Invalid device identifier'], 400);
    }
    if (!$config['enabled']) {
        mwt_json([
            'ok' => true, 'trialState' => 'disabled', 'access' => false,
            'startedAtMillis' => 0, 'expiresAtMillis' => 0,
            'serverTimeMillis' => time() * 1000, 'enforceFeatures' => false
        ]);
    }

    $deviceKey = mwt_hash('device', $androidId, $config);
    $db = mwt_db($config);
    $db->begin_transaction();
    try {
        // Start of a NEW DEVICE'S history = first API request, NOT start of Premium trial.
        // Time UTC comes from MySQL, never Android.
        $s = $db->prepare('INSERT IGNORE INTO mw_trial_devices '
            . '(device_key, first_seen_at, last_seen_at, last_active_day, active_days) '
            . 'VALUES (?, UTC_TIMESTAMP(), UTC_TIMESTAMP(), UTC_DATE(), 1)');
        $s->bind_param('s', $deviceKey);
        $s->execute();
        $s->close();

        // Lock row so simultaneous status/start requests cannot restart the 30-day clock.
        $s = $db->prepare('SELECT device_key FROM mw_trial_devices WHERE device_key = ? FOR UPDATE');
        $s->bind_param('s', $deviceKey);
        $s->execute();
        $s->bind_result($lockedKey);
        if (!$s->fetch() || !hash_equals($deviceKey, (string) $lockedKey)) {
            throw new RuntimeException('Device lookup failure');
        }
        $s->close();

        // A single table is enough for D1/D7/D30 day-exact return flags.
        // active_days counts DISTINCT UTC DAYS, not each opening/refresh call.
        // last_active_day MUST be updated last to preserve the old day in the count.
        $s = $db->prepare('UPDATE mw_trial_devices SET '
            . 'last_seen_at = UTC_TIMESTAMP(), '
            . 'active_days = active_days + IF(last_active_day < UTC_DATE(), 1, 0), '
            . 'returned_d1 = IF(returned_d1 = 1 OR DATEDIFF(UTC_DATE(), DATE(first_seen_at)) = 1, 1, 0), '
            . 'returned_d7 = IF(returned_d7 = 1 OR DATEDIFF(UTC_DATE(), DATE(first_seen_at)) = 7, 1, 0), '
            . 'returned_d30 = IF(returned_d30 = 1 OR DATEDIFF(UTC_DATE(), DATE(first_seen_at)) = 30, 1, 0), '
            . 'last_active_day = UTC_DATE() WHERE device_key = ?');
        $s->bind_param('s', $deviceKey);
        $s->execute();
        $s->close();

        if ($action === 'start') {
            // A single UPDATE sets both times. Once first_played_at is non-null,
            // NO further start request can extend/restart the 30-day trial.
            $s = $db->prepare('UPDATE mw_trial_devices SET '
                . 'first_played_at = UTC_TIMESTAMP(), '
                . 'trial_expires_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 DAY) '
                . 'WHERE device_key = ? AND first_played_at IS NULL');
            $s->bind_param('s', $deviceKey);
            $s->execute();
            $s->close();
        }

        $s = $db->prepare('SELECT UNIX_TIMESTAMP(first_played_at), '
            . 'UNIX_TIMESTAMP(trial_expires_at), UNIX_TIMESTAMP(UTC_TIMESTAMP()) '
            . 'FROM mw_trial_devices WHERE device_key = ?');
        $s->bind_param('s', $deviceKey);
        $s->execute();
        $s->bind_result($started, $expiry, $serverNow);
        if (!$s->fetch()) throw new RuntimeException('Device row missing');
        $s->close();
        $db->commit();
    } catch (Throwable $exception) {
        try { $db->rollback(); } catch (Throwable $ignored) {}
        throw $exception;
    }
    $db->close();

    $nowSeconds = (int) $serverNow;
    $startSeconds = (int) ($started ?? 0);
    $expirySeconds = (int) ($expiry ?? 0);
    $state = $startSeconds === 0 ? 'eligible' : ($expirySeconds > $nowSeconds ? 'active' : 'expired');
    mwt_json([
        'ok' => true,
        'trialState' => $state,
        'access' => $state === 'active',
        'trialDays' => 30,
        'startedAtMillis' => $startSeconds * 1000,
        'expiresAtMillis' => $expirySeconds * 1000,
        'serverTimeMillis' => $nowSeconds * 1000,
        'enforceFeatures' => true
    ]);
} catch (Throwable $exception) {
    // Never log Android ID or secret, SQL details, client body or personal data.
    error_log('MeloWave guest-trial error (' . get_class($exception) . ')');
    mwt_json(['ok' => false, 'message' => 'MeloWave trial server not ready'], 503);
}
