<?php
/** Read-only MeloWave guest-trial monitoring. Protected by a separate server password. */
declare(strict_types=1);
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
error_reporting(E_ALL);
require_once __DIR__ . '/melowave_trial_lib.php';

header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'");

$isHttps = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
$isLocalhost = in_array((string) ($_SERVER['REMOTE_ADDR'] ?? ''), ['127.0.0.1', '::1'], true);
if (!$isHttps && !$isLocalhost) { http_response_code(403); exit('HTTPS required'); }
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('melowave_trial_admin');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/melowave/', 'secure' => $isHttps,
        'httponly' => true, 'samesite' => 'Strict'
    ]);
    session_start();
}
function e(mixed $value): string { return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function scalar(mysqli $db, string $sql): int {
    $r = $db->query($sql);
    $row = $r->fetch_row();
    $r->free();
    return (int) ($row[0] ?? 0);
}
$adminPassword = (string) getenv('MELOWAVE_TRIAL_ADMIN_PASSWORD');
$loginError = '';
if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$canLogin = strlen($adminPassword) >= 16;
if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) === 'POST') {
    if (!hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(403); exit('Invalid form');
    }
    if (isset($_POST['logout'])) {
        $_SESSION = [];
        session_destroy();
        header('Location: melowave_trial_admin.php'); exit;
    }
    $attempted = (int) ($_SESSION['attempts'] ?? 0);
    $blockedUntil = (int) ($_SESSION['blockedUntil'] ?? 0);
    if (!$canLogin) $loginError = 'Chua cau hinh MELOWAVE_TRIAL_ADMIN_PASSWORD (toi thieu 16 ky tu).';
    elseif (time() < $blockedUntil) $loginError = 'Thu lai sau 5 phut.';
    elseif (hash_equals($adminPassword, (string) ($_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['authenticated'] = true;
        $_SESSION['attempts'] = 0;
    } else {
        $_SESSION['attempts'] = $attempted + 1;
        if ($attempted + 1 >= 5) {
            $_SESSION['blockedUntil'] = time() + 300;
            $_SESSION['attempts'] = 0;
        }
        $loginError = 'Mat khau khong dung.';
    }
}
$authenticated = $canLogin && !empty($_SESSION['authenticated']);
$stats = [];
$devices = [];
$reportError = '';
if ($authenticated) {
    try {
        $db = mwt_db(mwt_config());
        $stats['devices'] = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices');
        $stats['eligible'] = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE first_played_at IS NULL');
        $stats['active'] = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE trial_expires_at > UTC_TIMESTAMP()');
        $stats['expired'] = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE first_played_at IS NOT NULL AND trial_expires_at <= UTC_TIMESTAMP()');
        $stats['today'] = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE last_active_day = UTC_DATE()');
        $stats['newToday'] = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE DATE(first_seen_at) = UTC_DATE()');
        $stats['activityDays'] = scalar($db, 'SELECT COALESCE(SUM(active_days), 0) FROM mw_trial_devices');
        foreach ([1, 7, 30] as $days) {
            $eligible = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE DATE(first_seen_at) <= DATE_SUB(UTC_DATE(), INTERVAL ' . $days . ' DAY)');
            $returned = scalar($db, 'SELECT COUNT(*) FROM mw_trial_devices WHERE returned_d' . $days . ' = 1');
            $stats['d' . $days] = $eligible > 0 ? number_format(100 * $returned / $eligible, 1) . '%' : '—';
            $stats['d' . $days . 'cohort'] = $eligible;
        }
        $rs = $db->query('SELECT LEFT(device_key, 10) AS short_key, first_seen_at, last_seen_at, '
            . 'first_played_at, trial_expires_at, active_days, '
            . 'CASE WHEN first_played_at IS NULL THEN \'Chua dung thu\' '
            . 'WHEN trial_expires_at > UTC_TIMESTAMP() THEN \'Dang dung thu\' ELSE \'Het han\' END AS state '
            . 'FROM mw_trial_devices ORDER BY last_seen_at DESC LIMIT 50');
        while ($row = $rs->fetch_assoc()) $devices[] = $row;
        $rs->free();
        $db->close();
    } catch (Throwable $error) {
        $reportError = 'Khong the doc du lieu. Kiem tra cau hinh MySQL, 1 bang SQL va IIS.';
        error_log('MeloWave trial admin error (' . get_class($error) . ')');
    }
}
?><!doctype html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>MeloWave - Trial & Retention</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Segoe UI,Arial,sans-serif}
*{box-sizing:border-box}body{background:#101322;color:#f2f3ff;margin:0;line-height:1.5}
main{max-width:1120px;margin:32px auto;padding:0 18px}.head{display:flex;gap:16px;align-items:center;justify-content:space-between;flex-wrap:wrap}
h1{font-size:25px;margin:0}.muted{color:#a7acc4;font-size:13px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:12px;margin-top:23px}
.card,section{background:#1b2035;border:1px solid #323952;border-radius:16px;padding:18px}.number{font-weight:750;font-size:28px;margin-top:7px}
section{margin-top:18px;overflow-x:auto}h2{font-size:17px;margin:0 0 14px}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:10px;border-bottom:1px solid #333952;white-space:nowrap}th{color:#a5b0d0}
input{display:block;background:#111528;color:#fff;border:1px solid #52618d;border-radius:9px;padding:11px 13px;margin:9px 0;width:100%;max-width:380px}
button,a.btn{color:#fff;background:#6e4cda;border:0;border-radius:9px;padding:10px 16px;cursor:pointer;font-weight:650;text-decoration:none}
.warn{background:#462d32;color:#ffd1d1;padding:11px;border-radius:9px;margin:13px 0}.status{border-radius:8px;padding:4px 9px;background:#293145;white-space:nowrap}
footer{margin:24px 0;color:#8992b1;font-size:12px}
</style></head><body><main><div class="head"><div><h1>👑 MeloWave — Trial & Retention</h1>
<div class="muted">Dùng thử Premium 30 ngày / thiết bị · 1 bảng MySQL · UTC · Không chứa Gmail, IMEI hoặc Android ID gốc</div></div>
<?php if ($authenticated): ?><form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><button type="submit" name="logout" value="1">Đăng xuất</button></form><?php endif; ?></div>
<?php if (!$authenticated): ?>
<section><h2>Đăng nhập quản trị</h2><?php if ($loginError !== ''): ?><div class="warn"><?= e($loginError) ?></div><?php endif; ?>
<?php if (!$canLogin): ?><div class="warn">Cần cấu hình biến môi trường MELOWAVE_TRIAL_ADMIN_PASSWORD dài tối thiểu 16 ký tự, sau đó khởi động lại IIS.</div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><label>Mật khẩu quản trị</label><input name="password" type="password" required autocomplete="current-password"><button type="submit">Đăng nhập</button></form></section>
<?php else: ?>
<?php if ($reportError !== ''): ?><div class="warn"><?= e($reportError) ?></div><?php endif; ?>
<?php if ($stats): ?>
<div class="cards">
<?php foreach ([
  'Thiết bị ghi nhận' => $stats['devices'], 'Thiết bị mới hôm nay' => $stats['newToday'],
  'Chưa bắt đầu' => $stats['eligible'], 'Đang dùng thử' => $stats['active'],
  'Đã hết hạn' => $stats['expired'], 'Hoạt động hôm nay' => $stats['today'],
  'Tổng ngày thiết bị hoạt động' => $stats['activityDays'],
  'D1 quay lại' => $stats['d1'], 'D7 quay lại' => $stats['d7'], 'D30 quay lại' => $stats['d30'],
] as $label => $value): ?>
<div class="card"><div class="muted"><?= e($label) ?></div><div class="number"><?= e($value) ?></div></div>
<?php endforeach; ?>
</div>
<section><h2>50 thiết bị gần đây (mã đã ẩn bớt)</h2>
<table><thead><tr><th>Mã HMAC rút gọn</th><th>Ghi nhận lần đầu</th><th>Hoạt động gần nhất</th><th>Số ngày đã hoạt động</th><th>Bắt đầu dùng thử</th><th>Hết hạn</th><th>Trạng thái</th></tr></thead><tbody>
<?php foreach ($devices as $r): ?><tr><td><code><?= e($r['short_key']) ?>…</code></td>
<td><?= e($r['first_seen_at']) ?></td><td><?= e($r['last_seen_at']) ?></td>
<td><?= e($r['active_days']) ?></td><td><?= e($r['first_played_at'] ?? '-') ?></td><td><?= e($r['trial_expires_at'] ?? '-') ?></td>
<td><span class="status"><?= e($r['state']) ?></span></td></tr><?php endforeach; ?>
</tbody></table></section>
<footer>D1/D7/D30 là tỷ lệ mã thiết bị quay lại đúng ngày +1/+7/+30 (UTC) từ lần ghi nhận đầu tiên; mẫu số chỉ gồm thiết bị đã đủ tuổi. Một bảng ghi cờ D1/D7/D30, không lưu lịch sử từng ngày hay số lượt cài đặt. Số thiết bị ≠ số người thật; đổi thiết bị hoặc khóa ký có thể tạo mã mới. Trang chỉ đọc dữ liệu.</footer>
<?php endif; ?><?php endif; ?></main></body></html>
