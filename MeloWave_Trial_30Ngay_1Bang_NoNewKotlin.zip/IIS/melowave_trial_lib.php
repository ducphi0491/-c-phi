<?php
/**
 * Internal-only helpers shared by the standalone anonymous-trial API and its admin page.
 * Keep this separate from meloware_premium.php: paid Google Play Billing remains untouched.
 * PHP 8+, mysqli. DO NOT copy database secrets into a publicly served PHP file.
 */
declare(strict_types=1);

function mwt_config(): array {
    $secret = base64_decode((string) getenv('MELOWAVE_TRIAL_HMAC_KEY_B64'), true);
    if ($secret === false || strlen($secret) < 32) {
        throw new RuntimeException('TRIAL_HMAC_NOT_CONFIGURED');
    }
    $user = (string) getenv('MELOWAVE_TRIAL_DB_USER');
    $password = (string) getenv('MELOWAVE_TRIAL_DB_PASSWORD');
    if ($user === '' || $password === '') {
        throw new RuntimeException('TRIAL_DB_NOT_CONFIGURED');
    }
    return [
        'hmac_key' => $secret,
        'db_host' => getenv('MELOWAVE_TRIAL_DB_HOST') ?: '127.0.0.1',
        'db_port' => (int) (getenv('MELOWAVE_TRIAL_DB_PORT') ?: 3306),
        'db_name' => getenv('MELOWAVE_TRIAL_DB_NAME') ?: 'tuner',
        'db_user' => $user,
        'db_password' => $password,
        'enabled' => getenv('MELOWAVE_TRIAL_ENABLED') === '1',
    ];
}

function mwt_db(array $config): mysqli {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $db = new mysqli(
        (string) $config['db_host'],
        (string) $config['db_user'],
        (string) $config['db_password'],
        (string) $config['db_name'],
        (int) $config['db_port']
    );
    $db->set_charset('utf8mb4');
    $db->query("SET time_zone = '+00:00'");
    return $db;
}

function mwt_hash(string $type, string $value, array $config): string {
    // Domain separation keeps installation hashes distinct from device hashes.
    return hash_hmac('sha256', 'MeloWaveTrial:v1:' . $type . ':' . $value, $config['hmac_key']);
}

function mwt_json(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
