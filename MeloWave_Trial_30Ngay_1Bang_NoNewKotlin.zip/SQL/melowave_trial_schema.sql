-- MeloWave: exactly ONE NEW table for guest Premium trials and device-based retention.
-- Existing premium_accounts and premium_purchases are NOT touched.
-- Run in the existing tuner database. All timestamps stored in UTC.
USE `tuner`;

CREATE TABLE IF NOT EXISTS `mw_trial_devices` (
  `device_key` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `first_seen_at` DATETIME NOT NULL,
  `last_seen_at` DATETIME NOT NULL,
  `last_active_day` DATE NOT NULL,
  `active_days` INT UNSIGNED NOT NULL DEFAULT 1,
  `first_played_at` DATETIME NULL,
  `trial_expires_at` DATETIME NULL,
  `returned_d1` TINYINT(1) NOT NULL DEFAULT 0,
  `returned_d7` TINYINT(1) NOT NULL DEFAULT 0,
  `returned_d30` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`device_key`),
  INDEX `idx_mw_trial_expiry` (`trial_expires_at`),
  INDEX `idx_mw_trial_first_seen` (`first_seen_at`),
  INDEX `idx_mw_trial_last_active` (`last_active_day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
