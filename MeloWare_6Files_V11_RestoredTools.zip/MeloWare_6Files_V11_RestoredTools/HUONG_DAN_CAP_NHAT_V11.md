# MeloWare V11 - Logo, icon not nhac va khoi phuc cong cu cu

## File can thay
Nen thay tron bo 6 file Kotlin trong thu muc:

`app/src/main/java/duc_phi/music/`

- MainActivity.kt
- MusicController.kt
- HomeScreen.kt
- LibraryScreen.kt
- NowPlayingScreen.kt
- MusicUiComponents.kt

File `public_drive_api_key.xml` duoc giu nguyen tu ban V10.

## Noi dung da khoi phuc

1. Logo `R.drawable.logo` nam ben trai ten MeloWare tren Trang chu.
2. Placeholder khong co anh bia duoc ve lai thanh cap not moc kep dung ty le.
3. Cong cu tep nhac cuc bo:
   - Cat nhac va luu M4A vao `Music/MeloWare`.
   - Ghep hai bai nhac va luu M4A vao `Music/MeloWare`.
   - Dat nhac chuong cuoc goi.
   - Dat am bao thong bao.
   - Khoi phuc am thanh he thong mac dinh.
4. Thu thap thong tin su dung giong du an goc:
   - Dang nhap/dang xuat Google trong Cai dat.
   - Ghi `userId`, `deviceModel`, `osVersion`, `deviceId`, `accessTime`, `openCount`, `durationString`, `durationMs` vao Firebase Realtime Database `usage_stats`.
   - Chi cong thoi gian khi ung dung o foreground.

## Cach mo cong cu am thanh

- Trong Thu vien, tai bai hat tren dien thoai, bam nut ba cham.
- Trong man hinh Dang phat, bam nut ba cham o goc tren ben phai.
- Cac cong cu chi hien voi bai da luu tren dien thoai (`LOCAL_MEDIASTORE` hoac `DOWNLOADED`), dung logic an toan cua du an goc.

## AndroidManifest.xml

Dam bao Manifest co quyen sau de dat nhac chuong:

```xml
<uses-permission android:name="android.permission.WRITE_SETTINGS" />
```

Cac quyen Internet, doc audio, thong bao va receiver nhac nho van giu nhu ban truoc.

## Dependency

Ban V11 dung lai cac dependency da co trong du an goc:

- Media3 ExoPlayer
- Media3 Transformer
- Google Sign-In
- Firebase Realtime Database

Neu build.gradle cua ban da xoa mot trong cac dependency nay, hay dua lai dung phien ban da dung o du an goc. Khong nen tron nhieu phien ban Media3 trong cung module.

## Kiem tra da thuc hien

- Kotlin PSI Parser: 6/6 file khong co loi cu phap.
- Kiem tra moi `controller.*` duoc UI goi deu ton tai trong MusicController.
- Kiem tra icon Compose: khong thieu import.
- Kiem tra ZIP: thanh cong.

Luu y: Moi truong hien tai khong co toan bo Gradle project va Android SDK cua may ban, nen van can chay `Build > Clean Project` va `Build > Rebuild Project` tren Android Studio.
