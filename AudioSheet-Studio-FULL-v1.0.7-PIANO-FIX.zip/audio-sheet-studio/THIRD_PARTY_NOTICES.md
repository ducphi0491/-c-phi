# Third-party notices

This project installs or loads the following major open-source components. Their own license files and notices govern those components.

- Spotify Basic Pitch 0.4.0 - Apache License 2.0
- music21 10.5.2 - BSD 3-Clause License
- OpenSheetMusicDisplay 2.1.3 - BSD 3-Clause License
- FastAPI - MIT License
- yt-dlp - The Unlicense; its optional/release components may include other licenses
- FFmpeg - license depends on the build and enabled codecs
- TensorFlow 2.15.x - Apache License 2.0

AudioSheet Studio does not include or copy code from ledutu.com. It is an independent implementation using public open-source libraries.


### Salamander Grand Piano V3 (optional real-piano samples)

Alexander Holm — Creative Commons Attribution 3.0 Unported.
Source: https://github.com/sfzinstruments/SalamanderGrandPiano
MP3 distribution: https://tonejs.github.io/audio/salamander/
See LICENSE_PIANO_SAMPLES.txt for further details.
