@echo off
setlocal
cd /d "%~dp0"
echo ==================================================
echo  AudioSheet Studio - cai tieng PIANO THUC (1 lan)
echo ==================================================
echo  Nguon: Salamander Grand Piano V3 (CC BY 3.0)
echo  Khong can cai Node.js hoac thu vien Python moi.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\download_piano_samples.ps1"
if errorlevel 1 (
  echo.
  echo [THIEU] Mot so mau chua tai xong; kiem tra Internet va chay lai.
) else (
  echo.
  echo [OK] Tai du 30 mau piano. Khoi dong lai website (neu dang mo).
)
if not exist "web\vendor\opensheetmusicdisplay.min.js" (
  echo.
  echo [SHEET] Dang tai bo hien thi sheet nhac de dung offline...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\download_osmd.ps1"
)
pause
