Run TAI_AM_THANH_PIANO.bat at the project root to install the REAL acoustic
piano sample files here (30 MP3 recordings). Windows 10/11 and PowerShell 5.1+.
The browser can fetch them online automatically if they are not installed;
without internet it falls back to explicitly labeled synthesized sound.
Samples: Salamander Grand Piano V3 - Alexander Holm - CC BY 3.0.
See LICENSE_PIANO_SAMPLES.txt for attribution and source URLs.
