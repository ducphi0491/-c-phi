/* AudioSheet Studio v1.0.7 - acoustic piano, calibrated volume and explicit sample test.
 * Salamander Grand Piano V3, Alexander Holm, CC BY 3.0 (see LICENSE_PIANO_SAMPLES.txt).
 * Browser Web Audio API; no extra JS/Python dependency. Synth is only an explicit fallback.
 */
(() => {
  'use strict';

  const SAMPLE_KEYS = [
    'A0', 'C1', 'Ds1', 'Fs1', 'A1', 'C2', 'Ds2', 'Fs2', 'A2',
    'C3', 'Ds3', 'Fs3', 'A3', 'C4', 'Ds4', 'Fs4', 'A4',
    'C5', 'Ds5', 'Fs5', 'A5', 'C6', 'Ds6', 'Fs6', 'A6',
    'C7', 'Ds7', 'Fs7', 'A7', 'C8',
  ];
  const PC = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const SAMPLES = SAMPLE_KEYS.map(name => {
    const m = /^([A-G])(s?)(\d)$/.exec(name);
    return { name, midi: (Number(m[3]) + 1) * 12 + PC[m[1]] + (m[2] ? 1 : 0) };
  });
  const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

  class AudioSheetPianoPlayer {
    constructor(callbacks = {}) {
      this.callbacks = callbacks;
      this.audioContext = null;
      this.master = null;
      this.notes = [];
      this.duration = 0;
      this.position = 0;
      this.mode = 'light';
      this.volume = 0.82;
      this.isPlaying = false;
      this.ctxStart = 0;
      this.nextIndex = 0;
      this.timer = null;
      this.frame = null;
      this.voices = [];
      this.voiceByPitch = new Map();
      this.sampleBuffers = new Map();
      this.sampleNormalization = new Map();
      this.sampleSources = new Map();
      this.samplePromises = new Map();
      this.sampleFailures = new Set();
      this.sampleMode = 'unknown';
      this.remoteDisabled = false;
      this.generation = 0;
    }

    setNotes(notes, duration, mode = 'light') {
      this.stop();
      this.notes = Array.isArray(notes) ? notes.filter(n =>
        Number.isFinite(n.start) && Number.isFinite(n.end) &&
        Number.isInteger(n.pitch) && n.pitch >= 0 && n.pitch <= 127 && n.end > n.start
      ).sort((a, b) => a.start - b.start || b.pitch - a.pitch) : [];
      const latestEnd = this.notes.reduce((last, note) => Math.max(last, note.end), 0);
      this.duration = Math.max(0, Number(duration) || 0, latestEnd);
      this.mode = mode;
      this.position = 0;
      this.sampleMode = 'unknown';
      this._emit();
    }

    _emitLoading(message, failed = false) {
      this.callbacks.onLoading?.({ message, failed });
    }

    _outputGain() {
      // 0% must be silent; 82% should be audible without repeated attenuation.
      return this.volume <= 0 ? 0 : 0.94 * Math.pow(this.volume, 0.88);
    }

    setVolume(value) {
      const n = Number(value);
      this.volume = clamp(Number.isFinite(n) ? n : 0, 0, 1);
      if (this.master && this.audioContext) {
        this.master.gain.setTargetAtTime(this._outputGain(), this.audioContext.currentTime, 0.02);
      }
    }

    async _prepare() {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) throw new Error('Trình duyệt không hỗ trợ Web Audio. Hãy dùng Chrome hoặc Edge.');
      if (!this.audioContext) {
        this.audioContext = new AudioContext();
        this.master = this.audioContext.createGain();
        this.master.gain.value = this._outputGain();
        // Gently control dynamics, then limit peaks from dense chords without clipping.
        const compressor = this.audioContext.createDynamicsCompressor();
        compressor.threshold.value = -11;
        compressor.knee.value = 7;
        compressor.ratio.value = 2.4;
        compressor.attack.value = 0.004;
        compressor.release.value = 0.18;
        const limiter = this.audioContext.createDynamicsCompressor();
        limiter.threshold.value = -2.5;
        limiter.knee.value = 0;
        limiter.ratio.value = 16;
        limiter.attack.value = 0.001;
        limiter.release.value = 0.09;
        this.master.connect(compressor);
        compressor.connect(limiter);
        limiter.connect(this.audioContext.destination);
      }
      // Resume during a real user interaction, before attempting network requests.
      await this.audioContext.resume();
    }

    _sampleForPitch(pitch) {
      let nearest = SAMPLES[0];
      for (const sample of SAMPLES) {
        if (Math.abs(pitch - sample.midi) < Math.abs(pitch - nearest.midi)) nearest = sample;
      }
      return nearest;
    }

    _normalizationForBuffer(buffer) {
      // Normalise based on the attack portion of the *real recording*; bound by peak
      // headroom so this cannot turn a very quiet/corrupt recording into loud noise.
      const frames = Math.min(buffer.length, Math.round(buffer.sampleRate * 0.8));
      const stride = Math.max(1, Math.floor(buffer.sampleRate / 10000));
      if (!frames || !buffer.numberOfChannels) return 1;
      let squared = 0, peak = 0, count = 0;
      const channels = [];
      for (let i = 0; i < Math.min(buffer.numberOfChannels, 2); i++) channels.push(buffer.getChannelData(i));
      for (let i = 0; i < frames; i += stride) {
        for (const channel of channels) {
          const s = channel[i];
          squared += s * s;
          peak = Math.max(peak, Math.abs(s));
          count++;
        }
      }
      const rms = Math.sqrt(squared / Math.max(1, count));
      if (rms < 0.0002 || peak < 0.001) throw new Error('Mẫu piano gần như không có âm thanh.');
      // Target attack RMS ~0.13, with an absolute peak cap and bounded gain.
      return clamp(Math.min(0.13 / rms, 0.91 / peak), 0.6, 4.0);
    }

    async _downloadSample(sample) {
      if (this.sampleBuffers.has(sample.name)) return this.sampleBuffers.get(sample.name);
      if (this.samplePromises.has(sample.name)) return this.samplePromises.get(sample.name);
      const promise = (async () => {
        const urls = [
          `/static/piano_samples/${sample.name}.mp3`,
          ...(this.remoteDisabled ? [] : [`https://tonejs.github.io/audio/salamander/${sample.name}.mp3`]),
        ];
        let lastError = null;
        for (const url of urls) {
          let controller, timer;
          try {
            controller = new AbortController();
            timer = window.setTimeout(() => controller.abort(), 11000);
            const response = await fetch(url, { signal: controller.signal, cache: 'force-cache' });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const bytes = await response.arrayBuffer();
            if (bytes.byteLength < 2500) throw new Error('Tệp piano quá nhỏ.');
            const buffer = await this.audioContext.decodeAudioData(bytes);
            if (!buffer || !buffer.duration || !buffer.numberOfChannels) throw new Error('Không giải mã được MP3.');
            const scale = this._normalizationForBuffer(buffer);
            this.sampleBuffers.set(sample.name, buffer);
            this.sampleNormalization.set(sample.name, scale);
            this.sampleSources.set(sample.name, url.startsWith('/static/') ? 'local' : 'online');
            this.sampleFailures.delete(sample.name);
            return buffer;
          } catch (error) {
            lastError = error;
            if (url.startsWith('https://') && (error?.name === 'AbortError' || error instanceof TypeError)) {
              this.remoteDisabled = true;
            }
          } finally {
            if (timer) window.clearTimeout(timer);
          }
        }
        this.sampleFailures.add(sample.name);
        throw new Error(`Không đọc được tiếng piano ${sample.name}: ${lastError}`);
      })();
      this.samplePromises.set(sample.name, promise);
      try { return await promise; }
      finally { this.samplePromises.delete(sample.name); }
    }

    async _loadSamplesForNotes() {
      const keys = new Set(this.notes.map(n => this._sampleForPitch(n.pitch).name));
      const missing = SAMPLES.filter(s => keys.has(s.name) && !this.sampleBuffers.has(s.name));
      if (missing.length) {
        let finished = 0;
        this._emitLoading(`Đang mở các mẫu piano đã tải: 0/${missing.length}...`);
        let cursor = 0;
        const workers = Array.from({ length: Math.min(5, missing.length) }, async () => {
          while (cursor < missing.length) {
            const s = missing[cursor++];
            try { await this._downloadSample(s); }
            catch (_) { /* clearly reported below */ }
            finally {
              finished++;
              this._emitLoading(`Đang chuẩn bị tiếng piano: ${finished}/${missing.length}...`);
            }
          }
        });
        await Promise.all(workers);
      }
      const loaded = [...keys].filter(key => this.sampleBuffers.has(key));
      const failed = keys.size - loaded.length;
      const locallyLoaded = loaded.filter(key => this.sampleSources.get(key) === 'local').length;
      this.sampleMode = !loaded.length ? 'synth' : failed ? 'mixed' : 'recorded';
      if (failed) {
        this._emitLoading(
          failed === keys.size
            ? 'LỖI: Không đọc được mẫu piano MP3. Đang dùng âm tổng hợp dự phòng. Hãy bấm "Thử nốt C4" để kiểm tra.'
            : `Piano ghi âm ${loaded.length}/${keys.size} mẫu (${failed} mẫu dùng tiếng dự phòng).`, true,
        );
      } else {
        this._emitLoading(`PIANO THẬT: ${loaded.length}/${keys.size} mẫu đã giải mã (${locallyLoaded} mẫu trong máy).`);
      }
    }

    _indexAt(time) {
      let low = 0, high = this.notes.length;
      while (low < high) {
        const mid = (low + high) >>> 1;
        if (this.notes[mid].start < time) low = mid + 1;
        else high = mid;
      }
      return low;
    }

    _emit() {
      this.callbacks.onUpdate?.({
        time: this.currentTime(), duration: this.duration,
        playing: this.isPlaying, mode: this.mode, instrument: this.sampleMode,
      });
    }

    currentTime() {
      return this.isPlaying && this.audioContext
        ? Math.min(this.duration, this.position + this.audioContext.currentTime - this.ctxStart)
        : this.position;
    }

    async play() {
      if (this.isPlaying) return;
      if (!this.notes.length) throw new Error('Không có nốt nhạc để phát.');
      const token = this.generation;
      await this._prepare();
      if (this.position >= this.duration - 0.02) this.position = 0;
      await this._loadSamplesForNotes();
      if (token !== this.generation) return;
      this.ctxStart = this.audioContext.currentTime;
      this.nextIndex = this._indexAt(this.position - 0.000001);
      this.isPlaying = true;
      this.timer = window.setInterval(() => this._schedule(), 45);
      this._schedule();
      this._tick();
      this._emit();
    }

    async audition() {
      // Diagnostic independent from AI notes and sheet. Will NEVER play the synth fallback.
      this.stop();
      const token = this.generation;
      await this._prepare();
      const sample = this._sampleForPitch(60); // C4 = middle C
      await this._downloadSample(sample);
      if (token !== this.generation) return;
      this.sampleMode = 'recorded';
      this._playNote({ start: 0, end: 1.2, pitch: 60, velocity: 110, staff: 'upper' },
        this.audioContext.currentTime + 0.04, true);
      const origin = this.sampleSources.get(sample.name) === 'local' ? 'trong máy' : 'trực tuyến';
      this._emitLoading(`ĐANG PHÁT PIANO THẬT: C4.mp3 (${origin}). Nếu nốt này nghe đúng, khác biệt ở bài hát đến từ dữ liệu AI.`);
      this._emit();
    }

    _tick() {
      if (!this.isPlaying) return;
      if (this.currentTime() >= this.duration) { this.stop(); return; }
      this._emit();
      this.frame = window.requestAnimationFrame(() => this._tick());
    }

    _schedule() {
      if (!this.isPlaying || !this.audioContext) return;
      const until = this.currentTime() + 0.22;
      const now = this.audioContext.currentTime;
      this.voices = this.voices.filter(v => v.until > now);
      while (this.nextIndex < this.notes.length) {
        const note = this.notes[this.nextIndex];
        if (note.start > until) break;
        this.nextIndex++;
        const when = this.ctxStart + note.start - this.position;
        if (when < now - 0.045) continue;
        if (this.voices.filter(v => v.until > when).length >= 24) continue;
        this._playNote(note, Math.max(now, when));
      }
    }

    _playNote(note, when, audition = false) {
      const c = this.audioContext;
      const seconds = clamp(note.end - note.start, 0.07, 7);
      const release = audition ? 0.65 : clamp(seconds * 0.5, 0.22, 0.52);
      const until = when + seconds + release;
      const velocity = clamp((Number(note.velocity) || 75) / 127, 0.05, 1);
      const dynamics = 0.38 + 0.72 * Math.pow(velocity, 0.75);
      let partGain;
      if (audition) partGain = 0.95;
      else if (this.mode === 'melody') partGain = 1;
      else if (this.mode === 'light') partGain = note.staff === 'lower' ? 0.58 : 0.94;
      else partGain = 0.66;

      const sample = this._sampleForPitch(note.pitch);
      const buffer = this.sampleBuffers.get(sample.name);
      const normalization = buffer ? (this.sampleNormalization.get(sample.name) || 1) : 0.34;
      const gain = clamp(dynamics * partGain * normalization, 0.0001, 4.5);
      const envelope = c.createGain();
      envelope.gain.setValueAtTime(0.0001, when);
      envelope.gain.linearRampToValueAtTime(gain, when + 0.009);
      // Preserve piano sample's own decay. Do not muffle every strike after 170ms.
      envelope.gain.setValueAtTime(gain, when + seconds);
      envelope.gain.exponentialRampToValueAtTime(0.0001, until);
      envelope.connect(this.master);
      const sources = [];
      if (buffer) {
        const source = c.createBufferSource();
        source.buffer = buffer;
        source.playbackRate.setValueAtTime(Math.pow(2, (note.pitch - sample.midi) / 12), when);
        source.connect(envelope);
        source.start(when);
        source.stop(until);
        sources.push(source);
      } else if (!audition) {
        // Clearly labeled fallback only if MP3 loading fails.
        const hz = 440 * Math.pow(2, (note.pitch - 69) / 12);
        for (const [type, ratio, strength] of [['triangle', 1, .72], ['sine', 2.003, .20], ['sine', 3.01, .08]]) {
          if (hz * ratio > c.sampleRate * 0.43) continue;
          const osc = c.createOscillator();
          const g = c.createGain();
          g.gain.value = strength;
          osc.type = type;
          osc.frequency.setValueAtTime(hz * ratio, when);
          osc.connect(g);
          g.connect(envelope);
          osc.start(when);
          osc.stop(until);
          sources.push(osc);
        }
      } else {
        throw new Error('Không tìm được file tiếng piano ghi âm C4.mp3.');
      }

      const prev = this.voiceByPitch.get(note.pitch);
      if (prev && prev.until > when + 0.015) {
        try {
          prev.envelope.gain.cancelScheduledValues(when);
          prev.envelope.gain.setTargetAtTime(0.0001, when, 0.016);
          for (const source of prev.sources) source.stop(when + 0.065);
        } catch (_) { /* already finished */ }
        prev.until = when + 0.065;
      }
      const voice = { until, pitch: note.pitch, sources, envelope };
      this.voices.push(voice);
      this.voiceByPitch.set(note.pitch, voice);
    }

    _silence() {
      if (!this.audioContext) return;
      const now = this.audioContext.currentTime;
      for (const voice of this.voices) {
        try {
          voice.envelope.gain.cancelScheduledValues(now);
          voice.envelope.gain.setTargetAtTime(0.0001, now, 0.004);
          for (const source of voice.sources) source.stop(now + 0.045);
        } catch (_) { /* source already ended */ }
      }
      this.voices = [];
      this.voiceByPitch.clear();
    }

    _halt() {
      if (this.timer !== null) window.clearInterval(this.timer);
      if (this.frame !== null) window.cancelAnimationFrame(this.frame);
      this.timer = null;
      this.frame = null;
      this.isPlaying = false;
      this._silence();
    }

    pause() {
      if (!this.isPlaying) return;
      this.position = this.currentTime();
      this._halt();
      this._emit();
    }

    stop() {
      this.generation++;
      this._halt();
      this.position = 0;
      this.nextIndex = 0;
      this._emit();
    }

    async seek(time) {
      const playing = this.isPlaying;
      this._halt();
      this.position = clamp(Number(time) || 0, 0, this.duration);
      this._emit();
      if (playing) await this.play();
    }
  }
  window.AudioSheetPianoPlayer = AudioSheetPianoPlayer;
})();
