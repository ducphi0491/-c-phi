#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
. .venv/bin/activate
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
