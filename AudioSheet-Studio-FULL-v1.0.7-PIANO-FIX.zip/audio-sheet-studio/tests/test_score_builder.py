from pathlib import Path

import pytest

music21 = pytest.importorskip("music21")

from app.demo_score import create_demo_musicxml


@pytest.mark.parametrize("mode", ["piano", "lead", "raw"])
def test_demo_musicxml_can_be_created(tmp_path: Path, mode: str) -> None:
    target = tmp_path / f"{mode}.musicxml"
    create_demo_musicxml(target, mode=mode)
    assert target.exists()
    text = target.read_text(encoding="utf-8")
    assert "score-partwise" in text
