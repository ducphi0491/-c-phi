/* Run with `node tests/test_piano_player.mjs`. No network/browser required. */
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

function setup({ failLocal = false, failRemote = false } = {}) {
  const played = [];
  const statuses = [];
  const params = [];
  const calls = [];
  let oscillators = 0;

  function param(initial = 0) {
    const obj = {
      value: initial, changes: [],
      setValueAtTime(v, at) { this.value = v; this.changes.push([at, v]); },
      setTargetAtTime(v, at) { this.value = v; this.changes.push([at, v]); },
      exponentialRampToValueAtTime(v, at) { this.value = v; this.changes.push([at, v]); },
      linearRampToValueAtTime(v, at) { this.value = v; this.changes.push([at, v]); },
      cancelScheduledValues() {},
    };
    params.push(obj);
    return obj;
  }
  class AudioContext {
    constructor() { this.currentTime = 0; this.sampleRate = 44100; this.destination = {}; }
    async resume() { return true; }
    createGain() { return { gain: param(1), connect() {} }; }
    createDynamicsCompressor() {
      return { threshold: param(), knee: param(), ratio: param(), attack: param(), release: param(), connect() {} };
    }
    createBufferSource() {
      return { playbackRate: param(1), connect() {}, start(at) { played.push(at); }, stop() {} };
    }
    createOscillator() {
      oscillators++;
      return { frequency: param(), connect() {}, start() {}, stop() {}, type: '' };
    }
    async decodeAudioData() {
      const a = new Float32Array(44100);
      const b = new Float32Array(44100);
      for (let i = 0; i < a.length; i++) { a[i] = Math.sin(i * 0.08) * 0.037; b[i] = Math.sin(i * 0.0805) * 0.035; }
      return { duration: 1, numberOfChannels: 2, sampleRate: 44100, length: 44100,
        getChannelData: c => c === 0 ? a : b };
    }
  }
  const sandbox = {
    window: { AudioContext, setTimeout: () => 1, clearTimeout() {}, setInterval: () => 1,
      clearInterval() {}, requestAnimationFrame: () => 1, cancelAnimationFrame() {} },
    fetch: async url => {
      calls.push(url);
      if ((url.startsWith('/static/') && failLocal) || (url.startsWith('https:') && failRemote)) {
        return { ok: false, status: 404 };
      }
      return { ok: true, async arrayBuffer() { return new ArrayBuffer(12000); } };
    },
    AbortController: class { constructor() { this.signal = {}; } abort() {} },
    Number, Math, Set, Map, Error, Array,
  };
  vm.runInNewContext(fs.readFileSync(new URL('../web/playback.js', import.meta.url), 'utf8'), sandbox);
  const player = new sandbox.window.AudioSheetPianoPlayer({onLoading: e => statuses.push(e)});
  return { player, played, statuses, calls, params, getOscillatorCount: () => oscillators };
}

{
  const { player, played, statuses, calls, getOscillatorCount } = setup();
  player.setVolume(0.82);
  await player.audition();
  assert.equal(player.sampleMode, 'recorded');
  assert.equal(player.sampleSources.get('C4'), 'local');
  assert(played.length === 1, 'Recorded middle C should be played once');
  assert.equal(getOscillatorCount(), 0, 'Test note must not be an oscillator');
  assert(player.sampleNormalization.get('C4') > 1, 'Quiet samples should be gain-calibrated');
  assert(calls[0].endsWith('/C4.mp3'));
  assert(statuses.some(x => x.message.includes('PIANO THẬT')));
  assert(player._outputGain() > 0.7, 'Master level should not suffer the old 0.7 penalty');
  player.setVolume(0);
  assert.equal(player._outputGain(), 0, 'Zero volume must be silent');
}

{
  const { player, played, statuses } = setup();
  player.setNotes([
    {start:0.03, end:0.35, pitch:67, velocity:75, staff:'upper'},
    {start:0.05, end:0.7, pitch:43, velocity:35, staff:'lower'},
  ], 1, 'light');
  await player.play();
  assert.equal(player.sampleMode, 'recorded');
  assert(played.length === 2, 'Both melody and bass recorded notes should play');
  assert(statuses.some(x => x.message.includes('PIANO THẬT')));
  assert.equal(player.voices.length, 2);
  player.pause();
  assert.equal(player.voices.length, 0);
}

{
  const { player, statuses, getOscillatorCount } = setup({ failLocal:true, failRemote:true });
  player.setNotes([{ start:0.02, end:0.4, pitch:60, velocity:80 }], 1, 'full');
  await player.play();
  assert.equal(player.sampleMode, 'synth');
  assert(getOscillatorCount() > 0, 'Explicit fallback should be audible');
  assert(statuses.some(x => x.failed && x.message.includes('dự phòng')));
}

{
  const { player } = setup({ failLocal:true, failRemote:true });
  let threw = false;
  try { await player.audition(); } catch (e) { threw = true; }
  assert(threw, 'Piano test must fail visibly rather than silently replacing recorded C4 with synth');
}

console.log('PASS: 4 Web Audio tests — acoustic C4, loudness, A/B scheduling, explicit fallback.');
