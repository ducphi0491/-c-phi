import json
from pathlib import Path

import pretty_midi

from app.playback_modes import clean_notes, merge_fragments, prepare_variants, write_mode_midi


def test_unsorted_notes_and_three_independent_modes() -> None:
    raw = [
        {"start": 2.0, "end": 2.4, "pitch": 69, "velocity": 88},
        {"start": 0.0, "end": 0.25, "pitch": 68, "velocity": 80},
        {"start": 0.25, "end": 0.5, "pitch": 68, "velocity": 83},
        {"start": 0.9, "end": 1.5, "pitch": 44, "velocity": 70},
        {"start": 1.1, "end": 1.35, "pitch": 69, "velocity": 90},
    ]
    result = prepare_variants(raw)
    assert set(result['modes']) == {'melody', 'light', 'full'}
    assert result['raw_count'] == 5
    assert result['merged_count'] == 4
    assert result['reference_active'] is False
    assert result['modes']['full']['count'] == 5
    assert result['modes']['melody']['count'] <= result['modes']['light']['count'] < 5
    assert [n['start'] for n in result['modes']['full']['notes']] == sorted(n['start'] for n in raw)


def test_fragment_merge_preserves_distinct_repeated_hits() -> None:
    source = clean_notes([
        {'start': 0, 'end': .2, 'pitch': 68, 'velocity': 81},
        {'start': .2, 'end': .4, 'pitch': 68, 'velocity': 82},
        {'start': .52, 'end': .72, 'pitch': 68, 'velocity': 83},
        {'start': .72, 'end': .9, 'pitch': 68, 'velocity': 122},
    ])
    joined = merge_fragments(source)
    assert len(joined) == 3
    assert joined[0]['end'] == .4


def test_invalid_notes_cannot_crash_server() -> None:
    result = prepare_variants([
        {'start': 0, 'end': 1, 'pitch': 60, 'velocity': 80},
        {'start': -1, 'end': .2, 'pitch': 60, 'velocity': 80},
        {'start': 'NaN', 'end': 2, 'pitch': 60, 'velocity': 80},
        {'start': 0, 'end': 1, 'pitch': 300, 'velocity': 80},
        {'bad': 2},
    ])
    assert result['raw_count'] == 1
    assert result['modes']['full']['count'] == 1
    assert json.dumps(result, allow_nan=False)


def test_reference_changes_only_full_mode() -> None:
    original = [{'start': 1, 'end': 1.5, 'pitch': 68, 'velocity': 85},
                {'start': 2, 'end': 2.5, 'pitch': 45, 'velocity': 60}]
    reference = [{'start': 0.9, 'end': 2.1, 'pitch': 81, 'velocity': 70}]
    before = prepare_variants(original)
    after = prepare_variants(original, reference)
    assert after['reference_active'] is True
    assert after['modes']['full']['notes'][0]['pitch'] == 81
    assert before['modes']['melody'] == after['modes']['melody']
    assert before['modes']['light'] == after['modes']['light']


def test_export_each_midi(tmp_path: Path) -> None:
    raw = [
        {'start': .1, 'end': .6, 'pitch': 64, 'velocity': 70},
        {'start': .2, 'end': .7, 'pitch': 45, 'velocity': 60},
        {'start': 1.0, 'end': 1.8, 'pitch': 68, 'velocity': 99},
    ]
    variants = prepare_variants(raw)['modes']
    for mode, data in variants.items():
        path = tmp_path / f'{mode}.mid'
        write_mode_midi(data['notes'], str(path), bpm=100)
        midi = pretty_midi.PrettyMIDI(str(path))
        assert sum(len(instrument.notes) for instrument in midi.instruments) == data['count']
