import io
import json

import pretty_midi
from fastapi.testclient import TestClient

from app.job_store import job_store
from app.main import app

client = TestClient(app)


def sample_job():
    job = job_store.create({'source_type': 'upload', 'title': 'Demo fixture', 'bpm_used': 120})
    notes = [
        {'start': 0.2, 'end': 0.7, 'pitch': 68, 'velocity': 86},
        {'start': 0.7, 'end': 0.9, 'pitch': 68, 'velocity': 85},
        {'start': 1, 'end': 1.7, 'pitch': 44, 'velocity': 74},
        {'start': 2, 'end': 2.7, 'pitch': 69, 'velocity': 83},
    ]
    (job_store.job_dir(job['id']) / 'note_events.json').write_text(json.dumps(notes))
    job_store.update(job['id'], status='done', artifacts=[])
    return job['id']


def test_old_job_works_without_reprocessing_ai() -> None:
    job_id = sample_job()
    try:
        reply = client.get(f'/api/jobs/{job_id}/playback')
        assert reply.status_code == 200, reply.text
        body = reply.json()
        assert body['raw_count'] == 4
        assert all(name in body['modes'] for name in ('melody', 'light', 'full'))
        for name in body['modes']:
            stream = client.get(f'/api/jobs/{job_id}/playback-midi/{name}')
            assert stream.status_code == 200, stream.text
            assert stream.content[:4] == b'MThd'
    finally:
        job_store.delete(job_id)


def test_reference_midi_can_be_uploaded_and_removed() -> None:
    job_id = sample_job()
    try:
        midi = pretty_midi.PrettyMIDI()
        inst = pretty_midi.Instrument(program=0)
        inst.notes.append(pretty_midi.Note(velocity=99, pitch=74, start=1, end=2))
        midi.instruments.append(inst)
        output = io.BytesIO()
        midi.write(output)
        reply = client.post(f'/api/jobs/{job_id}/reference-midi', files={'midi_file': ('reference.mid', output.getvalue(), 'audio/midi')})
        assert reply.status_code == 200, reply.text
        assert reply.json()['reference_active'] is True
        assert reply.json()['modes']['full']['notes'][0]['pitch'] == 74
        assert reply.json()['modes']['melody']['notes']

        bad = client.post(f'/api/jobs/{job_id}/reference-midi', files={'midi_file': ('other.mid', b'not midi', 'audio/midi')})
        assert bad.status_code == 400
        assert client.get(f'/api/jobs/{job_id}/playback').json()['reference_active'] is True

        reply = client.delete(f'/api/jobs/{job_id}/reference-midi')
        assert reply.status_code == 204
        assert client.get(f'/api/jobs/{job_id}/playback').json()['reference_active'] is False
    finally:
        job_store.delete(job_id)


def test_demo_works_even_without_saved_note_json() -> None:
    job = job_store.create({'source_type': 'demo', 'bpm_used': 100})
    job_store.update(job['id'], status='done')
    try:
        result = client.get(f'/api/jobs/{job["id"]}/playback')
        assert result.status_code == 200, result.text
        assert result.json()['raw_count'] > 0
    finally:
        job_store.delete(job['id'])
