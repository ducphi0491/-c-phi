import pytest

from app.security import validate_audio_filename, validate_youtube_url


def test_audio_extension_validation() -> None:
    assert validate_audio_filename("song.MP3").endswith(".MP3")
    with pytest.raises(ValueError):
        validate_audio_filename("payload.exe")


def test_youtube_allowlist() -> None:
    assert validate_youtube_url("https://youtu.be/abc") == "https://youtu.be/abc"
    with pytest.raises(ValueError):
        validate_youtube_url("https://example.com/video")
