# AudioSheet Studio v1.0.7 — Piano gain/timbre fix

**Update:** Improves perceived loudness and sustain of the existing Salamander Grand Piano samples, adds a genuine recorded C4 test button and explicit fallback reporting. A/B/C continue to update both the sheet and playback. See `HUONG_DAN_V1.0.7.txt`.

**Existing installation path in this user's setup:** `C:\audio-sheet-studio` (not `C:\AudioSheetStudio\audio-sheet-studio`). To update using the FULL ZIP, unpack its `audio-sheet-studio/` folder into `C:\` and replace matching files **without deleting** `.venv`, `data` or `web\piano_samples`.

This release adds no new Python/Node dependencies. Previously downloaded Salamander MP3 samples are reused. The A/B/C presets are note arrangements, not separate AI models. Playback uses real piano recordings when the browser can decode them and labels the synthesized fallback if not.

---

**v1.0.6:** Three arrangements A/B/C update both the displayed MusicXML score and the audio playback. For recorded Yamaha C5 piano sound, run `TAI_AM_THANH_PIANO.bat` once on Windows to download licensed samples; no new Python packages or Node.js needed. See `HUONG_DAN_V1.0.6.txt` and `LICENSE_PIANO_SAMPLES.txt`.

# AudioSheet Studio – v1.0.6

**Three piano listening presets (A/B/C) added to the existing Basic Pitch transcription app.**
See `HUONG_DAN_3_CHE_DO.txt` for Vietnamese step-by-step instructions, and
`BAT_DAU_O_DAY.txt` for Windows launching.

The installer and website remain local-first. The new playback features require
no extra Python modules beyond the existing environment (Basic Pitch already
installs `pretty_midi`; it is now explicitly listed in requirements.txt).

**Existing Windows installation:** copy the contents of the FULL ZIP into
`C:\AudioSheetStudio`, replacing matching files. Do **not** delete the old
`audio-sheet-studio` directory, `.venv` or `data` (they contain the installed
Python environment and your prior jobs). Start `CHAY_WEBSITE.bat`.

**After transcribing or selecting an existing completed job:** choose A / B / C
in the result panel and press Play. C can additionally load the `.mid` reference
exported by another tool (e.g. Ledutu); with no reference, C plays all the
original AI notes. MIDI outputs A, B and C can be downloaded separately.

The three choices are audio arrangements, **not three different AI models**.
Web Audio creates piano-like tones directly on the user's device; no sample
SoundFont, third-party CDN, or server-side synth is required for playback.

---

# AudioSheet Studio v1.0.3

AudioSheet Studio is a local-first open-source MVP that converts an uploaded audio file or an authorized YouTube source into:

- MIDI transcription using Spotify Basic Pitch
- MusicXML notation using music21
- In-browser sheet rendering using OpenSheetMusicDisplay
- Piano two-hand, lead-sheet, and raw-transcription arrangements
- Optional PDF export through MuseScore CLI, plus browser Print / Save as PDF

The app does not call a third-party transcription API. Audio processing runs on the machine that hosts the FastAPI server.

## Quick start on Windows

1. Install Python 3.11, FFmpeg, and Node.js LTS.
2. Double-click `CHAY_WEBSITE.bat` (or `run_windows.bat`). It repairs missing `pkg_resources` and installs dependencies if needed.
3. On existing installations, keep `.venv` and `data/jobs` and overwrite only the source files from the ZIP.
4. Open `http://127.0.0.1:8000`.

Detailed Vietnamese instructions are in `HUONG_DAN_VAN_HANH.md`.

## Docker

```bash
docker compose up --build
```

Then open `http://127.0.0.1:8000`.

## Notes

- Basic Pitch works best with one clearly audible instrument at a time.
- Full mixed songs can produce noisy or incomplete notation.
- YouTube input is provided only for content the user is authorized to process.
- The current job queue is local and file-based. Use a database and a proper worker queue before multi-user public deployment.
