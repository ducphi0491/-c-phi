from __future__ import annotations

import importlib
import platform
import shutil
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def check_import(name: str) -> bool:
    try:
        module = importlib.import_module(name)
        version = getattr(module, "__version__", "installed")
        print(f"[OK] {name}: {version}")
        return True
    except Exception as exc:
        print(f"[MISSING] {name}: {exc}")
        return False


def main() -> int:
    print(f"Python: {platform.python_version()} ({sys.executable})")
    py_ok = sys.version_info[:2] == (3, 11)
    print("[OK] Python 3.11" if py_ok else "[WARNING] Use Python 3.11 for Basic Pitch 0.4.0")

    ok = True
    for command in ("ffmpeg", "ffprobe"):
        path = shutil.which(command)
        print(f"[OK] {command}: {path}" if path else f"[MISSING] {command}")
        ok = ok and bool(path)

    node = shutil.which("node")
    print(f"[OK] node: {node}" if node else "[OPTIONAL] Node.js is recommended for YouTube support")

    for package in ("fastapi", "music21", "tensorflow", "basic_pitch", "yt_dlp", "resampy", "pkg_resources", "basic_pitch.inference"):
        ok = check_import(package) and ok

    osmd = ROOT / "web" / "vendor" / "opensheetmusicdisplay.min.js"
    print(f"[OK] local OSMD: {osmd}" if osmd.exists() else "[OPTIONAL] local OSMD missing; CDN fallback is enabled")
    return 0 if ok and py_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
