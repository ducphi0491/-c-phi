$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$targetDir = Join-Path $root "web\vendor"
$targetFile = Join-Path $targetDir "opensheetmusicdisplay.min.js"
$url = "https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.1.3/build/opensheetmusicdisplay.min.js"
New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
try {
    Invoke-WebRequest -Uri $url -OutFile $targetFile -UseBasicParsing
    Write-Host "Downloaded OpenSheetMusicDisplay to $targetFile" -ForegroundColor Green
} catch {
    Write-Warning "Could not download OSMD. The web app will use the CDN fallback when online."
}
