# AudioSheet Studio 1.0.6 - download licensed acoustic piano MP3 samples.
# Salamander Grand Piano V3 by Alexander Holm - CC BY 3.0.
# No Node.js, npm, TensorFlow change, or pip install is necessary.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$destination = Join-Path $root 'web\piano_samples'
$origin = 'https://tonejs.github.io/audio/salamander/'
$names = @(
    'A0', 'C1', 'Ds1', 'Fs1', 'A1', 'C2', 'Ds2', 'Fs2',
    'A2', 'C3', 'Ds3', 'Fs3', 'A3', 'C4', 'Ds4', 'Fs4',
    'A4', 'C5', 'Ds5', 'Fs5', 'A5', 'C6', 'Ds6', 'Fs6',
    'A6', 'C7', 'Ds7', 'Fs7', 'A7', 'C8'
)
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$done = 0
$failed = New-Object 'System.Collections.Generic.List[string]'
Write-Host "`nAudioSheet Studio - TAI AM PIANO THUC" -ForegroundColor Cyan
Write-Host ('Luu tai: ' + $destination)
Write-Host ('Nguon: ' + $origin)
Write-Host 'License: Salamander Grand Piano V3 - CC BY 3.0'
foreach ($name in $names) {
    $file = Join-Path $destination ($name + '.mp3')
    $temp = $file + '.part'
    if ((Test-Path $file) -and (Get-Item $file).Length -gt 2500) {
        $done++
        Write-Host ('[DA CO] ' + $name) -ForegroundColor DarkGreen
        continue
    }
    $success = $false
    for ($attempt = 1; $attempt -le 2; $attempt++) {
        try {
            Invoke-WebRequest -Uri ($origin + $name + '.mp3') -UseBasicParsing -TimeoutSec 45 -OutFile $temp
            if ((Get-Item $temp).Length -le 2500) { throw 'Tep am thanh khong hop le.' }
            Move-Item -LiteralPath $temp -Destination $file -Force
            $success = $true
            break
        } catch {
            Remove-Item $temp -ErrorAction SilentlyContinue
            if ($attempt -eq 2) { Write-Host ('[LOI] ' + $name + ': ' + $_.Exception.Message) -ForegroundColor Red }
        }
    }
    if ($success) {
        $done++
        Write-Host ('[OK ' + $done + '/' + $names.Count + '] ' + $name) -ForegroundColor Green
    } else {
        $failed.Add($name)
    }
}
Write-Host ('`nKet qua: ' + $done + '/' + $names.Count + ' tep piano.') -ForegroundColor Cyan
if ($failed.Count -gt 0) {
    Write-Host ('Chua tai duoc: ' + ($failed -join ', ')) -ForegroundColor Yellow
    Write-Host 'Kiem tra Internet, sau do chay lai BAT. Tep da tai se duoc giu lai.' -ForegroundColor Yellow
    exit 1
}
Write-Host 'HOAN THANH. Ban co the tat Internet va nghe piano ngay tren website.' -ForegroundColor Green
exit 0
