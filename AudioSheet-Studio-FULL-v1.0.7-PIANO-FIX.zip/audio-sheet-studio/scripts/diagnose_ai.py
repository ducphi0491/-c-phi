r"""Deep, offline Basic Pitch diagnostics for AudioSheet Studio v1.0.0.

Run from the project root using the Python environment created by the installer:
    .venv\Scripts\python.exe scripts\diagnose_ai.py

Writes the traceback to data/ai_diagnostics.txt, without installing packages,
reading users' music, connecting to the network or modifying existing jobs.
"""
from __future__ import annotations

import contextlib
import importlib.metadata
import math
import platform
import sys
import tempfile
import traceback
import wave
from array import array
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
LOG_PATH = DATA_DIR / "ai_diagnostics.txt"


def write_test_wav(target: Path, sample_rate: int = 22050) -> None:
    """Write three seconds of a 440 Hz sine tone, using only stdlib modules."""
    frames = array("h")
    for n in range(sample_rate * 3):
        # Fade in and out to keep the synthetic note free of clicks.
        sec = n / sample_rate
        envelope = min(1.0, sec / 0.08, (3.0 - sec) / 0.08)
        signal = 0.28 * max(0.0, envelope) * math.sin(2.0 * math.pi * 440.0 * sec)
        frames.append(int(round(32767 * signal)))
    if sys.byteorder != "little":
        frames.byteswap()
    with wave.open(str(target), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(frames.tobytes())


def run_diagnostics() -> None:
    print("AUDIO SHEET STUDIO - AI DIAGNOSTICS")
    print("Project:", ROOT)
    print("Python:", platform.python_version())
    print("Python executable:", sys.executable)
    print("Platform:", platform.platform())

    for name in ("tensorflow", "basic-pitch", "numpy", "librosa", "music21"):
        try:
            print(f"Package {name}:", importlib.metadata.version(name))
        except importlib.metadata.PackageNotFoundError:
            print(f"Package {name}: NOT INSTALLED")

    print("\n[1/4] Import TensorFlow")
    import tensorflow as tf
    print("[OK] TensorFlow imported:", tf.__version__)

    print("\n[2/4] Import Basic Pitch, check model path")
    from basic_pitch import ICASSP_2022_MODEL_PATH
    model_path = Path(ICASSP_2022_MODEL_PATH)
    print("Basic Pitch model path:", model_path)
    print("Model path exists:", model_path.exists())
    if not model_path.exists():
        raise FileNotFoundError(f"Basic Pitch model files are missing: {model_path}")

    print("\n[3/4] Load the actual model used by the website")
    # Import the same module/model loader that the production code calls.
    sys.path.insert(0, str(ROOT))
    from app.transcriber import _get_model, transcribe
    model = _get_model()
    print("[OK] Model loaded:", type(model).__name__)
    print("Model runtime:", getattr(model, "model_type", "unknown"))

    print("\n[4/4] Test inference on generated audio")
    with tempfile.TemporaryDirectory(prefix="ai-probe-", dir=str(DATA_DIR)) as directory:
        test_dir = Path(directory)
        wav_path = test_dir / "test_440hz.wav"
        write_test_wav(wav_path)
        midi_path = test_dir / "test.mid"
        csv_path = test_dir / "test.csv"
        notes = transcribe(
            audio_path=wav_path,
            midi_path=midi_path,
            csv_path=csv_path,
            bpm=120.0,
            minimum_midi=36,
            maximum_midi=96,
            onset_threshold=0.5,
            frame_threshold=0.3,
            minimum_note_length_ms=127.7,
        )
        if not midi_path.is_file() or not csv_path.is_file():
            raise RuntimeError("Inference finished but MIDI/CSV output was not created")
        print(f"[OK] Inference completed; detected notes: {len(notes)}")
        print("[OK] MIDI and CSV generated successfully")
    print("\nRESULT: AI MODEL AND INFERENCE TEST PASSED")


def main() -> int:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("w", encoding="utf-8") as output:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            try:
                run_diagnostics()
                result = 0
            except Exception:
                print("\nRESULT: FAILED - full traceback follows")
                traceback.print_exc()
                result = 1
    print("Diagnostic log:", LOG_PATH)
    print("Result:", "PASS" if result == 0 else "FAIL - send the log file for diagnosis")
    return result


if __name__ == "__main__":
    raise SystemExit(main())
