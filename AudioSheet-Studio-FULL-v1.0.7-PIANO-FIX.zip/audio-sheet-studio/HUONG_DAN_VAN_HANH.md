# Huong dan nhanh v1.0.3 (Windows)

**Da cai ban cu:** Giai nen ZIP vao `C:\AudioSheetStudio`, ghi de file trung ten, giu nguyen `.venv` va `data/jobs`. Nhan dup `CHAY_WEBSITE.bat` de tu kiem tra va sua loi thieu `pkg_resources`.

**Cai moi:** Giai nen vao `C:\AudioSheetStudio`, cai Python 3.11 va FFmpeg, nhan dup `CHAY_WEBSITE.bat`. Node.js chi khuyen nghi neu dung YouTube. Neu Windows khong co `winget`, tai Python/FFmpeg/Node.js tu trang chinh thuc de cai thu cong.

**Loi AI:** Log chi tiet nam o `data/ai_diagnostics.txt`, chay `scripts/diagnose_ai.py` trong `.venv` neu can.

---

# HUONG DAN VAN HANH AUDIO SHEET STUDIO

## 1. Chuc nang da co

- Tai file MP3, WAV, FLAC, OGG, M4A, AAC hoac WEBM.
- Dan link YouTube hop le neu ban co quyen su dung noi dung.
- Nhan dang not bang Spotify Basic Pitch.
- Xuat file MIDI, MusicXML, CSV va JSON.
- Xem sheet ngay tren web bang OpenSheetMusicDisplay.
- Ba che do: Piano hai tay, Lead sheet va Ban chep tho.
- Tu dong uoc luong BPM hoac cho phep nhap BPM thu cong.
- Nghe lai file WAV da chuan hoa.
- In hoac luu PDF bang trinh duyet.
- Neu cai MuseScore va khai bao MUSESCORE_BIN, he thong tu tao them file PDF.

## 2. Yeu cau may Windows

Can cai cac thanh phan sau:

1. Python 3.11, khong dung Python 3.12/3.13 cho Basic Pitch 0.4.0.
2. FFmpeg va ffprobe.
3. Node.js LTS de ho tro yt-dlp xu ly YouTube tot hon.
4. RAM khuyen nghi tu 8 GB. TensorFlow va Basic Pitch dung kha nhieu bo nho.
5. MuseScore 4 la tuy chon, chi can khi muon server tu xuat PDF.

Lenh cai bang Windows Terminal hoac CMD chay voi quyen phu hop:

```bat
winget install Python.Python.3.11
winget install Gyan.FFmpeg
winget install OpenJS.NodeJS.LTS
```

Sau khi cai, dong CMD cu va mo lai CMD moi de PATH duoc cap nhat.

## 3. Cai dat lan dau tren Windows

1. Giai nen thu muc du an.
2. Mo thu muc `audio-sheet-studio`.
3. Bam dup `install_windows.bat`.
4. Script se tao `.venv`, cai thu vien Python va tai OpenSheetMusicDisplay.
5. Cuoi qua trinh, script chay `scripts/check_install.py` de kiem tra.

Neu thay dong `[MISSING] ffmpeg`, cai FFmpeg theo buoc 2 va chay lai script.

## 4. Khoi dong website

1. Bam dup `run_windows.bat`.
2. Khong dong cua so CMD trong luc dung website.
3. Trinh duyet se mo dia chi:

```text
http://127.0.0.1:8000
```

De dung he thong, bam `Ctrl + C` trong cua so CMD.

## 5. Cach su dung

### Cach A: Tai file am thanh

1. Chon tab `Tai file am thanh`.
2. Keo file vao khung hoac bam de chon.
3. Chon kieu sheet.
4. De BPM bang 0 neu muon tu dong uoc luong.
5. Chon nhip va muc luong tu hoa.
6. Xac nhan quyen su dung noi dung.
7. Bam `Tao sheet nhac`.

### Cach B: Link YouTube

1. Chon tab `Link YouTube`.
2. Dan link `youtube.com` hoac `youtu.be`.
3. Xac nhan ban co quyen xu ly noi dung.
4. Bam `Tao sheet nhac`.

Neu YouTube loi, kiem tra Node.js, FFmpeg, ket noi mang va cap nhat yt-dlp trong moi truong ao:

```bat
call .venv\Scripts\activate.bat
python -m pip install --upgrade "yt-dlp[default]"
```

## 6. Y nghia ba che do

### Piano hai tay

- Chia not theo moc MIDI mac dinh 60, tuong duong C4.
- Not tu moc chia tro len vao tay phai.
- Not thap hon vao tay trai.
- Co the thay doi `Diem tach tay piano` trong muc nang cao.

### Lead sheet

- Moi thoi diem onset chon not cao nhat lam giai dieu.
- He thong uoc luong hop am theo cao do xuat hien trong tung o nhip.
- Hop am chi la goi y, can kiem tra bang tai nghe va kien thuc nhac ly.

### Ban chep tho

- Giu nhieu not dong thoi nhat co the.
- Phu hop de mo tiep trong MuseScore va chinh sua thu cong.

## 7. Dieu chinh khi ket qua chua tot

- Qua nhieu not rac: tang `Nguong onset` tu 0.50 len 0.60 hoac 0.70.
- Not bi keo dai/nhieu: tang `Nguong frame` tu 0.30 len 0.40.
- Mat not nho: giam `Nguong onset` xuong 0.40.
- Qua nhieu not cuc ngan: tang `Not toi thieu` len 180-250 ms.
- Piano chia sai tay: doi `Diem tach tay piano` tu 60 sang 57, 59, 62 hoac 64.
- Nhip sai: nhap BPM thu cong thay vi de 0.
- Ban thu day du trong, bass, vocal va nhieu nhac cu se kem chinh xac hon solo piano/guitar.

## 8. Xuat PDF

### Cach don gian

Trong khu vuc ket qua, bam `In / Luu PDF`, sau do chon may in `Save as PDF` cua trinh duyet.

### Xuat PDF tu dong bang MuseScore

Cai MuseScore 4, sau do tao file `.env` tu `.env.example` va khai bao:

```text
MUSESCORE_BIN=C:\Program Files\MuseScore 4\bin\MuseScore4.exe
```

Luu y: phien ban MVP doc bien moi truong tu he dieu hanh. Neu chay truc tiep bang BAT, co the dat bien truoc khi chay:

```bat
set MUSESCORE_BIN=C:\Program Files\MuseScore 4\bin\MuseScore4.exe
run_windows.bat
```

## 9. Thu muc ket qua

Moi tac vu nam tai:

```text
data\jobs\<job_id>\
```

Cac file chinh:

- `normalized.wav`: am thanh mono 22.05 kHz.
- `transcription.mid`: MIDI tu Basic Pitch.
- `sheet.musicxml`: sheet de mo bang MuseScore, Dorico, Sibelius...
- `note_events.csv`: danh sach not.
- `note_events.json`: du lieu not dang JSON.
- `processor.log`: log neu tac vu bi loi.

## 10. Chay bang Docker

Can cai Docker Desktop, sau do chay:

```bat
docker compose up --build
```

Mo `http://127.0.0.1:8000`.

Dung container:

```bat
docker compose down
```

## 11. Trien khai len Internet

Ban MVP phu hop may ca nhan hoac mang noi bo. Truoc khi dua len website cong khai, can bo sung:

- Dang nhap va gioi han quyen nguoi dung.
- Reverse proxy HTTPS nhu Nginx/Caddy.
- Redis + Celery/RQ cho hang doi tac vu.
- PostgreSQL cho thong tin job.
- Gioi han tan suat, quota, quet tep va don dep du lieu dinh ky.
- Khong cong khai endpoint YouTube neu chua co quy trinh ban quyen.
- Tach worker AI khoi web server.

## 12. Gioi han hien tai

- Day la MVP, khong phai he thong ky am chuyen nghiep.
- Basic Pitch hoat dong tot nhat voi mot nhac cu tai mot thoi diem.
- Lead-sheet chord inference la heuristic, khong phai mo hinh hoa am chuyen sau.
- Chua co tach stem Demucs, chua co guitar tablature va chua co trinh sua not truc tiep tren web.
- File MusicXML nen duoc mo bang MuseScore de sua nhip, dau noi, phan be va enharmonic spelling.
