#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

if ! command -v python3.11 >/dev/null 2>&1; then
  echo "Python 3.11 is required."
  exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "Install ffmpeg and libsndfile1 with your system package manager."
  exit 1
fi

python3.11 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
mkdir -p web/vendor
python - <<'PY'
from pathlib import Path
from urllib.request import urlretrieve
url = "https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.1.3/build/opensheetmusicdisplay.min.js"
target = Path("web/vendor/opensheetmusicdisplay.min.js")
try:
    urlretrieve(url, target)
    print(f"Downloaded {target}")
except Exception as exc:
    print(f"OSMD download skipped: {exc}. CDN fallback remains available.")
PY
python scripts/check_install.py || true
