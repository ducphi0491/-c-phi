@echo off
setlocal
cd /d "%~dp0"

echo =============================================
echo AudioSheet Studio - Windows installation
echo =============================================

py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python 3.11 was not found.
  echo Install Python 3.11 from https://www.python.org/downloads/
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  py -3.11 -m venv .venv
  if errorlevel 1 exit /b 1
)

call .venv\Scripts\activate.bat
rem Pin setuptools below 82 to keep pkg_resources required by resampy/Basic Pitch.
python -m pip install --upgrade pip wheel "setuptools==80.9.0"
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

powershell -NoProfile -ExecutionPolicy Bypass -File scripts\download_osmd.ps1

where ffmpeg >nul 2>&1
if errorlevel 1 (
  echo.
  echo [WARNING] FFmpeg was not found.
  echo Install FFmpeg from https://ffmpeg.org/download.html
)

where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo [WARNING] Node.js was not found. YouTube extraction may be limited.
  echo Install Node.js LTS from https://nodejs.org/en/download
)

echo.
python scripts\check_install.py
if errorlevel 1 (
  echo.
  echo [ERROR] One or more required components are not ready.
  echo Review the messages above, fix the missing component, and run this installer again.
  pause
  exit /b 1
)
echo.
echo Installation finished. Run run_windows.bat to start the website.
pause
