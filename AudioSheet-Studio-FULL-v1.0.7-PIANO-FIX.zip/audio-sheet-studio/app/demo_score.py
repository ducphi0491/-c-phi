from __future__ import annotations

from pathlib import Path
from typing import Any

from .score_builder import write_musicxml


def demo_note_events() -> list[tuple[float, float, int, float, Any]]:
    bpm = 100.0
    beat_seconds = 60.0 / bpm
    melody = [60, 62, 64, 67, 69, 67, 64, 62, 60, 64, 67, 72, 71, 69, 67, 64]
    chords = [
        (0, [48, 52, 55]),
        (4, [45, 48, 52]),
        (8, [41, 45, 48]),
        (12, [43, 47, 50]),
    ]
    events: list[tuple[float, float, int, float, Any]] = []
    for index, pitch in enumerate(melody):
        start = index * beat_seconds
        events.append((start, start + beat_seconds * 0.9, pitch, 0.82, None))
    for beat, pitches in chords:
        start = beat * beat_seconds
        end = start + beat_seconds * 4
        for pitch in pitches:
            events.append((start, end, pitch, 0.58, None))
    return events


def create_demo_musicxml(path: Path, mode: str = "piano") -> Path:
    return write_musicxml(
        demo_note_events(),
        output_path=path,
        mode=mode,
        title="AudioSheet Studio Demo",
        bpm=100.0,
        time_signature="4/4",
        quantization=16,
        split_pitch=60,
    )
