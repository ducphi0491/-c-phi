"""Generate per-arrangement MusicXML without re-running Basic Pitch.

Pure Python on purpose: switching A/B/C does not require another neural model,
MuseScore, or any further package. Every written note comes from the selected
arrangement; no accompaniment is invented. Onsets/lengths are quantized for
notation, while the browser player keeps the original second-based timing.
"""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from xml.etree import ElementTree as ET

DIVISIONS = 480  # duration in ticks per quarter note
MAX_PART_VOICES = 32
MAX_MEASURES = 1200
PITCH_NAMES = ("C", "C", "D", "D", "E", "F", "F", "G", "G", "A", "A", "B")
SHARP_PCS = {1, 3, 6, 8, 10}


@dataclass
class NoteGroup:
    start: int
    end: int
    pitches: tuple[int, ...]
    voice: int = 1


def _add(parent: ET.Element, tag: str, value: str | int | float | None = None, **attrs: str) -> ET.Element:
    child = ET.SubElement(parent, tag, attrs)
    if value is not None:
        child.text = str(value)
    return child


def _duration_chunks(ticks: int) -> list[tuple[int, str, bool]]:
    """Spell a positive duration using ordinary (possibly dotted) note values."""
    options = []
    for length, kind in (
        (1920, "whole"), (960, "half"), (480, "quarter"),
        (240, "eighth"), (120, "16th"), (60, "32nd"), (30, "64th"),
    ):
        options.append((length * 3 // 2, kind, True))
        options.append((length, kind, False))
    options.sort(key=lambda x: x[0], reverse=True)
    chunks = []
    while ticks > 0:
        duration, kind, dotted = next((x for x in options if x[0] <= ticks), (30, "64th", False))
        chunks.append((duration, kind, dotted))
        ticks -= duration
    return chunks


def _safely_round(value: float, step: int) -> int:
    return int(round(value / step)) * step


def _pitch_xml(parent: ET.Element, midi_pitch: int) -> None:
    pitch = _add(parent, "pitch")
    pc = midi_pitch % 12
    _add(pitch, "step", PITCH_NAMES[pc])
    if pc in SHARP_PCS:
        _add(pitch, "alter", 1)
    _add(pitch, "octave", midi_pitch // 12 - 1)


def _emit_note(parent: ET.Element, pitches: tuple[int, ...] | None, duration: int,
               kind: str, dotted: bool, voice: int, tie_stop: bool = False,
               tie_start: bool = False) -> None:
    for index, pitch in enumerate(pitches if pitches is not None else (None,)):
        note = _add(parent, "note")
        if index > 0:
            _add(note, "chord")
        if pitch is None:
            _add(note, "rest")
        else:
            _pitch_xml(note, pitch)
        _add(note, "duration", duration)
        if pitch is not None and tie_stop:
            _add(note, "tie", type="stop")
        if pitch is not None and tie_start:
            _add(note, "tie", type="start")
        _add(note, "voice", voice)
        _add(note, "type", kind)
        if dotted:
            _add(note, "dot")
        if pitch is not None and (tie_start or tie_stop):
            notations = _add(note, "notations")
            if tie_stop:
                _add(notations, "tied", type="stop")
            if tie_start:
                _add(notations, "tied", type="start")


def _write_duration(parent: ET.Element, pitches: tuple[int, ...] | None,
                    ticks: int, voice: int, continuation_before: bool = False,
                    continuation_after: bool = False) -> None:
    chunks = _duration_chunks(ticks)
    for index, (duration, kind, dotted) in enumerate(chunks):
        _emit_note(parent, pitches, duration, kind, dotted, voice,
                   tie_stop=(index > 0 or continuation_before) if pitches else False,
                   tie_start=(index < len(chunks) - 1 or continuation_after) if pitches else False)


def _place_voices(notes: list[dict], bpm: float, divisions: int,
                  quantum: int) -> list[NoteGroup]:
    """Put simultaneous notes into chords; overlapping different chords into voices."""
    groups: dict[tuple[int, int], set[int]] = defaultdict(set)
    scale = bpm / 60.0 * divisions
    for note in notes:
        try:
            start = float(note["start"])
            end = float(note["end"])
            pitch = int(note["pitch"])
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
            continue
        if not 0 <= pitch <= 127 or start > 1200:
            continue
        s = max(0, _safely_round(start * scale, quantum))
        e = max(s + quantum, _safely_round(end * scale, quantum))
        groups[(s, e)].add(pitch)
    chunks = [NoteGroup(s, e, tuple(sorted(pitches))) for (s, e), pitches in groups.items()]
    chunks.sort(key=lambda x: (x.start, x.end, x.pitches))
    lanes: list[int] = []
    for group in chunks:
        # Use the lowest available voice; a different on/off at the same time
        # creates another voice rather than corrupting the note's duration.
        for i, end in enumerate(lanes):
            if end <= group.start:
                lanes[i] = group.end
                group.voice = i + 1
                break
        else:
            if len(lanes) >= MAX_PART_VOICES:
                # Extremely dense AI artefacts should not produce an unbounded
                # sheet; keep this event but reuse the first available lane by
                # ending the previous overlapping event early.
                ix = min(range(len(lanes)), key=lanes.__getitem__)
                prev = next((x for x in reversed(chunks[:chunks.index(group)]) if x.voice == ix + 1), None)
                if prev and prev.end > group.start:
                    prev.end = max(prev.start + quantum, group.start)
                lanes[ix] = group.end
                group.voice = ix + 1
            else:
                lanes.append(group.end)
                group.voice = len(lanes)
    return chunks


def _render_part(score: ET.Element, part_id: str, groups: list[NoteGroup],
                 title: str, beats: int, beat_type: int, clef: str,
                 bars: int, ticks_per_measure: int, bpm: float) -> None:
    part = _add(score, "part", id=part_id)
    measure_segments: dict[tuple[int, int], list[tuple[int, int, tuple[int, ...], bool, bool]]] = defaultdict(list)
    for group in groups:
        cursor = group.start
        while cursor < group.end:
            bar = cursor // ticks_per_measure
            local = cursor % ticks_per_measure
            stop = min(group.end, (bar + 1) * ticks_per_measure)
            span = stop - cursor
            measure_segments[(bar, group.voice)].append((local, span, group.pitches,
                                                          cursor > group.start, stop < group.end))
            cursor = stop

    for i in range(bars):
        measure = _add(part, "measure", number=str(i + 1))
        if i == 0:
            attrs = _add(measure, "attributes")
            _add(attrs, "divisions", DIVISIONS)
            key = _add(attrs, "key")
            _add(key, "fifths", 0)  # no unverified key-signature inference
            time = _add(attrs, "time")
            _add(time, "beats", beats)
            _add(time, "beat-type", beat_type)
            cf = _add(attrs, "clef")
            _add(cf, "sign", clef)
            _add(cf, "line", 2 if clef == "G" else 4)
            direction = _add(measure, "direction", placement="above")
            dt = _add(direction, "direction-type")
            metronome = _add(dt, "metronome")
            _add(metronome, "beat-unit", "quarter")
            _add(metronome, "per-minute", round(bpm, 2))
            _add(direction, "sound", tempo=str(round(bpm, 2)))

        voices = sorted(v for (bar, v) in measure_segments if bar == i)
        if not voices:
            _write_duration(measure, None, ticks_per_measure, 1)
            continue
        for k, voice in enumerate(voices):
            if k:
                back = _add(measure, "backup")
                _add(back, "duration", ticks_per_measure)
            offset = 0
            for local, span, pitches, tied_from, tied_to in sorted(measure_segments[(i, voice)]):
                if local > offset:
                    _write_duration(measure, None, local - offset, voice)
                # Voice assignment guarantees these sequences do not overlap.
                _write_duration(measure, pitches, span, voice, tied_from, tied_to)
                offset = local + span
            if offset < ticks_per_measure:
                _write_duration(measure, None, ticks_per_measure - offset, voice)


def create_arrangement_xml(notes: list[dict], mode: str, title: str,
                           bpm: float = 100, time_signature: str = "4/4",
                           quantization: int = 16, split_pitch: int = 60,
                           duration_seconds: float = 0) -> bytes:
    """Create reflowable MusicXML containing only the selected mode's notes."""
    if mode not in {"melody", "light", "full"}:
        raise ValueError("Invalid sheet mode")
    if not 30 <= float(bpm) <= 250:
        bpm = 100.0
    if quantization not in {8, 16, 32}:
        quantization = 16
    if time_signature not in {"4/4", "3/4", "6/8"}:
        time_signature = "4/4"
    beats, beat_type = map(int, time_signature.split("/"))
    measure_ticks = DIVISIONS * 4 * beats // beat_type
    quantum = DIVISIONS * 4 // quantization
    valid = [n for n in notes if isinstance(n, dict)]
    if mode == "melody":
        right, left = valid, []
    elif mode == "light":
        right = [n for n in valid if n.get("staff") != "lower"]
        left = [n for n in valid if n.get("staff") == "lower"]
    else:
        right = [n for n in valid if int(n.get("pitch", 60)) >= split_pitch]
        left = [n for n in valid if int(n.get("pitch", 60)) < split_pitch]

    rh = _place_voices(right, bpm, DIVISIONS, quantum)
    lh = _place_voices(left, bpm, DIVISIONS, quantum)
    end_tick = max([int(max(0, duration_seconds) * bpm / 60 * DIVISIONS)]
                   + [n.end for n in rh + lh])
    bar_count = max(1, min(MAX_MEASURES, math.ceil(end_tick / measure_ticks)))

    root = ET.Element("score-partwise", version="4.0")
    _add(root, "work")
    _add(root, "movement-title", title[:160] or "AudioSheet Studio")
    identification = _add(root, "identification")
    _add(identification, "creator", "AudioSheet Studio - ghi lai theo che do " + mode, type="composer")
    defaults = _add(root, "defaults")
    scaling = _add(defaults, "scaling")
    _add(scaling, "millimeters", 7)
    _add(scaling, "tenths", 40)
    parts = _add(root, "part-list")
    two_staves = mode != "melody"
    if two_staves:
        part_group = _add(parts, "part-group", number="1", type="start")
        _add(part_group, "group-symbol", "brace")
        _add(part_group, "group-barline", "yes")
    right_def = _add(parts, "score-part", id="P1")
    _add(right_def, "part-name", "Giai dieu" if not two_staves else "Piano - tay phai")
    _add(right_def, "part-abbreviation", "RH" if two_staves else "Mel")
    if two_staves:
        left_def = _add(parts, "score-part", id="P2")
        _add(left_def, "part-name", "Piano - tay trai")
        _add(left_def, "part-abbreviation", "LH")
        _add(parts, "part-group", number="1", type="stop")
    _render_part(root, "P1", rh, "RH", beats, beat_type, "G", bar_count, measure_ticks, bpm)
    if two_staves:
        _render_part(root, "P2", lh, "LH", beats, beat_type, "F", bar_count, measure_ticks, bpm)

    # ElementTree escapes user-supplied titles and note content automatically.
    xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    header = b'<!DOCTYPE score-partwise  PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">\n'
    return xml[:xml.find(b"?>") + 2] + b"\n" + header + xml[xml.find(b"?>") + 2:]
