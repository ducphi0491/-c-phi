from __future__ import annotations

import csv
import math
import threading
from pathlib import Path
from typing import Any


_model: Any = None
_model_lock = threading.Lock()
_inference_lock = threading.Lock()


def midi_to_hz(note_number: int) -> float:
    return 440.0 * (2.0 ** ((note_number - 69) / 12.0))


def _get_model() -> Any:
    global _model
    if _model is not None:
        return _model
    with _model_lock:
        if _model is None:
            from basic_pitch import ICASSP_2022_MODEL_PATH
            from basic_pitch.inference import Model

            _model = Model(ICASSP_2022_MODEL_PATH)
    return _model


def transcribe(
    audio_path: Path,
    midi_path: Path,
    csv_path: Path,
    bpm: float,
    minimum_midi: int,
    maximum_midi: int,
    onset_threshold: float,
    frame_threshold: float,
    minimum_note_length_ms: float,
) -> list[tuple[float, float, int, float, Any]]:
    if not 0 <= minimum_midi < maximum_midi <= 127:
        raise ValueError("MIDI range must be between 0 and 127")
    if not math.isfinite(bpm) or not 20 <= bpm <= 300:
        raise ValueError("BPM must be between 20 and 300")

    try:
        from basic_pitch.inference import predict
    except ImportError as exc:
        raise RuntimeError(
            "Basic Pitch is not installed. Run the installation script with Python 3.11."
        ) from exc

    model = _get_model()
    with _inference_lock:
        _, midi_data, note_events = predict(
            audio_path,
            model,
            onset_threshold=onset_threshold,
            frame_threshold=frame_threshold,
            minimum_note_length=minimum_note_length_ms,
            minimum_frequency=midi_to_hz(minimum_midi),
            maximum_frequency=midi_to_hz(maximum_midi),
            midi_tempo=bpm,
        )
    midi_data.write(str(midi_path))

    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["start_time_s", "end_time_s", "pitch_midi", "velocity", "pitch_bend"])
        for start, end, pitch, amplitude, bends in note_events:
            writer.writerow([start, end, pitch, round(float(amplitude) * 127), bends or ""])

    return note_events
