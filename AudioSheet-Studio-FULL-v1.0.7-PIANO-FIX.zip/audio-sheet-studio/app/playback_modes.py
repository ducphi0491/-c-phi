"""Three optional listening arrangements based on one Basic Pitch transcription.

These are *post-processing presets*, not separate neural-network models. They
leave the transcription, saved note_events.json and the MusicXML untouched.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Iterable

MAX_EVENTS = 60000


def _quantile(values: list[int], portion: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * portion)))
    return float(ordered[index])


def clean_notes(raw: Iterable[dict[str, Any]]) -> list[dict[str, int | float]]:
    """Validate and time-sort Basic Pitch JSON events (which may be unsorted)."""
    notes: list[dict[str, int | float]] = []
    for index, item in enumerate(raw):
        if index >= MAX_EVENTS:
            break
        if not isinstance(item, dict):
            continue
        try:
            start = float(item['start'])
            end = float(item['end'])
            pitch = int(item['pitch'])
            velocity = int(item.get('velocity', 80))
        except (TypeError, ValueError, KeyError, OverflowError):
            continue
        if not all(map(math.isfinite, (start, end))):
            continue
        if start < 0 or start > 3600 or end <= start + 0.025:
            continue
        if not 0 <= pitch <= 127:
            continue
        notes.append({
            'start': round(start, 5),
            'end': round(min(end, start + 18), 5),
            'pitch': pitch,
            'velocity': max(1, min(127, velocity)),
        })
    notes.sort(key=lambda n: (n['start'], -n['pitch'], -n['velocity']))
    return notes


def merge_fragments(notes: list[dict[str, int | float]], max_gap: float = 0.045) -> list[dict[str, int | float]]:
    """Join adjacent pitches likely created by segmentation (conservative).

    Repeated staccato notes are retained if there is a noticeable gap or
    velocity jump, so this is only a *heuristic*, not an error classifier.
    """
    by_pitch: dict[int, list[dict[str, int | float]]] = defaultdict(list)
    for note in notes:
        by_pitch[int(note['pitch'])].append(note)
    result = []
    for pitch, group in by_pitch.items():
        group.sort(key=lambda n: n['start'])
        previous: dict[str, int | float] | None = None
        for note in group:
            if previous is None:
                previous = dict(note)
                continue
            gap = note['start'] - previous['end']
            part_length = note['end'] - note['start']
            previous_span = previous['end'] - previous['start']
            # Keep genuinely repeated hits: merge only short, nearly attached
            # pieces with approximately stable velocity.
            joined = (
                -0.025 <= gap <= max_gap
                and part_length <= 0.60
                and previous_span <= 2.0
                and abs(note['velocity'] - previous['velocity']) <= 22
            )
            if joined:
                previous['end'] = max(previous['end'], note['end'])
                previous['velocity'] = max(previous['velocity'], note['velocity'])
            else:
                result.append(previous)
                previous = dict(note)
        if previous is not None:
            result.append(previous)
    result.sort(key=lambda n: (n['start'], -n['pitch']))
    return result


def extract_melody(notes: list[dict[str, int | float]]) -> list[dict[str, int | float]]:
    """Extract one predominant note at a time from AI note hypotheses."""
    if not notes:
        return []
    pitches = [int(n['pitch']) for n in notes]
    velocities = [int(n['velocity']) for n in notes]
    pitch_floor = max(35, min(83, int(_quantile(pitches, 0.46))))
    velocity_floor = max(38, int(_quantile(velocities, 0.32)))
    candidates = [n for n in notes if n['pitch'] >= pitch_floor and n['velocity'] >= velocity_floor]
    if not candidates:
        candidates = notes

    # Collate almost simultaneous attacks; a melody must be monophonic.
    groups: list[list[dict[str, int | float]]] = []
    for note in candidates:
        if groups and (note['start'] - groups[-1][0]['start']) <= 0.090:
            groups[-1].append(note)
        else:
            groups.append([note])

    lead = []
    for group in groups:
        prev_pitch = int(lead[-1]['pitch']) if lead else None
        def score(n: dict[str, int | float]) -> float:
            continuity = -0.65 * abs(n['pitch'] - prev_pitch) if prev_pitch is not None else 0.0
            duration_bonus = min(0.8, n['end'] - n['start']) * 12
            return 0.7 * n['velocity'] + 0.42 * n['pitch'] + duration_bonus + continuity
        chosen = max(group, key=score)
        if lead and chosen['start'] < lead[-1]['start'] + 0.085:
            continue
        lead.append(dict(chosen))

    for i, note in enumerate(lead):
        if i + 1 < len(lead):
            # Don't let synthetic notes overlap in the monophonic melody.
            note['end'] = round(min(note['end'], lead[i + 1]['start']), 5)
        note['velocity'] = max(45, min(102, round(note['velocity'] * 0.86)))
        note['end'] = max(note['end'], note['start'] + 0.055)
    return lead


def extract_light_bass(notes: list[dict[str, int | float]], melody: list[dict[str, int | float]]) -> list[dict[str, int | float]]:
    if not notes:
        return []
    pitches = [int(n['pitch']) for n in notes]
    floor = min(59, int(_quantile(pitches, 0.36)))
    candidates = [n for n in notes if n['pitch'] <= floor and n['velocity'] >= 35]
    bass: list[dict[str, int | float]] = []
    # One bass note per approximately 1-second time span, avoiding a wall of bass.
    last_at = -5.0
    for note in sorted(candidates, key=lambda n: (n['start'], -n['velocity'])):
        if note['start'] < last_at + 1.05:
            continue
        if any(abs(note['start'] - m['start']) < 0.07 and note['pitch'] == m['pitch'] for m in melody):
            continue
        bass.append({
            'start': note['start'],
            'end': round(min(note['end'], note['start'] + 1.2), 5),
            'pitch': note['pitch'],
            'velocity': 35,
        })
        last_at = note['start']
    return bass


def prepare_variants(raw: Iterable[dict[str, Any]], reference: Iterable[dict[str, Any]] | None = None) -> dict[str, Any]:
    original = clean_notes(raw)
    merged = merge_fragments(original)
    melody = extract_melody(merged)
    bass = extract_light_bass(merged, melody)
    # Staff roles are kept with the actual A/B/C note data; the MusicXML
    # generator and piano player therefore use the same arrangement.  A bass
    # note at a higher register must still go to the left-hand staff.
    light = sorted(
        [dict(n, staff='upper') for n in melody]
        + [dict(n, staff='lower') for n in bass],
        key=lambda n: (n['start'], -n['pitch']),
    )
    reference_notes = clean_notes(reference) if reference is not None else []
    used_reference = reference is not None and bool(reference_notes)
    # Align the first attacks approximately when comparing a third-party MIDI
    # export (often starting at t=0) with Basic Pitch (often starts after intro).
    reference_offset = 0.0
    if used_reference and original:
        reference_offset = round(original[0]['start'] - reference_notes[0]['start'], 4)
        if abs(reference_offset) > 0.025:
            for note in reference_notes:
                note['start'] = round(max(0.0, note['start'] + reference_offset), 5)
                note['end'] = round(max(note['start'] + 0.03, note['end'] + reference_offset), 5)
    # Full mode intentionally keeps the original AI notes so differences are audible.
    full = reference_notes if used_reference else original
    duration = max((n['end'] for n in original), default=0)
    duration = max(duration, max((n['end'] for n in reference_notes), default=0))
    return {
        'version': 1,
        'source': 'Basic Pitch + post-processing',
        'raw_count': len(original),
        'merged_count': len(merged),
        'duration_seconds': round(duration, 2),
        'reference_active': used_reference,
        'reference_offset_seconds': reference_offset,
        'modes': {
            'melody': {'label': 'A · Giai điệu mỏng', 'count': len(melody), 'notes': melody},
            'light': {'label': 'B · Giai điệu + đệm nhẹ', 'count': len(light), 'notes': light},
            'full': {
                'label': 'C · MIDI tham chiếu' if used_reference else 'C · Toàn bộ nốt AI',
                'count': len(full), 'notes': full,
            },
        },
    }


def midi_to_events(midi_path: str) -> list[dict[str, int | float]]:
    """Read a user-supplied local MIDI as an optional comparison for mode C."""
    import pretty_midi

    midi = pretty_midi.PrettyMIDI(midi_path)
    data = []
    for instrument in midi.instruments:
        if instrument.is_drum:
            continue
        for note in instrument.notes:
            data.append({
                'start': note.start, 'end': note.end,
                'pitch': note.pitch, 'velocity': note.velocity,
            })
            if len(data) >= MAX_EVENTS:
                raise ValueError('Reference MIDI has too many notes (maximum 60000).')
    if not data:
        raise ValueError('The reference MIDI contains no playable pitched notes.')
    if max(n['end'] for n in data) > 1200:
        raise ValueError('The reference MIDI is too long (over 20 minutes).')
    return clean_notes(data)


def write_mode_midi(notes: list[dict[str, int | float]], out_path: str, bpm: float = 100) -> None:
    """Export the *selected audible arrangement* as a conventional MIDI file."""
    import pretty_midi

    midi = pretty_midi.PrettyMIDI(initial_tempo=float(bpm) if 30 <= float(bpm) <= 250 else 100)
    piano = pretty_midi.Instrument(program=0, name='AudioSheet Piano')
    for n in notes:
        piano.notes.append(pretty_midi.Note(
            velocity=int(n['velocity']), pitch=int(n['pitch']),
            start=float(n['start']), end=float(n['end']),
        ))
    midi.instruments.append(piano)
    midi.write(out_path)
