from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


class ExternalToolError(RuntimeError):
    pass


def command_exists(command: str) -> bool:
    return bool(shutil.which(command))


def run_command(args: list[str], timeout: int = 900) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            args,
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise ExternalToolError(f"Required command was not found: {args[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise ExternalToolError(f"Command timed out: {args[0]}") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "Unknown command error").strip()
        raise ExternalToolError(detail[-2000:]) from exc


def probe_duration(path: Path) -> float:
    completed = run_command(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "json",
            str(path),
        ],
        timeout=60,
    )
    try:
        payload = json.loads(completed.stdout)
        return float(payload["format"]["duration"])
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ExternalToolError("ffprobe could not read the audio duration") from exc


def normalize_audio(source: Path, target: Path, max_seconds: int) -> float:
    if not command_exists("ffmpeg") or not command_exists("ffprobe"):
        raise ExternalToolError("FFmpeg and ffprobe must be installed and available in PATH")
    duration = probe_duration(source)
    if duration <= 0:
        raise ValueError("The audio file has no readable duration")
    if duration > max_seconds:
        raise ValueError(
            f"Audio is {duration:.1f} seconds long; the configured limit is {max_seconds} seconds"
        )
    run_command(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-i",
            str(source),
            "-vn",
            "-ac",
            "1",
            "-ar",
            "22050",
            "-c:a",
            "pcm_s16le",
            str(target),
        ],
        timeout=max(180, int(duration * 4)),
    )
    return duration


def estimate_bpm(audio_path: Path) -> float:
    try:
        import librosa
        import numpy as np

        audio, sample_rate = librosa.load(str(audio_path), sr=22050, mono=True)
        tempo, _ = librosa.beat.beat_track(y=audio, sr=sample_rate)
        value = float(np.asarray(tempo).reshape(-1)[0])
        if 40 <= value <= 240:
            return round(value, 1)
    except Exception:
        pass
    return 120.0


def download_youtube(
    url: str,
    output_dir: Path,
    max_seconds: int,
    max_bytes: int,
) -> tuple[Path, dict[str, Any]]:
    try:
        from yt_dlp import YoutubeDL
        from yt_dlp.utils import DownloadError
    except ImportError as exc:
        raise RuntimeError("yt-dlp is not installed") from exc

    output_dir.mkdir(parents=True, exist_ok=True)
    options: dict[str, Any] = {
        "format": "bestaudio/best",
        "outtmpl": str(output_dir / "youtube_source.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": True,
        "socket_timeout": 30,
        "retries": 3,
        "fragment_retries": 3,
        "max_filesize": max_bytes,
        "postprocessors": [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "wav",
                "preferredquality": "0",
            }
        ],
    }

    try:
        with YoutubeDL({**options, "skip_download": True}) as ydl:
            info = ydl.extract_info(url, download=False)
        if not isinstance(info, dict):
            raise ValueError("Could not read YouTube metadata")
        duration = float(info.get("duration") or 0)
        if duration <= 0:
            raise ValueError("Live streams and videos without a known duration are not supported")
        if duration > max_seconds:
            raise ValueError(
                f"Video is {duration:.1f} seconds long; the configured limit is {max_seconds} seconds"
            )
        if info.get("is_live"):
            raise ValueError("Live streams are not supported")

        with YoutubeDL(options) as ydl:
            ydl.download([url])
    except DownloadError as exc:
        raise RuntimeError(f"YouTube download failed: {exc}") from exc

    candidates = sorted(
        [
            path
            for path in output_dir.glob("youtube_source.*")
            if path.suffix.lower() in {".wav", ".mp3", ".m4a", ".webm", ".ogg", ".aac"}
        ],
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise RuntimeError("yt-dlp finished but no audio file was produced")
    return candidates[0], info
