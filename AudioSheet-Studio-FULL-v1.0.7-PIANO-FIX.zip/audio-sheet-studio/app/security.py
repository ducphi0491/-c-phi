from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse


ALLOWED_AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac", ".webm"}
YOUTUBE_HOSTS = {
    "youtube.com",
    "www.youtube.com",
    "m.youtube.com",
    "music.youtube.com",
    "youtu.be",
}


def safe_filename(name: str, fallback: str = "audio") -> str:
    base = Path(name or fallback).name
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._")
    return stem[:120] or fallback


def validate_audio_filename(name: str) -> str:
    safe = safe_filename(name)
    suffix = Path(safe).suffix.lower()
    if suffix not in ALLOWED_AUDIO_EXTENSIONS:
        allowed = ", ".join(sorted(ALLOWED_AUDIO_EXTENSIONS))
        raise ValueError(f"Unsupported audio file. Allowed extensions: {allowed}")
    return safe


def validate_youtube_url(url: str) -> str:
    value = (url or "").strip()
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("The YouTube URL must start with http:// or https://")
    if parsed.username or parsed.password:
        raise ValueError("URLs containing credentials are not allowed")
    host = (parsed.hostname or "").lower().rstrip(".")
    if host not in YOUTUBE_HOSTS:
        raise ValueError("Only youtube.com and youtu.be links are accepted")
    return value
