from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parent.parent


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"\"", "'"}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


_load_env_file(ROOT_DIR / ".env")


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    root_dir: Path = ROOT_DIR
    data_dir: Path = Path(os.getenv("DATA_DIR", str(ROOT_DIR / "data"))).resolve()
    web_dir: Path = Path(os.getenv("WEB_DIR", str(ROOT_DIR / "web"))).resolve()
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "80"))
    max_audio_seconds: int = int(os.getenv("MAX_AUDIO_SECONDS", "600"))
    worker_count: int = max(1, int(os.getenv("WORKER_COUNT", "1")))
    allow_youtube: bool = _env_bool("ALLOW_YOUTUBE", True)
    keep_source_audio: bool = _env_bool("KEEP_SOURCE_AUDIO", True)
    musescore_bin: str = os.getenv("MUSESCORE_BIN", "").strip()


settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
settings.web_dir.mkdir(parents=True, exist_ok=True)
