﻿TUNERTOOLS - DOCUMENTS UPLOAD LEN GOOGLE DRIVE (NGUON MOI 2026-11-06)

NGUON DOC DA CAP NHAT: C:\TunerTools\Data\Documents
THU MUC DICH TRÊN GOOGLE DRIVE: My Drive / TunerTools_AppBackup / document

CACH 1: Neu da giai nen ZIP cu trong C:\TunerTools\BackupScripts\Drive_Documents,
KHONG CAN TAI ZIP MOI. Chay lenh sau trong PowerShell:

powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File "C:\TunerTools\BackupScripts\Drive_Documents\CHAY_UPLOAD_DOCUMENTS.ps1" `
  -SourceDir "C:\TunerTools\Data\Documents"

CACH 2: De doi mac dinh cho lan chay tiep theo:
1. Tai ZIP TunerTools_Documents_Nguon_Moi_20261106.zip ve Downloads.
2. Giai nen de CHÉP DE cac script cu trong
   C:\TunerTools\BackupScripts\Drive_Documents
3. Chay CHAY_UPLOAD_DOCUMENTS.bat (khong can them -SourceDir).

HOAC: De ZIP va file 00_GiaiNen_Upload_Documents.ps1 trong Downloads,
chay:
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File "$env:USERPROFILE\Downloads\00_GiaiNen_Upload_Documents.ps1"

OAuth: tu tim drive_token.json cu tai:
C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json

BAO CAO KET QUA:
C:\TunerTools\BackupPrep\Drive_Documents\KET_QUA_UPLOAD_DOCUMENTS.txt

CHI SAU KHI status=complete va index day du:
- Dua documents_drive_index.php (sinh tu du lieu that) va
  api_documents_drive.php len Alwaysdata.
- Kiem tra https://tuner.alwaysdata.net/api_documents_drive.php?action=health
- Sau do moi kich hoat Gamefolder.kt DrivePrimary.

LOI NHAC AN TOAN:
- Khong xoa hoac thay doi du lieu nguon tren Windows.
- Khong gui OAuth JSON vao chat, khong upload OAuth JSON len web.
- Neu file nguon khong ton tai hoac khong co anh/PDF/video, upload se dung.
- Chi dong bo file media duoc ho tro; khong dong bo tep khac va _private/_pending.
- Khi cap nhat tai lieu tren IIS ve sau, can chay dong bo lai.
