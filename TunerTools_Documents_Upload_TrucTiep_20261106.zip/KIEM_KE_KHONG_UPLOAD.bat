@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp003_drive_documents.ps1" -SourceDir "C:\TunerTools\Data\Documents"
set "EC=%ERRORLEVEL%"
echo.
pause
exit /b %EC%
