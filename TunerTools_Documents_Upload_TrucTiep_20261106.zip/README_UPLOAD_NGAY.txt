TUNERTOOLS DOCUMENTS - UPLOAD TRUC TIEP LEN GOOGLE DRIVE (BAN HIEN TIEN DO)

Su dung du lieu tu C:\TunerTools\Data\Documents\
Chay tren may Windows co OAuth token cu Drive_Buoc2D\drive_token.json.

1) KHONG CHAY 2 LAN UPLOAD CUNG LUC.
2) Neu PowerShell cu CHUA tra ve dong PS C:\...>, no co the dang tinh MD5.
   Mo CUA SO POWERSHELL MOI, chay:
   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\BackupScripts\Drive_Documents\KIEM_TRA_UPLOAD.ps1"
3) Neu muon dung ban moi: dung lenh cu Ctrl+C truoc, sau do giai nen ZIP moi vao thu muc cu (ghi de).
4) Bat dau:
   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\BackupScripts\Drive_Documents\CHAY_UPLOAD_DOCUMENTS.ps1" -SourceDir "C:\TunerTools\Data\Documents"
5) Ban moi quet ten/kich thuoc nhanh, sau do tinh MD5 tung file va upload ngay.
   Google Drive: My Drive/TunerTools_AppBackup/document (khong xoa nguon).
6) Bao cao: C:\TunerTools\BackupPrep\Drive_Documents\KET_QUA_UPLOAD_DOCUMENTS.txt
7) Khi status complete, upload documents_drive_index.php len alwaysdata.

CANH BAO: Ban than file ZIP va PowerShell khong chuyen du lieu tru khi duoc chay tren may co du lieu va OAuth.
KHONG GUI TOKEN CHO NGUOI KHAC.
