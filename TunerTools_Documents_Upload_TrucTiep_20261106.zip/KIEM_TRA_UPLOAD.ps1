﻿param([string]$OutputDir = 'C:\TunerTools\BackupPrep\Drive_Documents')
$manifest = Join-Path $OutputDir 'documents_drive_manifest.json'
if (Test-Path -LiteralPath $manifest) {
    try {
        $m = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json
        $done = @($m.files | Where-Object { $_.status -in @('uploaded', 'updated', 'unchanged') }).Count
        $failed = @($m.files | Where-Object { $_.status -eq 'error' }).Count
        Write-Host "Google Drive status: $($m.status) | Completed: $done/$($m.total_files) | Error: $failed" -ForegroundColor Cyan
        if ($m.documents_drive_id) { Write-Host "Drive Folder ID: $($m.documents_drive_id)" }
    } catch { Write-Host 'Manifest currently being updated.' -ForegroundColor Yellow }
} else { Write-Host 'Manifest not yet created; startup inventory may be running.' -ForegroundColor Yellow }
$latestLog = Get-ChildItem -LiteralPath $OutputDir -Filter 'documents_upload_*.log' -File -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latestLog) {
    Write-Host ("Latest log: " + $latestLog.FullName)
    Get-Content -LiteralPath $latestLog.FullName -Tail 14 -ErrorAction SilentlyContinue
}
$jobs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match '^(python|python3|py)(\.exe)?$' -and $_.CommandLine -like '*03_upload_documents.py*'
})
if ($jobs.Count -gt 0) { Write-Host 'Uploader process: RUNNING. Do not start a second upload.' -ForegroundColor Green }
else { Write-Host 'No active Documents Python uploader found. Check last log or final report.' -ForegroundColor Yellow }
