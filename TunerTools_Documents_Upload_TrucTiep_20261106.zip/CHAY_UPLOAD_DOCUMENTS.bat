@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CHAY_UPLOAD_DOCUMENTS.ps1" %*
set "EC=%ERRORLEVEL%"
echo.
if not "%EC%"=="0" (
  echo [ERROR] Upload failed or is incomplete. See the message above.
  echo Re-run the same file after fixing the issue. Finished Drive files will be skipped.
) else (
  echo [OK] Check the summary inside C:\TunerTools\BackupPrep\Drive_Documents
)
echo.
pause
exit /b %EC%
