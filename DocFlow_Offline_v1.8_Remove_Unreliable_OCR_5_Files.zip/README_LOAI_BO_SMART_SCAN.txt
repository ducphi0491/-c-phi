DOCFLOW OFFLINE - LOAI BO SMART SCAN OCR KHONG ON DINH

Ly do loai bo:
- OCR Tesseract tong quat khong du tin cay de khoi phuc chinh xac bang tinh day dac tu anh chup man hinh.
- Ti le tin cay OCR khong dam bao do dung cua tung chu so, hang/cot hoac o gop.
- Sai mot chu so trong bang ke toan/san xuat co the gay hau qua lon.

FILE CAN THAY:
1. app/src/main/java/com/docflowoffline/MainActivity.kt
2. app/src/main/java/com/docflowoffline/DocumentScreens.kt
3. app/src/main/java/com/docflowoffline/DocumentEngines.kt
4. app/build.gradle.kts
5. settings.gradle.kts

FILE/THU MUC CAN XOA THU CONG NEU DANG TON TAI:
- app/src/main/assets/tessdata/eng.traineddata
- app/src/main/assets/tessdata/vie.traineddata
- Neu thu muc app/src/main/assets/tessdata rong, xoa ca thu muc tessdata.

CHUC NANG DUOC GIU LAI:
- Anh -> PDF
- PDF -> PNG
- PDF -> Word/Excel voi PDF co lop van ban (gioi han nhu cu)
- Word, Excel, PDF editor va cac cong cu PDF

CHUC NANG DA LOAI BO:
- Camera/anh -> Excel bang OCR
- Camera/anh -> Word bang OCR
- Man hinh Smart Scan
- Thu vien Tesseract va ExifInterface chi phuc vu Smart Scan

SAU KHI THAY FILE:
Build > Clean Project
Build > Rebuild Project

Luu y: AndroidManifest.xml va docflow_file_paths.xml khong can thay; FileProvider van duoc dung cho chia se/in/xuat tep.
