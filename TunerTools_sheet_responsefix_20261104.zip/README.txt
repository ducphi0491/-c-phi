TunerTools - Update sheet response hotfix 2026-11-04

Only replace:
  1) server/api_songs.php  -> live server api_songs.php
  2) android/SongRepository.kt -> app/src/main/java/ducphi/tunnerinstrument/SongRepository.kt

Do NOT replace SongMainScreen.kt or SongTabComponents.kt; keep the tutorial-buildfix
version installed from the previous ZIP. No changes to the GitHub token,
URL, Sync V2 cursor logic, or other app features.

New diagnostic: if an update POST returns HTML, empty data, or malformed JSON,
the app shows HTTP code, response type, and PHP marker. Also check Logcat
(tag SongScraper). PHP returns JSON for unexpected exceptions when possible.

This is a client/server safety patch; it does not guarantee recovery from
IIS request-filtering errors or a killed FastCGI worker.
