package com.docflowoffline

/** RFC 4180-style quoted fields; supports commas, escaped quotes and CRLF/newlines. */
object CsvEngine {
    fun parse(input: String, maxRows: Int = 5000): List<List<String>> {
        val result = mutableListOf<List<String>>()
        var record = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < input.length) {
            val ch = input[i]
            when {
                inQuotes && ch == '"' && i + 1 < input.length && input[i + 1] == '"' -> {
                    field.append('"')
                    i++
                }
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    record.add(field.toString())
                    field.setLength(0)
                }
                (ch == '\r' || ch == '\n') && !inQuotes -> {
                    record.add(field.toString())
                    result.add(record)
                    if (result.size >= maxRows) error("CSV quá lớn cho chế độ chỉnh sửa cơ bản.")
                    record = mutableListOf()
                    field.setLength(0)
                    if (ch == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
                }
                else -> field.append(ch)
            }
            i++
        }
        if (inQuotes) error("CSV không hợp lệ: thiếu dấu nháy đóng.")
        if (field.isNotEmpty() || record.isNotEmpty()) {
            record.add(field.toString())
            result.add(record)
        }
        return result
    }

    fun write(rows: List<List<String>>): String = rows.joinToString("\r\n") { row ->
        row.joinToString(",") { cell ->
            if (cell.any { it == ',' || it == '\n' || it == '\r' || it == '"' })
                "\"" + cell.replace("\"", "\"\"") + "\""
            else cell
        }
    }
}
