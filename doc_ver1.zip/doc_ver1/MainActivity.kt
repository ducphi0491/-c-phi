package com.docflowoffline

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
// Nếu Theme.kt nằm trong package ui.theme thì bỏ dấu // ở dòng dưới:
// import com.docflowoffline.ui.theme.DocFlowTheme

class MainActivity : ComponentActivity() {
    private var incomingUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        incomingUri = if (intent?.action == Intent.ACTION_VIEW) intent?.data else null
        setContent {
            DocFlowTheme {
                DocFlowApp(incomingUri)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingUri = if (intent.action == Intent.ACTION_VIEW) intent.data else null
    }
}