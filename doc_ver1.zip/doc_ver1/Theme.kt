package com.docflowoffline

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightScheme = lightColorScheme(
    primary = Color(0xFF245FC7),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE9FF),
    onPrimaryContainer = Color(0xFF15345E),
    secondary = Color(0xFF52668A),
    onSecondary = Color.White,
    background = Color(0xFFF7F9FD),
    onBackground = Color(0xFF1C2940),
    surface = Color.White,
    onSurface = Color(0xFF1C2940),
    onSurfaceVariant = Color(0xFF64738A),
    surfaceVariant = Color(0xFFEDF2FA),
    outlineVariant = Color(0xFFDCE4EF)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFA3C5FF),
    onPrimary = Color(0xFF002A60),
    primaryContainer = Color(0xFF294777),
    onPrimaryContainer = Color(0xFFE0EBFF),
    secondary = Color(0xFFB3C7EC),
    background = Color(0xFF10151E),
    onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF191F2B),
    onSurface = Color(0xFFE8ECF4),
    onSurfaceVariant = Color(0xFFB5C1D1),
    surfaceVariant = Color(0xFF2A3444),
    outlineVariant = Color(0xFF414E62)
)

@Composable
fun DocFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme,
        content = content
    )
}
