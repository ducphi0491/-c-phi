package duc_phi.music

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.FileNotFoundException
import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.Locale

/** Public folder link: no Google OAuth scopes are requested for this mode. */
internal data class PublicDriveLink(val folderId: String, val resourceKey: String?)
internal data class PublicDriveFolder(val id: String, val name: String, val resourceKey: String?)
internal data class PublicDriveEntry(
    val id: String,
    val name: String,
    val mimeType: String,
    val resourceKey: String?,
    val isFolder: Boolean,
    val canDownload: Boolean,
    val size: Long
)

/**
 * Anonymous/public Google Drive API v3. API key is ONLY for a folder shared as
 * "Anyone with the link". NEVER use this for a user's private Google Drive.
 */
internal object PublicDriveApi {
    private const val BASE = "https://www.googleapis.com/drive/v3/files"
    private const val FOLDER_MIME = "application/vnd.google-apps.folder"
    private const val MAX_PER_FOLDER = 10000
    private const val MAX_PLAYLIST = 2000
    private const val MAX_AUDIO_BYTES = 512L * 1024L * 1024L
    private val audioExtensions = setOf(
        "mp3", "m4a", "m4b", "aac", "adts", "flac", "wav", "wave", "ogg",
        "oga", "opus", "amr", "3gp", "mp4", "webm", "mka", "mkv",
        "ac3", "ec3", "ac4", "ts", "mpeg", "mpg"
    )

    fun parseFolderLink(input: String): PublicDriveLink {
        val raw = input.trim()
        val id: String
        val resourceKey: String?
        if (Regex("[A-Za-z0-9_-]{12,}").matches(raw)) {
            id = raw
            resourceKey = null
        } else {
            val parsed = try { Uri.parse(raw) } catch (_: Exception) { null }
                ?: throw IllegalArgumentException("Liên kết Google Drive không hợp lệ")
            if (parsed.scheme?.lowercase(Locale.ROOT) != "https") {
                throw IllegalArgumentException("Vui lòng dùng link Google Drive bắt đầu bằng https://")
            }
            val host = parsed.host?.lowercase(Locale.ROOT)
            if (host !in setOf("drive.google.com", "www.drive.google.com")) {
                throw IllegalArgumentException("Chỉ hỗ trợ link thư mục drive.google.com")
            }
            val path = parsed.pathSegments
            val folderIndex = path.indexOfLast { it == "folders" }
            id = if (folderIndex >= 0 && folderIndex + 1 < path.size) {
                path[folderIndex + 1]
            } else {
                parsed.getQueryParameter("id").orEmpty()
            }
            resourceKey = parsed.getQueryParameter("resourcekey")
                ?: parsed.getQueryParameter("resourceKey")
        }
        if (!Regex("[A-Za-z0-9_-]{10,}").matches(id)) {
            throw IllegalArgumentException("Link này không chứa ID thư mục Drive hợp lệ")
        }
        return PublicDriveLink(id, resourceKey?.takeIf { it.isNotBlank() })
    }

    private fun apiKey(context: Context): String {
        val key = context.getString(R.string.public_drive_api_key).trim()
        if (key.isBlank() || key.startsWith("REPLACE_", ignoreCase = true)) {
            throw IllegalStateException(
                "Chưa cấu hình Google Drive API key trong res/values/public_drive_api_key.xml"
            )
        }
        return key
    }

    private fun androidCertSha1(context: Context): String? = try {
        val pm = context.packageManager
        @Suppress("DEPRECATION")
        val signature = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
                .signatures?.firstOrNull()
        }
        signature?.let { sig ->
            MessageDigest.getInstance("SHA-1").digest(sig.toByteArray())
                .joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        }
    } catch (_: Exception) { null }

    private fun connect(
        context: Context,
        url: String,
        resourceKeyPairs: List<Pair<String, String?>> = emptyList()
    ): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 20000
        connection.readTimeout = 45000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("Accept", "application/json, audio/*, application/octet-stream")
        connection.setRequestProperty("X-Android-Package", context.packageName)
        androidCertSha1(context)?.let { connection.setRequestProperty("X-Android-Cert", it) }
        val pairs = resourceKeyPairs
            .filter { it.second?.isNotBlank() == true }
            .distinctBy { it.first }
        if (pairs.isNotEmpty()) {
            connection.setRequestProperty(
                "X-Goog-Drive-Resource-Keys",
                pairs.joinToString(",") { "${it.first}/${it.second.orEmpty()}" }
            )
        }
        return connection
    }

    private fun errorFor(code: Int, connection: HttpURLConnection): IOException {
        val body = runCatching {
            connection.errorStream?.bufferedReader()?.use { it.readText().take(1200) }
        }.getOrNull().orEmpty()
        val message = runCatching { JSONObject(body).getJSONObject("error").optString("message") }
            .getOrNull().orEmpty().ifBlank { body.take(250) }
        val advice = when (code) {
            400 -> "Link/ID hoặc tham số Drive không hợp lệ."
            401 -> "Drive yêu cầu xác thực, thư mục/file chưa mở quyền công khai."
            403 -> "Drive từ chối: kiểm tra chia sẻ Anyone with the link, hạn chế tải, API key, SHA-1 và quota."
            404 -> "Không tìm thấy thư mục/file công khai hoặc thiếu resourcekey trong link."
            429 -> "Drive API vượt giới hạn, vui lòng thử lại."
            else -> "Lỗi kết nối Google Drive."
        }
        return IOException("Google Drive HTTP $code: $advice ${message.take(220)}")
    }

    private fun getJson(
        context: Context,
        url: String,
        resourceKeyPairs: List<Pair<String, String?>>
    ): JSONObject {
        val connection = connect(context, url, resourceKeyPairs)
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw errorFor(code, connection)
            val result = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return JSONObject(result)
        } finally {
            connection.disconnect()
        }
    }

    fun readRoot(context: Context, root: PublicDriveLink): PublicDriveFolder {
        val fields = URLEncoder.encode("id,name,mimeType,resourceKey", "UTF-8")
        val url = "$BASE/${root.folderId}?fields=$fields&supportsAllDrives=true&key=${urlEncode(apiKey(context))}"
        val json = getJson(context, url, listOf(root.folderId to root.resourceKey))
        if (json.optString("mimeType") != FOLDER_MIME) {
            throw IllegalArgumentException("Link bạn dán không trỏ tới thư mục Google Drive")
        }
        return PublicDriveFolder(
            json.getString("id"),
            json.optString("name", "Google Drive công khai"),
            json.optString("resourceKey").takeIf { it.isNotBlank() } ?: root.resourceKey
        )
    }

    fun listChildren(
        context: Context,
        root: PublicDriveLink,
        folder: PublicDriveFolder
    ): List<PublicDriveEntry> {
        val key = apiKey(context)
        val results = ArrayList<PublicDriveEntry>()
        val q = "'${folder.id}' in parents and trashed = false"
        val fields = "nextPageToken,files(id,name,mimeType,size,resourceKey,capabilities(canDownload))"
        var nextPage: String? = null
        var pages = 0
        do {
            val url = StringBuilder("$BASE?q=${urlEncode(q)}")
                .append("&fields=${urlEncode(fields)}")
                .append("&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true")
                .append("&key=${urlEncode(key)}")
                .apply { if (!nextPage.isNullOrBlank()) append("&pageToken=${urlEncode(nextPage!!)}") }
                .toString()
            val json = getJson(context, url, listOf(root.folderId to root.resourceKey, folder.id to folder.resourceKey))
            val array = json.optJSONArray("files")
            if (array != null) {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val id = item.optString("id")
                    if (id.isBlank()) continue
                    val mime = item.optString("mimeType")
                    val isFolder = mime == FOLDER_MIME
                    val canDownload = item.optJSONObject("capabilities")?.optBoolean("canDownload", true) ?: true
                    results.add(PublicDriveEntry(
                        id = id,
                        name = item.optString("name", "Chưa có tên"),
                        mimeType = mime,
                        resourceKey = item.optString("resourceKey").takeIf { it.isNotBlank() },
                        isFolder = isFolder,
                        canDownload = canDownload,
                        size = item.optLong("size", 0L)
                    ))
                }
            }
            nextPage = json.optString("nextPageToken").takeIf { it.isNotBlank() }
            pages++
            if (results.size >= MAX_PER_FOLDER || pages >= 10) {
                if (nextPage != null) throw IOException("Thư mục quá lớn (trên $MAX_PER_FOLDER file). Hãy chọn thư mục con nhỏ hơn.")
                break
            }
        } while (nextPage != null)
        return results.sortedWith(compareBy<PublicDriveEntry> { !it.isFolder }
            .thenBy { it.name.lowercase(Locale.ROOT) })
    }

    fun isPlayable(entry: PublicDriveEntry): Boolean {
        if (entry.isFolder || !entry.canDownload) return false
        return entry.mimeType.startsWith("audio/", ignoreCase = true) ||
                entry.name.substringAfterLast('.', "").lowercase(Locale.ROOT) in audioExtensions
    }

    private fun audioMime(entry: PublicDriveEntry): String? {
        if (entry.mimeType.startsWith("audio/", ignoreCase = true)) return entry.mimeType
        return when (entry.name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "mp3", "mpeg", "mpg" -> "audio/mpeg"
            "flac" -> "audio/flac"
            "m4a", "m4b", "mp4" -> "audio/mp4"
            "wav", "wave" -> "audio/wav"
            "ogg", "oga" -> "audio/ogg"
            "opus" -> "audio/opus"
            "aac", "adts" -> "audio/aac"
            "webm" -> "audio/webm"
            "amr" -> "audio/amr"
            "ac3" -> "audio/ac3"
            "ec3" -> "audio/eac3"
            else -> entry.mimeType.takeIf { it.startsWith("video/") }
        }
    }

    fun toSong(entry: PublicDriveEntry, root: PublicDriveLink): SongItem {
        val fileUri = Uri.Builder()
            .scheme("publicdrive")
            .authority("file")
            .appendPath(entry.id)
            .appendQueryParameter("rk", entry.resourceKey.orEmpty())
            .appendQueryParameter("rootId", root.folderId)
            .appendQueryParameter("rootKey", root.resourceKey.orEmpty())
            .build()
        val withoutExtension = entry.name.substringBeforeLast('.', entry.name)
        val parts = withoutExtension.split(" - ", limit = 2)
        return SongItem(
            id = "pubdrive_${entry.id}",
            title = parts.firstOrNull().orEmpty().ifBlank { entry.name },
            artist = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: "Google Drive (chia sẻ)",
            uri = fileUri,
            durationLabel = "--:--",
            source = SongSource.PUBLIC_DRIVE,
            mimeType = audioMime(entry)
        )
    }

    /** Gets ALL audio tracks from selected folder and descendants; bounded for mobile performance. */
    fun collectAudioRecursively(
        context: Context,
        root: PublicDriveLink,
        selectedFolder: PublicDriveFolder
    ): List<SongItem> {
        val folders = ArrayDeque<PublicDriveFolder>()
        val visited = HashSet<String>()
        val songs = LinkedHashMap<String, SongItem>()
        folders.add(selectedFolder)
        while (folders.isNotEmpty()) {
            val current = folders.removeFirst()
            if (!visited.add(current.id)) continue
            val entries = listChildren(context, root, current)
            for (entry in entries) {
                if (entry.isFolder) folders.add(PublicDriveFolder(entry.id, entry.name, entry.resourceKey))
                else if (isPlayable(entry)) songs[entry.id] = toSong(entry, root)
                if (songs.size >= MAX_PLAYLIST) {
                    throw IOException("Thư mục có trên $MAX_PLAYLIST bài. Vui lòng chọn thư mục nhỏ hơn để phát ổn định.")
                }
            }
        }
        return songs.values.toList()
    }

    /** Copies real audio bytes into app cache. Never pass a Google Drive page URL to ExoPlayer. */
    fun copyAudioTo(context: Context, song: SongItem, output: OutputStream) {
        require(song.source == SongSource.PUBLIC_DRIVE && song.uri.scheme == "publicdrive")
        val fileId = song.uri.lastPathSegment
            ?.takeIf { Regex("[A-Za-z0-9_-]{10,}").matches(it) }
            ?: throw FileNotFoundException("Không tìm thấy file ID của bài hát")
        val rootId = song.uri.getQueryParameter("rootId").orEmpty()
        val fileKey = song.uri.getQueryParameter("rk")
        val rootKey = song.uri.getQueryParameter("rootKey")
        val url = "$BASE/$fileId?alt=media&supportsAllDrives=true&key=${urlEncode(apiKey(context))}"
        val connection = connect(context, url, listOf(fileId to fileKey, rootId to rootKey))
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw errorFor(code, connection)
            val contentType = connection.contentType.orEmpty().lowercase(Locale.ROOT)
            if (contentType.contains("text/html") || contentType.contains("application/json")) {
                throw IOException("Google Drive trả trang HTML/JSON thay vì dữ liệu âm thanh; kiểm tra quyền chia sẻ.")
            }
            connection.inputStream.use { input ->
                val buffer = ByteArray(128 * 1024)
                var bytes = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count == 0) continue
                    bytes += count
                    if (bytes > MAX_AUDIO_BYTES) {
                        throw IOException("Tệp quá 512 MB. Không thể cache toàn bộ tệp trên điện thoại.")
                    }
                    output.write(buffer, 0, count)
                }
                if (bytes <= 0) throw IOException("Google Drive trả về file rỗng")
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun urlEncode(value: String): String = URLEncoder.encode(value, "UTF-8")
}

@Composable
internal fun PublicDriveBrowserDialog(
    onDismiss: () -> Unit,
    onPlay: (List<SongItem>) -> Unit
) {
    val context = LocalContext.current
    val palette = LocalPalette.current
    val strings = LocalStrings.current
    val scope = rememberCoroutineScope()
    val prefs = remember(context) { context.getSharedPreferences("music_app_prefs", Context.MODE_PRIVATE) }
    var linkText by remember { mutableStateOf(prefs.getString("public_drive_last_link", "").orEmpty()) }
    var root by remember { mutableStateOf<PublicDriveLink?>(null) }
    val path = remember { mutableStateListOf<PublicDriveFolder>() }
    var entries by remember { mutableStateOf<List<PublicDriveEntry>>(emptyList()) }
    val checked = remember { mutableStateMapOf<String, SongItem>() }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Editing/clearing a link must also invalidate the previous folder tree.
    fun updateSharedLink(newText: String, forgetSaved: Boolean = false) {
        if (linkText != newText || forgetSaved) {
            linkText = newText
            root = null
            path.clear()
            entries = emptyList()
            checked.clear()
            error = null
            if (forgetSaved) prefs.edit().remove("public_drive_last_link").apply()
        }
    }

    fun pasteSharedLink() {
        val pasted = runCatching {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE)
                    as? android.content.ClipboardManager
            val clip = clipboard?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                clip.getItemAt(0).coerceToText(context).toString().trim()
            } else ""
        }.getOrDefault("")
        if (pasted.isBlank()) {
            error = "Bộ nhớ tạm trống. Hãy sao chép link Google Drive trước."
        } else {
            updateSharedLink(pasted)
        }
    }

    fun browse(target: PublicDriveFolder, newRoot: PublicDriveLink, reset: Boolean) {
        busy = true
        error = null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { PublicDriveApi.listChildren(context, newRoot, target) }
            }
            busy = false
            result.onSuccess { loaded ->
                root = newRoot
                if (reset) path.clear()
                path.add(target)
                entries = loaded
                checked.clear()
            }.onFailure { throwable ->
                error = throwable.localizedMessage ?: "Không thể đọc danh sách file Google Drive"
            }
        }
    }

    fun openSharedLink() {
        val link = try { PublicDriveApi.parseFolderLink(linkText) } catch (e: Exception) {
            error = e.localizedMessage
            return
        }
        busy = true
        error = null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { PublicDriveApi.readRoot(context, link) }
            }
            result.onSuccess { folder ->
                prefs.edit().putString("public_drive_last_link", linkText.trim()).apply()
                browse(folder, link, reset = true)
            }.onFailure { e ->
                busy = false
                error = e.localizedMessage ?: "Không mở được link Drive công khai"
            }
        }
    }

    fun goBack() {
        val currentRoot = root ?: return
        if (path.size <= 1) return
        val parent = path[path.lastIndex - 1]
        busy = true
        error = null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { PublicDriveApi.listChildren(context, currentRoot, parent) }
            }
            busy = false
            result.onSuccess { loaded ->
                path.removeAt(path.lastIndex)
                entries = loaded
                checked.clear()
            }.onFailure { e -> error = e.localizedMessage ?: "Không quay lại được thư mục" }
        }
    }

    fun playWholeFolder() {
        val currentRoot = root ?: return
        val folder = path.lastOrNull() ?: return
        busy = true
        error = null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    PublicDriveApi.collectAudioRecursively(context, currentRoot, folder)
                }
            }
            busy = false
            result.onSuccess { selected ->
                if (selected.isEmpty()) error = "Thư mục này không có file âm thanh được hỗ trợ."
                else onPlay(selected)
            }.onFailure { e -> error = e.localizedMessage ?: "Không quét được thư mục này" }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.91f),
            shape = RoundedCornerShape(20.dp),
            color = palette.backgroundSoft,
            border = BorderStroke(1.dp, palette.border)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Link, contentDescription = null, tint = palette.purpleBright)
                    Spacer(Modifier.size(8.dp))
                    Text(
                        if (strings.lang == "vi") "Google Drive - Link công khai" else "Google Drive - Public link",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, enabled = !busy) {
                        Icon(Icons.Rounded.Close, contentDescription = "Đóng", tint = palette.textSecondary)
                    }
                }
                Text(
                    text = if (strings.lang == "vi") {
                        "Dán link thư mục công khai của người khác (không phải content://)"
                    } else {
                        "Paste a public Google Drive folder URL (not content://)"
                    },
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = linkText,
                    onValueChange = { updateSharedLink(it) },
                    enabled = !busy,
                    readOnly = false,
                    placeholder = { Text("https://drive.google.com/drive/folders/...") },
                    label = { Text(if (strings.lang == "vi") "Đường link Drive" else "Drive folder URL") },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Uri,
                        imeAction = androidx.compose.ui.text.input.ImeAction.Go
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                        onGo = { if (!busy && linkText.isNotBlank()) openSharedLink() }
                    ),
                    trailingIcon = {
                        if (linkText.isNotEmpty()) {
                            IconButton(
                                onClick = { updateSharedLink("", forgetSaved = true) },
                                enabled = !busy
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = "Xóa link cũ")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { pasteSharedLink() }, enabled = !busy) {
                        Text(if (strings.lang == "vi") "Dán từ bộ nhớ tạm" else "Paste clipboard")
                    }
                    TextButton(
                        onClick = { updateSharedLink("", forgetSaved = true) },
                        enabled = !busy && linkText.isNotBlank()
                    ) {
                        Text(if (strings.lang == "vi") "Xóa link cũ" else "Clear link")
                    }
                }
                Button(
                    onClick = { openSharedLink() },
                    enabled = !busy && linkText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.purple)
                ) {
                    Text(if (strings.lang == "vi") "Mở link / Chọn thư mục" else "Open link / Browse folders")
                }
                if (busy) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.size(10.dp))
                        Text("Đang đọc Google Drive...", color = palette.textSecondary)
                    }
                }
                error?.let {
                    Text(it, color = palette.red, fontSize = 12.sp)
                }
                val currentFolder = path.lastOrNull()
                if (currentFolder != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { goBack() }, enabled = !busy && path.size > 1) {
                            Icon(Icons.Rounded.ArrowBack, contentDescription = "Trở lại", tint = palette.textPrimary)
                        }
                        Text(
                            path.joinToString(" / ") { it.name },
                            color = palette.textPrimary,
                            fontSize = 13.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    val playable = entries.filter { PublicDriveApi.isPlayable(it) }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${entries.count { it.isFolder }} thư mục · ${playable.size} bài", color = palette.textSecondary, fontSize = 12.sp)
                        TextButton(onClick = {
                            if (checked.size == playable.size) checked.clear()
                            else {
                                checked.clear()
                                val activeRoot = root!!
                                playable.forEach { checked[it.id] = PublicDriveApi.toSong(it, activeRoot) }
                            }
                        }, enabled = !busy && playable.isNotEmpty()) {
                            Text(if (checked.size == playable.size && playable.isNotEmpty()) "Bỏ chọn" else "Chọn tất cả")
                        }
                    }
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(entries, key = { it.id }) { entry ->
                            val isPlayable = PublicDriveApi.isPlayable(entry)
                            val isSelected = checked.containsKey(entry.id)
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable(enabled = !busy && (entry.isFolder || isPlayable)) {
                                    if (entry.isFolder) {
                                        val activeRoot = root ?: return@clickable
                                        browse(PublicDriveFolder(entry.id, entry.name, entry.resourceKey), activeRoot, false)
                                    } else if (isSelected) {
                                        checked.remove(entry.id)
                                    } else {
                                        val activeRoot = root ?: return@clickable
                                        checked[entry.id] = PublicDriveApi.toSong(entry, activeRoot)
                                    }
                                }.padding(vertical = 9.dp, horizontal = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (entry.isFolder) Icons.Rounded.Folder else Icons.Rounded.MusicNote,
                                    contentDescription = null,
                                    tint = if (entry.isFolder) palette.purpleBright else palette.textSecondary
                                )
                                Spacer(Modifier.size(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis, color = palette.textPrimary, fontSize = 13.sp)
                                    if (!entry.isFolder && !isPlayable) {
                                        Text("Không hỗ trợ hoặc chủ sở hữu đã chặn tải", color = palette.textMuted, fontSize = 11.sp)
                                    }
                                }
                                if (entry.isFolder) Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = palette.textSecondary)
                                else if (isPlayable) Text(if (isSelected) "☑" else "□", color = palette.purpleBright, fontSize = 22.sp)
                            }
                        }
                    }
                    Button(
                        onClick = { onPlay(checked.values.toList()) },
                        enabled = !busy && checked.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.blue)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Text("Phát ${checked.size} bài đã chọn")
                    }
                    Button(
                        onClick = { playWholeFolder() },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.purple)
                    ) {
                        Text("Phát toàn bộ thư mục này (gồm thư mục con)")
                    }
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Link cần có quyền Anyone with the link - Viewer. Ứng dụng chỉ đọc nội dung được chia sẻ, không cần đăng nhập tài khoản của chủ sở hữu.",
                        color = palette.textSecondary, fontSize = 12.sp
                    )
                }
            }
        }
    }
}
