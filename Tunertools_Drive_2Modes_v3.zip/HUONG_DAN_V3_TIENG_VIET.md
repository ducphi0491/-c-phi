# TUNERTOOLS - GOOGLE DRIVE 2 CHE DO - V3 (10/10/2026)

## 1. Tai sao giao dien cu khong cho nhap link?

O phien ban cu, o "Duong dan thu muc da chon" hien gia tri dang
`content://...` va duoc danh dau `readOnly = true`. Day la URI cua
Android DocumentsProvider, KHONG PHAI URL chia se Google Drive.
Vi vay nguoi dung khong the dan URL `https://drive.google.com/...` vao o do.

Anh chup truoc day co URI bat dau `content://com.android.externalstorage.documents/...`.
No chi vao BO NHO DIEN THOAI (thu muc Music), khong phai nha cung cap Google Drive.

## 2. Giao dien moi

Trong cua so 'Chon nguon nhac', hai nut nay luon nam canh nhau:

    [  Drive cua toi  ]   [  Dan link cong khai  ]

- Drive cua toi: mo DocumentsPicker cua Android, chon Google Drive,
  chon tai khoan, chon thu muc va cap quyen doc.
- Dan link cong khai: mo man hinh co o URL THUC SU nhap/duoc dan.
  Co nut 'Dan tu bo nho tam', 'Xoa link cu', bieu tuong X va
  'Mo link / Chon thu muc'.
- Khong con o `content://...` bi dat giong o nhap link.
- Khi chon link moi, danh sach thu muc cua link cu tu dong duoc xoa
  de khong lay nham du lieu.
- Khi dong man hinh public link, tro ve cua so chon hai che do.
- Nut 'Bo chon' cua Drive ca nhan chi go quyen/URI va khoi danh sach
  thu muc da quet, KHONG xoa bat ky tep nao tren Google Drive.
- Nguon nhac tren dien thoai tiep tuc dung nut 'Quet bo nho may'.
  Mo cua so Google Drive khong tu dong xin quyen doc nhac tren may.

## 3. Thay file dung cach

Trong Android Studio:

1. Sao luu file goc `MainActivity.kt`.
2. Copy:
   `app/src/main/java/duc_phi/music/MainActivity.kt`
   tu ZIP vao dung package `duc_phi.music` trong du an (thay file cu).
3. Copy:
   `app/src/main/java/duc_phi/music/PublicDriveBrowser.kt`
   cung folder voi MainActivity.kt.
4. Copy:
   `app/src/main/res/values/public_drive_api_key.xml`
   vao res/values/ (giu API key that da co neu truoc do ban da cau hinh).
5. Sync Gradle, Build va Run lai ung dung.

QUAN TRONG: Neu chi thay MainActivity ma KHONG them PublicDriveBrowser.kt
hoac thieu file XML, code se khong build day du.

## 4. Thu che do 1: Drive cua toi

1. Nhan icon thu muc trong ung dung.
2. Nhan 'Drive cua toi'.
3. Android mo 'Chon thu muc'; mo menu ben trai (ba gach ☰).
4. Chon *Google Drive*, khong chon 'Bo nho trong', 'Download', 'Music'.
5. Chon tai khoan Google, thu muc va 'Su dung thu muc nay'.
6. Chon bai hoac folder hien ben duoi, nhan 'Phat'.

Neu he thong chi hien bo nho may, hay cap nhat Google Drive;
tren mot so may/ROM, Drive co the khong cung cap thu muc cho SAF.
Ung dung se thong bao ro khi nguoi dung chon nham bo nho may.

## 5. Thu che do 2: Link public

1. Nhan icon thu muc -> 'Dan link cong khai'.
2. Neu co link cu, bam X trong o nhap hoac 'Xoa link cu'.
3. Sao chep URL cua chu so huu -> nhan 'Dan tu bo nho tam'
   (hoac nhan giu trong o input -> Dan).
4. Bam 'Mo link / Chon thu muc'.
5. Duyet thu muc con -> danh dau bai -> phat;
   hoac bam 'Phat toan bo thu muc nay'.

Link mau (bo fbclid):
https://drive.google.com/drive/folders/1KB8-kxt0QSpgBSQw4VMIQmYCGS3F2D2a

Chu so huu phai mo chia se 'Anyone with the link' (Viewer),
va khong chan quyen tai file. Viec thay ten folder chua du de
ket luan tat ca file ben trong phat duoc.

## 6. API KEY (chi can cho mode link cong khai)

1. Vao https://console.cloud.google.com/.
2. Bat Google Drive API cho Google Cloud project.
3. APIs & Services > Credentials > Create credentials > API key.
4. Han che API key theo Google Drive API va Android applicationId/SHA-1.
5. Thay chuoi REPLACE_WITH_YOUR_DRIVE_API_KEY trong XML bang key.
6. Manifest can co <uses-permission android:name="android.permission.INTERNET" />.
7. Build lai app. KHONG can API key cho che do Drive cua toi dung SAF.

Luu y: API key khong cho phep doc Drive private. Khong dang API key
len Internet. Vi key nam trong APK, van can gioi han API/quota.

## 7. Kiem tra va gioi han xac nhan

Da kiem tra bang Kotlin PSI Parser: MainActivity.kt va PublicDriveBrowser.kt
khong co loi CU PHAP. Da doi chieu cac ham UI voi callback va luong cache.
CHUA kiem chung Gradle build hoan chinh hoac phat nhac tren dien thoai;
can project Android day du va API key that de thu end-to-end.

Cac chuc nang khac (nhac local, Youtube, Equalizer, AdMob, Firebase,
Google Sign-In hien co) tiep tuc o file MainActivity; khong chu dong
thay doi logic nguon nhac/ket noi khac ngoai viec quet bo nho may.
