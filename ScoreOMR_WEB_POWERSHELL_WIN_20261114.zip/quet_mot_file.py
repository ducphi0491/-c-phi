"""Standalone PowerShell-friendly PDF/image OMR evaluator."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys
from uuid import uuid4
from engine import ALLOWED_SUFFIXES, normalize_options, run_engine


def main(argv=None):
    p = argparse.ArgumentParser(description='Score-OMR independent evaluator')
    p.add_argument('--file', required=True)
    p.add_argument('--pages', default='1')
    p.add_argument('--meter', default='6/8')
    p.add_argument('--bpm', type=int, default=80)
    p.add_argument('--no-mp3', action='store_true')
    a = p.parse_args(argv)
    src = Path(a.file).expanduser().resolve()
    if not src.is_file() or src.suffix.lower() not in ALLOWED_SUFFIXES:
        p.error('Input must exist and be PDF/JPG/PNG')
    options = normalize_options({'pages':a.pages, 'meter':a.meter, 'bpm':a.bpm, 'mp3':not a.no_mp3})
    target = Path(__file__).resolve().parent / 'ket_qua' / uuid4().hex[:24]
    target.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(src, target / ('source' + src.suffix.lower()))
    print('Input:', src, flush=True)
    print('Directory:', target, flush=True)
    report = run_engine(target, options)
    print('Status:', report['status'])
    print('Exit code:', report['exit_code'])
    print('Results:', target / 'DOI_CHIEU_SCORE_OMR.zip')
    if report['status'] != 'completed':
        print('See console_stderr.txt and report.json for details.')
    return 0 if report['status'] == 'completed' else (2 if report['status'] == 'partial' else 1)

if __name__ == '__main__':
    sys.exit(main())
