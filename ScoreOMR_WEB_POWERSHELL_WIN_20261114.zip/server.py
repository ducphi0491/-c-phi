"""Private localhost browser UI for testing independent Score-OMR output."""
from __future__ import annotations
from datetime import datetime, timezone
from email.parser import BytesParser
from email import policy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import re
import threading
import traceback
import uuid
from urllib.parse import urlparse, unquote

from engine import ALLOWED_SUFFIXES, ARTIFACTS, MAX_INPUT_BYTES, normalize_options, run_engine, installed_engine_version, archive_results

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'ket_qua'
STATIC = ROOT / 'static'
PORT = int(os.environ.get('SCORE_OMR_PORT', '8022'))
WORK.mkdir(exist_ok=True)
JOBS: dict[str, dict] = {}
LOCK = threading.RLock()
RUN_SLOT = threading.BoundedSemaphore(1)
MAX_REQUEST = MAX_INPUT_BYTES + 4096


def _job_snapshot(job_id):
    with LOCK:
        state = JOBS.get(job_id)
        return dict(state) if state else None


def _modify_job(job_id, **fields):
    with LOCK:
        JOBS[job_id].update(fields)


def _worker(job_id, opts):
    with RUN_SLOT:
        _modify_job(job_id, status='processing', message='Dang chay Score-OMR...')
        try:
            result = run_engine(WORK / job_id, opts)
            _modify_job(job_id, status=result['status'], message=('Hoan tat' if result['status'] == 'completed' else 'Co canh bao - hay kiem tra file log'), report=result)
        except Exception as ex:
            details = traceback.format_exc()
            folder = WORK / job_id
            (folder / 'console_stderr.txt').write_text(details, encoding='utf-8')
            (folder / 'console_stdout.txt').write_text('', encoding='utf-8')
            diagnostic = {'status': 'failed', 'message': str(ex), 'artifacts': {}, 'error_type': type(ex).__name__, 'accuracy_checked_against_source': False}
            (folder / 'report.json').write_text(json.dumps(diagnostic, ensure_ascii=False, indent=2), encoding='utf-8')
            archive_results(folder)
            _modify_job(job_id, status='failed', message=str(ex), report=diagnostic)


class Handler(BaseHTTPRequestHandler):
    server_version = 'ScoreOMRTest/1.0'
    def log_message(self, fmt, *args):
        print('[web]', fmt % args, flush=True)

    def _send(self, data: bytes, content_type='application/octet-stream', status=200, disposition=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        if disposition:
            self.send_header('Content-Disposition', disposition)
        self.end_headers()
        self.wfile.write(data)

    def _json(self, value, status=200):
        self._send(json.dumps(value, ensure_ascii=False).encode('utf8'), 'application/json; charset=utf-8', status=status)

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        if path == '/api/health':
            return self._json({'ok': True, 'app': 'Score-OMR independent evaluation', 'version': '1.0.0', 'engine_installed': installed_engine_version(), 'port': PORT})
        if path in ('/', '/index.html'):
            p = STATIC / 'index.html'
            return self._send(p.read_bytes(), 'text/html; charset=utf-8')
        if path in ('/style.css','/app.js'):
            p = STATIC / path[1:]
            typ = 'text/css; charset=utf-8' if path.endswith('css') else 'application/javascript; charset=utf-8'
            return self._send(p.read_bytes(), typ)
        m = re.fullmatch(r'/api/jobs/([a-f0-9]{24})', path)
        if m:
            state = _job_snapshot(m.group(1))
            return self._json(state if state is not None else {'error':'job not found'}, 200 if state else 404)
        m = re.fullmatch(r'/api/jobs/([a-f0-9]{24})/(archive|source|files/([\w.]+))', path)
        if m:
            job_id, mode, filename = m.group(1), m.group(2), m.group(3)
            if not (WORK / job_id).is_dir():
                return self._json({'error':'job not found'}, 404)
            if mode == 'archive':
                name = 'DOI_CHIEU_SCORE_OMR.zip'
                content_type = 'application/zip'
                disposition = 'attachment; filename="'+job_id+'_DOI_CHIEU_SCORE_OMR.zip"'
            elif mode == 'source':
                sources = [p for p in (WORK / job_id).iterdir() if p.name.startswith('source.') and p.suffix.lower() in ALLOWED_SUFFIXES]
                if not sources:
                    return self._json({'error':'source unavailable'}, 404)
                name = sources[0].name
                content_type = mimetypes.guess_type(name)[0] or 'application/octet-stream'
                disposition = 'inline'
            else:
                if filename not in ARTIFACTS:
                    return self._json({'error':'unsupported artifact'}, 404)
                name = filename
                content_type = ARTIFACTS[name]
                disposition = ('inline' if name.endswith('.mp3') else 'attachment; filename="' + name + '"')
            target = WORK / job_id / name
            if not target.is_file():
                return self._json({'error':'file unavailable'}, 404)
            return self._send(target.read_bytes(), content_type, disposition=disposition)
        return self._json({'error':'not found'}, 404)

    def do_POST(self):
        if urlparse(self.path).path != '/api/jobs':
            return self._json({'error':'not found'}, 404)
        length = self.headers.get('Content-Length', '')
        if not length.isdigit() or not 1 <= int(length) <= MAX_REQUEST:
            return self._json({'error':'Upload phai < 30 MB'}, 413)
        ctype = self.headers.get('Content-Type','')
        if not ctype.startswith('multipart/form-data') or 'boundary=' not in ctype:
            return self._json({'error':'Expected multipart form'}, 400)
        try:
            data = self.rfile.read(int(length))
            message = BytesParser(policy=policy.default).parsebytes(('Content-Type: ' + ctype + '\r\nMIME-Version: 1.0\r\n\r\n').encode('utf8') + data)
            if not message.is_multipart():
                return self._json({'error':'Invalid multipart'}, 400)
            form = {}
            selected = None
            for part in message.iter_parts():
                key = part.get_param('name', header='content-disposition')
                if not key:
                    continue
                payload = part.get_payload(decode=True)
                if key == 'file':
                    selected = (part.get_filename(), payload)
                elif len(payload) < 2000:
                    form[key] = payload.decode('utf8', 'replace')
            if not selected or not selected[0] or not selected[1]:
                return self._json({'error':'Chua chon file PDF/JPG/PNG'}, 400)
            fname, contents = selected
            ext = Path(fname).suffix.lower()
            if ext not in ALLOWED_SUFFIXES:
                return self._json({'error':'Chi nhan PDF, PNG, JPG va JPEG'}, 400)
            if len(contents) > MAX_INPUT_BYTES:
                return self._json({'error':'File > 30 MB'}, 413)
            options = normalize_options(form)
            job_id = uuid.uuid4().hex[:24]
            directory = WORK / job_id
            directory.mkdir(parents=True)
            (directory / ('source' + ext)).write_bytes(contents)
            state = {'id': job_id, 'status':'queued', 'message':'Dang cho luot nhan dien', 'name': Path(fname).name, 'source_extension':ext, 'submitted_at_utc':datetime.now(timezone.utc).isoformat(), 'options': options}
            with LOCK:
                JOBS[job_id] = state
            thread = threading.Thread(target=_worker, args=(job_id, options), daemon=True)
            thread.start()
            return self._json({'id':job_id, 'status':'queued'}, 202)
        except ValueError as ex:
            return self._json({'error':str(ex)}, 400)
        except Exception as ex:
            return self._json({'error':'Loi xu ly upload: ' + str(ex)}, 500)


def main():
    httpd = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    print('Score-OMR TEST: http://127.0.0.1:%s' % PORT, flush=True)
    print('Results: ' + str(WORK), flush=True)
    print('Ctrl+C to stop the server.', flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == '__main__':
    main()
