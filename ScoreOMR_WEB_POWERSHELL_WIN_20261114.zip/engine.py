"""Local-only Score-OMR orchestration. No fake OMR data is ever generated."""
from __future__ import annotations
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
import zipfile
import xml.etree.ElementTree as ET

ENGINE_VERSION = '0.2.1'
MAX_INPUT_BYTES = 30 * 1024 * 1024
ALLOWED_SUFFIXES = {'.pdf', '.png', '.jpg', '.jpeg'}
ARTIFACTS = {
    'score.json': 'application/json; charset=utf-8',
    'score.musicxml': 'application/xml; charset=utf-8',
    'score.mid': 'audio/midi',
    'score.mp3': 'audio/mpeg',
    'report.json': 'application/json; charset=utf-8',
    'console_stdout.txt': 'text/plain; charset=utf-8',
    'console_stderr.txt': 'text/plain; charset=utf-8',
}


def installed_engine_version():
    try:
        return importlib.metadata.version('score-reader')
    except importlib.metadata.PackageNotFoundError:
        return None


def expected_binary():
    exe_dir = Path(sys.executable).parent
    binary = exe_dir / ('score-reader.exe' if os.name == 'nt' else 'score-reader')
    if binary.exists():
        return str(binary)
    return shutil.which('score-reader')


def sha256(path: Path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def musicxml_stats(path: Path):
    if not path.exists() or path.stat().st_size == 0:
        return None
    try:
        root = ET.parse(path).getroot()
        parts = [e for e in list(root) if e.tag.split('}')[-1] == 'part']
        rows = []
        for part in parts:
            measures = [e for e in part if e.tag.split('}')[-1] == 'measure']
            notes = 0
            rests = 0
            for m in measures:
                for n in m.iter():
                    kind = n.tag.split('}')[-1]
                    if kind == 'note':
                        notes += 1
                    if kind == 'rest':
                        rests += 1
            rows.append({'id': part.attrib.get('id', ''), 'measures': len(measures), 'note_symbols': notes, 'rests': rests})
        return {'root': root.tag.split('}')[-1], 'parts': rows, 'max_measures_per_part': max((x['measures'] for x in rows), default=0)}
    except Exception as ex:
        return {'parse_error': str(ex)}


def normalize_options(raw):
    meter = str(raw.get('meter', '6/8')).strip()
    if not re.fullmatch(r'\d{1,2}/(1|2|4|8|16|32)', meter):
        raise ValueError('So chi nhip phai dang 6/8, 4/4, 3/4 ...')
    num, den = map(int, meter.split('/'))
    if not 1 <= num <= 16:
        raise ValueError('Tu so nhip phai nam trong 1..16')
    bpm = int(raw.get('bpm', 80))
    if not 20 <= bpm <= 300:
        raise ValueError('BPM phai nam trong 20..300')
    pages = str(raw.get('pages', '1')).strip().replace(' ', '')
    if pages and (not re.fullmatch(r'\d{1,4}(,\d{1,4}){0,49}', pages) or any(int(x) < 1 for x in pages.split(','))):
        raise ValueError('Trang PDF: de trong hoac nhap 1 / 1,5 / 1,2,3')
    return {'meter': meter, 'bpm': bpm, 'pages': pages, 'mp3': str(raw.get('mp3', 'true')).lower() in ('true', '1', 'yes', 'on')}


def _run_once(cmd, directory):
    try:
        completed = subprocess.run(cmd, cwd=directory, stdin=subprocess.DEVNULL, capture_output=True, timeout=1800, text=True, errors='replace', shell=False, check=False)
        return completed.returncode, completed.stdout or '', completed.stderr or ''
    except subprocess.TimeoutExpired as ex:
        return 124, (ex.stdout or b'').decode('utf8', 'replace') if isinstance(ex.stdout, bytes) else (ex.stdout or ''), 'Qua thoi gian toi da 30 phut. ' + str(ex)
    except Exception as ex:
        return 125, '', str(ex)


def archive_results(directory: Path):
    archive = directory / 'DOI_CHIEU_SCORE_OMR.zip'
    names = ['source' + suf for suf in ('.pdf', '.png', '.jpg', '.jpeg')] + list(ARTIFACTS)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in names:
            path = directory / name
            if path.exists() and path.is_file():
                z.write(path, arcname=('source/' + path.name if path.name.startswith('source.') else 'result/' + path.name))
    return archive


def run_engine(directory: Path, options: dict, cli_command=None):
    directory = Path(directory)
    source = next((p for p in directory.iterdir() if p.name.startswith('source.') and p.suffix.lower() in ALLOWED_SUFFIXES), None)
    if source is None:
        raise ValueError('Thieu source.pdf / source.png / source.jpg')
    cli = cli_command if cli_command is not None else ([expected_binary()] if expected_binary() else None)
    if not cli or not cli[0]:
        raise RuntimeError('Khong tim thay score-reader CLI trong moi truong Python.')
    opts = normalize_options(options)
    cmd = list(map(str, cli)) + [str(source.resolve()), '-o', str((directory / 'score.json').resolve()), '--musicxml', str((directory / 'score.musicxml').resolve()), '--midi', str((directory / 'score.mid').resolve()), '--meter', opts['meter'], '--bpm', str(opts['bpm'])]
    if opts['pages'] and source.suffix.lower() == '.pdf':
        cmd.extend(['--pages', opts['pages']])
    if opts['mp3']:
        cmd += ['--mp3', str((directory / 'score.mp3').resolve())]
    start = datetime.now(timezone.utc).isoformat()
    ret, out, err = _run_once(cmd, directory)
    retried_without_mp3 = False
    if ret and opts['mp3'] and any(k in err.lower() for k in ('ffmpeg','encoder','mp3','audio')):
        # MP3 is optional; don't lose MusicXML/MIDI if only the audio encoder fails.
        retried_without_mp3 = True
        retry = [str(x) for x in cmd[:-2]]
        ret2, out2, err2 = _run_once(retry, directory)
        out += '\n-- Retry without MP3 --\n' + out2
        err += '\n-- Retry without MP3 --\n' + err2
        ret = ret2
    (directory / 'console_stdout.txt').write_text(out, encoding='utf-8')
    (directory / 'console_stderr.txt').write_text(err, encoding='utf-8')
    good = {}
    for name in ('score.json', 'score.musicxml', 'score.mid', 'score.mp3'):
        p = directory / name
        good[name] = p.exists() and p.stat().st_size > 0
    json_valid = False
    json_keys = []
    if good['score.json']:
        try:
            parsed = json.loads((directory / 'score.json').read_text(encoding='utf-8-sig'))
            json_valid = True
            json_keys = sorted(parsed.keys()) if isinstance(parsed, dict) else []
        except Exception as ex:
            err += '\nJSON khong doc duoc: ' + str(ex)
            (directory / 'console_stderr.txt').write_text(err, encoding='utf-8')
    xml_stats = musicxml_stats(directory / 'score.musicxml')
    xml_valid = xml_stats is not None and 'parse_error' not in xml_stats
    if ret == 0 and json_valid and xml_valid and good['score.mid']:
        status = 'completed' if (not opts['mp3'] or good['score.mp3']) else 'partial'
    elif json_valid or xml_valid:
        status = 'partial'
    else:
        status = 'failed'
    report = {
        'app': 'TunerTools Score-OMR evaluation - not the V6 OCR engine',
        'score_reader_version_requested': ENGINE_VERSION,
        'score_reader_version_installed': installed_engine_version(),
        'started_at_utc': start,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': status,
        'exit_code': ret,
        'source_name': source.name,
        'source_sha256': sha256(source),
        'options': opts,
        'cmd_arguments': cmd[1:],
        'retry_without_mp3': retried_without_mp3,
        'artifacts': good,
        'json_valid': json_valid,
        'json_top_level_keys': json_keys,
        'musicxml': xml_stats,
        'accuracy_checked_against_source': False,
        'note': 'A generated MusicXML/MIDI file is not proof of correct note/rhythm recognition.',
    }
    (directory / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    archive_results(directory)
    return report
