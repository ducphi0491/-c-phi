@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CHAY_SCORE_OMR_WEB.ps1"
if errorlevel 1 (
  echo.
  echo Loi khoi dong. Hay xem thong bao ben tren.
  pause
)
