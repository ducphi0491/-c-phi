param([switch]$KhongMoTrinhDuyet)
# Score-OMR test server - isolated from TunerTools V6, binds 127.0.0.1:8022 only.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$venv = Join-Path $root '.venv'
$py = Join-Path $venv 'Scripts\python.exe'
$reader = Join-Path $venv 'Scripts\score-reader.exe'

function CallNative([string]$FilePath, [string[]]$Parameters) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue' # PowerShell 5.1 may treat stderr as errors
    try {
        & $FilePath @Parameters
        $exitcode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $old
    }
    if ($exitcode -ne 0) { throw "Lenh that bai ($exitcode): $FilePath" }
}

Write-Host "`n=======================================" -ForegroundColor Cyan
Write-Host ' TUNERTOOLS - SCORE-OMR THU NGHIEM' -ForegroundColor Cyan
Write-Host '=======================================' -ForegroundColor Cyan
Write-Host 'Web rieng: http://127.0.0.1:8022'
Write-Host 'Khong thay the V6; khong tai PDF len may chu ngoai.'
Write-Host ''

# Find 64-bit CPython 3.11/3.10; NOT Python 3.12+.
$launcher = $null
$prefix = @()
if (Get-Command py -ErrorAction SilentlyContinue) {
    foreach ($ver in @('-3.11-64', '-3.11', '-3.10-64', '-3.10')) {
        $old = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { & py $ver -c 'import sys; sys.exit(0 if sys.maxsize>2**32 and sys.version_info[:2] in ((3,11),(3,10)) else 1)' | Out-Null; $code = $LASTEXITCODE }
        finally { $ErrorActionPreference = $old }
        if ($code -eq 0) { $launcher = 'py'; $prefix = @($ver); break }
    }
}
if (-not $launcher -and (Get-Command python -ErrorAction SilentlyContinue)) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & python -c 'import sys; sys.exit(0 if sys.maxsize>2**32 and sys.version_info[:2] in ((3,11),(3,10)) else 1)' | Out-Null; $code = $LASTEXITCODE }
    finally { $ErrorActionPreference = $old }
    if ($code -eq 0) { $launcher = 'python'; $prefix = @() }
}
if (-not $launcher) {
    throw 'Can cai Python 3.11 (64-bit), bat tuy chon Add Python to PATH / Python Launcher. https://www.python.org/downloads/'
}
Write-Host "[OK] Python launcher: $launcher $($prefix -join ' ')" -ForegroundColor Green

# Validate JDK 17 or later: uses JAVAC, not just Java runtime.
$javaPath = $null
$javacPath = $null
if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    $javaPath = Join-Path $env:JAVA_HOME 'bin\java.exe'
    $javacPath = Join-Path $env:JAVA_HOME 'bin\javac.exe'
} else {
    $javaCmd = Get-Command java -ErrorAction SilentlyContinue
    $javacCmd = Get-Command javac -ErrorAction SilentlyContinue
    if ($javaCmd) { $javaPath = $javaCmd.Source }
    if ($javacCmd) { $javacPath = $javacCmd.Source }
}
if (-not $javaPath -or -not $javacPath -or -not (Test-Path $javaPath) -or -not (Test-Path $javacPath)) {
    throw 'Chua tim thay JDK Java 17+ (java.exe va javac.exe). Cai JDK 17/21, mo PowerShell moi. https://learn.microsoft.com/en-us/java/openjdk/download'
}
$old = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try { $verLines = & $javaPath -version 2>&1 | Out-String; $javaExit = $LASTEXITCODE }
finally { $ErrorActionPreference = $old }
if ($javaExit -ne 0) { throw 'Khong kiem tra duoc Java. Hay cai JDK 17+.' }
if ($verLines -match '(?i)(?:version\s*"|openjdk\s+)(\d+)(?:\.(\d+))?') {
    $major = [int]$Matches[1]
    if ($major -eq 1 -and $Matches[2]) { $major = [int]$Matches[2] }
    if ($major -lt 17) { throw "Java version $major qua cu. Can JDK 17+." }
} else { Write-Warning 'Khong doc duoc version Java; thu chay voi Java hien tai.' }
Write-Host '[OK] Java JDK duoc tim thay.' -ForegroundColor Green

# Only create/modify the local .venv within the extracted directory.
if (-not (Test-Path $py)) {
    Write-Host 'Tao Python virtual environment (.venv) ...' -ForegroundColor Cyan
    CallNative $launcher ($prefix + @('-m','venv',$venv))
}
$needInstall = -not (Test-Path $reader)
if (-not $needInstall) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $py -c 'import importlib.metadata as m; import sys; sys.exit(0 if m.version("score-reader")=="0.2.1" else 1)' | Out-Null; $code = $LASTEXITCODE }
    finally { $ErrorActionPreference = $old }
    if ($code -ne 0) { $needInstall = $true }
}
if ($needInstall) {
    Write-Host 'Dang cai score-reader[pdf,audio]==0.2.1 (can Internet lan dau) ...' -ForegroundColor Cyan
    CallNative $py @('-m','pip','install','--disable-pip-version-check','--prefer-binary','score-reader[pdf,audio]==0.2.1')
}
if (-not (Test-Path $reader)) { throw 'Da cai Python package nhung chua co Scripts\score-reader.exe. Kiem tra pip output.' }
Write-Host '[OK] Score-OMR 0.2.1 san sang.' -ForegroundColor Green

# Detect an existing server on port 8022; never kill a different process automatically.
try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8022/api/health' -TimeoutSec 2
    if ($health.version -eq '1.0.0') {
        Write-Host '[OK] Score-OMR Web da chay tu truoc tren cong 8022.' -ForegroundColor Yellow
        if (-not $KhongMoTrinhDuyet) { Start-Process 'http://127.0.0.1:8022' }
        return
    }
    throw 'Cong 8022 da co chuong trinh khac. Hay dung chuong trinh do truoc.'
} catch {
    if ($_.Exception.Message -match 'Cong 8022') { throw }
}

$stdout = Join-Path $root 'web_stdout.log'
$stderr = Join-Path $root 'web_stderr.log'
$p = Start-Process -FilePath $py -ArgumentList @('server.py') -WorkingDirectory $root -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
$ready = $false
for ($n=0; $n -lt 40; $n++) {
    Start-Sleep -Milliseconds 500
    if ($p.HasExited) { break }
    try { $response = Invoke-RestMethod 'http://127.0.0.1:8022/api/health' -TimeoutSec 2; if ($response.ok) { $ready=$true; break } } catch {}
}
if (-not $ready) {
    Write-Host 'Khong khoi dong duoc web. Xem file web_stderr.log:' -ForegroundColor Red
    if (Test-Path $stderr) { Get-Content $stderr -Tail 25 }
    throw 'Score-OMR web khong mo duoc. Cong 8022 co the dang bi su dung.'
}
Write-Host "`n[OK] DA CHAY: http://127.0.0.1:8022" -ForegroundColor Green
Write-Host ("Ket qua o: " + (Join-Path $root 'ket_qua'))
if (-not $KhongMoTrinhDuyet) { Start-Process 'http://127.0.0.1:8022' }
try {
    Read-Host 'NHAN ENTER DE DUNG SCORE-OMR WEB'
} finally {
    if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
}
Write-Host 'Da dung web Score-OMR. Web V6 tren cong 8021 khong bi anh huong.'
