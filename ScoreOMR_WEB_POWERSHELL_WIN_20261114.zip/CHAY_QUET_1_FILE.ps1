param(
    [string]$FilePath = '',
    [string]$Pages = '1',
    [string]$Meter = '6/8',
    [int]$Bpm = 80,
    [switch]$NoMp3
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$py = Join-Path $root '.venv\Scripts\python.exe'
$reader = Join-Path $root '.venv\Scripts\score-reader.exe'
if (-not (Test-Path $reader)) { throw 'Chua cai engine. Chay CHAY_SCORE_OMR_WEB.ps1 mot lan de tu cai Python dependencies.' }
if (-not $FilePath) {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Sheet music (*.pdf;*.png;*.jpg;*.jpeg)|*.pdf;*.png;*.jpg;*.jpeg'
    $dlg.Title = 'Chon file PDF/anh de thu Score-OMR'
    $dlg.InitialDirectory = [Environment]::GetFolderPath('MyDocuments')
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Da huy chon file'; return }
    $FilePath = $dlg.FileName
}
$parameters = @('quet_mot_file.py','--file',$FilePath,'--pages',$Pages,'--meter',$Meter,'--bpm',"$Bpm")
if ($NoMp3) { $parameters += '--no-mp3' }
Push-Location $root
try {
    & $py @parameters
    if ($LASTEXITCODE -ne 0) { Write-Warning 'Xu ly co loi/khong day du. Xem thu muc ket_qua va ZIP cho biet chi tiet.' }
} finally { Pop-Location }
