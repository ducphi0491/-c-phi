# Báo cáo kiểm thử gói Score-OMR Web

Ngày đóng gói: 2026-11-14.

- **Đã kiểm tra trong môi trường đóng gói:** biên dịch cú pháp các tệp Python, cú pháp JS; 3 bài kiểm tra unit/API với engine **mô phỏng**. Đã xác nhận luồng upload ảnh/PDF -> tạo công việc -> đọc trạng thái -> đóng ZIP; kiểm tra cấm tải tệp tùy ý.
- **Đã xác minh từ nguồn công khai:** PyPI có `score-reader` 0.2.1; CLI hỗ trợ PDF/ảnh, `--pages`, `--meter`, `--bpm`, `-o`, `--musicxml`, `--midi`, `--mp3`; yêu cầu Python 3.10/3.11 và Java 17+.
- **Chưa chạy được trong môi trường đóng gói:** suy luận bằng Score-OMR thật, vì không có Internet để tải thư viện và môi trường hiện có Python 3.13 (không được phiên bản gói hỗ trợ). Chưa xác minh việc cài/khởi động trên Windows của người dùng.
- **Chưa đo:** độ chính xác nốt/nhịp/tab, số ô trích từ PDF 6 trang, khả năng giữ kỹ thuật guitar, tốc độ suy luận. Không khẳng định vượt V6 cho tới khi có ZIP kết quả thật.
- **Giới hạn:** Không có xuất GP3, GP4, GP5; bản đánh giá mới xuất JSON/MusicXML/MIDI/MP3. Bước chuyển MusicXML sang GP phải xây dựng sau khi chất lượng OMR đạt yêu cầu.
- **Bảo mật:** Backend chỉ lắng nghe `127.0.0.1:8022`, không gửi file người dùng đến máy chủ. Quá trình cài pip ở lần đầu tải thư viện từ kho PyPI qua Internet.
