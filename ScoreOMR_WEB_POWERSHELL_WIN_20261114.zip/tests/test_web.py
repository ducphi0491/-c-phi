"""Tests of packaging, web upload and archiving ONLY. Not a music-recognition benchmark."""
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import engine
import server


class CoreTests(unittest.TestCase):
    def test_valid_options(self):
        self.assertEqual(engine.normalize_options({'pages': '1, 5','meter': '6/8','bpm':'80','mp3':'on'})['pages'], '1,5')
        with self.assertRaises(ValueError):
            engine.normalize_options({'pages': '../secret'})
        with self.assertRaises(ValueError):
            engine.normalize_options({'bpm': '600'})

    def test_run_with_fake_cli(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p / 'source.png').write_bytes(b'not-a-real-picture; just an interface test')
            script = p / 'fake_cli.py'
            script.write_text("""import sys,pathlib,json
args=sys.argv
for flag,body in [('-o',json.dumps({'unit_test':True})),('--musicxml','<score-partwise><part id="P1"><measure number="1"><note><pitch><step>C</step><octave>4</octave></pitch></note></measure></part></score-partwise>'),('--midi','MThd')]:
 idx=args.index(flag)
 pathlib.Path(args[idx+1]).write_bytes(body.encode('utf-8'))
""", encoding='utf-8')
            report = engine.run_engine(p, {'meter':'6/8','bpm':80,'pages':'','mp3':'false'}, [sys.executable,str(script)])
            self.assertEqual(report['status'],'completed')
            self.assertEqual(report['musicxml']['max_measures_per_part'],1)
            with zipfile.ZipFile(p / 'DOI_CHIEU_SCORE_OMR.zip') as z:
                self.assertIn('result/score.musicxml', z.namelist())
                self.assertIn('source/source.png', z.namelist())
                self.assertIn('result/report.json', z.namelist())
                self.assertNotIn('foo', z.namelist())


class WebTests(unittest.TestCase):
    def test_health_static_and_form_upload(self):
        import http.server
        import shutil
        orig_work, orig_engine = server.WORK, server.run_engine
        with tempfile.TemporaryDirectory() as td:
            server.WORK = Path(td)
            def mock_run(where, opts):
                (where / 'score.json').write_text('{}', encoding='utf8')
                (where / 'score.musicxml').write_text('<score-partwise><part id="A"><measure number="1"/></part></score-partwise>', encoding='utf8')
                (where / 'score.mid').write_bytes(b'MThd')
                (where / 'report.json').write_text('{"status":"completed"}', encoding='utf8')
                (where / 'console_stdout.txt').write_text('mock', encoding='utf8')
                (where / 'console_stderr.txt').write_text('', encoding='utf8')
                engine.archive_results(where)
                return {'status':'completed','musicxml':{'max_measures_per_part':1,'parts':[{'id':'A'}]},'artifacts':{'score.json':True,'score.musicxml':True,'score.mid':True,'score.mp3':False}}
            server.run_engine = mock_run
            httpd = http.server.ThreadingHTTPServer(('127.0.0.1',0), server.Handler)
            port = httpd.server_address[1]
            thread = threading.Thread(target=httpd.serve_forever, daemon=True)
            thread.start()
            try:
                base = 'http://127.0.0.1:%s' % port
                health = json.load(urllib.request.urlopen(base+'/api/health'))
                self.assertTrue(health['ok'])
                html = urllib.request.urlopen(base).read()
                self.assertIn(b'Score-OMR', html)
                boundary = 'boundaryTEST12345'
                pdfbytes = b'%PDF-1.4\nThis is a harmless fake upload for interface test\n'
                fields = [('pages','1'),('meter','6/8'),('bpm','80'),('mp3','false')]
                body = b''
                for k,v in fields:
                    body += ('--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"\r\n\r\n'+v+'\r\n').encode()
                body += ('--'+boundary+'\r\nContent-Disposition: form-data; name="file"; filename="input.pdf"\r\nContent-Type: application/pdf\r\n\r\n').encode()+pdfbytes+b'\r\n'
                body += ('--'+boundary+'--\r\n').encode()
                req=urllib.request.Request(base+'/api/jobs', data=body,headers={'Content-Type':'multipart/form-data; boundary='+boundary},method='POST')
                j=json.load(urllib.request.urlopen(req))
                self.assertEqual(j['status'],'queued')
                for _ in range(50):
                    state=json.load(urllib.request.urlopen(base+'/api/jobs/'+j['id']))
                    if state['status'] in ('completed','failed','partial'):
                        break
                    time.sleep(.05)
                self.assertEqual(state['status'],'completed')
                arc=urllib.request.urlopen(base+'/api/jobs/'+j['id']+'/archive').read()
                with zipfile.ZipFile(io.BytesIO(arc)) as z:
                    self.assertIn('source/source.pdf', z.namelist())
                    self.assertIn('result/score.mid', z.namelist())
                with self.assertRaises(urllib.error.HTTPError) as err:
                    urllib.request.urlopen(base+'/api/jobs/'+j['id']+'/files/server.py')
                self.assertEqual(err.exception.code,404)
            finally:
                httpd.shutdown();httpd.server_close();thread.join(3)
                server.WORK, server.run_engine=orig_work,orig_engine


if __name__ == '__main__':
    unittest.main()
