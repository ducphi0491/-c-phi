# TunerTools - read-only GitHub diagnostics for sheet update HTTP 502.
# Only GET requests to https://api.github.com. No changes to PHP, MySQL, or GitHub.
# GitHub credential is read from the existing PHP on this machine, never printed or saved.
param(
    [string]$PhpPath = '',
    [string]$Slug = '',
    [int]$ImageCount = 1
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if ([string]::IsNullOrWhiteSpace($PhpPath)) {
    $candidates = @(
        'C:\inetpub\wwwroot\api_songs.php',
        'C:\inetpub\wwwroot\tunertools\api_songs.php',
        'C:\TunerToolsGP_Fresh\api_songs.php'
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            $PhpPath = $candidate
            break
        }
    }
}
if ([string]::IsNullOrWhiteSpace($PhpPath) -or !(Test-Path -LiteralPath $PhpPath -PathType Leaf)) {
    Write-Host 'ERROR: Cannot find api_songs.php. Run with -PhpPath "C:\path\to\api_songs.php".' -ForegroundColor Red
    exit 1
}

$source = Get-Content -LiteralPath $PhpPath -Raw -Encoding UTF8
$tokenMatch = [regex]::Match($source, '\$ghToken\s*=\s*["'']([^"''\r\n]+)["'']')
$ownerMatch = [regex]::Match($source, '\$ghUsername\s*=\s*["'']([^"''\r\n]+)["'']')
$repoMatch = [regex]::Match($source, '\$ghRepo\s*=\s*["'']([^"''\r\n]+)["'']')
$branchMatch = [regex]::Match($source, '\$ghBranch\s*=\s*["'']([^"''\r\n]+)["'']')
if (!$tokenMatch.Success -or !$ownerMatch.Success -or !$repoMatch.Success) {
    Write-Host 'ERROR: Cannot find GitHub configuration in PHP. No token is printed.' -ForegroundColor Red
    exit 1
}

$token = $tokenMatch.Groups[1].Value
$owner = $ownerMatch.Groups[1].Value
$repo = $repoMatch.Groups[1].Value
$branch = if ($branchMatch.Success) { $branchMatch.Groups[1].Value } else { 'main' }
if ($owner -notmatch '^[a-zA-Z0-9-]+$' -or $repo -notmatch '^[a-zA-Z0-9_.-]+$' -or $branch -notmatch '^[a-zA-Z0-9_.-]+$') {
    Write-Host 'ERROR: Repository configuration has unexpected characters.' -ForegroundColor Red
    exit 1
}

$headers = @{
    Authorization = ('Bearer ' + $token)
    'User-Agent' = 'TunerTools-Sheet-ReadOnly-Diagnostic'
    Accept = 'application/vnd.github+json'
    'X-GitHub-Api-Version' = '2022-11-28'
}

function Get-GithubInfo {
    param([string]$Url)
    $status = 0
    $content = ''
    $networkError = ''
    try {
        $res = Invoke-WebRequest -Uri $Url -Method Get -Headers $headers -TimeoutSec 30 -UseBasicParsing
        $status = [int]$res.StatusCode
        $content = [string]$res.Content
    } catch {
        $exceptionResponse = $_.Exception.Response
        if ($null -ne $exceptionResponse) {
            try { $status = [int]$exceptionResponse.StatusCode } catch { $status = 0 }
            try {
                $stream = $exceptionResponse.GetResponseStream()
                if ($null -ne $stream) {
                    $reader = New-Object System.IO.StreamReader($stream)
                    $content = $reader.ReadToEnd()
                    $reader.Close()
                }
            } catch { }
        } else {
            $networkError = $_.Exception.GetType().Name
        }
    }
    $data = $null
    if (![string]::IsNullOrWhiteSpace($content) -and $content.TrimStart().StartsWith('{')) {
        try { $data = ConvertFrom-Json -InputObject $content -ErrorAction Stop } catch { }
    }
    $message = ''
    if ($null -ne $data -and $null -ne $data.message) { $message = [string]$data.message }
    if ($message.Length -gt 150) { $message = $message.Substring(0, 150) }
    return [pscustomobject]@{ Status = $status; Message = $message; NetworkError = $networkError; Data = $data }
}

$lines = New-Object 'System.Collections.Generic.List[string]'
function Report([string]$Line) {
    Write-Host $Line
    [void]$script:lines.Add($Line)
}

Report 'TunerTools - GitHub sheet READ-ONLY check'
Report ('Time: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Report ('PHP: ' + $PhpPath)
Report ('Repository: ' + $owner + '/' + $repo + ' branch=' + $branch)
Report 'GitHub token is never shown or saved.'

$repoUrl = 'https://api.github.com/repos/' + $owner + '/' + $repo
$repoResult = Get-GithubInfo -Url $repoUrl
Report ('Repo GET: HTTP=' + $repoResult.Status + ' message=' + $repoResult.Message + ' network=' + $repoResult.NetworkError)
if ($null -ne $repoResult.Data -and $null -ne $repoResult.Data.permissions) {
    $push = $repoResult.Data.permissions.push
    if ($null -ne $push) { Report ('Repo permissions.push=' + [string]$push) }
}

if ([string]::IsNullOrWhiteSpace($Slug)) {
    $Slug = Read-Host 'Enter FULL slug from MySQL for the song (Enter to skip image check)'
}
$Slug = $Slug.Trim()
if ($Slug -ne '') {
    $ImageCount = [Math]::Max(1, [Math]::Min($ImageCount, 5))
    Report ('Image prefix slug=' + $Slug + ', pages tested=' + $ImageCount)
    $extensions = @('jpg', 'jpeg', 'png', 'webp', 'gif')
    for ($page = 1; $page -le $ImageCount; $page++) {
        foreach ($ext in $extensions) {
            $filename = $Slug + '-' + $page + '.' + $ext
            $imageUrl = $repoUrl + '/contents/' + [Uri]::EscapeDataString($filename) + '?ref=' + [Uri]::EscapeDataString($branch)
            $r = Get-GithubInfo -Url $imageUrl
            if ($r.Status -eq 200) {
                Report ('Page ' + $page + ' found: ' + $filename + ' (HTTP 200)')
                break
            }
            if ($r.Status -ne 404) {
                Report ('Page ' + $page + ': ' + $filename + ' HTTP=' + $r.Status + ' message=' + $r.Message + ' network=' + $r.NetworkError)
                break
            }
            if ($ext -eq $extensions[$extensions.Length - 1]) {
                Report ('Page ' + $page + ' missing in all 5 extensions (HTTP 404)')
            }
        }
    }
} else {
    Report 'Image file check skipped (no slug).'
}

$outPath = Join-Path -Path $PSScriptRoot -ChildPath ('TunerTools_GitHub_ReadOnly_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
$lines | Set-Content -LiteralPath $outPath -Encoding UTF8
Write-Host ('Saved: ' + $outPath)
Write-Host 'This script did not modify PHP, GitHub or MySQL.'
