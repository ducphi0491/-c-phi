KIEM TRA HTTP 502 KHI SUA SHEET (KHONG GHI DU LIEU)

1) Copy Check_GitHub_Sheet_ReadOnly.ps1 vao C:\TunerToolsGP_Fresh\ tren may chu IIS.
2) Mo MySQL Workbench va chay:
   SELECT id, slug, image_count FROM songs
   WHERE title = 'Nguoi Tinh Mua Dong' OR title LIKE '%Tinh Mua Dong%';
   (Neu duoc, su dung title tieng Viet co dau cho chinh xac.)
3) Mo PowerShell tai C:\TunerToolsGP_Fresh va chay:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Check_GitHub_Sheet_ReadOnly.ps1
   Neu PHP khong o C:\inetpub\wwwroot\api_songs.php, dung:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Check_GitHub_Sheet_ReadOnly.ps1 -PhpPath "C:\duong_dan\api_songs.php"
4) Khi duoc hoi, nhap FULL slug tu MySQL (khong phai title).
5) Gui file TunerTools_GitHub_ReadOnly_*.txt duoc tao trong cung thu muc.

Chi GET den api.github.com, khong PUT/DELETE, khong sua token, khong sua file PHP, khong sua MySQL.
Script DOC token tu PHP HIEN CO nhung KHONG HIEN THI hay GHI token vao file ket qua.
Dau ra 'permissions.push' (neu GitHub tra ve) chi la quyen duoc bao cao,
khong thay the cho viec test PUT thuc su.

Interpretation:
- HTTP 401: Token khong duoc GitHub chap nhan.
- HTTP 403: Thieu quyen hoac bi gioi han.
- Repo HTTP 200 va Image HTTP 404: Anh slug co the khong ton tai tai duong dan GitHub da kiem tra.
- Image HTTP 200: Doc duoc anh cu. 502 co the la loi ghi anh moi; can lay JSON error code.
- Repo HTTP 404: Repo khong ton tai hoac token khong co quyen truy cap (khong the phan biet bang GET nay).
