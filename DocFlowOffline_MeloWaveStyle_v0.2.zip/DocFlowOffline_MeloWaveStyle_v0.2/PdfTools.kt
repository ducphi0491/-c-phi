package com.example.docflowoffline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import kotlin.math.min

object PdfTools {
    private fun ready(context: Context) { PDFBoxResourceLoader.init(context.applicationContext) }

    fun merge(context: Context, inputFiles: List<Uri>, output: OutputStream) {
        require(inputFiles.size >= 2) { "Chọn tối thiểu hai tệp PDF để ghép." }
        ready(context)
        PDDocument().use { target ->
            val merger = PDFMergerUtility()
            inputFiles.forEach { uri ->
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    PDDocument.load(stream).use { document -> merger.appendDocument(target, document) }
                } ?: throw IOException("Không mở được PDF: $uri")
            }
            target.save(output)
        }
    }

    /** 1-based page range e.g. "1-3,5,8-9" */
    fun extract(context: Context, source: Uri, pages: String, output: OutputStream) {
        ready(context)
        context.contentResolver.openInputStream(source)?.use { stream ->
            PDDocument.load(stream).use { document ->
                val indices = parsePageRange(pages, document.numberOfPages)
                PDDocument().use { result ->
                    indices.forEach { page -> result.importPage(document.getPage(page - 1)) }
                    result.save(output)
                }
            }
        } ?: throw IOException("Không mở được tệp PDF nguồn.")
    }

    fun parsePageRange(spec: String, total: Int): List<Int> {
        require(total > 0)
        val unique = linkedSetOf<Int>()
        spec.split(',').forEach { part ->
            val token = part.trim()
            require(token.matches(Regex("[1-9][0-9]*(?:\\s*-\\s*[1-9][0-9]*)?"))) { "Khoảng trang không hợp lệ: $token" }
            val numbers = token.split('-').map { it.trim().toInt() }
            val start = numbers.first()
            val end = numbers.last()
            require(start <= end && start in 1..total && end in 1..total) { "Trang phải thuộc khoảng 1..$total" }
            require(end - start <= 2000) { "Khoảng trang quá dài." }
            for (index in start..end) unique.add(index)
        }
        require(unique.isNotEmpty()) { "Chưa chọn trang." }
        return unique.toList()
    }

    fun renderPage(context: Context, uri: Uri, pageIndex: Int, maxWidth: Int = 1280): Pair<Bitmap, Int> {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Không mở được PDF.")
        descriptor.use { fd ->
            PdfRenderer(fd).use { renderer ->
                require(pageIndex in 0 until renderer.pageCount) { "Trang không hợp lệ." }
                renderer.openPage(pageIndex).use { page ->
                    val scale = min(maxWidth.toFloat() / page.width, 3f).coerceAtLeast(0.2f)
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap to renderer.pageCount
                }
            }
        }
    }

    fun pagePng(context: Context, uri: Uri, pageIndex: Int, output: OutputStream) {
        val (bitmap, _) = renderPage(context, uri, pageIndex, 1900)
        try {
            require(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) { "Không thể ghi PNG." }
        } finally { bitmap.recycle() }
    }

    fun imagesToPdf(context: Context, uris: List<Uri>, output: OutputStream) {
        require(uris.isNotEmpty()) { "Chưa chọn hình ảnh." }
        PdfDocument().use { pdf ->
            val pageWidth = 595
            val pageHeight = 842
            val padding = 28f
            uris.forEachIndexed { index, uri ->
                val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
                    val buffer = ByteArrayOutputStream()
                    val chunk = ByteArray(8192)
                    while (true) {
                        val n = stream.read(chunk)
                        if (n < 0) break
                        require(buffer.size() + n <= 24 * 1024 * 1024) { "Ảnh quá lớn." }
                        buffer.write(chunk, 0, n)
                    }
                    buffer.toByteArray()
                } ?: throw IOException("Không đọc được hình ảnh: $uri")
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Định dạng ảnh không hợp lệ." }
                var sample = 1
                while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    ?: throw IOException("Không giải mã được hình ảnh.")
                try {
                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create())
                    page.canvas.drawColor(Color.WHITE)
                    val xScale = (pageWidth - padding * 2) / bitmap.width
                    val yScale = (pageHeight - padding * 2) / bitmap.height
                    val ratio = min(xScale, yScale)
                    val width = bitmap.width * ratio
                    val height = bitmap.height * ratio
                    page.canvas.drawBitmap(bitmap, null,
                        android.graphics.RectF((pageWidth - width) / 2f, (pageHeight - height) / 2f,
                            (pageWidth + width) / 2f, (pageHeight + height) / 2f),
                        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    pdf.finishPage(page)
                } finally { bitmap.recycle() }
            }
            pdf.writeTo(output)
        }
    }
}

/** Simple text-to-PDF fallback; it does not preserve Word/Excel page layout. */
object TextPdfExporter {
    fun create(text: String, output: OutputStream, title: String = "Tài liệu") {
        PdfDocument().use { document ->
            val width = 595
            val height = 842
            val margin = 42f
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(30, 40, 56)
                textSize = 12f
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            }
            val lineHeight = 19f
            var pageNumber = 0
            var y = 0f
            var page: PdfDocument.Page? = null
            fun nextPage() {
                if (page != null) document.finishPage(page!!)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create())
                page!!.canvas.drawColor(Color.WHITE)
                y = margin
                paint.textSize = 9f
                paint.color = Color.GRAY
                page!!.canvas.drawText("$title  |  $pageNumber", margin, y, paint)
                paint.textSize = 12f
                paint.color = Color.rgb(30, 40, 56)
                y += 32f
            }
            nextPage()
            for (line in text.replace("\r\n", "\n").split('\n')) {
                val fragments = wrap(line, paint, width - 2 * margin)
                for (fragment in fragments) {
                    if (y > height - margin) nextPage()
                    page!!.canvas.drawText(fragment, margin, y, paint)
                    y += lineHeight
                }
            }
            if (page != null) document.finishPage(page!!)
            document.writeTo(output)
        }
    }

    private fun wrap(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isEmpty()) return listOf("")
        val lines = mutableListOf<String>()
        var rest = text.replace('\t', ' ')
        while (rest.isNotEmpty()) {
            val fit = paint.breakText(rest, true, maxWidth, null).coerceAtLeast(1)
            if (fit >= rest.length) {
                lines.add(rest)
                break
            }
            val end = rest.lastIndexOf(' ', fit).takeIf { it > 0 } ?: fit
            lines.add(rest.substring(0, end).trimEnd())
            rest = rest.substring(end).trimStart()
        }
        return lines
    }
}
