DOCFLOW OFFLINE v0.2 — FILE CODE SẮP XẾP GIỐNG MELOWAVE

Tất cả file *.kt ở thư mục gốc ZIP, cùng package: com.example.docflowoffline

CÁCH THAY FILE VÀO ANDROID STUDIO:
1. Mở Android Studio, project DocFlowOffline (hoặc dùng ZIP Android Studio đi kèm).
2. Chép 8 file *.kt vào: app/src/main/java/com/example/docflowoffline/
   XÓA các file *.kt cũ ở: core/ và ui/ để tránh lỗi duplicate class.
3. Chép AndroidManifest.xml vào: app/src/main/AndroidManifest.xml
4. Chép build.gradle.kts vào: app/build.gradle.kts (KHÔNG phải ở root project).
5. Chép thư mục assets/* vào app/src/main/assets/
6. Chép thư mục res/* vào app/src/main/res/
7. Sync Gradle, sau đó build project.

KHÔNG PHẢI chép tất cả file vào 1 thư mục Android Studio duy nhất:
Kotlin ở một thư mục; Manifest/Gradle/ảnh/tài liệu mẫu phải đúng đường dẫn Android.

Không đổi logic; chỉ sắp xếp cấu trúc package và import.
Giữ nguyên 8 file Kotlin, không yêu cầu thêm quyền INTERNET hay bản quyền SDK thương mại.
Tính năng chỉnh sửa Office WYSIWYG bằng Collabora chưa được tích hợp.

Nếu muốn mở trực tiếp bằng Android Studio mà không chép file, hãy dùng ZIP:
DocFlowOffline_AndroidStudio_Flat_v0.2.zip
