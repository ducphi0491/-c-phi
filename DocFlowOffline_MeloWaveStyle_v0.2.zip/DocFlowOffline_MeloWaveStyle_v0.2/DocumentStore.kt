package com.example.docflowoffline

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.Locale

object DocumentStore {
    const val DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    const val PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    const val PDF = "application/pdf"
    const val CSV = "text/csv"
    const val TXT = "text/plain"

    sealed class OpenFile(open val uri: Uri, open val name: String) {
        data class Word(override val uri: Uri, override val name: String, val bytes: ByteArray, val data: OfficeOoxml.Word) : OpenFile(uri, name)
        data class Excel(override val uri: Uri, override val name: String, val bytes: ByteArray, val data: OfficeOoxml.Workbook) : OpenFile(uri, name)
        data class Slides(override val uri: Uri, override val name: String, val slides: List<OfficeOoxml.Slide>) : OpenFile(uri, name)
        data class Pdf(override val uri: Uri, override val name: String) : OpenFile(uri, name)
        data class Text(override val uri: Uri, override val name: String, val value: String, val csv: Boolean) : OpenFile(uri, name)
    }

    fun fileName(context: Context, uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Tai_lieu"
    }

    fun open(context: Context, uri: Uri): OpenFile {
        val name = fileName(context, uri)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val kind = if (ext in setOf("docx", "xlsx", "pptx", "pdf", "txt", "csv", "tsv")) ext
            else when (context.contentResolver.getType(uri)) {
                DOCX -> "docx"
                XLSX -> "xlsx"
                PPTX -> "pptx"
                PDF -> "pdf"
                CSV -> "csv"
                TXT -> "txt"
                else -> ext
            }
        return when (kind) {
            "docx" -> {
                val bytes = readUpTo(context, uri)
                OpenFile.Word(uri, name, bytes, OfficeOoxml.readWord(bytes))
            }
            "xlsx" -> {
                val bytes = readUpTo(context, uri)
                OpenFile.Excel(uri, name, bytes, OfficeOoxml.readWorkbook(bytes))
            }
            "pptx" -> {
                val bytes = readUpTo(context, uri)
                OpenFile.Slides(uri, name, OfficeOoxml.readPresentation(bytes))
            }
            "pdf" -> OpenFile.Pdf(uri, name)
            "txt", "csv", "tsv" -> {
                val bytes = readUpTo(context, uri, 10 * 1024 * 1024)
                // BOM UTF-8 only; older encodings need a future encoding chooser.
                val body = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
                OpenFile.Text(uri, name, body, ext != "txt")
            }
            else -> throw IllegalArgumentException("Định dạng .$ext chưa được hỗ trợ. Hãy chọn DOCX, XLSX, PPTX, PDF, TXT hoặc CSV.")
        }
    }

    fun readUpTo(context: Context, uri: Uri, maxBytes: Int = 40 * 1024 * 1024): ByteArray {
        val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Không mở được tệp.")
        return input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(16384)
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                if (out.size() + n > maxBytes) throw IOException("Tệp quá lớn (giới hạn ${maxBytes / (1024 * 1024)} MB trong phiên bản thử nghiệm).")
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        }
    }

    data class Recent(val uri: String, val name: String)
    fun recent(context: Context): List<Recent> = runCatching {
        val json = JSONArray(context.getSharedPreferences("recent_files", Context.MODE_PRIVATE).getString("files", "[]"))
        (0 until json.length()).mapNotNull { i ->
            val item = json.optJSONObject(i) ?: return@mapNotNull null
            val uri = item.optString("uri")
            val name = item.optString("name")
            if (uri.isEmpty() || name.isEmpty()) null else Recent(uri, name)
        }
    }.getOrDefault(emptyList())

    fun remember(context: Context, uri: Uri, name: String) {
        val list = (listOf(Recent(uri.toString(), name)) + recent(context).filterNot { it.uri == uri.toString() }).take(15)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        context.getSharedPreferences("recent_files", Context.MODE_PRIVATE).edit().putString("files", arr.toString()).apply()
    }

    fun persistReadPermission(context: Context, uri: Uri) {
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    fun suggestedCopyName(original: String, ext: String): String =
        original.substringBeforeLast('.', original) + "_edited." + ext
}
