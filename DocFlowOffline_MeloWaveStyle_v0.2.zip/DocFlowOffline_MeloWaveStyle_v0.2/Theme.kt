package com.example.docflowoffline

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightScheme = lightColorScheme(
    primary = Color(0xFF126D78),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC8EFF1),
    onPrimaryContainer = Color(0xFF07373C),
    secondary = Color(0xFF4B6265),
    background = Color(0xFFF7F9FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFEDF2F4)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF80D5DD),
    primaryContainer = Color(0xFF164C54),
    secondary = Color(0xFFB1CDD0),
    background = Color(0xFF101719),
    surface = Color(0xFF192124)
)

@Composable
fun DocFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme, content = content)
}
