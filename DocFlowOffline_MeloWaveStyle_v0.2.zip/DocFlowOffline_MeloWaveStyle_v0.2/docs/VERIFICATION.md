# Báo cáo kiểm thử (2026-10-20)

## Đã kiểm tra trực tiếp trong môi trường tạo dự án

- `kotlinc` trên JVM: biên dịch thành công `OfficeOoxml.kt` và `CsvEngine.kt`.
- DOCX: sửa, thêm đoạn tiếng Việt; xuất ZIP OOXML thành công; file mở lại bằng **python-docx** được.
- XLSX: sửa chuỗi tiếng Việt, số 12.5 và công thức `=SUM(B3:B3)`; **openpyxl** đọc file được sau khi lưu.
- PPTX: đọc nội dung 2 slide, thay chữ trong slide; **python-pptx** đọc lại file đã chỉnh sửa được.
- CSV: bộ phân tích đọc/lưu dấu phẩy, dấu nháy kép và xuống dòng trong một ô.

## Chưa kiểm tra được (không được hiểu là đã pass)

- Chưa có Android SDK, Android Gradle Plugin và Gradle distribution trong môi trường chạy code này; do đó **chưa chạy được Gradle Sync, Android compile, emulator hoặc thiết bị thật**.
- Chưa chạy thử thư viện PDFBox-Android trên thiết bị; chức năng ghép/tách PDF là code triển khai cần kiểm chứng.
- Chưa biên dịch Collabora native; mã nguồn **không chứa Collabora engine**.
- Chưa kiểm thử tương thích Office thực tế bằng Microsoft Word/Excel/PowerPoint trên Android hoặc PC; python-docx/openpyxl/python-pptx không bảo đảm mọi định dạng được bảo toàn.
- Chưa kiểm tra hiệu năng với nhiều loại tệp lớn, tệp mã hóa hoặc file PDF độc hại.

## Đề xuất kiểm thử đầu tiên trên Android Studio

1. Gradle Sync và Build Debug. Giải quyết API-level/dependency issue nếu phiên bản Android Studio cụ thể có khác biệt.
2. Tạo Word, sửa chữ có dấu, lưu bản sao, mở lại.
3. Tạo Excel, nhập A1, B3 và `=SUM(B3:B3)`, lưu, mở trên Microsoft Excel/LibreOffice để xác nhận công thức tính lại.
4. Mở PPTX mẫu; sửa tiêu đề, lưu bản sao, mở lại.
5. Mở PDF nhiều trang, chuyển trang, xuất PNG; ghép hai PDF, tách trang `1-2,4`.
6. Chọn nhiều ảnh tạo PDF. Bật chế độ máy bay và lặp lại bài kiểm tra.
7. Kiểm tra file gốc có còn nguyên và file mới không bị lỗi, đặc biệt khi ứng dụng bị đóng/mất dung lượng trong lúc lưu.
