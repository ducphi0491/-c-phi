# Hướng tích hợp Collabora/LibreOffice native (giai đoạn nâng cấp)

## Trạng thái

**Chưa tích hợp** engine native vào APK này. App 0.1 đang sử dụng OOXML đơn giản nên không có toàn bộ tính năng của Writer/Calc/Impress.

Collabora là một ứng dụng và codebase native lớn, **không** phải chỉ một Maven/Gradle dependency. Hướng dẫn chính thức (kiểm tra tháng 10/2026):
https://www.collaboraoffice.org/post/build-code-android/

## 1. Chuẩn bị Linux

- Máy Linux/Ubuntu thật hoặc VM Linux đủ CPU, RAM và trống SSD.
- Git, make, autoconf/automake, các gói phụ thuộc LibreOffice theo README của engine.
- Android SDK và NDK tương thích với đúng commit đang build; tài liệu chính thức nêu NDK 23.0.7599858 đã được kiểm thử, các bản NDK khác phải xác nhận lại.
- Android Studio để build/test phần Android sau khi engine đã được biên dịch.

## 2. Lấy mã nguồn nguyên gốc từ dự án Collabora

```bash
git clone https://gerrit.collaboraoffice.com/online collabora-office
cd collabora-office/engine
```

Core nằm ở `engine/` cùng monorepo `online`; không dùng một repo core cũ độc lập.

## 3. Cấu hình ABI arm64-v8a (ví dụ)

Tạo `engine/autogen.input`; đường dẫn SDK/NDK **chỉ là ví dụ** và cần thay bằng đường dẫn trên máy build:

```
--build=x86_64-unknown-linux-gnu
--with-android-ndk=/home/USER/Android/Sdk/ndk/23.0.7599858
--with-android-sdk=/home/USER/Android/Sdk
--enable-sal-log
--with-distro=CPAndroidAarch64
```

Sau đó trong `engine/` chạy:

```bash
./autogen.sh
make -j4
```

Tại thư mục gốc monorepo chạy bước cấu hình/app theo hướng dẫn chính thức, với `--with-lo-builddir=` chỉ đến bản build engine và `--with-android-abi=arm64-v8a`. Cuối cùng mở `android/` bằng Android Studio.

**Không cung cấp sẵn các bước chép ngẫu nhiên `.so` vào app Compose**: Collabora yêu cầu asset, thư viện native, Java/JS bootstrap và lifecycle tương ứng. Sao chép mỗi file `.so` không tạo ra trình soạn thảo hoạt động.

## 4. Chiến lược tích hợp vào sản phẩm riêng

1. Build ứng dụng Collabora Android nguyên bản từ nguồn trước; kiểm thử DOCX/XLSX/PPTX và lưu tệp khi bật chế độ máy bay.
2. Đánh giá chính xác giấy phép *của commit được chọn*, các third-party NOTICE, bộ nhận diện thương hiệu và điều khoản phát hành trên Google Play.
3. Thử nghiệm giao diện launcher/manager Kotlin + Compose điều hướng đến Activity editor của **bản Collabora tự build**, thay vì cố nhúng engine như một Gradle artifact. Việc đổi package/applicationId/resource names cần được xem xét kỹ.
4. Giữ Storage Access Framework và logic lưu bản sao, sau đó nối dữ liệu sang editor native.
5. Thử trên Android arm64 và x86_64, offline và khi đổi màn hình; kiểm tra tính đúng đắn của định dạng và file lớn.
6. Chỉ khi ứng dụng tích hợp chạy ổn mới loại bỏ bộ editor OOXML đơn giản của prototype.

**Quan trọng:** Không bảo đảm chỉ riêng MPL 2.0 áp dụng cho toàn bộ sản phẩm. Phải kiểm toán giấy phép trên từng phần nguồn/asset, và cung cấp mã nguồn tương ứng cho các phần mà giấy phép yêu cầu. Dùng mã nguồn mở theo giấy phép không phải trả phí theo mỗi người dùng, nhưng vẫn có trách nhiệm tuân thủ.
