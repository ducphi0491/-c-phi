# Third-party components, license notes (prototype)

Các thành phần ở file `app/build.gradle.kts` được lấy từ Google Maven và Maven Central trong lần Gradle Sync đầu tiên.

- Android Gradle Plugin / Android SDK: theo điều khoản phát triển & phân phối Android của Google.
- Kotlin, Kotlin Coroutines: Apache License 2.0.
- AndroidX Jetpack Compose / Activity / Core: Apache License 2.0.
- `com.tom-roush:pdfbox-android:2.0.27.0`: Apache License 2.0, https://github.com/TomRoush/PdfBox-Android . Bản này cũ nên cần kiểm tra vấn đề an toàn khi dùng trên file PDF không tin cậy trước khi phát hành công khai. Có các phụ thuộc bouncy-castle cần kiểm toán CVE.
- Mẫu trống DOCX/XLSX/PPTX: được tạo bằng python-docx/openpyxl/python-pptx trong quá trình xây dựng, không sao chép mẫu độc quyền.
- `OfficeOoxml.kt`, `CsvEngine.kt` và code Android: mã nguồn tự viết trong dự án này; không chứa bất kỳ mã binary hay mã nguồn Collabora nào.

**Nếu tích hợp Collabora**: đọc giấy phép hiện hành của source commit từ chính upstream; chuẩn bị đầy đủ third-party notices và các phần source phải công bố. Không lấy Collabora APK thương mại hoặc asset thương hiệu rồi đóng gói lại mà chưa có quyền.
