DOCFLOW OFFLINE v1.5 - BOI CHON VA CONG CU CO BAN CHO WORD/PDF
================================================================

FILE CAN THAY:
1) app/src/main/java/com/docflowoffline/DocumentScreens.kt
2) app/src/main/java/com/docflowoffline/DocumentEngines.kt

Khong can sua AndroidManifest.xml hoac build.gradle.kts.
Du an hien tai da co thu vien com.tom-roush:pdfbox-android:2.0.27.0.

WORD - CHUC NANG MOI
- Nhan giu tren van ban va keo hai tay nam de boi chon.
- Sao chep, cat, dan va chon tat ca.
- In dam, nghieng, gach chan.
- Mau chu, mau nen, tang/giam co chu.
- Can trai, giua, phai.
- Dau dau dong va danh so.
- Tim, thay mot va thay tat ca.
- Hoan tac, lam lai.
- Luu ban sao DOCX co dinh dang co ban.
- Xuat Word thanh PDF dang van ban.

PDF - CHUC NANG MOI
- Tim kiem van ban trong toan bo PDF va nhay den trang ket qua.
- Chon cong cu boi vung, sau do keo tren trang PDF.
- Sao chep van ban trong vung da chon neu PDF co lop chu.
- To sang, gach chan, gach ngang va luu thanh ban PDF moi.
- Xoay trang 90 do.
- Xoa trang hien tai.
- Xuat trang hien tai thanh PNG.
- Giu zoom, keo trang, tach trang nhu truoc.

GIOI HAN
- Word co bang, hinh ve, text box, header/footer phuc tap duoc mo o che do chi doc de tranh lam hong bo cuc. Van co the boi chon va sao chep chu.
- PDF scan/hinh anh khong co lop chu: co the boi vung va to sang, nhung chua sao chep/tim kiem chu neu chua tich hop OCR.
- PDF khong chinh sua truc tiep noi dung goc nhu Word; cac thao tac la chu thich, sap xep trang va trich xuat.

CAP NHAT
- Sao luu 2 file cu.
- Chep de 2 file trong ZIP vao dung thu muc.
- Android Studio: Build > Clean Project, sau do Build > Rebuild Project.
