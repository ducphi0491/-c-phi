TUNERTOOLS - KOTLIN GOOGLE LOGIN + DOCUMENTS DRIVE-PRIMARY FIX V4
=============================================================

MUC TIEU
- Giu nguyen dang nhap Google thong thuong cua app (email + profile).
- Documents/Quyen tai lieu doc tu Alwaysdata + Google Drive truoc, IIS la du phong.
- KHONG tu signOut Google chi vi Documents chua duoc cap ID token.
- Khi nguoi dung dang nhap Documents, dung Web OAuth Client ID rieng de xin ID token.
- Hien dung ma loi Google neu Intent co thong tin, du resultCode la CANCELED.
- Neu Google khong cap ID token, hien package va SHA-1 CUA APK DANG CAI tren thiet bi.
- KHONG bo xac minh ID token o Alwaysdata, KHONG tin moi Gmail do Android tu gui.

FILES
Android/Gamefolder.kt: thay file Gamefolder.kt trong du an.
Android/admin.kt: thay file admin.kt trong du an.
Android/tt_documents_oauth.xml: mau XML cua nguoi dung da cung cap.
README_HUONG_DAN.txt: file nay.
KET_QUA_KIEM_TRA.txt: ket qua kiem tra tĩnh va helper Kotlin.

CAI DAT
1. Backup Gamefolder.kt va admin.kt dang dung trong Android Studio.
2. Chi thay 2 file Kotlin trong app/src/main/java/ducphi/tunnerinstrument/
   (neu project luu khac, tim dung vi tri file cu de THAY, khong tao trung).
3. Giu 1 file app/src/main/res/values/tt_documents_oauth.xml. Neu da co,
   khong tao them ban thu hai. Ma trong XML phai la WEB CLIENT ID,
   trung voi /home/tuner/private/tt_documents_private.php tren Alwaysdata.
4. Android Studio -> Build -> Rebuild Project; build va cai APK moi.
5. Thu DANG NHAP GOOGLE CHUNG cua TunerTools truoc.
6. Vao Admin -> Quyen tai lieu -> Dang nhap bang Google.
7. Neu tiep tuc thieu token/Google ma 10, trong thong bao V4 co:
       APK package: ...
       SHA-1 APK: ...
   Doi chieu SHA-1 nay voi OAuth Android Client trong CUNG project
   Google Cloud voi WEB CLIENT ID (va applicationId cua APK).
   Luu y APK debug, release va Google Play co the ky bang cac chung chi khac nhau.
8. Neu Google da cap token nhung Alwaysdata bao google_identity_not_verified,
   can kiem tra backend: aud/iss/exp/email_verified/sub KHONG gui token len chat.

PHAN BIET CAC NGUYEN NHAN
- Google login chung thanh cong, Documents thieu ID token: KHONG phai loi
  token Drive hoac document_permissions.json. Can xu ly OAuth/ID token.
- Google OAuth code 10: kiem tra Android package + SHA-1 va Google project.
- `oauth_ready=True` o Alwaysdata chi chung to bien cau hinh da duoc nap,
  khong chung to Android da duoc Google cap token.

BAO MAT
- Khong gui ID token, Drive token, Session secret, Shared secret hay
  file tt_documents_private.php cho ai.
- SHA-1 APK la fingerprint cong khai, co the gui de doi chieu.
- Khong thay doi PHP IIS, MySQL hoac JSON phan quyen 93 tai khoan.

KIEM TRA DA LAM
- So sanh luong sign-in thong thuong voi file nguon truoc Drive-Primary:
  khong requestIdToken bat buoc cho sign-in chung.
- XML bien dich duoc bang XML parser.
- Unit test Kotlin stub cua helper lay SHA-1 APK: OK.
- Kiem tra logic Kotlin: phan tach client, audience, xu ly intent Google: OK.
- CHUA build APK voi toan bo Gradle/Android SDK cua du an, CHUA thu tren dien thoai.
- KHONG the dam bao ID token duoc cap neu Google Cloud package + SHA-1 sai.

KHOI PHUC
- Neu gap loi build, phuc hoi 2 file Kotlin backup da sao luu o buoc 1.
- Khong can sua/restore database hay Google Drive.
