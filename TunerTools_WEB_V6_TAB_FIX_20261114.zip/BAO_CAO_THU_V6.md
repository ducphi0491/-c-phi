# TunerTools Web V6 - Báo cáo thử nghiệm trước khi bàn giao

## Nội dung sửa thật

- **Khắc phục mất dây TAB trên cùng:** Trong V5, nhóm TAB chỉ có 5 đường vector luôn được nối thêm đường dưới. V6 kiểm tra vị trí các chữ số fret quanh cả hai phía và chọn phía có bằng chứng tốt hơn; không có đủ bằng chứng thì giữ cảnh báo.
- **Cảnh báo khuông chồng nhau:** Những nhóm đường TAB ứng viên chiếm cùng vùng được ghi nhận là rủi ro; chưa tách tự động.
- **Đồng bộ ảnh overlay:** Đường TAB trên bản kiểm tra nguồn nay dùng cùng kết quả căn chỉnh với trình trích xuất.
- **Báo cáo chi tiết:** ZIP đối chiếu V6 bổ sung `alignment_audit.csv`, số lượng chữ số ứng viên được khôi phục, vùng chồng đường và trạng thái chưa kiểm chứng.

## Kết quả chạy với PDF Nhật ký của mẹ - Tremolo (6 trang)

| Hạng mục | V5 | V6 thử nghiệm |
|---|---:|---:|
| Vùng ô nhịp được dựng | 96 | 96 |
| Số nốt được lưu trong dữ liệu nháp | 962 | 1120 |
| Số ngăn TAB ứng viên từ PDF | 966 | 1124 |
| Ứng viên được tìm thêm nhờ căn chỉnh đường | - | 158 |
| Nhãn ô nhịp chưa ánh xạ chắc chắn | 15 | 15 |
| Hệ có đường TAB chồng / căn chỉnh mơ hồ | Chưa có cảnh báo riêng | 3 |

Các con số này **không phải thước đo độ chính xác âm nhạc**. Có thêm nốt không đảm bảo đủ và đúng trường độ. Đặc biệt V6 chưa giải mã OMR độc lập và còn có thể ghép sai nhiều bè, dấu hóa và kỹ thuật guitar. Giai điệu không được cam kết chính xác.

## Kiểm thử tự động

- 21 bài kiểm thử Python đã chạy qua, trong đó có phép thử dựng PDF vector bị thiếu đường trên/dưới, bảo vệ báo cáo ZIP và API.
- Đã đọc thử đầy đủ 6 trang PDF mẫu bằng hàm trích xuất; chương trình tạo kết quả thống kê nêu trên.
- **Chưa chạy thử ghi GP3/GP4/GP5 và toàn bộ launcher trên Windows tại môi trường này:** không thể tải PyGuitarPro do Internet bị giới hạn. Các chức năng ghi GP giữ nguyên logic từ V5; máy Windows của bạn sẽ cần chạy và gửi lại gói đối chiếu.

## Hướng phát triển sau V6

Nhánh OMR độc lập để đọc trường độ từ thanh nối/đuôi nốt, nhận diện vạch nhịp theo cả hai hệ, ánh xạ chính xác 111 nhãn và nhận diện H/P, slide, tremolo là **chưa hoàn thành**. Chỉ bổ sung sau khi có dữ liệu thực nghiệm. Không coi bản GP nháp là bản chuẩn.
