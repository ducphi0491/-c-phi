@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAI_DAT_V6.ps1"
if errorlevel 1 (
  echo Installation failed. Check the text above.
  pause
  exit /b 1
)
echo.
echo Launching TunerTools V6...
call "C:\TunerTools\Tools\PDF_TAB_GP_WEB\CHAY_WEB.bat"
