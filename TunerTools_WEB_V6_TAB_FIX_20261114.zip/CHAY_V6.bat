@echo off
if not exist "C:\TunerTools\Tools\PDF_TAB_GP_WEB\CHAY_WEB.bat" (
  echo Cannot find TunerTools Web. Install V6 first.
  pause
  exit /b 1
)
call "C:\TunerTools\Tools\PDF_TAB_GP_WEB\CHAY_WEB.bat"
