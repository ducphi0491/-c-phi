"""V6 regression tests: recover the *top* string of a partial vector TAB."""
import io
import json
import zipfile

import fitz
from vector_draft import _tab_candidates, _words_in_tab, extract_vector_draft
from review_bundle import generate_review_zip


def _partial_tab_pdf(recover_top=True):
    d=fitz.open()
    p=d.new_page(width=595,height=360)
    # Real TAB rows 1..6 (7.8pt apart). Five are vector-drawn.
    start=142.2
    rows=[start+i*7.8 for i in range(6)]
    kept=rows[1:] if recover_top else rows[:-1]
    for y in kept:
        shape=p.new_shape()
        shape.draw_line((45,y),(550,y))
        shape.finish(color=(0,0,0),width=.5)
        shape.commit()
    active=rows[0] if recover_top else rows[-1]
    # 24 distinct fret positions support the missing line.
    for j in range(24):
        p.insert_text((50+20*j,active+3.4),'8' if recover_top else '3',fontsize=9)
    # And a few letters on a known line.
    for x in [60,180,310]:
        p.insert_text((x,kept[2]+3.4),'0',fontsize=9)
    out=d.tobytes();d.close()
    return out


def test_top_string_recovered_from_pdf_glyphs():
    data=_partial_tab_pdf(True)
    with fitz.open(stream=data,filetype='pdf') as doc:
        tabs=_tab_candidates(doc[0])
        assert len(tabs)==1
        top=tabs[0]
        assert top['alignment']['method']=='prepend_top'
        notes=_words_in_tab(doc[0],top)
        assert len([x for x in notes if x['string']==1]) == 24
    draft=extract_vector_draft(data,[0])
    assert draft['source_frets'] >= 27
    assert draft['new_fret_candidates_found'] >= 24
    assert any(a['method']=='prepend_top' for a in draft['alignment_audit'])
    assert draft['notes_are_verified'] is False
    assert draft['rhythm_is_verified'] is False


def test_bottom_string_recovered_when_evidence_is_below():
    data=_partial_tab_pdf(False)
    with fitz.open(stream=data,filetype='pdf') as doc:
        tabs=_tab_candidates(doc[0])
        assert len(tabs)==1
        assert tabs[0]['alignment']['method']=='append_bottom'
        assert len([x for x in _words_in_tab(doc[0],tabs[0]) if x['string']==6])==24


def test_zip_contains_alignment_csv_even_when_no_draft():
    score={'tempo':80,'title':'Demo','tracks':[]}
    z=generate_review_zip({'source_file':b'','source_filename':'dummy.png',
                           'files':{},'score':score,'report':{},'name':'dummy'})
    with zipfile.ZipFile(io.BytesIO(z)) as f:
        assert f.testzip() is None
        assert 'alignment_audit.csv' in f.namelist()
        manifest=json.loads(f.read('manifest.json'))
        assert manifest['version']=='6.0-tab-audit'
