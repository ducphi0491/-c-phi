param([switch]$Reinstall)

# Windows PowerShell 5.1 and Windows 10/11. No administrator rights required.
# The app listens ONLY on 127.0.0.1, not on a public network interface.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root
$Venv = Join-Path $Root '.venv'
$Python = Join-Path $Venv 'Scripts\python.exe'

Write-Host ''
Write-Host '===========================================' -ForegroundColor Cyan
Write-Host ' TunerTools - PDF / Anh -> GP Web V6 TAB AUDIT' -ForegroundColor Cyan
Write-Host '===========================================' -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $Python)) {
    Write-Host 'Tao moi truong Python rieng ...' -ForegroundColor Yellow
    $created = $false
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3.11 -m venv $Venv
        $created = ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python))
        if (-not $created) {
            & py -3.12 -m venv $Venv
            $created = ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python))
        }
    }
    if (-not $created -and (Get-Command python -ErrorAction SilentlyContinue)) {
        & python -m venv $Venv
        $created = ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python))
    }
    if (-not $created) {
        Write-Host 'LOI: Can cai Python 3.11 hoac 3.12 (64-bit), bat Add Python to PATH.' -ForegroundColor Red
        exit 1
    }
}

$Marker = Join-Path $Root '.deps_installed_v4'
if ((-not (Test-Path -LiteralPath $Marker)) -or $Reinstall) {
    Write-Host 'Cai thu vien CO BAN: Web, PDF vector, Guitar Pro (can Internet lan dau)' -ForegroundColor Yellow
    & $Python -m pip install --disable-pip-version-check -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'LOI: Cai thu vien co ban that bai. Kiem tra Internet / Python.' -ForegroundColor Red
        exit 1
    }
    & $Python -c "import fastapi, fitz, guitarpro, PIL; print('Core modules OK')"
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'LOI: Thu vien chua san sang. Chay lai CHAY_WEB.ps1 -Reinstall.' -ForegroundColor Red
        exit 1
    }
    Set-Content -LiteralPath $Marker -Value 'V4 core modules installed' -Encoding UTF8
}
& $Python -c "import importlib.util; print('Optional OCR engine:', bool(importlib.util.find_spec('pdf_to_gp5')))"
Write-Host 'Ghi chu: V6 co the chay TAB vector ma khong can cai OCR/OMR.' -ForegroundColor Green
Write-Host 'De them OCR anh/PDF scan, chay CAI_ENGINE_OCR.bat rieng.' -ForegroundColor Yellow

# Optional visual renderer: local alphaTab + Bravura + SoundFont (MPL/OFL/Apache).
# If download fails, the built-in offline SVG renderer still shows both staff and TAB.
$AlphaJs = Join-Path $Root 'static\alphatab\alphaTab.min.js'
$AlphaSound = Join-Path $Root 'static\alphatab\soundfont\sonivox.sf2'
if (-not (Test-Path -LiteralPath $AlphaJs) -or -not (Test-Path -LiteralPath $AlphaSound)) {
    Write-Host 'Cai bo hien thi khuong nhac alphaTab cho lan dau ...' -ForegroundColor Yellow
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root 'CAI_ALPHATAB.ps1')
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'CHU Y: Khong cai duoc alphaTab. Van dung duoc khuong nhac SVG co ban.' -ForegroundColor Yellow
    }
}

$Port = 8021
$Url = "http://127.0.0.1:$Port"
# Prevent accidentally displaying an older instance still bound to port 8021.
try {
    $Existing = Invoke-WebRequest -Uri ($Url + '/api/health') -TimeoutSec 2 -UseBasicParsing -ErrorAction Stop
    if ($Existing.StatusCode -eq 200) {
        Write-Host 'LOI: Port 8021 van dang co web cu chay. Hay quay lai cua so CHAY_WEB cu, nhan ENTER de dung.' -ForegroundColor Red
        Write-Host 'Sau do hay chay lai file CHAY_WEB.bat moi; nhan Ctrl+F5 tren trinh duyet.' -ForegroundColor Yellow
        exit 1
    }
} catch { }
Write-Host ('Mo server local: ' + $Url) -ForegroundColor Green

# Start the local server. A separate process allows the script to open the
# browser only after its health endpoint responds (rather than showing a 404).
$server = Start-Process -FilePath $Python -ArgumentList @('-m','uvicorn','app:app','--host','127.0.0.1','--port',"$Port",'--workers','1') -WorkingDirectory $Root -PassThru
if (-not $server) {
    Write-Host 'LOI: Khong khoi dong duoc server.' -ForegroundColor Red
    exit 1
}
$ready = $false
for ($i=0; $i -lt 40; $i++) {
    try {
        $res = Invoke-WebRequest -Uri ($Url + '/api/health') -TimeoutSec 2 -UseBasicParsing
        if ($res.StatusCode -eq 200) { $ready = $true; break }
    } catch { Start-Sleep -Milliseconds 500 }
    if ($server.HasExited) { break }
}
if (-not $ready) {
    Write-Host 'LOI: Server khong san sang. Kiem tra port 8021 va Python.' -ForegroundColor Red
    if (-not $server.HasExited) { Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue }
    exit 1
}
Start-Process $Url
Write-Host ''
Write-Host 'Da mo giao dien tren trinh duyet.' -ForegroundColor Green
Write-Host 'KHONG mo cong 8021 ra Internet; moi file duoc xu ly tren may tinh.'
Write-Host 'Nhan ENTER tai cua so nay de dung server.' -ForegroundColor Cyan
$null = Read-Host
Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
