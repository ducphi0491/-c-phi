'use strict';

const $ = id => document.getElementById(id);
const state = { file: null, blobURL: null, jobId: null, response: null, track: 0,
  audio: null, interval: null, isPlaying: false, positionQ: 0, startQ: 0, startAt: 0,
  events: [], nextEvent: 0, maxQ: 0, activeNote: null, editing: null, demo: false,
  scoreMode: 'both', scoreZoom: 1, playEngine: 'web', inspection: null, sourceId:null,
  sourcePage:1, overlayMode:false, orpheusAvailable:false, loadSequence:0 };
const FILE_MAX = 35 * 1024 * 1024;
const n2 = n => String(n).padStart(2, '0');
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c])); }
function fmtTime(sec) { sec = Math.max(0, Math.floor(sec)); return `${n2(Math.floor(sec/60))}:${n2(sec%60)}`; }
function getBpm() { return Math.min(300, Math.max(30, Number($('playBpm').value) || 100)); }
function getSpeed() { return Number($('speedSelect').value) || 1; }
function secPerQuarter() { return 60 / (getBpm()*getSpeed()); }
function loadFile(file) {
  if (!file) return;
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (!['pdf','png','jpg','jpeg','webp','gp3','gp4','gp5'].includes(ext)) return showError('Chỉ hỗ trợ PDF, PNG, JPG, WebP và GP3/GP4/GP5.');
  if (file.size > FILE_MAX) return showError('File lớn hơn 35 MB, vui lòng chọn file nhỏ hơn.');
  clearError(); stopPlayer();
  state.file = file; state.jobId = null; state.response = null; state.demo = false;
  state.inspection=null; state.sourceId=null; state.sourcePage=1;state.overlayMode=false;state.loadSequence++;
  $('showVectorOverlay').checked=false;$('sourceAudit').classList.add('hidden');$('vectorSourceSummary').classList.add('hidden');
  $('pageRangeInput').value='';$('pageRangeRow').classList.toggle('hidden',ext!=='pdf');
  if(window.TunerAlpha)TunerAlpha.nativeOnly('Chưa nhận diện bản nhạc mới.');
  $('fileName').textContent = file.name;
  if(['png','jpg','jpeg','webp'].includes(ext)) $('conversionMode').value='engine';
  else $('conversionMode').value='auto';
  updateModeOptions();
  $('fileSize').textContent = (file.size/1024/1024).toFixed(2)+' MB';
  $('selectedFile').classList.remove('hidden');
  $('convertBtn').disabled = false;
  setSource(file);
  resetScore();
  if(['pdf','png','jpg','jpeg','webp'].includes(ext))inspectFile(file,state.loadSequence);
}
function setSource(file) {
  if (state.blobURL) URL.revokeObjectURL(state.blobURL);
  state.blobURL = URL.createObjectURL(file);
  $('emptySource').classList.add('hidden'); $('pdfViewer').classList.add('hidden'); $('imgViewer').classList.add('hidden');
  const ext = file.name.split('.').pop().toLowerCase();
  if (ext === 'pdf') { $('pdfViewer').src = state.blobURL+'#page='+state.sourcePage; $('pdfViewer').classList.remove('hidden'); }
  else if (['png','jpg','jpeg','webp'].includes(ext)) { $('imgViewer').src = state.blobURL; $('imgViewer').classList.remove('hidden'); }
  else { $('emptySource').classList.remove('hidden'); $('emptySource').querySelector('h3').textContent = 'Đầu vào Guitar Pro không có ảnh/PDF gốc'; }
  updateSourceView();
}
function resetScore() {
  $('reviewZipBtn').disabled = true; $('reviewSummary').textContent='Chua co ket qua; hay chuyen file truoc.'; $('reviewFlags').classList.add('hidden');
  $('emptyScore').classList.remove('hidden'); $('scoreContent').classList.add('hidden');
  $('report').classList.add('hidden'); $('trackPicker').innerHTML='';
  for(const el of ['gp5Btn','gp4Btn','gp3Btn','downloadAllBtn','playBtn','stopBtn','prevBtn','playBpm','speedSelect','positionSlider']) $(el).disabled = true;
  $('currentTime').textContent='00:00'; $('totalTime').textContent='00:00'; $('positionSlider').value=0;
}
function showError(message) { $('errorBox').textContent = message; $('errorBox').classList.remove('hidden'); }
function clearError() { $('errorBox').textContent=''; $('errorBox').classList.add('hidden'); }
function switchTab(which) {
  for(const tab of document.querySelectorAll('.tab')) tab.classList.toggle('active',tab.dataset.tab===which);
  const compare=which==='tabCompare';
  document.querySelector('.workspace').classList.toggle('compare-mode',compare);
  document.querySelector('.center-panel').classList.toggle('compare-mode',compare);
  for(const view of document.querySelectorAll('.tab-view'))
    view.classList.toggle('hidden',!compare && view.id!==which);
  if(compare && state.response && window.TunerAlpha){try{TunerAlpha.setZoom(state.scoreZoom)}catch(e){}}
}
async function inspectFile(file,sequence) {
  $('sourceAudit').classList.remove('hidden');$('auditStatus').textContent='Đang đọc dữ liệu gốc...';
  $('auditMetrics').innerHTML='';$('auditDetails').textContent='';
  const form=new FormData();form.append('file',file);
  try {
    const r=await fetch('/api/inspect',{method:'POST',body:form});const result=await r.json();
    if(!r.ok)throw Error(result.detail||'Không thể phân tích nguồn.');
    if(sequence!==state.loadSequence)return;
    state.inspection=result;state.sourceId=result.id;
    const format=result.format==='pdf'?'PDF':'Ảnh';
    $('auditStatus').textContent='Đã đọc '+format+' · '+result.pages+' trang';
    $('auditMetrics').innerHTML=`<div><b>${result.pages}</b><span>Trang</span></div><div><b>${result.staff_groups}</b><span>Nhóm khuông 5</span></div><div><b>${result.tab_groups}</b><span>Nhóm TAB (ước lượng)</span></div><div><b>${result.fret_candidates}</b><span>Chữ số ứng viên</span></div>`;
    const items=result.items.map(i=>`Trang ${i.page}: ${i.tab_groups} vùng TAB · ${i.staff_groups} khuông · ${i.fret_candidates} số ngăn`).join(' | ');
    $('auditDetails').textContent=items;
    const vector=result.vector_summary;
    if(vector?.available){
      $('vectorSourceSummary').classList.remove('hidden');
      $('vectorSourceSummary').innerHTML=`<strong>Trích xuất vector thử nghiệm – trang 1</strong><p>${vector.bars_first_page} ô · ${vector.frets_first_page} chữ số TAB · ${vector.aligned_staff_columns}/${vector.columns} vị trí cột gần ký hiệu nốt trên khuông.</p><p class="fine-print">Đây là đối chiếu vị trí đồ họa, KHÔNG xác minh trường độ, cao độ, nhịp hoặc kỹ thuật guitar.</p>`;
    }else{
      $('vectorSourceSummary').classList.add('hidden');
    }
    $('sourcePageSelect').innerHTML=result.items.map(i=>`<option value="${i.page}">Trang ${i.page}</option>`).join('');
    $('sourcePageSelect').value=String(state.sourcePage);
    $('runOrpheusBtn').disabled=!state.orpheusAvailable;
    $('researchInfo').textContent=state.orpheusAvailable?'Orpheus đã cài để thử layout. Chỉ hiển thị bản đồ phân vùng, KHÔNG xuất nốt.':'Có thể cài Orpheus do bạn tự cung cấp để nghiên cứu layout; không đóng gói mô hình vào web.';
    updateSourceView();
  } catch(e){if(sequence!==state.loadSequence)return;$('auditStatus').textContent='Không đọc được nguồn';$('auditDetails').textContent=e.message;}
}
function updateSourceView() {
  const file=state.file;
  if(!file)return;
  $('sourcePageTitle').textContent='Bản gốc · trang '+state.sourcePage;
  $('sourcePageSelect').value=String(state.sourcePage);
  const ext=(file.name.split('.').pop()||'').toLowerCase();
  const hasPreview=!!state.sourceId && state.sourcePage <= Number(state.inspection?.preview_limit||0);
  $('vectorPreview').classList.add('hidden');
  $('pdfViewer').classList.add('hidden');$('imgViewer').classList.add('hidden');
  if(state.overlayMode && hasPreview){
    const key=state.sourceId;
    $('vectorPreview').src=`/api/source-preview/${encodeURIComponent(key)}/${state.sourcePage}?overlay=1`;
    $('vectorPreview').classList.remove('hidden');return;
  }
  if(ext==='pdf'){$('pdfViewer').src=state.blobURL+'#page='+state.sourcePage;$('pdfViewer').classList.remove('hidden');}
  else if(['png','jpg','jpeg','webp'].includes(ext)){$('imgViewer').classList.remove('hidden');}
}
async function showOrpheusLayout(){
  if(!state.sourceId)return;
  const b=$('runOrpheusBtn');b.disabled=true;
  $('researchInfo').textContent='Đang chạy ONNX layout cục bộ...';
  try{
    const r=await fetch(`/api/orpheus-layout/${state.sourceId}/${state.sourcePage}`,{method:'POST'});
    const result=await r.json();if(!r.ok)throw Error(result.detail||`Lỗi ${r.status}`);
    $('vectorPreview').src=result.preview_url+'?t='+Date.now();
    $('vectorPreview').classList.remove('hidden');$('pdfViewer').classList.add('hidden');$('imgViewer').classList.add('hidden');
    $('researchInfo').textContent=`Orpheus layout: ${result.inference_ms} ms · ${result.background_pct}% nền · lớp ${JSON.stringify(result.classes)}. KHÔNG PHẢI nhận diện nốt.`;
    switchTab('tabSource');
  }catch(e){$('researchInfo').textContent='Chưa chạy được mô hình Orpheus: '+e.message;}
  finally{b.disabled=!state.orpheusAvailable;}
}

async function convert() {
  if (!state.file) return;
  clearError(); stopPlayer();
  $('convertBtn').disabled=true;
  $('processing').classList.remove('hidden');
  $('processingTitle').textContent='Đang nhận diện TAB và tạo file Guitar Pro…';
  const form = new FormData(); form.append('file', state.file);
  const bpm = $('bpmInput').value.trim(); if(bpm) form.append('bpm',bpm);
  const pages=$('pageRangeInput').value.trim();if(pages)form.append('pages',pages);
  if(state.sourceId)form.append('source_id',state.sourceId);
  form.append('mode',$('conversionMode').value);
  form.append('time_sig',$('timeSigSelect').value);
  try {
    const reply = await fetch('/api/convert',{method:'POST',body:form});
    const body = await reply.json();
    if(!reply.ok) throw Error(typeof body.detail==='string'?body.detail:`Lỗi HTTP ${reply.status}`);
    state.jobId=body.id; state.demo=false; displayResult(body);
    switchTab(state.sourceId?'tabCompare':'tabScore');
  } catch(err) { showError(err.message||String(err)); }
  finally { $('processing').classList.add('hidden'); $('convertBtn').disabled=false; }
}
function displayResult(result) {
  stopPlayer();state.response=result; state.track=0;state.positionQ=0;
  const score=result.score;
  $('emptyScore').classList.add('hidden'); $('scoreContent').classList.remove('hidden');
  $('songTitle').textContent=score.title||state.file?.name||'Bản nhạc';
  $('songMeta').textContent=`${score.total_measures} ô nhịp · ${score.total_notes} nốt · ${score.tracks.length} track`;
  $('scoreStatus').textContent=state.demo?'DEMO ÂM THANH':result.recognition_mode==='vector_draft'?'GP NHÁP · NHỊP ƯỚC LƯỢNG':result.recognition_mode==='ocr_engine'?'OCR/OMR · CHƯA ĐỐI CHIẾU':'CHƯA ĐỐI CHIẾU';
  $('trackPicker').innerHTML=score.tracks.map((t,i)=>`<option value="${i}">${esc(t.name||'Guitar')} (${t.strings} dây)</option>`).join('');
  $('trackPicker').value='0'; $('playBpm').value=score.tempo||100;
  for(const id of ['playBtn','stopBtn','prevBtn','playBpm','speedSelect','positionSlider']) $(id).disabled=false;
  for(const fmt of ['gp5','gp4','gp3']) $(fmt+'Btn').disabled=!result.formats?.includes(fmt);
  $('downloadAllBtn').disabled=!result.formats?.length;
  $('reviewZipBtn').disabled=!!state.demo || !state.jobId;
  const audit=result.label_audit;
  if(audit && result.recognition_mode==='vector_draft'){
    $('reviewSummary').textContent=`GP nhap: ${result.score.total_measures} o nhip; ${audit.printed_measure_label_count} so thu tu PDF tim duoc; ${audit.unresolved_count} so chua ghep dang tin cay. TAT CA truong do van la UOC LUONG.`;
    const flags=(audit.overprinted_systems||[]).map(x=>`Trang ${x.page}, he ${x.system}: ${x.lanes.map(y=>y.join('-')).join(' / ')}`);
    const d=result.draft_summary||{};
    $('reviewSummary').textContent+=` V6: phat hien them ${d.new_fret_candidates_found||0} so ngan ung vien khi can chinh dong TAB; co ${d.alignment_review_systems||0} he can kiem tra thu cong. Xem alignment_audit.csv trong ZIP.`;
    $('reviewFlags').textContent=flags.length?`Can kiem tra nhung vung trung so o nhip: ${flags.join(' | ')}`:'Chua phat hien nhieu day so o nhip chong nhau trong trang da chon.';
    $('reviewFlags').classList.remove('hidden');
  }else{
    $('reviewSummary').textContent='Goi gom file GP xuat, MIDI, file nguon (neu chon), thong so note CSV/JSON va anh nguon PDF. OCR/OMR van can kiem chung.';
    $('reviewFlags').classList.add('hidden');
  }
  const out=score.total_measures;
  $('stats').innerHTML=`<div><strong>${out}</strong><span>Ô nhịp</span></div><div><strong>${score.total_notes}</strong><span>Nốt ghi nhận</span></div><div><strong>${score.tracks.length}</strong><span>Track</span></div><div><strong>${score.tempo}</strong><span>BPM gốc</span></div>`;
  const warnings=[];
  if(state.demo) warnings.push('Bản nhạc demo chỉ dùng để thử phát âm thanh; không có file GP xuất được.');
  else if(result.recognition_mode==='vector_draft'){
    warnings.push('GP NHÁP TỪ PDF VECTOR: số dây/ngăn được đọc trực tiếp, nhưng thời lượng nốt do chương trình suy luận từ khoảng cách ngang, có thể khác bản gốc.');
    const d=result.draft_summary;
    if(d){
      warnings.push(`Kiểm tra nguồn: ${d.total_notes} số ngăn trong ${score.total_measures} ô nhịp nháp; ${d.staff_aligned_columns}/${d.all_columns} cột gần ký hiệu notehead trên khuông. Đây không phải xác minh cao độ.`);
      if(d.new_fret_candidates_found)warnings.push(`V6: da tim them ${d.new_fret_candidates_found} so ngan ung vien nho can chinh 6 day TAB; chua xac minh do chinh xac.`);
      if(d.alignment_review_systems)warnings.push(`${d.alignment_review_systems} he TAB bi chong duong hoac chua can chinh chac chan, xem alignment_audit.csv trong ZIP.`);
      if(d.unmapped_frets)warnings.push(`CẢNH BÁO: ${d.unmapped_frets} số ngăn không đưa được vào bản GP nháp. Hãy kiểm tra với PDF gốc.`);
      if(d.uncertain_bars)warnings.push(`${d.uncertain_bars} ô nhịp có khoảng cách nốt khó xác định trường độ.`);
      for(const item of (d.problems||[]).slice(0,10))warnings.push(item);
    }
  } else warnings.push('Kết quả OCR/OMR là bản nháp; cần đối chiếu từng ô nhịp với PDF/ảnh gốc.');
  if(result.source_audit){
    const a=result.source_audit;
    warnings.push(`Kiểm tra PDF vector: ${a.staff_groups} nhóm khuông; ${a.tab_groups} nhóm TAB; ${a.fret_candidates} chữ số ứng viên. Đây là gợi ý kiểm tra, không phải kết quả OMR.`);
    if(a.possible_omissions)warnings.push(`CẢNH BÁO BỎ SÓT: ${a.selected_fret_candidates} chữ số TAB ứng viên ở trang được chọn nhưng chỉ ${a.gp_note_count} nốt trong GP. Chênh lệch có thể do OCR sai, nhiều bè hoặc kiểm tra nguồn ước lượng. Hãy đối chiếu từng ô.`);
  }
  if(result.selected_pages?.length)warnings.push('Bản GP chỉ nhận diện từ các trang đã chọn: '+result.selected_pages.join(', '));
  for(const w of (result.warnings||[]).slice(0,12)) warnings.push(w);
  for(const [fmt,w] of Object.entries(result.export_warnings||{})) warnings.push(`${fmt.toUpperCase()}: ${w}`);
  $('warnings').innerHTML=warnings.map(w=>`<div>⚠ ${esc(w)}</div>`).join('');
  $('report').classList.remove('hidden');
  renderTrack();
}
function midiLabel(midi) { const names=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];return names[((midi%12)+12)%12]; }
function renderTrack() {
  stopPlayer();
  const score=state.response?.score;if (!score) return;
  const track=score.tracks[state.track];if(!track) return;
  state.events=[]; state.maxQ=track.duration_quarters||0;
  for(const measure of track.measures){
    for(const beat of measure.beats){
      for(const n of beat.notes){
        state.events.push({at:measure.start+beat.position,length:beat.length,pitch:n.pitch,
          velocity:n.velocity,measure:measure.index,string:n.string,fret:n.fret,
          key:`${state.track}:${measure.index}:${beat.voice}:${beat.beat}:${n.note}`});
      }
    }
  }
  state.events.sort((a,b)=>a.at-b.at);
  state.positionQ=0;
  renderNotation();
  if(window.TunerAlpha)TunerAlpha.load(state.jobId,state.track,
    {mode:state.scoreMode,zoom:state.scoreZoom},
    {onMode:(professional)=>{
      if(professional){$('audioModeInfo').textContent='alphaTab hiển thị khuông nhạc và TAB. Nếu bộ phát SoundFont sẵn sàng, âm thanh và con trỏ trên khuông sẽ chạy đồng bộ.';}
    },
    onPlayerReady:()=>{$('audioModeInfo').textContent='Âm thanh SoundFont và con trỏ alphaTab sẵn sàng; GP5 vẫn là nguồn dữ liệu duy nhất.';},
    onPosition:(e)=>{
      if(state.playEngine!=='alpha')return;
      const denom=Number(e.endTick)||1;
      state.positionQ=Math.max(0,Math.min(state.maxQ,(Number(e.currentTick)||0)/denom*state.maxQ));
      syncTime();highlight(state.positionQ);
    },
    onFinished:()=>{if(state.playEngine==='alpha'){state.isPlaying=false;stopPlayer(true);}}
    });
  syncTime();
}
function renderNotation(){
  const score=state.response?.score;if(!score)return;
  const native=window.TunerNativeNotation;
  if(native){
    native.render($('tabNotation'),score,state.track,state.scoreMode,state.scoreZoom);
    // Keep an editable tablature copy when alphaTab provides professional engraving.
    native.render($('editTabNotation'),score,state.track,'tabs',Math.min(1,state.scoreZoom));
  }else{
    $('tabNotation').textContent='Không thể nạp trình hiển thị khuông nhạc SVG.';
  }
  highlight(state.positionQ);
}
function setScoreMode(mode){
  if(!['both','score','tabs'].includes(mode))return;
  state.scoreMode=mode;
  for(const b of document.querySelectorAll('.notation-mode')){
    const selected=b.dataset.mode===mode;
    b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));
  }
  renderNotation();
  if(window.TunerAlpha)TunerAlpha.setMode(mode);
}
function setScoreZoom(zoom){
  const value=Number(zoom)||1;
  state.scoreZoom=Math.max(0.75,Math.min(1.5,value));
  renderNotation();if(window.TunerAlpha)TunerAlpha.setZoom(state.scoreZoom);
}
function tone(ctx, pitch, at, len, velocity) {
  // Lightweight sound to preview the note contour, not a Guitar Pro/SoundFont renderer.
  const hz=440*Math.pow(2,(pitch-69)/12);
  const gain=ctx.createGain();
  gain.gain.setValueAtTime(0.0001,at);
  gain.gain.exponentialRampToValueAtTime(Math.min(.13,.08*(velocity||95)/95)+.0001,at+.012);
  gain.gain.exponentialRampToValueAtTime(0.0001,at+Math.min(Math.max(.14,len),2.7));
  gain.connect(ctx.destination);
  for(const [type,mul,level] of [['triangle',1,.8],['sine',2,.18]]) {
    const osc=ctx.createOscillator();osc.type=type;osc.frequency.setValueAtTime(hz*mul,at);
    const g=ctx.createGain();g.gain.value=level;osc.connect(g);g.connect(gain);
    osc.start(at);osc.stop(at+Math.min(Math.max(.14,len),2.7)+.04);
  }
}
function currentQuarter() {
  if (state.playEngine==='alpha') return state.positionQ;
  if (!state.isPlaying || !state.audio) return state.positionQ;
  return Math.min(state.maxQ,state.startQ+(state.audio.currentTime-state.startAt)/secPerQuarter());
}
function syncTime() {
  const max=state.maxQ||0;
  const sec=secPerQuarter();
  let currentSec=state.positionQ*sec, totalSec=max*sec;
  if(state.playEngine==='alpha' && window.TunerAlpha){
    const alphaTime=TunerAlpha.time();
    if(alphaTime && alphaTime.endMs>0){currentSec=alphaTime.timeMs/1000;totalSec=alphaTime.endMs/1000;}
  }
  $('currentTime').textContent=fmtTime(currentSec);
  $('totalTime').textContent=fmtTime(totalSec);
  $('positionSlider').value=max?Math.floor(1000*state.positionQ/max):0;
}
function clearHighlights() {
  document.querySelectorAll('.bar-score.playing').forEach(el=>el.classList.remove('playing'));
  document.querySelectorAll('.fret-note.active,.staff-note.active').forEach(el=>el.classList.remove('active'));
}
function highlight(q) {
  if (!state.events.length) return;
  const tr=state.response.score.tracks[state.track];
  const measure=tr.measures.find(m=>q>=m.start && q<m.start+m.length) || tr.measures.at(-1);
  if(!measure) return;
  const bars=[...document.querySelectorAll(`.bar-score[data-measure="${measure.index}"]`)];
  if(!bars.length) return;
  if(state.activeNote!==measure.index){
    clearHighlights();state.activeNote=measure.index;
    if (state.isPlaying && !window.TunerAlpha?.isReady()) bars[0].scrollIntoView({block:'nearest',behavior:'smooth'});
  }
  for(const bar of bars){
    bar.classList.add('playing');
    for(const el of bar.querySelectorAll('.fret-note,.staff-note')){
      const at=Number(el.dataset.start);
      el.classList.toggle('active',q>=at && q<at+Math.max(.08,Number(el.dataset.length)||.25));
    }
  }
}
function tick() {
  if(!state.isPlaying || state.playEngine==='alpha' || !state.audio)return;
  const now=state.audio.currentTime;
  state.positionQ=currentQuarter();
  const ahead=now+.2;
  while(state.nextEvent<state.events.length){
    const ev=state.events[state.nextEvent];
    const when=state.startAt+(ev.at-state.startQ)*secPerQuarter();
    if(when>ahead) break;
    if(when>=now-.1) tone(state.audio,ev.pitch,Math.max(when,now+.002),ev.length*secPerQuarter(),ev.velocity);
    state.nextEvent++;
  }
  highlight(state.positionQ);syncTime();
  if(state.positionQ>=state.maxQ-.005) stopPlayer(true);
}
async function playPlayer() {
  if(!state.response)return;
  if(state.isPlaying) return pausePlayer();
  if(!state.demo && state.jobId && window.TunerAlpha?.canPlay()){
    TunerAlpha.speed((getBpm()/(Number(state.response?.score?.tempo)||100))*getSpeed());
    if(state.positionQ>=state.maxQ)state.positionQ=0;
    TunerAlpha.seek(state.maxQ?state.positionQ/state.maxQ:0);
    if(TunerAlpha.play()){
      state.playEngine='alpha';state.isPlaying=true;
      $('playBtn').textContent='Ⅱ';$('playBtn').ariaLabel='Tạm dừng';
      syncTime();return;
    }
  }
  state.playEngine='web';
  try {
    if(!state.audio) state.audio=new(window.AudioContext||window.webkitAudioContext)();
    await state.audio.resume();
  }catch(e){return showError('Không mở được WebAudio: '+e.message);}
  if(state.positionQ>=state.maxQ)state.positionQ=0;
  state.startQ=state.positionQ;state.startAt=state.audio.currentTime+.06;
  state.nextEvent=state.events.findIndex(e=>e.at>=state.startQ-.0001);
  if(state.nextEvent<0)state.nextEvent=state.events.length;
  state.isPlaying=true;$('playBtn').textContent='Ⅱ';$('playBtn').ariaLabel='Tạm dừng';
  state.interval=setInterval(tick,35);tick();
}
function pausePlayer() {
  if(state.isPlaying)state.positionQ=currentQuarter();
  if(state.playEngine==='alpha' && window.TunerAlpha)TunerAlpha.pause();
  state.isPlaying=false;
  if(state.interval)clearInterval(state.interval);
  state.interval=null;$('playBtn').textContent='▶';$('playBtn').ariaLabel='Phát bản nhạc';syncTime();
}
function stopPlayer(end=false) {
  pausePlayer();
  if(window.TunerAlpha)TunerAlpha.stop();
  state.playEngine='web';state.positionQ=end?state.maxQ:0;
  state.activeNote=null;clearHighlights();syncTime();
}
function seekQuarter(q) {
  const playing=state.isPlaying;
  const wasAlpha=state.playEngine==='alpha';
  pausePlayer();state.positionQ=Math.max(0,Math.min(state.maxQ,q));
  if(window.TunerAlpha?.canPlay() && (wasAlpha || (!playing && state.jobId))){
    TunerAlpha.seek(state.maxQ?state.positionQ/state.maxQ:0);
  }
  syncTime();highlight(state.positionQ);
  if(playing)playPlayer();
}
function triggerDownload(fmt){
  if(!state.jobId)return;
  const url=fmt==='review'?`/api/review-package/${state.jobId}?include_source=${$('includeSource').checked?1:0}`:fmt==='zip'?`/api/download-all/${state.jobId}`:`/api/download/${state.jobId}/${fmt}`;
  const a=document.createElement('a');a.href=url;a.download='';document.body.appendChild(a);a.click();a.remove();
}
function openEdit(button) {
  if(state.demo) return showError('Bản demo chỉ dùng thử khuông nhạc và âm thanh, không lưu các nốt. Hãy chọn PDF/ảnh thật.');
  const d=button.dataset;
  state.editing={track:Number(d.track),measure:Number(d.measure),voice:Number(d.voice),beat:Number(d.beat),note:Number(d.note)};
  $('editContext').textContent=`Ô ${state.editing.measure+1} · dây ${d.string} · ngăn hiện tại ${d.fret}`;
  $('editFret').value=d.fret;$('editString').value=d.string;$('editError').classList.add('hidden');$('editDialog').showModal();
}
async function saveEdit(e) {
  e.preventDefault();
  if(!state.editing||!state.jobId)return;
  const fret=Number($('editFret').value);
  const string=Number($('editString').value);
  if(!Number.isInteger(fret)||fret<0||fret>36||!Number.isInteger(string)||string<1||string>8)return;
  $('saveEdit').disabled=true;
  try{
    const r=await fetch(`/api/edit/${state.jobId}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...state.editing,fret,string})});
    const payload=await r.json();
    if(!r.ok)throw Error(payload.detail||`Lỗi ${r.status}`);
    const selectedTrack=state.track;
    displayResult(payload);state.track=selectedTrack;$('trackPicker').value=String(selectedTrack);renderTrack();
    $('editDialog').close();
  }catch(err){$('editError').textContent=err.message;$('editError').classList.remove('hidden');}
  finally{$('saveEdit').disabled=false;}
}
function updateModeOptions(){
  const mode=$('conversionMode').value;
  const ext=state.file?.name?.split('.').pop()?.toLowerCase()||'';
  $('timeSigRow').classList.toggle('muted-field',mode==='engine');
  $('modeCaution').innerHTML=(mode==='engine')
    ?'OCR/OMR dựa vào engine mã nguồn mở cài riêng. Với ảnh scan, kết quả có thể sai nốt, dây và trường độ; cần chỉnh sửa.'
    :((ext==='png'||ext==='jpg'||ext==='jpeg'||ext==='webp')
       ?'Ảnh không có dữ liệu TAB vector. Hãy chọn chế độ OCR/OMR và cài engine bổ sung nếu cần.'
       :'PDF vector: đọc số ngăn theo dòng TAB, sau đó <strong>ước lượng</strong> trường độ. Hãy kiểm tra bản GP trước khi sử dụng.');
}
function loadDemo(){
  clearError();stopPlayer();state.jobId=null;state.demo=true;
  const melody=[0,2,3,0,3,5,7,5,3,2,0,2,3,0,2,0];
  const bars=[];for(let m=0;m<4;m++){
    bars.push({index:m,number:m+1,start:m*4,length:4,time:'4/4',beats:melody.slice(m*4,m*4+4).map((f,i)=>({voice:0,beat:i,position:i,length:1,duration:4,dotted:false,notes:[{note:0,string:1,fret:f,pitch:64+f,velocity:95}]}))});
  }
  displayResult({id:null,formats:[],warnings:[],export_warnings:{},score:{title:'Guitar demo – 4 ô nhịp',tempo:100,artist:'',total_notes:16,total_measures:4,tracks:[{index:0,name:'Guitar Demo',strings:6,clef:'treble',notation_transposition:12,tuning:{1:64,2:59,3:55,4:50,5:45,6:40},measures:bars,duration_quarters:16}]}});
  switchTab('tabScore');
}
async function checkServer() {
  try{
    const r=await fetch('/api/health');const data=await r.json();
    const el=$('engineStatus');
    state.orpheusAvailable=!!data.orpheus_research;
    if(state.sourceId)$('runOrpheusBtn').disabled=!state.orpheusAvailable;
    if(data.guitarpro){
      el.textContent=data.engine?'● TAB vector + OCR/OMR sẵn sàng':'● TAB vector sẵn sàng · OCR/OMR chưa cài';el.className='server-state ok';
    }else{el.textContent='● Chưa cài thư viện Guitar Pro (PyGuitarPro)';el.className='server-state bad';}
  }catch(e){const el=$('engineStatus');el.textContent='● Mất kết nối máy chủ cục bộ';el.className='server-state bad';}
}

$('dropzone').addEventListener('click',()=> $('fileInput').click());
$('dropzone').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('fileInput').click();}});
$('fileInput').addEventListener('change',e=>loadFile(e.target.files?.[0]));
for(const evt of ['dragenter','dragover'])$('dropzone').addEventListener(evt,e=>{e.preventDefault();$('dropzone').classList.add('drag')});
for(const evt of ['dragleave','drop'])$('dropzone').addEventListener(evt,e=>{e.preventDefault();$('dropzone').classList.remove('drag')});
$('dropzone').addEventListener('drop',e=>loadFile(e.dataTransfer.files?.[0]));
$('clearFile').addEventListener('click',()=>{state.loadSequence++;state.sourceId=null;state.inspection=null;$('sourceAudit').classList.add('hidden');$('vectorPreview').classList.add('hidden');state.file=null;$('fileInput').value='';$('selectedFile').classList.add('hidden');$('convertBtn').disabled=true;resetScore();stopPlayer();if(state.blobURL)URL.revokeObjectURL(state.blobURL);$('emptySource').classList.remove('hidden');$('pdfViewer').classList.add('hidden');$('imgViewer').classList.add('hidden');});
$('convertBtn').addEventListener('click',convert);
$('demoBtn').addEventListener('click',loadDemo);
$('conversionMode').addEventListener('change',updateModeOptions);
$('sourcePageSelect').addEventListener('change',e=>{state.sourcePage=Number(e.target.value)||1;updateSourceView();});
$('showVectorOverlay').addEventListener('change',e=>{state.overlayMode=e.target.checked;updateSourceView();});
$('auditOverlayBtn').addEventListener('click',()=>{state.overlayMode=true;$('showVectorOverlay').checked=true;updateSourceView();switchTab('tabSource');});
$('runOrpheusBtn').addEventListener('click',showOrpheusLayout);
$('navPreview').addEventListener('click',()=>switchTab('tabScore'));
for(const b of document.querySelectorAll('.tab'))b.addEventListener('click',()=>switchTab(b.dataset.tab));
$('trackPicker').addEventListener('change',e=>{state.track=Number(e.target.value)||0;renderTrack()});
for(const id of ['tabNotation','editTabNotation']){
  $(id).addEventListener('click',e=>{const b=e.target.closest('.fret-note');if(b)openEdit(b)});
  $(id).addEventListener('keydown',e=>{const b=e.target.closest('.fret-note');if(b&&(e.key==='Enter'||e.key===' ')){e.preventDefault();openEdit(b)}});
}
for(const modeBtn of document.querySelectorAll('.notation-mode'))modeBtn.addEventListener('click',()=>setScoreMode(modeBtn.dataset.mode));
$('notationZoom').addEventListener('change',e=>setScoreZoom(e.target.value));
$('printScoreBtn').addEventListener('click',()=>{if(!state.response)return showError('Chưa có bản nhạc để in.');window.print();});
$('playBtn').addEventListener('click',playPlayer);
$('stopBtn').addEventListener('click',()=>stopPlayer(false));
$('prevBtn').addEventListener('click',()=>seekQuarter(0));
$('positionSlider').addEventListener('input',e=>{if(state.maxQ)seekQuarter(Number(e.target.value)/1000*state.maxQ)});
$('playBpm').addEventListener('change',()=>{if(state.isPlaying){const current=currentQuarter();pausePlayer();state.positionQ=current;playPlayer();}else syncTime()});
$('speedSelect').addEventListener('change',()=>{if(state.isPlaying){const current=currentQuarter();pausePlayer();state.positionQ=current;playPlayer();}else syncTime()});
for(const fmt of ['gp5','gp4','gp3'])$(fmt+'Btn').addEventListener('click',()=>triggerDownload(fmt));
$('downloadAllBtn').addEventListener('click',()=>triggerDownload('zip'));
$('reviewZipBtn').addEventListener('click',()=>triggerDownload('review'));
$('editForm').addEventListener('submit',saveEdit);
$('cancelEdit').addEventListener('click',()=>$('editDialog').close());
checkServer();
