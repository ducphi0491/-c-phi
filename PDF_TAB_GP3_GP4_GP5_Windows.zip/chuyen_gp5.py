#!/usr/bin/env python3
"""Convert a user-provided GP5 file to GP3 and GP4 with verification.

Does not recognize PDF/images; use a separate OMR/TAB recognizer to create GP5 first.
"""
import argparse
import json
from pathlib import Path
import shutil
import sys
import traceback


def describe(song):
    tracks = []
    total_measures = 0
    total_beats = 0
    total_notes = 0
    note_signature = []
    for ti, track in enumerate(song.tracks):
        measure_count = len(track.measures)
        total_measures += measure_count
        this_beats = 0
        this_notes = 0
        for mi, measure in enumerate(track.measures):
            for vi, voice in enumerate(measure.voices):
                for bi, beat in enumerate(voice.beats):
                    this_beats += 1
                    notes = []
                    for note in beat.notes:
                        this_notes += 1
                        notes.append((int(note.string), int(note.value)))
                    if notes:
                        note_signature.append((ti, mi, vi, bi, tuple(sorted(notes))))
        total_beats += this_beats
        total_notes += this_notes
        tracks.append({
            "name": str(track.name),
            "measure_count": measure_count,
            "beat_count": this_beats,
            "note_count": this_notes,
        })
    return {
        "track_count": len(song.tracks),
        "measure_count_sum_tracks": total_measures,
        "beat_count": total_beats,
        "note_count": total_notes,
        "tracks": tracks,
        "note_signature": note_signature,
    }


def brief(info):
    return {
        "track_count": info["track_count"],
        "measure_count_sum_tracks": info["measure_count_sum_tracks"],
        "beat_count": info["beat_count"],
        "note_count": info["note_count"],
        "tracks": info["tracks"],
    }


def main():
    parser = argparse.ArgumentParser(description="Convert an existing GP5 into GP3/GP4")
    parser.add_argument("source", type=Path, help="Path to an existing .gp5 file")
    parser.add_argument("--out", type=Path, default=None, help="Output directory")
    args = parser.parse_args()

    src = args.source.expanduser().resolve()
    if not src.is_file() or src.suffix.lower() != ".gp5":
        parser.error("Source file must exist and have .gp5 extension")

    out = (args.out or src.parent / (src.stem + "_GP_EXPORT")).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    try:
        import guitarpro
    except ImportError:
        sys.exit("Missing PyGuitarPro: python -m pip install PyGuitarPro")

    try:
        song = guitarpro.parse(str(src))
    except Exception as e:
        sys.exit(f"Cannot read input GP5: {type(e).__name__}: {e}")

    expected = describe(song)
    print(f"INPUT: {src}")
    print(f"Tracks: {expected['track_count']}; measures (sum per track): {expected['measure_count_sum_tracks']}; notes: {expected['note_count']}")
    report = {
        "source": str(src),
        "source_summary": brief(expected),
        "warning": "This is only GP-format conversion; PDF/image recognition must be done separately. Older formats may lose unsupported articulations.",
        "outputs": {},
    }
    results = 0
    for fmt in ("gp5", "gp4", "gp3"):
        dest = out / (src.stem + "." + fmt)
        rec = {"file": str(dest), "format": fmt}
        try:
            if fmt == "gp5":
                shutil.copy2(src, dest)
            else:
                guitarpro.write(song, str(dest))
            if not dest.is_file() or dest.stat().st_size <= 0:
                raise RuntimeError("Empty or missing output")
            test_song = guitarpro.parse(str(dest))
            actual = describe(test_song)
            rec["summary"] = brief(actual)
            rec["bytes"] = dest.stat().st_size
            rec["track_count_matches"] = actual["track_count"] == expected["track_count"]
            rec["note_count_matches"] = actual["note_count"] == expected["note_count"]
            rec["exact_string_fret_signature_matches"] = actual["note_signature"] == expected["note_signature"]
            rec["status"] = "PASS" if (rec["track_count_matches"] and rec["note_count_matches"] and rec["exact_string_fret_signature_matches"]) else "REVIEW_REQUIRED"
            results += 1
            print(f"[{rec['status']}] {fmt.upper()}: {dest.name}, {rec['bytes']} bytes, {actual['note_count']} notes")
            if rec["status"] == "REVIEW_REQUIRED":
                print("  WARN: Notes, tracks, or string/fret placements differ; compare in editor before using")
        except Exception as e:
            rec["status"] = "FAILED"
            rec["error"] = f"{type(e).__name__}: {e}"
            print(f"[FAILED] {fmt.upper()}: {rec['error']}")
            if dest.exists() and dest.suffix != ".gp5":
                try:
                    dest.unlink()
                except OSError:
                    pass
        report["outputs"][fmt] = rec

    dest_report = out / "bao_cao_chuyen_gp.json"
    dest_report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"REPORT: {dest_report}")
    print("NEXT: Open the exported files in TuxGuitar and compare rhythm, techniques and sound against source PDF.")
    return 0 if results else 1


if __name__ == "__main__":
    sys.exit(main())
