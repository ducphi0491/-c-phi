param(
    [string]$Gp5File = ""
)

# This script converts an EXISTING GP5 file to GP3/GP4/GP5.
# It does NOT automatically recognize PDF/PNG/JPG images.
$ErrorActionPreference = 'Continue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root

if (-not $Gp5File) {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = "Choose a Guitar Pro 5 file converted from your PDF or image"
    $dlg.Filter = "Guitar Pro 5 (*.gp5)|*.gp5"
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host "No GP5 file selected."
        exit 0
    }
    $Gp5File = $dlg.FileName
}

if (-not (Test-Path -LiteralPath $Gp5File -PathType Leaf)) {
    Write-Error "Input GP5 not found: $Gp5File"
    exit 1
}

$Venv = Join-Path $Root '.venv_gp'
$VenvPython = Join-Path $Venv 'Scripts\python.exe'

if (-not (Test-Path -LiteralPath $VenvPython)) {
    Write-Host "Creating a private Python environment ..."
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 -m venv $Venv
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python -m venv $Venv
    } else {
        Write-Error "Python 3 is not installed. Install Python 3.11+ and rerun."
        exit 1
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to create Python environment."
        exit 1
    }
}

Write-Host "Checking PyGuitarPro ..."
& $VenvPython -m pip install --disable-pip-version-check 'PyGuitarPro>=0.10,<1'
if ($LASTEXITCODE -ne 0) {
    Write-Error "PyGuitarPro installation failed. Check network and Python version."
    exit 1
}

Write-Host "Converting and validating GP files ..."
& $VenvPython (Join-Path $Root 'chuyen_gp5.py') $Gp5File
if ($LASTEXITCODE -ne 0) {
    Write-Error "Conversion failed. See error above."
    exit 1
}
Write-Host "Finished. Check the *_GP_EXPORT folder next to your source GP5 file."
