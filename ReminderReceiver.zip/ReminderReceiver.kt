package duc_phi.music

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val channelId = "daily_music_reminder_channel"
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Nhắc nhở nghe nhạc",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val clickIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, clickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Lấy ngôn ngữ hiện hành mà người dùng đang cài đặt trong ứng dụng
        val prefs = context.getSharedPreferences("music_app_prefs", Context.MODE_PRIVATE)
        val lang = prefs.getString("app_language", "vi") ?: "vi"

        // Đa ngôn ngữ cho Tiêu đề thông báo
        val title = when (lang) {
            "en" -> "Time to relax \uD83C\uDF19"
            "zh" -> "放松时间 \uD83C\uDF19"
            "ja" -> "リラックスタイム \uD83C\uDF19"
            "ko" -> "휴식 시간 \uD83C\uDF19"
            "es" -> "Hora de relajarse \uD83C\uDF19"
            "fr" -> "Moment de détente \uD83C\uDF19"
            "de" -> "Zeit zum Entspannen \uD83C\uDF19"
            "ru" -> "Время расслабиться \uD83C\uDF19"
            "pt" -> "Hora de relaxar \uD83C\uDF19"
            "id" -> "Waktunya bersantai \uD83C\uDF19"
            "hi" -> "आराम का समय \uD83C\uDF19"
            "ar" -> "وقت الاسترخاء \uD83C\uDF19"
            "th" -> "เวลาพักผ่อน \uD83C\uDF19"
            "it" -> "Tempo di relax \uD83C\uDF19"
            else -> "Thư giãn cuối ngày \uD83C\uDF19"
        }

        // Đa ngôn ngữ cho Nội dung thông báo
        val message = when (lang) {
            "en" -> "Listening to a song will help you sleep better \uD83C\uDFB6"
            "zh" -> "听一首音乐会让您睡得更好 \uD83C\uDFB6"
            "ja" -> "音楽を聴くと、よりよく眠れるようになります \uD83C\uDFB6"
            "ko" -> "음악을 들으면 더 쉽게 잠들 수 있습니다 \uD83C\uDFB6"
            "es" -> "Escuchar música te ayudará a dormir mejor \uD83C\uDFB6"
            "fr" -> "Écouter de la musique vous aidera à mieux dormir \uD83C\uDFB6"
            "de" -> "Musik zu hören hilft Ihnen, besser zu schlafen \uD83C\uDFB6"
            "ru" -> "Прослушивание музыки поможет вам лучше уснуть \uD83C\uDFB6"
            "pt" -> "Ouvir uma música vai te ajudar a dormir melhor \uD83C\uDFB6"
            "id" -> "Mendengarkan musik akan membuat Anda lebih mudah tidur \uD83C\uDFB6"
            "hi" -> "संगीत सुनने से आपको बेहतर नींद आने में मदद मिलेगी \uD83C\uDFB6"
            "ar" -> "الاستماع إلى الموسيقى سيساعدك على النوم بشكل أفضل \uD83C\uDFB6"
            "th" -> "การฟังเพลงจะช่วยให้คุณนอนหลับได้ง่ายขึ้น \uD83C\uDFB6"
            "it" -> "Ascoltare musica ti aiuterà a dormire meglio \uD83C\uDFB6"
            else -> "Nghe 1 bản nhạc sẽ làm bạn dễ ngủ hơn \uD83C\uDFB6"
        }

        // Decode file logo thành Bitmap để làm icon lớn
        val logoBitmap = android.graphics.BitmapFactory.decodeResource(context.resources, R.drawable.logo)

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_stat_name)
            .setColor(android.graphics.Color.parseColor("#8D35FF"))
            .setLargeIcon(logoBitmap)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(message)
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)

        // Sau khi báo xong, tự động hẹn lại đúng giờ này vào ngày mai
        scheduleDailyReminder(context)
    }
}

@SuppressLint("MissingPermission")
fun scheduleDailyReminder(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    val targetHour = 21
    val targetMinute = 30 // Đã cập nhật thành 30 phút

    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, targetHour)
        set(Calendar.MINUTE, targetMinute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)

        // Nếu qua 21:30 của ngày hôm nay rồi thì hẹn sang ngày mai
        if (timeInMillis <= System.currentTimeMillis()) {
            add(Calendar.DAY_OF_YEAR, 1)
        }
    }

    val intent = Intent(context, ReminderReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(
        context,
        1220,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    try {
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            pendingIntent
        )
    } catch (e: SecurityException) {
        e.printStackTrace()
    }
}