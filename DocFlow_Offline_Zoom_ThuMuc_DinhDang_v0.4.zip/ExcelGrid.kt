package com.docflowoffline

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min

// One canvas per visible row. No 100,000 x 256 Compose TextFields or cell Views.
internal const val GRID_COLUMN_DP = 124
private const val GRID_ROW_DP = 43
private const val GRID_INDEX_DP = 50

@Composable
internal fun ExcelGrid(
    rows: Int,
    columns: Int,
    selected: String,
    cellValue: (String) -> String,
    onCellClick: (String) -> Unit,
    horizontal: ScrollState,
    vertical: LazyListState,
    zoom: Float,
    onPinchZoom: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val bg = scheme.surface
    val header = scheme.surfaceVariant
    val foreground = scheme.onSurface
    val selectedBg = scheme.primaryContainer
    val selectedFg = scheme.onPrimaryContainer
    val outline = scheme.outlineVariant
    val density = LocalDensity.current
    val scale = zoom.coerceIn(0.65f, 2.5f)
    val columnWidth = GRID_COLUMN_DP.dp * scale
    val rowHeight = GRID_ROW_DP.dp * scale
    val indexWidth = GRID_INDEX_DP.dp * scale
    val columnWidthPx = with(density) { columnWidth.toPx() }
    val rowHeightPx = with(density) { rowHeight.toPx() }
    val contentWidth = (columns * GRID_COLUMN_DP).dp * scale
    val currentClick = rememberUpdatedState(onCellClick)
    val currentPinch = rememberUpdatedState(onPinchZoom)
    val labelSize = with(density) { (13f * scale).sp.toPx() }
    val regularPaint = remember(foreground, labelSize) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = foreground.toArgb(); textSize = labelSize }
    }
    val highlightedPaint = remember(selectedFg, labelSize) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = selectedFg.toArgb(); textSize = labelSize; isFakeBoldText = true }
    }

    Column(
        modifier.background(bg, RoundedCornerShape(10.dp)).clipToBounds()
            .pointerInput(Unit) {
                // React only when at least two fingers are touching. Single-finger scrolling
                // remains owned by the horizontal ScrollState / vertical LazyColumn.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.size >= 2) {
                            val oldDistance = (pressed[0].previousPosition - pressed[1].previousPosition).getDistance()
                            val newDistance = (pressed[0].position - pressed[1].position).getDistance()
                            if (oldDistance > 2f && newDistance > 2f) {
                                val factor = (newDistance / oldDistance).coerceIn(0.8f, 1.25f)
                                if (kotlin.math.abs(factor - 1f) > 0.005f) currentPinch.value(factor)
                            }
                            pressed.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        Row(Modifier.fillMaxWidth().height(38.dp * scale)) {
            GridIndex("", true, Modifier.width(indexWidth), scale)
            BoxWithConstraints(Modifier.weight(1f).clipToBounds()) {
                val viewportWidthPx = with(density) { maxWidth.toPx() }
                Row(Modifier.horizontalScroll(horizontal)) {
                    Canvas(Modifier.width(contentWidth).fillMaxHeight()) {
                        val start = (horizontal.value / columnWidthPx).toInt().coerceIn(0, columns - 1)
                        val end = min(columns - 1, start + ceil(viewportWidthPx / columnWidthPx).toInt() + 2)
                        val canvas = drawContext.canvas.nativeCanvas
                        for (c in start..end) {
                            val x = c * columnWidthPx
                            drawRect(header, topLeft = Offset(x, 0f), size = androidx.compose.ui.geometry.Size(columnWidthPx, size.height))
                            drawLine(outline, Offset(x + columnWidthPx, 0f), Offset(x + columnWidthPx, size.height), 0.7.dp.toPx())
                            val label = OfficeOoxml.cellAddress(1, c + 1).dropLast(1)
                            val paint = regularPaint
                            val textWidth = paint.measureText(label)
                            canvas.drawText(label, x + (columnWidthPx - textWidth) / 2, size.height / 2 + labelSize / 3, paint)
                        }
                        drawLine(outline, Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), 0.7.dp.toPx())
                    }
                }
            }
        }
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), state = vertical) {
            items(count = rows, key = { it }) { zeroBased ->
                val rowNumber = zeroBased + 1
                Row(Modifier.fillMaxWidth().height(rowHeight), verticalAlignment = Alignment.CenterVertically) {
                    val selectedRow = selected.dropWhile(Char::isLetter).toIntOrNull() == rowNumber
                    GridIndex(rowNumber.toString(), selectedRow, Modifier.width(indexWidth), scale)
                    BoxWithConstraints(Modifier.weight(1f).fillMaxHeight().clipToBounds()) {
                        val viewportWidthPx = with(density) { maxWidth.toPx() }
                        Row(Modifier.horizontalScroll(horizontal)) {
                            Canvas(
                                Modifier.width(contentWidth).fillMaxHeight()
                                    .pointerInput(rowNumber, columns, columnWidthPx) {
                                        detectTapGestures { point ->
                                            val c = (floor(point.x / columnWidthPx).toInt() + 1).coerceIn(1, columns)
                                            currentClick.value(OfficeOoxml.cellAddress(rowNumber, c))
                                        }
                                    }
                            ) {
                                val start = (horizontal.value / columnWidthPx).toInt().coerceIn(0, columns - 1)
                                // draw only visible columns even though the canvas spans all columns
                                val end = min(columns - 1, start + ceil(viewportWidthPx / columnWidthPx).toInt() + 2)
                                val canvas = drawContext.canvas.nativeCanvas
                                for (column in start..end) {
                                    val x = column * columnWidthPx
                                    val address = OfficeOoxml.cellAddress(rowNumber, column + 1)
                                    val isSelected = address == selected
                                    if (isSelected) {
                                        drawRect(selectedBg, topLeft = Offset(x, 0f),
                                            size = androidx.compose.ui.geometry.Size(columnWidthPx, size.height))
                                    }
                                    val value = cellValue(address)
                                    if (value.isNotEmpty()) {
                                        val paint = if (isSelected) highlightedPaint else regularPaint
                                        canvas.save()
                                        canvas.clipRect(x + 7f, 0f, x + columnWidthPx - 7f, size.height)
                                        // Clip text to the cell boundary, never overlap adjacent cells.
                                        canvas.drawText(value.replace('\n', ' '), x + 9.dp.toPx(),
                                            rowHeightPx / 2 + labelSize / 3, paint)
                                        canvas.restore()
                                    }
                                    drawLine(outline, Offset(x + columnWidthPx, 0f),
                                        Offset(x + columnWidthPx, size.height), 0.65.dp.toPx())
                                    if (isSelected) {
                                        val blue = scheme.primary
                                        drawLine(blue, Offset(x, 1f), Offset(x + columnWidthPx, 1f), 2.dp.toPx())
                                        drawLine(blue, Offset(x, size.height - 1f), Offset(x + columnWidthPx, size.height - 1f), 2.dp.toPx())
                                        drawLine(blue, Offset(x + 1f, 0f), Offset(x + 1f, size.height), 2.dp.toPx())
                                        drawLine(blue, Offset(x + columnWidthPx - 1f, 0f), Offset(x + columnWidthPx - 1f, size.height), 2.dp.toPx())
                                    }
                                }
                                drawLine(outline, Offset(0f, size.height - 0.5f),
                                    Offset(size.width, size.height - 0.5f), 0.65.dp.toPx())
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridIndex(label: String, active: Boolean, modifier: Modifier, scale: Float) {
    val scheme = MaterialTheme.colorScheme
    Box(
        modifier.fillMaxHeight()
            .background(if (active) scheme.primaryContainer else scheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = (12f * scale).sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = if (active) scheme.onPrimaryContainer else scheme.onSurfaceVariant)
    }
}
