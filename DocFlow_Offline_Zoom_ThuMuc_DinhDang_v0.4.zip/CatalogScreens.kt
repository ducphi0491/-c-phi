package com.docflowoffline

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

private fun kindIcon(kind: CatalogKind): ImageVector = when (kind) {
    CatalogKind.PDF -> Icons.Default.PictureAsPdf
    CatalogKind.EXCEL -> Icons.Default.TableChart
    CatalogKind.WORD -> Icons.Default.Description
    CatalogKind.SLIDES -> Icons.Default.Slideshow
    CatalogKind.TEXT -> Icons.Default.Notes
}

private fun kindColor(kind: CatalogKind): Color = when (kind) {
    CatalogKind.PDF -> Color(0xFFCC4147)
    CatalogKind.EXCEL -> Color(0xFF138451)
    CatalogKind.WORD -> Color(0xFF2473B9)
    CatalogKind.SLIDES -> Color(0xFFE16B34)
    CatalogKind.TEXT -> Color(0xFF916E38)
}

@Composable
internal fun CategoryFolderGrid(
    indexed: List<CatalogItem>,
    recent: List<DocumentStore.Recent>,
    scanning: Boolean,
    folders: List<CatalogFolder>,
    open: (CatalogKind) -> Unit,
    addFolder: () -> Unit,
    manageFolders: () -> Unit
) {
    val kinds = remember { listOf(CatalogKind.PDF, CatalogKind.EXCEL, CatalogKind.WORD, CatalogKind.SLIDES, CatalogKind.TEXT) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Thư mục theo định dạng", modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            TextButton(onClick = manageFolders) { Icon(Icons.Default.Folder, null, Modifier.size(18.dp)); Text("Quản lý") }
        }
        kinds.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { kind ->
                    val seen = indexed.count { it.kind == kind }
                    val recentCount = recent.count { catalogKind(it.name) == kind }
                    Surface(
                        onClick = { open(kind) }, modifier = Modifier.weight(1f).height(105.dp),
                        shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(kindIcon(kind), null, tint = kindColor(kind), modifier = Modifier.size(29.dp))
                            Text(kind.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(if (seen > 0) "$seen tệp đã tìm thấy"
                                 else if (recentCount > 0) "$recentCount tệp gần đây"
                                 else if (scanning) "Đang tìm tệp..." else "Mở thư mục",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (folders.isEmpty()) {
            OutlinedButton(onClick = addFolder, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.CreateNewFolder, null)
                Spacer(Modifier.width(8.dp))
                Text("Chọn thư mục trên điện thoại để phân loại tệp")
            }
        } else {
            Text("Đang theo dõi ${folders.size} thư mục được bạn cấp quyền" +
                if (scanning) " · Đang cập nhật" else "",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
internal fun CategoryFolderScreen(
    kind: CatalogKind,
    files: List<CatalogItem>,
    recent: List<DocumentStore.Recent>,
    folders: List<CatalogFolder>,
    scanning: Boolean,
    warnings: List<String>,
    limited: Boolean,
    openItem: (String, String) -> Unit,
    addFolder: () -> Unit,
    manageFolders: () -> Unit,
    refresh: () -> Unit
) {
    var search by remember(kind) { mutableStateOf("") }
    val candidates = remember(files, kind, search) {
        files.filter { it.kind == kind && (search.isBlank() || it.name.contains(search.trim(), ignoreCase = true)) }
    }
    val groups = remember(candidates) { candidates.groupBy { it.path } }
    val nonIndexed = remember(recent, files, kind, search) {
        val indexedUris = files.map { it.uri }.toSet()
        recent.filter { catalogKind(it.name) == kind && it.uri !in indexedUris &&
            (search.isBlank() || it.name.contains(search.trim(), ignoreCase = true)) }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).background(kindColor(kind).copy(alpha = .12f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center) {
                    Icon(kindIcon(kind), null, tint = kindColor(kind))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Thư mục ${kind.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(kind.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = refresh, enabled = !scanning) {
                    Icon(Icons.Default.Refresh, "Quét lại")
                }
            }
        }
        item {
            OutlinedTextField(value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("Tìm tệp ${kind.title}...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = if (search.isNotEmpty()) {
                    { IconButton(onClick = { search = "" }) { Icon(Icons.Default.Close, "Xóa") } }
                } else null)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = addFolder, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.CreateNewFolder, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Thêm thư mục")
                }
                OutlinedButton(onClick = manageFolders) { Text("Đã chọn (${folders.size})") }
            }
        }
        if (scanning) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (warnings.isNotEmpty() || limited) item {
            Text((warnings + if (limited) listOf("Đã đạt giới hạn quét. Hãy chọn thư mục cụ thể hơn để xem đủ tệp.")
                    else emptyList()).joinToString("\n"),
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (groups.isEmpty() && nonIndexed.isEmpty() && !scanning) item {
            Surface(shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Chưa có tệp ${kind.title}", fontWeight = FontWeight.Medium)
                    Text("Chọn thư mục chứa tài liệu. DocFlow sẽ phân loại tệp vào đây và các thư mục con.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = addFolder) { Text("Chọn thư mục") }
                }
            }
        }
        if (nonIndexed.isNotEmpty()) {
            item { Text("Đã mở gần đây", fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.titleSmall) }
            items(nonIndexed, key = { "recent:${it.uri}" }) { record ->
                CategoryFileRow(record.name, "Đã mở gần đây", kind, onClick = { openItem(record.uri, record.name) })
            }
        }
        groups.forEach { (path, contents) ->
            item(key = "path:$path") {
                Text(path, fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.titleSmall, maxLines = 2,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(contents, key = { "file:${it.uri}" }) { record ->
                CategoryFileRow(record.name,
                    (if (record.modifiedAt > 0L) DateFormat.getDateInstance(DateFormat.SHORT).format(Date(record.modifiedAt))
                     else "Tài liệu") + if (record.size > 0L) " · ${record.size / 1024} KB" else "",
                    kind,
                    onClick = { openItem(record.uri, record.name) })
            }
        }
        if (files.isNotEmpty()) item {
            Text("Chỉ hiển thị tệp trong các thư mục đã được cấp quyền. " +
                "Định dạng .doc, .xls, .ppt đời cũ cần chuyển sang định dạng mới để chỉnh sửa.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryFileRow(name: String, detail: String, kind: CatalogKind, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(13.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(kindIcon(kind), null, tint = kindColor(kind), modifier = Modifier.size(25.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
internal fun FolderSourcesDialog(
    folders: List<CatalogFolder>,
    onDismiss: () -> Unit,
    onAdd: () -> Unit,
    onRemove: (CatalogFolder) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Thư mục được phép truy cập") },
        text = {
            Column(Modifier.heightIn(max = 390.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("DocFlow chỉ quét thư mục bạn chọn và các thư mục con. Không cần quyền đọc toàn bộ bộ nhớ.",
                    style = MaterialTheme.typography.bodySmall)
                if (folders.isEmpty()) Text("Chưa chọn thư mục nào.")
                folders.forEach { folder ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Folder, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(folder.name, modifier = Modifier.weight(1f),
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { onRemove(folder) }) {
                            Icon(Icons.Default.DeleteOutline, "Bỏ quyền thư mục")
                        }
                    }
                }
                Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Chọn thư mục khác")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}
