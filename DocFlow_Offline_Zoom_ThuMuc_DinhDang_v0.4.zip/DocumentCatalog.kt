package com.docflowoffline

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.Locale

/** Virtual format folders backed ONLY by document trees explicitly authorized by the user. */
internal enum class CatalogKind(val title: String, val subtitle: String) {
    PDF("PDF", ".pdf"),
    EXCEL("Excel", ".xlsx · .xls · .csv"),
    WORD("Word", ".docx · .doc"),
    SLIDES("PowerPoint", ".pptx · .ppt"),
    TEXT("Văn bản", ".txt · .tsv")
}

internal fun catalogKind(name: String): CatalogKind? = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
    "pdf" -> CatalogKind.PDF
    "xlsx", "xls", "csv" -> CatalogKind.EXCEL
    "docx", "doc" -> CatalogKind.WORD
    "pptx", "ppt" -> CatalogKind.SLIDES
    "txt", "tsv" -> CatalogKind.TEXT
    else -> null
}

internal fun isSupportedDocument(name: String): Boolean =
    name.substringAfterLast('.', "").lowercase(Locale.ROOT) in setOf("pdf", "xlsx", "csv", "docx", "pptx", "txt", "tsv")

internal data class CatalogFolder(val uri: String, val name: String)

internal data class CatalogItem(
    val uri: String,
    val name: String,
    val kind: CatalogKind,
    val path: String,
    val modifiedAt: Long,
    val size: Long
)

internal data class CatalogScan(val items: List<CatalogItem>, val warnings: List<String>, val limited: Boolean)

internal object DocumentCatalog {
    private const val PREFS = "docflow_document_folders"
    private const val FOLDERS = "folders"
    private const val MAX_TREES = 12
    private const val MAX_NODES = 15000
    private const val MAX_DEPTH = 12

    fun folders(context: Context): List<CatalogFolder> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(FOLDERS, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val obj = array.optJSONObject(i) ?: return@mapNotNull null
            val uri = obj.optString("uri")
            val name = obj.optString("name")
            if (uri.isBlank()) null else CatalogFolder(uri, name.ifBlank { "Thư mục đã chọn" })
        }
    }.getOrDefault(emptyList())

    private fun saveFolders(context: Context, value: List<CatalogFolder>) {
        val array = JSONArray()
        value.forEach { array.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(FOLDERS, array.toString()).apply()
    }

    fun add(context: Context, tree: Uri): List<CatalogFolder> {
        val existing = folders(context)
        require(existing.size < MAX_TREES || existing.any { it.uri == tree.toString() }) {
            "Chỉ có thể theo dõi tối đa $MAX_TREES thư mục. Hãy bỏ bớt một thư mục."
        }
        context.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val name = runCatching {
            val root = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            context.contentResolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull().orEmpty().ifBlank { "Thư mục ${folders(context).size + 1}" }
        val next = existing.filterNot { it.uri == tree.toString() } + CatalogFolder(tree.toString(), name)
        saveFolders(context, next)
        return next
    }

    fun remove(context: Context, folder: CatalogFolder): List<CatalogFolder> {
        val next = folders(context).filterNot { it.uri == folder.uri }
        saveFolders(context, next)
        runCatching {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(folder.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        return next
    }

    /** Execute on Dispatchers.IO. Enumerates the selected trees, never the entire phone. */
    fun scan(context: Context, folders: List<CatalogFolder>): CatalogScan {
        val resolver = context.contentResolver
        val granted = resolver.persistedUriPermissions.filter { it.isReadPermission }.map { it.uri.toString() }.toSet()
        val warnings = mutableListOf<String>()
        val items = LinkedHashMap<String, CatalogItem>()
        var nodes = 0
        var limited = false
        for (folder in folders) {
            if (folder.uri !in granted) {
                warnings += "Không còn quyền đọc: ${folder.name}. Hãy chọn lại thư mục."
                continue
            }
            try {
                val treeUri = Uri.parse(folder.uri)
                data class Pending(val documentId: String, val relative: String, val depth: Int)
                val queue = ArrayDeque<Pending>()
                queue.add(Pending(DocumentsContract.getTreeDocumentId(treeUri), folder.name, 0))
                while (queue.isNotEmpty()) {
                    if (nodes >= MAX_NODES) { limited = true; break }
                    val dir = queue.removeFirst()
                    val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, dir.documentId)
                    val projection = arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                        DocumentsContract.Document.COLUMN_SIZE
                    )
                    resolver.query(children, projection, null, null, null)?.use { cursor ->
                        while (cursor.moveToNext()) {
                            nodes++
                            if (nodes > MAX_NODES) { limited = true; break }
                            val id = cursor.getString(0) ?: continue
                            val name = cursor.getString(1) ?: continue
                            val mime = cursor.getString(2).orEmpty()
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                if (dir.depth < MAX_DEPTH) queue.add(Pending(id, "${dir.relative}/$name", dir.depth + 1))
                                else limited = true
                            } else {
                                val kind = catalogKind(name) ?: continue
                                val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                                items.putIfAbsent(documentUri.toString(), CatalogItem(
                                    uri = documentUri.toString(), name = name, kind = kind,
                                    path = dir.relative, modifiedAt = if (cursor.isNull(3)) 0L else cursor.getLong(3),
                                    size = if (cursor.isNull(4)) 0L else cursor.getLong(4)
                                ))
                            }
                        }
                    }
                    if (limited) break
                }
            } catch (e: Exception) {
                warnings += "Không quét được ${folder.name}: ${e.message ?: "lỗi truy cập"}"
            }
            if (limited) break
        }
        return CatalogScan(items.values.sortedWith(compareByDescending<CatalogItem> { it.modifiedAt }.thenBy { it.name.lowercase(Locale.ROOT) }), warnings, limited)
    }
}
