package com.docflowoffline

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.OutputStream
import kotlin.math.min
import kotlin.math.roundToInt

internal typealias Save = (String, String, Boolean, (Context, OutputStream) -> Unit) -> Unit

@Composable
internal fun DocumentScreen(document: DocumentStore.OpenFile, requestSave: Save, notify: (String) -> Unit) {
    when (document) {
        is DocumentStore.OpenFile.Word -> WordEditor(document, requestSave, notify)
        is DocumentStore.OpenFile.Excel -> ExcelEditor(document, requestSave, notify)
        is DocumentStore.OpenFile.Slides -> PowerPointEditor(document, requestSave, notify)
        is DocumentStore.OpenFile.Pdf -> PdfScreen(document, requestSave, notify)
        is DocumentStore.OpenFile.Text -> TextEditor(document, requestSave, notify)
    }
}

@Composable
private fun EditorInfo(text: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(12.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DocumentZoomBar(
    zoom: Float, minimum: Float, maximum: Float,
    onZoom: (Float) -> Unit, modifier: Modifier = Modifier
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Zoom", style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        FilledTonalIconButton(onClick = { onZoom((zoom - .25f).coerceAtLeast(minimum)) },
            enabled = zoom > minimum + .01f, modifier = Modifier.size(35.dp)) {
            Icon(Icons.Default.Remove, "Thu nhỏ", Modifier.size(18.dp))
        }
        Text("${(zoom * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.widthIn(min = 47.dp))
        FilledTonalIconButton(onClick = { onZoom((zoom + .25f).coerceAtMost(maximum)) },
            enabled = zoom < maximum - .01f, modifier = Modifier.size(35.dp)) {
            Icon(Icons.Default.Add, "Phóng to", Modifier.size(18.dp))
        }
        TextButton(onClick = { onZoom(1f) }, enabled = zoom != 1f) { Text("100%") }
    }
}

@Composable
private fun WordEditor(document: DocumentStore.OpenFile.Word, save: Save, notify: (String) -> Unit) {
    val editable = document.data.editable
    var wordZoom by remember(document.uri) { mutableFloatStateOf(1f) }
    val paragraphs = remember(document.uri) {
        mutableStateListOf<String>().apply { addAll(document.data.paragraphs.ifEmpty { listOf("") }) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Trình chỉnh sửa Word cơ bản", fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
        EditorInfo(document.data.reason ?: "Chỉnh sửa từng đoạn chữ. Tệp gốc được giữ nguyên. Định dạng phức tạp cần tích hợp Collabora.")
        DocumentZoomBar(wordZoom, .75f, 2f, onZoom = { wordZoom = it })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val values = paragraphs.toList()
                save(DocumentStore.suggestedCopyName(document.name, "docx"), DocumentStore.DOCX, true) { _, out ->
                    out.write(OfficeOoxml.writeWord(document.bytes, values))
                }
            }, enabled = editable, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Save, null); Spacer(Modifier.width(4.dp)); Text("Lưu bản sao")
            }
            OutlinedButton(onClick = {
                val content = paragraphs.joinToString("\n")
                save(document.name.substringBeforeLast('.') + ".pdf", DocumentStore.PDF, true) { _, out ->
                    TextPdfExporter.create(content, out, document.name)
                }
            }, modifier = Modifier.weight(1f)) { Text("Xuất PDF (chữ)") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 20.dp)) {
            itemsIndexed(paragraphs) { index, value ->
                Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Đoạn ${index + 1}", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                            if (editable && paragraphs.size > 1) IconButton(onClick = { paragraphs.removeAt(index) },
                                modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Xóa đoạn")
                            }
                        }
                        if (editable) OutlinedTextField(value = value, onValueChange = { paragraphs[index] = it },
                            modifier = Modifier.fillMaxWidth(), minLines = 2,
                            textStyle = TextStyle(fontSize = (16f * wordZoom).sp))
                        else Text(value.ifBlank { "(đoạn trống)" }, modifier = Modifier.padding(8.dp),
                            fontSize = (16f * wordZoom).sp)
                    }
                }
            }
            if (editable) item {
                OutlinedButton(onClick = { paragraphs.add("") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Thêm đoạn mới")
                }
            }
        }
    }
}

@Composable
private fun ExcelEditor(document: DocumentStore.OpenFile.Excel, save: Save, notify: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    var zoom by remember(document.uri) { mutableFloatStateOf(1f) }
    var lastZoom by remember(document.uri) { mutableFloatStateOf(1f) }
    val columnPx = with(density) { (GRID_COLUMN_DP.dp * zoom).roundToPx() }
    var sheetIndex by remember(document.uri) { mutableIntStateOf(0) }
    val edits = remember(document.uri) { mutableStateMapOf<String, String>() }
    val sheet = document.data.sheets.getOrNull(sheetIndex) ?: return
    var selected by remember(document.uri, sheet.partPath) { mutableStateOf("A1") }
    val selectedKey = "${sheet.partPath}::$selected"
    var formula by remember(document.uri, selectedKey) {
        mutableStateOf(edits[selectedKey] ?: sheet.cells[selected].orEmpty())
    }
    val rowCount = maxOf(100, sheet.maxRow + 30).coerceAtMost(100_000)
    val columnCount = maxOf(12, sheet.maxCol + 6).coerceAtMost(256)
    val xScroll = rememberScrollState()
    val yScroll = rememberLazyListState()
    var jump by remember(document.uri, sheet.partPath) { mutableStateOf("") }
    var searchOpen by remember(document.uri) { mutableStateOf(false) }
    var searchText by remember(document.uri) { mutableStateOf("") }
    var matches by remember(document.uri, sheet.partPath) { mutableStateOf(emptyList<String>()) }
    var matchIndex by remember(document.uri, sheet.partPath) { mutableIntStateOf(0) }
    var isSearching by remember { mutableStateOf(false) }
    LaunchedEffect(sheet.partPath) {
        yScroll.scrollToItem(0)
        xScroll.scrollTo(0)
    }
    LaunchedEffect(zoom) {
        if (lastZoom != zoom && lastZoom > 0f) {
            // Keep roughly the same viewport column when changing cell width.
            xScroll.scrollTo((xScroll.value * zoom / lastZoom).roundToInt()
                .coerceIn(0, xScroll.maxValue))
            lastZoom = zoom
        }
    }

    fun displayedValue(address: String): String {
        val key = "${sheet.partPath}::$address"
        return edits[key] ?: sheet.displayCells[address] ?: sheet.cells[address].orEmpty()
    }

    fun navigate(address: String) {
        val ref = address.trim().uppercase(java.util.Locale.ROOT).replace("$", "")
        if (!ref.matches(Regex("[A-Z]{1,3}[1-9][0-9]{0,5}"))) {
            notify("Địa chỉ ô không hợp lệ. Ví dụ: B12 hoặc AA250.")
            return
        }
        val row = ref.dropWhile(Char::isLetter).toIntOrNull() ?: return
        val letters = ref.takeWhile(Char::isLetter)
        var column = 0
        for (c in letters) column = column * 26 + (c - 'A') + 1
        if (row !in 1..rowCount || column !in 1..columnCount) {
            notify("Ô $ref ngoài vùng xem hiện tại (A1:${OfficeOoxml.cellAddress(rowCount, columnCount)}).")
            return
        }
        selected = ref
        scope.launch {
            yScroll.animateScrollToItem(row - 1)
            xScroll.animateScrollTo(((column - 1) * columnPx).coerceAtMost(xScroll.maxValue))
        }
    }

    Column(
        Modifier.fillMaxSize().imePadding().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Trang tính", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("${document.data.sheets.size} sheet · ${sheet.cells.size} ô đã nạp",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { searchOpen = !searchOpen; matches = emptyList() }) {
                Icon(Icons.Default.Search, contentDescription = "Tìm trong trang tính")
            }
            Button(onClick = {
                val changes = edits.map { (key, value) ->
                    val div = key.lastIndexOf("::")
                    OfficeOoxml.CellChange(key.substring(0, div), key.substring(div + 2), value)
                }
                save(DocumentStore.suggestedCopyName(document.name, "xlsx"), DocumentStore.XLSX, true) { _, out ->
                    out.write(OfficeOoxml.writeWorkbook(document.bytes, changes))
                }
            }) {
                Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(5.dp))
                Text("Lưu")
            }
        }
        if (sheet.truncated) {
            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(10.dp)) {
                Text("Tệp lớn: phần xem trước chỉ nạp tối đa 120.000 ô, 100.000 hàng và 256 cột. " +
                    "Những ô chưa nạp vẫn được giữ nguyên trong tệp gốc khi lưu bản sao.",
                    Modifier.fillMaxWidth().padding(9.dp), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }
        if (searchOpen) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedTextField(searchText, onValueChange = { searchText = it },
                    label = { Text("Tìm trong sheet") }, singleLine = true,
                    modifier = Modifier.weight(1f))
                Button(enabled = !isSearching && searchText.isNotBlank(), onClick = {
                    val q = searchText.trim()
                    val changed = edits.toMap()
                    isSearching = true
                    scope.launch {
                        val found = withContext(Dispatchers.Default) {
                            val prefix = "${sheet.partPath}::"
                            val references = LinkedHashSet<String>()
                            for ((ref, old) in sheet.cells) {
                                val newValue = changed["$prefix$ref"] ?: old
                                if (newValue.contains(q, ignoreCase = true)) references.add(ref)
                                if (references.size >= 200) break
                            }
                            if (references.size < 200) {
                                for ((key, v) in changed) {
                                    if (key.startsWith(prefix) && v.contains(q, ignoreCase = true)) {
                                        references.add(key.removePrefix(prefix))
                                        if (references.size >= 200) break
                                    }
                                }
                            }
                            references.toList()
                        }
                        matches = found
                        matchIndex = 0
                        isSearching = false
                        if (found.isNotEmpty()) navigate(found[0]) else notify("Không tìm thấy '$q' trong dữ liệu đã nạp.")
                    }
                }) { Text("Tìm") }
            }
            if (matches.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kết quả ${matchIndex + 1}/${matches.size}" + if (matches.size == 200) " (tối đa 200)" else "",
                        style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        matchIndex = (matchIndex - 1 + matches.size) % matches.size
                        navigate(matches[matchIndex])
                    }) { Text("Trước") }
                    TextButton(onClick = {
                        matchIndex = (matchIndex + 1) % matches.size
                        navigate(matches[matchIndex])
                    }) { Text("Tiếp") }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(shape = RoundedCornerShape(9.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Text(selected, modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Text("fx", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = formula, onValueChange = { formula = it }, singleLine = true,
                placeholder = { Text("Nội dung hoặc =CÔNG_THỨC") },
                modifier = Modifier.weight(1f))
            FilledTonalIconButton(onClick = {
                if (formula == sheet.cells[selected].orEmpty()) edits.remove(selectedKey)
                else edits[selectedKey] = formula
                notify("Đã cập nhật $selected · chưa lưu vào tệp")
            }) { Icon(Icons.Default.Check, contentDescription = "Áp dụng thay đổi ô") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = jump, onValueChange = { jump = it }, singleLine = true,
                modifier = Modifier.width(110.dp), label = { Text("Đến ô") },
                placeholder = { Text("AA250") })
            TextButton(onClick = { navigate(jump) }, enabled = jump.isNotBlank()) { Text("Đi") }
            Spacer(Modifier.weight(1f))
            Text("${edits.size} thay đổi", color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall)
            TextButton(onClick = {
                val simpleText = buildString {
                    document.data.sheets.forEach { s ->
                        append("\n### ").append(s.name).append('\n')
                        for (r in 1..60) {
                            val line = (1..8).joinToString("  |  ") { c ->
                                val cell = OfficeOoxml.cellAddress(r, c)
                                edits["${s.partPath}::$cell"] ?: s.cells[cell].orEmpty()
                            }
                            if (line.isNotBlank()) append(line).append('\n')
                        }
                    }
                }
                save(document.name.substringBeforeLast('.') + ".pdf", DocumentStore.PDF, true) { _, out ->
                    TextPdfExporter.create(simpleText, out, document.name)
                }
            }) { Text("PDF chữ") }
        }
        DocumentZoomBar(zoom, .65f, 2.5f, onZoom = { zoom = it },
            modifier = Modifier.fillMaxWidth())
        ExcelGrid(
            rows = rowCount,
            columns = columnCount,
            selected = selected,
            cellValue = ::displayedValue,
            onCellClick = { selected = it },
            horizontal = xScroll,
            vertical = yScroll,
            zoom = zoom,
            onPinchZoom = { zoom = (zoom * it).coerceIn(.65f, 2.5f) },
            modifier = Modifier.weight(1f).fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            document.data.sheets.forEachIndexed { index, item ->
                FilterChip(selected = sheetIndex == index, onClick = { sheetIndex = index },
                    label = { Text(item.name, maxLines = 1) })
            }
        }
        Text("Chế độ chỉnh sửa ô cơ bản · giá trị công thức hiển thị từ cache, không tự tính lại. " +
            "Lưu thành bản sao để giữ tệp gốc.", style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
    }
}

@Composable
private fun PowerPointEditor(document: DocumentStore.OpenFile.Slides, save: Save, notify: (String) -> Unit) {
    // Basic editing existing text runs, without modifying slide shapes or positions.
    val changes = remember(document.uri) { mutableStateMapOf<String, String>() }
    var slidesZoom by remember(document.uri) { mutableFloatStateOf(1f) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PowerPoint — chỉnh sửa chữ", fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
        EditorInfo("Chỉ sửa đoạn chữ có sẵn trong slide. Không xem đúng bố cục hoặc sửa hiệu ứng, hình ảnh, hình khối.")
        DocumentZoomBar(slidesZoom, .75f, 2f, onZoom = { slidesZoom = it })
        Button(onClick = {
            val edits = changes.map { (key, value) ->
                val split = key.lastIndexOf("::")
                OfficeOoxml.SlideChange(key.substring(0, split), key.substring(split + 2).toInt(), value)
            }
            // DocumentStore.Slides keeps no entire byte[]: it is re-read from the file picker URI when saving.
            save(DocumentStore.suggestedCopyName(document.name, "pptx"), DocumentStore.PPTX, true) { ctx, out ->
                val data = DocumentStore.readUpTo(ctx, document.uri)
                out.write(OfficeOoxml.writePresentation(data, edits))
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Lưu bản sao PPTX")
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(document.slides) { _, slide ->
                Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Slide ${slide.number}", fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary)
                        slide.paragraphs.forEachIndexed { index, item ->
                            if (item.isNotBlank()) {
                                val key = "${slide.partPath}::$index"
                                OutlinedTextField(
                                    value = changes[key] ?: item,
                                    onValueChange = { changes[key] = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Văn bản ${index + 1}") },
                                    textStyle = TextStyle(fontSize = (16f * slidesZoom).sp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TextEditor(document: DocumentStore.OpenFile.Text, save: Save, notify: (String) -> Unit) {
    var text by remember(document.uri) { mutableStateOf(document.value) }
    var textZoom by remember(document.uri) { mutableFloatStateOf(1f) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (document.csv) "Chỉnh sửa CSV/TSV" else "Chỉnh sửa văn bản", fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
        EditorInfo("Chỉnh sửa UTF-8. Lưu thành bản sao; với CSV, hãy giữ đúng quy tắc dấu phẩy và dấu nháy.")
        DocumentZoomBar(textZoom, .75f, 2f, onZoom = { textZoom = it })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val body = text
                save(DocumentStore.suggestedCopyName(document.name, if (document.csv) "csv" else "txt"),
                    if (document.csv) DocumentStore.CSV else DocumentStore.TXT, true) { _, out ->
                    out.write(body.toByteArray(Charsets.UTF_8))
                }
            }, modifier = Modifier.weight(1f)) { Text("Lưu bản sao") }
            OutlinedButton(onClick = {
                val body = text
                save(document.name.substringBeforeLast('.') + ".pdf", DocumentStore.PDF, true) { _, out ->
                    TextPdfExporter.create(body, out, document.name)
                }
            }, modifier = Modifier.weight(1f)) { Text("Xuất PDF") }
        }
        OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().weight(1f),
            label = { Text("Nội dung") }, textStyle = TextStyle(fontSize = (16f * textZoom).sp))
    }
}

@Composable
private fun PdfScreen(document: DocumentStore.OpenFile.Pdf, save: Save, notify: (String) -> Unit) {
    val context = LocalContext.current
    var page by remember(document.uri) { mutableIntStateOf(0) }
    var total by remember(document.uri) { mutableIntStateOf(0) }
    var zoom by remember(document.uri, page) { mutableFloatStateOf(1f) }
    var pan by remember(document.uri, page) { mutableStateOf(Offset.Zero) }
    var rendered by remember(document.uri, page) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(document.uri) { mutableStateOf(false) }
    var error by remember(document.uri) { mutableStateOf<String?>(null) }
    var selection by remember(document.uri) { mutableStateOf("1") }
    var toolsExpanded by remember(document.uri) { mutableStateOf(false) }

    // Increase render quality only when needed; avoid rerendering on every pinch frame.
    val renderWidth = when {
        zoom >= 2.3f -> 2500
        zoom >= 1.4f -> 1850
        else -> 1280
    }
    LaunchedEffect(document.uri, page, renderWidth) {
        loading = true
        error = null
        try {
            val result = withContext(Dispatchers.IO) {
                PdfTools.renderPage(context, document.uri, page, renderWidth)
            }
            rendered = result.first
            total = result.second
        } catch (e: Exception) {
            rendered = null
            error = e.message ?: "Không thể hiển thị PDF."
        } finally { loading = false }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { page = (page - 1).coerceAtLeast(0) }, enabled = page > 0) {
                Icon(Icons.Default.ChevronLeft, "Trang trước")
            }
            Text("Trang ${page + 1} / ${total.coerceAtLeast(1)}", modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            IconButton(onClick = { page = (page + 1).coerceAtMost(total - 1) }, enabled = page < total - 1) {
                Icon(Icons.Default.ChevronRight, "Trang sau")
            }
            TextButton(onClick = {
                val current = page
                save(document.name.substringBeforeLast('.') + "_page_${page + 1}.png", "image/png", false) { ctx, out ->
                    PdfTools.pagePng(ctx, document.uri, current, out)
                }
            }) { Text("PNG") }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            DocumentZoomBar(zoom, 1f, 4f, onZoom = {
                zoom = it
                if (zoom <= 1f) pan = Offset.Zero
            }, modifier = Modifier.weight(1f))
            TextButton(onClick = { toolsExpanded = !toolsExpanded }) {
                Icon(Icons.Default.Tune, null, Modifier.size(17.dp))
                Text("Công cụ")
            }
        }
        if (toolsExpanded) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = selection, onValueChange = { selection = it }, singleLine = true,
                    label = { Text("Trang: 1-3,5") }, modifier = Modifier.weight(1f))
                Button(onClick = {
                    val pages = selection
                    try {
                        if (total > 0) PdfTools.parsePageRange(pages, total)
                        save(document.name.substringBeforeLast('.') + "_tach.pdf", DocumentStore.PDF, true) { ctx, out ->
                            PdfTools.extract(ctx, document.uri, pages, out)
                        }
                    } catch (e: Exception) { notify(e.message ?: "Khoảng trang không hợp lệ.") }
                }, enabled = total > 0) { Text("Tách PDF") }
            }
        }
        BoxWithConstraints(
            Modifier.fillMaxWidth().weight(1f)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
                .clipToBounds(), contentAlignment = Alignment.Center
        ) {
            val bitmap = rendered
            val imageBitmap = remember(bitmap) { bitmap?.asImageBitmap() }
            val viewportWidth = constraints.maxWidth.toFloat()
            val viewportHeight = constraints.maxHeight.toFloat()
            val paddingPx = with(LocalDensity.current) { 10.dp.toPx() }
            val innerWidth = (viewportWidth - paddingPx * 2).coerceAtLeast(1f)
            val innerHeight = (viewportHeight - paddingPx * 2).coerceAtLeast(1f)
            val fitFactor = if (bitmap == null) 1f else min(
                innerWidth / bitmap.width.toFloat(), innerHeight / bitmap.height.toFloat()
            )
            val fittedWidth = if (bitmap == null) innerWidth else bitmap.width * fitFactor
            val fittedHeight = if (bitmap == null) innerHeight else bitmap.height * fitFactor
            fun clampOffset(value: Offset, scale: Float): Offset {
                val x = ((fittedWidth * scale - innerWidth) / 2f).coerceAtLeast(0f)
                val y = ((fittedHeight * scale - innerHeight) / 2f).coerceAtLeast(0f)
                return Offset(value.x.coerceIn(-x, x), value.y.coerceIn(-y, y))
            }
            val visibleOffset = clampOffset(pan, zoom)
            if (bitmap != null) {
                Image(
                    imageBitmap!!, contentDescription = "Trang PDF ${page + 1}",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(10.dp)
                        .graphicsLayer {
                            scaleX = zoom
                            scaleY = zoom
                            translationX = visibleOffset.x
                            translationY = visibleOffset.y
                        }
                )
            }
            // Parent receives pinch and drag; image redraw remains independent of the render job.
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(document.uri, page, viewportWidth, viewportHeight,
                        bitmap?.width, bitmap?.height) {
                        detectTransformGestures { _, drag, factor, _ ->
                            val nextZoom = (zoom * factor).coerceIn(1f, 4f)
                            zoom = nextZoom
                            pan = if (nextZoom <= 1f) Offset.Zero
                                  else clampOffset(pan + drag, nextZoom)
                        }
                    }
            )
            when {
                error != null -> Text("Lỗi: $error", Modifier.padding(16.dp))
                loading && bitmap == null -> CircularProgressIndicator()
                bitmap == null -> Text("Đang mở PDF...")
            }
            if (loading && bitmap != null) LinearProgressIndicator(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth())
        }
        Text("Chụm hai ngón để phóng to; kéo trang khi đã zoom. Tài liệu được xử lý offline.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
