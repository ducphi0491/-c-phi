package ducphi.tunnerinstrument

import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
// --- CẤU TRÚC DỮ LIỆU ---
data class LeaderboardEntry(
    val rank: Int,
    val name: String,
    val email: String,
    val score: Int,
    val totalTime: Int = 0, // <-- THÊM TRƯỜNG THỜI GIAN
    val avatarUrl: String? = null
)

// --- HÀM LẤY KEY THÁNG HIỆN TẠI ---
fun getCurrentMonthKey(): String {
    val sdf = SimpleDateFormat("MM_yyyy", Locale.getDefault())
    return "score_${sdf.format(Date())}"
}

// --- HÀM XỬ LÝ LƯU TRỮ LỊCH SỬ LOCAL & FIREBASE ---
fun saveGameHistory(context: Context, instrument: String, gameType: String, score: Int, total: Int, totalTime: Int, wrongAnswersJson: String = "") {
    val prefs = context.getSharedPreferences("MinigameHistory", Context.MODE_PRIVATE)

    val localKey = "${instrument}_$gameType"
    val currentHistory = prefs.getString(localKey, "") ?: ""
    val timestamp = System.currentTimeMillis()

    // 1. MÃ HÓA JSON SANG BASE64 ĐỂ TRÁNH LỖI KHI CÓ DẤU PHẨY TRONG CHUỖI
    val safeJson = if (wrongAnswersJson.isNotEmpty() && wrongAnswersJson != "[]") {
        android.util.Base64.encodeToString(wrongAnswersJson.toByteArray(), android.util.Base64.NO_WRAP)
    } else ""

    // 2. LƯU THÊM safeJson VÀO VỊ TRÍ THỨ 5
    val newEntry = "$score|$total|$timestamp|$totalTime|$safeJson"

    val updatedHistory = (listOf(newEntry) + currentHistory.split(",").filter { it.isNotBlank() })
        .take(15).joinToString(",")

    prefs.edit().putString(localKey, updatedHistory).apply()

    val wrongAnswers = total - score
    var baseExp = when (gameType) {
        "NOTE" -> (score * 10) - (wrongAnswers * 5)
        "CHORD" -> (score * 20) - (wrongAnswers * 10)
        "RHYTHM" -> (score * 30) - (wrongAnswers * 15)
        "PITCH" -> (score * 40) - (wrongAnswers * 20)
        else -> 0
    }

    baseExp = maxOf(0, baseExp)

    val isPerfect = score == total && total > 0
    val finalExp = if (isPerfect) (baseExp * 1.5).toInt() else baseExp

    // SỬA Ở ĐÂY: Thêm điều kiện || totalTime > 0 để lưu dữ liệu khi có thời gian chơi
    if (finalExp > 0 || totalTime > 0) {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        if (account != null && account.email != null) {
            val db = FirebaseFirestore.getInstance()
            val userRef = db.collection("GlobalLeaderboard").document(account.email!!)
            val currentMonthKey = getCurrentMonthKey()

            db.runTransaction { transaction ->
                val snapshot = transaction.get(userRef)

                // Lấy điểm
                val currentTotalScore = if (snapshot.exists()) snapshot.getLong("score") ?: 0L else 0L
                val currentMonthScore = if (snapshot.exists()) snapshot.getLong(currentMonthKey) ?: 0L else 0L
                val currentCategoryScore = if (snapshot.exists()) snapshot.getLong("score_$gameType") ?: 0L else 0L

                // Lấy thời gian tích lũy
                val currentTotalTime = if (snapshot.exists()) snapshot.getLong("time_total") ?: 0L else 0L
                val currentMonthTime = if (snapshot.exists()) snapshot.getLong("time_$currentMonthKey") ?: 0L else 0L
                val currentCategoryTime = if (snapshot.exists()) snapshot.getLong("time_$gameType") ?: 0L else 0L

                val userData: Map<String, Any> = mapOf(
                    "name" to (account.displayName ?: "Người chơi ẩn danh"),
                    "email" to account.email!!,
                    "avatarUrl" to (account.photoUrl?.toString() ?: ""),

                    "score" to (currentTotalScore + finalExp),
                    "time_total" to (currentTotalTime + totalTime.toLong()),
                    currentMonthKey to (currentMonthScore + finalExp),
                    "time_$currentMonthKey" to (currentMonthTime + totalTime.toLong()),
                    "score_$gameType" to (currentCategoryScore + finalExp),
                    "time_$gameType" to (currentCategoryTime + totalTime.toLong())
                )
                transaction.set(userRef, userData, SetOptions.merge())
            }
        }
    }
}
fun getGameHistory(context: Context, instrument: String, gameType: String): List<String> {
    val prefs = context.getSharedPreferences("MinigameHistory", Context.MODE_PRIVATE)
    val localKey = "${instrument}_$gameType"
    return prefs.getString(localKey, "")?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
}

// --- GIAO DIỆN MÀN HÌNH CHỜ TRƯỚC KHI PLAY ---
@Composable
fun MinigamePrepareView(
    title: String,
    gameType: String,
    instrument: String? = null,
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String,
    onPlay: () -> Unit,
    onClose: () -> Unit,
    onReviewHistory: (score: Int, total: Int, time: Int, wrongAnswersJson: String) -> Unit = { _, _, _, _ -> }
) {
    val context = LocalContext.current
    // SỬA Ở ĐÂY: Thêm instrument vào getGameHistory và dùng remember để load lại khi đổi nhạc cụ
    var historyList by remember(instrument, gameType) { // <--- Đổi val thành var
        mutableStateOf(getGameHistory(context, instrument ?: "Guitar", gameType))
    }
    // BIẾN QUẢN LÝ VIỆC HIỂN THỊ DIALOG CÂU SAI
    var selectedWrongAnswersJson by remember { mutableStateOf<String?>(null) }
    var categoryDatabaseScore by remember { mutableIntStateOf(0) }

    // THÊM BIẾN NÀY ĐỂ QUẢN LÝ DIALOG XÁC NHẬN XÓA LỊCH SỬ
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(gameType) {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        if (account != null && account.email != null) {
            try {
                val db = FirebaseFirestore.getInstance()
                val doc = db.collection("GlobalLeaderboard").document(account.email!!).get().await()
                categoryDatabaseScore = doc.getLong("score_$gameType")?.toInt() ?: 0
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .padding(top = 16.dp, start = 16.dp, end = 16.dp, bottom = 0.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.background(tunaGreen.copy(alpha = 0.3f), CircleShape).size(40.dp)
                ) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = tunaGreen) }
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = title, color = tunaGreen, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(
                onClick = onClose,
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) { Icon(Icons.Default.Close, contentDescription = "Close", tint = textColor) }
        }

        Spacer(modifier = Modifier.height(16.dp))

        var isPressed by remember { mutableStateOf(false) }
        val btnScale by animateFloatAsState(if (isPressed) 0.95f else 1f, animationSpec = tween(100))

        Box(
            modifier = Modifier
                .size(240.dp)
                .background(Brush.radialGradient(colors = listOf(tunaGreen.copy(alpha = 0.4f), Color.Transparent), radius = 350f)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .scale(btnScale)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(tunaGreen, tunaGreen.copy(alpha = 0.4f))))
                    .border(4.dp, tunaGreen.copy(alpha = 0.6f), CircleShape)
                    .clickable {
                        isPressed = true
                        onPlay()
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(56.dp))
                    Text(CoreTranslator.getString("start_btn", currentLang).uppercase(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(surfaceColor, RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(44.dp).background(Color(0xFFB8860B).copy(alpha = 0.2f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Star, contentDescription = "Star", tint = Color(0xFFFFD700), modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(CoreTranslator.getString("achievement_lbl", currentLang), color = textColor.copy(alpha = 0.6f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text(title, color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(text = "$categoryDatabaseScore", color = Color(0xFFFFD700), fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "LP", color = Color(0xFFFFD700).copy(alpha = 0.8f), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(surfaceColor, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .padding(horizontal = 10.dp, vertical = 20.dp) // <--- KÉO RỘNG SÁT VIỀN
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = textColor.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(CoreTranslator.getString("recent_history_lbl", currentLang), color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                // Chỉ hiện nút xóa nếu có lịch sử
                if (historyList.isNotEmpty()) {
                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete History",
                            tint = Color(0xFFF56C6C) // Nút màu đỏ cảnh báo
                        )
                    }
                }
            }

            HorizontalDivider(color = textColor.copy(alpha = 0.1f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(16.dp))

            if (historyList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(CoreTranslator.getString("empty_history_msg", currentLang), color = Color.Gray, fontSize = 14.sp)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(items = historyList) { historyItem ->
                        val parts = historyItem.split("|")
                        if (parts.size >= 3) {
                            val score = parts[0].toIntOrNull() ?: 0
                            val total = parts[1].toIntOrNull() ?: 0
                            val time = parts[2].toLongOrNull() ?: 0L
                            val timeSpent = if (parts.size >= 4) parts[3].toIntOrNull() ?: 0 else 0

                            // LẤY CHUỖI JSON ĐÃ MÃ HÓA
                            val safeJson = if (parts.size >= 5) parts[4] else ""

                            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                            val dateStr = sdf.format(Date(time))
                            val timeSpentStr = String.format(Locale.getDefault(), "%02d:%02d", timeSpent / 60, timeSpent % 60)
                            val isCanceled = total == 0
                            val isPerfect = score == total && total > 0

                            val statusColor = if (isCanceled) Color.Gray else if (isPerfect) Color(0xFFFFD700) else tunaGreen
                            val statusIcon = if (isCanceled) Icons.Default.Cancel else if (isPerfect) Icons.Default.Star else Icons.Default.CheckCircle
                            val statusText = if (isCanceled) CoreTranslator.getString("status_canceled", currentLang) else if (isPerfect) CoreTranslator.getString("status_perfect", currentLang) else CoreTranslator.getString("status_completed", currentLang)

                            val wrongAnswers = total - score
                            var baseExp = when (gameType) {
                                "NOTE" -> (score * 10) - (wrongAnswers * 5)
                                "CHORD" -> (score * 20) - (wrongAnswers * 10)
                                "RHYTHM" -> (score * 30) - (wrongAnswers * 15)
                                "PITCH" -> (score * 40) - (wrongAnswers * 20)
                                else -> 0
                            }
                            baseExp = maxOf(0, baseExp)
                            val finalExp = if (isPerfect) (baseExp * 1.5).toInt() else baseExp

// GIẢI MÃ JSON ĐỂ KIỂM TRA CÓ CÂU SAI KHÔNG
                            val decodedWrongJson = if (safeJson.isNotEmpty()) {
                                String(android.util.Base64.decode(safeJson, android.util.Base64.NO_WRAP))
                            } else ""
                            val isHaveWrong = decodedWrongJson.isNotBlank() && decodedWrongJson != "[]"

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        // Gửi dữ liệu ra ngoài để hiển thị Popup ResultPhase
                                        onReviewHistory(score, total, timeSpent, decodedWrongJson)
                                    },
                                colors = CardDefaults.cardColors(containerColor = bgColor),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, if (isPerfect) Color(0xFFFFD700).copy(alpha = 0.5f) else surfaceColor)
                            ) {
                                Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) { // GIẢM KHOẢNG CÁCH BÊN TRONG THẺ
                                    // HÀNG 1: THỜI GIAN VÀ ĐIỂM SỐ
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(statusIcon, contentDescription = null, tint = statusColor, modifier = Modifier.size(14.dp)) // Thu nhỏ Icon
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(dateStr, color = textColor.copy(alpha = 0.6f), fontSize = 12.sp) // Giảm font ngày tháng
                                            if (timeSpent > 0) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("•  ⏱️ $timeSpentStr", color = textColor.copy(alpha = 0.6f), fontSize = 11.sp) // Giảm font giờ
                                            }
                                        }
                                        Text(text = "$score / $total", color = statusColor, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) // Giảm font tỷ số
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // HÀNG 2: THÀNH TÍCH VÀ NÚT XEM SAI
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(statusText, color = statusColor, fontSize = 14.sp, fontWeight = FontWeight.Bold) // Giảm font trạng thái
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(text = "+$finalExp LP", color = statusColor, fontSize = 12.sp, fontWeight = FontWeight.Bold) // Giảm font EXP
                                        }

                                        // NÚT BẤM XEM CÂU SAI ĐƯỢC THU GỌN LẠI
                                        if (isHaveWrong && wrongAnswers > 0) {
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFF56C6C).copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFF56C6C).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                                    .clip(RoundedCornerShape(6.dp))
                                                    // THAY THẾ DÒNG .clickable CŨ BẰNG DÒNG MỚI NÀY:
                                                    .clickable {
                                                        onReviewHistory(score, total, timeSpent, decodedWrongJson)
                                                    }
                                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Visibility, contentDescription = "Xem", tint = Color(0xFFF56C6C), modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("$wrongAnswers sai", color = Color(0xFFF56C6C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- DIALOG HIỂN THỊ CÂU SAI ---
// --- DIALOG HIỂN THỊ CÂU SAI ---
    if (selectedWrongAnswersJson != null) {
        AlertDialog(
            onDismissRequest = { selectedWrongAnswersJson = null },
            title = {
                Text(
                    text = if (currentLang == "vi") "Xem lại câu sai" else "Review wrong answers",
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
            },
            text = {
                val gson = com.google.gson.Gson()
                val type = object : com.google.gson.reflect.TypeToken<List<WrongAnswerData>>() {}.type
                val wrongList: List<WrongAnswerData> = try {
                    gson.fromJson(selectedWrongAnswersJson, type)
                } catch (e: Exception) {
                    emptyList()
                }

                if (wrongList.isEmpty()) {
                    Text("Tuyệt vời! Lượt chơi này bạn không sai câu nào.", color = textColor)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(wrongList) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(surfaceColor, RoundedCornerShape(12.dp))
                                    .border(1.dp, surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Cột Text (bên trái)
                                Column(modifier = Modifier.weight(1f)) {
                                    val typeLabel = when(item.questionType) {
                                        "CHORD" -> if(currentLang == "vi") "Hợp âm" else "Chord"
                                        "NOTE" -> if(currentLang == "vi") "Nốt nhạc" else "Note"
                                        "PITCH_CHORD" -> if(currentLang == "vi") "Nghe Hợp âm" else "Pitch Chord"
                                        else -> if(currentLang == "vi") "Nghe Nốt" else "Pitch Note"
                                    }
                                    Text("Phân loại: $typeLabel", fontWeight = FontWeight.Bold, color = textColor, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Bạn đã chọn: ${item.selectedOption}", color = Color(0xFFF56C6C), fontSize = 14.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Đáp án đúng: ${item.correctOption}", color = tunaGreen, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }

// Khu vực vẽ hình (bên phải)
                                if (item.imageDataJson.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(16.dp))

                                    val savedInstrument = if (item.instrument.isNotEmpty()) item.instrument else (instrument ?: "Guitar")

                                    // Cho phép nhạc cụ Piano được dùng khung nằm ngang (rộng) để bàn phím đàn đẹp hơn
                                    val isPiano = savedInstrument == "Piano"
                                    val isNoteQuestion = (item.questionType == "NOTE" || item.questionType == "PITCH_NOTE")
                                    val isWideBox = isNoteQuestion || isPiano

                                    val boxWidth = if (isWideBox) 140.dp else 105.dp
                                    val boxHeight = if (isWideBox) 90.dp else 145.dp

                                    Box(
                                        modifier = Modifier
                                            .width(boxWidth)
                                            .height(boxHeight)
                                            .background(bgColor, RoundedCornerShape(8.dp))
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                // CLICK VÀO HÌNH SẼ PHÁT RA ÂM THANH
                                                var midisToPlay: List<Int>? = null
                                                try {
                                                    when (item.questionType) {
                                                        "CHORD", "PITCH_CHORD" -> {
                                                            try {
                                                                val pos = gson.fromJson(item.imageDataJson, ChordPosition::class.java)
                                                                midisToPlay = pos.midi
                                                            } catch (e: Exception) {
                                                                // Fallback nếu lưu dưới dạng mảng Midi (các bản cũ)
                                                                val typeArray = object : com.google.gson.reflect.TypeToken<List<Int>>() {}.type
                                                                midisToPlay = gson.fromJson(item.imageDataJson, typeArray)
                                                            }
                                                        }
                                                        "NOTE", "PITCH_NOTE" -> {
                                                            try {
                                                                val pos = gson.fromJson(item.imageDataJson, NotePosition::class.java)
                                                                if (pos.midi != -1) {
                                                                    midisToPlay = listOf(pos.midi)
                                                                } else {
                                                                    // Tính toán lại midi nếu nó không được lưu sẵn (-1)
                                                                    val openMidi = if (savedInstrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                                                                    if (pos.stringIdx in openMidi.indices) {
                                                                        midisToPlay = listOf(openMidi[pos.stringIdx] + pos.fret)
                                                                    }
                                                                }
                                                            } catch (e: Exception) {
                                                                // Fallback nếu dữ liệu pitch cũ chỉ lưu Midi Array
                                                                val typeArray = object : com.google.gson.reflect.TypeToken<List<Int>>() {}.type
                                                                midisToPlay = gson.fromJson(item.imageDataJson, typeArray)
                                                            }
                                                        }
                                                    }

                                                    // NẾU TÌM ĐƯỢC MIDI THÌ PHÁT ÂM THANH
                                                    if (midisToPlay != null && midisToPlay.isNotEmpty()) {
                                                        CoreAudioPlayer.playChord(midisToPlay, savedInstrument)
                                                    }
                                                } catch (e: Exception) {
                                                    e.printStackTrace()
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        var parseSuccess = false
                                        var chordPos: ChordPosition? = null
                                        var notePos: NotePosition? = null
                                        var pitchMidis: List<Int>? = null // Dùng để fallback lịch sử cũ

                                        // ... (Đoạn mã vẽ hình bên trong khối Box này giữ nguyên như cũ)
                                        try {
                                            when (item.questionType) {
                                                "CHORD" -> chordPos = gson.fromJson(item.imageDataJson, ChordPosition::class.java)
                                                "PITCH_CHORD" -> {
                                                    try { chordPos = gson.fromJson(item.imageDataJson, ChordPosition::class.java) }
                                                    catch (e: Exception) { pitchMidis = gson.fromJson(item.imageDataJson, Array<Int>::class.java).toList() }
                                                }
                                                "NOTE" -> notePos = gson.fromJson(item.imageDataJson, NotePosition::class.java)
                                                "PITCH_NOTE" -> {
                                                    try { notePos = gson.fromJson(item.imageDataJson, NotePosition::class.java) }
                                                    catch (e: Exception) { pitchMidis = gson.fromJson(item.imageDataJson, Array<Int>::class.java).toList() }
                                                }
                                            }
                                            parseSuccess = true
                                        } catch (e: Exception) {
                                            parseSuccess = false
                                        }

                                        if (!parseSuccess) {
                                            Text("Lỗi ảnh", color = Color.Gray, fontSize = 10.sp)
                                        } else {
                                            val inst = savedInstrument
                                            when (item.questionType) {
                                                "CHORD", "PITCH_CHORD" -> {
                                                    if (chordPos != null) {
                                                        if (inst == "Piano") {
                                                            CompactHistoryPianoDiagram(chordPos!!.midi, tunaGreen)
                                                        } else {
                                                            Box(modifier = Modifier.graphicsLayer { scaleX = 0.7f; scaleY = 0.7f }) {
                                                                FretboardDiagram(item.correctOption, chordPos!!.frets, chordPos!!.fingers, chordPos!!.baseFret, if (inst == "Guitar") 6 else 4, textColor, tunaGreen)
                                                            }
                                                        }
                                                    } else if (pitchMidis != null) {
                                                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = tunaGreen, modifier = Modifier.size(40.dp))
                                                    }
                                                }
                                                "NOTE", "PITCH_NOTE" -> {
                                                    if (notePos != null) {
                                                        if (inst == "Piano") {
                                                            CompactHistoryPianoDiagram(listOf(notePos!!.midi), tunaGreen)
                                                        } else {
                                                            Box(modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = 0.95f; scaleY = 0.95f }) {
                                                                ReviewProportionalNoteFretboard(inst, notePos!!, textColor, tunaGreen)
                                                            }
                                                        }
                                                    } else if (pitchMidis != null) {
                                                        val firstMidi = pitchMidis!!.firstOrNull() ?: 60
                                                        Box(modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = 0.8f; scaleY = 0.8f }) {
                                                            SingleNoteStaffDiagram(firstMidi, inst, textColor, tunaGreen)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedWrongAnswersJson = null }) {
                    Text(if (currentLang == "vi") "Đóng" else "Close", color = tunaGreen, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = bgColor,
            shape = RoundedCornerShape(16.dp),
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false), // THÊM LỆNH NÀY ĐỂ MỞ RỘNG MÀN HÌNH
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
    }

    // --- DIALOG XÁC NHẬN XÓA LỊCH SỬ ---
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = {
                Text(
                    text = if (currentLang == "vi") "Xóa lịch sử" else "Clear History",
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
            },
            text = {
                Text(
                    text = if (currentLang == "vi") "Bạn có chắc chắn muốn xóa toàn bộ lịch sử chơi của phần này không?" else "Are you sure you want to clear all history for this game?",
                    color = textColor,
                    fontSize = 15.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        // 1. Xóa dữ liệu trong bộ nhớ máy (SharedPreferences)
                        val prefs = context.getSharedPreferences("MinigameHistory", Context.MODE_PRIVATE)
                        val localKey = "${instrument ?: "Guitar"}_$gameType"
                        prefs.edit().remove(localKey).apply()

                        // 2. Làm rỗng danh sách trên màn hình
                        historyList = emptyList()

                        // 3. Đóng Dialog
                        showDeleteConfirmDialog = false
                    }
                ) {
                    Text(if (currentLang == "vi") "Xóa" else "Clear", color = Color(0xFFF56C6C), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(if (currentLang == "vi") "Hủy" else "Cancel", color = tunaGreen, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = bgColor,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

// --- GIAO DIỆN CHÍNH MINIGAME HUB ---
@Composable
fun MinigameHubScreen(
    instrument: String?,
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String,
    onNavigateToGame: (String) -> Unit,
    onClose: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    // Thêm biến quản lý trạng thái hiển thị Dialog
    var showUserDialog by remember { mutableStateOf(false) }

    val tabs = listOf(
        Pair(CoreTranslator.getString("tab_games", currentLang), Icons.Default.SportsEsports),
        Pair(CoreTranslator.getString("tab_leaderboard", currentLang), Icons.Default.Leaderboard)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        // --- HEADER BAR CẬP NHẬT ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween // Đẩy các thành phần sang 2 bên
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .background(surfaceColor, CircleShape)
                        .size(36.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = CoreTranslator.getString("hub_title", currentLang),
                    color = tunaGreen,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Hiển thị Avatar khi ở Tab Bảng Xếp Hạng
            if (selectedTab == 1) {
                val account = GoogleSignIn.getLastSignedInAccount(LocalContext.current)
                val photoUrl = account?.photoUrl // Lấy URL ảnh đại diện

                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(tunaGreen.copy(alpha = 0.8f), CircleShape)
                        .border(1.dp, tunaGreen, CircleShape)
                        .clip(CircleShape)
                        .clickable { showUserDialog = true },
                    contentAlignment = Alignment.Center
                ) {
                    if (photoUrl != null) {
                        // Nếu có ảnh đại diện, dùng AsyncImage của Coil để hiển thị
                        AsyncImage(
                            model = photoUrl,
                            contentDescription = "User Avatar",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        // Fallback: Nếu không có ảnh, hiển thị chữ cái đầu
                        Text(
                            text = (account?.displayName?.take(1) ?: "U").uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = bgColor,
            contentColor = tunaGreen,
            indicator = { tabPositions ->
                TabRowDefaults.Indicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = tunaGreen
                )
            }
        ) {
            tabs.forEachIndexed { index, tabInfo ->
                LeadingIconTab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    icon = {
                        Icon(
                            imageVector = tabInfo.second,
                            contentDescription = tabInfo.first,
                            tint = if (selectedTab == index) tunaGreen else Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    text = {
                        Text(
                            text = tabInfo.first,
                            color = if (selectedTab == index) tunaGreen else Color.Gray,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 15.sp
                        )
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (selectedTab == 0) {
                GameSelectionView(
                    instrument = instrument,
                    surfaceColor = surfaceColor,
                    textColor = textColor,
                    tunaGreen = tunaGreen,
                    currentLang = currentLang,
                    onNavigateToGame = onNavigateToGame
                )
            } else {
                LeaderboardView(
                    bgColor = bgColor,
                    surfaceColor = surfaceColor,
                    textColor = textColor,
                    tunaGreen = tunaGreen,
                    currentLang = currentLang,
                    showUserDialog = showUserDialog,         // Truyền state
                    onDismissUserDialog = { showUserDialog = false } // Đóng dialog
                )
            }
        }
    }
}

@Composable
fun GameSelectionView(
    instrument: String?,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String,
    onNavigateToGame: (String) -> Unit
) {
    val chordIcon = when (instrument) {
        "Ukulele" -> CustomIcons.UkuleleChord
        "Piano" -> CustomIcons.PianoChord
        else -> CustomIcons.Chord // Mặc định là Guitar
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            GameCard3D(
                title = CoreTranslator.getString("game_chord_title", currentLang),
                desc = CoreTranslator.getString("game_chord_desc", currentLang),
                icon = chordIcon,
                badgeText = "Chords", // Bạn có thể giữ nguyên badge tiếng Anh hoặc dùng `CoreTranslator` nếu có key
                accentColor = tunaGreen,
                surfaceColor = surfaceColor,
                textColor = textColor,
                onClick = { onNavigateToGame("CHORD") }
            )
        }
        item {
            GameCard3D(
                title = CoreTranslator.getString("game_note_title", currentLang),
                desc = CoreTranslator.getString("game_note_desc", currentLang),
                icon = CustomIcons.MusicScore,
                badgeText = "Notes",
                accentColor = Color(0xFF409EFF),
                surfaceColor = surfaceColor,
                textColor = textColor,
                onClick = { onNavigateToGame("NOTE") }
            )
        }
        item {
            GameCard3D(
                title = CoreTranslator.getString("game_rhythm_title", currentLang),
                desc = CoreTranslator.getString("game_rhythm_desc", currentLang),
                icon = CustomIcons.Metronome,
                badgeText = "Rhythm",
                accentColor = Color(0xFFE6A23C),
                surfaceColor = surfaceColor,
                textColor = textColor,
                onClick = { onNavigateToGame("RHYTHM") }
            )
        }
        item {
            GameCard3D(
                title = CoreTranslator.getString("game_pitch_title", currentLang),
                desc = CoreTranslator.getString("game_pitch_desc", currentLang),
                icon = Icons.Default.Headset,
                badgeText = "Listening",
                accentColor = Color(0xFF9C27B0),
                surfaceColor = surfaceColor,
                textColor = textColor,
                onClick = { onNavigateToGame("PITCH") }
            )
        }
    }
}

@Composable
fun GameCard3D(
    title: String,
    desc: String,
    icon: ImageVector,
    badgeText: String,
    accentColor: Color,
    surfaceColor: Color,
    textColor: Color,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val cardScale by animateFloatAsState(if (isPressed) 0.97f else 1f, animationSpec = tween(50), label = "cardScale")

    // Tự động nhận diện chế độ Sáng/Tối dựa vào màu chữ
    val isLightMode = textColor != Color.White

    // Xử lý viền 3D: Light Mode dùng viền siêu mờ, Dark Mode dùng viền nổi
    val borderBrush = if (isLightMode) {
        Brush.verticalGradient(colors = listOf(Color.White, Color.Gray.copy(alpha = 0.1f)))
    } else {
        Brush.verticalGradient(colors = listOf(Color.White.copy(alpha = 0.15f), Color.Black.copy(alpha = 0.3f)))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(cardScale)
            .border(
                width = 1.dp,
                brush = borderBrush,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable {
                isPressed = true
                onClick()
            },
        // SỬA: Light Mode dùng màu Trắng Tinh 100%, Dark Mode giữ nguyên độ trong suốt 80%
        colors = CardDefaults.cardColors(containerColor = if (isLightMode) surfaceColor else surfaceColor.copy(alpha = 0.8f)),
        shape = RoundedCornerShape(16.dp),
        // SỬA: Bóng đổ nhẹ (3.dp) ở Light Mode cho thanh thoát, Dark Mode bóng đổ mạnh hơn (6.dp)
        elevation = CardDefaults.cardElevation(defaultElevation = if (isLightMode) 3.dp else 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(accentColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = title, color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .background(accentColor.copy(alpha = 0.2f), CircleShape)
                            .padding(horizontal = 10.dp, vertical = 2.dp)
                    ) {
                        Text(text = badgeText, color = accentColor, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = desc, color = textColor.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun LeaderboardView(
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String,
    showUserDialog: Boolean,        // THÊM THAM SỐ NÀY
    onDismissUserDialog: () -> Unit // THÊM THAM SỐ NÀY
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(true) }
    var leaderboardList by remember { mutableStateOf<List<LeaderboardEntry>>(emptyList()) }

    var timeFilter by remember { mutableStateOf("ALL_TIME") }
    var selectedTierFilter by remember { mutableStateOf<String?>(null) }

    val currentGoogleAccount = remember { GoogleSignIn.getLastSignedInAccount(context) }
    val myEmail = currentGoogleAccount?.email ?: ""

    fun getTierInfo(score: Int): Triple<String, Color, Int> {
        return when {
            score >= 8000 -> Triple(CoreTranslator.getString("tier_platinum", currentLang), Color(0xFF00E5FF), 8000)
            score >= 4000 -> Triple(CoreTranslator.getString("tier_gold", currentLang), Color(0xFFFFD700), 8000)
            score >= 2000 -> Triple(CoreTranslator.getString("tier_silver", currentLang), Color(0xFFC0C0C0), 4000)
            score >= 500 -> Triple(CoreTranslator.getString("tier_bronze", currentLang), Color(0xFFB87333), 2000)
            else -> Triple(CoreTranslator.getString("tier_rookie", currentLang), Color(0xFFA1887F), 500)
        }
    }

    fun loadLeaderboardData(filterType: String) {
        isLoading = true
        coroutineScope.launch {
            try {
                val db = FirebaseFirestore.getInstance()
                val orderByField = if (filterType == "ALL_TIME") "score" else getCurrentMonthKey()
                val orderTimeField = if (filterType == "ALL_TIME") "time_total" else "time_${getCurrentMonthKey()}"

                val snapshot = db.collection("GlobalLeaderboard")
                    .orderBy(orderByField, com.google.firebase.firestore.Query.Direction.DESCENDING)
                    .orderBy(orderTimeField, com.google.firebase.firestore.Query.Direction.ASCENDING)
                    // XÓA DÒNG NÀY: .limit(50)
                    .get()
                    .await()

                val realLeaderboard = snapshot.documents.mapIndexed { index, doc ->
                    LeaderboardEntry(
                        rank = index + 1,
                        name = doc.getString("name") ?: "Unknown",
                        email = doc.getString("email") ?: "",
                        score = doc.getLong(orderByField)?.toInt() ?: 0,
                        totalTime = doc.getLong(orderTimeField)?.toInt() ?: 0,
                        avatarUrl = doc.getString("avatarUrl")
                    )
                } // XÓA DÒNG NÀY: .filter { it.score > 0 }

                leaderboardList = realLeaderboard
            } catch (e: Exception) {
                e.printStackTrace()
                leaderboardList = emptyList()
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(timeFilter) {
        loadLeaderboardData(timeFilter)
    }

    val displayedLeaderboard = remember(leaderboardList, selectedTierFilter) {
        if (selectedTierFilter == null) {
            leaderboardList
        } else {
            leaderboardList.filter { entry ->
                val (tierName, _, _) = getTierInfo(entry.score)
                tierName == selectedTierFilter
            }
        }
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = tunaGreen)
        }
    } else {
        Box(modifier = Modifier.fillMaxSize()) {
            // ĐÃ XÓA .padding(bottom = 120.dp) ĐỂ DANH SÁCH KHÔNG BỊ TRỐNG PHẦN DƯỚI
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isAllTime = timeFilter == "ALL_TIME"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isAllTime) surfaceColor else Color.Transparent, RoundedCornerShape(12.dp))
                            .border(1.dp, textColor.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { if (!isAllTime) timeFilter = "ALL_TIME" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isAllTime) textColor else textColor.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(CoreTranslator.getString("all_time_lbl", currentLang), color = if (isAllTime) textColor else textColor.copy(alpha = 0.5f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    val isThisMonth = timeFilter == "THIS_MONTH"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isThisMonth) surfaceColor else Color.Transparent, RoundedCornerShape(12.dp))
                            .border(1.dp, textColor.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { if (!isThisMonth) timeFilter = "THIS_MONTH" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isThisMonth) textColor else textColor.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(CoreTranslator.getString("this_month_lbl", currentLang), color = if (isThisMonth) textColor else textColor.copy(alpha = 0.5f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val tiers = listOf(
                        Triple(CoreTranslator.getString("tier_rookie", currentLang), Color(0xFFA1887F), "🎓"),
                        Triple(CoreTranslator.getString("tier_bronze", currentLang), Color(0xFFB87333), "🥉"),
                        Triple(CoreTranslator.getString("tier_silver", currentLang), Color(0xFFC0C0C0), "🥈"),
                        Triple(CoreTranslator.getString("tier_gold", currentLang), Color(0xFFFFD700), "🥇"),
                        Triple(CoreTranslator.getString("tier_platinum", currentLang), Color(0xFF00E5FF), "💎")
                    )

                    tiers.forEach { (tierName, tierColor, tierEmoji) ->
                        val isSelected = selectedTierFilter == tierName
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) tierColor.copy(alpha = 0.15f) else surfaceColor, RoundedCornerShape(20.dp))
                                .border(1.dp, if (isSelected) tierColor else Color.Transparent, RoundedCornerShape(20.dp))
                                .clickable {
                                    selectedTierFilter = if (selectedTierFilter == tierName) null else tierName
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = tierEmoji, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(tierName, color = if (isSelected) tierColor else textColor.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (displayedLeaderboard.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (selectedTierFilter != null) CoreTranslator.getString("no_tier_data", currentLang).replace("{tier}", selectedTierFilter!!) else CoreTranslator.getString("no_rank_data", currentLang),
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        contentPadding = PaddingValues(bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(displayedLeaderboard) { _, entry ->
                            LeaderboardItem3D(entry, myEmail, surfaceColor, textColor, tunaGreen, currentLang)
                        }
                    }
                }
            }

            // HIỂN THỊ DIALOG THÔNG TIN NGƯỜI CHƠI THAY VÌ BOX Ở ĐÁY MÀN HÌNH
            if (showUserDialog) {
                Dialog(onDismissRequest = onDismissUserDialog) {
                    val myEntry = leaderboardList.find { it.email == myEmail }
                    val myScore = myEntry?.score ?: 0
                    val myRankInt = myEntry?.rank ?: -1
                    val myRankStr = if (myRankInt > 0) myRankInt.toString() else "-"
                    val (myTier, tierColor, nextTierScore) = getTierInfo(myScore)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(surfaceColor, RoundedCornerShape(16.dp))
                            .border(1.dp, tierColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("#$myRankStr", color = textColor, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.width(40.dp))

                            val bottomAvatarBg = when (myRankInt) {
                                1 -> Brush.verticalGradient(listOf(Color(0xFFFF80AB), Color(0xFFF50057)))
                                2 -> Brush.verticalGradient(listOf(Color(0xFF82B1FF), Color(0xFF2979FF)))
                                3 -> Brush.verticalGradient(listOf(Color(0xFFFFD180), Color(0xFFFF9100)))
                                else -> SolidColor(Color.Gray.copy(alpha = 0.5f))
                            }

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(bottomAvatarBg, CircleShape)
                                    .clip(CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                val dialogPhotoUrl = currentGoogleAccount?.photoUrl

                                if (dialogPhotoUrl != null) {
                                    AsyncImage(
                                        model = dialogPhotoUrl,
                                        contentDescription = "User Avatar",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Text(
                                        text = (currentGoogleAccount?.displayName?.take(1) ?: "U").uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(currentGoogleAccount?.displayName ?: CoreTranslator.getString("player_lbl", currentLang), color = textColor, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)

                                val myTierEmoji = when (myTier) {
                                    CoreTranslator.getString("tier_platinum", currentLang) -> "💎"
                                    CoreTranslator.getString("tier_gold", currentLang) -> "🥇"
                                    CoreTranslator.getString("tier_silver", currentLang) -> "🥈"
                                    CoreTranslator.getString("tier_bronze", currentLang) -> "🥉"
                                    else -> "🎓"
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = myTierEmoji, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(myTier, color = tierColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Text("$myScore LP", color = tunaGreen, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        val milestones = listOf(0, 500, 2000, 4000, 8000)
                        val totalSegments = milestones.size - 1
                        var currentSegment = 0
                        var segmentProgress = 0f

                        for (i in 0 until totalSegments) {
                            if (myScore >= milestones[i + 1]) {
                                currentSegment = i + 1
                            } else {
                                currentSegment = i
                                val range = (milestones[i + 1] - milestones[i]).toFloat()
                                segmentProgress = (myScore - milestones[i]) / range
                                break
                            }
                        }

                        val visualProgress = if (myScore >= 8000) 1f else (currentSegment + segmentProgress) / totalSegments

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "🎓", fontSize = 12.sp)
                                Text(text = "🥉", fontSize = 12.sp)
                                Text(text = "🥈", fontSize = 12.sp)
                                Text(text = "🥇", fontSize = 12.sp)
                                Text(text = "💎", fontSize = 12.sp)
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black.copy(alpha = 0.3f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(visualProgress)
                                        .fillMaxHeight()
                                        .background(tierColor)
                                )

                                Row(modifier = Modifier.fillMaxSize()) {
                                    Spacer(modifier = Modifier.weight(1f))
                                    Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(surfaceColor))
                                    Spacer(modifier = Modifier.weight(1f))
                                    Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(surfaceColor))
                                    Spacer(modifier = Modifier.weight(1f))
                                    Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(surfaceColor))
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (myScore >= 8000) {
                            Text(CoreTranslator.getString("max_tier_reached", currentLang), color = textColor.copy(alpha = 0.6f), fontSize = 11.sp)
                        } else {
                            Text("${CoreTranslator.getString("lp_needed_prefix", currentLang)} ${nextTierScore - myScore} ${CoreTranslator.getString("lp_needed_suffix", currentLang)}", color = textColor.copy(alpha = 0.6f), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun LeaderboardItem3D(
    entry: LeaderboardEntry,
    myEmail: String,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String // ĐÃ THÊM DÒNG NÀY ĐỂ NHẬN NGÔN NGỮ
) {
    val isMe = entry.email == myEmail

    val borderBrush = when (entry.rank) {
        1 -> Brush.linearGradient(listOf(Color(0xFFFFDF00), Color(0xFFD4AF37), Color(0xFF996515)))
        2 -> Brush.linearGradient(listOf(Color(0xFFE0E0E0), Color(0xFFBDBDBD), Color(0xFF757575)))
        3 -> Brush.linearGradient(listOf(Color(0xFFFF9E80), Color(0xFFCD7F32), Color(0xFF8D4004)))
        else -> SolidColor(if (isMe) tunaGreen.copy(alpha = 0.5f) else surfaceColor.copy(alpha = 0.5f))
    }

    val bgColor = if (isMe && entry.rank > 3) tunaGreen.copy(alpha = 0.1f) else surfaceColor

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor, RoundedCornerShape(12.dp))
            .border(if (entry.rank <= 3) 2.dp else 1.dp, borderBrush, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(40.dp), contentAlignment = Alignment.CenterStart) {
            when (entry.rank) {
                1 -> Text("👑", fontSize = 24.sp)
                2 -> Text("🏆", fontSize = 22.sp)
                3 -> Text("⭐", fontSize = 22.sp)
                else -> Text("#${entry.rank}", color = textColor.copy(alpha = 0.7f), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        val avatarBg = when (entry.rank) {
            1 -> Brush.verticalGradient(listOf(Color(0xFFFF80AB), Color(0xFFF50057)))
            2 -> Brush.verticalGradient(listOf(Color(0xFF82B1FF), Color(0xFF2979FF)))
            3 -> Brush.verticalGradient(listOf(Color(0xFFFFD180), Color(0xFFFF9100)))
            else -> SolidColor(Color.Gray.copy(alpha = 0.5f))
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .background(avatarBg, CircleShape)
                .clip(CircleShape), // Cần clip để ảnh thành hình tròn
            contentAlignment = Alignment.Center
        ) {
            // Kiểm tra xem user này có URL ảnh không
            if (!entry.avatarUrl.isNullOrEmpty()) {
                AsyncImage(
                    model = entry.avatarUrl,
                    contentDescription = "User Avatar",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                // Nếu không có ảnh hoặc tài khoản cũ chưa cập nhật, hiển thị chữ cái đầu
                Text(
                    text = entry.name.take(1).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = entry.name + (if (isMe) " (" + CoreTranslator.getString("you", currentLang) + ")" else ""),
            color = if (entry.rank == 1) Color(0xFFFFD700) else textColor,
            fontWeight = if (entry.rank <= 3 || isMe) FontWeight.ExtraBold else FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        val scoreColor = when (entry.rank) {
            1 -> Color(0xFFFFD700)
            2 -> Color(0xFFC0C0C0)
            3 -> Color(0xFFCD7F32)
            else -> textColor.copy(alpha = 0.9f)
        }

        // CỘT BÊN PHẢI HIỂN THỊ ĐIỂM + THỜI GIAN
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${entry.score} LP",
                color = scoreColor,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp
            )
            val timeStr = String.format(Locale.getDefault(), "%02d:%02d", entry.totalTime / 60, entry.totalTime % 60)
            Text(
                text = "⏱️ $timeStr",
                color = textColor.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
@Composable
fun CompactHistoryPianoDiagram(
    targetMidis: List<Int>,
    tunaGreen: Color
) {
    if (targetMidis.isEmpty()) return

    val minMidi = targetMidis.minOrNull() ?: 60
    val maxMidi = targetMidis.maxOrNull() ?: 60

    // Cắt mở rộng ra 3-4 bán cung hai bên để lấy trọn vẹn cụm phím
    var startMidi = minMidi - 3
    var endMidi = maxMidi + 4

    val isWhite = { m: Int -> val n = m % 12; n == 0 || n == 2 || n == 4 || n == 5 || n == 7 || n == 9 || n == 11 }
    while (!isWhite(startMidi)) startMidi--
    while (!isWhite(endMidi)) endMidi++

    val whiteKeyMidis = mutableListOf<Int>()
    for (m in startMidi..endMidi) {
        if (isWhite(m)) whiteKeyMidis.add(m)
    }

    // Đảm bảo có tối thiểu 7 phím trắng để form đàn trông tự nhiên, không bị mập
    while (whiteKeyMidis.size < 7) {
        endMidi++
        if (isWhite(endMidi)) whiteKeyMidis.add(endMidi)
    }

    androidx.compose.foundation.Canvas(
        modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 8.dp)
    ) {
        val w = size.width
        val h = size.height
        val keyW = w / whiteKeyMidis.size
        val blackKeyW = keyW * 0.65f
        val blackKeyH = h * 0.6f
        val radius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)

        // 1. VẼ PHÍM TRẮNG
        for (i in whiteKeyMidis.indices) {
            val midi = whiteKeyMidis[i]
            val isTarget = targetMidis.contains(midi)
            val keyColor = if (isTarget) tunaGreen else Color.White

            drawRoundRect(
                color = keyColor,
                topLeft = androidx.compose.ui.geometry.Offset(i * keyW, 0f),
                size = androidx.compose.ui.geometry.Size(keyW, h),
                cornerRadius = radius
            )
            drawRoundRect(
                color = Color.Black,
                topLeft = androidx.compose.ui.geometry.Offset(i * keyW, 0f),
                size = androidx.compose.ui.geometry.Size(keyW, h),
                cornerRadius = radius,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )

            if (isTarget) {
                drawCircle(
                    color = Color.White,
                    radius = keyW * 0.15f,
                    center = androidx.compose.ui.geometry.Offset(i * keyW + keyW / 2, h - 20f)
                )
            }
        }

        // 2. VẼ PHÍM ĐEN
        for (i in 0 until whiteKeyMidis.size - 1) {
            if (whiteKeyMidis[i + 1] - whiteKeyMidis[i] == 2) {
                val blackMidi = whiteKeyMidis[i] + 1
                val isTarget = targetMidis.contains(blackMidi)

                val keyColor = if (isTarget) tunaGreen else Color(0xFF262626)
                val bLeft = (i + 1) * keyW - (blackKeyW / 2f)

                drawRoundRect(
                    color = keyColor,
                    topLeft = androidx.compose.ui.geometry.Offset(bLeft, 0f),
                    size = androidx.compose.ui.geometry.Size(blackKeyW, blackKeyH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                )

                if (isTarget) {
                    drawCircle(
                        color = Color.White,
                        radius = blackKeyW * 0.15f,
                        center = androidx.compose.ui.geometry.Offset(bLeft + blackKeyW / 2, blackKeyH - 16f)
                    )
                }
            }
        }
    }
}
@Composable
fun ReviewProportionalNoteFretboard(
    instrument: String,
    notePos: NotePosition,
    textColor: Color,
    tunaGreen: Color
) {
    val numStrings = if (instrument == "Guitar") 6 else 4
    val baseFret = maxOf(1, notePos.fret - 1)
    val numFretsDisplay = 4

    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp)) {
        val w = size.width
        val h = size.height
        val nutX = w * 0.15f
        val endX = w * 0.95f

        // Công thức chia ngăn theo tỷ lệ chuẩn 12-TET
        val r = Math.pow(2.0, -1.0 / 12.0).toFloat()
        var totalR = 0f
        for (i in 0 until numFretsDisplay) {
            totalR += Math.pow(r.toDouble(), (baseFret + i).toDouble()).toFloat()
        }
        val unit = (endX - nutX) / totalR

        fun getFretX(localFret: Int): Float {
            var x = nutX
            for (i in 0 until localFret) {
                x += unit * Math.pow(r.toDouble(), (baseFret + i).toDouble()).toFloat()
            }
            return x
        }

        val neckW = h * 0.65f
        fun getY(s: Int): Float = (h - neckW) / 2f + s * (neckW / (numStrings - 1))

        // 1. Vẽ chấm tròn (dots)
        val dotColor = textColor.copy(alpha = 0.15f)
        val dotFrets = if (instrument == "Ukulele") listOf(5, 7, 10, 12, 15) else listOf(3, 5, 7, 9, 12, 15)
        for (i in 0 until numFretsDisplay) {
            val actualFret = baseFret + i
            if (actualFret in dotFrets) {
                val midX = (getFretX(i) + getFretX(i + 1)) / 2f
                if (actualFret == 12) {
                    drawCircle(color = dotColor, radius = 10f, center = Offset(midX, getY(1)))
                    drawCircle(color = dotColor, radius = 10f, center = Offset(midX, getY(numStrings - 2)))
                } else {
                    val midY = (getY(0) + getY(numStrings - 1)) / 2f
                    drawCircle(color = dotColor, radius = 12f, center = Offset(midX, midY))
                }
            }
        }

        // 2. Vẽ vạch ngăn đàn (frets)
        for (i in 0..numFretsDisplay) {
            val x = getFretX(i)
            val isNut = (i == 0 && baseFret == 1)
            drawLine(
                color = textColor.copy(alpha = if (isNut) 1f else 0.4f),
                start = Offset(x, getY(0) - if (isNut) 2f else 0f),
                end = Offset(x, getY(numStrings - 1) + if (isNut) 2f else 0f),
                strokeWidth = if (isNut) 12f else 4f
            )
        }

        // 3. Vẽ dây đàn (strings)
        for (s in 0 until numStrings) {
            val stringStrokeWidth = if (instrument == "Guitar") (s + 1) * 1.5f else 2.5f
            drawLine(color = textColor.copy(alpha = 0.7f), start = Offset(nutX, getY(s)), end = Offset(endX, getY(s)), strokeWidth = stringStrokeWidth)
        }

        // 4. Số thứ tự ngăn đàn
        val textPaint = android.graphics.Paint().apply {
            textSize = 28f
            textAlign = android.graphics.Paint.Align.CENTER
            color = android.graphics.Color.GRAY
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        if (baseFret > 1) {
            drawContext.canvas.nativeCanvas.drawText("${baseFret}fr", nutX - 25f, getY(numStrings - 1) + 35f, textPaint)
        }

        // 5. Vẽ nốt nhạc
        val notePaint = android.graphics.Paint().apply {
            textAlign = android.graphics.Paint.Align.CENTER
            color = android.graphics.Color.WHITE
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        if (notePos.fret >= 0 && notePos.stringIdx >= 0) {
            if (notePos.fret == 0) {
                val noteX = nutX - 25f
                val noteY = getY(notePos.stringIdx)
                drawCircle(color = tunaGreen, radius = 20f, center = Offset(noteX, noteY))
                notePaint.textSize = 22f
                drawContext.canvas.nativeCanvas.drawText(notePos.name, noteX, noteY - ((notePaint.descent() + notePaint.ascent()) / 2), notePaint)
            } else {
                val localIndex = notePos.fret - baseFret
                if (localIndex in 0 until numFretsDisplay) {
                    val noteX = (getFretX(localIndex) + getFretX(localIndex + 1)) / 2f
                    val noteY = getY(notePos.stringIdx)

                    // Tự động điều chỉnh kích thước nốt nhạc vừa với độ rộng của ngăn đàn
                    val noteRadius = minOf(26f, (getFretX(localIndex + 1) - getFretX(localIndex)) * 0.35f)

                    drawCircle(color = tunaGreen, radius = noteRadius, center = Offset(noteX, noteY))

                    notePaint.textSize = noteRadius * 1.1f
                    drawContext.canvas.nativeCanvas.drawText(notePos.name, noteX, noteY - ((notePaint.descent() + notePaint.ascent()) / 2), notePaint)
                }
            }
        }
    }
}