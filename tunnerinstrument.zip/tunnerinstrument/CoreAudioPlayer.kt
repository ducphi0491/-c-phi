package ducphi.tunnerinstrument

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import kotlin.math.pow

object CoreAudioPlayer {
    private var soundPool: SoundPool? = null
    private var currentInstrument = ""

    private var soundLowId = -1
    private var soundHighId = -1

    private val activeTrebleStreams = ConcurrentLinkedQueue<Int>()
    private val fastAudioExecutor = Executors.newFixedThreadPool(10)

    fun init() {
        if (soundPool == null) {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            soundPool = SoundPool.Builder()
                .setMaxStreams(28)
                .setAudioAttributes(attributes)
                .build()
        }
    }

    fun loadInstrument(context: Context, instrument: String) {
        if (currentInstrument == instrument) return

        if (soundLowId != -1) soundPool?.unload(soundLowId)
        if (soundHighId != -1) soundPool?.unload(soundHighId)

        currentInstrument = instrument

        if (instrument.contains("Piano")) {
            val pianoResId = context.resources.getIdentifier("piano_c4", "raw", context.packageName)
            if (pianoResId != 0) soundLowId = soundPool?.load(context, pianoResId, 1) ?: -1
            soundHighId = -1
            return
        }

        val prefix = when {
            instrument.contains("Guitar") -> "guitar_"
            instrument.contains("Ukulele") -> "ukulele_"
            instrument.contains("Bass") -> "bass_"
            instrument.contains("Violin") -> "violin_"
            instrument.contains("Saxophone") -> "saxophone_"
            else -> "guitar_"
        }

        val lowResId = context.resources.getIdentifier("${prefix}low", "raw", context.packageName)
        val highResId = context.resources.getIdentifier("${prefix}high", "raw", context.packageName)

        if (lowResId != 0) soundLowId = soundPool?.load(context, lowResId, 1) ?: -1
        if (highResId != 0) soundHighId = soundPool?.load(context, highResId, 1) ?: -1
    }

    fun playChord(midiNotes: List<Int>, instrument: String, volume: Float = 1.0f) {
        CoroutineScope(Dispatchers.Main).launch {
            for (midi in midiNotes) {
                val (baseMidi, soundId) = when {
                    instrument.contains("Bass") -> if (midi <= 33) Pair(23, soundLowId) else Pair(43, soundHighId)
                    instrument.contains("Ukulele") -> if (midi <= 64) Pair(60, soundLowId) else Pair(69, soundHighId)
                    instrument.contains("Violin") -> if (midi <= 62) Pair(55, soundLowId) else Pair(76, soundHighId)
                    instrument.contains("Saxophone") -> Pair(67, soundLowId)
                    instrument.contains("Piano") -> Pair(60, soundLowId)
                    else -> if (midi < 52) Pair(40, soundLowId) else Pair(64, soundHighId)
                }

                if (soundId != -1) {
                    val playbackRate = 2.0.pow((midi - baseMidi) / 12.0).toFloat()
                    soundPool?.play(soundId, volume, volume, 1, 0, playbackRate)
                }

                if (!instrument.contains("Piano") && !instrument.contains("Saxophone")) {
                    delay(250)
                }
            }
        }
    }

    fun playSingleNote(midi: Int, instrument: String, volume: Float = 1.0f) {
        val (baseMidi, soundId) = when {
            instrument.contains("Bass") -> if (midi <= 33) Pair(23, soundLowId) else Pair(43, soundHighId)
            instrument.contains("Ukulele") -> if (midi <= 64) Pair(60, soundLowId) else Pair(69, soundHighId)
            instrument.contains("Violin") -> if (midi <= 62) Pair(55, soundLowId) else Pair(76, soundHighId)
            instrument.contains("Saxophone") -> Pair(67, soundLowId)
            instrument.contains("Piano") -> Pair(60, soundLowId)
            else -> if (midi < 52) Pair(40, soundLowId) else Pair(64, soundHighId)
        }

        if (soundId != -1) {
            val playbackRate = 2.0.pow((midi - baseMidi) / 12.0).toFloat()
            soundPool?.play(soundId, volume, volume, 1, 0, playbackRate)
        }
    }

    // Dừng đuôi âm các nốt treble cũ
    fun stopTrebleStrum() {
        while (activeTrebleStreams.isNotEmpty()) {
            val streamId = activeTrebleStreams.poll() ?: break
            soundPool?.stop(streamId)
        }
    }

    // Alias để tương thích với SongStrumming.kt khi dừng toàn bộ phát
    fun stopPreviousStrum() {
        stopTrebleStrum()
    }

    // Thuật toán quét phím acoustic
    fun playStrumRoll(
        notesWithVolume: List<Pair<Int, Float>>,
        instrument: String,
        isUpstroke: Boolean = false,
        isMute: Boolean = false,
        stringGapMs: Long = 10L
    ) {
        stopTrebleStrum()

        val playParams = notesWithVolume.mapNotNull { (midi, volume) ->
            val (baseMidi, soundId) = when {
                instrument.contains("Bass") -> if (midi <= 33) Pair(23, soundLowId) else Pair(43, soundHighId)
                instrument.contains("Ukulele") -> if (midi <= 64) Pair(60, soundLowId) else Pair(69, soundHighId)
                instrument.contains("Violin") -> if (midi <= 62) Pair(55, soundLowId) else Pair(76, soundHighId)
                instrument.contains("Saxophone") -> Pair(67, soundLowId)
                instrument.contains("Piano") -> Pair(60, soundLowId)
                else -> if (midi < 52) Pair(40, soundLowId) else Pair(64, soundHighId)
            }

            if (soundId != -1) {
                val playbackRate = 2.0.pow((midi - baseMidi) / 12.0).toFloat()
                Triple(soundId, volume, playbackRate)
            } else null
        }

        fastAudioExecutor.execute {
            playParams.forEachIndexed { index, (soundId, volume, rate) ->
                val finalVol = if (isMute) volume * 0.35f else volume
                val streamId = soundPool?.play(soundId, finalVol, finalVol, 1, 0, rate) ?: 0

                if (streamId != 0 && index >= playParams.size - 3) {
                    activeTrebleStreams.add(streamId)
                }

                if (isMute && streamId != 0) {
                    fastAudioExecutor.execute {
                        Thread.sleep(35)
                        soundPool?.stop(streamId)
                    }
                }

                if (!isMute && playParams.size > 1 && index < playParams.size - 1) {
                    Thread.sleep(stringGapMs)
                }
            }
        }
    }

    fun playSimultaneousNotes(notesWithVolume: List<Pair<Int, Float>>, instrument: String) {
        val playParams = notesWithVolume.mapNotNull { (midi, volume) ->
            val (baseMidi, soundId) = when {
                instrument.contains("Bass") -> if (midi <= 33) Pair(23, soundLowId) else Pair(43, soundHighId)
                instrument.contains("Ukulele") -> if (midi <= 64) Pair(60, soundLowId) else Pair(69, soundHighId)
                instrument.contains("Violin") -> if (midi <= 62) Pair(55, soundLowId) else Pair(76, soundHighId)
                instrument.contains("Saxophone") -> Pair(67, soundLowId)
                instrument.contains("Piano") -> Pair(60, soundLowId)
                else -> if (midi < 52) Pair(40, soundLowId) else Pair(64, soundHighId)
            }

            if (soundId != -1) {
                val playbackRate = 2.0.pow((midi - baseMidi) / 12.0).toFloat()
                Triple(soundId, volume, playbackRate)
            } else null
        }

        playParams.forEach { (soundId, volume, rate) ->
            fastAudioExecutor.execute {
                soundPool?.play(soundId, volume, volume, 1, 0, rate)
            }
        }
    }

    fun release() {
        soundPool?.release()
        soundPool = null
        fastAudioExecutor.shutdown()
    }
}