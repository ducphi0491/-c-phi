package ducphi.tunnerinstrument

import android.media.AudioAttributes
import android.media.SoundPool
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import androidx.compose.material.icons.filled.Lock
data class RhythmNote(val duration: Float, val isRest: Boolean = false)

data class RhythmExercise(
    val id: Int,
    val name: String,
    val category: String,
    val categoryDesc: String,
    val notes: List<RhythmNote>,
    val defaultBpm: Float = 75f,
    val timeSig: String = "4/4"
)

enum class RhythmPhase { PREPARE, IDLE, LISTEN, TAP, EVALUATE }
@Composable
fun RhythmTapScreen(
    instrument: String = "Guitar", // SỬA Ở ĐÂY: Thêm biến nhạc cụ
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String,
    onClose: () -> Unit,
    startDirectlyInGame: Boolean = false
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prefs = context.getSharedPreferences("RhythmProgress", android.content.Context.MODE_PRIVATE)
    var unlockedExerciseIndex by remember { mutableIntStateOf(prefs.getInt("rhythm_unlocked_index", 0)) }

    val exercises = remember(currentLang) {
        listOf(
            RhythmExercise(1, CoreTranslator.getString("ex_4_quarter", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_rhythm_steady", currentLang), listOf(RhythmNote(1f), RhythmNote(1f), RhythmNote(1f), RhythmNote(1f))),
            RhythmExercise(2, CoreTranslator.getString("ex_2_eighth", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(1f), RhythmNote(1f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(1f))),
            RhythmExercise(3, CoreTranslator.getString("ex_rest_eighth", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(1f), RhythmNote(1f), RhythmNote(0.5f, isRest = true), RhythmNote(0.5f), RhythmNote(1f))),
            RhythmExercise(4, CoreTranslator.getString("ex_rest_3_eighth", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(1f), RhythmNote(0.5f, isRest = true), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(1f))),
            RhythmExercise(5, CoreTranslator.getString("ex_combo_eighth", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(1f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(1f), RhythmNote(0.5f), RhythmNote(0.5f))),
            RhythmExercise(6, CoreTranslator.getString("ex_group_4_eighth", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(1f), RhythmNote(1f))),
            RhythmExercise(7, CoreTranslator.getString("ex_2_eighth_34", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(1f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(1f)), timeSig = "3/4"),
            RhythmExercise(8, CoreTranslator.getString("ex_rest_eighth_34", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(1f), RhythmNote(0.5f, isRest = true), RhythmNote(0.5f), RhythmNote(1f)), timeSig = "3/4"),
            RhythmExercise(9, CoreTranslator.getString("ex_rest_eighth_3", currentLang), CoreTranslator.getString("cat_basic", currentLang), CoreTranslator.getString("desc_eighth_rest", currentLang), listOf(RhythmNote(0.5f, isRest = true), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(1f)), timeSig = "3/4"),

            RhythmExercise(12, CoreTranslator.getString("ex_syncopation", currentLang), CoreTranslator.getString("cat_adv", currentLang), CoreTranslator.getString("desc_reflex", currentLang), listOf(RhythmNote(0.5f), RhythmNote(1f), RhythmNote(0.5f), RhythmNote(1f), RhythmNote(1f))),
            RhythmExercise(13, CoreTranslator.getString("ex_full_eighth", currentLang), CoreTranslator.getString("cat_adv", currentLang), CoreTranslator.getString("desc_reflex", currentLang), listOf(RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f), RhythmNote(0.5f))),

            RhythmExercise(14, CoreTranslator.getString("ex_4_sixteenth", currentLang), CoreTranslator.getString("cat_sixteenth", currentLang), CoreTranslator.getString("desc_sixteenth", currentLang), listOf(RhythmNote(1f), RhythmNote(1f), RhythmNote(0.25f), RhythmNote(0.25f), RhythmNote(0.25f), RhythmNote(0.25f), RhythmNote(1f))),
            RhythmExercise(15, CoreTranslator.getString("ex_eighth_2_sixteenth", currentLang), CoreTranslator.getString("cat_sixteenth", currentLang), CoreTranslator.getString("desc_sixteenth", currentLang), listOf(RhythmNote(1f), RhythmNote(1f), RhythmNote(0.5f), RhythmNote(0.25f), RhythmNote(0.25f), RhythmNote(1f)))
        )
    }
    // === CHÈN THÊM ĐOẠN NÀY ĐỂ TỰ ĐỘNG ĐỒNG BỘ Ổ KHÓA BỊ LỆCH ===
    LaunchedEffect(Unit) {
        var calculatedUnlock = 0
        for (i in 0 until exercises.size - 1) {
            val score = prefs.getInt("rhythm_score_${exercises[i].id}", 0)
            if (score >= 8) {
                calculatedUnlock = i + 1 // Nếu bài hiện tại >= 8 điểm, mở bài tiếp theo
            } else {
                break // Chưa qua bài này thì không xét tiếp các bài sau
            }
        }
        if (calculatedUnlock > unlockedExerciseIndex) {
            unlockedExerciseIndex = calculatedUnlock
            prefs.edit().putInt("rhythm_unlocked_index", unlockedExerciseIndex).apply()
        }
    }
    // ============================================================

    var showMenuList by remember { mutableStateOf(!startDirectlyInGame) }

    // Tự động BẬT chế độ Thực hành (Bỏ qua Nghe Mẫu) nếu vào từ Minigame
    var isPracticeOnly by remember { mutableStateOf(startDirectlyInGame) }

    // Sinh ra 10 bài tập liên tiếp: Trộn các bài cơ bản lên trước, bài khó lên sau
    var selectedExercise by remember {
        // Luôn luôn bắt đầu từ bài số 1 (Dễ nhất: 4 nốt đen)
        mutableStateOf(exercises[0])
    }

    var currentExerciseNotes by remember { mutableStateOf(selectedExercise.notes) }
    var currentBpm by remember { mutableFloatStateOf(selectedExercise.defaultBpm) }

    // 1. Biến đếm thời gian
    var totalElapsedTime by remember { mutableIntStateOf(0) }

    // 2. Khai báo DUY NHẤT một lần currentPhase
    var currentPhase by remember { mutableStateOf(if (startDirectlyInGame) RhythmPhase.PREPARE else RhythmPhase.IDLE) }

    // 3. Luồng đếm thời gian
    LaunchedEffect(currentPhase) {
        if (currentPhase != RhythmPhase.IDLE && currentPhase != RhythmPhase.PREPARE) {
            while (true) {
                delay(1000L)
                totalElapsedTime++
            }
        }
    }

    // --- BIẾN TRẠNG THÁI CHẤM ĐIỂM ---
    var correctRounds by remember { mutableIntStateOf(0) }
    var showResultDialog by remember { mutableStateOf(false) }
    var currentRound by remember { mutableIntStateOf(1) }

    var hitResults by remember { mutableStateOf<List<Boolean?>>(List(currentExerciseNotes.size) { null }) }
    var activeNoteIndex by remember { mutableIntStateOf(-1) }

    var isTappedVisually by remember { mutableStateOf(false) }
    var hasStartedTapping by remember { mutableStateOf(false) }
    var firstTapTime by remember { mutableLongStateOf(0L) }

    val soundPool = remember {
        val attr = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        SoundPool.Builder().setMaxStreams(5).setAudioAttributes(attr).build()
    }

    val metronomeTickId = remember { soundPool.load(context, R.raw.metronome_weak, 1) }
    val noteTapId = remember { soundPool.load(context, R.raw.hit_sound, 1) }

    DisposableEffect(Unit) { onDispose { soundPool.release() } }

    if (showMenuList) {
        Column(modifier = Modifier.fillMaxSize().background(bgColor).padding(top = 16.dp)) {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose, modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(CoreTranslator.getString("practice_rhythm_title", currentLang), color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(16.dp))
            val groupedExercises = exercises.groupBy { it.category }

            LazyColumn(
                modifier = Modifier.fillMaxSize().background(surfaceColor, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).padding(horizontal = 20.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                groupedExercises.forEach { (category, list) ->
                    item {
                        // Bỏ khóa toàn bộ danh mục, chỉ hiển thị tiêu đề bình thường
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(category, color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(list.first().categoryDesc, color = textColor.copy(alpha = 0.7f), fontSize = 13.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            list.forEach { exercise ->
                                // TÍNH TOÁN LOGIC KHÓA CHO TỪNG BÀI:
                                // Nếu vị trí của bài này trong tổng danh sách > vị trí đã mở khóa -> Khóa
                                val exerciseIndex = exercises.indexOf(exercise)
                                val isExerciseLocked = exerciseIndex > unlockedExerciseIndex

                                // ĐỌC ĐIỂM CAO NHẤT TỪ BỘ NHỚ
                                val highScore = prefs.getInt("rhythm_score_${exercise.id}", 0)

                                Row(
                                    modifier = Modifier.fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .then(
                                            if (!isExerciseLocked) {
                                                Modifier.clickable {
                                                    selectedExercise = exercise
                                                    currentExerciseNotes = exercise.notes
                                                    currentBpm = exercise.defaultBpm
                                                    hitResults = List(exercise.notes.size) { null }
                                                    currentRound = 1
                                                    correctRounds = 0
                                                    currentPhase = RhythmPhase.IDLE
                                                    showMenuList = false
                                                }
                                            } else Modifier
                                        )
                                        .padding(vertical = 12.dp)
                                        .graphicsLayer {
                                            alpha = if (isExerciseLocked) 0.5f else 1f
                                        },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier.size(40.dp)
                                            .background(textColor.copy(alpha = 0.1f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            if (isExerciseLocked) Icons.Default.Lock else Icons.Default.Hearing,
                                            contentDescription = null,
                                            tint = if (isExerciseLocked) textColor.copy(alpha = 0.5f) else tunaGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            exercise.name,
                                            color = textColor,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "${exercise.defaultBpm.toInt()} BPM · ${exercise.timeSig}",
                                            color = textColor.copy(alpha = 0.7f),
                                            fontSize = 12.sp
                                        )
                                    }

                                    // --- HIỂN THỊ TIẾN TRÌNH Ở BÊN PHẢI ---
                                    if (isExerciseLocked) {
                                        // Nếu bị khóa thì hiện thông báo yêu cầu
                                        Text(
                                            CoreTranslator.getString("require_score_msg", currentLang), // Sửa ở đây
                                            color = textColor.copy(alpha = 0.5f), fontSize = 12.sp, fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (highScore >= 8) {
                                                // Nếu đã qua ải (>= 8 điểm)
                                                Text(
                                                    CoreTranslator.getString("completed_msg", currentLang), // Sửa ở đây
                                                    color = tunaGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold
                                                )
                                            } else {
                                                // Nếu đang chơi dang dở (ví dụ 2/10)
                                                Text(
                                                    "$highScore/10 🎯",
                                                    color = tunaGreen,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Icon(
                                                Icons.Default.ChevronRight,
                                                contentDescription = null,
                                                tint = textColor.copy(alpha = 0.5f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return
    }

    if (currentPhase == RhythmPhase.PREPARE) {
        MinigamePrepareView(
            title = if (currentLang == "vi") "Bậc Thầy Gõ Nhịp" else "Rhythm Master",
            gameType = "RHYTHM",
            bgColor = bgColor,
            surfaceColor = surfaceColor,
            textColor = textColor,
            tunaGreen = tunaGreen,
            currentLang = currentLang,
            onPlay = { currentPhase = if (isPracticeOnly) RhythmPhase.TAP else RhythmPhase.LISTEN },
            onClose = onClose
        )
        return
    }

    val msPerBeat = remember(currentBpm) { (60000f / currentBpm).toLong() }
    val toleranceMs = 150L

    val expectedHitTimesMs = remember(currentExerciseNotes, msPerBeat) {
        var accumulated = 0f
        currentExerciseNotes.map { note ->
            val time = (accumulated * msPerBeat).toLong()
            accumulated += note.duration
            time
        }
    }

    val totalDurationMs = remember(currentExerciseNotes, msPerBeat) {
        (currentExerciseNotes.sumOf { it.duration.toDouble() }.toFloat() * msPerBeat).toLong() + msPerBeat
    }

    fun shuffleNotes(originalNotes: List<RhythmNote>): List<RhythmNote> {
        val chunks = mutableListOf<List<RhythmNote>>()
        var currentChunk = mutableListOf<RhythmNote>()
        var currentSum = 0f
        for (n in originalNotes) {
            currentChunk.add(n)
            currentSum += n.duration
            if (currentSum >= 0.95f) {
                chunks.add(currentChunk)
                currentChunk = mutableListOf()
                currentSum = 0f
            }
        }
        if (currentChunk.isNotEmpty()) chunks.add(currentChunk)
        return chunks.shuffled().flatten()
    }

    LaunchedEffect(currentPhase) {
        when (currentPhase) {
            RhythmPhase.LISTEN -> {
                hitResults = List(currentExerciseNotes.size) { null }
                val startTime = System.currentTimeMillis()

                expectedHitTimesMs.forEachIndexed { index, timeOffset ->
                    val note = currentExerciseNotes[index]
                    val targetTime = startTime + timeOffset
                    val sleepTime = targetTime - System.currentTimeMillis()
                    if (sleepTime > 0) delay(sleepTime)

                    if (!note.isRest) {
                        soundPool.play(metronomeTickId, 1f, 1f, 1, 0, 1f)
                        activeNoteIndex = index
                        coroutineScope.launch {
                            delay(150)
                            if (activeNoteIndex == index) activeNoteIndex = -1
                        }
                        val newStates = hitResults.toMutableList()
                        newStates[index] = true
                        hitResults = newStates
                    }
                }

                val remain = (startTime + totalDurationMs) - System.currentTimeMillis()
                if (remain > 0) delay(remain)

                currentPhase = RhythmPhase.TAP
            }

            RhythmPhase.TAP -> {
                hitResults = currentExerciseNotes.map { if (it.isRest) true else null }
                hasStartedTapping = false

                launch {
                    while (isActive && currentPhase == RhythmPhase.TAP) {
                        if (hasStartedTapping) {
                            val now = System.currentTimeMillis()
                            var allDone = true

                            for (i in 0 until expectedHitTimesMs.size) {
                                if (hitResults[i] == null && !currentExerciseNotes[i].isRest) {
                                    val expireTime = firstTapTime + expectedHitTimesMs[i] + toleranceMs
                                    if (now > expireTime) {
                                        val newStates = hitResults.toMutableList()
                                        newStates[i] = false
                                        hitResults = newStates
                                    } else {
                                        allDone = false
                                    }
                                }
                            }

                            if (allDone || !hitResults.contains(null)) {
                                delay(500) // Nghỉ 0.5s để xem kết quả xanh/đỏ trước khi sang vòng mới
                                currentPhase = RhythmPhase.EVALUATE
                                break
                            }
                        }
                        delay(50)
                    }
                }
            }
            RhythmPhase.EVALUATE -> {
                // CHẤM ĐIỂM: Nếu không có nốt nào sai (false) và không bị bỏ lỡ (null), cộng 1 vòng đúng
                val isPerfect = !hitResults.contains(false) && !hitResults.contains(null)
                if (isPerfect) {
                    correctRounds++
                }
                // ĐÃ XÓA LOGIC TỰ ĐỘNG CHUYỂN VÒNG (AUTO-NEXT). CHỜ NGƯỜI DÙNG BẤM NÚT "TIẾP THEO".
            }
            else -> {}
        }
    }

    val handleTap = {
        if (currentPhase == RhythmPhase.TAP) {
            isTappedVisually = true
            coroutineScope.launch {
                delay(100)
                isTappedVisually = false
            }

            soundPool.play(noteTapId, 1f, 1f, 1, 0, 1f)

            if (!hasStartedTapping) {
                hasStartedTapping = true

                val firstNoteIdx = currentExerciseNotes.indexOfFirst { !it.isRest }
                if (firstNoteIdx != -1) {
                    firstTapTime = System.currentTimeMillis() - expectedHitTimesMs[firstNoteIdx]

                    val newStates = hitResults.toMutableList()
                    newStates[firstNoteIdx] = true
                    hitResults = newStates

                    activeNoteIndex = firstNoteIdx
                    coroutineScope.launch {
                        delay(150)
                        if (activeNoteIndex == firstNoteIdx) activeNoteIndex = -1
                    }
                }
            } else {
                val tapTimeOffset = System.currentTimeMillis() - firstTapTime
                var closestIndex = -1
                var minDiff = Long.MAX_VALUE

                for (i in expectedHitTimesMs.indices) {
                    if (hitResults[i] == null && !currentExerciseNotes[i].isRest) {
                        val diff = abs(expectedHitTimesMs[i] - tapTimeOffset)
                        if (diff < minDiff) {
                            minDiff = diff
                            closestIndex = i
                        }
                    }
                }

                // [ĐÃ SỬA LỖI SPAM]: Nếu gõ bậy, phạt thành 'false' ngay lập tức
                if (closestIndex != -1) {
                    val newStates = hitResults.toMutableList()
                    if (minDiff <= toleranceMs) {
                        newStates[closestIndex] = true // Gõ chuẩn
                    } else {
                        newStates[closestIndex] = false // Gõ trượt/Spam bừa -> Đánh dấu sai (Đỏ)
                    }
                    hitResults = newStates

                    activeNoteIndex = closestIndex
                    coroutineScope.launch {
                        delay(150)
                        if (activeNoteIndex == closestIndex) activeNoteIndex = -1
                    }
                }
            }
        }
    }

    val activeNoteScale by animateFloatAsState(
        targetValue = if (activeNoteIndex != -1) 1.5f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "noteBounce"
    )

    Column(
        modifier = Modifier.fillMaxSize().background(bgColor).padding(top = 16.dp, bottom = 32.dp, start = 16.dp, end = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
// --- TOP BAR ---
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = { if (startDirectlyInGame) onClose() else showMenuList = true },
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor) }

            Text(
                text = selectedExercise.name,
                color = textColor,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Đưa nút Chốt điểm lên góc phải, thay cho khoảng trống Spacer cũ
            Spacer(modifier = Modifier.size(36.dp)) // Khôi phục lại khoảng trống, xóa nút dư thừa
        }

        // ====> THÊM MỚI: THANH THỐNG KÊ (ĐỒNG NHẤT VỚI CÁC GAME KHÁC) <====
        Spacer(modifier = Modifier.height(16.dp))

        // Logic tính toán điểm: Cập nhật tổng số câu ngay khi đang ở pha Evaluate
        val totalAnswered = if (currentPhase == RhythmPhase.EVALUATE) currentRound else currentRound - 1
        val wrongCount = maxOf(0, totalAnswered - correctRounds)
        val accuracy = if (totalAnswered == 0) 0 else (correctRounds * 100) / totalAnswered
        val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", totalElapsedTime / 60, totalElapsedTime % 60)

        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val statModifier = Modifier.background(surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp)).border(1.dp, textColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 6.dp)
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("⏱️", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text(timeString, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("✅", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text("$correctRounds", color = tunaGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("❌", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text("$wrongCount", color = Color(0xFFF56C6C), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("🎯", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text("$accuracy%", color = Color(0xFF409EFF), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }

        if (startDirectlyInGame) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${CoreTranslator.getString("current_round_lbl", currentLang)} $currentRound", color = textColor.copy(alpha = 0.7f), fontWeight = FontWeight.Bold) // Sửa ở đây
            }
        }
        // =================================================================

        Spacer(modifier = Modifier.weight(1f))

        // --- KHUNG HIỂN THỊ NỐT NHẠC KÈM NÚT LOA CHUYỂN CHẾ ĐỘ ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(surfaceColor, RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val statusColor = if (currentPhase == RhythmPhase.LISTEN) Color(0xFF9C27B0) else tunaGreen
                val statusText = when (currentPhase) {
                    RhythmPhase.PREPARE -> CoreTranslator.getString("status_prepare", currentLang)
                    RhythmPhase.IDLE -> CoreTranslator.getString("status_ready", currentLang)
                    RhythmPhase.LISTEN -> CoreTranslator.getString("status_listen", currentLang)
                    RhythmPhase.TAP -> if (!hasStartedTapping) CoreTranslator.getString("status_tap_first", currentLang) else CoreTranslator.getString("status_tap_again", currentLang)
                    RhythmPhase.EVALUATE -> CoreTranslator.getString("status_evaluate", currentLang)
                }
                val roundText = CoreTranslator.getString("round", currentLang)

                Text("$roundText $currentRound - $statusText", color = statusColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                Spacer(modifier = Modifier.height(16.dp))

                RhythmSheetCanvas(
                    notes = currentExerciseNotes,
                    hitResults = hitResults,
                    activeNoteIndex = activeNoteIndex,
                    activeNoteScale = activeNoteScale,
                    tunaGreen = tunaGreen,
                    textColor = textColor,
                    modifier = Modifier.fillMaxWidth().height(180.dp).padding(horizontal = 24.dp)
                )
            }
            // NÚT BẬT/TẮT CHẾ ĐỘ NGHE MẪU (THAY THẾ CHO CÔNG TẮC)
            IconButton(
                onClick = {
                    isPracticeOnly = !isPracticeOnly
                    val msg = if (isPracticeOnly) {
                        CoreTranslator.getString("toast_listen_disabled", currentLang).ifEmpty { if (currentLang == "vi") "Đã tắt chế độ nghe" else "Listen phase disabled" }
                    } else {
                        CoreTranslator.getString("toast_listen_enabled", currentLang).ifEmpty { if (currentLang == "vi") "Đã bật chế độ nghe" else "Listen phase enabled" }
                    }
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                Icon(
                    imageVector = if (isPracticeOnly) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                    contentDescription = "Toggle Listen Phase",
                    tint = if (isPracticeOnly) textColor.copy(alpha = 0.5f) else tunaGreen
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // --- THANH KÉO BPM (CHỈ HIỂN THỊ KHI Ở TRẠNG THÁI CHỜ - IDLE) ---
        if (currentPhase == RhythmPhase.IDLE) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${currentBpm.toInt()} BPM", color = textColor.copy(alpha = 0.8f), fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.width(64.dp))
                Slider(
                    value = currentBpm,
                    onValueChange = { currentBpm = it },
                    valueRange = 40f..120f,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = tunaGreen,
                        activeTrackColor = tunaGreen.copy(alpha = 0.8f),
                        inactiveTrackColor = surfaceColor
                    )
                )
            }
            Spacer(modifier = Modifier.weight(0.3f))
        }

        // --- KHU VỰC BÀN CHÂN DẬM NHỊP + MẶT SÀN ---
        // Mặt sàn được đặt trong cùng Box với bàn chân nên luôn đúng vị trí,
        // chỉ xuất hiện ở pha LISTEN và không lọt sang trang danh sách bài tập.
        val practiceFootBlue = Color(0xFF79C9FF)
        val floorImpact by animateFloatAsState(
            targetValue = if (
                currentPhase == RhythmPhase.LISTEN && activeNoteIndex != -1
            ) 1f else 0f,
            animationSpec = tween(
                durationMillis = if (activeNoteIndex != -1) 70 else 260,
                easing = FastOutSlowInEasing
            ),
            label = "practiceFloorImpact"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.animation.AnimatedVisibility(
                visible = currentPhase == RhythmPhase.LISTEN,
                enter = fadeIn(),
                exit = fadeOut(animationSpec = tween(300))
            ) {
                Box(
                    modifier = Modifier
                        .width(190.dp)
                        .height(80.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Với bàn chân 70dp căn đáy, đường đế giày nằm ở khoảng y = 66dp.
                        // Đặt mặt sàn đúng tại điểm này để gót chân giữ nguyên điểm tiếp xúc
                        // còn mũi chân có thể nâng lên/hạ xuống tự nhiên.
                        val floorY = 66.dp.toPx()
                        val startX = size.width * 0.08f
                        val endX = size.width * 0.92f

                        // Bóng dưới mặt sàn tạo cảm giác có chiều sâu.
                        drawLine(
                            color = Color.Black.copy(alpha = 0.52f),
                            start = Offset(startX, floorY + 4.dp.toPx()),
                            end = Offset(endX, floorY + 4.dp.toPx()),
                            strokeWidth = 7.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Quầng sáng lan theo nhịp dậm.
                        drawLine(
                            color = practiceFootBlue.copy(
                                alpha = 0.14f + floorImpact * 0.24f
                            ),
                            start = Offset(startX, floorY + 1.dp.toPx()),
                            end = Offset(endX, floorY + 1.dp.toPx()),
                            strokeWidth = (7f + floorImpact * 3f).dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Đường mặt sàn xanh dương nhẹ.
                        drawLine(
                            color = practiceFootBlue.copy(
                                alpha = 0.72f + floorImpact * 0.28f
                            ),
                            start = Offset(startX, floorY),
                            end = Offset(endX, floorY),
                            strokeWidth = (2.2f + floorImpact * 1.4f).dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Vệt phản sáng ở vùng tiếp xúc của bàn chân.
                        drawLine(
                            color = Color.White.copy(
                                alpha = 0.18f + floorImpact * 0.48f
                            ),
                            start = Offset(size.width * 0.34f, floorY - 1.dp.toPx()),
                            end = Offset(size.width * 0.66f, floorY - 1.dp.toPx()),
                            strokeWidth = 1.1.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    AnimatedFootCanvas(
                        activeNoteIndex = activeNoteIndex,
                        isPlaying = currentPhase == RhythmPhase.LISTEN,
                        color = practiceFootBlue,
                        modifier = Modifier
                            .size(70.dp)
                            .align(Alignment.BottomCenter)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(0.7f))

        // --- BIẾN TRẠNG THÁI CHO HIỆU ỨNG NÚT BẤM ---
        val btnScale by animateFloatAsState(if (isTappedVisually) 0.95f else 1f, animationSpec = tween(50), label = "btnScale")
        val isIdleState = currentPhase == RhythmPhase.IDLE

        // --- KHU VỰC CHỨA NÚT TAP VÀ BÀN TAY HƯỚNG DẪN ---
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            // 1. Nút chính PLAY / TAP
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .scale(btnScale)
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        brush = if (isTappedVisually) SolidColor(Color(0xFF5E35B1))
                        else if (isIdleState) Brush.verticalGradient(listOf(Color(0xFF4CAF50), Color(0xFF2E7D32)))
                        else Brush.verticalGradient(listOf(Color(0xFF9575CD), Color(0xFF673AB7)))
                    )
                    .border(
                        width = 2.dp,
                        brush = if (isTappedVisually) SolidColor(Color.Transparent)
                        else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Black.copy(alpha = 0.3f))),
                        shape = RoundedCornerShape(32.dp)
                    )
                    .pointerInput(currentPhase) {
                        detectTapGestures(onPress = {
                            if (currentPhase == RhythmPhase.IDLE) {
                                isTappedVisually = true
                                coroutineScope.launch {
                                    delay(100)
                                    isTappedVisually = false
                                    // Reset trạng thái (Vì đã vô hạn nên chỉ cần reset nếu không phải là Minigame)
                                    if (!startDirectlyInGame && currentRound >= 10) {
                                        currentRound = 1
                                        correctRounds = 0
                                    }
                                    currentPhase = if (isPracticeOnly) RhythmPhase.TAP else RhythmPhase.LISTEN
                                }
                            } else if (currentPhase == RhythmPhase.TAP) {
                                handleTap()
                            }
                        })
                    },
                contentAlignment = Alignment.Center
            ) {
                if (isIdleState) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "PLAY",
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                    }
                } else {
                    Text(
                        if (currentPhase == RhythmPhase.LISTEN) CoreTranslator.getString("listen_dots", currentLang).ifEmpty { if (currentLang == "vi") "NGHE..." else "LISTEN..." } else "TAP",
                        color = if (isTappedVisually) Color.White.copy(alpha = 0.6f) else Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                }
            }

            // 2. Bàn tay hướng dẫn nảy nhẹ chỉ vào nút TAP
            val showHand = currentPhase == RhythmPhase.TAP && !hasStartedTapping

            val infiniteTransition = rememberInfiniteTransition(label = "handBounce")
            val handOffsetY by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 15f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "handOffsetY"
            )

            androidx.compose.animation.AnimatedVisibility(
                visible = showHand,
                enter = fadeIn(),
                exit = fadeOut(animationSpec = tween(200)),
                modifier = Modifier.offset(y = 45.dp + handOffsetY.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = "Hand Icon",
                    tint = tunaGreen,
                    modifier = Modifier.size(60.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (currentPhase == RhythmPhase.EVALUATE) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ================= NÚT DỪNG LẠI =================
                Button(
                    onClick = {
                        // CHỈ LƯU LÊN BẢNG XẾP HẠNG NẾU ĐANG CHƠI MINIGAME
                        if (startDirectlyInGame) {
                            // SỬA Ở ĐÂY: Thêm instrument vào vị trí thứ 2
                            saveGameHistory(context, instrument, "RHYTHM", correctRounds, currentRound, totalElapsedTime)
                        }

                        // LƯU ĐIỂM CAO NHẤT ĐỂ MỞ KHÓA BÀI TẬP (Vẫn giữ cho chế độ tập luyện)
                        val currentHS = prefs.getInt("rhythm_score_${selectedExercise.id}", 0)
                        if (correctRounds > currentHS) {
                            prefs.edit().putInt("rhythm_score_${selectedExercise.id}", correctRounds).apply()
                        }

                        // LOGIC MỞ KHÓA BÀI TẬP NGAY CẢ KHI BẤM DỪNG SỚM
                        if (correctRounds >= 8) {
                            val currentIndex = exercises.indexOf(selectedExercise)
                            if (unlockedExerciseIndex <= currentIndex && currentIndex < exercises.size - 1) {
                                unlockedExerciseIndex = currentIndex + 1
                                prefs.edit().putInt("rhythm_unlocked_index", unlockedExerciseIndex).apply()
                                Toast.makeText(context, CoreTranslator.getString("unlock_success_toast", currentLang), Toast.LENGTH_LONG).show()
                            }
                        }
                        showResultDialog = true
                        currentPhase = RhythmPhase.IDLE
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF56C6C)),
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(CoreTranslator.getString("stop_btn", currentLang), color = Color.White, fontWeight = FontWeight.Bold)
                }

                // ================= NÚT TIẾP THEO =================
                Button(
                    onClick = {
                        if (startDirectlyInGame || currentRound < 10) {
                            currentRound++
                            if (startDirectlyInGame) {
                                if (currentRound <= exercises.size) selectedExercise = exercises[currentRound - 1]
                                else selectedExercise = exercises.filter { it.category != CoreTranslator.getString("cat_basic", currentLang) }.ifEmpty { exercises }.random()
                                currentBpm = if (currentRound > 5) minOf(150f, currentBpm + 3f) else selectedExercise.defaultBpm

                                // [ĐÃ SỬA]: BẮT BUỘC PHẢI GÁN LẠI NỐT NHẠC ĐỂ CANVAS VẼ BÀI MỚI
                                currentExerciseNotes = selectedExercise.notes

                            } else {
                                currentExerciseNotes = shuffleNotes(selectedExercise.notes)
                            }
                            hitResults = List(currentExerciseNotes.size) { null }
                            currentPhase = if (isPracticeOnly) RhythmPhase.TAP else RhythmPhase.LISTEN
                        } else {

                            // CHỈ LƯU LÊN BẢNG XẾP HẠNG NẾU ĐANG CHƠI MINIGAME
                            if (startDirectlyInGame) {
                                saveGameHistory(context, instrument, "RHYTHM", correctRounds, currentRound, totalElapsedTime)
                            }

                            // LƯU ĐIỂM CAO NHẤT ĐỂ MỞ KHÓA BÀI TẬP
                            val currentHS = prefs.getInt("rhythm_score_${selectedExercise.id}", 0)
                            if (correctRounds > currentHS) {
                                prefs.edit().putInt("rhythm_score_${selectedExercise.id}", correctRounds).apply()
                            }

                            // LOGIC MỞ KHÓA BÀI TẬP LIỀN KỀ
                            if (correctRounds >= 8) {
                                val currentIndex = exercises.indexOf(selectedExercise)
                                if (unlockedExerciseIndex <= currentIndex && currentIndex < exercises.size - 1) {
                                    unlockedExerciseIndex = currentIndex + 1
                                    prefs.edit().putInt("rhythm_unlocked_index", unlockedExerciseIndex).apply()
                                    Toast.makeText(context, if (currentLang == "vi") "Tuyệt vời! Đã mở khóa bài tập tiếp theo 🎉" else "Awesome! Next exercise unlocked 🎉", Toast.LENGTH_LONG).show()
                                }
                            }

                            showResultDialog = true
                            currentPhase = RhythmPhase.IDLE
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(CoreTranslator.getString("next_btn", currentLang), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    // --- HIỂN THỊ KẾT QUẢ DẠNG DIALOG ĐÈ LÊN ---
    if (showResultDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { /* Không cho tắt khi bấm ra ngoài */ }) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = surfaceColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = CoreTranslator.getString("quiz_result", currentLang).uppercase(),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = tunaGreen
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(CoreTranslator.getString("passed_lbl", currentLang), color = textColor, fontSize = 16.sp); Text("$correctRounds", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(CoreTranslator.getString("time_lbl", currentLang), color = textColor, fontSize = 16.sp)
                            val m = totalElapsedTime / 60
                            val s = totalElapsedTime % 60
                            Text(String.format("%02d:%02d", m, s), color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = onClose, border = BorderStroke(1.dp, textColor.copy(alpha=0.5f)), colors = ButtonDefaults.outlinedButtonColors(contentColor = textColor), modifier = Modifier.weight(1f)) {
                            Text(CoreTranslator.getString("exit_btn", currentLang))
                        }

                        Button(
                            onClick = {
                                correctRounds = 0
                                currentRound = 1
                                totalElapsedTime = 0
                                hitResults = List(currentExerciseNotes.size) { null }
                                showResultDialog = false
                                currentPhase = if (startDirectlyInGame) RhythmPhase.PREPARE else RhythmPhase.IDLE
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(CoreTranslator.getString("play_again", currentLang), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RhythmSheetCanvas(
    notes: List<RhythmNote>,
    hitResults: List<Boolean?>,
    activeNoteIndex: Int,
    activeNoteScale: Float,
    tunaGreen: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val centerY = h / 2f

        drawLine(color = textColor, start = Offset(0f, centerY), end = Offset(w, centerY), strokeWidth = 3f)

        // Lùi lề vào 15% mỗi bên để khung nốt nhạc gọn gàng hơn
        val startX = w * 0.15f
        val endX = w * 0.85f
        val availableW = endX - startX

        val totalIntervals = if (notes.size > 1) {
            notes.dropLast(1).sumOf { maxOf(it.duration.toDouble(), 0.35) }.toFloat()
        } else {
            1f
        }

        var visualAccumulated = 0f
        var realAccumulated = 0f

        val notePositions = mutableListOf<Float>()
        val noteBeatIndices = mutableListOf<Int>()

        val baseNoteW = 44f
        val baseNoteH = 32f

        notes.forEachIndexed { index, note ->
            val noteCenterX = if (notes.size > 1) {
                startX + (visualAccumulated / totalIntervals) * availableW
            } else {
                w / 2f
            }

            notePositions.add(noteCenterX)
            noteBeatIndices.add(realAccumulated.toInt())

            val scale = if (index == activeNoteIndex) activeNoteScale else 1f
            val noteWidth = baseNoteW * scale
            val noteHeight = baseNoteH * scale

            if (note.isRest) {
                val restColor = if (index == activeNoteIndex) tunaGreen else textColor

                if (note.duration <= 0.5f) {
                    val eighthRestChar = "𝄾"
                    val textLayout = textMeasurer.measure(
                        text = eighthRestChar,
                        style = TextStyle(fontSize = (56 * scale).sp, color = restColor)
                    )
                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(
                            x = noteCenterX - (textLayout.size.width / 2f),
                            y = centerY - (textLayout.size.height / 2f) + 5f
                        )
                    )
                } else {
                    val quarterRestChar = "𝄽"
                    val textLayout = textMeasurer.measure(
                        text = quarterRestChar,
                        style = TextStyle(fontSize = (64 * scale).sp, color = restColor)
                    )
                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(
                            x = noteCenterX - (textLayout.size.width / 2f),
                            y = centerY - (textLayout.size.height / 2f) - 15f
                        )
                    )
                }
            } else {
                val noteColor = when (hitResults[index]) {
                    true -> tunaGreen
                    false -> Color.Red
                    null -> textColor
                }

                rotate(degrees = -20f, pivot = Offset(noteCenterX, centerY)) {
                    drawOval(
                        color = noteColor,
                        topLeft = Offset(noteCenterX - noteWidth / 2, centerY - noteHeight / 2),
                        size = Size(noteWidth, noteHeight)
                    )
                }

                val stemX = noteCenterX + noteWidth / 2 - 2f
                val stemEndY = centerY - 100f
                drawLine(
                    color = noteColor,
                    start = Offset(stemX, centerY),
                    end = Offset(stemX, stemEndY),
                    strokeWidth = 6f
                )

                val dotColor = when (hitResults[index]) {
                    true -> tunaGreen
                    false -> Color.Red
                    null -> textColor.copy(alpha = 0.5f)
                }
                drawCircle(color = dotColor, radius = if (hitResults[index] != null) 22f else 14f, center = Offset(noteCenterX, centerY + 70f))
            }

            if (index < notes.size - 1) {
                visualAccumulated += maxOf(note.duration.toFloat(), 0.35f)
            }
            realAccumulated += note.duration
        }

        for (i in 0 until notes.size - 1) {
            val current = notes[i]
            val next = notes[i+1]

            if (!current.isRest && !next.isRest && current.duration < 1f && next.duration < 1f && noteBeatIndices[i] == noteBeatIndices[i + 1]) {
                val beamColor = when (hitResults[i]) {
                    true -> tunaGreen
                    false -> Color.Red
                    null -> textColor
                }

                val scale1 = if (i == activeNoteIndex) activeNoteScale else 1f
                val scale2 = if (i + 1 == activeNoteIndex) activeNoteScale else 1f

                val x1 = notePositions[i] + (baseNoteW * scale1) / 2 - 2f
                val x2 = notePositions[i + 1] + (baseNoteW * scale2) / 2 - 2f
                val beamY = centerY - 100f

                drawLine(color = beamColor, start = Offset(x1, beamY), end = Offset(x2, beamY), strokeWidth = 12f)

                if (current.duration <= 0.25f && next.duration <= 0.25f) {
                    drawLine(color = beamColor, start = Offset(x1, beamY + 18f), end = Offset(x2, beamY + 18f), strokeWidth = 12f)
                }
            }
        }
    }
}

@Composable
fun AnimatedFootCanvas(
    activeNoteIndex: Int,
    isPlaying: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    val toeAnimatable = remember { Animatable(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            // ĐÃ SỬA: Góc nhấc chân cao hơn (-45 độ) khi bắt đầu đập nhịp
            toeAnimatable.animateTo(-45f, tween(200))
        } else {
            toeAnimatable.animateTo(0f, tween(200))
        }
    }

    LaunchedEffect(activeNoteIndex) {
        if (activeNoteIndex != -1 && isPlaying) {
            // ĐÃ SỬA: Đập chân mạnh xuống (0 độ) với thời gian cực ngắn (20ms)
            toeAnimatable.animateTo(0f, animationSpec = tween(20, easing = LinearOutSlowInEasing))
            // ĐÃ SỬA: Nảy mũi chân lên cao (-45 độ) rõ rệt hơn (250ms)
            toeAnimatable.animateTo(-45f, animationSpec = tween(250, easing = FastOutSlowInEasing))
        }
    }

    Canvas(
        modifier = modifier.graphicsLayer {
            rotationZ = toeAnimatable.value
            // ĐÃ SỬA: Dời tâm xoay lùi về gót chân một chút để tạo độ nảy mạnh cho mũi chân
            transformOrigin = TransformOrigin(0.1f, 0.8f)
        }
    ) {
        val w = size.width
        val h = size.height

        val shoePath = Path().apply {
            moveTo(w * 0.15f, h * 0.8f)
            lineTo(w * 0.85f, h * 0.8f)

            quadraticBezierTo(w * 0.98f, h * 0.8f, w * 0.92f, h * 0.65f)
            quadraticBezierTo(w * 0.75f, h * 0.45f, w * 0.55f, h * 0.45f)
            lineTo(w * 0.45f, h * 0.2f)
            quadraticBezierTo(w * 0.4f, h * 0.1f, w * 0.3f, h * 0.15f)
            lineTo(w * 0.2f, h * 0.5f)
            quadraticBezierTo(w * 0.1f, h * 0.7f, w * 0.15f, h * 0.8f)
            close()
        }

        drawPath(
            path = shoePath,
            color = color,
            style = Fill
        )

        val solePath = Path().apply {
            moveTo(w * 0.15f, h * 0.8f)
            lineTo(w * 0.85f, h * 0.8f)
        }
        drawPath(
            path = solePath,
            color = Color.White.copy(alpha = 0.3f),
            style = Stroke(width = h * 0.06f, cap = StrokeCap.Round)
        )
    }
}