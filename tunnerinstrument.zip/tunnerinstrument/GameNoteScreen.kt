package ducphi.tunnerinstrument

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

data class DrawNote(
    val x: Float, val y: Float, val stringIdx: Int, val fret: Int,
    val midi: Int, val isRoot: Boolean, val noteName: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExplorePhase(
    instrument: String,
    lang: String,
    textColor: Color,
    bgColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    onClose: () -> Unit
) {
    var pianoKeyCount by remember { mutableStateOf(37) }
    var isKeyCountExpanded by remember { mutableStateOf(false) }

    var rootNote by remember { mutableStateOf("C") }
    var scaleType by remember { mutableStateOf("Major") }
    var displayMode by remember { mutableStateOf("FULL") }

    var selectedStartFret by remember { mutableIntStateOf(0) }
    var hiddenFrets by remember { mutableStateOf(setOf<Int>()) }

    var showSettings by remember { mutableStateOf(false) }
    var isColorEnabled by remember { mutableStateOf(true) }
    var isLinesEnabled by remember { mutableStateOf(true) }
    var noteLabelMode by remember { mutableStateOf("NOTE_NAME") }
    var handedness by remember { mutableStateOf("RIGHT") }
    var orientation by remember { mutableStateOf("LANDSCAPE") }
    var currentNumFrets by remember { mutableIntStateOf(15) }
    var currentInstrument by remember { mutableStateOf(instrument) }
    var bassStringCount by remember { mutableIntStateOf(4) }
    var currentTuning by remember { mutableStateOf("Standard") }

    val roots = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val scales = listOf("Chromatic", "Major", "Minor", "Pentatonic Major", "Pentatonic Minor")

    val context = LocalContext.current
    val activity = context as? Activity
    LaunchedEffect(instrument) {
        CoreAudioPlayer.loadInstrument(context, instrument)
    }

    LaunchedEffect(currentInstrument) {
        CoreAudioPlayer.loadInstrument(context, currentInstrument)
    }

    DisposableEffect(orientation) {
        activity?.requestedOrientation = if (orientation == "LANDSCAPE") {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }

    val rootIdx = roots.indexOf(rootNote)
    val scaleIntervals = when (scaleType) {
        "Major" -> listOf(0, 2, 4, 5, 7, 9, 11)
        "Minor" -> listOf(0, 2, 3, 5, 7, 8, 10)
        "Pentatonic Major" -> listOf(0, 2, 4, 7, 9)
        "Pentatonic Minor" -> listOf(0, 3, 5, 7, 10)
        else -> (0..11).toList()
    }
    val scaleIndices = scaleIntervals.map { (rootIdx + it) % 12 }
    val allScaleMidis = (0..127).filter { scaleIndices.contains(it % 12) }

    Box(modifier = Modifier.fillMaxSize().background(bgColor)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose, modifier = Modifier.background(surfaceColor, CircleShape)) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor)
                }

                if (currentInstrument == "Piano") {
                    Spacer(modifier = Modifier.weight(1f))
                    Box {
                        Row(
                            modifier = Modifier.background(surfaceColor, RoundedCornerShape(8.dp)).clickable { isKeyCountExpanded = true }.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "$pianoKeyCount ${CoreTranslator.getString("keys_lbl", lang)}", color = tunaGreen, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = tunaGreen)
                        }
                        DropdownMenu(expanded = isKeyCountExpanded, onDismissRequest = { isKeyCountExpanded = false }, modifier = Modifier.background(surfaceColor)) {
                            listOf(37, 61).forEach { count ->
                                DropdownMenuItem(text = { Text("$count ${CoreTranslator.getString("keys_lbl", lang)}", color = textColor) }, onClick = { pianoKeyCount = count; isKeyCountExpanded = false })
                            }
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.width(16.dp))
                    CustomDropdownChip(rootNote, roots, { rootNote = it }, surfaceColor, textColor, modifier = Modifier.weight(0.7f))
                    Spacer(modifier = Modifier.width(8.dp))
                    CustomDropdownChip(scaleType, scales, { scaleType = it }, surfaceColor, textColor, modifier = Modifier.weight(1.3f))
                    Spacer(modifier = Modifier.width(8.dp))

                    CustomDropdownChip(
                        selectedValue = when(displayMode) {
                            "FULL" -> CoreTranslator.getString("mode_full", lang)
                            "POSITION" -> CoreTranslator.getString("mode_position", lang)
                            "DIAGONAL" -> CoreTranslator.getString("mode_diagonal", lang)
                            "OCTAVE" -> CoreTranslator.getString("mode_octave", lang)
                            else -> displayMode
                        },
                        options = listOf(
                            CoreTranslator.getString("mode_full", lang),
                            CoreTranslator.getString("mode_position", lang),
                            CoreTranslator.getString("mode_diagonal", lang),
                            CoreTranslator.getString("mode_octave", lang)
                        ),
                        onSelected = { selected ->
                            displayMode = when(selected) {
                                CoreTranslator.getString("mode_full", lang) -> "FULL"
                                CoreTranslator.getString("mode_position", lang) -> "POSITION"
                                CoreTranslator.getString("mode_diagonal", lang) -> "DIAGONAL"
                                CoreTranslator.getString("mode_octave", lang) -> "OCTAVE"
                                else -> "FULL"
                            }
                        },
                        surfaceColor = surfaceColor, textColor = textColor, modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { showSettings = true },
                        modifier = Modifier.background(surfaceColor, CircleShape).size(40.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = textColor)
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (currentInstrument == "Piano") {
                    FullPianoNotesResponsive(pianoKeyCount, textColor, surfaceColor, tunaGreen, rootNote, scaleType, displayMode)
                } else {
                    FullFretboardNotesResponsive(
                        instrument = currentInstrument,
                        bassStringCount = bassStringCount,
                        textColor = textColor,
                        surfaceColor = surfaceColor,
                        tunaGreen = tunaGreen,
                        rootNote = rootNote,
                        scaleType = scaleType,
                        displayMode = displayMode,
                        numFrets = currentNumFrets,
                        scaleIntervals = scaleIntervals,
                        scaleIndices = scaleIndices,
                        allScaleMidis = allScaleMidis,
                        selectedStartFret = selectedStartFret,
                        onFretSelected = { selectedStartFret = it },
                        hiddenFrets = hiddenFrets,
                        onFretToggled = { fret ->
                            hiddenFrets = if (hiddenFrets.contains(fret)) hiddenFrets - fret else hiddenFrets + fret
                        },
                        isColorEnabled = isColorEnabled,
                        isLinesEnabled = isLinesEnabled,
                        noteLabelMode = noteLabelMode,
                        orientation = orientation,
                        handedness = handedness,
                        currentTuning = currentTuning
                    )
                }
            }
        }

        if (showSettings) {
            val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(bgColor)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showSettings = false },
                        modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Close Settings", tint = textColor)
                    }
                    Text(
                        text = CoreTranslator.getString("settings_title", lang),
                        color = textColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }

                if (isLandscape) {
                    Row(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            SettingBox(CoreTranslator.getString("setting_display", lang), surfaceColor) {
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(CoreTranslator.getString("show_color", lang), color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    Switch(checked = isColorEnabled, onCheckedChange = { isColorEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = textColor, checkedTrackColor = tunaGreen, uncheckedThumbColor = Color.Gray, uncheckedTrackColor = surfaceColor))
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(CoreTranslator.getString("show_lines", lang), color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    Switch(checked = isLinesEnabled, onCheckedChange = { isLinesEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = textColor, checkedTrackColor = tunaGreen, uncheckedThumbColor = Color.Gray, uncheckedTrackColor = surfaceColor))
                                }
                            }
                            SettingBox(CoreTranslator.getString("note_label", lang), surfaceColor) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn(CoreTranslator.getString("note_name", lang), noteLabelMode == "NOTE_NAME", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { noteLabelMode = "NOTE_NAME" }
                                    SettingOptionBtn(CoreTranslator.getString("roman_numeral", lang), noteLabelMode == "ROMAN", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { noteLabelMode = "ROMAN" }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            SettingBox(CoreTranslator.getString("orientation_handedness", lang), surfaceColor) {
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn(CoreTranslator.getString("landscape", lang), orientation == "LANDSCAPE", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { orientation = "LANDSCAPE" }
                                    SettingOptionBtn(CoreTranslator.getString("portrait", lang), orientation == "PORTRAIT", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { orientation = "PORTRAIT" }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn(CoreTranslator.getString("right_handed", lang), handedness == "RIGHT", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { handedness = "RIGHT" }
                                    SettingOptionBtn(CoreTranslator.getString("left_handed", lang), handedness == "LEFT", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { handedness = "LEFT" }
                                }
                            }
                            SettingBox(CoreTranslator.getString("fret_count", lang), surfaceColor) {
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn("12", currentNumFrets == 12, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 12 }
                                    SettingOptionBtn("15", currentNumFrets == 15, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 15 }
                                    SettingOptionBtn("18", currentNumFrets == 18, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 18 }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn("21", currentNumFrets == 21, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 21 }
                                    SettingOptionBtn("24", currentNumFrets == 24, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 24 }
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            SettingBox(CoreTranslator.getString("setting_instrument", lang), surfaceColor) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn(CoreTranslator.getString("inst_guitar", lang), currentInstrument == "Guitar", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentInstrument = "Guitar" }
                                    SettingOptionBtn(CoreTranslator.getString("inst_ukulele", lang), currentInstrument == "Ukulele", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentInstrument = "Ukulele" }
                                    SettingOptionBtn(CoreTranslator.getString("inst_bass", lang), currentInstrument == "Bass", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentInstrument = "Bass" }
                                }
                                if (currentInstrument == "Bass") {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    CustomDropdownChip(
                                        selectedValue = "$bassStringCount ${CoreTranslator.getString("strings", lang)}",
                                        options = listOf("4 ${CoreTranslator.getString("strings", lang)}", "5 ${CoreTranslator.getString("strings", lang)}"),
                                        onSelected = { bassStringCount = it.split(" ")[0].toInt() },
                                        surfaceColor = surfaceColor,
                                        textColor = textColor,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            SettingBox(CoreTranslator.getString("setting_tuning", lang), surfaceColor) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SettingOptionBtn("Standard", currentTuning == "Standard", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentTuning = "Standard" }
                                    SettingOptionBtn("Drop D", currentTuning == "Drop D", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentTuning = "Drop D" }
                                }
                            }
                        }
                    }
                } else {
                    Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        SettingBox(CoreTranslator.getString("setting_display", lang), surfaceColor) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(CoreTranslator.getString("show_color", lang), color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Switch(checked = isColorEnabled, onCheckedChange = { isColorEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = textColor, checkedTrackColor = tunaGreen, uncheckedThumbColor = Color.Gray, uncheckedTrackColor = surfaceColor))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(CoreTranslator.getString("show_lines", lang), color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Switch(checked = isLinesEnabled, onCheckedChange = { isLinesEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = textColor, checkedTrackColor = tunaGreen, uncheckedThumbColor = Color.Gray, uncheckedTrackColor = surfaceColor))
                            }
                        }
                        SettingBox(CoreTranslator.getString("note_label", lang), surfaceColor) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn(CoreTranslator.getString("note_name", lang), noteLabelMode == "NOTE_NAME", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { noteLabelMode = "NOTE_NAME" }
                                SettingOptionBtn(CoreTranslator.getString("roman_numeral", lang), noteLabelMode == "ROMAN", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { noteLabelMode = "ROMAN" }
                            }
                        }
                        SettingBox(CoreTranslator.getString("orientation_handedness", lang), surfaceColor) {
                            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn(CoreTranslator.getString("landscape", lang), orientation == "LANDSCAPE", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { orientation = "LANDSCAPE" }
                                SettingOptionBtn(CoreTranslator.getString("portrait", lang), orientation == "PORTRAIT", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { orientation = "PORTRAIT" }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn(CoreTranslator.getString("right_handed", lang), handedness == "RIGHT", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { handedness = "RIGHT" }
                                SettingOptionBtn(CoreTranslator.getString("left_handed", lang), handedness == "LEFT", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { handedness = "LEFT" }
                            }
                        }
                        SettingBox(CoreTranslator.getString("fret_count", lang), surfaceColor) {
                            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn("12", currentNumFrets == 12, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 12 }
                                SettingOptionBtn("15", currentNumFrets == 15, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 15 }
                                SettingOptionBtn("18", currentNumFrets == 18, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 18 }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn("21", currentNumFrets == 21, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 21 }
                                SettingOptionBtn("24", currentNumFrets == 24, tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentNumFrets = 24 }
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                        SettingBox(CoreTranslator.getString("setting_instrument", lang), surfaceColor) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn(CoreTranslator.getString("inst_guitar", lang), currentInstrument == "Guitar", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentInstrument = "Guitar" }
                                SettingOptionBtn(CoreTranslator.getString("inst_ukulele", lang), currentInstrument == "Ukulele", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentInstrument = "Ukulele" }
                                SettingOptionBtn(CoreTranslator.getString("inst_bass", lang), currentInstrument == "Bass", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentInstrument = "Bass" }
                            }
                            if (currentInstrument == "Bass") {
                                Spacer(modifier = Modifier.height(8.dp))
                                CustomDropdownChip(
                                    selectedValue = "$bassStringCount ${CoreTranslator.getString("strings", lang)}",
                                    options = listOf("4 ${CoreTranslator.getString("strings", lang)}", "5 ${CoreTranslator.getString("strings", lang)}"),
                                    onSelected = { bassStringCount = it.split(" ")[0].toInt() },
                                    surfaceColor = surfaceColor,
                                    textColor = textColor,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        SettingBox(CoreTranslator.getString("setting_tuning", lang), surfaceColor) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SettingOptionBtn("Standard", currentTuning == "Standard", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentTuning = "Standard" }
                                SettingOptionBtn("Drop D", currentTuning == "Drop D", tunaGreen, surfaceColor, textColor, Modifier.weight(1f)) { currentTuning = "Drop D" }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingBox(title: String, surfaceColor: Color, content: @Composable () -> Unit) { // Thêm surfaceColor
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .background(surfaceColor, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Text(
            text = title,
            color = Color.Gray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        content()
    }
}

@Composable
fun SettingOptionBtn(
    text: String,
    isSelected: Boolean,
    activeColor: Color,
    surfaceColor: Color,
    textColor: Color, // THÊM THAM SỐ NÀY
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgColor = if (isSelected) activeColor else surfaceColor
    val borderColor = if (isSelected) activeColor else Color.DarkGray

    // Xử lý màu chữ: Chữ Trắng khi được chọn, chữ màu hệ thống khi không chọn
    val finalTextColor = if (isSelected) Color.White else textColor

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = finalTextColor, // Sử dụng biến màu thông minh
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun CustomDropdownChip(
    selectedValue: String,
    options: List<String>,
    onSelected: (String) -> Unit,
    surfaceColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(surfaceColor, RoundedCornerShape(8.dp))
                .clickable { expanded = true }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(selectedValue, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Icon(Icons.Default.ArrowDropDown, null, tint = textColor)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.background(surfaceColor).heightIn(max = 300.dp)) {
            options.forEach { opt ->
                DropdownMenuItem(text = { Text(opt, color = textColor) }, onClick = { onSelected(opt); expanded = false })
            }
        }
    }
}

@Composable
fun FullFretboardNotesResponsive(
    instrument: String, bassStringCount: Int, textColor: Color, surfaceColor: Color, tunaGreen: Color,
    rootNote: String, scaleType: String, displayMode: String, numFrets: Int,
    scaleIntervals: List<Int>, scaleIndices: List<Int>, allScaleMidis: List<Int>,
    selectedStartFret: Int, onFretSelected: (Int) -> Unit,
    hiddenFrets: Set<Int>, onFretToggled: (Int) -> Unit,
    isColorEnabled: Boolean = true,
    isLinesEnabled: Boolean = true,
    noteLabelMode: String = "NOTE_NAME",
    orientation: String = "LANDSCAPE",
    handedness: String = "RIGHT",
    currentTuning: String = "Standard"
) {
    val isVert = orientation == "PORTRAIT"
    val isLeftHanded = handedness == "LEFT"

    val numStrings = when (instrument) {
        "Guitar" -> 6
        "Ukulele" -> 4
        else -> bassStringCount
    }

    val baseOpenMidi = when (instrument) {
        "Guitar" -> {
            when (currentTuning) {
                "Standard" -> listOf(64, 59, 55, 50, 45, 40)
                "Drop D"   -> listOf(64, 59, 55, 50, 45, 38)
                "Eb"       -> listOf(63, 58, 54, 49, 44, 39)
                "D"        -> listOf(62, 57, 53, 48, 43, 38)
                "Open G"   -> listOf(62, 59, 55, 50, 43, 38)
                "DADGAD"   -> listOf(62, 57, 55, 50, 45, 38)
                else       -> listOf(64, 59, 55, 50, 45, 40)
            }
        }
        "Ukulele" -> listOf(69, 64, 60, 67)
        else -> {
            if (bassStringCount == 4) {
                when (currentTuning) {
                    "Drop D"   -> listOf(43, 38, 33, 26)
                    "Eb"       -> listOf(42, 37, 32, 27)
                    "D"        -> listOf(41, 36, 31, 26)
                    else       -> listOf(43, 38, 33, 28)
                }
            } else {
                when (currentTuning) {
                    "Drop D"   -> listOf(43, 38, 33, 26, 23)
                    "Eb"       -> listOf(42, 37, 32, 27, 22)
                    "D"        -> listOf(41, 36, 31, 26, 21)
                    else       -> listOf(43, 38, 33, 28, 23)
                }
            }
        }
    }

    val baseStringNames = when (instrument) {
        "Guitar" -> {
            when (currentTuning) {
                "Standard" -> listOf("e", "B", "G", "D", "A", "E")
                "Drop D"   -> listOf("e", "B", "G", "D", "A", "D")
                "Eb"       -> listOf("eb", "Bb", "Gb", "Db", "Ab", "Eb")
                "D"        -> listOf("d", "A", "F", "C", "G", "D")
                "Open G"   -> listOf("d", "B", "G", "D", "G", "D")
                "DADGAD"   -> listOf("d", "A", "G", "D", "A", "D")
                else       -> listOf("e", "B", "G", "D", "A", "E")
            }
        }
        "Ukulele" -> listOf("A", "E", "C", "G")
        else -> {
            if (bassStringCount == 4) {
                when (currentTuning) {
                    "Drop D"   -> listOf("G", "D", "A", "D")
                    "Eb"       -> listOf("Gb", "Db", "Ab", "Eb")
                    "D"        -> listOf("F", "C", "G", "D")
                    else       -> listOf("G", "D", "A", "E")
                }
            } else {
                when (currentTuning) {
                    "Drop D"   -> listOf("G", "D", "A", "D", "B")
                    "Eb"       -> listOf("Gb", "Db", "Ab", "Eb", "Bb")
                    "D"        -> listOf("F", "C", "G", "D", "A")
                    else       -> listOf("G", "D", "A", "E", "B")
                }
            }
        }
    }

    val openMidi = if (isLeftHanded) baseOpenMidi.reversed() else baseOpenMidi
    val stringNames = if (isLeftHanded) baseStringNames.reversed() else baseStringNames
    val notes = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    val rootColor = Color(0xFFE53935)
    val scaleColor = Color(0xFFFFA726)
    val lineColor = textColor.copy(alpha = 0.8f)

    val isChromatic = scaleType == "Chromatic"
    val rootIdx = notes.indexOf(rootNote)

    var pressedString by remember { mutableIntStateOf(-1) }
    var pressedFret by remember { mutableIntStateOf(-1) }

    val infiniteTransition = rememberInfiniteTransition(label = "rootAnimation")
    val rootScale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 800, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "rootScale"
    )
    val rootAlpha by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 0.4f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 800, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "rootAlpha"
    )

    val sequenceNotes = mutableListOf<DrawNote>()

    val isViTri = displayMode == "POSITION"
    val isChayCheo = displayMode == "DIAGONAL"
    val isPositional = isViTri || isChayCheo

    if (!isChromatic && isChayCheo) {
        var actualStartFret = selectedStartFret
        var currentLimitFret = numFrets

        if (selectedStartFret >= 7) {
            actualStartFret = 0
            currentLimitFret = selectedStartFret
        }

        val bassStrIdx = (0 until numStrings).minByOrNull { openMidi[it] } ?: (numStrings - 1)
        val trebleStrIdx = (0 until numStrings).maxByOrNull { openMidi[it] } ?: 0

        var startMidi = -1
        for (f in actualStartFret..currentLimitFret) {
            val m = openMidi[bassStrIdx] + f
            if (scaleIndices.contains(m % 12)) {
                startMidi = m
                break
            }
        }

        var endMidi = -1
        for (f in currentLimitFret downTo 0) {
            val m = openMidi[trebleStrIdx] + f
            if (scaleIndices.contains(m % 12)) {
                endMidi = m
                break
            }
        }

        if (startMidi != -1 && endMidi != -1 && startMidi <= endMidi) {
            val startIndex = allScaleMidis.indexOf(startMidi)
            val endIndex = allScaleMidis.indexOf(endMidi)

            if (startIndex != -1 && endIndex != -1) {
                val totalNotes = endIndex - startIndex + 1
                val baseNotesPerString = totalNotes / numStrings
                val remainder = totalNotes % numStrings

                val stringSequence = (0 until numStrings).sortedBy { openMidi[it] }

                var currentMidiIdx = startIndex
                for ((iteration, s) in stringSequence.withIndex()) {
                    val notesToTake = if (iteration >= numStrings - remainder) baseNotesPerString + 1 else baseNotesPerString

                    var added = 0
                    while (added < notesToTake && currentMidiIdx <= endIndex) {
                        val targetMidi = allScaleMidis[currentMidiIdx]
                        val f = targetMidi - openMidi[s]

                        if (f in 0..35) {
                            if (!hiddenFrets.contains(f)) {
                                val isRoot = (targetMidi % 12) == rootIdx
                                sequenceNotes.add(DrawNote(0f, 0f, s, f, targetMidi, isRoot, notes[targetMidi % 12]))
                            }
                        }
                        added++
                        currentMidiIdx++
                    }
                }
            }
        }
    }else if (!isChromatic && isViTri) {
        val endFret = minOf(selectedStartFret + 4, numFrets)
        for (s in (numStrings - 1) downTo 0) {
            for (f in selectedStartFret..endFret) {
                if (hiddenFrets.contains(f)) continue
                val m = openMidi[s] + f
                if (scaleIndices.contains(m % 12)) {
                    val isRoot = (m % 12) == rootIdx
                    sequenceNotes.add(DrawNote(0f, 0f, s, f, m, isRoot, notes[m % 12]))
                }
            }
        }
    } else {
        for (s in 0 until numStrings) {
            for (f in 0..numFrets) {
                if (hiddenFrets.contains(f)) continue
                val m = openMidi[s] + f
                if (displayMode == "OCTAVE" || scaleIndices.contains(m % 12)) {
                    val isRoot = (m % 12) == rootIdx
                    sequenceNotes.add(DrawNote(0f, 0f, s, f, m, isRoot, notes[m % 12]))
                }
            }
        }
    }

    fun getOctaveColor(midi: Int): Color {
        val octave = (midi / 12) - 1
        return when (octave) {
            2 -> Color(0xFF4CAF50); 3 -> Color(0xFF2196F3); 4 -> Color(0xFFFF9800)
            5 -> Color(0xFFE91E63); 6 -> Color(0xFF9C27B0); else -> Color(0xFF9E9E9E)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            Canvas(modifier = Modifier.fillMaxSize().pointerInput(instrument, sequenceNotes, hiddenFrets, selectedStartFret, isLeftHanded) {
                val canvasSize = this.size
                detectTapGestures(
                    onPress = { tapOffset ->
                        val w = canvasSize.width.toFloat(); val h = canvasSize.height.toFloat()

                        val nutPos = 160f
                        val primaryLen = if (isVert) h - nutPos - 20f else w - nutPos - 40f
                        val scaleFactorLast = 1f - (1f / Math.pow(2.0, numFrets / 12.0).toFloat())
                        val scaleLength = primaryLen / scaleFactorLast

                        fun getFretPos(n: Int): Float {
                            return if (isVert) {
                                nutPos + (primaryLen / numFrets) * n
                            } else {
                                nutPos + scaleLength * (1f - (1f / Math.pow(2.0, n / 12.0).toFloat()))
                            }
                        }

                        val actualTapX = tapOffset.x
                        val tapFretPos = if (isVert) tapOffset.y else actualTapX
                        val tapSecondaryPos = if (isVert) actualTapX else tapOffset.y
                        val btnTopZone = 130f

                        if ((isVert && tapSecondaryPos <= w * 0.20f) || (!isVert && tapSecondaryPos <= btnTopZone)) {
                            for (i in 0..numFrets) {
                                val fPos = if (i == 0) nutPos - 60f else (getFretPos(i - 1) + getFretPos(i)) / 2f
                                if (Math.abs(tapFretPos - fPos) < 35f) {
                                    if (isPositional) {
                                        onFretSelected(i)
                                    } else {
                                        val midisOnFret = sequenceNotes.filter { it.fret == i }.map { it.midi }
                                        if (midisOnFret.isNotEmpty()) {
                                            try { CoreAudioPlayer.playChord(midisOnFret, instrument) } catch (e: Exception) {}
                                        }
                                    }
                                    return@detectTapGestures
                                }
                            }
                        }

                        val secStart = if (isVert) w * 0.16f else 130f
                        val secEnd = if (isVert) w * 0.96f else h - 5f
                        val fret12Pos = getFretPos(12)

                        fun getStringSecondary(s: Int, fPos: Float): Float {
                            val t = (fPos - nutPos) / (fret12Pos - nutPos)
                            val wNut = (secEnd - secStart) * 0.75f
                            val w12 = (secEnd - secStart) * 0.95f
                            val currentW = wNut + t * (w12 - wNut)
                            val top = secStart + (secEnd - secStart - currentW) / 2f
                            val spacing = if (numStrings > 1) currentW / (numStrings - 1) else 0f
                            return if (isVert) top + (numStrings - 1 - s) * spacing else top + s * spacing
                        }

                        for (p in sequenceNotes) {
                            val fPos = if (p.fret == 0) nutPos - 60f else (getFretPos(p.fret - 1) + getFretPos(p.fret)) / 2f
                            val sSec = getStringSecondary(p.stringIdx, fPos)
                            val x = if (isVert) sSec else fPos
                            val y = if (isVert) fPos else sSec

                            if (Math.hypot((actualTapX - x).toDouble(), (tapOffset.y - y).toDouble()) < 45f) {
                                pressedString = p.stringIdx
                                pressedFret = p.fret
                                try { CoreAudioPlayer.playChord(listOf(p.midi), instrument) } catch (e: Exception) {}
                                break
                            }
                        }
                        tryAwaitRelease()
                        pressedString = -1
                        pressedFret = -1
                    }
                )
            }) {
                val w = size.width; val h = size.height

                fun flipX(x: Float): Float = x

                val nutPos = 160f
                val primaryLen = if (isVert) h - nutPos - 20f else w - nutPos - 40f
                val scaleFactorLast = 1f - (1f / Math.pow(2.0, numFrets / 12.0).toFloat())
                val scaleLength = primaryLen / scaleFactorLast

                fun getFretPos(n: Int): Float {
                    return if (isVert) {
                        nutPos + (primaryLen / numFrets) * n
                    } else {
                        nutPos + scaleLength * (1f - (1f / Math.pow(2.0, n / 12.0).toFloat()))
                    }
                }
                val fret12Pos = getFretPos(12)

                val secStart = if (isVert) w * 0.16f else 130f
                val secEnd = if (isVert) w * 0.96f else h - 5f

                fun getStringSecondary(s: Int, fPos: Float): Float {
                    val t = (fPos - nutPos) / (fret12Pos - nutPos)
                    val wNut = (secEnd - secStart) * 0.75f
                    val w12 = (secEnd - secStart) * 0.95f
                    val currentW = wNut + t * (w12 - wNut)
                    val top = secStart + (secEnd - secStart - currentW) / 2f
                    val spacing = if (numStrings > 1) currentW / (numStrings - 1) else 0f
                    return if (isVert) top + (numStrings - 1 - s) * spacing else top + s * spacing
                }

                for (i in 0..numFrets) {
                    val fPos = if (i == 0) nutPos - 60f else (getFretPos(i - 1) + getFretPos(i)) / 2f
                    val leftEdge = getStringSecondary(numStrings - 1, fPos)
                    val topEdge = getStringSecondary(0, fPos)

                    val textX = flipX(if (isVert) leftEdge - 85f else fPos)
                    val textY = if (isVert) fPos else topEdge - 90f

                    val isHighlighted = if (isViTri) {
                        i in selectedStartFret..minOf(selectedStartFret + 4, numFrets)
                    } else if (isChayCheo) {
                        i == selectedStartFret || i == numFrets
                    } else {
                        hiddenFrets.contains(i)
                    }

                    if (!isVert) {
                        val btnSize = 52f
                        val bgColor = if (isHighlighted) Color(0xFFE53935).copy(alpha = 0.25f) else surfaceColor
                        val strokeColor = if (isHighlighted) Color(0xFFE53935) else textColor.copy(alpha = 0.2f)

                        drawRoundRect(
                            color = bgColor,
                            topLeft = Offset(textX - btnSize / 2, textY - btnSize / 2),
                            size = Size(btnSize, btnSize),
                            cornerRadius = CornerRadius(14f, 14f)
                        )
                        drawRoundRect(
                            color = strokeColor,
                            topLeft = Offset(textX - btnSize / 2, textY - btnSize / 2),
                            size = Size(btnSize, btnSize),
                            cornerRadius = CornerRadius(14f, 14f),
                            style = Stroke(width = 2.5f)
                        )
                    }

                    val tSize = if (isVert) 36f else 26f
                    val paintToUse = android.graphics.Paint().apply {
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        color = if (isPositional && isHighlighted) tunaGreen.toArgb()
                        else if (isHighlighted) Color(0xFFE53935).toArgb()
                        else textColor.copy(alpha = 0.9f).toArgb()
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        textSize = if (isHighlighted) tSize * 1.15f else tSize
                    }

                    drawContext.canvas.nativeCanvas.drawText(
                        i.toString(),
                        textX,
                        textY - ((paintToUse.descent() + paintToUse.ascent()) / 2),
                        paintToUse
                    )
                }

                val stringNamePaint = android.graphics.Paint().apply { textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; color = textColor.toArgb(); typeface = android.graphics.Typeface.DEFAULT_BOLD; textSize = if (displayMode == "FULL") 34f else 28f }
                for (s in 0 until numStrings) {
                    val strSec = getStringSecondary(s, nutPos)
                    val txtX = flipX(if (isVert) strSec else 30f)
                    val txtY = if (isVert) nutPos - 120f else strSec - ((stringNamePaint.descent() + stringNamePaint.ascent()) / 2)
                    drawContext.canvas.nativeCanvas.drawText(stringNames[s], txtX, txtY, stringNamePaint)
                }

                val dotFrets = if (instrument == "Ukulele") listOf(5, 7, 10, 12, 15) else listOf(3, 5, 7, 9, 12, 15, 17, 19, 21, 24)
                val dotColor = textColor.copy(alpha = 0.2f)
                dotFrets.forEach { fret ->
                    if (fret <= numFrets) {
                        val fPos = (getFretPos(fret - 1) + getFretPos(fret)) / 2f
                        val t = (fPos - nutPos) / (fret12Pos - nutPos)
                        val currW = (secEnd - secStart) * 0.75f + t * ((secEnd - secStart) * 0.95f - (secEnd - secStart) * 0.75f)
                        val top = secStart + (secEnd - secStart - currW) / 2f

                        if (fret == 12 || fret == 24) {
                            val dot1 = top + currW * 0.25f
                            val dot2 = top + currW * 0.75f
                            drawCircle(color = dotColor, radius = 16f, center = Offset(flipX(if (isVert) dot1 else fPos), if (isVert) fPos else dot1))
                            drawCircle(color = dotColor, radius = 16f, center = Offset(flipX(if (isVert) dot2 else fPos), if (isVert) fPos else dot2))
                        } else {
                            val midDot = top + currW / 2f
                            drawCircle(color = dotColor, radius = 16f, center = Offset(flipX(if (isVert) midDot else fPos), if (isVert) fPos else midDot))
                        }
                    }
                }

                for (i in 1..numFrets) {
                    val fPos = getFretPos(i)
                    val s0Sec = getStringSecondary(0, fPos)
                    val sNSec = getStringSecondary(numStrings - 1, fPos)
                    val start = Offset(flipX(if (isVert) sNSec else fPos), if (isVert) fPos else s0Sec)
                    val end = Offset(flipX(if (isVert) s0Sec else fPos), if (isVert) fPos else sNSec)
                    drawLine(color = textColor.copy(alpha = 0.4f), start = start, end = end, strokeWidth = 4f)
                }

                val s0Nut = getStringSecondary(0, nutPos)
                val sNNut = getStringSecondary(numStrings - 1, nutPos)
                val nutStart = Offset(flipX(if (isVert) sNNut - 2f else nutPos), if (isVert) nutPos else s0Nut - 2f)
                val nutEnd = Offset(flipX(if (isVert) s0Nut + 2f else nutPos), if (isVert) nutPos else sNNut + 2f)
                drawLine(color = textColor, start = nutStart, end = nutEnd, strokeWidth = 14f)

                for (s in 0 until numStrings) {
                    val stringStrokeWidth = if (instrument == "Guitar") (s + 1) * 1.8f else (s + 1) * 2.2f
                    val sStartSec = getStringSecondary(s, nutPos)
                    val sEndSec = getStringSecondary(s, getFretPos(numFrets) + 20f)

                    val start = Offset(flipX(if (isVert) sStartSec else nutPos), if (isVert) nutPos else sStartSec)
                    val end = Offset(flipX(if (isVert) sEndSec else getFretPos(numFrets) + 20f), if (isVert) getFretPos(numFrets) + 20f else sEndSec)

                    drawLine(color = textColor.copy(alpha = 0.7f), start = start, end = end, strokeWidth = stringStrokeWidth)
                }

                val actualPoints = sequenceNotes.filter { it.fret >= 0 && it.fret <= numFrets }.map { p ->
                    val fPos = if (p.fret == 0) nutPos - 60f else (getFretPos(p.fret - 1) + getFretPos(p.fret)) / 2f
                    val sSec = getStringSecondary(p.stringIdx, fPos)
                    val x = if (isVert) sSec else fPos
                    val y = if (isVert) fPos else sSec
                    p.copy(x = flipX(x), y = y)
                }

                val rootFret6 = (rootIdx - 4 + 12) % 12

                val refGuitarMidi = arrayOf(64, 59, 55, 50, 45, 40, 35)

                val patternMap = arrayOf(
                    listOf(listOf(5,1), listOf(1), listOf(1,2), listOf(2), listOf(2,3), listOf(3), listOf(3), listOf(3,4), listOf(4), listOf(4,5), listOf(5), listOf(5)),
                    listOf(listOf(5,1), listOf(1), listOf(1,2), listOf(1,2), listOf(2), listOf(2,3), listOf(3), listOf(3,4), listOf(4), listOf(4,5), listOf(5), listOf(5)),
                    listOf(listOf(5,1), listOf(1,2), listOf(2), listOf(2), listOf(2,3), listOf(3), listOf(3,4), listOf(4), listOf(4), listOf(4,5), listOf(5), listOf(5,1)),
                    listOf(listOf(5,1), listOf(1), listOf(1,2), listOf(2), listOf(2,3), listOf(3), listOf(3,4), listOf(4), listOf(4), listOf(4,5), listOf(5), listOf(5,1)),
                    listOf(listOf(1), listOf(1,2), listOf(1,2), listOf(2), listOf(2,3), listOf(3), listOf(3), listOf(3,4), listOf(4), listOf(4,5), listOf(5), listOf(5,1)),
                    listOf(listOf(5,1), listOf(1), listOf(1,2), listOf(2), listOf(2,3), listOf(3), listOf(3), listOf(3,4), listOf(4), listOf(4,5), listOf(5), listOf(5)),
                    listOf(listOf(5,1), listOf(1), listOf(1,2), listOf(2), listOf(2,3), listOf(3), listOf(3), listOf(3,4), listOf(4), listOf(4,5), listOf(5), listOf(5))
                )

                fun getCagedColor(idx: Int): Color = when(idx) {
                    1 -> Color(0xFFE53935); 2 -> Color(0xFFFFB300); 3 -> Color(0xFF43A047)
                    4 -> Color(0xFF1E88E5); 5 -> Color(0xFF8E24AA); else -> scaleColor
                }

                if (isLinesEnabled && !isChromatic && actualPoints.size > 1) {
                    if (isViTri) {
                        for (i in 0 until actualPoints.size - 1) {
                            val p1 = actualPoints[i]
                            val p2 = actualPoints[i + 1]
                            var segmentColor = lineColor.copy(alpha = 0.8f)

                            if (isColorEnabled) {
                                val s_idx1 = if (instrument == "Bass") (if (numStrings == 4) p1.stringIdx + 2 else if (p1.stringIdx < 4) p1.stringIdx + 2 else 6) else p1.stringIdx
                                val s_idx2 = if (instrument == "Bass") (if (numStrings == 4) p2.stringIdx + 2 else if (p2.stringIdx < 4) p2.stringIdx + 2 else 6) else p2.stringIdx

                                val diff1 = openMidi[p1.stringIdx] - refGuitarMidi[s_idx1]
                                val diff2 = openMidi[p2.stringIdx] - refGuitarMidi[s_idx2]
                                val f_rel1 = (p1.fret + diff1 - rootFret6 + 120) % 12
                                val f_rel2 = (p2.fret + diff2 - rootFret6 + 120) % 12

                                val p1Patterns = patternMap[s_idx1][f_rel1]
                                val p2Patterns = patternMap[s_idx2][f_rel2]
                                val sharedPattern = p1Patterns.firstOrNull { it in p2Patterns } ?: p1Patterns.first()
                                segmentColor = getCagedColor(sharedPattern).copy(alpha = 0.8f)
                            }
                            drawLine(color = segmentColor, start = Offset(p1.x, p1.y), end = Offset(p2.x, p2.y), strokeWidth = 5f, cap = StrokeCap.Round)
                        }
                    } else if (isChayCheo) {
                        val path = Path()
                        path.moveTo(actualPoints.first().x, actualPoints.first().y)
                        for (i in 1 until actualPoints.size) { path.lineTo(actualPoints[i].x, actualPoints[i].y) }
                        drawPath(path, color = lineColor.copy(alpha = 0.8f), style = Stroke(width = 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                    else if (displayMode == "FULL") {
                        for (pattern in 1..5) {
                            val patternPoints = actualPoints.filter { p ->
                                val s_idx = if (instrument == "Bass") (if (numStrings == 4) p.stringIdx + 2 else if (p.stringIdx < 4) p.stringIdx + 2 else 6) else p.stringIdx

                                val diff = openMidi[p.stringIdx] - refGuitarMidi[s_idx]
                                val f_rel = (p.fret + diff - rootFret6 + 120) % 12

                                patternMap[s_idx][f_rel].contains(pattern)
                            }.sortedBy { it.fret }

                            if (patternPoints.isNotEmpty()) {
                                val clusters = mutableListOf<MutableList<DrawNote>>()
                                var currentCluster = mutableListOf<DrawNote>()
                                currentCluster.add(patternPoints.first())

                                for (i in 1 until patternPoints.size) {
                                    val p = patternPoints[i]
                                    val prev = patternPoints[i - 1]
                                    if (p.fret - prev.fret > 4) {
                                        clusters.add(currentCluster)
                                        currentCluster = mutableListOf()
                                    }
                                    currentCluster.add(p)
                                }
                                clusters.add(currentCluster)

                                val pathColor = if (isColorEnabled) getCagedColor(pattern).copy(alpha = 0.7f) else lineColor.copy(alpha = 0.5f)
                                clusters.forEach { cluster ->
                                    val sortedCluster = cluster.sortedWith(compareBy({ it.midi }, { -it.stringIdx }))
                                    if (sortedCluster.size > 1) {
                                        val path = Path()
                                        path.moveTo(sortedCluster.first().x, sortedCluster.first().y)
                                        for (i in 1 until sortedCluster.size) { path.lineTo(sortedCluster[i].x, sortedCluster[i].y) }
                                        drawPath(path, color = pathColor, style = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                                    }
                                }
                            }
                        }
                    }
                }

                val wNutGlobal = (secEnd - secStart) * 0.75f
                val minStringSpacing = if (numStrings > 1) wNutGlobal / (numStrings - 1) else 0f
                val minFretHeight = if (isVert) {
                    primaryLen / numFrets
                } else {
                    getFretPos(numFrets) - getFretPos(numFrets - 1)
                }

                val globalMaxR = if (isVert) 46f else (if (displayMode == "FULL") 44f else 40f)
                val globalR = minOf(minStringSpacing * 0.52f, minFretHeight * 0.52f).coerceAtMost(globalMaxR)
                for (p in actualPoints) {
                    val x = p.x
                    val y = p.y
                    val isPressed = (p.stringIdx == pressedString && p.fret == pressedFret)

                    var r = globalR
                    if (isPressed) r *= 1.2f

                    val currentR = if (p.isRoot && !isPressed) r * rootScale else r

                    val interval = ((p.midi % 12) - rootIdx + 12) % 12
                    val romanNumeral = when(interval) {
                        0 -> "I"; 1 -> "bII"; 2 -> "II"; 3 -> "bIII"; 4 -> "III"
                        5 -> "IV"; 6 -> "bV"; 7 -> "V"; 8 -> "bVI"; 9 -> "VI"
                        10 -> "bVII"; 11 -> "VII"; else -> ""
                    }
                    val displayNoteText = if (noteLabelMode == "ROMAN") romanNumeral else p.noteName

                    val fontSize = if (displayNoteText.length > 2) currentR * 0.75f else currentR * 1.15f

                    val txtColor = if (isPressed) android.graphics.Color.BLACK else android.graphics.Color.WHITE
                    val tPaint = android.graphics.Paint().apply {
                        textSize = fontSize
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        color = txtColor
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        if (p.isRoot && !isPressed) alpha = (255 * rootAlpha).toInt()
                    }

                    if (!isColorEnabled) {
                        val circleColor = when {
                            isPressed -> Color.White
                            p.isRoot -> rootColor.copy(alpha = rootAlpha)
                            else -> tunaGreen
                        }
                        drawCircle(color = circleColor, radius = currentR, center = Offset(x, y))
                        if (p.isRoot) {
                            drawCircle(color = textColor.copy(alpha = rootAlpha), radius = currentR, center = Offset(x, y), style = Stroke(width = 4f * rootScale))
                        }
                    } else {
                        if (displayMode == "OCTAVE" && !isPressed) {
                            val octaveColor = getOctaveColor(p.midi)
                            drawCircle(color = octaveColor, radius = currentR, center = Offset(x, y))
                            if (p.isRoot) drawCircle(color = textColor.copy(alpha = rootAlpha), radius = currentR, center = Offset(x, y), style = Stroke(width = 4f * rootScale))
                        } else if ((displayMode == "FULL" || displayMode == "POSITION") && !isChromatic && !isPressed) {

                            val s_idx = if (instrument == "Bass") (if (numStrings == 4) p.stringIdx + 2 else if (p.stringIdx < 4) p.stringIdx + 2 else 6) else p.stringIdx

                            val diff = openMidi[p.stringIdx] - refGuitarMidi[s_idx]
                            val f_rel = (p.fret + diff - rootFret6 + 120) % 12

                            val colorIndices = patternMap[s_idx][f_rel]

                            if (colorIndices.size == 1) {
                                drawCircle(color = getCagedColor(colorIndices[0]), radius = currentR, center = Offset(x, y))
                            } else {
                                val c1 = getCagedColor(colorIndices[0])
                                val c2 = getCagedColor(colorIndices[1])
                                val rectTopLeft = Offset(x - currentR, y - currentR)
                                val rectSize = Size(currentR * 2f, currentR * 2f)
                                drawArc(color = c1, startAngle = 90f, sweepAngle = 180f, useCenter = true, topLeft = rectTopLeft, size = rectSize)
                                drawArc(color = c2, startAngle = -90f, sweepAngle = 180f, useCenter = true, topLeft = rectTopLeft, size = rectSize)
                            }
                            if (p.isRoot) drawCircle(color = textColor.copy(alpha = rootAlpha), radius = currentR, center = Offset(x, y), style = Stroke(width = 4f * rootScale))
                        } else {
                            val circleColor = when {
                                isPressed -> Color.White
                                isChromatic -> tunaGreen
                                p.isRoot -> rootColor.copy(alpha = rootAlpha)
                                else -> scaleColor
                            }
                            drawCircle(color = circleColor, radius = currentR, center = Offset(x, y))
                        }
                    }

                    drawContext.canvas.nativeCanvas.drawText(displayNoteText, x, y - ((tPaint.descent() + tPaint.ascent()) / 2), tPaint)
                }
            }
        }

        val formulaStr = when (scaleType) {
            "Major" -> "1, 2, 3, 4, 5, 6, 7"
            "Minor" -> "1, 2, b3, 4, 5, b6, b7"
            "Pentatonic Major" -> "1, 2, 3, 5, 6"
            "Pentatonic Minor" -> "1, b3, 4, 5, b7"
            else -> "1, b2, 2, b3, 3, 4, b5, 5, b6, 6, b7, 7"
        }
        Text(
            text = "$rootNote $scaleType - $formulaStr",
            color = textColor, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = if(isVert) 4.dp else 2.dp)
        )
        if (isPositional && !isChromatic) {
            val tabNotes = sequenceNotes.filter { it.fret >= 0 && it.fret <= numFrets }
            val tabScrollState = rememberScrollState()

            val configuration = LocalConfiguration.current
            val notesWidthDp = max(configuration.screenWidthDp - 40, tabNotes.size * 40 + 40).dp

            Row(
                modifier = if (isVert) {
                    Modifier.height(120.dp).fillMaxWidth().padding(bottom = 8.dp)
                } else {
                    Modifier.weight(0.45f).fillMaxWidth()
                }
            ) {
                Canvas(modifier = Modifier.width(if(isVert) 30.dp else 40.dp).fillMaxHeight()) {
                    val w = size.width; val h = size.height
                    val tabLineSpacing = h / (numStrings + 1f)
                    val stringNamePaint = android.graphics.Paint().apply { textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; color = textColor.copy(alpha=0.6f).toArgb(); typeface = android.graphics.Typeface.DEFAULT_BOLD; textSize = 26f }

                    for (s in 0 until numStrings) {
                        val y = (s + 1) * tabLineSpacing
                        drawLine(color = textColor.copy(alpha = 0.2f), start = Offset(w * 0.5f, y), end = Offset(w, y), strokeWidth = 2f)
                        drawContext.canvas.nativeCanvas.drawText(stringNames[s], 30f, y - ((stringNamePaint.descent() + stringNamePaint.ascent()) / 2), stringNamePaint)
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight().horizontalScroll(tabScrollState)) {
                    Canvas(modifier = Modifier.width(notesWidthDp).fillMaxHeight()) {
                        val w = size.width; val h = size.height
                        val tabLineSpacing = h / (numStrings + 1f)

                        for (s in 0 until numStrings) {
                            val y = (s + 1) * tabLineSpacing
                            drawLine(color = textColor.copy(alpha = 0.2f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 2f)
                        }

                        if (tabNotes.isNotEmpty()) {
                            val noteSpacing = w / (tabNotes.size + 1)
                            val tabTextPaint = android.graphics.Paint().apply { textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; typeface = android.graphics.Typeface.DEFAULT_BOLD; textSize = 28f }

                            tabNotes.forEachIndexed { index, note ->
                                val x = (index + 1) * noteSpacing
                                val y = (note.stringIdx + 1) * tabLineSpacing
                                drawRect(color = surfaceColor, topLeft = Offset(x - 16f, y - 16f), size = Size(32f, 32f))
                                tabTextPaint.color = if (note.isRoot) rootColor.toArgb() else textColor.copy(alpha = 0.9f).toArgb()
                                drawContext.canvas.nativeCanvas.drawText(note.fret.toString(), x, y - ((tabTextPaint.descent() + tabTextPaint.ascent()) / 2), tabTextPaint)
                            }
                        }
                    }
                }
            }
        } else if (displayMode == "OCTAVE" && isColorEnabled) {
            Row(
                modifier = if (isVert) {
                    Modifier.wrapContentHeight().fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp).horizontalScroll(rememberScrollState())
                } else {
                    Modifier.weight(0.4f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).horizontalScroll(rememberScrollState())
                },
                horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                val octaveLegendColors = listOf(
                    Color(0xFF4CAF50) to "Octave 2",
                    Color(0xFF2196F3) to "Octave 3",
                    Color(0xFFFF9800) to "Octave 4",
                    Color(0xFFE91E63) to "Octave 5"
                )
                octaveLegendColors.forEach { (color, name) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(16.dp).background(color, CircleShape).border(1.dp, Color.White, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(name, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if ((displayMode == "FULL") && !isChromatic && isColorEnabled) {
            Row(
                modifier = if (isVert) {
                    Modifier.wrapContentHeight().fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp).horizontalScroll(rememberScrollState())
                } else {
                    Modifier.weight(0.4f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).horizontalScroll(rememberScrollState())
                },
                horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                val legendColors = listOf(
                    Color(0xFFE53935) to "Pattern 1 (E)",
                    Color(0xFFFFB300) to "Pattern 2 (D)",
                    Color(0xFF43A047) to "Pattern 3 (C)",
                    Color(0xFF1E88E5) to "Pattern 4 (A)",
                    Color(0xFF8E24AA) to "Pattern 5 (G)"
                )
                legendColors.forEach { (color, name) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(16.dp).background(color, CircleShape).border(1.dp, Color.White, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(name, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Spacer(modifier = if (isVert) Modifier.height(8.dp) else Modifier.weight(0.05f))
        }
    }
}

@Composable
fun FullPianoNotesResponsive(
    keyCount: Int, textColor: Color, surfaceColor: Color, tunaGreen: Color,
    rootNote: String, scaleType: String, displayMode: String
) {
    val notes = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val rootIdx = notes.indexOf(rootNote)
    val scaleIntervals = when (scaleType) {
        "Major" -> listOf(0, 2, 4, 5, 7, 9, 11)
        "Minor" -> listOf(0, 2, 3, 5, 7, 8, 10)
        "Pentatonic Major" -> listOf(0, 2, 4, 7, 9)
        "Pentatonic Minor" -> listOf(0, 3, 5, 7, 10)
        else -> (0..11).toList()
    }
    val scaleIndices = scaleIntervals.map { (rootIdx + it) % 12 }
    val isChromatic = scaleType == "Chromatic"

    val whiteKeyMidis = remember(keyCount) {
        val midis = mutableListOf<Int>()
        if (keyCount == 37) {
            for (octave in 3..5) { val b = 12 + octave * 12; midis.addAll(listOf(b, b+2, b+4, b+5, b+7, b+9, b+11)) }
            midis.add(84)
        } else {
            for (octave in 2..6) { val b = 12 + octave * 12; midis.addAll(listOf(b, b+2, b+4, b+5, b+7, b+9, b+11)) }
            midis.add(96)
        }
        midis
    }

    val numWhiteKeys = whiteKeyMidis.size
    var pressedMidi by remember { mutableIntStateOf(-1) }

    Box(
        modifier = Modifier.fillMaxWidth().height(180.dp)
    ) {
        Canvas(
            modifier = Modifier.fillMaxSize().pointerInput(keyCount) {
                val canvasSize = this.size
                detectTapGestures(
                    onPress = { tapOffset ->
                        val w = canvasSize.width.toFloat(); val h = canvasSize.height.toFloat()
                        val keyW = w / numWhiteKeys; val blackKeyW = keyW * 0.6f; val blackKeyH = h * 0.6f
                        var tappedMidi = -1

                        for (i in 0 until numWhiteKeys - 1) {
                            if (whiteKeyMidis[i + 1] - whiteKeyMidis[i] == 2) {
                                val blackKeyLeft = (i + 1) * keyW - (blackKeyW / 2f)
                                if (tapOffset.x >= blackKeyLeft && tapOffset.x <= blackKeyLeft + blackKeyW && tapOffset.y <= blackKeyH) {
                                    tappedMidi = whiteKeyMidis[i] + 1; break
                                }
                            }
                        }

                        if (tappedMidi == -1) {
                            val clickedWhiteIdx = (tapOffset.x / keyW).toInt()
                            if (clickedWhiteIdx in 0 until numWhiteKeys) tappedMidi = whiteKeyMidis[clickedWhiteIdx]
                        }

                        pressedMidi = tappedMidi

                        if (tappedMidi != -1) {
                            try {
                                CoreAudioPlayer.playChord(listOf(tappedMidi), "Piano")
                            } catch (e: Exception) { e.printStackTrace() }
                        }

                        tryAwaitRelease()
                        pressedMidi = -1
                    }
                )
            }
        ) {
            val w = size.width; val h = size.height
            val keyW = w / numWhiteKeys; val blackKeyW = keyW * 0.6f; val blackKeyH = h * 0.58f

            val whiteTextPaint = android.graphics.Paint().apply { textSize = (keyW * 0.5f).coerceIn(12f, 26f); textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; color = android.graphics.Color.BLACK; typeface = android.graphics.Typeface.DEFAULT_BOLD }

            val cornerR = 12f
            for (i in 0 until numWhiteKeys) {
                val x = i * keyW
                val midi = whiteKeyMidis[i]
                val noteIdx = midi % 12
                val isPressed = midi == pressedMidi

                // Trả về màu cơ bản của Piano: Trắng (khi không bấm) và Xám nhạt (khi bấm)
                val keyColor = if (isPressed) Color(0xFFE0E0E0) else Color.White

                drawRoundRect(color = keyColor, topLeft = Offset(x, -cornerR), size = Size(keyW, h + cornerR), cornerRadius = CornerRadius(cornerR, cornerR))
                drawRoundRect(color = Color.Black, topLeft = Offset(x, -cornerR), size = Size(keyW, h + cornerR), cornerRadius = CornerRadius(cornerR, cornerR), style = Stroke(width = 2f))

                // Luôn hiển thị tên nốt trên phím trắng cho dễ nhìn
                val baseNote = notes[noteIdx]
                val octave = (midi / 12) - 1
                drawContext.canvas.nativeCanvas.drawText("$baseNote$octave", x + keyW / 2, h - 22f, whiteTextPaint)
            }

            val blackTextPaint = android.graphics.Paint().apply { textSize = (blackKeyW * 0.6f).coerceIn(10f, 20f); textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; color = android.graphics.Color.WHITE; typeface = android.graphics.Typeface.DEFAULT_BOLD }
            val bCornerR = 8f
            for (i in 0 until numWhiteKeys - 1) {
                if (whiteKeyMidis[i + 1] - whiteKeyMidis[i] == 2) {
                    val blackMidi = whiteKeyMidis[i] + 1
                    val noteIdx = blackMidi % 12
                    val blackKeyLeft = (i + 1) * keyW - (blackKeyW / 2f)
                    val isPressed = blackMidi == pressedMidi

                    // Trả về màu cơ bản của Piano: Đen (khi không bấm) và Xám đậm (khi bấm)
                    val keyColor = if (isPressed) Color(0xFF505050) else Color(0xFF262626)

                    drawRoundRect(color = keyColor, topLeft = Offset(blackKeyLeft, -bCornerR), size = Size(blackKeyW, blackKeyH + bCornerR), cornerRadius = CornerRadius(bCornerR, bCornerR))
                    drawRoundRect(color = Color.Black, topLeft = Offset(blackKeyLeft, -bCornerR), size = Size(blackKeyW, blackKeyH + bCornerR), cornerRadius = CornerRadius(bCornerR, bCornerR), style = Stroke(width = 1.5f))

                    // Bỏ text trên phím đen để giống piano thực tế
                }
            }
        }
    }
}

@Composable
fun MiniFretboardIcon(modifier: Modifier = Modifier, color: Color, numStrings: Int) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawLine(color, Offset(0f, 0f), Offset(w, 0f), strokeWidth = 6f)

        for (i in 1..4) {
            val y = i * (h / 4)
            drawLine(color, Offset(0f, y), Offset(w, y), strokeWidth = 3f)
        }

        val stringSpacing = w / (numStrings - 1)
        for (i in 0 until numStrings) {
            val x = i * stringSpacing
            drawLine(color, Offset(x, 0f), Offset(x, h), strokeWidth = 3f)
        }

        val dotRadius = w * 0.15f * (4f / numStrings)
        val midString1 = numStrings / 2 - 1
        val midString2 = numStrings / 2
        drawCircle(color, radius = dotRadius, center = Offset(stringSpacing * midString1, h / 4 + h / 8))
        drawCircle(color, radius = dotRadius, center = Offset(stringSpacing * midString2, h / 2 + h / 8))
    }
}

@Composable
fun MiniPianoIcon(modifier: Modifier = Modifier, color: Color) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val whiteKeyW = w / 5

        for (i in 0..5) {
            val x = i * whiteKeyW
            drawLine(color, Offset(x, 0f), Offset(x, h), strokeWidth = 3f)
        }
        drawLine(color, Offset(0f, 0f), Offset(w, 0f), strokeWidth = 3f)
        drawLine(color, Offset(0f, h), Offset(w, h), strokeWidth = 3f)

        val blackKeyW = whiteKeyW * 0.6f
        val blackKeyH = h * 0.55f
        val blackKeyOffsets = listOf(1, 2, 4, 5)
        for (i in blackKeyOffsets) {
            val x = i * whiteKeyW - (blackKeyW / 2)
            drawRect(color, topLeft = Offset(x, 0f), size = Size(blackKeyW, blackKeyH))
        }
    }
}