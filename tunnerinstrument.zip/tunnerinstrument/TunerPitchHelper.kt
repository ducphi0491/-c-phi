package ducphi.tunnerinstrument
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.roundToInt

object TunerPitchHelper {
    private val NOTES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    data class PitchResult(val noteName: String, val frequency: Float, val centsDeviation: Float)

    fun processPitch(pitchInHz: Float): PitchResult? {
        if (pitchInHz < 20f || pitchInHz > 2000f) return null // Lọc dải tần số nhiễu (Dưới 20Hz ko nghe được)

        // Tính toán nốt MIDI gần nhất
        val pitchInMidi = (69 + 12 * log2(pitchInHz / 440.0f)).roundToInt()

        // Tính tần số chuẩn (mục tiêu) của nốt MIDI đó
        val targetFreq = 440.0 * 2.0.pow((pitchInMidi - 69) / 12.0)

        // Tính độ lệch (Cents)
        val cents = 1200 * log2(pitchInHz / targetFreq.toFloat())

        val noteName = NOTES[pitchInMidi % 12]

        return PitchResult(noteName, pitchInHz, cents)
    }
}