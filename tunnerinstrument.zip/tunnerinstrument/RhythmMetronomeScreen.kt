package ducphi.tunnerinstrument

import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import ducphi.tunnerinstrument.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

// ==========================================
// TỰ VẼ ICON TÙY CHỈNH CHO THANH MENU
// ==========================================
val InterFontFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_bold, FontWeight.Bold)
)
object LocalCustomIcons {
    val ClickWave: ImageVector
        get() = ImageVector.Builder(name = "ClickWave", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f).apply {
            path(stroke = SolidColor(Color.Black), strokeLineWidth = 2f, strokeLineCap = StrokeCap.Round) {
                moveTo(7f, 10f); lineTo(7f, 14f)
                moveTo(12f, 6f); lineTo(12f, 18f)
                moveTo(17f, 10f); lineTo(17f, 14f)
            }
        }.build()

    val Drum: ImageVector
        get() = ImageVector.Builder(name = "Drum", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f).apply {
            path(stroke = SolidColor(Color.Black), strokeLineWidth = 1.5f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) {
                moveTo(5f, 11f); quadTo(12f, 14f, 19f, 11f)
                moveTo(5f, 11f); quadTo(12f, 8f, 19f, 11f)
                moveTo(5f, 11f); lineTo(5f, 17f)
                quadTo(12f, 20f, 19f, 17f)
                lineTo(19f, 11f)
            }
            path(stroke = SolidColor(Color.Black), strokeLineWidth = 1.5f, strokeLineCap = StrokeCap.Round) {
                moveTo(7f, 4f); lineTo(10.5f, 8f)
                moveTo(17f, 4f); lineTo(13.5f, 8f)
            }
        }.build()
}

@Suppress("UnusedBoxWithConstraintsScope")
@Composable
fun MetronomeScreen(
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    currentLang: String
) {
    val context = LocalContext.current
    val localDensity = LocalDensity.current

    // Bảng màu đơn sắc dùng cho toàn bộ nội dung bên dưới.
    // Riêng ba tab Click / Drummer / Trainer vẫn giữ màu tunaGreen như thiết kế cũ.
    val monochromeAccent = textColor
    val monochromeOnAccent = bgColor
    val monochromeSoft = textColor.copy(alpha = 0.14f)
    val monochromeMedium = textColor.copy(alpha = 0.35f)

    // --- BIẾN TRẠNG THÁI GỌI MÀN HÌNH GÕ NHỊP ---
    var showRhythmTapScreen by remember { mutableStateOf(false) }

    if (showRhythmTapScreen) {
        // RhythmTapScreen dùng tunaGreen làm màu nền các nút hành động và Color.White cho chữ.
        // Không truyền monochromeAccent (= trắng ở Dark Mode), nếu không nút sẽ thành trắng trên trắng.
        RhythmTapScreen(
            bgColor = bgColor,
            surfaceColor = surfaceColor,
            textColor = textColor,
            tunaGreen = tunaGreen,
            currentLang = currentLang,
            onClose = { showRhythmTapScreen = false }
        )
        return
    }

    // Đọc bộ nhớ đệm (Đã sửa lỗi Unresolved reference Context)
    val prefs = context.getSharedPreferences("TunerPrefs", android.content.Context.MODE_PRIVATE)

    var bpm by remember { mutableFloatStateOf(prefs.getFloat("saved_bpm", 120f)) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentBeat by remember { mutableIntStateOf(-1) }

    var selectedSignature by remember { mutableStateOf(prefs.getString("saved_signature", "4/4") ?: "4/4") }
    val beatsPerMeasure = selectedSignature.split("/")[0].toInt()

    // Danh sách các loại nhịp đầy đủ (Đã thêm nhiều loại nhịp phổ biến)
    val timeSignaturesList = listOf("1/4", "2/4", "3/4", "4/4", "5/4", "6/4", "7/4", "3/8", "6/8", "7/8", "9/8", "12/8")

    // Lưu tự động vào cache khi bpm hoặc selectedSignature thay đổi
    LaunchedEffect(bpm, selectedSignature) {
        prefs.edit()
            .putFloat("saved_bpm", bpm)
            .putString("saved_signature", selectedSignature)
            .apply()
    }

    // Lưu trạng thái từng phách: 0 (bình thường/trống), 1 (mạnh ">"), 2 (nhẹ "^")
    var beatStates by remember(beatsPerMeasure) { mutableStateOf(List(beatsPerMeasure) { if (it == 0) 1 else 0 }) }
    val currentBeatStates by rememberUpdatedState(beatStates)

    var selectedMode by remember { mutableStateOf("Metronome") }
    var metronomeVisualType by remember { mutableStateOf("Click") }
    val modes = listOf("Metronome", "Drummer", "Trainer")

    // --- Biến lưu vết click vào tab Nhịp ---
    var metronomeClickTrigger by remember { mutableIntStateOf(0) }
    // --- Biến kích hoạt animation 3s cho 2 icon Nhịp và Trống ---
    var isMenuIconsAnimating by remember { mutableStateOf(false) }

    // --- State cho Icon Bàn Chân trên thanh Menu ---
    var smallFootActiveNote by remember { mutableIntStateOf(-1) }
    var isSmallFootPlaying by remember { mutableStateOf(false) }

    // --- State cho Icon Bàn Chân to ở giữa màn hình ---
    var bigFootActiveNote by remember { mutableIntStateOf(-1) }
    var isBigFootPlaying by remember { mutableStateOf(false) }

    // --- State cho Trống ---
    var showDrumSelector by remember { mutableStateOf(false) }
    var drumFiles by remember { mutableStateOf<Map<String, List<String>>>(emptyMap()) }
    var selectedDrumSound by remember { mutableStateOf("") }

    // --- State cho Click/Pendulum Âm thanh ---
    var showClickSoundSelector by remember { mutableStateOf(false) }
    var clickSoundOptions by remember { mutableStateOf(listOf("Standard Click")) }
    var selectedClickSound by remember { mutableStateOf("Standard Click") }

    // BIẾN TRIGGER ĐỂ ÉP BUỘC TẢI LẠI ÂM THANH MỖI KHI CLICK CHỌN
    var forceReloadAudioTrigger by remember { mutableIntStateOf(0) }

    // Khai báo state cho ID âm thanh để thay đổi linh hoạt khi tải từ mạng
    var strongBeatId by remember { mutableIntStateOf(0) }
    var weakBeatId by remember { mutableIntStateOf(0) }

    var swingDirection by remember { mutableStateOf(1f) }

    // Chạy animation 3 giây cho icon Nhịp và Trống
    LaunchedEffect(metronomeClickTrigger) {
        isMenuIconsAnimating = true
        delay(3000)
        isMenuIconsAnimating = false
    }

    // Logic đồng bộ hóa các hiệu ứng bàn chân
    LaunchedEffect(selectedMode, metronomeClickTrigger) {
        if (selectedMode != "Metronome" && selectedMode != "Drummer") {
            isPlaying = false
            currentBeat = -1
        }

        if (selectedMode == "Metronome") {
            isSmallFootPlaying = true
            isBigFootPlaying = false
            delay(150)
            for (i in 0 until 4) {
                smallFootActiveNote = i
                delay(600)
            }
            smallFootActiveNote = -1
            isSmallFootPlaying = false
        } else if (selectedMode == "Trainer") {
            isSmallFootPlaying = false
            smallFootActiveNote = -1

            isBigFootPlaying = true
            var i = 0
            while (true) {
                bigFootActiveNote = i++
                delay(600)
            }
        } else {
            isSmallFootPlaying = false
            smallFootActiveNote = -1
            isBigFootPlaying = false
            bigFootActiveNote = -1
        }
    }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val apiUrl = "https://tunertools.top/api_songs.php?action=get_drum_sounds"
                val url = java.net.URL(apiUrl)
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                if (connection.responseCode == 200) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }.trim()
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        try {
                            val jsonObject = org.json.JSONObject(response)
                            val map = mutableMapOf<String, List<String>>()
                            val keys = jsonObject.keys()
                            while (keys.hasNext()) {
                                val key = keys.next()
                                val array = jsonObject.getJSONArray(key)
                                val list = List(array.length()) { array.getString(it) }
                                map[key] = list
                            }
                            if (map.isNotEmpty()) {
                                drumFiles = map
                                if (selectedDrumSound.isEmpty() && !map.containsKey("LỖI")) {
                                    val firstFolder = map.keys.first()
                                    if (map[firstFolder]!!.isNotEmpty()) {
                                        selectedDrumSound = map[firstFolder]!![0]
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            drumFiles = mapOf("LỖI" to listOf("Server không trả về JSON hợp lệ"))
                        }
                    }
                } else {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        drumFiles = mapOf("LỖI HTTP" to listOf(connection.responseCode.toString()))
                    }
                }
            } catch (e: Exception) {
                // Rớt mạng -> Fallback dùng âm thanh cục bộ
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    val files = context.assets.list("drums")?.toList()?.filter { it != "metronome.wav" } ?: emptyList()
                    if (files.isNotEmpty()) {
                        drumFiles = mapOf("Mặc định" to files)
                        if (selectedDrumSound.isEmpty()) {
                            selectedDrumSound = files[0]
                        }
                    } else {
                        drumFiles = mapOf("LỖI" to listOf("Mất kết nối và không có thư mục trống offline"))
                    }
                }
            }
        }
    }

    val soundPool = remember {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        SoundPool.Builder().setMaxStreams(8).setAudioAttributes(audioAttributes).build()
    }

    // Gọi API để lấy danh sách tên âm thanh từ Server khi khởi chạy
    LaunchedEffect(Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val apiUrl = "https://tunertools.top/api_songs.php?action=get_metronome_sounds"
                val url = java.net.URL(apiUrl)
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val responseCode = connection.responseCode

                if (responseCode == 200) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }.trim()

                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        try {
                            val jsonArray = org.json.JSONArray(response)
                            val serverList = List(jsonArray.length()) { jsonArray.getString(it) }

                            // LUÔN CHÈN "Standard Click" VÀO ĐẦU DANH SÁCH ĐỂ NGƯỜI DÙNG CÓ THỂ CHỌN OFFLINE
                            val finalList = mutableListOf("Standard Click")
                            finalList.addAll(serverList.filter { it != "Standard Click" })

                            if (finalList.isNotEmpty()) {
                                clickSoundOptions = finalList
                                if (!finalList.contains(selectedClickSound)) {
                                    selectedClickSound = finalList[0]
                                }
                                forceReloadAudioTrigger++ // Ép trigger tải âm thanh lần đầu
                            }
                        } catch (parseException: Exception) {
                            forceReloadAudioTrigger++ // Nếu lỗi API vẫn phải gọi để load âm thanh gốc
                        }
                    }
                } else {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        forceReloadAudioTrigger++ // Lỗi kết nối, ép trigger để load âm gốc
                    }
                }
            } catch (e: Exception) {
                // TRƯỜNG HỢP MẤT MẠNG INTERNET KHI MỞ APP
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    clickSoundOptions = listOf("Standard Click")
                    selectedClickSound = "Standard Click"
                    forceReloadAudioTrigger++ // Ép trigger để load âm thanh từ máy
                    android.widget.Toast.makeText(context, "Chế độ ngoại tuyến. Đang dùng âm thanh mặc định.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

// Lắng nghe biến TRIGGER thay vì selectedClickSound để bắt buộc chạy mỗi khi bấm
    LaunchedEffect(forceReloadAudioTrigger) {
        if (forceReloadAudioTrigger == 0) return@LaunchedEffect

        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                // 1. NẾU ĐANG CHỌN ÂM THANH GỐC (HOẶC MẤT MẠNG) -> LẤY FILE TRỰC TIẾP TRONG RAW
                if (selectedClickSound == "Standard Click") {
                    val sId = soundPool.load(context, R.raw.metronome_strong, 1)
                    val wId = soundPool.load(context, R.raw.metronome_weak, 1)

                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        strongBeatId = sId
                        weakBeatId = wId
                    }
                    return@withContext // Ngừng tại đây, không tải từ server nữa
                }

                // 2. NẾU CÓ MẠNG VÀ CHỌN ÂM THANH KHÁC -> BẮT ĐẦU TẢI TỪ SERVER
                val baseUrl = "https://tunertools.top/api_songs.php"
                val fileName = selectedClickSound.trim().lowercase(java.util.Locale.getDefault()) + ".wav"
                val encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8").replace("+", "%20")
                val fileUrl = "$baseUrl?action=download_sound&file=$encodedFileName"

                val cacheFile = java.io.File(context.cacheDir, fileName)

                if (!cacheFile.exists() || cacheFile.length() < 100) {
                    val url = java.net.URL(fileUrl)
                    val connection = url.openConnection() as java.net.HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 5000
                    connection.readTimeout = 5000

                    val responseCode = connection.responseCode

                    if (responseCode == 200) {
                        connection.inputStream.use { input ->
                            java.io.FileOutputStream(cacheFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                    } else {
                        // Trả về lỗi 404 hoặc lỗi mạng để nhảy thẳng xuống catch
                        throw Exception("Lỗi HTTP $responseCode")
                    }
                }

                val loadedSoundId = soundPool.load(cacheFile.absolutePath, 1)

                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    strongBeatId = loadedSoundId
                    weakBeatId = loadedSoundId
                }

            } catch (e: Exception) {
                // 3. XỬ LÝ KHỦNG HOẢNG: MẤT MẠNG GIỮA CHỪNG KHI ĐANG TẢI FILE HOẶC FILE KHÔNG TỒN TẠI
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    // Tự động chuyển UI hiển thị lại "Standard Click"
                    selectedClickSound = "Standard Click"

                    // Phát luôn âm thanh mặc định offline
                    strongBeatId = soundPool.load(context, R.raw.metronome_strong, 1)
                    weakBeatId = soundPool.load(context, R.raw.metronome_weak, 1)

                    // Báo lỗi cho người dùng
                    android.widget.Toast.makeText(context, "Lỗi mạng hoặc tải file thất bại! Đã tự động chuyển về âm thanh gốc.", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val metronomeSoundId = remember {
        var id = 0
        try {
            context.assets.openFd("drums/metronome.wav").use { afd ->
                id = soundPool.load(afd, 1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        id
    }

    val mediaPlayer = remember { android.media.MediaPlayer() }

    DisposableEffect(Unit) {
        onDispose {
            soundPool.release()
            mediaPlayer.release()
        }
    }

    // 1. TỰ ĐỘNG TÌM BPM GỐC TỪ TÊN FILE ĐỂ TÍNH TỶ LỆ (Ví dụ: "Holizna90 bpm" -> 90)
    val originalDrumBpm = remember(selectedDrumSound) {
        val matchBpm = Regex("(?i)(\\d+)\\s*bpm").find(selectedDrumSound)
        if (matchBpm != null) {
            matchBpm.groupValues[1].toFloatOrNull() ?: 120f
        } else {
            val matchNum = Regex("(\\d+)").findAll(selectedDrumSound.substringBeforeLast(".")).lastOrNull()
            matchNum?.value?.toFloatOrNull() ?: 120f
        }
    }

    // 2. KHỐI TẢI NHẠC - Áp dụng tốc độ ngay khi vừa tải xong
    LaunchedEffect(selectedDrumSound) {
        if (selectedDrumSound.isNotEmpty()) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val baseUrl = "https://tunertools.top/api_songs.php"
                    val fileName = selectedDrumSound
                    val encodedFileName = java.net.URLEncoder.encode(fileName, "UTF-8").replace("+", "%20")
                    val fileUrl = "$baseUrl?action=download_drum_sound&file=$encodedFileName"

                    val safeCacheName = fileName.replace("/", "_")
                    val cacheFile = java.io.File(context.cacheDir, safeCacheName)

                    if (!cacheFile.exists() || cacheFile.length() < 100) {
                        val url = java.net.URL(fileUrl)
                        val connection = url.openConnection() as java.net.HttpURLConnection
                        connection.requestMethod = "GET"
                        connection.connectTimeout = 5000
                        connection.readTimeout = 5000

                        if (connection.responseCode == 200) {
                            connection.inputStream.use { input ->
                                java.io.FileOutputStream(cacheFile).use { output ->
                                    input.copyTo(output)
                                }
                            }
                        } else {
                            throw java.lang.Exception("HTTP " + connection.responseCode)
                        }
                    }

                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        mediaPlayer.reset()
                        mediaPlayer.setDataSource(cacheFile.absolutePath)
                        mediaPlayer.prepare()
                        mediaPlayer.isLooping = true
                        if (isPlaying && selectedMode == "Drummer") {
                            mediaPlayer.start()
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                val params = mediaPlayer.playbackParams
                                params.speed = (bpm / originalDrumBpm).coerceIn(0.25f, 4.0f)
                                mediaPlayer.playbackParams = params
                            }
                        }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        try {
                            mediaPlayer.reset()
                            val offlineFileName = selectedDrumSound.substringAfterLast("/")
                            val descriptor = context.assets.openFd("drums/$offlineFileName")
                            mediaPlayer.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
                            descriptor.close()
                            mediaPlayer.prepare()
                            mediaPlayer.isLooping = true
                            if (isPlaying && selectedMode == "Drummer") {
                                mediaPlayer.start()
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                    val params = mediaPlayer.playbackParams
                                    params.speed = (bpm / originalDrumBpm).coerceIn(0.25f, 4.0f)
                                    mediaPlayer.playbackParams = params
                                }
                            }
                        } catch (ex: Exception) {
                            ex.printStackTrace()
                        }
                    }
                }
            }
        }
    }

    // 3. KHỐI LẮNG NGHE - Lập tức thay đổi tốc độ khi người dùng kéo thanh BPM
    LaunchedEffect(isPlaying, bpm, selectedMode, originalDrumBpm) {
        if (selectedMode == "Drummer") {
            if (isPlaying) {
                if (!mediaPlayer.isPlaying) mediaPlayer.start()
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    try {
                        // Tính toán tốc độ kéo dãn dựa trên BPM hiện tại và BPM gốc
                        val targetSpeed = (bpm / originalDrumBpm).coerceIn(0.25f, 4.0f)
                        val params = mediaPlayer.playbackParams

                        // Chỉ cập nhật nếu tốc độ có sự thay đổi để tối ưu hiệu năng
                        if (kotlin.math.abs(params.speed - targetSpeed) > 0.01f) {
                            params.speed = targetSpeed
                            mediaPlayer.playbackParams = params
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } else {
                if (mediaPlayer.isPlaying) mediaPlayer.pause()
            }
        } else {
            if (mediaPlayer.isPlaying) mediaPlayer.pause()
        }
    }

    LaunchedEffect(isPlaying, bpm, beatsPerMeasure, selectedMode, metronomeVisualType) {
        if (isPlaying && selectedMode == "Metronome") {
            currentBeat = 0
            var nextBeatTime = System.currentTimeMillis()
            while (true) {
                if (metronomeVisualType == "Click") {
                    val currentAccent = currentBeatStates[currentBeat]

                    android.util.Log.d("MetronomePlay", "Đang cố phát - strongBeatId: $strongBeatId | weakBeatId: $weakBeatId")

                    when (currentAccent) {
                        1 -> if(strongBeatId != 0) soundPool.play(strongBeatId, 1f, 1f, 1, 0, 1f)
                        2 -> if(weakBeatId != 0) soundPool.play(weakBeatId, 1f, 1f, 1, 0, 1.2f)
                        else -> if(weakBeatId != 0) soundPool.play(weakBeatId, 0.4f, 0.4f, 1, 0, 1f)
                    }
                } else if (metronomeVisualType == "Pendulum") {
                    if (metronomeSoundId != 0) {
                        soundPool.play(metronomeSoundId, 1f, 1f, 1, 0, 1f)
                    }
                }

                swingDirection *= -1f

                val delayMillis = (60000f / bpm).toLong()
                nextBeatTime += delayMillis
                val timeToSleep = nextBeatTime - System.currentTimeMillis()
                if (timeToSleep > 0) delay(timeToSleep)

                currentBeat = (currentBeat + 1) % beatsPerMeasure
            }
        } else {
            currentBeat = -1
            swingDirection = 1f
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(bgColor).padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ==========================================
        // KHỞI TẠO ANIMATION CHO CÁC ICON MENU
        // ==========================================
        val menuIconTransition = rememberInfiniteTransition(label = "menuIcons")
        val metronomeMenuAngle by menuIconTransition.animateFloat(
            initialValue = -25f,
            targetValue = 25f,
            animationSpec = infiniteRepeatable(
                animation = tween(200, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "metronomeMenuAngle"
        )
        val drumMenuScale by menuIconTransition.animateFloat(
            initialValue = 0.85f,
            targetValue = 1.25f,
            animationSpec = infiniteRepeatable(
                animation = tween(250, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "drumMenuScale"
        )

        // ==========================================
        // THANH MENU VIÊN THUỐC 3D (NEUMORPHISM)
        // ==========================================
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(CircleShape)
                .background(surfaceColor.copy(alpha = 0.4f))
                .border(
                    width = 1.5.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.4f),
                            Color.White.copy(alpha = 0.05f)
                        )
                    ),
                    shape = CircleShape
                )
                .padding(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val configuration = androidx.compose.ui.platform.LocalConfiguration.current
                val screenWidth = configuration.screenWidthDp

                val dynamicFontSize = when {
                    screenWidth < 360 -> 10.sp
                    screenWidth < 400 -> 10.sp
                    else -> 13.sp
                }

                modes.forEach { mode ->
                    val isSelected = selectedMode == mode

                    val displayTitle = when (mode) {
                        "Metronome" -> if (metronomeVisualType == "Click") {
                            CoreTranslator.getString("click_tab", currentLang)
                        } else {
                            CoreTranslator.getString("classic_tab", currentLang)
                        }

                        "Drummer" -> CoreTranslator.getString("drummer_tab", currentLang)
                        "Trainer" -> CoreTranslator.getString("trainer_tab", currentLang)
                        else -> ""
                    }

                    val icon = when (mode) {
                        "Metronome" -> if (metronomeVisualType == "Click") LocalCustomIcons.ClickWave else CustomIcons.Metronome
                        "Drummer" -> LocalCustomIcons.Drum
                        else -> Icons.Default.Star
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(CircleShape)
                            .background(
                                brush = if (isSelected) {
                                    Brush.verticalGradient(
                                        colors = listOf(tunaGreen.copy(alpha = 0.7f), tunaGreen)
                                    )
                                } else SolidColor(Color.Transparent)
                            )
                            .then(
                                if (isSelected) {
                                    Modifier.border(
                                        width = 1.dp,
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = 0.4f),
                                                Color.Black.copy(alpha = 0.2f)
                                            )
                                        ),
                                        shape = CircleShape
                                    )
                                } else Modifier
                            )
                            .clickable {
                                if (mode == "Metronome") {
                                    metronomeClickTrigger++
                                    if (selectedMode == "Metronome") {
                                        metronomeVisualType =
                                            if (metronomeVisualType == "Click") "Pendulum" else "Click"
                                    } else {
                                        selectedMode = "Metronome"
                                    }
                                } else {
                                    selectedMode = mode
                                }
                            }
                            .height(50.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            if (mode == "Trainer") {
                                AnimatedFootCanvas(
                                    activeNoteIndex = if (selectedMode == "Metronome" && isPlaying) currentBeat else if (isSmallFootPlaying) smallFootActiveNote else -1,
                                    isPlaying = (selectedMode == "Metronome" && isPlaying) || isSmallFootPlaying,
                                    color = if (isSelected) Color.White else textColor.copy(
                                        alpha = 0.6f
                                    ),
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                var modifierIcon = Modifier.size(20.dp)

                                if (isMenuIconsAnimating) {
                                    if (mode == "Metronome") {
                                        modifierIcon = modifierIcon.graphicsLayer {
                                            rotationZ = metronomeMenuAngle
                                            transformOrigin = TransformOrigin(0.5f, 0.8f)
                                        }
                                    } else if (mode == "Drummer") {
                                        modifierIcon = modifierIcon.graphicsLayer {
                                            scaleX = drumMenuScale
                                            scaleY = drumMenuScale
                                        }
                                    }
                                }

                                Icon(
                                    imageVector = icon,
                                    contentDescription = mode,
                                    tint = if (isSelected) Color.White else textColor.copy(alpha = 0.6f),
                                    modifier = modifierIcon
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(
                                text = displayTitle,
                                color = if (isSelected) Color.White else textColor.copy(alpha = 0.8f),
                                fontWeight = FontWeight.Bold,
                                fontSize = dynamicFontSize,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                maxLines = 1,
                                lineHeight = (dynamicFontSize.value * 1.2).sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ==========================================
        // KHỐI RENDER NỘI DUNG THEO MODE
        // ==========================================
        if (selectedMode == "Metronome" && metronomeVisualType == "Click") {
            // --- GIAO DIỆN NHỊP (CLICK) ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { showClickSoundSelector = true },
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = "Sound", tint = Color.LightGray)
                }
                Column(modifier = Modifier.clickable { showClickSoundSelector = true }) {
                    Text(
                        text = selectedClickSound,
                        color = monochromeAccent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CoreTranslator.getString("select_sound", currentLang),
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }
            }
            Spacer(modifier = Modifier.weight(0.5f))
            // THUẬT TOÁN KÍCH THƯỚC ĐỘNG: Tự động co giãn hoàn hảo theo số lượng nhịp
            val dynamicPadding = if (beatsPerMeasure <= 5) 6.dp else 2.dp
            // Lấy xấp xỉ chiều rộng màn hình (340dp) trừ đi tổng khoảng trống padding, sau đó chia đều cho số lượng nhịp
            val dynamicBoxSize = ((340f - (beatsPerMeasure * dynamicPadding.value * 2)) / beatsPerMeasure).coerceAtMost(56f).dp
            val dynamicFontSize = (dynamicBoxSize.value * 0.5f).sp // Chữ luôn bằng 50% kích thước ô
            val dynamicCorner = (dynamicBoxSize.value * 0.2f).dp   // Bo góc luôn bằng 20% kích thước ô

            // Mỗi phách có một màu riêng. Khi tempo chạy, ô đang phát sẽ nâng lên,
            // nghiêng nhẹ theo phối cảnh và đổi gradient để tạo cảm giác phím 3D thật.
            val beat3DColors = remember {
                listOf(
                    Color(0xFF29B6F6), // xanh trời
                    Color(0xFF7E57C2), // tím
                    Color(0xFFFFB74D), // cam vàng
                    Color(0xFF26A69A), // xanh ngọc
                    Color(0xFFEC407A), // hồng
                    Color(0xFF5C6BC0), // chàm
                    Color(0xFF66BB6A)  // xanh lá
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(88.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until beatsPerMeasure) {
                    val isActive = isPlaying && i == currentBeat
                    val state = beatStates[i]
                    val beatColor = beat3DColors[i % beat3DColors.size]
                    val beatDark = beatColor.copy(alpha = 0.58f)

                    val lift by animateDpAsState(
                        targetValue = if (isActive) (-8).dp else 0.dp,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        label = "beatLift_$i"
                    )
                    val depth by animateDpAsState(
                        targetValue = if (isActive) 7.dp else 3.dp,
                        animationSpec = tween(120),
                        label = "beatDepth_$i"
                    )
                    val scale3D by animateFloatAsState(
                        targetValue = if (isActive) 1.09f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "beatScale3D_$i"
                    )
                    val tilt3D by animateFloatAsState(
                        targetValue = if (isActive) -8f else 0f,
                        animationSpec = tween(110),
                        label = "beatTilt3D_$i"
                    )
                    val glowAlpha by animateFloatAsState(
                        targetValue = if (isActive) 0.72f else 0f,
                        animationSpec = tween(130),
                        label = "beatGlow_$i"
                    )
                    val iconColor by animateColorAsState(
                        targetValue = if (isActive) Color.White else textColor.copy(alpha = 0.62f),
                        animationSpec = tween(120),
                        label = "beatIconColor_$i"
                    )

                    Box(
                        modifier = Modifier
                            .padding(horizontal = dynamicPadding)
                            .size(dynamicBoxSize)
                            .offset(y = lift),
                        contentAlignment = Alignment.Center
                    ) {
                        // Lớp chân phím nằm thấp hơn, tạo độ dày như một nút bấm thật.
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .offset(y = depth)
                                .clip(RoundedCornerShape(dynamicCorner))
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = if (isActive) {
                                            listOf(beatDark, beatColor.copy(alpha = 0.30f))
                                        } else {
                                            listOf(
                                                Color.Black.copy(alpha = 0.62f),
                                                Color.Black.copy(alpha = 0.28f)
                                            )
                                        }
                                    )
                                )
                        )

                        // Hào quang chỉ xuất hiện ở phách đang chạy.
                        if (glowAlpha > 0.01f) {
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .graphicsLayer {
                                        scaleX = 1.28f
                                        scaleY = 1.28f
                                        alpha = glowAlpha
                                    }
                                    .background(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                beatColor.copy(alpha = 0.38f),
                                                beatColor.copy(alpha = 0.10f),
                                                Color.Transparent
                                            )
                                        ),
                                        shape = RoundedCornerShape(dynamicCorner)
                                    )
                            )
                        }

                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .graphicsLayer {
                                    scaleX = scale3D
                                    scaleY = scale3D
                                    rotationX = tilt3D
                                    cameraDistance = 12f * localDensity.density
                                    shadowElevation = with(localDensity) {
                                        (if (isActive) 13.dp else 4.dp).toPx()
                                    }
                                    transformOrigin = TransformOrigin(0.5f, 1f)
                                    shape = RoundedCornerShape(dynamicCorner)
                                    clip = true
                                }
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = if (isActive) {
                                            listOf(
                                                Color.White.copy(alpha = 0.78f),
                                                beatColor,
                                                beatColor.copy(alpha = 0.78f)
                                            )
                                        } else {
                                            listOf(
                                                textColor.copy(alpha = 0.13f),
                                                surfaceColor.copy(alpha = 0.94f),
                                                bgColor.copy(alpha = 0.90f)
                                            )
                                        }
                                    )
                                )
                                .border(
                                    width = if (isActive) 1.6.dp else 1.dp,
                                    color = if (isActive) Color.White.copy(alpha = 0.82f)
                                    else textColor.copy(alpha = 0.28f),
                                    shape = RoundedCornerShape(dynamicCorner)
                                )
                                .clickable {
                                    val newStates = beatStates.toMutableList()
                                    newStates[i] = (newStates[i] + 1) % 3
                                    beatStates = newStates
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            // Vệt phản sáng trên mặt phím làm bề mặt trông cong và có chiều sâu.
                            Canvas(modifier = Modifier.matchParentSize()) {
                                drawLine(
                                    color = Color.White.copy(alpha = if (isActive) 0.72f else 0.16f),
                                    start = Offset(size.width * 0.20f, size.height * 0.18f),
                                    end = Offset(size.width * 0.80f, size.height * 0.18f),
                                    strokeWidth = 1.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                                if (isActive) {
                                    drawCircle(
                                        color = Color.White.copy(alpha = 0.22f),
                                        radius = size.minDimension * 0.12f,
                                        center = Offset(size.width * 0.32f, size.height * 0.31f)
                                    )
                                }
                            }

                            when (state) {
                                1 -> Text(
                                    ">",
                                    color = iconColor,
                                    fontSize = dynamicFontSize,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                2 -> Text(
                                    "^",
                                    color = iconColor,
                                    fontSize = dynamicFontSize,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                else -> if (isActive) {
                                    Box(
                                        modifier = Modifier
                                            .size((dynamicBoxSize.value * 0.16f).dp)
                                            .background(Color.White.copy(alpha = 0.88f), CircleShape)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.weight(0.5f))
            Text(bpm.roundToInt().toString(), color = textColor, fontSize = 80.sp, fontWeight = FontWeight.ExtraBold)
            Text("BPM", color = Color.Gray, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(40.dp))
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(onClick = { if (bpm > 10f) bpm -= 1f }, modifier = Modifier.background(surfaceColor, CircleShape).size(48.dp)) { Icon(Icons.Default.Remove, "Decrease", tint = textColor) }
                Slider(value = bpm, onValueChange = { bpm = it }, valueRange = 10f..400f, modifier = Modifier.weight(1f).padding(horizontal = 16.dp), colors = SliderDefaults.colors(thumbColor = monochromeAccent, activeTrackColor = monochromeAccent, inactiveTrackColor = monochromeSoft))
                IconButton(onClick = { if (bpm < 400f) bpm += 1f }, modifier = Modifier.background(surfaceColor, CircleShape).size(48.dp)) { Icon(Icons.Default.Add, "Increase", tint = textColor) }
            }
            Spacer(modifier = Modifier.height(40.dp))
            val scrollState = rememberScrollState()
            Row(modifier = Modifier.padding(horizontal = 24.dp).background(surfaceColor, RoundedCornerShape(12.dp)).horizontalScroll(scrollState).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                timeSignaturesList.forEach { sig ->
                    val isSelected = selectedSignature == sig
                    Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (isSelected) monochromeAccent else Color.Transparent).clickable { selectedSignature = sig; currentBeat = -1 }.padding(horizontal = 16.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(sig, color = if (isSelected) monochromeOnAccent else textColor, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            FloatingActionButton(onClick = { isPlaying = !isPlaying }, containerColor = monochromeAccent, contentColor = monochromeOnAccent, modifier = Modifier.size(80.dp), shape = CircleShape) {
                Icon(if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow, if (isPlaying) "Stop" else "Play", modifier = Modifier.size(40.dp))
            }
            Spacer(modifier = Modifier.height(20.dp))

        } else if (selectedMode == "Metronome" && metronomeVisualType == "Pendulum") {
            // --- GIAO DIỆN CỔ ĐIỂN (PENDULUM) ---
            val tempoName = when {
                bpm < 60 -> "Largo"
                bpm < 76 -> "Adagio"
                bpm < 108 -> "Andante"
                bpm < 120 -> "Moderato"
                bpm < 168 -> "Allegro"
                else -> "Presto"
            }

            val animatedAngle by animateFloatAsState(
                targetValue = if (isPlaying) 35f * swingDirection else 0f,
                animationSpec = tween(durationMillis = if (isPlaying) (60000 / bpm).toInt() else 300, easing = LinearEasing),
                label = "swingAnim"
            )

            val metalGradient = Brush.horizontalGradient(
                colors = listOf(
                    Color(0xFF9E9E9E),
                    Color(0xFFE0E0E0),
                    Color(0xFF757575)
                )
            )

            val brassGradient = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFF1F1F1),
                    Color(0xFFBDBDBD),
                    Color(0xFF6F6F6F)
                )
            )

            Column(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 24.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    val canvasHeightFloat = maxHeight.value

                    // LỚP 1: HÌNH THANG GỖ & LỚP KÍNH 3D
                    Canvas(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        val topWidth = canvasWidth * 0.35f
                        val bottomWidth = canvasWidth * 0.9f
                        val leftTop = Offset((canvasWidth - topWidth) / 2, 0f)
                        val rightTop = Offset((canvasWidth + topWidth) / 2, 0f)
                        val leftBottom = Offset((canvasWidth - bottomWidth) / 2, canvasHeight)
                        val rightBottom = Offset((canvasWidth + bottomWidth) / 2, canvasHeight)

                        val path = Path().apply {
                            moveTo(leftTop.x, leftTop.y)
                            lineTo(rightTop.x, rightTop.y)
                            lineTo(rightBottom.x, rightBottom.y)
                            lineTo(leftBottom.x, leftBottom.y)
                            close()
                        }

                        drawIntoCanvas { canvas ->
                            val nativeCanvas = canvas.nativeCanvas

                            // Bóng đổ 3D
                            val shadowPaint = android.graphics.Paint().apply {
                                isAntiAlias = true
                                pathEffect = android.graphics.CornerPathEffect(60f)
                                style = android.graphics.Paint.Style.FILL
                                color = android.graphics.Color.TRANSPARENT
                                setShadowLayer(30f, 0f, 15f, android.graphics.Color.argb(180, 0, 0, 0))
                            }
                            nativeCanvas.drawPath(path.asAndroidPath(), shadowPaint)

                            // Nền Gỗ
                            val fillPaint = android.graphics.Paint().apply {
                                isAntiAlias = true
                                pathEffect = android.graphics.CornerPathEffect(60f)
                                style = android.graphics.Paint.Style.FILL
                                shader = android.graphics.LinearGradient(
                                    0f, 0f, 0f, canvasHeight,
                                    intArrayOf(
                                        android.graphics.Color.parseColor("#444444"),
                                        android.graphics.Color.parseColor("#252525"),
                                        android.graphics.Color.parseColor("#101010")
                                    ),
                                    null,
                                    android.graphics.Shader.TileMode.CLAMP
                                )
                            }
                            nativeCanvas.drawPath(path.asAndroidPath(), fillPaint)

                            // Viền chìm
                            val strokePaint = android.graphics.Paint().apply {
                                isAntiAlias = true
                                pathEffect = android.graphics.CornerPathEffect(60f)
                                style = android.graphics.Paint.Style.STROKE
                                strokeWidth = 3.dp.toPx()
                                color = android.graphics.Color.argb(128, 0, 0, 0)
                            }
                            nativeCanvas.drawPath(path.asAndroidPath(), strokePaint)
                        }

                        // Vạch chia
                        val tickCount = 8
                        val startFraction = 0.15f
                        val endFraction = 0.65f

                        for (i in 0..tickCount) {
                            val fraction = startFraction + (endFraction - startFraction) * (i.toFloat() / tickCount)
                            val yPos = canvasHeight * fraction
                            val leftX = leftTop.x + (leftBottom.x - leftTop.x) * fraction
                            val rightX = rightTop.x + (rightBottom.x - rightTop.x) * fraction
                            val tickLength = if (i % 2 == 0) 18f else 10f

                            drawLine(Color.Black, Offset(leftX + 16f, yPos + 3f), Offset(leftX + 16f + tickLength, yPos + 3f), 4.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(Color.Black, Offset(rightX - 16f, yPos + 3f), Offset(rightX - 16f - tickLength, yPos + 3f), 4.dp.toPx(), cap = StrokeCap.Round)

                            drawLine(Color(0xFFBDBDBD), Offset(leftX + 16f, yPos), Offset(leftX + 16f + tickLength, yPos), 3.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(Color(0xFFBDBDBD), Offset(rightX - 16f, yPos), Offset(rightX - 16f - tickLength, yPos), 3.dp.toPx(), cap = StrokeCap.Round)
                        }

                        // Phủ kính
                        drawIntoCanvas { canvas ->
                            val nativeCanvas = canvas.nativeCanvas
                            val glassGlarePaint = android.graphics.Paint().apply {
                                isAntiAlias = true
                                pathEffect = android.graphics.CornerPathEffect(60f)
                                style = android.graphics.Paint.Style.FILL
                                shader = android.graphics.LinearGradient(
                                    0f, 0f, canvasWidth, canvasHeight,
                                    intArrayOf(
                                        android.graphics.Color.argb(80, 255, 255, 255),
                                        android.graphics.Color.argb(0, 255, 255, 255),
                                        android.graphics.Color.argb(30, 255, 255, 255)
                                    ),
                                    floatArrayOf(0f, 0.4f, 1f),
                                    android.graphics.Shader.TileMode.CLAMP
                                )
                            }
                            nativeCanvas.drawPath(path.asAndroidPath(), glassGlarePaint)

                            val glassEdgePaint = android.graphics.Paint().apply {
                                isAntiAlias = true
                                pathEffect = android.graphics.CornerPathEffect(60f)
                                style = android.graphics.Paint.Style.STROKE
                                strokeWidth = 2.dp.toPx()
                                shader = android.graphics.LinearGradient(
                                    0f, 0f, canvasWidth, canvasHeight,
                                    intArrayOf(
                                        android.graphics.Color.argb(180, 255, 255, 255),
                                        android.graphics.Color.argb(20, 255, 255, 255),
                                        android.graphics.Color.argb(100, 255, 255, 255)
                                    ),
                                    null,
                                    android.graphics.Shader.TileMode.CLAMP
                                )
                            }
                            nativeCanvas.drawPath(path.asAndroidPath(), glassEdgePaint)
                        }
                    }

                    // LỚP 2: Khối số [- 120 +]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .height(90.dp)
                            .background(Color.Transparent)
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("–", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { if (bpm > 10) bpm -= 1 }.padding(12.dp))
                        Text(bpm.roundToInt().toString(), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Black)
                        Text("+", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { if (bpm < 400) bpm += 1 }.padding(12.dp))
                    }

                    // LỚP 3: Con lắc
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 90.dp, top = 40.dp)
                            .graphicsLayer {
                                rotationZ = animatedAngle
                                transformOrigin = TransformOrigin(0.5f, 1f)
                            },
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .offset(y = (-15).dp)
                                .width(6.dp)
                                .fillMaxHeight(0.95f)
                                .background(metalGradient)
                        )

                        val startFraction = 0.15f
                        val endFraction = 0.65f

                        val maxBottomOffset = canvasHeightFloat * (1f - startFraction) - 90f - 14f
                        val minBottomOffset = canvasHeightFloat * (1f - endFraction) - 90f - 14f

                        val weightBottomOffset = minBottomOffset + ((400f - bpm) / (400f - 10f)) * (maxBottomOffset - minBottomOffset)

                        Box(
                            modifier = Modifier
                                .offset(y = (-weightBottomOffset).dp)
                                .pointerInput(Unit) {
                                    detectVerticalDragGestures { change, dragAmount ->
                                        change.consume()
                                        val dragAmountDp = dragAmount / localDensity.density
                                        val dpPerBpm = (maxBottomOffset - minBottomOffset) / (400f - 10f)
                                        val deltaBpm = dragAmountDp / dpPerBpm
                                        bpm = (bpm + deltaBpm).coerceIn(10f, 400f)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp, 28.dp)
                                    .background(brush = brassGradient, shape = RoundedCornerShape(6.dp))
                                    .border(1.dp, Color(0xFF666666), RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Box(modifier = Modifier.width(16.dp).height(2.dp).background(Color(0xFF666666)))
                                    Box(modifier = Modifier.width(16.dp).height(2.dp).background(Color(0xFF666666)))
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .offset(y = 18.dp)
                                .background(brush = brassGradient, shape = CircleShape)
                                .border(2.dp, Color(0xFF666666), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFF303030), CircleShape))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(tempoName, color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 32.dp)
                        .padding(bottom = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedSignature,
                        color = textColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            val idx = timeSignaturesList.indexOf(selectedSignature)
                            selectedSignature = if (idx < timeSignaturesList.size - 1) timeSignaturesList[idx + 1] else timeSignaturesList[0]
                            currentBeat = -1
                        }
                    )

                    FloatingActionButton(
                        onClick = { isPlaying = !isPlaying },
                        containerColor = monochromeAccent,
                        contentColor = monochromeOnAccent,
                        modifier = Modifier.size(72.dp),
                        shape = CircleShape,
                        elevation = FloatingActionButtonDefaults.elevation(0.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(onClick = { showClickSoundSelector = true }) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Settings",
                            tint = textColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

        } else if (selectedMode == "Drummer") {
            // --- GIAO DIỆN TRỐNG (DRUMMER) ---
            // Một chu kỳ bằng đúng một phách. Trong phần đầu chu kỳ, mặt trống nảy mạnh
            // rồi có một nhịp hồi nhỏ để tạo cảm giác màng trống đang rung thật.
            val drumBeatDurationMs = (60000f / bpm.coerceAtLeast(10f))
                .roundToInt()
                .coerceIn(140, 6000)
            val drumDepthTransition = rememberInfiniteTransition(label = "drumDepthTransition")
            val drumPhase by drumDepthTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = drumBeatDurationMs, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "drumBeatPhase"
            )
            val drumShake by drumDepthTransition.animateFloat(
                initialValue = -1f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 46, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "drumMicroShake"
            )
            val drumPulse = if (isPlaying) {
                when {
                    drumPhase < 0.22f -> kotlin.math.sin(
                        (drumPhase / 0.22f) * kotlin.math.PI
                    ).toFloat().coerceAtLeast(0f)

                    drumPhase < 0.42f -> kotlin.math.sin(
                        ((drumPhase - 0.22f) / 0.20f) * kotlin.math.PI
                    ).toFloat().coerceAtLeast(0f) * 0.24f

                    else -> 0f
                }
            } else {
                0f
            }
            val drumShakeX = if (isPlaying) drumShake * drumPulse * 2.4f else 0f

            Column(modifier = Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showDrumSelector = true }, modifier = Modifier.padding(end = 8.dp)) {
                        Icon(Icons.Default.VolumeUp, "Volume", tint = Color.LightGray)
                    }
                    Column(modifier = Modifier.clickable { showDrumSelector = true }) {
                        val justName = selectedDrumSound.substringAfterLast("/")
                        val cleanedName = justName.substringBeforeLast(".")
                            .replace(Regex("[-_]"), " ")
                            .replace(Regex("(?i)\\b(drum|loop|percussion|beat)\\b"), "")
                            .replace(Regex("\\s+"), " ")
                            .trim()
                            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
                            .ifEmpty { CoreTranslator.getString("default_drum", currentLang) }

                        val displaySoundName = if (cleanedName.split(" ").size > 4) {
                            cleanedName.split(" ").take(4).joinToString(" ") + "..."
                        } else {
                            cleanedName
                        }

                        Text(displaySoundName, color = monochromeAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(CoreTranslator.getString("select_sound", currentLang), color = Color.Gray, fontSize = 14.sp)
                    }
                }
                Spacer(modifier = Modifier.weight(0.8f))
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(246.dp)
                        .graphicsLayer {
                            translationX = drumShakeX
                            rotationZ = drumShake * drumPulse * 0.75f
                        }
                ) {
                    // Hào quang phía sau giúp cụm trống tách khỏi nền và có chiều sâu.
                    Box(
                        modifier = Modifier
                            .size(242.dp)
                            .graphicsLayer {
                                alpha = 0.18f + drumPulse * 0.22f
                                scaleX = 1f + drumPulse * 0.05f
                                scaleY = 1f + drumPulse * 0.05f
                            }
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF64B5F6).copy(alpha = 0.52f),
                                        Color(0xFF7E57C2).copy(alpha = 0.24f),
                                        Color.Transparent
                                    )
                                ),
                                shape = CircleShape
                            )
                    )

                    // Vành ngoài: xanh dương - tím - hồng - vàng.
                    Box(
                        modifier = Modifier
                            .size(224.dp)
                            .graphicsLayer {
                                scaleX = 1f + drumPulse * 0.018f
                                scaleY = 1f + drumPulse * 0.018f
                                shadowElevation = 18.dp.toPx()
                                shape = CircleShape
                                clip = false
                            }
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF29B6F6),
                                        Color(0xFF5C6BC0),
                                        Color(0xFFAB47BC),
                                        Color(0xFFEC407A),
                                        Color(0xFFFFB74D),
                                        Color(0xFF29B6F6)
                                    )
                                ),
                                shape = CircleShape
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.28f), CircleShape)
                    )

                    // Rãnh tối giữa hai vành tạo cảm giác lớp kim loại lồng vào nhau.
                    Box(
                        modifier = Modifier
                            .size(194.dp)
                            .graphicsLayer {
                                scaleX = 1f + drumPulse * 0.025f
                                scaleY = 1f + drumPulse * 0.025f
                                shadowElevation = 12.dp.toPx()
                                shape = CircleShape
                                clip = false
                            }
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF283A5B),
                                        Color(0xFF14213D),
                                        Color(0xFF080D18)
                                    )
                                ),
                                shape = CircleShape
                            )
                            .border(3.dp, Color.Black.copy(alpha = 0.46f), CircleShape)
                    )

                    // Vành giữa mang tông cyan - xanh biển để phân biệt rõ từng tầng.
                    Box(
                        modifier = Modifier
                            .size(166.dp)
                            .graphicsLayer {
                                scaleX = 1f + drumPulse * 0.035f
                                scaleY = 1f + drumPulse * 0.028f
                                shadowElevation = 10.dp.toPx()
                                shape = CircleShape
                                clip = false
                            }
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF80DEEA),
                                        Color(0xFF26C6DA),
                                        Color(0xFF1976D2),
                                        Color(0xFF311B92)
                                    )
                                ),
                                shape = CircleShape
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.24f), CircleShape)
                    )

                    // Viền trong ấm màu để làm nổi bật mặt trống ở tâm.
                    Box(
                        modifier = Modifier
                            .size(132.dp)
                            .graphicsLayer {
                                scaleX = 1f + drumPulse * 0.043f
                                scaleY = 1f + drumPulse * 0.032f
                                shadowElevation = 8.dp.toPx()
                                shape = CircleShape
                                clip = false
                            }
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFFFD166),
                                        Color(0xFFFF8A65),
                                        Color(0xFFEF5350),
                                        Color(0xFF8E44AD),
                                        Color(0xFF42A5F5)
                                    )
                                ),
                                shape = CircleShape
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.30f), CircleShape)
                    )

                    // Sóng lan nhanh ra khỏi mặt trống đúng lúc chạm phách.
                    Box(
                        modifier = Modifier
                            .size(112.dp)
                            .graphicsLayer {
                                val rippleScale = 1f + drumPulse * 0.42f
                                scaleX = rippleScale
                                scaleY = rippleScale
                                alpha = drumPulse * 0.42f
                            }
                            .border(2.dp, Color(0xFFB3E5FC), CircleShape)
                    )

                    // Mặt trống: nén theo chiều dọc và nở ngang khi phát để tạo cảm giác rung.
                    Box(
                        modifier = Modifier
                            .size(104.dp)
                            .graphicsLayer {
                                scaleX = 1f + drumPulse * 0.060f
                                scaleY = 1f - drumPulse * 0.040f
                                translationY = drumPulse * 2.2f
                                shadowElevation = (8f + drumPulse * 10f).dp.toPx()
                                shape = CircleShape
                                clip = false
                            }
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color.White,
                                        Color(0xFFE1F5FE),
                                        Color(0xFF90CAF9),
                                        Color(0xFF42A5F5),
                                        Color(0xFF0D47A1)
                                    )
                                ),
                                shape = CircleShape
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.70f), CircleShape)
                    )

                    // Điểm phản sáng nhỏ làm mặt trống trông cong thay vì phẳng.
                    Box(
                        modifier = Modifier
                            .offset(x = (-18).dp, y = (-19).dp)
                            .size(34.dp)
                            .graphicsLayer { alpha = 0.42f + drumPulse * 0.20f }
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.88f),
                                        Color.White.copy(alpha = 0.12f),
                                        Color.Transparent
                                    )
                                ),
                                shape = CircleShape
                            )
                    )
                }
                Spacer(modifier = Modifier.weight(0.8f))
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = LocalCustomIcons.Drum,
                        contentDescription = null,
                        tint = textColor,
                        modifier = Modifier
                            .padding(bottom = 12.dp)
                            .size(48.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "=",
                        color = textColor,
                        fontSize = 40.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = bpm.roundToInt().toString(),
                        color = textColor,
                        fontSize = 72.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BPM",
                        color = Color.Gray,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton(onClick = { if (bpm > 10f) bpm -= 1f }) { Icon(Icons.Default.Remove, "Decrease", tint = textColor) }
                    Slider(value = bpm, onValueChange = { bpm = it }, valueRange = 10f..400f, modifier = Modifier.weight(1f).padding(horizontal = 8.dp), colors = SliderDefaults.colors(thumbColor = monochromeAccent, activeTrackColor = monochromeAccent, inactiveTrackColor = monochromeSoft))
                    IconButton(onClick = { if (bpm < 400f) bpm += 1f }) { Icon(Icons.Default.Add, "Increase", tint = textColor) }
                }
                Spacer(modifier = Modifier.weight(1f))
                FloatingActionButton(onClick = { isPlaying = !isPlaying }, containerColor = monochromeAccent, contentColor = monochromeOnAccent, modifier = Modifier.size(80.dp), shape = CircleShape) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pause" else "Play", modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

        } else if (selectedMode == "Trainer") {
            // --- GIAO DIỆN LUYỆN TẬP NHỊP ĐIỆU (RHYTHM TRAINER) ---
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val trainerFootBlue = Color(0xFF79C9FF)
                val trainerFootImpact = remember { Animatable(0f) }
                LaunchedEffect(bigFootActiveNote, isBigFootPlaying) {
                    if (isBigFootPlaying && bigFootActiveNote >= 0) {
                        trainerFootImpact.snapTo(1f)
                        trainerFootImpact.animateTo(
                            targetValue = 0f,
                            animationSpec = tween(
                                durationMillis = 320,
                                easing = FastOutSlowInEasing
                            )
                        )
                    } else {
                        trainerFootImpact.snapTo(0f)
                    }
                }

                Box(
                    modifier = Modifier
                        .width(190.dp)
                        .height(126.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val floorY = size.height * 0.84f
                        val impact = trainerFootImpact.value

                        // Bóng sàn phía dưới làm đường ngang có độ sâu.
                        drawLine(
                            color = Color.Black.copy(alpha = 0.50f),
                            start = Offset(size.width * 0.08f, floorY + 4.dp.toPx()),
                            end = Offset(size.width * 0.92f, floorY + 4.dp.toPx()),
                            strokeWidth = 7.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Đường sàn xanh phản sáng; sáng lên mỗi lần bàn chân dậm xuống.
                        drawLine(
                            color = trainerFootBlue.copy(alpha = 0.42f + impact * 0.48f),
                            start = Offset(size.width * 0.08f, floorY),
                            end = Offset(size.width * 0.92f, floorY),
                            strokeWidth = (1.8f + impact * 1.6f).dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Vệt sáng ngắn ngay điểm tiếp xúc tạo cảm giác lực dậm truyền xuống sàn.
                        drawLine(
                            color = Color.White.copy(alpha = 0.18f + impact * 0.42f),
                            start = Offset(size.width * 0.34f, floorY - 1.dp.toPx()),
                            end = Offset(size.width * 0.66f, floorY - 1.dp.toPx()),
                            strokeWidth = 1.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    AnimatedFootCanvas(
                        activeNoteIndex = bigFootActiveNote,
                        isPlaying = isBigFootPlaying,
                        color = trainerFootBlue,
                        modifier = Modifier
                            .size(90.dp)
                            .align(Alignment.BottomCenter)
                            .offset(y = (-12).dp)
                            .graphicsLayer {
                                val impact = trainerFootImpact.value
                                scaleX = 1f + impact * 0.025f
                                scaleY = 1f - impact * 0.018f
                                shadowElevation = (4f + impact * 8f).dp.toPx()
                                shape = CircleShape
                                clip = false
                            }
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = CoreTranslator.getString("rhythm_tap_practice", currentLang),
                    color = textColor,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = CoreTranslator.getString("train_ear_rhythm", currentLang),
                    color = textColor.copy(alpha = 0.7f),
                    fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
                Spacer(modifier = Modifier.height(40.dp))

                Button(
                    onClick = { showRhythmTapScreen = true },
                    colors = ButtonDefaults.buttonColors(containerColor = monochromeAccent),
                    modifier = Modifier.fillMaxWidth(0.7f).height(56.dp),
                    shape = RoundedCornerShape(28.dp)
                ) {
                    Text(
                        CoreTranslator.getString("start_now", currentLang),
                        color = monochromeOnAccent,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showDrumSelector) {
        // Danh sách các mảng màu khác nhau cho từng Tên điệu
        val categoryColors = listOf(
            textColor,
            textColor.copy(alpha = 0.90f),
            textColor.copy(alpha = 0.82f),
            textColor.copy(alpha = 0.74f),
            textColor.copy(alpha = 0.66f),
            textColor.copy(alpha = 0.58f),
            textColor.copy(alpha = 0.50f),
            textColor.copy(alpha = 0.42f)
        )
        val categoryList = drumFiles.keys.toList()

        AlertDialog(
            onDismissRequest = { showDrumSelector = false },
            title = { Text(CoreTranslator.getString("select_drum_sound", currentLang), fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    drumFiles.forEach { (category, files) ->
                        // Tính toán màu theo thứ tự của điệu trống
                        val catIndex = categoryList.indexOf(category)
                        val catColor = categoryColors[catIndex % categoryColors.size]

                        item {
                            Text(
                                text = category,
                                color = catColor, // Gán màu riêng cho Tên điệu
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                modifier = Modifier.padding(top = 16.dp, bottom = 4.dp, start = 8.dp)
                            )
                        }
                        items(files) { file ->
                            val justName = file.substringAfterLast("/")
                            val cleanedName = justName.substringBeforeLast(".")
                                .replace(Regex("[-_]"), " ")
                                .replace(Regex("(?i)\\b(drum|loop|percussion|beat)\\b"), "")
                                .replace(Regex("\\s+"), " ")
                                .trim()
                                .replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
                                .ifEmpty { CoreTranslator.getString("default_drum", currentLang) }

                            val words = cleanedName.split(" ")
                            val displayName = if (words.size > 4) words.take(4).joinToString(" ") + "..." else cleanedName

                            val isSelected = selectedDrumSound == file

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedDrumSound = file

                                        // Tự động tìm số đầu tiên trong tên file để set BPM
                                        val match = Regex("(\\d+)").find(file.substringAfterLast("/"))
                                        if (match != null) {
                                            match.value.toFloatOrNull()?.let { extractedBpm ->
                                                // Đảm bảo số lấy ra nằm trong giới hạn cho phép (10 - 400)
                                                if (extractedBpm in 10f..400f) {
                                                    bpm = extractedBpm
                                                }
                                            }
                                        }

                                        showDrumSelector = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Thêm Icon Trống (Drum) vào đầu mỗi bài
                                Icon(
                                    imageVector = LocalCustomIcons.Drum,
                                    contentDescription = "Drum",
                                    tint = if (isSelected) textColor else textColor.copy(alpha = 0.5f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = displayName,
                                    color = textColor, // Chỉ giữ màu mặc định (Trắng/Đen) cho tên bài hát, không dùng màu mè
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDrumSelector = false }) { Text(CoreTranslator.getString("close", currentLang), color = monochromeAccent) } },
            containerColor = surfaceColor, titleContentColor = textColor, textContentColor = textColor
        )
    }

    if (showClickSoundSelector) {
        AlertDialog(
            onDismissRequest = { showClickSoundSelector = false },
            title = { Text(CoreTranslator.getString("click_sound_title", currentLang), fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(clickSoundOptions) { sound ->
                        Text(
                            text = sound,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedClickSound = sound
                                    forceReloadAudioTrigger++ // KÍCH HOẠT LẠI KHỐI TẢI FILE
                                    showClickSoundSelector = false
                                }
                                .padding(vertical = 16.dp, horizontal = 8.dp),
                            color = if (selectedClickSound == sound) monochromeAccent else textColor,
                            fontWeight = if (selectedClickSound == sound) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showClickSoundSelector = false }) { Text(CoreTranslator.getString("close", currentLang), color = monochromeAccent) } },
            containerColor = surfaceColor, titleContentColor = textColor, textContentColor = textColor
        )
    }
}