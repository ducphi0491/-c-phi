package ducphi.tunnerinstrument

import android.content.Context
import org.json.JSONObject

object CoreTranslator {
    private val translations = mutableMapOf<String, Map<String, String>>()

    // Giữ nguyên danh sách ngôn ngữ hiện tại của bạn
    val supportedLanguages = listOf(
        "vi" to "Tiếng Việt", "en" to "English", "es" to "Español",
        "fr" to "Français", "de" to "Deutsch", "ru" to "Русский",
        "ja" to "日本語", "zh" to "中文", "th" to "ไทย",
        "lo" to "ລາວ", "km" to "ភាសាខ្មែរ", "ko" to "한국어",
        "pt" to "Português", "sw" to "Kiswahili", "ar" to "العربية"
    )

    // Hàm khởi tạo: Gọi hàm này 1 lần duy nhất trong MainActivity
    fun init(context: Context) {
        try {
            val jsonString = context.assets.open("translations.json").bufferedReader().use { it.readText() }
            val jsonObject = JSONObject(jsonString)

            for (langCode in jsonObject.keys()) {
                val langData = jsonObject.getJSONObject(langCode)
                val mapData = mutableMapOf<String, String>()
                for (key in langData.keys()) {
                    mapData[key] = langData.getString(key)
                }
                translations[langCode] = mapData
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getString(key: String, langCode: String): String {
        return translations[langCode]?.get(key) ?: translations["en"]?.get(key) ?: key
    }
}