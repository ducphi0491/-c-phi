package ducphi.tunnerinstrument

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

// --- HÀM TIỆN ÍCH DÙNG CHUNG ---
fun String.toMusicSymbolsLocal(): String {
    return this.replace("#", "♯").replace("b", "♭")
}

// ============================================================================
// ==================== PHẦN 1: COMPONENT VÒNG QUÃNG 5 ========================
// ============================================================================

val circleMajors = listOf("C", "G", "D", "A", "E", "B", "F#", "Db", "Ab", "Eb", "Bb", "F")
val circleMinors = listOf("A", "E", "B", "F#", "C#", "G#", "Eb", "Bb", "F", "C", "G", "D")
val romanMajors = listOf("I", "ii", "iii", "IV", "V", "vi")

@Composable
fun CircleOfFifthsComponent(
    currentLang: String,
    selectedKey: String,
    selectedSuffix: String,
    textColor: Color,
    bgColor: Color,
    tunaGreen: Color,
    onKeySelected: (String, String) -> Unit,
    onChordBoxClicked: (String, String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val keySignatures = remember {
        listOf("", "♯F", "♯FC", "♯FCG", "♯FCGD", "♯FCGDA", "♯FCGDAE", "♭BEADG", "♭BEAD", "♭BEA", "♭BE", "♭B")
    }

    val isDark = textColor == Color.White
    val wheelOuterBg = if (isDark) Color(0xFF2D2E33) else Color(0xFFE8E8E8)
    val wheelInnerBg = if (isDark) Color(0xFF242529) else Color(0xFFD6D6D6)

    val highlightTextColor = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.parseColor("#1B1C20")
    val normalMajorTextColor = if (isDark) android.graphics.Color.parseColor("#B0B0B0") else android.graphics.Color.parseColor("#666666")
    val normalMinorTextColor = if (isDark) android.graphics.Color.parseColor("#989898") else android.graphics.Color.parseColor("#808080")
    val sigTextColor = if (isDark) android.graphics.Color.parseColor("#A0A0A0") else android.graphics.Color.parseColor("#777777")

    val baseIndex = if (selectedSuffix == "minor") {
        circleMinors.indexOf(selectedKey).takeIf { it >= 0 } ?: 0
    } else {
        circleMajors.indexOf(selectedKey).takeIf { it >= 0 } ?: 0
    }

    val rotation = remember { Animatable(-baseIndex * 30f) }

    LaunchedEffect(baseIndex) {
        val target = -baseIndex * 30f
        var diff = (target - rotation.value) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        rotation.animateTo(rotation.value + diff, tween(400))
    }

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        val hintText = if (currentLang == "vi") "← Kéo vòng tròn để xoay →" else "← Swipe circle to rotate →"
        Text(text = hintText, color = textColor.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))

        Box(
            // ĐÃ CHỈNH SÁT VIỀN: fillMaxWidth + aspectRatio 1:1, không dùng padding horizontal nữa
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val down = awaitFirstDown()
                            val center = Offset(size.width / 2f, size.height / 2f)
                            var prevAngle = Math.toDegrees(atan2((down.position.y - center.y).toDouble(), (down.position.x - center.x).toDouble())).toFloat()
                            var isDragging = false
                            do {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull()
                                if (change != null && change.pressed) {
                                    val currAngle = Math.toDegrees(atan2((change.position.y - center.y).toDouble(), (change.position.x - center.x).toDouble())).toFloat()
                                    var diff = currAngle - prevAngle
                                    if (diff > 180) diff -= 360
                                    if (diff < -180) diff += 360
                                    if (Math.abs(diff) > 0.5f) isDragging = true
                                    if (isDragging) {
                                        coroutineScope.launch { rotation.snapTo(rotation.value + diff) }
                                        change.consume()
                                        prevAngle = currAngle
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            if (!isDragging) {
                                val tapAngleScreen = Math.toDegrees(atan2((down.position.y - center.y).toDouble(), (down.position.x - center.x).toDouble())).toFloat()
                                val wheelAngle = (tapAngleScreen - rotation.value % 360f + 360f) % 360f
                                val normalizedWheel = (wheelAngle + 90f) % 360f
                                val sliceIndex = Math.round(normalizedWheel / 30f).toInt() % 12
                                val distance = Math.hypot((down.position.x - center.x).toDouble(), (down.position.y - center.y).toDouble()).toFloat()
                                val R = size.width / 2f
                                if (distance in (R * 0.65f)..R) onKeySelected(circleMajors[sliceIndex], "major")
                                else if (distance in (R * 0.12f)..(R * 0.65f)) onKeySelected(circleMinors[sliceIndex], "minor")
                            } else {
                                val steps = Math.round(-rotation.value / 30f)
                                val newIndex = (steps % 12 + 12) % 12
                                onKeySelected(if(selectedSuffix == "minor") circleMinors[newIndex.toInt()] else circleMajors[newIndex.toInt()], selectedSuffix)
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f; val cy = size.height / 2f; val R = size.width / 2f
                val innerR = R * 0.65f; val holeR = R * 0.22f

                drawCircle(wheelOuterBg, R)
                drawCircle(wheelInnerBg, innerR)

                drawArc(tunaGreen.copy(alpha = 0.2f), -135f, 30f, true, Offset(cx - R, cy - R), Size(R * 2, R * 2))
                drawArc(tunaGreen.copy(alpha = 0.2f), -75f, 30f, true, Offset(cx - R, cy - R), Size(R * 2, R * 2))
                drawArc(tunaGreen.copy(alpha = 0.4f), -105f, 30f, true, Offset(cx - R, cy - R), Size(R * 2, R * 2))
                drawArc(tunaGreen.copy(alpha = 0.6f), -105f, 30f, true, Offset(cx - innerR, cy - innerR), Size(innerR * 2, innerR * 2))

                val gapDegrees = 2.5f
                val gapPath = Path()

                for (i in 0 until 12) {
                    val lineAngle = i * 30f - 105f + rotation.value
                    val rad1 = Math.toRadians((lineAngle - gapDegrees / 2).toDouble())
                    val rad2 = Math.toRadians((lineAngle + gapDegrees / 2).toDouble())
                    val extendedR = R + 10f
                    gapPath.moveTo(cx, cy)
                    gapPath.lineTo(cx + extendedR * Math.cos(rad1).toFloat(), cy + extendedR * Math.sin(rad1).toFloat())
                    gapPath.lineTo(cx + extendedR * Math.cos(rad2).toFloat(), cy + extendedR * Math.sin(rad2).toFloat())
                    gapPath.close()
                }

                drawPath(path = gapPath, color = bgColor)
                drawCircle(color = bgColor, radius = innerR, style = Stroke(width = 6f))
                drawCircle(bgColor, holeR)

                drawContext.canvas.nativeCanvas.apply {
                    for (i in 0 until 12) {
                        val centerAngle = i * 30f - 90f + rotation.value
                        var normTop = ((centerAngle + 90f) % 360f + 360f) % 360f
                        if (normTop > 180f) normTop -= 360f
                        val isHighlighted = Math.abs(normTop) < 45f

                        save(); translate(cx, cy); rotate(centerAngle + 90f)
                        val textPaint = android.graphics.Paint().apply { textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }

                        if (keySignatures[i].isNotEmpty()) {
                            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
                            textPaint.textSize = 34f // Cỡ chữ bự hơn
                            textPaint.color = sigTextColor
                            drawText(keySignatures[i], 0f, -R * 0.94f, textPaint)
                        }

                        textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
                        textPaint.textSize = if (isHighlighted) 74f else 56f // Cỡ chữ bự hơn
                        textPaint.color = if (isHighlighted) highlightTextColor else normalMajorTextColor
                        drawText(circleMajors[i].toMusicSymbolsLocal(), 0f, -R * 0.81f, textPaint)

                        textPaint.textSize = if (isHighlighted) 54f else 42f // Cỡ chữ bự hơn
                        textPaint.color = if (isHighlighted) highlightTextColor else normalMinorTextColor
                        drawText("${circleMinors[i].toMusicSymbolsLocal()}m", 0f, -R * 0.52f, textPaint)
                        restore()
                    }

                    fun drawFixedRoman(text: String, angle: Float, radiusOffset: Float, size: Float) {
                        save(); translate(cx, cy); rotate(angle + 90f)
                        val paint = android.graphics.Paint().apply { textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; color = highlightTextColor; textSize = size; typeface = android.graphics.Typeface.DEFAULT_BOLD }
                        drawText(text, 0f, -radiusOffset, paint); restore()
                    }

                    // Tăng tỷ lệ chữ số La Mã
                    drawFixedRoman("(IV)", -120f, R * 0.68f, 32f)
                    drawFixedRoman("(I)", -90f, R * 0.68f, 32f)
                    drawFixedRoman("(V)", -60f, R * 0.68f, 32f)
                    drawFixedRoman("(ii)", -120f, R * 0.40f, 30f)
                    drawFixedRoman("(vi)", -90f, R * 0.40f, 30f)
                    drawFixedRoman("(iii)", -60f, R * 0.40f, 30f)

                    val safeTopIndex = ((Math.round(-rotation.value / 30f) % 12 + 12) % 12).toInt()
                    val dimRoot = circleMajors[(safeTopIndex + 5) % 12].toMusicSymbolsLocal()
                    drawFixedRoman("$dimRoot°", -90f, R * 0.28f, 36f)
                    drawFixedRoman("(vii°)", -90f, R * 0.18f, 24f)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val iKey = circleMajors[baseIndex].toMusicSymbolsLocal(); val viKey = circleMinors[baseIndex].toMusicSymbolsLocal() + "m"
        val iiKey = circleMinors[(baseIndex - 1 + 12) % 12].toMusicSymbolsLocal() + "m"; val iiiKey = circleMinors[(baseIndex + 1) % 12].toMusicSymbolsLocal() + "m"
        val ivKey = circleMajors[(baseIndex - 1 + 12) % 12].toMusicSymbolsLocal(); val vKey = circleMajors[(baseIndex + 1) % 12].toMusicSymbolsLocal()
        val scaleChords = listOf(iKey, iiKey, iiiKey, ivKey, vKey, viKey)

        val boxBgColor = if (isDark) Color(0xFF34343A) else Color(0xFFF2F2F7)
        val outerFrameBg = if (isDark) Color(0xFF1B1C20).copy(alpha = 0.5f) else Color.White

        Surface(
            color = outerFrameBg, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.5.dp, tunaGreen.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
        ) {
            Column(modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "$iKey / $viKey", color = tunaGreen, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    scaleChords.forEachIndexed { index, chordDisplay ->
                        Column(
                            modifier = Modifier.weight(1f).background(boxBgColor, RoundedCornerShape(10.dp)).border(1.dp, if(isDark) Color.White.copy(alpha = 0.1f) else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable {
                                    // 1. Ép trực tiếp ký hiệu ♯/♭ về lại #/b
                                    var rawKey = chordDisplay.removeSuffix("m")
                                        .replace("♯", "#")
                                        .replace("♭", "b")

                                    // 2. Chuyển đổi âm trùng (Enharmonic) cho các giọng thứ (minor) thường bị sai khác trong DB
                                    val isMinor = chordDisplay.endsWith("m")
                                    if (isMinor) {
                                        rawKey = when (rawKey) {
                                            "G#" -> "Ab"
                                            "D#" -> "Eb"
                                            "A#" -> "Bb"
                                            "E#" -> "F"
                                            "B#" -> "C"
                                            "Cb" -> "B"
                                            "Fb" -> "E"
                                            else -> rawKey
                                        }
                                    }

                                    onChordBoxClicked(rawKey, if (isMinor) "minor" else "major")
                                }.padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(romanMajors[index], color = textColor.copy(alpha = 0.7f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(chordDisplay, color = textColor, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// ==================== PHẦN 2: COMPONENT VÒNG TRENTHAM =======================
// ============================================================================

data class HarmonySlice(
    val chordName: String,
    val note4: String,
    val note3: String,
    val note2: String,
    val root: String,
    val keySig: String
)

val trenthamData = listOf(
    // Group C
    HarmonySlice("C+", "", "G#", "E", "C", "NAT"),
    HarmonySlice("C7", "Bb", "G", "E", "C", "NAT"),
    HarmonySlice("C6", "A", "G", "E", "C", "NAT"),
    HarmonySlice("Cm6", "A", "G", "Eb", "C", "NAT"),
    HarmonySlice("C°", "A", "Gb", "Eb", "C", "NAT"),

    // Group G
    HarmonySlice("G+", "", "D#", "B", "G", "#"),
    HarmonySlice("G7", "F", "D", "B", "G", "#"),
    HarmonySlice("G6", "E", "D", "B", "G", "#"),
    HarmonySlice("Gm6", "E", "D", "Bb", "G", "#"),
    HarmonySlice("G°", "E", "Db", "Bb", "G", "#"),

    // Group D
    HarmonySlice("D+", "", "A#", "F#", "D", "2#"),
    HarmonySlice("D7", "C", "A", "F#", "D", "2#"),
    HarmonySlice("D6", "B", "A", "F#", "D", "2#"),
    HarmonySlice("Dm6", "B", "A", "F", "D", "2#"),
    HarmonySlice("D°", "B", "Ab", "F", "D", "2#"),

    // Group A
    HarmonySlice("A+", "", "F", "C#", "A", "3#"),
    HarmonySlice("A7", "G", "E", "C#", "A", "3#"),
    HarmonySlice("A6", "F#", "E", "C#", "A", "3#"),
    HarmonySlice("Am6", "F#", "E", "C", "A", "3#"),
    HarmonySlice("A°", "F#", "Eb", "C", "A", "3#"),

    // Group E
    HarmonySlice("E+", "", "C", "G#", "E", "4#"),
    HarmonySlice("E7", "D", "B", "G#", "E", "4#"),
    HarmonySlice("E6", "C#", "B", "G#", "E", "4#"),
    HarmonySlice("Em6", "C#", "B", "G", "E", "4#"),
    HarmonySlice("E°", "C#", "Bb", "G", "E", "4#"),

    // Group B
    HarmonySlice("B+", "", "G", "D#", "B", "5#"),
    HarmonySlice("B7", "A", "F#", "D#", "B", "5#"),
    HarmonySlice("B6", "G#", "F#", "D#", "B", "5#"),
    HarmonySlice("Bm6", "G#", "F#", "D", "B", "5#"),
    HarmonySlice("B°", "G#", "F", "D", "B", "5#"),

    // Group F#
    HarmonySlice("F#+", "", "D", "A#", "F#", "6#\n6b"),
    HarmonySlice("F#7", "E", "C#", "A#", "F#", "6#\n6b"),
    HarmonySlice("F#6", "D#", "C#", "A#", "F#", "6#\n6b"),
    HarmonySlice("F#m6", "D#", "C#", "A", "F#", "6#\n6b"),
    HarmonySlice("F#°", "D#", "C", "A", "F#", "6#\n6b"),

    // Group Db
    HarmonySlice("Db+", "", "A", "F", "Db", "5b"),
    HarmonySlice("Db7", "Cb", "Ab", "F", "Db", "5b"),
    HarmonySlice("Db6", "Bb", "Ab", "F", "Db", "5b"),
    HarmonySlice("Dbm6", "Bb", "Ab", "Fb", "Db", "5b"),
    HarmonySlice("Db°", "Bb", "G", "Fb", "Db", "5b"),

    // Group Ab
    HarmonySlice("Ab+", "", "E", "C", "Ab", "4b"),
    HarmonySlice("Ab7", "Gb", "Eb", "C", "Ab", "4b"),
    HarmonySlice("Ab6", "F", "Eb", "C", "Ab", "4b"),
    HarmonySlice("Abm6", "F", "Eb", "Cb", "Ab", "4b"),
    HarmonySlice("Ab°", "F", "D", "Cb", "Ab", "4b"),

    // Group Eb
    HarmonySlice("Eb+", "", "B", "G", "Eb", "3b"),
    HarmonySlice("Eb7", "Db", "Bb", "G", "Eb", "3b"),
    HarmonySlice("Eb6", "C", "Bb", "G", "Eb", "3b"),
    HarmonySlice("Ebm6", "C", "Bb", "Gb", "Eb", "3b"),
    HarmonySlice("Eb°", "C", "A", "Gb", "Eb", "3b"),

    // Group Bb
    HarmonySlice("Bb+", "", "F#", "D", "Bb", "2b"),
    HarmonySlice("Bb7", "Ab", "F", "D", "Bb", "2b"),
    HarmonySlice("Bb6", "G", "F", "D", "Bb", "2b"),
    HarmonySlice("Bbm6", "G", "F", "Db", "Bb", "2b"),
    HarmonySlice("Bb°", "G", "E", "Db", "Bb", "2b"),

    // Group F
    HarmonySlice("F+", "", "C#", "A", "F", "b"),
    HarmonySlice("F7", "Eb", "C", "A", "F", "b"),
    HarmonySlice("F6", "D", "C", "A", "F", "b"),
    HarmonySlice("Fm6", "D", "C", "Ab", "F", "b"),
    HarmonySlice("F°", "D", "B", "Ab", "F", "b")
)

@Composable
fun CircleOfHarmonyComponent(
    currentLang: String,
    selectedKey: String,
    textColor: Color,
    bgColor: Color,
    tunaGreen: Color
) {
    val coroutineScope = rememberCoroutineScope()
    val isDark = textColor == Color.White
    val surfaceColor = if (isDark) Color(0xFF242529) else Color(0xFFE8E8E8)

    val initialSliceIndex = trenthamData.indexOfFirst { it.root == selectedKey && it.chordName.endsWith("7") }.takeIf { it >= 0 } ?: 1

    // ĐÃ CHỈNH LỆCH TÂM: Trừ đi 3 độ để kim đâm thẳng vào giữa ô!
    val rotation = remember { Animatable(-initialSliceIndex * 6f - 3f) }

    val activeSliceIndex by remember {
        derivedStateOf {
            // Tính toán snap cũng bù trừ 3 độ
            val steps = Math.round((-rotation.value - 3f) / 6f)
            ((steps % 60) + 60) % 60
        }
    }

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        val titleText = if (currentLang == "vi") "Vòng Hoà Âm (Trentham)" else "Circle of Harmony"

        Text(
            text = titleText, color = tunaGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            text = "SHOWING RELATIONSHIP OF CHORDS & KEYS", color = textColor.copy(alpha = 0.7f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp)
        )

        Box(
            // ĐÃ CHỈNH SÁT VIỀN TỐI ĐA (Aspect Ratio 1:1, full width)
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val down = awaitFirstDown()
                            val center = Offset(size.width / 2f, size.height / 2f)
                            var prevAngle = Math.toDegrees(atan2((down.position.y - center.y).toDouble(), (down.position.x - center.x).toDouble())).toFloat()
                            var isDragging = false
                            do {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull()
                                if (change != null && change.pressed) {
                                    val currAngle = Math.toDegrees(atan2((change.position.y - center.y).toDouble(), (change.position.x - center.x).toDouble())).toFloat()
                                    var diff = currAngle - prevAngle
                                    if (diff > 180) diff -= 360
                                    if (diff < -180) diff += 360
                                    if (Math.abs(diff) > 0.5f) isDragging = true
                                    if (isDragging) {
                                        coroutineScope.launch { rotation.snapTo(rotation.value + diff) }
                                        change.consume()
                                        prevAngle = currAngle
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            // THUẬT TOÁN SNAP: Khựng lại đúng giữa ô
                            val steps = Math.round((-rotation.value - 3f) / 6f)
                            val targetAngle = -steps * 6f - 3f
                            coroutineScope.launch { rotation.animateTo(targetAngle, tween(250)) }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val R = size.width / 2f

                val r0 = R * 0.14f
                val r1 = R * 0.28f
                val r2 = R * 0.41f
                val r3 = R * 0.53f
                val r4 = R * 0.65f
                val r5 = R * 0.76f

                val wheelBg = if (isDark) Color(0xFF242529) else Color(0xFFD6D6D6)
                val wheelBgAlt = if (isDark) Color(0xFF2D2E33) else Color(0xFFE8E8E8)
                val lineCol = if (isDark) Color.White.copy(alpha = 0.2f) else Color.Black.copy(alpha = 0.2f)

                // 1. Vẽ nền các vòng tròn
                drawCircle(color = wheelBgAlt, radius = R)
                drawCircle(color = wheelBg, radius = r5)
                drawCircle(color = wheelBgAlt, radius = r4)
                drawCircle(color = wheelBg, radius = r3)
                drawCircle(color = wheelBgAlt, radius = r2)
                drawCircle(color = wheelBg, radius = r1)
                drawCircle(color = bgColor, radius = r0)

                fun getBounds(ring: Int, offset: Int): Pair<Int, Int> {
                    return when (ring) {
                        0, 1 -> Pair(0, 4)
                        2 -> if (offset < 3) Pair(0, 2) else Pair(3, 4)
                        3 -> if (offset == 0) Pair(0, 0) else if (offset < 4) Pair(1, 3) else Pair(4, 4)
                        4 -> if (offset == 0) Pair(0, 0) else if (offset == 1) Pair(1, 1) else Pair(2, 4)
                        else -> Pair(offset, offset)
                    }
                }

                // 2. HIGHLIGHT CÁC Ô ĐƯỢC CHỌN (Khớp với việc kim đã vào giữa ô)
                val activeOffset = activeSliceIndex % 5

                for (ring in 0..5) {
                    val bounds = getBounds(ring, activeOffset)
                    val rInner = when(ring) { 0 -> r0; 1 -> r1; 2 -> r2; 3 -> r3; 4 -> r4; else -> r5 }
                    val rOuter = when(ring) { 0 -> r1; 1 -> r2; 2 -> r3; 3 -> r4; 4 -> r5; else -> R }

                    // Góc quét của highlight cũng phải lùi lại 3 độ (-93f thay vì -90f) để bao trọn ô
                    val startScreenAngle = -93f + (bounds.first - activeOffset) * 6f
                    val sweepAngle = (bounds.second - bounds.first + 1) * 6f

                    val path = Path().apply {
                        arcTo(androidx.compose.ui.geometry.Rect(cx - rOuter, cy - rOuter, cx + rOuter, cy + rOuter), startScreenAngle, sweepAngle, false)
                        arcTo(androidx.compose.ui.geometry.Rect(cx - rInner, cy - rInner, cx + rInner, cy + rInner), startScreenAngle + sweepAngle, -sweepAngle, false)
                        close()
                    }

                    drawPath(path, Color(0xFFB8A038).copy(alpha = 0.45f))
                    drawPath(path, Color.Red, style = Stroke(3.5f))
                }

                // 3. THUẬT TOÁN VẼ LƯỚI TOẠ ĐỘ
                for (i in 0 until 12) {
                    val groupStart = i * 5
                    for (offset in 0..4) {
                        val angle = (groupStart + offset) * 6f - 90f + rotation.value
                        val rad = Math.toRadians(angle.toDouble())
                        val cosA = cos(rad).toFloat()
                        val sinA = sin(rad).toFloat()

                        if (offset == 0) {
                            drawLine(lineCol, Offset(cx + r0 * cosA, cy + r0 * sinA), Offset(cx + R * cosA, cy + R * sinA), 3f)
                        } else if (offset == 1) {
                            drawLine(lineCol, Offset(cx + r3 * cosA, cy + r3 * sinA), Offset(cx + R * cosA, cy + R * sinA), 1.5f)
                        } else if (offset == 2) {
                            drawLine(lineCol, Offset(cx + r4 * cosA, cy + r4 * sinA), Offset(cx + R * cosA, cy + R * sinA), 1.5f)
                        } else if (offset == 3) {
                            drawLine(lineCol, Offset(cx + r2 * cosA, cy + r2 * sinA), Offset(cx + r3 * cosA, cy + r3 * sinA), 1.5f)
                            drawLine(lineCol, Offset(cx + r5 * cosA, cy + r5 * sinA), Offset(cx + R * cosA, cy + R * sinA), 1.5f)
                        } else if (offset == 4) {
                            drawLine(lineCol, Offset(cx + r3 * cosA, cy + r3 * sinA), Offset(cx + r4 * cosA, cy + r4 * sinA), 1.5f)
                            drawLine(lineCol, Offset(cx + r5 * cosA, cy + r5 * sinA), Offset(cx + R * cosA, cy + R * sinA), 1.5f)
                        }
                    }
                }

                // 4. THUẬT TOÁN VẼ TEXT
                drawContext.canvas.nativeCanvas.apply {
                    val textPaint = android.graphics.Paint().apply {
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                    }

                    fun drawMergedText(text: String, groupStart: Int, startOffset: Int, endOffset: Int, rInner: Float, rOuter: Float, bold: Boolean, size: Float, colorHex: String, isRadial: Boolean = false) {
                        if (text.isBlank()) return
                        save()
                        translate(cx, cy)
                        val ringAngle = (groupStart + (startOffset + endOffset) / 2f + 0.5f) * 6f - 90f + rotation.value

                        val rMid = (rInner + rOuter) / 2f
                        textPaint.textSize = size
                        textPaint.typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
                        textPaint.color = android.graphics.Color.parseColor(colorHex)

                        if (isRadial) {
                            rotate(ringAngle)
                            val yOffset = (textPaint.descent() + textPaint.ascent()) / 2f
                            drawText(text.toMusicSymbolsLocal(), rMid, -yOffset, textPaint)
                        } else {
                            rotate(ringAngle + 90f)
                            if (text.contains("\n")) {
                                val lines = text.split("\n")
                                drawText(lines[0], 0f, -rMid + textPaint.textSize * 0.1f, textPaint)
                                drawText(lines[1], 0f, -rMid + textPaint.textSize * 1.1f, textPaint)
                            } else {
                                val yOffset = (textPaint.descent() + textPaint.ascent()) / 2f
                                drawText(text.toMusicSymbolsLocal(), 0f, -rMid - yOffset, textPaint)
                            }
                        }
                        restore()
                    }

                    val colorMain = if (isDark) "#FFFFFF" else "#000000"
                    val colorSub = if (isDark) "#CCCCCC" else "#444444"

                    for (group in 0 until 12) {
                        val groupStart = group * 5
                        val rootSlice = trenthamData[groupStart]

                        // ĐÃ PHÓNG TO TOÀN BỘ CỠ CHỮ
                        drawMergedText(rootSlice.keySig, groupStart, 0, 4, r0, r1, true, 26f, "#FF4B4B")
                        drawMergedText(rootSlice.root, groupStart, 0, 4, r1, r2, true, 44f, colorMain)

                        for (offset in 0..4) {
                            val data = trenthamData[groupStart + offset]

                            val bound2 = getBounds(2, offset)
                            if (offset == bound2.first) drawMergedText(data.note2, groupStart, bound2.first, bound2.second, r2, r3, false, 26f, colorSub)

                            val bound3 = getBounds(3, offset)
                            if (offset == bound3.first) drawMergedText(data.note3, groupStart, bound3.first, bound3.second, r3, r4, false, 26f, colorSub)

                            val bound4 = getBounds(4, offset)
                            if (offset == bound4.first) drawMergedText(data.note4, groupStart, bound4.first, bound4.second, r4, r5, false, 26f, colorSub)

                            val bound5 = getBounds(5, offset)
                            if (offset == bound5.first) drawMergedText(data.chordName, groupStart, bound5.first, bound5.second, r5, R, true, 32f, colorMain, isRadial = true)
                        }
                    }
                }

                // 5. KẺ VIỀN CÁC ĐƯỜNG TRÒN
                drawCircle(color = lineCol, radius = R, style = Stroke(width = 2.5f))
                drawCircle(color = lineCol, radius = r5, style = Stroke(width = 1.5f))
                drawCircle(color = lineCol, radius = r4, style = Stroke(width = 1.5f))
                drawCircle(color = lineCol, radius = r3, style = Stroke(width = 1.5f))
                drawCircle(color = lineCol, radius = r2, style = Stroke(width = 2.5f))
                drawCircle(color = lineCol, radius = r1, style = Stroke(width = 2.5f))
                drawCircle(color = lineCol, radius = r0, style = Stroke(width = 2.5f))

                // 6. VẼ KIM ĐỎ (LUÔN CHỈ VÀO ĐÚNG -90 ĐỘ TỨC LÀ GIỮA Ô)
                val pointerPath = Path().apply {
                    moveTo(cx, cy - R - 5f)
                    lineTo(cx - 12f, cy - R - 30f)
                    lineTo(cx + 12f, cy - R - 30f)
                    close()
                }
                drawPath(path = pointerPath, color = Color.Red)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- BẢNG "MỔ XẺ" CHI TIẾT HỢP ÂM ---
        val activeSlice = trenthamData[activeSliceIndex]
        val boxBgColor = if (isDark) Color(0xFF34343A) else Color(0xFFF2F2F7)

        Surface(
            color = surfaceColor.copy(alpha = 0.5f), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, tunaGreen.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
        ) {
            Column(modifier = Modifier.padding(vertical = 12.dp, horizontal = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {

                Text(
                    text = if(currentLang == "vi") "GIẢI PHẪU HỢP ÂM ${activeSlice.chordName}" else "CHORD SPELLING: ${activeSlice.chordName}",
                    color = tunaGreen,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = if(currentLang == "vi") "Giọng: ${activeSlice.root} (Hóa biểu: ${activeSlice.keySig.replace("\n", " ")})" else "Key: ${activeSlice.root} (Sig: ${activeSlice.keySig.replace("\n", " ")})",
                    color = textColor.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val notes = listOf(activeSlice.root, activeSlice.note2, activeSlice.note3, activeSlice.note4).filter { it.isNotBlank() }

                    notes.forEachIndexed { index, note ->
                        Column(
                            modifier = Modifier.weight(1f)
                                .background(boxBgColor, RoundedCornerShape(10.dp))
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val numeral = when(index) { 0 -> "Root"; 1 -> "3rd"; 2 -> "5th"; else -> "7th/6th" }
                            Text(text = numeral, color = textColor.copy(alpha = 0.5f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = note.toMusicSymbolsLocal(), color = textColor, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}