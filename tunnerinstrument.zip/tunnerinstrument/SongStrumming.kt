@file:OptIn(ExperimentalMaterial3Api::class)

package ducphi.tunnerinstrument

import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// 1. DATA MODELS
data class StrumAction(
    val type: StrumType,
    val isAccent: Boolean = false,
    val arpeggioNote: String = ""
)

data class StrumStep(
    val actions: List<StrumAction>
)

data class StrumPatternDef(
    val id: String,
    val name: String = "",
    val pattern: List<StrumStep>
)

data class StrumCategoryDef(
    val title: String,
    val patterns: List<StrumPatternDef>
)

enum class StrumType { DOWN, UP, MUTE, REST }

// Hàm dịch chuỗi phách cho Quạt chả
fun parsePatternString(patternStr: String): List<StrumStep> {
    return patternStr.split(" ").filter { it.isNotBlank() }.map { token ->
        val type = when {
            token.startsWith("D") -> StrumType.DOWN
            token.startsWith("U") -> StrumType.UP
            token.startsWith("M") -> StrumType.MUTE
            else -> StrumType.REST
        }
        val isAccent = token.contains("a")
        val arpeggioNote = when (type) {
            StrumType.DOWN -> if (isAccent) "B" else "3"
            StrumType.UP -> "12"
            StrumType.MUTE -> "123"
            StrumType.REST -> ""
        }
        StrumStep(listOf(StrumAction(type, isAccent, arpeggioNote)))
    }
}

// Hàm dịch chuỗi phách cho Móc rải (Arpeggio)
fun parseArpeggioPattern(patternStr: String): List<StrumStep> {
    return patternStr.split(" ").filter { it.isNotBlank() }.map { token ->
        if (token == ".") {
            StrumStep(listOf(StrumAction(StrumType.REST, isAccent = false, arpeggioNote = "")))
        } else {
            val isAccent = token.endsWith("a")
            val note = token.removeSuffix("a")
            StrumStep(listOf(StrumAction(StrumType.DOWN, isAccent = isAccent, arpeggioNote = note)))
        }
    }
}

// 2. DATABASE TIẾT TẤU
fun getGroupedStrummingPatterns(rhythm: String, isArpeggio: Boolean): List<StrumCategoryDef> {
    val cleanRhythm = rhythm.lowercase().trim()
    return when {
        cleanRhythm.contains("ballad") || cleanRhythm.contains("surf") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "15 Kiểu Móc Rải Ballad Chuẩn",
                        patterns = listOf(
                            StrumPatternDef("arpeggio_1", "Rải Ballad 1", parseArpeggioPattern("Ba 3 2a 3 1 2 3a 2")),
                            StrumPatternDef("arpeggio_2", "Rải Ballad 2", parseArpeggioPattern("Ba 3 1a 3 2 3 1a 3")),
                            StrumPatternDef("arpeggio_3", "Rải Ballad 3", parseArpeggioPattern("Ba 32 1a 1 21 3 21a 3")),
                            StrumPatternDef("arpeggio_4", "Rải Ballad 4", parseArpeggioPattern("Ba 3 2a 3 1 . 2a 3")),
                            StrumPatternDef("arpeggio_5", "Rải Ballad 5", parseArpeggioPattern("Ba 3 2a 3 1 . 3a 2")),
                            StrumPatternDef("arpeggio_6", "Rải Ballad 6", parseArpeggioPattern("Ba 3 2a 3 1 3 2a 3")),
                            StrumPatternDef("arpeggio_7", "Rải Ballad 7", parseArpeggioPattern("Ba . 21a 3 21 . 21a 3")),
                            StrumPatternDef("arpeggio_8", "Rải Ballad 8 (Móc dượt)", parseArpeggioPattern("Ba 21a 3 21a 3 21a 3 2")),
                            StrumPatternDef("arpeggio_9", "Rải Ballad 9 (Móc đơn)", parseArpeggioPattern("Ba . 21a 3 21 . 21a 32")),
                            StrumPatternDef("arpeggio_10", "Rải Ballad 10", parseArpeggioPattern("Ba 3 2a 1 2 3 2a .")),
                            StrumPatternDef("arpeggio_11", "Rải Ballad 11", parseArpeggioPattern("Ba 4 3a 2 1 3 2a 3")),
                            StrumPatternDef("arpeggio_12", "Rải Ballad 12", parseArpeggioPattern("Ba 4 32a 4 21 3 21a 3")),
                            StrumPatternDef("arpeggio_13", "Rải Ballad 13", parseArpeggioPattern("Ba 4 3a 2 1 . 2a 3")),
                            StrumPatternDef("arpeggio_14", "Rải Ballad 14 (1 phách ngoài)", parseArpeggioPattern("Ba 4 3a 2 . 1 2a 3")),
                            StrumPatternDef("arpeggio_15", "Rải Ballad 15 (1 phách ngoài)", parseArpeggioPattern("Ba 4 3a 2 . 3 2a 3"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "8 Kiểu Quạt Ballad 16 Phách Chuẩn",
                        patterns = listOf(
                            StrumPatternDef("ballad_1", "Ballad Kiểu 1", parsePatternString("Da . . . D . . U Da . . U Da . D U")),
                            StrumPatternDef("ballad_2", "Ballad Kiểu 2", parsePatternString("Da . . . D . D U Da . D U Da . D U")),
                            StrumPatternDef("ballad_3", "Ballad Kiểu 3", parsePatternString("Da . . . D . . U Da U D U Da . D U")),
                            StrumPatternDef("ballad_4", "Ballad Kiểu 4", parsePatternString("Da . . . D . . U Da U D . Da . D U")),
                            StrumPatternDef("ballad_5", "Ballad Kiểu 5", parsePatternString("Da . . . D . . U Da U . U Da . D U")),
                            StrumPatternDef("ballad_6", "Ballad Kiểu 6", parsePatternString("Da . . . D . . U . U . U Da . D U")),
                            StrumPatternDef("ballad_7", "Ballad Kiểu 7", parsePatternString("Da . . . D . D . Da U D . Da . D U")),
                            StrumPatternDef("ballad_8", "Ballad Kiểu 8", parsePatternString("Da . . . D . . U . U D . Da . D U"))
                        )
                    ),
                    StrumCategoryDef(
                        title = "Funk & Tiết tấu khác",
                        patterns = listOf(
                            StrumPatternDef("funk", "Funk", parsePatternString("Da M M U M M D M M U M M D M M M")),
                            StrumPatternDef("rock", "Kiểu rock - sôi động", parsePatternString("Da . D . Da . . Ua . D . Ua Da Da Da Ua"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("disco") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Disco",
                        patterns = listOf(
                            // 1. Disco 2/4: Bass - 3 - Chập (123) - 3
                            StrumPatternDef("disco_arp_1", "Disco 2/4 (B-3-Chập-3)", parseArpeggioPattern("Ba 3 123a 3")),
                            // 2. Disco 4/4 đảo phách: Bass - 3 - Chập - 3 - Nghỉ - 3 - Chập - 3
                            StrumPatternDef("disco_arp_2", "Disco 4/4 Đảo phách", parseArpeggioPattern("Ba 3 123a 3 . 3 123a 3"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Disco (Chuẩn Thu Nhạc)",
                        patterns = listOf(
                            // 1. Disco nhịp 2/4: Xuống - Lên - Chặn - Lên
                            StrumPatternDef("disco_strum_1", "Disco nhịp 2/4 (D-U-M-U)", parsePatternString("Da U M U")),
                            // 2. Disco nhịp 4/4 đảo phách: Xuống - Lên - Chặn - Lên - Nghỉ - Lên - Chặn - Lên
                            StrumPatternDef("disco_strum_2", "Disco nhịp 4/4 Đảo phách", parsePatternString("Da U M U . U M U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("fox") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Fox (Nhịp 2/4 - 4/4)",
                        patterns = listOf(
                            StrumPatternDef("fox_arp_1", "Rải Fox cơ bản (Bùm - Chát)", parseArpeggioPattern("Ba . 123a . Ba . 123a .")),
                            StrumPatternDef("fox_arp_2", "Rải Fox tỉa dây (B-3-12-3)", parseArpeggioPattern("Ba 3 12a 3 Ba 3 12a 3"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Fox (Vui nhộn)",
                        patterns = listOf(
                            StrumPatternDef("fox_strum_1", "Quạt Fox dồn dập (Bùm-Chát)", parsePatternString("Da . D U Da . D U")),
                            StrumPatternDef("fox_strum_2", "Fox quạt đều tay", parsePatternString("Da U D U Da U D U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("chacha") || cleanRhythm.contains("chachacha") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải ChaChaCha (Latin)",
                        patterns = listOf(
                            StrumPatternDef("chacha_arp_1", "Rải ChaCha cơ bản", parseArpeggioPattern("Ba . 123a . Ba 123 123 123")),
                            StrumPatternDef("chacha_arp_2", "Rải ChaCha Latinh nhấp nhả", parseArpeggioPattern("Ba 3 12a . Ba 12 12 12"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả ChaChaCha",
                        patterns = listOf(
                            StrumPatternDef("chacha_strum_1", "ChaCha cơ bản (Chát-Chát-ChaChaCha)", parsePatternString("Da . M . Da M D U")),
                            StrumPatternDef("chacha_strum_2", "ChaCha dập Latinh sôi nổi", parsePatternString("Da . D U Da D U D"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("slowrock") || cleanRhythm.contains("slow rock") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Slow Rock 6/8",
                        patterns = listOf(
                            StrumPatternDef("sr_arp_1", "Rải cơ bản (B-3-2-1-2-3)", parseArpeggioPattern("Ba 3 2 1a 2 3")),
                            StrumPatternDef("sr_arp_2", "Rải móc kép (B-3-12-3-12-3)", parseArpeggioPattern("Ba 3 12a 3 12a 3")),
                            StrumPatternDef("sr_arp_3", "Rải vắt dây (B-4-3-2-1-2)", parseArpeggioPattern("Ba 4 3 2a 1 2"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Slow Rock 6 Phách",
                        patterns = listOf(
                            StrumPatternDef("sr_strum_1", "Quạt dậm nhịp (Bùm-Chát)", parsePatternString("Da D D Da D D")),
                            StrumPatternDef("sr_strum_2", "Quạt cuộn sóng (Nhấp nhả)", parsePatternString("Da D U Da D U")),
                            StrumPatternDef("sr_strum_3", "Quạt cao trào (Điệp khúc)", parsePatternString("Da U D Ua D U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("valse") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Valse (Nhịp 3/4)",
                        patterns = listOf(
                            // Kiểu 1: Bùm - Chát - Chát (Móc chùm 3 dây treble)
                            StrumPatternDef("valse_arp_1", "Rải cơ bản (B - 123 - 123)", parseArpeggioPattern("Ba 123 123")),
                            // Kiểu 2: Rải đơn tách nốt (Bass - 3 - 2 - 1 - 2 - 3)
                            StrumPatternDef("valse_arp_2", "Rải lượn sóng (B - 3 - 2 - 1 - 2 - 3)", parseArpeggioPattern("Ba 3 2 1 2 3")),
                            // Kiểu 3: Rải kép nhấp nhả (Bass - 3 - 12 - 3 - 12)
                            StrumPatternDef("valse_arp_3", "Rải móc kép (B - 3 - 12 - 3 - 12)", parseArpeggioPattern("Ba 3 12 3 12 ."))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Valse (Nhịp 3/4)",
                        patterns = listOf(
                            // Kiểu 1: BùM - Chát - Chát (Dậm phách rõ)
                            StrumPatternDef("valse_strum_1", "Quạt cơ bản (Bùm - Chát - Chát)", parsePatternString("Da D D")),
                            // Kiểu 2: Dạt dào (Xuống - Xuống Lên - Xuống Lên)
                            StrumPatternDef("valse_strum_2", "Quạt dạt dào (X - X L - X L)", parsePatternString("Da D U D U .")),
                            // Kiểu 3: Nhấn phách liên tục
                            StrumPatternDef("valse_strum_3", "Quạt biến tấu nhịp 3", parsePatternString("Da . D U Da ."))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("boston") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Boston (Nhịp 3/4 Chậm)",
                        patterns = listOf(
                            // Kiểu 1: Rải chuẩn Boston (Bass - 3 - 2 - 1 - 2 - 3 với phách 1 nhấn mạnh)
                            StrumPatternDef("boston_arp_1", "Rải cơ bản (B - 3 - 2 - 1 - 2 - 3)", parseArpeggioPattern("Ba 3 2 1 2 3")),
                            // Kiểu 2: Móc kép (Bass - 3 - 12 - 3 - 12 - 3)
                            StrumPatternDef("boston_arp_2", "Rải móc kép (B - 3 - 12 - 3 - 12 - 3)", parseArpeggioPattern("Ba 3 12 3 12 3")),
                            // Kiểu 3: Móc trải dây trầm (Bass - 4 - 3 - 2 - 1 - 2)
                            StrumPatternDef("boston_arp_3", "Rải vắt dây trầm", parseArpeggioPattern("Ba 4 3 2 1 2"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Boston (Nhịp 3/4 Trữ tình)",
                        patterns = listOf(
                            // Kiểu 1: Nhấn nhẹ nhàng chậm rãi
                            StrumPatternDef("boston_strum_1", "Quạt cơ bản (X - X - X L)", parsePatternString("Da . D . D U")),
                            // Kiểu 2: Cuộn nhịp tình ca (X - X L - X L)
                            StrumPatternDef("boston_strum_2", "Quạt cuộn sóng (X - X L - X L)", parsePatternString("Da D U D U .")),
                            // Kiểu 3: Đầy đặn cho điệp khúc
                            StrumPatternDef("boston_strum_3", "Quạt cao trào Boston", parsePatternString("Da U D U D U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("bossanova") || cleanRhythm.contains("bossa") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Bossa Nova (Chuẩn Duytieu Music)",
                        patterns = listOf(
                            // 1. Tiết Tấu 1 chuẩn bản nhạc: Bass - Chập - Bass - CHẬP(nhấn) - Nghỉ - Chập
                            StrumPatternDef("bossa_arp_1", "Bossa Nova Tiết Tấu 1", parseArpeggioPattern("Ba 123 Ba 123a . 123 Ba 123 . 123a . Ba")),
                            // 2. Tiết Tấu 2: Biến tấu móc kép đảo phách Latin
                            StrumPatternDef("bossa_arp_2", "Bossa Nova Tiết Tấu 2", parseArpeggioPattern("Ba 3 12a . Ba 12 12a 12"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Bossa Nova (Chuẩn Duytieu Music)",
                        patterns = listOf(
                            // 1. Quạt mô phỏng Tiết Tấu 1 đảo phách: X - L - X - L(nhấn) - Nghỉ - L
                            StrumPatternDef("bossa_strum_1", "Bossa Nova Quạt Tiết Tấu 1", parsePatternString("Da U Da Ua . U Da U . Ua . Da")),
                            // 2. Quạt dập nhịp Latinh nhấp nhả
                            StrumPatternDef("bossa_strum_2", "Bossa Nova Quạt Tiết Tấu 2", parsePatternString("Da . D U Da U D ."))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("tango") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Tango (Chuẩn Giáo Trình)",
                        patterns = listOf(
                            // Cách đệm 1: Bass(chấm dôi) - Dây 4 - Chập(123) - Bass phụ (B - 4 - Chập - B)
                            StrumPatternDef("tango_arp_1", "Tango Cách đệm 1 (B-4-Chập-B)", parseArpeggioPattern("Ba . 4 123a Ba . 4 123a")),
                            // Biến thể tỉa nốt gián đoạn
                            StrumPatternDef("tango_arp_2", "Tango Tỉa ngắt tiếng", parseArpeggioPattern("Ba . 3 123a Ba . 3 123a"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Tango (Chuẩn Giáo Trình)",
                        patterns = listOf(
                            // Cách đệm 2: Chát - nghỉ - Chát - nghỉ - Chát - Chát Chát (Dập dứt khoát)
                            StrumPatternDef("tango_strum_1", "Tango Cách đệm 2 (Dậm ngắt)", parsePatternString("Da . M . Da . M M")),
                            // Biến thể quạt hành khúc Tango
                            StrumPatternDef("tango_strum_2", "Tango Hùng tráng", parsePatternString("Da . M . Da M Da M"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("reggae") || cleanRhythm.contains("ska") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Reggae (Off-Beat)",
                        patterns = listOf(
                            StrumPatternDef("reggae_arp_1", "Reggae nhấp phách lệch", parseArpeggioPattern("Ba . 123a . Ba . 123a ."))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Reggae (Chém Chặn)",
                        patterns = listOf(
                            // Chém phách lệch: Nghỉ ở phách chính, dập chát chặn ở phách phụ
                            StrumPatternDef("reggae_strum_1", "Reggae chém phách lệch", parsePatternString(". Ma . Ma . Ma . Ma")),
                            StrumPatternDef("reggae_strum_2", "Ska dập nảy sôi động", parsePatternString(". M . U . M . U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("blue") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Blues / Shuffle",
                        patterns = listOf(
                            // Kiểu 1: Móc luân phiên dây Bass và Treble
                            StrumPatternDef("blues_arp_1", "Rải Blues cơ bản (B-3-12-3)", parseArpeggioPattern("Ba 3 12a 3 Ba 3 12a 3")),
                            // Kiểu 2: Blues lượn ngón chậm rãi
                            StrumPatternDef("blues_arp_2", "Rải Blues cổ điển (B-3-2-1-2-3)", parseArpeggioPattern("Ba 3 2 1 2 3 Ba .")),
                            // Kiểu 3: Shuffle nhấn phách lệch
                            StrumPatternDef("blues_arp_3", "Blues Shuffle rải nảy", parseArpeggioPattern("Ba . 21a 3 Ba . 21a 3"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Blues (Shuffle / Swing)",
                        patterns = listOf(
                            // Kiểu 1: Blues Shuffle cơ bản dậm giật phách
                            StrumPatternDef("blues_strum_1", "Blues Shuffle cơ bản", parsePatternString("Da . D U Da . D U")),
                            // Kiểu 2: Quạt nhấp nhả dây trầm - bổng
                            StrumPatternDef("blues_strum_2", "Blues nhấp nhả (Swing)", parsePatternString("Da U D . Da U D .")),
                            // Kiểu 3: Blues Rock cao trào
                            StrumPatternDef("blues_strum_3", "Blues Rock cao trào", parsePatternString("Da U D U Da U D U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("bolero") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Bolero (Chuẩn Giáo Trình)",
                        patterns = listOf(
                            // 1. Bolero 4/4 chuẩn: Bùm - (chờ) - 3 - 2 - 123 (chát) - 123 (chách) - Bùm - 123 - Bùm - 123
                            StrumPatternDef("bolero_arp_1", "Bolero 4/4 Truyền thống", parseArpeggioPattern("Ba . 3 2 123a . 123a . Ba . 123a . Ba . 123a .")),
                            // 2. Bolero 2/4 (Đoạn điệp khúc/nhấn phách): Bùm - (chờ) - 3 - 2 - 123 (chát) - 123 (chách)
                            StrumPatternDef("bolero_arp_2", "Bolero 2/4 Ngắn (Điệp khúc)", parseArpeggioPattern("Ba . 3 2 123a . 123a .")),
                            // 3. Bolero móc tỉa nốt mượt mà
                            StrumPatternDef("bolero_arp_3", "Bolero tỉa êm dịu", parseArpeggioPattern("Ba 3 2 1 123a 3 Ba 123a"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Bolero (Chuẩn Giáo Trình)",
                        patterns = listOf(
                            // 1. Quạt Bolero 4/4: Bùm - (Xuống-Lên-Xuống) - Chát - Bùm - Chát - Bùm - Chát
                            StrumPatternDef("bolero_strum_1", "Quạt Bolero 4/4 Chuẩn", parsePatternString("Da . D U Da . D . Da . D . Da . D .")),
                            // 2. Quạt Bolero 2/4: Bùm - (Xuống-Lên-Xuống) - Chát
                            StrumPatternDef("bolero_strum_2", "Quạt Bolero 2/4 (Dồn nhịp)", parsePatternString("Da . D U Da . D .")),
                            // 3. Quạt Bolero giật phách cao trào
                            StrumPatternDef("bolero_strum_3", "Quạt Bolero cao trào", parsePatternString("Da . D U Da U D U Da . D U Da U D U"))
                        )
                    )
                )
            }
        }

        cleanRhythm.contains("rhumba") || cleanRhythm.contains("rumba") -> {
            if (isArpeggio) {
                listOf(
                    StrumCategoryDef(
                        title = "Móc Rải Rumba (Nhịp 4/4 Nhộn nhịp)",
                        patterns = listOf(
                            // 1. Rumba cơ bản giật nảy: Bass - 3 - Chập - Bass - 3 - Chập
                            StrumPatternDef("rumba_arp_1", "Rải Rumba cơ bản", parseArpeggioPattern("Ba 3 123a . Ba 3 123a .")),
                            // 2. Rumba móc nhấp nhả Latinh
                            StrumPatternDef("rumba_arp_2", "Rải Rumba Latinh", parseArpeggioPattern("Ba . 21a 3 Ba . 21a 3")),
                            // 3. Rumba đảo phách
                            StrumPatternDef("rumba_arp_3", "Rải Rumba đảo phách", parseArpeggioPattern("Ba 3 2 1a . 3 2 1"))
                        )
                    )
                )
            } else {
                listOf(
                    StrumCategoryDef(
                        title = "Quạt Chả Rumba (Latin Sôi động)",
                        patterns = listOf(
                            // 1. Quạt Rumba dập chặt tiếng
                            StrumPatternDef("rumba_strum_1", "Quạt Rumba giật phách", parsePatternString("Da . M U Da . M U")),
                            // 2. Quạt Rumba nhịp khiêu vũ
                            StrumPatternDef("rumba_strum_2", "Quạt Rumba khiêu vũ", parsePatternString("Da U M U Da U D U")),
                            // 3. Quạt Rumba bốc lửa
                            StrumPatternDef("rumba_strum_3", "Quạt Rumba cao trào", parsePatternString("Da M Da M Da M D U"))
                        )
                    )
                )
            }
        }

        else -> emptyList()
    }
}

// 3. DIALOG GIAO DIỆN CHÍNH
@Composable
fun StrummingPatternDialog(
    songId: String = "",
    rhythmName: String,
    bpm: Float,
    songChords: List<String>,
    guitarChordsList: List<ChordModel>,
    surfaceColor: Color,
    tunaGreen: Color,
    textColor: Color,
    onPatternSelected: (patternId: String, isArpeggio: Boolean) -> Unit = { _, _ -> },
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val pref = remember { context.getSharedPreferences("SongPatternPref", Context.MODE_PRIVATE) }
    val savedPatternId = remember(songId) { pref.getString("pattern_id_$songId", null) }

    // Ép luôn luôn mở tab Móc rải (bên trái) mặc định
    var isArpeggioMode by remember { mutableStateOf(true) }
    val categories = remember(rhythmName, isArpeggioMode) { getGroupedStrummingPatterns(rhythmName, isArpeggioMode) }
    val displayRhythm = rhythmName.ifBlank { "Ballad" }

    var currentBpm by remember { mutableFloatStateOf(if (bpm > 0) bpm else 74f) }

    var selectedPatternId by remember(categories, isArpeggioMode) {
        val fallbackId = categories.firstOrNull()?.patterns?.firstOrNull()?.id ?: "arpeggio_1"
        mutableStateOf(if (isArpeggioMode && savedPatternId != null && savedPatternId.startsWith("arpeggio")) savedPatternId else fallbackId)
    }
    var playingPatternId by remember { mutableStateOf<String?>(null) }
    var activeStepIndex by remember { mutableIntStateOf(-1) }
    var currentChordText by remember { mutableStateOf("") }
    var showRhythmTutorialSheet by remember { mutableStateOf(false) }

    // BIẾN LƯU VIDEO ĐANG PHÁT TẠI CHỖ
    var playingTutorialVideoId by remember { mutableStateOf<String?>(null) }

    var userSelectedChord by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = true
    )

    LaunchedEffect(Unit) {
        CoreAudioPlayer.init()
        CoreAudioPlayer.loadInstrument(context, "Guitar")
    }

    val defaultChordQuery = remember(songChords) { if (songChords.isNotEmpty()) songChords.first() else "C" }

    val allPatternsMap = remember(categories) {
        categories.flatMap { it.patterns }.associateBy { it.id }
    }

    val dynamicBassString = remember(currentChordText, defaultChordQuery, guitarChordsList) {
        val targetQuery = if (currentChordText.isNotEmpty()) currentChordText else defaultChordQuery

        val exactMatch = guitarChordsList.find { chord ->
            val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
            val chordFullName = "${chord.key}$displaySuffix"
            val isDirectMatch = chordFullName.equals(targetQuery, ignoreCase = true)

            val enharmonicMap = mapOf("C#" to "Db", "Db" to "C#", "D#" to "Eb", "Eb" to "D#", "F#" to "Gb", "Gb" to "F#", "G#" to "Ab", "Ab" to "G#", "A#" to "Bb", "Bb" to "A#")
            var isEnharmonicMatch = false
            val match = Regex("^([A-G][#b]?)(.*)").find(targetQuery)

            if (match != null) {
                val root = match.groupValues[1]
                val suffix = match.groupValues[2]
                val altRoot = enharmonicMap[root]
                if (altRoot != null) {
                    val altChordName = "$altRoot$suffix"
                    isEnharmonicMatch = chordFullName.equals(altChordName, ignoreCase = true)
                }
            }
            isDirectMatch || isEnharmonicMatch
        }

        val position = exactMatch?.positions?.firstOrNull()

        var bassStr = 5
        if (position != null && position.frets.size == 6) {
            val bassIndex = position.frets.indexOfFirst { it != -1 }
            if (bassIndex in 0..5) {
                bassStr = 6 - bassIndex
            }
        }
        bassStr
    }

    val defaultMidiData = remember(defaultChordQuery, guitarChordsList) {
        val exactMatch = guitarChordsList.find { chord ->
            val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
            val chordFullName = "${chord.key}$displaySuffix"
            chordFullName.equals(defaultChordQuery, ignoreCase = true)
        }
        exactMatch?.positions?.firstOrNull()?.midi
    }

    val playStepAudio: (StrumStep, List<Int>, String) -> Unit = { step, notes, _ ->
        coroutineScope.launch(Dispatchers.Default) {
            step.actions.forEach { action ->
                if (isArpeggioMode && action.arpeggioNote.isNotEmpty()) {
                    val playNotes = mutableListOf<Int>()
                    val noteStr = action.arpeggioNote

                    if (noteStr.contains("B")) {
                        val bassIndex = 6 - dynamicBassString
                        val bassNote = if (bassIndex in notes.indices) notes[bassIndex] else notes.firstOrNull()
                        bassNote?.let { playNotes.add(it) }
                    }
                    if (noteStr.contains("4")) { val n = notes.getOrNull(notes.size - 4); if (n != null) playNotes.add(n) }
                    if (noteStr.contains("3")) { val n = notes.getOrNull(notes.size - 3) ?: notes.lastOrNull(); if (n != null) playNotes.add(n) }
                    if (noteStr.contains("2")) { val n = notes.getOrNull(notes.size - 2) ?: notes.lastOrNull(); if (n != null) playNotes.add(n) }
                    if (noteStr.contains("1")) { val n = notes.lastOrNull(); if (n != null) playNotes.add(n) }

                    if (playNotes.isNotEmpty()) {
                        val vol = if (action.isAccent) 1.0f else 0.8f
                        val notesToFire = playNotes.map { Pair(it, vol) }
                        CoreAudioPlayer.playSimultaneousNotes(notesToFire, "Guitar")
                    }

                } else if (!isArpeggioMode) {
                    if (action.type == StrumType.DOWN || action.type == StrumType.UP || action.type == StrumType.MUTE) {
                        val isUp = action.type == StrumType.UP
                        val isMute = action.type == StrumType.MUTE

                        // Dừng hoàn toàn mọi âm thanh đang ngân
                        CoreAudioPlayer.stopPreviousStrum()

                        if (isMute) {
                            // XỬ LÝ CHẶN (MUTE): Dập tắt toàn bộ âm thanh dây đàn, không phát bất kỳ nốt nào
                            CoreAudioPlayer.stopPreviousStrum()
                        } else {
                            // XỬ LÝ QUẠT XUỐNG / LÊN
                            val strumNotes = if (isUp) notes.takeLast(4).reversed() else notes

                            launch {
                                strumNotes.forEachIndexed { index, note ->
                                    val baseVolume = when {
                                        action.isAccent -> 1.0f
                                        isUp -> 0.70f - (index * 0.05f)
                                        else -> 0.75f - (index * 0.05f)
                                    }
                                    val finalVolume = baseVolume.coerceIn(0.35f, 1.0f)
                                    CoreAudioPlayer.playSimultaneousNotes(listOf(Pair(note, finalVolume)), "Guitar")
                                    delay(18)
                                }
                            }
                        }
                    }
                }

                if (step.actions.size > 1) { delay(120) }
            }
        }
    }

    LaunchedEffect(playingPatternId, isArpeggioMode, userSelectedChord) {
        if (playingPatternId != null) {
            val activePatternDef = allPatternsMap[playingPatternId]
            if (activePatternDef != null) {
                val activePattern = activePatternDef.pattern
                val baseChords = if (songChords.isNotEmpty()) songChords.take(8) else listOf("C", "E7", "Am7", "Fm", "Am7/G", "F", "Dm7", "G")
                val chordsToPlay = if (userSelectedChord != null) listOf(userSelectedChord!!) else baseChords
                var chordIndex = 0

                val isSlowRock = rhythmName.lowercase().contains("slow")

                while (playingPatternId != null) {
                    val actualBpm = if (currentBpm > 0) currentBpm else 74f
                    val delayMs = when (activePattern.size) {
                        16 -> (60000f / actualBpm / 4f).toLong()
                        8 -> (60000f / actualBpm / 2f).toLong()
                        6 -> if (isSlowRock) (60000f / actualBpm / 3f).toLong() else (60000f / actualBpm / 2f).toLong()
                        else -> (60000f / actualBpm / 2f).toLong()
                    }.coerceAtLeast(40L)

                    val currentChordQuery = chordsToPlay[chordIndex]
                    currentChordText = currentChordQuery

                    val exactMatch = guitarChordsList.find { chord ->
                        val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
                        val chordFullName = "${chord.key}$displaySuffix"
                        chordFullName.equals(currentChordQuery, ignoreCase = true)
                    }

                    val midiData = exactMatch?.positions?.firstOrNull()?.midi

                    for (i in activePattern.indices) {
                        if (playingPatternId == null) break
                        activeStepIndex = i
                        val step = activePattern[i]

                        midiData?.let { notes -> playStepAudio(step, notes, "TỰ ĐỘNG PHÁT") }
                        delay(delayMs)
                    }
                    chordIndex = (chordIndex + 1) % chordsToPlay.size
                }
            }
        } else {
            activeStepIndex = -1
            currentChordText = userSelectedChord ?: ""
            CoreAudioPlayer.stopPreviousStrum()
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            playingPatternId = null
            playingTutorialVideoId = null
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = surfaceColor,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(4.dp)
                        .background(tunaGreen.copy(alpha = 0.8f), RoundedCornerShape(2.dp))
                )
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight(0.95f)
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // KHUNG PHÁT VIDEO NỔI NGAY TẠI APP
            if (playingTutorialVideoId != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    val embedUrl = "https://www.youtube.com/embed/${playingTutorialVideoId}?autoplay=1&playsinline=1&fs=1"
                    AndroidView(
                        factory = { ctx ->
                            android.webkit.WebView(ctx).apply {
                                layoutParams = android.view.ViewGroup.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                setBackgroundColor(android.graphics.Color.BLACK)
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    mediaPlaybackRequiresUserGesture = false
                                    mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                    userAgentString = "Mozilla/5.0"
                                }
                                webViewClient = android.webkit.WebViewClient()
                                val headers = mutableMapOf<String, String>()
                                headers["Referer"] = "http://ducphi.atwebpages.com/"
                                loadUrl(embedUrl, headers)
                            }
                        },
                        onRelease = { webView ->
                            webView.stopLoading()
                            webView.loadUrl("about:blank")
                            webView.destroy()
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Nút đóng khung video nổi
                    IconButton(
                        onClick = { playingTutorialVideoId = null },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(28.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Đóng video",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // TIÊU ĐỀ
            Text(
                text = "Tiết tấu · Điệu $displayRhythm",
                color = textColor,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            // 1. BORDER NGANG CHIA RANH GIỚI TIÊU ĐỀ
            HorizontalDivider(
                color = Color.Gray.copy(alpha = 0.2f),
                thickness = 1.dp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Thanh tab chuyển đổi Móc rải (trái) / Quạt chả (phải)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Gray.copy(alpha = 0.1f))
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isArpeggioMode) tunaGreen else Color.Transparent)
                        .clickable { isArpeggioMode = true; playingPatternId = null }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Móc rải", color = if (isArpeggioMode) Color.White else textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!isArpeggioMode) tunaGreen else Color.Transparent)
                        .clickable { isArpeggioMode = false; playingPatternId = null }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Quạt chả", color = if (!isArpeggioMode) Color.White else textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            val isDarkModeDialog = textColor == Color.White
            val controlBgColor = if (isDarkModeDialog) Color(0xFF181818) else Color.Gray.copy(alpha = 0.12f)
            val btnCircleBgColor = if (isDarkModeDialog) Color(0xFF282828) else Color.Gray.copy(alpha = 0.25f)
            val sliderInactiveColor = if (isDarkModeDialog) Color(0xFF333333) else Color.Gray.copy(alpha = 0.3f)

            // 2. KHU VỰC ĐIỀU CHỈNH BPM + NÚT VIDEO HƯỚNG DẪN ĐIỆU NHẠC
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(controlBgColor)
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(btnCircleBgColor, CircleShape)
                                .clickable { if (currentBpm > 40) currentBpm -= 2 },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Remove, null, tint = textColor, modifier = Modifier.size(13.dp))
                        }

                        Text(
                            text = "${currentBpm.toInt()} BPM",
                            color = tunaGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )

                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(btnCircleBgColor, CircleShape)
                                .clickable { if (currentBpm < 240) currentBpm += 2 },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Add, null, tint = textColor, modifier = Modifier.size(13.dp))
                        }
                    }

                    Slider(
                        value = currentBpm,
                        onValueChange = { currentBpm = it },
                        valueRange = 40f..240f,
                        modifier = Modifier.weight(1f).padding(start = 6.dp).height(22.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = tunaGreen,
                            activeTrackColor = tunaGreen,
                            inactiveTrackColor = sliderInactiveColor
                        )
                    )
                }

                // NÚT VIDEO HƯỚNG DẪN ĐIỆU NHẠC
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(controlBgColor)
                        .border(1.dp, tunaGreen.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .clickable { showRhythmTutorialSheet = true }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.OndemandVideo,
                        contentDescription = "Hướng dẫn điệu nhạc",
                        tint = tunaGreen,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Hướng dẫn",
                        color = textColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val chordList = remember(songChords) {
                if (songChords.isNotEmpty()) songChords.take(8) else listOf("C", "E7", "Am7", "Fm", "Am7/G", "F", "Dm7", "G")
            }

            // CHÚ THÍCH KÝ HIỆU
            if (!isArpeggioMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("↓", color = Color(0xFFFF9800), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Xuống", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("↑", color = Color(0xFF00BCD4), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Lên", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("✕", color = Color(0xFFF44336), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Chặn", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(4.dp).background(Color.Gray, CircleShape))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nghỉ", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(5.dp).background(Color(0xFF00E676), CircleShape))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Nhấn", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("p:", color = Color(0xFF9C27B0), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Cái", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("i:", color = Color(0xFF2196F3), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Trỏ", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("m:", color = Color(0xFF4CAF50), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Giữa", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("a:", color = Color(0xFFF44336), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Áp út", color = textColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Danh sách tiết tấu cuộn dọc
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(scrollState)
            ) {
                categories.forEach { category ->
                    if (category.title.isNotBlank()) {
                        Text(
                            text = category.title,
                            color = textColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)
                        )
                    }

                    category.patterns.forEachIndexed { patternIndex, patternDef ->
                        val isSelected = selectedPatternId == patternDef.id
                        val isPlaying = playingPatternId == patternDef.id
                        val isDarkModeCard = textColor == Color.White

                        val itemBgColor = if (isSelected) {
                            if (isDarkModeCard) Color(0xFF161616) else Color.Gray.copy(alpha = 0.12f)
                        } else Color.Transparent

                        val itemBorderColor = if (isPlaying) {
                            tunaGreen
                        } else if (isSelected) {
                            tunaGreen.copy(alpha = 0.6f)
                        } else {
                            if (isDarkModeCard) Color(0xFF2C2C2C) else Color.Gray.copy(alpha = 0.35f)
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(itemBgColor)
                                .border(
                                    width = if (isPlaying) 1.5.dp else 1.dp,
                                    color = itemBorderColor,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    selectedPatternId = patternDef.id
                                    if (songId.isNotBlank()) {
                                        pref.edit()
                                            .putString("pattern_id_$songId", patternDef.id)
                                            .putBoolean("is_arp_$songId", isArpeggioMode)
                                            .apply()
                                    }
                                    onPatternSelected(patternDef.id, isArpeggioMode)
                                }
                                .padding(10.dp)
                        ) {
                            if (isPlaying) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp)
                                        .horizontalScroll(rememberScrollState()),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Vòng hợp âm: ",
                                        color = textColor.copy(alpha = 0.6f),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )

                                    chordList.forEachIndexed { idx, chord ->
                                        val isPlayingThisChord = currentChordText.equals(chord, ignoreCase = true)
                                        val isSelectedManually = (userSelectedChord == chord)
                                        val isHighlighted = isPlayingThisChord || isSelectedManually

                                        Text(
                                            text = chord,
                                            color = if (isHighlighted) tunaGreen else textColor.copy(alpha = 0.35f),
                                            fontSize = if (isHighlighted) 14.sp else 12.sp,
                                            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .clickable {
                                                    userSelectedChord = if (userSelectedChord == chord) null else chord
                                                    currentChordText = userSelectedChord ?: ""
                                                }
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        )

                                        if (idx < chordList.size - 1) {
                                            Text(
                                                text = "-",
                                                color = textColor.copy(alpha = 0.25f),
                                                fontSize = 12.sp,
                                                modifier = Modifier.padding(horizontal = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${patternIndex + 1}.",
                                    color = if (isPlaying) tunaGreen else textColor.copy(alpha = 0.5f),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(end = 8.dp)
                                )

                                val isDarkModeItem = textColor == Color.White
                                val dialogPlayBtnBg = if (isPlaying) tunaGreen else (if (isDarkModeItem) Color(0xFF282828) else Color.Gray.copy(alpha = 0.2f))
                                val dialogPlayBtnIconColor = if (isPlaying) Color.White else textColor
                                val dialogChunkBgColor = if (isDarkModeItem) Color(0xFF181818) else Color.Gray.copy(alpha = 0.12f)
                                val dialogDividerColor = if (isDarkModeItem) Color(0xFF262626) else Color.Gray.copy(alpha = 0.25f)

                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .background(dialogPlayBtnBg, CircleShape)
                                        .clickable {
                                            playingPatternId = if (isPlaying) null else patternDef.id
                                            selectedPatternId = patternDef.id
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = dialogPlayBtnIconColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                Spacer(Modifier.width(10.dp))

                                if (isArpeggioMode) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        FingerstyleTabViewer(
                                            pattern = patternDef.pattern,
                                            activeStepIndex = if (isPlaying) activeStepIndex else -1,
                                            isPlaying = isPlaying,
                                            bassString = dynamicBassString,
                                            textColor = textColor,
                                            tunaGreen = tunaGreen,
                                            onStepClick = { globalIndex ->
                                                if (playingPatternId == null) {
                                                    activeStepIndex = globalIndex
                                                    currentChordText = userSelectedChord ?: defaultChordQuery
                                                    val clickChord = currentChordText
                                                    val exactMatch = guitarChordsList.find { chord ->
                                                        val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
                                                        val chordFullName = "${chord.key}$displaySuffix"
                                                        chordFullName.equals(clickChord, ignoreCase = true)
                                                    }
                                                    val midiData = exactMatch?.positions?.firstOrNull()?.midi ?: defaultMidiData
                                                    midiData?.let { playStepAudio(patternDef.pattern[globalIndex], it, "CLICK THỦ CÔNG") }
                                                    coroutineScope.launch {
                                                        delay(300)
                                                        if (playingPatternId == null && activeStepIndex == globalIndex) {
                                                            activeStepIndex = -1
                                                            currentChordText = userSelectedChord ?: ""
                                                        }
                                                    }
                                                }
                                            }
                                        )
                                    }
                                } else {
                                    val chunkSize = when (patternDef.pattern.size) {
                                        16 -> 4
                                        8 -> 2
                                        6 -> 2
                                        else -> 4
                                    }
                                    val chunks = patternDef.pattern.chunked(chunkSize)

                                    Row(
                                        modifier = Modifier.weight(1f),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        chunks.forEachIndexed { chunkIndex, chunkItems ->
                                            Row(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(dialogChunkBgColor)
                                                    .padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceEvenly,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                chunkItems.forEachIndexed { itemIndex, step ->
                                                    val globalIndex = chunkIndex * chunkSize + itemIndex
                                                    val isActive = (isPlaying || playingPatternId == null) && globalIndex == activeStepIndex

                                                    val itemAlpha = when {
                                                        !isPlaying -> 1f
                                                        isActive -> 1f
                                                        else -> 0.85f
                                                    }

                                                    val stepBgColor = when {
                                                        isActive && isPlaying -> tunaGreen.copy(alpha = 0.5f)
                                                        isActive && playingPatternId == null -> tunaGreen.copy(alpha = 0.25f)
                                                        else -> Color.Transparent
                                                    }

                                                    Column(
                                                        horizontalAlignment = Alignment.CenterHorizontally,
                                                        verticalArrangement = Arrangement.Center,
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(30.dp)
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(stepBgColor)
                                                            .clickable {
                                                                if (playingPatternId == null) {
                                                                    activeStepIndex = globalIndex
                                                                    currentChordText = userSelectedChord ?: defaultChordQuery
                                                                    val clickChord = currentChordText
                                                                    val exactMatch = guitarChordsList.find { chord ->
                                                                        val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
                                                                        val chordFullName = "${chord.key}$displaySuffix"
                                                                        chordFullName.equals(clickChord, ignoreCase = true)
                                                                    }
                                                                    val midiData = exactMatch?.positions?.firstOrNull()?.midi ?: defaultMidiData
                                                                    midiData?.let { playStepAudio(step, it, "CLICK THỦ CÔNG") }
                                                                    coroutineScope.launch {
                                                                        delay(300)
                                                                        if (playingPatternId == null && activeStepIndex == globalIndex) {
                                                                            activeStepIndex = -1
                                                                            currentChordText = userSelectedChord ?: ""
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            .padding(vertical = 2.dp)
                                                    ) {
                                                        val baseIconSize = if (patternDef.pattern.size >= 16) 12.dp else 14.dp

                                                        Box(modifier = Modifier.size(14.dp), contentAlignment = Alignment.Center) {
                                                            step.actions.forEach { action ->
                                                                when (action.type) {
                                                                    StrumType.DOWN -> Icon(Icons.Default.ArrowDownward, null, tint = Color(0xFFFF9800).copy(alpha = itemAlpha), modifier = Modifier.size(baseIconSize))
                                                                    StrumType.UP -> Icon(Icons.Default.ArrowUpward, null, tint = Color(0xFF00BCD4).copy(alpha = itemAlpha), modifier = Modifier.size(baseIconSize))
                                                                    StrumType.MUTE -> Icon(Icons.Default.Close, null, tint = Color(0xFFF44336).copy(alpha = itemAlpha), modifier = Modifier.size(baseIconSize))
                                                                    StrumType.REST -> Box(modifier = Modifier.size(3.5.dp).background((if (isPlaying) (if (isDarkModeItem) Color.LightGray else Color.DarkGray) else Color.Gray).copy(alpha = itemAlpha), CircleShape))
                                                                }
                                                            }
                                                        }

                                                        Spacer(modifier = Modifier.height(2.dp))

                                                        if (step.actions.any { it.isAccent }) {
                                                            Box(modifier = Modifier.size(3.dp).background(Color(0xFF00E676).copy(alpha = itemAlpha), CircleShape))
                                                        } else {
                                                            Spacer(modifier = Modifier.size(3.dp))
                                                        }
                                                    }

                                                    if (itemIndex < chunkItems.size - 1) {
                                                        Box(modifier = Modifier.width(1.dp).height(14.dp).background(dialogDividerColor))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (isSelected) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = tunaGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // BOTTOM SHEET TÌM KIẾM VIDEO HƯỚNG DẪN
    if (showRhythmTutorialSheet) {
        TutorialBottomSheet(
            songTitle = "điệu nhạc",
            songSinger = displayRhythm,
            tunaGreen = tunaGreen,
            bgColor = surfaceColor,
            surfaceColor = surfaceColor,
            currentLang = "vi",
            textColor = textColor,
            onDismiss = { showRhythmTutorialSheet = false },
            onVideoClick = { videoId ->
                // Đóng sheet danh sách và gán ID để hiển thị khung video nổi trên đầu
                playingTutorialVideoId = videoId
                showRhythmTutorialSheet = false
            }
        )
    }
}

// 4. COMPONENT TAB GUITAR CHO CHẾ ĐỘ MÓC RẢI
@Composable
fun FingerstyleTabViewer(
    pattern: List<StrumStep>,
    activeStepIndex: Int,
    isPlaying: Boolean = false,
    bassString: Int,
    textColor: Color,
    tunaGreen: Color,
    onStepClick: (Int) -> Unit
) {
    val numStrings = 6
    val rowHeight = 11.5.dp
    val totalHeight = rowHeight * (numStrings + 1)

    // Tự động đổi màu nền và đường kẻ theo giao diện Sáng / Tối
    val tabBgColor = if (textColor == Color.White) Color(0xFF151515) else Color.Gray.copy(alpha = 0.12f)
    val lineStrokeColor = if (textColor == Color.White) Color.Gray.copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.35f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(totalHeight)
            .clip(RoundedCornerShape(6.dp))
            .background(tabBgColor)
    ) {
        Box(
            modifier = Modifier
                .width(16.dp)
                .fillMaxHeight()
                .drawBehind {
                    val spacing = size.height / (numStrings + 1)
                    val textPaint = android.graphics.Paint().apply {
                        color = (if (isPlaying) Color(0xFFA0B4A9) else textColor.copy(alpha = 0.4f)).toArgb()
                        textSize = 7.5.sp.toPx()
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }
                    val textOffset = (textPaint.descent() + textPaint.ascent()) / 2
                    val centerX = size.width / 2

                    for (i in 1..numStrings) {
                        val y = spacing * i
                        drawIntoCanvas { canvas ->
                            canvas.nativeCanvas.drawText(i.toString(), centerX, y - textOffset, textPaint)
                        }
                    }
                }
        )

        Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(lineStrokeColor))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .drawBehind {
                    val spacing = size.height / (numStrings + 1)
                    for (i in 1..numStrings) {
                        val y = spacing * i
                        drawLine(
                            color = lineStrokeColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                }
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                pattern.forEachIndexed { index, step ->
                    val isActive = index == activeStepIndex

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(if (isActive) tunaGreen.copy(alpha = 0.35f) else Color.Transparent)
                            .clickable { onStepClick(index) }
                    ) {
                        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                            val spacing = size.height / (numStrings + 1)
                            val centerX = size.width / 2

                            fun drawTabDot(charStr: String, strNum: Int, dotColor: Color) {
                                val y = spacing * strNum
                                val radius = size.width.coerceAtMost(spacing).times(0.48f).coerceAtMost(6.5.dp.toPx())

                                drawCircle(color = tabBgColor, radius = radius + 1.dp.toPx(), center = Offset(centerX, y))
                                drawCircle(color = dotColor, radius = radius, center = Offset(centerX, y), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))

                                drawIntoCanvas { canvas ->
                                    val textPaint = android.graphics.Paint().apply {
                                        color = dotColor.toArgb()
                                        textSize = radius * 1.3f
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                                    }
                                    val textY = y - ((textPaint.descent() + textPaint.ascent()) / 2)
                                    canvas.nativeCanvas.drawText(charStr, centerX, textY, textPaint)
                                }
                            }

                            step.actions.forEach { action ->
                                val notes = action.arpeggioNote
                                if (notes.isNotEmpty()) {
                                    if (notes.contains("B")) drawTabDot("p", bassString, Color(0xFF9C27B0))
                                    if (notes.contains("4")) drawTabDot("i", 4, Color(0xFFFF9800))
                                    if (notes.contains("3")) drawTabDot("i", 3, Color(0xFF2196F3))
                                    if (notes.contains("2")) drawTabDot("m", 2, Color(0xFF4CAF50))
                                    if (notes.contains("1")) drawTabDot("a", 1, Color(0xFFF44336))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
// ===================================================================
// THANH HIỂN THỊ 1 TIẾT TẤU DUY NHẤT DƯỚI THANH CÔNG CỤ
// ===================================================================
@Composable
fun SingleStrummingPatternBar(
    songId: String = "",
    rhythmName: String,
    bpm: Float,
    songChords: List<String>,
    guitarChordsList: List<ChordModel>,
    surfaceColor: Color,
    tunaGreen: Color,
    textColor: Color,
    onHide: () -> Unit = {},
    onOpenFullDialog: () -> Unit
) {
    val context = LocalContext.current
    val pref = remember { context.getSharedPreferences("SongPatternPref", Context.MODE_PRIVATE) }

    // Khởi tạo và nạp sẵn âm thanh Guitar ngay khi thanh tiết tấu hiển thị
    LaunchedEffect(Unit) {
        CoreAudioPlayer.init()
        CoreAudioPlayer.loadInstrument(context, "Guitar")
    }

    val isArpeggio = remember(songId) { pref.getBoolean("is_arp_$songId", true) }
    val savedPatternId = remember(songId) { pref.getString("pattern_id_$songId", null) }

    val categories = remember(rhythmName, isArpeggio) { getGroupedStrummingPatterns(rhythmName, isArpeggio) }
    val allPatterns = remember(categories) { categories.flatMap { it.patterns } }

    val targetIndex = remember(allPatterns, savedPatternId) {
        if (savedPatternId != null) {
            val idx = allPatterns.indexOfFirst { it.id == savedPatternId }
            if (idx >= 0) idx else 0
        } else 0
    }
    val currentPatternDef = remember(allPatterns, targetIndex) { allPatterns.getOrNull(targetIndex) }

    if (currentPatternDef == null) return

    val pattern = currentPatternDef.pattern
    var isPlaying by remember { mutableStateOf(false) }
    var activeStepIndex by remember { mutableIntStateOf(-1) }
    val coroutineScope = rememberCoroutineScope()

    val defaultChord = remember(songChords) { songChords.firstOrNull() ?: "C" }
    val midiData = remember(defaultChord, guitarChordsList) {
        guitarChordsList.find { chord ->
            val suffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
            "${chord.key}$suffix".equals(defaultChord, ignoreCase = true)
        }?.positions?.firstOrNull()?.midi
    }

    val dynamicBassString = remember(defaultChord, guitarChordsList) {
        val exactMatch = guitarChordsList.find { chord ->
            val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
            "${chord.key}$displaySuffix".equals(defaultChord, ignoreCase = true)
        }
        val position = exactMatch?.positions?.firstOrNull()
        var bassStr = 5
        if (position != null && position.frets.size == 6) {
            val bassIndex = position.frets.indexOfFirst { it != -1 }
            if (bassIndex in 0..5) bassStr = 6 - bassIndex
        }
        bassStr
    }

    LaunchedEffect(isPlaying, isArpeggio) {
        if (isPlaying) {
            val safeBpm = if (bpm > 0) bpm else 74f
            val isSlowRock = rhythmName.lowercase().contains("slow")
            val delayMs = when (pattern.size) {
                16 -> (60000f / safeBpm / 4f).toLong()
                8 -> (60000f / safeBpm / 2f).toLong()
                6 -> if (isSlowRock) (60000f / safeBpm / 3f).toLong() else (60000f / safeBpm / 2f).toLong()
                else -> (60000f / safeBpm / 2f).toLong()
            }.coerceAtLeast(40L)

            while (isPlaying) {
                for (i in pattern.indices) {
                    if (!isPlaying) break
                    activeStepIndex = i
                    val step = pattern[i]

                    midiData?.let { notes ->
                        coroutineScope.launch(Dispatchers.Default) {
                            step.actions.forEach { action ->
                                if (isArpeggio && action.arpeggioNote.isNotEmpty()) {
                                    val playNotes = mutableListOf<Int>()
                                    val noteStr = action.arpeggioNote
                                    if (noteStr.contains("B")) {
                                        val bassIndex = 6 - dynamicBassString
                                        val bassNote = if (bassIndex in notes.indices) notes[bassIndex] else notes.firstOrNull()
                                        bassNote?.let { playNotes.add(it) }
                                    }
                                    if (noteStr.contains("4")) notes.getOrNull(notes.size - 4)?.let { playNotes.add(it) }
                                    if (noteStr.contains("3")) (notes.getOrNull(notes.size - 3) ?: notes.lastOrNull())?.let { playNotes.add(it) }
                                    if (noteStr.contains("2")) (notes.getOrNull(notes.size - 2) ?: notes.lastOrNull())?.let { playNotes.add(it) }
                                    if (noteStr.contains("1")) notes.lastOrNull()?.let { playNotes.add(it) }

                                    if (playNotes.isNotEmpty()) {
                                        val vol = if (action.isAccent) 1.0f else 0.8f
                                        CoreAudioPlayer.playSimultaneousNotes(playNotes.map { Pair(it, vol) }, "Guitar")
                                    }
                                } else if (!isArpeggio) {
                                    if (action.type == StrumType.DOWN || action.type == StrumType.UP) {
                                        val isUp = action.type == StrumType.UP
                                        val strumNotes = if (isUp) notes.takeLast(4).reversed() else notes
                                        CoreAudioPlayer.stopPreviousStrum()
                                        launch {
                                            strumNotes.forEachIndexed { index, note ->
                                                val baseVol = if (action.isAccent) 1.0f else 0.75f
                                                CoreAudioPlayer.playSimultaneousNotes(listOf(Pair(note, baseVol)), "Guitar")
                                                delay(18)
                                            }
                                        }
                                    } else if (action.type == StrumType.MUTE) {
                                        CoreAudioPlayer.stopPreviousStrum()
                                    }
                                }
                            }
                        }
                    }
                    delay(delayMs)
                }
            }
        } else {
            activeStepIndex = -1
            CoreAudioPlayer.stopPreviousStrum()
        }
    }

    val playSingleStepAudio: (StrumStep, List<Int>) -> Unit = { step, notes ->
        coroutineScope.launch(Dispatchers.Default) {
            step.actions.forEach { action ->
                if (isArpeggio && action.arpeggioNote.isNotEmpty()) {
                    val playNotes = mutableListOf<Int>()
                    val noteStr = action.arpeggioNote
                    if (noteStr.contains("B")) {
                        val bassIndex = 6 - dynamicBassString
                        val bassNote = if (bassIndex in notes.indices) notes[bassIndex] else notes.firstOrNull()
                        bassNote?.let { playNotes.add(it) }
                    }
                    if (noteStr.contains("4")) notes.getOrNull(notes.size - 4)?.let { playNotes.add(it) }
                    if (noteStr.contains("3")) (notes.getOrNull(notes.size - 3) ?: notes.lastOrNull())?.let { playNotes.add(it) }
                    if (noteStr.contains("2")) (notes.getOrNull(notes.size - 2) ?: notes.lastOrNull())?.let { playNotes.add(it) }
                    if (noteStr.contains("1")) notes.lastOrNull()?.let { playNotes.add(it) }

                    if (playNotes.isNotEmpty()) {
                        val vol = if (action.isAccent) 1.0f else 0.8f
                        CoreAudioPlayer.playSimultaneousNotes(playNotes.map { Pair(it, vol) }, "Guitar")
                    }
                } else if (!isArpeggio) {
                    if (action.type == StrumType.DOWN || action.type == StrumType.UP) {
                        val isUp = action.type == StrumType.UP
                        val strumNotes = if (isUp) notes.takeLast(4).reversed() else notes
                        CoreAudioPlayer.stopPreviousStrum()
                        launch {
                            strumNotes.forEachIndexed { index, note ->
                                val baseVol = if (action.isAccent) 1.0f else 0.75f
                                CoreAudioPlayer.playSimultaneousNotes(listOf(Pair(note, baseVol)), "Guitar")
                                delay(18)
                            }
                        }
                    } else if (action.type == StrumType.MUTE) {
                        CoreAudioPlayer.stopPreviousStrum()
                    }
                }
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "${targetIndex + 1}.",
            color = if (isPlaying) tunaGreen else textColor.copy(alpha = 0.5f),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .clickable { onOpenFullDialog() }
                .padding(end = 6.dp)
        )

        val isDarkMode = textColor == Color.White
        val playBtnBg = if (isPlaying) tunaGreen else (if (isDarkMode) Color(0xFF282828) else Color.Gray.copy(alpha = 0.2f))
        val playBtnIconColor = if (isPlaying) Color.White else textColor
        val chunkBgColor = if (isDarkMode) Color(0xFF141414) else Color.Gray.copy(alpha = 0.12f)
        val dividerColor = if (isDarkMode) Color(0xFF262626) else Color.Gray.copy(alpha = 0.25f)

        Box(
            modifier = Modifier
                .size(28.dp)
                .background(playBtnBg, CircleShape)
                .clickable { isPlaying = !isPlaying },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = playBtnIconColor,
                modifier = Modifier.size(15.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isArpeggio) {
            Box(modifier = Modifier.weight(1f)) {
                FingerstyleTabViewer(
                    pattern = pattern,
                    activeStepIndex = activeStepIndex,
                    isPlaying = isPlaying,
                    bassString = dynamicBassString,
                    textColor = textColor,
                    tunaGreen = tunaGreen,
                    onStepClick = { stepIdx ->
                        if (!isPlaying) {
                            activeStepIndex = stepIdx
                            midiData?.let { playSingleStepAudio(pattern[stepIdx], it) }
                            coroutineScope.launch {
                                delay(300)
                                if (!isPlaying && activeStepIndex == stepIdx) {
                                    activeStepIndex = -1
                                }
                            }
                        }
                    }
                )
            }
        } else {
            val chunkSize = when (pattern.size) { 16 -> 4; 8 -> 2; 6 -> 2; else -> 4 }
            val chunks = pattern.chunked(chunkSize)

            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                chunks.forEachIndexed { chunkIdx, chunkItems ->
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(chunkBgColor)
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        chunkItems.forEachIndexed { itemIdx, step ->
                            val globalIndex = chunkIdx * chunkSize + itemIdx
                            val isActive = globalIndex == activeStepIndex
                            val stepBg = when {
                                isActive && isPlaying -> tunaGreen.copy(alpha = 0.5f)
                                isActive && !isPlaying -> tunaGreen.copy(alpha = 0.3f)
                                else -> Color.Transparent
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(26.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(stepBg)
                                    .clickable {
                                        if (!isPlaying) {
                                            activeStepIndex = globalIndex
                                            midiData?.let { playSingleStepAudio(step, it) }
                                            coroutineScope.launch {
                                                delay(300)
                                                if (!isPlaying && activeStepIndex == globalIndex) {
                                                    activeStepIndex = -1
                                                }
                                            }
                                        }
                                    }
                            ) {
                                val baseIconSize = if (pattern.size >= 16) 11.dp else 13.dp
                                Box(modifier = Modifier.size(13.dp), contentAlignment = Alignment.Center) {
                                    step.actions.forEach { action ->
                                        when (action.type) {
                                            StrumType.DOWN -> Icon(Icons.Default.ArrowDownward, null, tint = Color(0xFFFF9800), modifier = Modifier.size(baseIconSize))
                                            StrumType.UP -> Icon(Icons.Default.ArrowUpward, null, tint = Color(0xFF00BCD4), modifier = Modifier.size(baseIconSize))
                                            StrumType.MUTE -> Icon(Icons.Default.Close, null, tint = Color(0xFFF44336), modifier = Modifier.size(baseIconSize))
                                            StrumType.REST -> Box(modifier = Modifier.size(3.dp).background(Color.Gray, CircleShape))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                if (step.actions.any { it.isAccent }) {
                                    Box(modifier = Modifier.size(3.dp).background(Color(0xFF00E676), CircleShape))
                                } else {
                                    Spacer(modifier = Modifier.size(3.dp))
                                }
                            }

                            if (itemIdx < chunkItems.size - 1) {
                                Box(modifier = Modifier.width(1.dp).height(12.dp).background(dividerColor))
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(6.dp))

        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color.Gray.copy(alpha = 0.15f))
                .clickable { onHide() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Remove,
                contentDescription = "Ẩn tiết tấu",
                tint = textColor.copy(alpha = 0.7f),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}