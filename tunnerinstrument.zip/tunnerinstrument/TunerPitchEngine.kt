package ducphi.tunnerinstrument

object TunerPitchEngine {
    init {
        System.loadLibrary("pitch_engine")
    }

    // Hàm nhận mảng âm thanh từ Micro và ném xuống C++ xử lý
    external fun processAudioData(audioData: FloatArray, sampleRate: Int): Float
}