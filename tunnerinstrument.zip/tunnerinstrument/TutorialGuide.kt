package ducphi.tunnerinstrument

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

enum class TutorialStep { NONE, SEARCH, DISPLAY_TOOLS, ADD, EDIT }

@Composable
fun GuideMenuDialog(
    currentLang: String,
    bgColor: Color,
    textColor: Color,
    tunaGreen: Color,
    onDismiss: () -> Unit,
    onSelectTutorial: (TutorialStep) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = bgColor,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = CoreTranslator.getString("tut_user_guide", currentLang),
                    color = tunaGreen,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = CoreTranslator.getString("tut_sheet_music", currentLang),
                    color = textColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                val guides = listOf(
                    Pair(CoreTranslator.getString("tut_search_tools", currentLang), TutorialStep.SEARCH),
                    Pair(CoreTranslator.getString("tut_display_tools", currentLang), TutorialStep.DISPLAY_TOOLS),
                    Pair(CoreTranslator.getString("tut_add_song", currentLang), TutorialStep.ADD),
                    Pair(CoreTranslator.getString("tut_edit_song", currentLang), TutorialStep.EDIT)
                )

                guides.forEach { (title, step) ->
                    Text(
                        text = title,
                        color = textColor,
                        fontSize = 16.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectTutorial(step) }
                            .padding(vertical = 12.dp, horizontal = 16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text(CoreTranslator.getString("close", currentLang), color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun TutorialOverlay(
    step: TutorialStep,
    currentLang: String,
    tunaGreen: Color,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.7f))
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .fillMaxHeight(0.85f)
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // --- TIÊU ĐỀ CHÍNH ---
            Text(
                text = when (step) {
                    TutorialStep.SEARCH -> CoreTranslator.getString("tut_search_tools", currentLang)
                    TutorialStep.DISPLAY_TOOLS -> CoreTranslator.getString("tut_display_tools_short", currentLang)
                    TutorialStep.ADD -> CoreTranslator.getString("tut_add_new_song", currentLang)
                    TutorialStep.EDIT -> CoreTranslator.getString("tut_edit_song_short", currentLang)
                    else -> ""
                },
                color = tunaGreen, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(16.dp))

            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
            ) {
                when (step) {
                    TutorialStep.SEARCH -> {
                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp)).padding(8.dp)) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_search_box", currentLang),
                            desc = CoreTranslator.getString("tut_search_box_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = { Icon(Icons.Default.Mic, contentDescription = null, tint = tunaGreen, modifier = Modifier.size(24.dp).padding(top = 4.dp)) },
                            title = CoreTranslator.getString("tut_voice", currentLang),
                            desc = CoreTranslator.getString("tut_voice_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.border(1.dp, tunaGreen, RoundedCornerShape(4.dp)).padding(6.dp)) {
                                    Icon(CustomIcons.Chord, contentDescription = null, tint = tunaGreen, modifier = Modifier.size(16.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_chords", currentLang),
                            desc = CoreTranslator.getString("tut_chords_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.border(1.dp, Color(0xFFE6A23C), RoundedCornerShape(4.dp)).padding(6.dp)) {
                                    SheetMusicIcon(tint = Color(0xFFE6A23C), modifier = Modifier.size(16.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_sheet", currentLang),
                            desc = CoreTranslator.getString("tut_sheet_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = { ZingMp3Icon(modifier = Modifier.size(28.dp)) },
                            title = CoreTranslator.getString("tut_zing", currentLang),
                            desc = CoreTranslator.getString("tut_zing_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.size(width = 28.dp, height = 20.dp).background(Color.Red, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_youtube", currentLang),
                            desc = CoreTranslator.getString("tut_youtube_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = { Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.Red, modifier = Modifier.size(26.dp)) },
                            title = CoreTranslator.getString("tut_favorite", currentLang),
                            desc = CoreTranslator.getString("tut_favorite_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = { Icon(Icons.Default.Flag, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(26.dp)) },
                            title = CoreTranslator.getString("tut_report", currentLang),
                            desc = CoreTranslator.getString("tut_report_desc", currentLang)
                        )
                    }

                    TutorialStep.DISPLAY_TOOLS -> {
                        TutorialItemRow(
                            iconView = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(22.dp).background(Color(0xFFF5F5F5), RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                                        Text("♭", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(modifier = Modifier.size(22.dp).background(Color(0xFFF5F5F5), RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                                        Text("♯", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    }
                                }
                            },
                            title = CoreTranslator.getString("tut_transpose", currentLang),
                            desc = CoreTranslator.getString("tut_transpose_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Remove, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(modifier = Modifier.size(22.dp).background(tunaGreen, CircleShape), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.KeyboardDoubleArrowDown, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_autoscroll", currentLang),
                            desc = CoreTranslator.getString("tut_autoscroll_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.size(24.dp).background(tunaGreen, CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Palette, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_palette", currentLang),
                            desc = CoreTranslator.getString("tut_palette_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.size(24.dp).background(tunaGreen, CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_split", currentLang),
                            desc = CoreTranslator.getString("tut_split_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.size(24.dp).border(1.dp, tunaGreen, CircleShape), contentAlignment = Alignment.Center) {
                                    Text("IV", color = tunaGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            title = CoreTranslator.getString("tut_roman", currentLang),
                            desc = CoreTranslator.getString("tut_roman_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("A", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("A", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                            },
                            title = CoreTranslator.getString("tut_fontsize", currentLang),
                            desc = CoreTranslator.getString("tut_fontsize_desc", currentLang)
                        )

                        TutorialItemRow(
                            iconView = {
                                Icon(Icons.Default.Translate, contentDescription = null, tint = tunaGreen, modifier = Modifier.size(22.dp))
                            },
                            title = CoreTranslator.getString("tut_trans", currentLang),
                            desc = CoreTranslator.getString("tut_trans_desc", currentLang)
                        )
                    }

                    TutorialStep.ADD -> {
                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.background(Color(0xFF1976D2), RoundedCornerShape(6.dp)).padding(8.dp)) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_add_btn", currentLang),
                            desc = CoreTranslator.getString("tut_add_btn_desc", currentLang)
                        )
                    }

                    TutorialStep.EDIT -> {
                        TutorialItemRow(
                            iconView = {
                                Box(modifier = Modifier.background(Color(0xFFE6A23C), RoundedCornerShape(6.dp)).padding(8.dp)) {
                                    Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                }
                            },
                            title = CoreTranslator.getString("tut_edit_btn", currentLang),
                            desc = CoreTranslator.getString("tut_edit_btn_desc", currentLang)
                        )
                    }
                    else -> {}
                }
            }

            // --- NÚT ĐÓNG ---
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                modifier = Modifier.fillMaxWidth(0.7f).height(48.dp)
            ) {
                Text(CoreTranslator.getString("tut_got_it", currentLang), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun TutorialItemRow(iconView: @Composable () -> Unit, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier.width(48.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            iconView()
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = title, color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = desc, color = Color.DarkGray, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}