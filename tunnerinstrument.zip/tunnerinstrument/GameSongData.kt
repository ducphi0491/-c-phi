package ducphi.tunnerinstrument

// ================= CẤU TRÚC DỮ LIỆU CÓ TRƯỜNG ĐỘ =================
data class PracticeTarget(
    val midis: List<Int>,
    val durationBeats: Float = 1f, // 1f = 1 nhịp (Nốt đen), 0.5f = Móc đơn, 2f = Nốt trắng...
    val lyric: String = ""
)

data class PracticeSong(
    val name: String,
    val recommendedBpm: Float,
    val sequence: List<PracticeTarget>,
    val timeSig: Int = 4 // Đặt mặc định là 4 (cho nhịp 4/4)
)

val builtInSongs = listOf(
    // ================= NHẠC VIỆT NAM =================
    PracticeSong(
        name = "Kìa Con Bướm Vàng",
        recommendedBpm = 100f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(60), 1f, "Kìa"), PracticeTarget(listOf(62), 1f, "con"), PracticeTarget(listOf(64), 1f, "bướm"), PracticeTarget(listOf(60), 1f, "vàng"),
            PracticeTarget(listOf(60), 1f, "Kìa"), PracticeTarget(listOf(62), 1f, "con"), PracticeTarget(listOf(64), 1f, "bướm"), PracticeTarget(listOf(60), 1f, "vàng"),
            PracticeTarget(listOf(64), 1f, "Xòe"), PracticeTarget(listOf(65), 1f, "đôi"), PracticeTarget(listOf(67), 2f, "cánh"),
            PracticeTarget(listOf(64), 1f, "Xòe"), PracticeTarget(listOf(65), 1f, "đôi"), PracticeTarget(listOf(67), 2f, "cánh"),
            PracticeTarget(listOf(67), 0.5f, "Tung"), PracticeTarget(listOf(69), 0.5f, "cánh"), PracticeTarget(listOf(67), 0.5f, "bay"), PracticeTarget(listOf(65), 0.5f, "năm"), PracticeTarget(listOf(64), 1f, "ba"), PracticeTarget(listOf(60), 1f, "vòng"),
            PracticeTarget(listOf(67), 0.5f, "Tung"), PracticeTarget(listOf(69), 0.5f, "cánh"), PracticeTarget(listOf(67), 0.5f, "bay"), PracticeTarget(listOf(65), 0.5f, "năm"), PracticeTarget(listOf(64), 1f, "ba"), PracticeTarget(listOf(60), 1f, "vòng"),
            PracticeTarget(listOf(60), 1f, "Em"), PracticeTarget(listOf(55), 1f, "ngồi"), PracticeTarget(listOf(60), 2f, "xem"),
            PracticeTarget(listOf(60), 1f, "Em"), PracticeTarget(listOf(55), 1f, "ngồi"), PracticeTarget(listOf(60), 2f, "xem")
        )
    ),

    // ================= NHẠC QUỐC TẾ (10 BÀI CHUẨN) =================

    // 1. Happy Birthday (Tone C)
    PracticeSong(
        name = "Happy Birthday",
        recommendedBpm = 90f,
        timeSig = 3, // Nhịp 3/4 (Valse)
        sequence = listOf(
            PracticeTarget(listOf(55), 0.5f, "Hap"), PracticeTarget(listOf(55), 0.5f, "py"), PracticeTarget(listOf(57), 1f, "Birth"), PracticeTarget(listOf(55), 1f, "day"), PracticeTarget(listOf(60), 1f, "to"), PracticeTarget(listOf(59), 2f, "you"),
            PracticeTarget(listOf(55), 0.5f, "Hap"), PracticeTarget(listOf(55), 0.5f, "py"), PracticeTarget(listOf(57), 1f, "Birth"), PracticeTarget(listOf(55), 1f, "day"), PracticeTarget(listOf(62), 1f, "to"), PracticeTarget(listOf(60), 2f, "you"),
            PracticeTarget(listOf(55), 0.5f, "Hap"), PracticeTarget(listOf(55), 0.5f, "py"), PracticeTarget(listOf(67), 1f, "Birth"), PracticeTarget(listOf(64), 1f, "day"), PracticeTarget(listOf(60), 1f, "dear"), PracticeTarget(listOf(59), 1f, "Name"), PracticeTarget(listOf(57), 1f, ""),
            PracticeTarget(listOf(65), 0.5f, "Hap"), PracticeTarget(listOf(65), 0.5f, "py"), PracticeTarget(listOf(64), 1f, "Birth"), PracticeTarget(listOf(60), 1f, "day"), PracticeTarget(listOf(62), 1f, "to"), PracticeTarget(listOf(60), 2f, "you")
        )
    ),

    // 2. Twinkle Twinkle Little Star (Tone C)
    PracticeSong(
        name = "Twinkle Twinkle Little Star",
        recommendedBpm = 80f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(60), 1f, "Twin"), PracticeTarget(listOf(60), 1f, "kle"), PracticeTarget(listOf(67), 1f, "twin"), PracticeTarget(listOf(67), 1f, "kle"), PracticeTarget(listOf(69), 1f, "lit"), PracticeTarget(listOf(69), 1f, "tle"), PracticeTarget(listOf(67), 2f, "star"),
            PracticeTarget(listOf(65), 1f, "How"), PracticeTarget(listOf(65), 1f, "I"), PracticeTarget(listOf(64), 1f, "won"), PracticeTarget(listOf(64), 1f, "der"), PracticeTarget(listOf(62), 1f, "what"), PracticeTarget(listOf(62), 1f, "you"), PracticeTarget(listOf(60), 2f, "are"),
            PracticeTarget(listOf(67), 1f, "Up"), PracticeTarget(listOf(67), 1f, "a"), PracticeTarget(listOf(65), 1f, "bove"), PracticeTarget(listOf(65), 1f, "the"), PracticeTarget(listOf(64), 1f, "world"), PracticeTarget(listOf(64), 1f, "so"), PracticeTarget(listOf(62), 2f, "high"),
            PracticeTarget(listOf(67), 1f, "Like"), PracticeTarget(listOf(67), 1f, "a"), PracticeTarget(listOf(65), 1f, "dia"), PracticeTarget(listOf(65), 1f, "mond"), PracticeTarget(listOf(64), 1f, "in"), PracticeTarget(listOf(64), 1f, "the"), PracticeTarget(listOf(62), 2f, "sky"),
            PracticeTarget(listOf(60), 1f, "Twin"), PracticeTarget(listOf(60), 1f, "kle"), PracticeTarget(listOf(67), 1f, "twin"), PracticeTarget(listOf(67), 1f, "kle"), PracticeTarget(listOf(69), 1f, "lit"), PracticeTarget(listOf(69), 1f, "tle"), PracticeTarget(listOf(67), 2f, "star")
        )
    ),

    // 3. Ode to Joy - Beethoven (Tone C)
    PracticeSong(
        name = "Ode to Joy",
        recommendedBpm = 100f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(64), 1f, "Joy"), PracticeTarget(listOf(64), 1f, "ful"), PracticeTarget(listOf(65), 1f, "joy"), PracticeTarget(listOf(67), 1f, "ful"), PracticeTarget(listOf(67), 1f, "we"), PracticeTarget(listOf(65), 1f, "a"), PracticeTarget(listOf(64), 1f, "dore"), PracticeTarget(listOf(62), 1f, "Thee"),
            PracticeTarget(listOf(60), 1f, "God"), PracticeTarget(listOf(60), 1f, "of"), PracticeTarget(listOf(62), 1f, "glo"), PracticeTarget(listOf(64), 1f, "ry"), PracticeTarget(listOf(64), 1.5f, "Lord"), PracticeTarget(listOf(62), 0.5f, "of"), PracticeTarget(listOf(62), 2f, "love"),
            PracticeTarget(listOf(64), 1f, "Hearts"), PracticeTarget(listOf(64), 1f, "un"), PracticeTarget(listOf(65), 1f, "fold"), PracticeTarget(listOf(67), 1f, "like"), PracticeTarget(listOf(67), 1f, "flow'rs"), PracticeTarget(listOf(65), 1f, "be"), PracticeTarget(listOf(64), 1f, "fore"), PracticeTarget(listOf(62), 1f, "Thee"),
            PracticeTarget(listOf(60), 1f, "O"), PracticeTarget(listOf(60), 1f, "p'ning"), PracticeTarget(listOf(62), 1f, "to"), PracticeTarget(listOf(64), 1f, "the"), PracticeTarget(listOf(62), 1.5f, "sun"), PracticeTarget(listOf(60), 0.5f, "a"), PracticeTarget(listOf(60), 2f, "bove")
        )
    ),

    // 4. Jingle Bells - Chorus (Tone C)
    PracticeSong(
        name = "Jingle Bells",
        recommendedBpm = 110f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(64), 1f, "Jin"), PracticeTarget(listOf(64), 1f, "gle"), PracticeTarget(listOf(64), 2f, "bells"),
            PracticeTarget(listOf(64), 1f, "Jin"), PracticeTarget(listOf(64), 1f, "gle"), PracticeTarget(listOf(64), 2f, "bells"),
            PracticeTarget(listOf(64), 1f, "Jin"), PracticeTarget(listOf(67), 1f, "gle"), PracticeTarget(listOf(60), 1.5f, "all"), PracticeTarget(listOf(62), 0.5f, "the"), PracticeTarget(listOf(64), 2f, "way"),
            PracticeTarget(listOf(65), 1f, "Oh"), PracticeTarget(listOf(65), 1f, "what"), PracticeTarget(listOf(65), 1.5f, "fun"), PracticeTarget(listOf(65), 0.5f, "it"), PracticeTarget(listOf(65), 1f, "is"), PracticeTarget(listOf(64), 1f, "to"), PracticeTarget(listOf(64), 1f, "ride"), PracticeTarget(listOf(64), 0.5f, "in"), PracticeTarget(listOf(64), 0.5f, "a"),
            PracticeTarget(listOf(64), 1f, "one"), PracticeTarget(listOf(62), 1f, "horse"), PracticeTarget(listOf(62), 1f, "o"), PracticeTarget(listOf(64), 1f, "pen"), PracticeTarget(listOf(62), 2f, "sleigh"), PracticeTarget(listOf(67), 2f, "hey!")
        )
    ),

    // 5. Mary Had a Little Lamb (Tone C)
    PracticeSong(
        name = "Mary Had a Little Lamb",
        recommendedBpm = 90f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(64), 1f, "Ma"), PracticeTarget(listOf(62), 1f, "ry"), PracticeTarget(listOf(60), 1f, "had"), PracticeTarget(listOf(62), 1f, "a"), PracticeTarget(listOf(64), 1f, "lit"), PracticeTarget(listOf(64), 1f, "tle"), PracticeTarget(listOf(64), 2f, "lamb"),
            PracticeTarget(listOf(62), 1f, "Lit"), PracticeTarget(listOf(62), 1f, "tle"), PracticeTarget(listOf(62), 2f, "lamb"), PracticeTarget(listOf(64), 1f, "lit"), PracticeTarget(listOf(67), 1f, "tle"), PracticeTarget(listOf(67), 2f, "lamb"),
            PracticeTarget(listOf(64), 1f, "Ma"), PracticeTarget(listOf(62), 1f, "ry"), PracticeTarget(listOf(60), 1f, "had"), PracticeTarget(listOf(62), 1f, "a"), PracticeTarget(listOf(64), 1f, "lit"), PracticeTarget(listOf(64), 1f, "tle"), PracticeTarget(listOf(64), 1f, "lamb"), PracticeTarget(listOf(64), 1f, "its"),
            PracticeTarget(listOf(62), 1f, "fleece"), PracticeTarget(listOf(62), 1f, "was"), PracticeTarget(listOf(64), 1f, "white"), PracticeTarget(listOf(62), 1f, "as"), PracticeTarget(listOf(60), 2f, "snow")
        )
    ),

    // 6. Frère Jacques (Tone C)
    PracticeSong(
        name = "Frère Jacques",
        recommendedBpm = 100f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(60), 1f, "Frè"), PracticeTarget(listOf(62), 1f, "re"), PracticeTarget(listOf(64), 1f, "Jac"), PracticeTarget(listOf(60), 1f, "ques"),
            PracticeTarget(listOf(60), 1f, "Frè"), PracticeTarget(listOf(62), 1f, "re"), PracticeTarget(listOf(64), 1f, "Jac"), PracticeTarget(listOf(60), 1f, "ques"),
            PracticeTarget(listOf(64), 1f, "Dor"), PracticeTarget(listOf(65), 1f, "mez"), PracticeTarget(listOf(67), 2f, "vous?"),
            PracticeTarget(listOf(64), 1f, "Dor"), PracticeTarget(listOf(65), 1f, "mez"), PracticeTarget(listOf(67), 2f, "vous?"),
            PracticeTarget(listOf(67), 0.5f, "Son"), PracticeTarget(listOf(69), 0.5f, "nez"), PracticeTarget(listOf(67), 0.5f, "les"), PracticeTarget(listOf(65), 0.5f, "ma"), PracticeTarget(listOf(64), 1f, "ti"), PracticeTarget(listOf(60), 1f, "nes"),
            PracticeTarget(listOf(67), 0.5f, "Son"), PracticeTarget(listOf(69), 0.5f, "nez"), PracticeTarget(listOf(67), 0.5f, "les"), PracticeTarget(listOf(65), 0.5f, "ma"), PracticeTarget(listOf(64), 1f, "ti"), PracticeTarget(listOf(60), 1f, "nes"),
            PracticeTarget(listOf(60), 1f, "Ding"), PracticeTarget(listOf(55), 1f, "dang"), PracticeTarget(listOf(60), 2f, "dong"),
            PracticeTarget(listOf(60), 1f, "Ding"), PracticeTarget(listOf(55), 1f, "dang"), PracticeTarget(listOf(60), 2f, "dong")
        )
    ),

    // 7. London Bridge is Falling Down (Tone C)
    PracticeSong(
        name = "London Bridge is Falling Down",
        recommendedBpm = 105f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(67), 1.5f, "Lon"), PracticeTarget(listOf(69), 0.5f, "don"), PracticeTarget(listOf(67), 1f, "bridge"), PracticeTarget(listOf(65), 1f, "is"), PracticeTarget(listOf(64), 1f, "fal"), PracticeTarget(listOf(65), 1f, "ling"), PracticeTarget(listOf(67), 2f, "down"),
            PracticeTarget(listOf(62), 1f, "Fal"), PracticeTarget(listOf(64), 1f, "ling"), PracticeTarget(listOf(65), 2f, "down"), PracticeTarget(listOf(64), 1f, "Fal"), PracticeTarget(listOf(65), 1f, "ling"), PracticeTarget(listOf(67), 2f, "down"),
            PracticeTarget(listOf(67), 1.5f, "Lon"), PracticeTarget(listOf(69), 0.5f, "don"), PracticeTarget(listOf(67), 1f, "bridge"), PracticeTarget(listOf(65), 1f, "is"), PracticeTarget(listOf(64), 1f, "fal"), PracticeTarget(listOf(65), 1f, "ling"), PracticeTarget(listOf(67), 2f, "down"),
            PracticeTarget(listOf(62), 2f, "My"), PracticeTarget(listOf(67), 2f, "fair"), PracticeTarget(listOf(64), 1f, "la"), PracticeTarget(listOf(60), 2f, "dy")
        )
    ),

    // 8. Baa Baa Black Sheep (Tone C)
    PracticeSong(
        name = "Baa Baa Black Sheep",
        recommendedBpm = 95f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(60), 1f, "Baa"), PracticeTarget(listOf(60), 1f, "baa"), PracticeTarget(listOf(67), 1f, "black"), PracticeTarget(listOf(67), 1f, "sheep"),
            PracticeTarget(listOf(69), 0.5f, "Have"), PracticeTarget(listOf(69), 0.5f, "you"), PracticeTarget(listOf(69), 0.5f, "a"), PracticeTarget(listOf(69), 0.5f, "ny"), PracticeTarget(listOf(67), 2f, "wool?"),
            PracticeTarget(listOf(65), 1f, "Yes"), PracticeTarget(listOf(65), 1f, "sir"), PracticeTarget(listOf(64), 1f, "yes"), PracticeTarget(listOf(64), 1f, "sir"),
            PracticeTarget(listOf(62), 1f, "Three"), PracticeTarget(listOf(62), 1f, "bags"), PracticeTarget(listOf(60), 2f, "full")
        )
    ),

    // 9. Old MacDonald Had a Farm (Tone C)
    PracticeSong(
        name = "Old MacDonald Had a Farm",
        recommendedBpm = 110f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(60), 1f, "Old"), PracticeTarget(listOf(60), 1f, "Mac"), PracticeTarget(listOf(60), 1f, "Don"), PracticeTarget(listOf(55), 1f, "ald"), PracticeTarget(listOf(57), 1f, "had"), PracticeTarget(listOf(57), 1f, "a"), PracticeTarget(listOf(55), 2f, "farm"),
            PracticeTarget(listOf(64), 1f, "E"), PracticeTarget(listOf(64), 1f, "I"), PracticeTarget(listOf(62), 1f, "E"), PracticeTarget(listOf(62), 1f, "I"), PracticeTarget(listOf(60), 2f, "O"),
            PracticeTarget(listOf(55), 1f, "And"), PracticeTarget(listOf(60), 1f, "on"), PracticeTarget(listOf(60), 1f, "that"), PracticeTarget(listOf(60), 1f, "farm"), PracticeTarget(listOf(55), 1f, "he"), PracticeTarget(listOf(57), 1f, "had"), PracticeTarget(listOf(57), 1f, "a"), PracticeTarget(listOf(55), 2f, "cow"),
            PracticeTarget(listOf(64), 1f, "E"), PracticeTarget(listOf(64), 1f, "I"), PracticeTarget(listOf(62), 1f, "E"), PracticeTarget(listOf(62), 1f, "I"), PracticeTarget(listOf(60), 2f, "O")
        )
    ),

    // 10. Baby Shark (Tone C)
    PracticeSong(
        name = "Baby Shark",
        recommendedBpm = 115f,
        timeSig = 4, // Nhịp 4/4
        sequence = listOf(
            PracticeTarget(listOf(62), 1f, "Ba"), PracticeTarget(listOf(64), 1f, "by"), PracticeTarget(listOf(67), 0.5f, "shark"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"),
            PracticeTarget(listOf(62), 1f, "Ba"), PracticeTarget(listOf(64), 1f, "by"), PracticeTarget(listOf(67), 0.5f, "shark"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"),
            PracticeTarget(listOf(62), 1f, "Ba"), PracticeTarget(listOf(64), 1f, "by"), PracticeTarget(listOf(67), 0.5f, "shark"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"), PracticeTarget(listOf(67), 0.5f, "doo"),
            PracticeTarget(listOf(67), 1f, "Ba"), PracticeTarget(listOf(67), 1f, "by"), PracticeTarget(listOf(66), 2f, "shark")
        )
    )
)