package ducphi.tunnerinstrument

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.Environment
import android.os.Build
import android.os.ParcelFileDescriptor
import android.widget.VideoView
import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.shadow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material.icons.filled.Settings
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Add
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.roundToInt

enum class PracticeMode { MENU, LEARN, QUIZ, RESULT, EXPLORE, FINGER_TRAINING, REAL_GUITAR_READING, MINIGAME_PREPARE, RUNNING_NOTES_GAME, RUNNING_CHORDS_GAME, MATCHING_GAME, LEARNING_MATERIALS }
enum class NoteGameMode { NONE, QUIZ, RUNNING_NOTES, RUNNING_CHORDS, MATCHING }
enum class PracticeCategory { CHORDS, NOTES, EXPLORE, PITCH }
enum class NoteState { ACTIVE, HIT, MISSED }

// Thêm Data Class cho Hợp âm chạy
// Thêm Data Class mới này để chứa cả tên và dữ liệu vẽ sơ đồ
data class ChordOption(val name: String, val position: ChordPosition)

// Sửa lại RunningChord (thay List<String> thành List<ChordOption>)
data class RunningChord(
    val id: Long,
    val midis: List<Int>,
    val correctName: String,
    val options: List<ChordOption>, // Đã thay đổi ở đây
    val spawnTime: Long,
    var state: NoteState = NoteState.ACTIVE
)

data class RunningNote(
    val id: Long,
    val midi: Int,
    val spawnTime: Long,
    var state: NoteState = NoteState.ACTIVE
)
data class PitchQuizQuestion(
    val isChord: Boolean,
    val midis: List<Int>,
    val correctName: String,
    val options: List<String>,
    val imageDataJson: String = ""
)
enum class Difficulty(val timeLimit: Int, val itemCount: Int) {
    EASY(7, 7), HARD(5, 7), EXPERT(3, 10)
}
data class WrongAnswerData(
    val questionType: String,
    val selectedOption: String,
    val correctOption: String,
    val imageDataJson: String = "",
    val instrument: String = ""
)
data class QuizQuestion(val chord: ChordModel, val position: ChordPosition, val options: List<String>)
data class NotePosition(val name: String, val stringIdx: Int = -1, val fret: Int = -1, val midi: Int = -1)
data class NoteQuizQuestion(val targetNote: NotePosition, val options: List<String>)

fun playQuizSound(context: Context, isCorrect: Boolean) {
    try {
        val soundName = if (isCorrect) "correct_sound" else "wrong_sound"
        val resId = context.resources.getIdentifier(soundName, "raw", context.packageName)

        if (resId != 0) {
            val mediaPlayer = MediaPlayer.create(context, resId)
            mediaPlayer?.setOnCompletionListener { it.release() }
            mediaPlayer?.start()
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
fun playHitSound(context: Context) {
    try {
        val resId = context.resources.getIdentifier("hit_sound", "raw", context.packageName)
        if (resId != 0) {
            val mediaPlayer = MediaPlayer.create(context, resId)
            mediaPlayer?.setOnCompletionListener { it.release() }
            mediaPlayer?.start()
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
fun getInstrumentNotePosition(midi: Int, instrument: String): NotePosition {
    val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val name = noteNames[midi % 12]
    val openMidi = if (instrument == "Ukulele") listOf(69, 64, 60, 67) else listOf(64, 59, 55, 50, 45, 40)

    for (s in openMidi.indices) {
        val fret = midi - openMidi[s]
        if (fret in 0..4) return NotePosition(name = name, stringIdx = s, fret = fret, midi = midi)
    }
    for (s in openMidi.indices) {
        val fret = midi - openMidi[s]
        if (fret >= 0) return NotePosition(name = name, stringIdx = s, fret = fret, midi = midi)
    }
    return NotePosition(name, -1, -1, midi)
}

@Composable
fun ChordPracticeScreen(
    allChords: List<ChordModel>,
    instrument: String,
    onInstrumentChange: (String) -> Unit,
    currentLang: String,
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    tunerViewModel: TunerViewModel = viewModel(),
    onClose: () -> Unit,
    onFullScreenToggle: (Boolean) -> Unit = {},
    startDirectlyInQuiz: Boolean = false,
    quizCategory: PracticeCategory = PracticeCategory.CHORDS
) {
    val context = LocalContext.current
    var runningNotesTimeLimit by remember { mutableIntStateOf(60) }
    var showRunningNotesSettings by remember { mutableStateOf(false) }
    var runningNotesStartBpm by remember { mutableIntStateOf(30) }
    // Khởi tạo thẳng vào màn hình Prepare nếu được yêu cầu từ ngoài Hub truyền vào
    var currentState by remember { mutableStateOf(if (startDirectlyInQuiz) PracticeMode.MINIGAME_PREPARE else PracticeMode.MENU) }
    // Ghi nhớ màn con và cấu hình nhận diện cao độ khi chuyển qua lại giữa 2 file.
    var fingerTrainingLandingPage by remember { mutableStateOf(FingerTrainingLandingPage.ENTRY) }
    var pitchRecognitionLaunchConfig by remember { mutableStateOf(PitchRecognitionLaunchConfig()) }
    var noteGameMode by remember { mutableStateOf(NoteGameMode.NONE) }
    var chordGameMode by remember { mutableStateOf(NoteGameMode.NONE) }
    // Khởi tạo thẳng category tương ứng
    var selectedCategory by remember { mutableStateOf(if (startDirectlyInQuiz) quizCategory else PracticeCategory.CHORDS) }
    var difficulty by remember { mutableStateOf(Difficulty.EASY) }

    var learningChords by remember { mutableStateOf<List<ChordModel>>(emptyList()) }
    var quizQuestions by remember { mutableStateOf<List<QuizQuestion>>(emptyList()) }

    var learningNotes by remember { mutableStateOf<List<NotePosition>>(emptyList()) }
    var quizNoteQuestions by remember { mutableStateOf<List<NoteQuizQuestion>>(emptyList()) }

    var quizPitchQuestions by remember { mutableStateOf<List<PitchQuizQuestion>>(emptyList()) }

    var currentIndex by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var timeLeft by remember { mutableStateOf(0) }
    var isTimerRunning by remember { mutableStateOf(false) }
    var isQuestionAnswered by remember { mutableStateOf(false) }
    var selectedAnswer by remember { mutableStateOf<String?>(null) }
    var showResultDialog by remember { mutableStateOf(false) }
    var currentWrongAnswers by remember { mutableStateOf<List<WrongAnswerData>>(emptyList()) }
    var totalElapsedTime by remember { mutableIntStateOf(0) }

    // Thêm các biến để xem lại lịch sử
    var historyReviewScore by remember { mutableIntStateOf(0) }
    var historyReviewTotal by remember { mutableIntStateOf(0) }
    var historyReviewTime by remember { mutableIntStateOf(0) }
    var historyReviewWrongAnswers by remember { mutableStateOf<List<WrongAnswerData>?>(null) }

    LaunchedEffect(currentState, showResultDialog) {
        if (currentState == PracticeMode.QUIZ && !showResultDialog) {
            while (true) {
                kotlinx.coroutines.delay(1000L)
                totalElapsedTime++
            }
        } else if (currentState != PracticeMode.QUIZ) {
            totalElapsedTime = 0
        }
    }

    fun getPoolForDifficulty(diff: Difficulty): List<ChordModel> {
        return allChords.filter { chord ->
            val isNatural = !chord.key.contains("#") && !chord.key.contains("b")
            isNatural && when (diff) {
                Difficulty.EASY -> chord.suffix == "major" || chord.suffix == "minor"
                Difficulty.HARD -> chord.suffix == "major" || chord.suffix == "minor" || chord.suffix.contains("7")
                Difficulty.EXPERT -> true
            }
        }.filter { it.positions.isNotEmpty() }
    }

    fun generateQuestions(chordsToQuiz: List<ChordModel>, diff: Difficulty, customItemCount: Int = diff.itemCount) {
        val questions = mutableListOf<QuizQuestion>()
        val fullPool = getPoolForDifficulty(diff)

        val selectedChordsForQuiz = if (diff == Difficulty.EXPERT) {
            val selected = mutableListOf<ChordModel>()
            while (selected.size < customItemCount) {
                selected.addAll(fullPool.shuffled().take(customItemCount - selected.size))
            }
            selected
        } else chordsToQuiz

        selectedChordsForQuiz.forEach { chord ->
            val pos = if (difficulty == Difficulty.EASY) chord.positions.minByOrNull { it.baseFret } ?: chord.positions.first() else chord.positions.random()
            val correctName = "${chord.key}${if(chord.suffix == "minor") "m" else if(chord.suffix == "major") "" else chord.suffix}".toMusicSymbols()
            val wrongOptions = fullPool.filter { it.key != chord.key || it.suffix != chord.suffix }.shuffled().take(3)
                .map { "${it.key}${if(it.suffix == "minor") "m" else if(it.suffix == "major") "" else it.suffix}".toMusicSymbols() }
            questions.add(QuizQuestion(chord, pos, (wrongOptions + correctName).shuffled()))
        }
        quizQuestions = questions.shuffled()
        currentIndex = 0; score = 0; timeLeft = diff.timeLimit; isQuestionAnswered = false; selectedAnswer = null; isTimerRunning = true
        currentState = PracticeMode.QUIZ
    }
    val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    fun getNotePool(inst: String, diff: Difficulty): List<NotePosition> {
        val pool = mutableListOf<NotePosition>()
        if (inst == "Piano") {
            val (minMidi, maxMidi) = when(diff) {
                Difficulty.EASY -> Pair(60, 71)
                Difficulty.HARD -> Pair(48, 83)
                Difficulty.EXPERT -> Pair(36, 95)
            }
            for (m in minMidi..maxMidi) pool.add(NotePosition(noteNames[m % 12], midi = m))
        } else {
            val openIdx = if (inst == "Guitar") listOf(4, 11, 7, 2, 9, 4) else listOf(9, 4, 0, 7)
            val fretRange = when (diff) {
                Difficulty.EASY -> if (inst == "Guitar") 0..3 else 0..4
                Difficulty.HARD -> if (inst == "Guitar") 4..7 else 5..8
                Difficulty.EXPERT -> if (inst == "Guitar") 8..12 else 9..12
            }
            for (s in openIdx.indices) {
                for (f in fretRange) {
                    val name = noteNames[(openIdx[s] + f) % 12]
                    pool.add(NotePosition(name, stringIdx = s, fret = f))
                }
            }
        }
        return pool
    }

    fun generateNoteQuestions(notesToQuiz: List<NotePosition>, diff: Difficulty) {
        val questions = mutableListOf<NoteQuizQuestion>()
        notesToQuiz.forEach { note ->
            val wrongOptions = noteNames.filter { it != note.name }.shuffled().take(3)
            questions.add(NoteQuizQuestion(note, (wrongOptions + note.name).shuffled()))
        }
        quizNoteQuestions = questions.shuffled()
        currentIndex = 0; score = 0; timeLeft = diff.timeLimit; isQuestionAnswered = false; selectedAnswer = null; isTimerRunning = true
        currentState = PracticeMode.QUIZ
    }
    fun generatePitchQuestions(diff: Difficulty, customItemCount: Int = 10) {
        val questions = mutableListOf<PitchQuizQuestion>()
        val chordPool = getPoolForDifficulty(diff)
        val notePool = getNotePool(instrument, diff)

        for (i in 0 until customItemCount) {
            val isChord = kotlin.random.Random.nextBoolean()

            if (isChord && chordPool.isNotEmpty()) {
                val chord = chordPool.random()
                val pos = chord.positions.random()
                val correctName = "${chord.key}${if(chord.suffix == "minor") "m" else if(chord.suffix == "major") "" else chord.suffix}".toMusicSymbols()
                val wrongOptions = chordPool.filter { it.key != chord.key || it.suffix != chord.suffix }.shuffled().take(3).map { "${it.key}${if(it.suffix == "minor") "m" else if(it.suffix == "major") "" else it.suffix}".toMusicSymbols() }

                val imageDataJson = com.google.gson.Gson().toJson(pos)
                questions.add(PitchQuizQuestion(true, pos.midi, correctName, (wrongOptions + correctName).shuffled(), imageDataJson))
            } else if (notePool.isNotEmpty()) {
                val note = notePool.random()
                val actualMidi = if (note.midi != -1) note.midi else {
                    val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40)
                    else if (instrument == "Ukulele") listOf(69, 64, 60, 67)
                    else listOf(60, 62, 64, 65, 67, 69, 71, 72)

                    if (note.stringIdx != -1 && note.stringIdx < openMidi.size) {
                        openMidi[note.stringIdx] + note.fret
                    } else {
                        if (instrument == "Piano") (48..83).random() else 60
                    }
                }
                val wrongOptions = noteNames.filter { it != note.name }.shuffled().take(3)

                val fullNotePos = NotePosition(note.name, note.stringIdx, note.fret, actualMidi)
                val imageDataJson = com.google.gson.Gson().toJson(fullNotePos)
                questions.add(PitchQuizQuestion(false, listOf(actualMidi), note.name, (wrongOptions + note.name).shuffled(), imageDataJson))
            }
        }

        quizPitchQuestions = questions
        currentIndex = 0; score = 0; timeLeft = diff.timeLimit; isQuestionAnswered = false; selectedAnswer = null; isTimerRunning = true
        currentState = PracticeMode.QUIZ
    }
    fun startLearning(diff: Difficulty, category: PracticeCategory, customItemCount: Int) {
        difficulty = diff
        selectedCategory = category

        if (category == PracticeCategory.CHORDS) {
            val pool = getPoolForDifficulty(diff)
            if (pool.isEmpty()) return

            if (diff == Difficulty.EXPERT) generateQuestions(emptyList(), diff, customItemCount)
            else {
                val selected = mutableListOf<ChordModel>()
                while (selected.size < customItemCount) {
                    selected.addAll(pool.shuffled().take(customItemCount - selected.size))
                }
                learningChords = selected
                currentIndex = 0
                currentState = PracticeMode.LEARN
            }
        } else if (category == PracticeCategory.NOTES) {
            val pool = getNotePool(instrument, diff)
            if (pool.isEmpty()) return

            val selected = mutableListOf<NotePosition>()
            while (selected.size < customItemCount) {
                selected.addAll(pool.shuffled().take(customItemCount - selected.size))
            }
            learningNotes = selected
            currentIndex = 0
            currentState = PracticeMode.LEARN
        } else {
            currentState = PracticeMode.EXPLORE
            onFullScreenToggle(true)
        }
    }

    LaunchedEffect(isTimerRunning, timeLeft) {
        if (isTimerRunning && timeLeft > 0) {
            delay(1000L)
            timeLeft--
        } else if (isTimerRunning && timeLeft == 0) {
            isTimerRunning = false
            isQuestionAnswered = true
            selectedAnswer = ""
            playQuizSound(context, false)
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = bgColor) {
        if (currentState == PracticeMode.EXPLORE) {
            // ---> ĐÃ THÊM bgColor VÀO GIỮA surfaceColor VÀ tunaGreen Ở ĐÂY <---
            ExplorePhase(instrument, currentLang, textColor, surfaceColor, bgColor, tunaGreen) {
                currentState = PracticeMode.MENU
                onFullScreenToggle(false)
            }
        } else if (currentState == PracticeMode.FINGER_TRAINING) {
            GameFingerTrainingScreen(
                instrument = instrument,
                currentLang = currentLang,
                bgColor = bgColor,
                surfaceColor = surfaceColor,
                textColor = textColor,
                tunaGreen = tunaGreen,
                initialPage = fingerTrainingLandingPage,
                onOpenPitchRecognition = { config ->
                    pitchRecognitionLaunchConfig = config
                    // Khi quay lại từ màn đọc sheet, trở về đúng menu 5 chế độ.
                    fingerTrainingLandingPage = FingerTrainingLandingPage.PITCH_MENU
                    currentState = PracticeMode.REAL_GUITAR_READING
                },
                onClose = {
                    fingerTrainingLandingPage = FingerTrainingLandingPage.ENTRY
                    currentState = PracticeMode.MENU
                    onFullScreenToggle(false)
                }
            )
        } else if (currentState == PracticeMode.REAL_GUITAR_READING) {
            // Mở màn nhận diện cao độ cũ ở đúng chế độ được chọn từ menu mới.
            RealGuitarReadingPhase(
                instrument = instrument,
                lang = currentLang,
                textColor = textColor,
                surfaceColor = surfaceColor,
                tunaGreen = tunaGreen,
                tunerViewModel = tunerViewModel,
                initialPracticeType = pitchRecognitionLaunchConfig.practiceType,
                initialReadingMode = pitchRecognitionLaunchConfig.readingMode,
                initialAutoEvaluate = pitchRecognitionLaunchConfig.autoEvaluate
            ) {
                fingerTrainingLandingPage = FingerTrainingLandingPage.PITCH_MENU
                currentState = PracticeMode.FINGER_TRAINING
            }
        } else if (currentState == PracticeMode.LEARNING_MATERIALS) {
            LearningMaterialsScreen(
                instrument = instrument,
                lang = currentLang,
                bgColor = bgColor,
                surfaceColor = surfaceColor,
                textColor = textColor,
                tunaGreen = tunaGreen,
                onClose = {
                    currentState = PracticeMode.MENU
                    onFullScreenToggle(false)
                }
            )
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
                if (currentState != PracticeMode.QUIZ &&
                    currentState != PracticeMode.MENU &&
                    currentState != PracticeMode.MINIGAME_PREPARE &&
                    currentState != PracticeMode.RUNNING_NOTES_GAME &&
                    currentState != PracticeMode.RUNNING_CHORDS_GAME &&
                    currentState != PracticeMode.MATCHING_GAME) { // <-- ĐÃ THÊM MATCHING_GAME VÀO ĐÂY
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = CoreTranslator.getString("practice_mode", currentLang), color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Close", tint = textColor) }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                when (currentState) {
                    PracticeMode.MENU -> {
                        PracticeMenu(currentLang, instrument, textColor, surfaceColor, tunaGreen, onClose, onInstrumentChange, { diff, cat, count ->
                            startLearning(diff, cat, count)
                        }, onOpenFingerTraining = {
                            // Luôn bắt đầu từ màn chọn Luyện ngón / Nhận diện cao độ.
                            fingerTrainingLandingPage = FingerTrainingLandingPage.ENTRY
                            currentState = PracticeMode.FINGER_TRAINING
                            onFullScreenToggle(true)
                        }, onOpenLearningMaterials = {
                            currentState = PracticeMode.LEARNING_MATERIALS
                            onFullScreenToggle(true)
                        })
                    }
                    PracticeMode.LEARN -> {
                        if (selectedCategory == PracticeCategory.CHORDS) {
                            LearnPhase(chord = learningChords[currentIndex], currentIndex = currentIndex, total = learningChords.size, instrument = instrument, lang = currentLang, textColor = textColor, surfaceColor = surfaceColor, tunaGreen = tunaGreen, onNext = { if (currentIndex < learningChords.size - 1) currentIndex++ else generateQuestions(learningChords, difficulty) })
                        } else {
                            LearnNotePhase(note = learningNotes[currentIndex], currentIndex = currentIndex, total = learningNotes.size, instrument = instrument, lang = currentLang, textColor = textColor, surfaceColor = surfaceColor, tunaGreen = tunaGreen, onNext = { if (currentIndex < learningNotes.size - 1) currentIndex++ else generateNoteQuestions(learningNotes, difficulty) })
                        }
                    }
                    PracticeMode.RUNNING_NOTES_GAME -> {
                        RunningNotesGamePhase(
                            instrument = instrument,
                            lang = currentLang,
                            textColor = textColor,
                            surfaceColor = surfaceColor,
                            bgColor = bgColor, // THÊM DÒNG NÀY Ở ĐÂY
                            tunaGreen = tunaGreen,
                            initialTime = runningNotesTimeLimit,
                            initialBpm = runningNotesStartBpm,
                            onClose = {
                                currentState = PracticeMode.MINIGAME_PREPARE
                                noteGameMode = NoteGameMode.NONE
                            }
                        )
                    }
                    PracticeMode.QUIZ -> {
                        if (selectedCategory == PracticeCategory.CHORDS) {
                            val safeIndex = minOf(currentIndex, maxOf(0, quizQuestions.size - 1))

                            QuizPhase(
                                question = quizQuestions[safeIndex],
                                currentIndex = safeIndex,
                                total = quizQuestions.size,
                                timeLeft = timeLeft,
                                timeLimit = difficulty.timeLimit,
                                score = score, totalElapsedTime = totalElapsedTime,
                                instrument = instrument,
                                lang = currentLang,
                                textColor = textColor,
                                surfaceColor = surfaceColor,
                                tunaGreen = tunaGreen,
                                isAnswered = isQuestionAnswered,
                                selectedAnswer = selectedAnswer,
                                onAnswerSelected = { opt, isCorrect ->
                                    if (!isQuestionAnswered) {
                                        isQuestionAnswered = true;
                                        selectedAnswer = opt;
                                        isTimerRunning = false;
                                        if (isCorrect) {
                                            score++;
                                        } else {
                                            val currentQ = quizQuestions[safeIndex]
                                            val q = currentQ.chord
                                            val correctName = "${q.key}${if(q.suffix == "minor") "m" else if(q.suffix == "major") "" else q.suffix}".toMusicSymbols()
                                            val gson = com.google.gson.Gson()
                                            val imageData = gson.toJson(currentQ.position)
                                            currentWrongAnswers = currentWrongAnswers + WrongAnswerData("CHORD", opt, correctName, imageData, instrument)
                                        }
                                        playQuizSound(context, isCorrect)
                                    }
                                },
                                onStop = { showResultDialog = true },
                                onNext = {
                                    currentIndex++
                                    if (currentIndex >= quizQuestions.size) {
                                        if (startDirectlyInQuiz) {
                                            difficulty = when {
                                                currentIndex < 10 -> Difficulty.EASY
                                                currentIndex < 20 -> Difficulty.HARD
                                                else -> Difficulty.EXPERT
                                            }
                                            timeLeft = difficulty.timeLimit

                                            val pool = getPoolForDifficulty(difficulty)
                                            val newBatch = mutableListOf<QuizQuestion>()
                                            val selectedChords = mutableListOf<ChordModel>()
                                            while (selectedChords.size < 10) { selectedChords.addAll(pool.shuffled().take(10 - selectedChords.size)) }

                                            selectedChords.forEach { chord ->
                                                val pos = chord.positions.random()
                                                val correctName = "${chord.key}${if(chord.suffix == "minor") "m" else if(chord.suffix == "major") "" else chord.suffix}".toMusicSymbols()
                                                val wrongOptions = pool.filter { it.key != chord.key || it.suffix != chord.suffix }.shuffled().take(3).map { "${it.key}${if(it.suffix == "minor") "m" else if(it.suffix == "major") "" else it.suffix}".toMusicSymbols() }
                                                newBatch.add(QuizQuestion(chord, pos, (wrongOptions + correctName).shuffled()))
                                            }
                                            quizQuestions = quizQuestions + newBatch
                                            isQuestionAnswered = false
                                            selectedAnswer = null
                                            isTimerRunning = true
                                        } else {
                                            isTimerRunning = false
                                            showResultDialog = true
                                        }
                                    } else {
                                        difficulty = when {
                                            currentIndex < 10 -> Difficulty.EASY
                                            currentIndex < 20 -> Difficulty.HARD
                                            else -> Difficulty.EXPERT
                                        }
                                        timeLeft = difficulty.timeLimit
                                        isQuestionAnswered = false
                                        selectedAnswer = null
                                        isTimerRunning = true
                                    }
                                }
                            )
                        } else if (selectedCategory == PracticeCategory.NOTES) {
                            val safeIndex = minOf(currentIndex, maxOf(0, quizNoteQuestions.size - 1))

                            QuizNotePhase(
                                question = quizNoteQuestions[safeIndex],
                                currentIndex = safeIndex,
                                total = quizNoteQuestions.size,
                                timeLeft = timeLeft,
                                timeLimit = difficulty.timeLimit,
                                score = score, totalElapsedTime = totalElapsedTime,
                                instrument = instrument,
                                lang = currentLang,
                                textColor = textColor,
                                surfaceColor = surfaceColor,
                                tunaGreen = tunaGreen,
                                isAnswered = isQuestionAnswered,
                                selectedAnswer = selectedAnswer,
                                onAnswerSelected = { opt, isCorrect ->
                                    if (!isQuestionAnswered) {
                                        isQuestionAnswered = true;
                                        selectedAnswer = opt;
                                        isTimerRunning = false;
                                        if (isCorrect) {
                                            score++;
                                        } else {
                                            val currentQ = quizNoteQuestions[safeIndex]
                                            val correctName = currentQ.targetNote.name
                                            val gson = com.google.gson.Gson()
                                            val imageData = gson.toJson(currentQ.targetNote)
                                            currentWrongAnswers = currentWrongAnswers + WrongAnswerData("NOTE", opt, correctName, imageData, instrument)
                                        }
                                        playQuizSound(context, isCorrect)
                                    }
                                },
                                onStop = { showResultDialog = true },
                                onNext = {
                                    currentIndex++
                                    if (currentIndex >= quizNoteQuestions.size) {
                                        if (startDirectlyInQuiz) {
                                            difficulty = when {
                                                currentIndex < 10 -> Difficulty.EASY
                                                currentIndex < 20 -> Difficulty.HARD
                                                else -> Difficulty.EXPERT
                                            }
                                            timeLeft = difficulty.timeLimit

                                            val pool = getNotePool(instrument, difficulty)
                                            val newBatch = mutableListOf<NoteQuizQuestion>()
                                            val selectedNotes = mutableListOf<NotePosition>()
                                            while (selectedNotes.size < 10) { selectedNotes.addAll(pool.shuffled().take(10 - selectedNotes.size)) }

                                            selectedNotes.forEach { note ->
                                                val wrongOptions = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B").filter { it != note.name }.shuffled().take(3)
                                                newBatch.add(NoteQuizQuestion(note, (wrongOptions + note.name).shuffled()))
                                            }
                                            quizNoteQuestions = quizNoteQuestions + newBatch
                                            isQuestionAnswered = false
                                            selectedAnswer = null
                                            isTimerRunning = true
                                        } else {
                                            isTimerRunning = false
                                            showResultDialog = true
                                        }
                                    } else {
                                        difficulty = when {
                                            currentIndex < 10 -> Difficulty.EASY
                                            currentIndex < 20 -> Difficulty.HARD
                                            else -> Difficulty.EXPERT
                                        }
                                        timeLeft = difficulty.timeLimit
                                        isQuestionAnswered = false
                                        selectedAnswer = null
                                        isTimerRunning = true
                                    }
                                }
                            )
                        } else {
                            val safeIndex = minOf(currentIndex, maxOf(0, quizPitchQuestions.size - 1))

                            AudioQuizPhase(
                                question = quizPitchQuestions[safeIndex],
                                currentIndex = safeIndex,
                                total = quizPitchQuestions.size,
                                timeLeft = timeLeft,
                                timeLimit = difficulty.timeLimit,
                                score = score, totalElapsedTime = totalElapsedTime,
                                instrument = instrument,
                                lang = currentLang,
                                textColor = textColor,
                                surfaceColor = surfaceColor,
                                tunaGreen = tunaGreen,
                                isAnswered = isQuestionAnswered,
                                selectedAnswer = selectedAnswer,
                                onAnswerSelected = { opt, isCorrect ->
                                    if (!isQuestionAnswered) {
                                        isQuestionAnswered = true
                                        selectedAnswer = opt
                                        isTimerRunning = false
                                        if (isCorrect) {
                                            score++
                                        } else {
                                            val q = quizPitchQuestions[safeIndex]
                                            val qType = if (q.isChord) "PITCH_CHORD" else "PITCH_NOTE"
                                            val imageData = q.imageDataJson
                                            currentWrongAnswers = currentWrongAnswers + WrongAnswerData(qType, opt, q.correctName, imageData, instrument)
                                        }
                                        playQuizSound(context, isCorrect)
                                    }
                                },
                                onStop = { showResultDialog = true },
                                onNext = {
                                    currentIndex++
                                    if (currentIndex >= quizPitchQuestions.size) {
                                        if (startDirectlyInQuiz) {
                                            difficulty = when {
                                                currentIndex < 10 -> Difficulty.EASY
                                                currentIndex < 20 -> Difficulty.HARD
                                                else -> Difficulty.EXPERT
                                            }
                                            timeLeft = difficulty.timeLimit

                                            val chordPool = getPoolForDifficulty(difficulty)
                                            val notePool = getNotePool(instrument, difficulty)
                                            val newBatch = mutableListOf<PitchQuizQuestion>()

                                            for (i in 0 until 10) {
                                                val isChord = kotlin.random.Random.nextBoolean()
                                                if (isChord && chordPool.isNotEmpty()) {
                                                    val chord = chordPool.random()
                                                    val pos = chord.positions.random()
                                                    val correctName = "${chord.key}${if(chord.suffix == "minor") "m" else if(chord.suffix == "major") "" else chord.suffix}".toMusicSymbols()
                                                    val wrongOptions = chordPool.filter { it.key != chord.key || it.suffix != chord.suffix }.shuffled().take(3).map { "${it.key}${if(it.suffix == "minor") "m" else if(it.suffix == "major") "" else it.suffix}".toMusicSymbols() }
                                                    val imageDataJson = com.google.gson.Gson().toJson(pos)
                                                    newBatch.add(PitchQuizQuestion(true, pos.midi, correctName, (wrongOptions + correctName).shuffled(), imageDataJson))
                                                } else if (notePool.isNotEmpty()) {
                                                    val note = notePool.random()
                                                    val actualMidi = if (note.midi != -1) note.midi else {
                                                        val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                                                        if (note.stringIdx < openMidi.size) openMidi[note.stringIdx] + note.fret else 60
                                                    }
                                                    val wrongOptions = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B").filter { it != note.name }.shuffled().take(3)
                                                    val fullNotePos = NotePosition(note.name, note.stringIdx, note.fret, actualMidi)
                                                    val imageDataJson = com.google.gson.Gson().toJson(fullNotePos)
                                                    newBatch.add(PitchQuizQuestion(false, listOf(actualMidi), note.name, (wrongOptions + note.name).shuffled(), imageDataJson))
                                                }
                                            }
                                            quizPitchQuestions = quizPitchQuestions + newBatch
                                            isQuestionAnswered = false
                                            selectedAnswer = null
                                            isTimerRunning = true
                                        } else {
                                            isTimerRunning = false
                                            showResultDialog = true
                                        }
                                    } else {
                                        difficulty = when {
                                            currentIndex < 10 -> Difficulty.EASY
                                            currentIndex < 20 -> Difficulty.HARD
                                            else -> Difficulty.EXPERT
                                        }
                                        timeLeft = difficulty.timeLimit
                                        isQuestionAnswered = false
                                        selectedAnswer = null
                                        isTimerRunning = true
                                    }
                                }
                            )
                        }
                    }

                    PracticeMode.MINIGAME_PREPARE -> {
                        // Gọi Sub-menu nếu chưa chọn chế độ
                        if (selectedCategory == PracticeCategory.NOTES && noteGameMode == NoteGameMode.NONE) {
                            NoteModeSelectionPhase(currentLang, textColor, surfaceColor, tunaGreen, { noteGameMode = it }, { onClose() })
                        } else if (selectedCategory == PracticeCategory.CHORDS && chordGameMode == NoteGameMode.NONE) {
                            ChordModeSelectionPhase(currentLang, textColor, surfaceColor, tunaGreen, { chordGameMode = it }, { onClose() })
                        } else {
                            // ĐÃ SỬA: Thêm các nhánh xử lý tên hiển thị cho cả 3 chế độ
                            val title = when (selectedCategory) {
                                PracticeCategory.PITCH -> CoreTranslator.getString("game_pitch_title", currentLang)
                                PracticeCategory.CHORDS -> when (chordGameMode) {
                                    NoteGameMode.RUNNING_CHORDS -> CoreTranslator.getString("game_running_chords_title", currentLang)
                                    NoteGameMode.MATCHING -> CoreTranslator.getString("game_matching_chord_title", currentLang)
                                    else -> CoreTranslator.getString("game_chord_title", currentLang)
                                }
                                PracticeCategory.NOTES -> when (noteGameMode) {
                                    NoteGameMode.RUNNING_NOTES -> CoreTranslator.getString("game_running_notes_title", currentLang)
                                    NoteGameMode.MATCHING -> CoreTranslator.getString("game_matching_note_title", currentLang)
                                    else -> CoreTranslator.getString("game_note_title", currentLang)
                                }
                                else -> ""
                            }

                            // ĐÃ SỬA: Đồng bộ ID lưu trữ lịch sử khớp với các ID khi gọi hàm saveGameHistory()
                            val gameTypeStr = when (selectedCategory) {
                                PracticeCategory.PITCH -> "PITCH"
                                PracticeCategory.CHORDS -> when (chordGameMode) {
                                    NoteGameMode.RUNNING_CHORDS -> "CHORD_RUN"
                                    NoteGameMode.MATCHING -> "MATCHING"
                                    else -> "CHORD"
                                }
                                PracticeCategory.NOTES -> when (noteGameMode) {
                                    NoteGameMode.RUNNING_NOTES -> "NOTE_RUN"
                                    NoteGameMode.MATCHING -> "NOTE_MATCHING"
                                    else -> "NOTE"
                                }
                                else -> ""
                            }

                            Box(modifier = Modifier.fillMaxSize()) {
                                MinigamePrepareView(
                                    title = title, gameType = gameTypeStr, instrument = instrument, bgColor = bgColor, surfaceColor = surfaceColor, textColor = textColor, currentLang = currentLang, tunaGreen = tunaGreen,
                                    onPlay = {
                                        difficulty = Difficulty.EASY
                                        currentWrongAnswers = emptyList()

                                        if (selectedCategory == PracticeCategory.NOTES && noteGameMode == NoteGameMode.RUNNING_NOTES) {
                                            currentState = PracticeMode.RUNNING_NOTES_GAME
                                        } else if (selectedCategory == PracticeCategory.CHORDS && chordGameMode == NoteGameMode.RUNNING_CHORDS) {
                                            currentState = PracticeMode.RUNNING_CHORDS_GAME
                                        } else if (selectedCategory == PracticeCategory.CHORDS && chordGameMode == NoteGameMode.MATCHING) {
                                            currentState = PracticeMode.MATCHING_GAME // <-- CHUYỂN SANG MÀN HÌNH MỚI NÀY
                                        } else if (selectedCategory == PracticeCategory.NOTES && noteGameMode == NoteGameMode.MATCHING) {
                                            currentState = PracticeMode.MATCHING_GAME
                                        } else {
                                            // Trắc nghiệm tĩnh cũ
                                            when (selectedCategory) {
                                                PracticeCategory.CHORDS -> generateQuestions(getPoolForDifficulty(Difficulty.EASY).shuffled().take(10), Difficulty.EASY)
                                                PracticeCategory.NOTES -> generateNoteQuestions(getNotePool(instrument, Difficulty.EASY).shuffled().take(10), Difficulty.EASY)
                                                PracticeCategory.PITCH -> generatePitchQuestions(Difficulty.EASY, 10)
                                                else -> {}
                                            }
                                        }
                                    },
                                    onClose = {
                                        if (selectedCategory == PracticeCategory.NOTES) noteGameMode = NoteGameMode.NONE
                                        else if (selectedCategory == PracticeCategory.CHORDS) chordGameMode = NoteGameMode.NONE
                                        else onClose()
                                    },
                                    onReviewHistory = { hScore, hTotal, hTime, hWrongJson ->
                                        historyReviewScore = hScore
                                        historyReviewTotal = hTotal
                                        historyReviewTime = hTime
                                        val type = object : com.google.gson.reflect.TypeToken<List<WrongAnswerData>>() {}.type
                                        historyReviewWrongAnswers = try {
                                            com.google.gson.Gson().fromJson(hWrongJson, type) ?: emptyList()
                                        } catch (e: Exception) {
                                            emptyList()
                                        }
                                    }
                                )

                                // Hiển thị Icon Bánh Răng cho cả 2 trò chơi chạy
                                if ((selectedCategory == PracticeCategory.NOTES && noteGameMode == NoteGameMode.RUNNING_NOTES) || (selectedCategory == PracticeCategory.CHORDS && chordGameMode == NoteGameMode.RUNNING_CHORDS)) {
                                    IconButton(
                                        onClick = { showRunningNotesSettings = true },
                                        modifier = Modifier.align(Alignment.TopEnd).padding(top = 72.dp, end = 16.dp).background(surfaceColor.copy(alpha = 0.8f), CircleShape).border(1.dp, textColor.copy(alpha = 0.2f), CircleShape).size(42.dp)
                                    ) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = tunaGreen) }
                                }
                            }

                            // Hiển thị Popup xem lại lịch sử
                            if (historyReviewWrongAnswers != null) {
                                ResultPhase(
                                    score = historyReviewScore,
                                    total = historyReviewTotal,
                                    totalElapsedTime = historyReviewTime,
                                    wrongAnswers = historyReviewWrongAnswers!!,
                                    lang = currentLang,
                                    textColor = textColor,
                                    surfaceColor = surfaceColor,
                                    tunaGreen = tunaGreen
                                ) {
                                    historyReviewWrongAnswers = null
                                }
                            }

                            // Popup Cài đặt (Dùng chung cho cả 2 trò)
                            if (showRunningNotesSettings) {
                                androidx.compose.ui.window.Dialog(onDismissRequest = { showRunningNotesSettings = false }) {
                                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = surfaceColor)) {
                                        Column(modifier = Modifier.padding(24.dp)) {
                                            Text(CoreTranslator.getString("settings_game_title", currentLang), color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(20.dp))
                                            Text(CoreTranslator.getString("settings_time_sec", currentLang), color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                listOf(30, 60, 90, 120).forEach { t ->
                                                    val isSel = runningNotesTimeLimit == t
                                                    Button(onClick = { runningNotesTimeLimit = t }, colors = ButtonDefaults.buttonColors(containerColor = if(isSel) tunaGreen else bgColor), modifier = Modifier.weight(1f).height(40.dp), shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(0.dp)) {
                                                        Text("$t", color = if(isSel) Color.White else textColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(24.dp))
                                            Text("${CoreTranslator.getString("settings_start_bpm", currentLang)} $runningNotesStartBpm", color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                            Slider(value = runningNotesStartBpm.toFloat(), onValueChange = { runningNotesStartBpm = it.toInt() }, valueRange = 20f..100f, colors = SliderDefaults.colors(thumbColor = tunaGreen, activeTrackColor = tunaGreen, inactiveTrackColor = textColor.copy(alpha = 0.2f)))
                                            Spacer(modifier = Modifier.height(24.dp))
                                            Button(onClick = { showRunningNotesSettings = false }, colors = ButtonDefaults.buttonColors(containerColor = tunaGreen), modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(12.dp)) {
                                                Text(CoreTranslator.getString("btn_done", currentLang), color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    PracticeMode.RUNNING_CHORDS_GAME -> {
                        RunningChordsGamePhase(
                            allChords = allChords, instrument = instrument, lang = currentLang,
                            textColor = textColor, surfaceColor = surfaceColor,
                            bgColor = bgColor, // THÊM DÒNG NÀY Ở ĐÂY
                            tunaGreen = tunaGreen,
                            initialTime = runningNotesTimeLimit, initialBpm = runningNotesStartBpm,
                            onClose = {
                                currentState = PracticeMode.MINIGAME_PREPARE
                                chordGameMode = NoteGameMode.NONE
                            }
                        )
                    }
                    PracticeMode.MATCHING_GAME -> {
                        if (selectedCategory == PracticeCategory.CHORDS) {
                            MatchingGamePhase(
                                allChords = allChords, instrument = instrument, lang = currentLang,
                                textColor = textColor, surfaceColor = surfaceColor, bgColor = bgColor, tunaGreen = tunaGreen, // THÊM bgColor = bgColor Ở ĐÂY
                                onClose = { currentState = PracticeMode.MINIGAME_PREPARE; chordGameMode = NoteGameMode.NONE }
                            )
                        } else if (selectedCategory == PracticeCategory.NOTES) {
                            NoteMatchingGamePhase(
                                instrument = instrument, lang = currentLang,
                                textColor = textColor, surfaceColor = surfaceColor, bgColor = bgColor, tunaGreen = tunaGreen, // THÊM bgColor = bgColor Ở ĐÂY
                                onClose = { currentState = PracticeMode.MINIGAME_PREPARE; noteGameMode = NoteGameMode.NONE }
                            )
                        }
                    }
                    else -> {}
                }

                if (showResultDialog) {
                    val totalQ = if (startDirectlyInQuiz) {
                        score + currentWrongAnswers.size
                    } else {
                        when (selectedCategory) {
                            PracticeCategory.CHORDS -> quizQuestions.size
                            PracticeCategory.NOTES -> quizNoteQuestions.size
                            PracticeCategory.PITCH -> quizPitchQuestions.size
                            else -> currentIndex
                        }
                    }

                    LaunchedEffect(Unit) {
                        if (startDirectlyInQuiz) {
                            val type = when (selectedCategory) {
                                PracticeCategory.CHORDS -> "CHORD"
                                PracticeCategory.NOTES -> "NOTE"
                                else -> "PITCH"
                            }
                            val gson = com.google.gson.Gson()
                            val wrongAnswersJson = gson.toJson(currentWrongAnswers)
                            saveGameHistory(context, instrument, type, score, totalQ, totalElapsedTime, wrongAnswersJson)
                        }
                    }
                    ResultPhase(
                        score = score,
                        total = totalQ,
                        totalElapsedTime = totalElapsedTime,
                        wrongAnswers = currentWrongAnswers,
                        lang = currentLang,
                        textColor = textColor,
                        surfaceColor = surfaceColor,
                        tunaGreen = tunaGreen
                    ) {
                        // Bắt đầu đoạn code chuyển state
                        showResultDialog = false
                        if (startDirectlyInQuiz) {
                            currentState = PracticeMode.MINIGAME_PREPARE
                        } else {
                            currentState = PracticeMode.MENU
                        }
                        // Kết thúc đoạn code chuyển state
                    }
                }
            }
        }
    }
}

@Composable
fun PracticeMenu(
    lang: String, currentInstrument: String, textColor: Color, surfaceColor: Color, tunaGreen: Color,
    onClose: () -> Unit, onInstrumentChange: (String) -> Unit,
    onSelect: (Difficulty, PracticeCategory, Int) -> Unit,
    onOpenFingerTraining: () -> Unit,
    onOpenLearningMaterials: () -> Unit
) {
    var practiceCategory by remember { mutableStateOf(PracticeCategory.CHORDS) }
    var selectedDifficultyForDialog by remember { mutableStateOf<Difficulty?>(null) }
    var tempItemCount by remember { mutableIntStateOf(7) }
    var customInputText by remember { mutableStateOf("") }

    val context = LocalContext.current
    val activity = context as? Activity

    DisposableEffect(Unit) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        onDispose {}
    }

    if (selectedDifficultyForDialog != null) {
        AlertDialog(
            onDismissRequest = { selectedDifficultyForDialog = null },
            containerColor = surfaceColor,
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(text = CoreTranslator.getString("setting_qty_title", lang), color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(CoreTranslator.getString("setting_qty_desc", lang), color = textColor.copy(alpha = 0.8f), fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.2f))
                            .border(1.5.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.4f), Color.White.copy(alpha = 0.05f))), CircleShape)
                            .padding(6.dp)
                    ) {
                        val counts = listOf(5, 7, 10, 15, 20)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            counts.forEach { count ->
                                val isSelected = tempItemCount == count && customInputText.isEmpty()
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(CircleShape)
                                        .background(if (isSelected) androidx.compose.ui.graphics.Brush.verticalGradient(listOf(tunaGreen.copy(alpha = 0.7f), tunaGreen)) else androidx.compose.ui.graphics.SolidColor(Color.Transparent))
                                        .then(if (isSelected) Modifier.border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.4f), Color.Black.copy(alpha = 0.2f))), CircleShape) else Modifier)
                                        .clickable {
                                            tempItemCount = count
                                            customInputText = ""
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(count.toString(), color = if (isSelected) Color.White else textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            val isCustomSelected = customInputText.isNotEmpty()
                            Box(
                                modifier = Modifier
                                    .weight(1.2f)
                                    .clip(CircleShape)
                                    .background(if (isCustomSelected) androidx.compose.ui.graphics.Brush.verticalGradient(listOf(tunaGreen.copy(alpha = 0.7f), tunaGreen)) else androidx.compose.ui.graphics.SolidColor(Color.Transparent))
                                    .then(if (isCustomSelected) Modifier.border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.4f), Color.Black.copy(alpha = 0.2f))), CircleShape) else Modifier)
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                androidx.compose.foundation.text.BasicTextField(
                                    value = customInputText,
                                    onValueChange = { input ->
                                        val filtered = input.filter { it.isDigit() }.take(3)
                                        customInputText = filtered
                                        tempItemCount = filtered.toIntOrNull() ?: 0
                                    },
                                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number,
                                        imeAction = androidx.compose.ui.text.input.ImeAction.Done
                                    ),
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        color = if (isCustomSelected) Color.White else textColor,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    ),
                                    cursorBrush = androidx.compose.ui.graphics.SolidColor(if (isCustomSelected) Color.White else tunaGreen),
                                    decorationBox = { innerTextField ->
                                        if (customInputText.isEmpty()) {
                                            Text("...", color = textColor.copy(alpha = 0.5f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        }
                                        innerTextField()
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalCount = if (tempItemCount > 0) tempItemCount else 1
                        onSelect(selectedDifficultyForDialog!!, practiceCategory, finalCount)
                        selectedDifficultyForDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        // ĐÃ SỬA
                        Text(CoreTranslator.getString("start_btn", lang), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedDifficultyForDialog = null }) {
                    // ĐÃ SỬA
                    Text(CoreTranslator.getString("cancel", lang), color = textColor.copy(alpha = 0.7f), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Giao diện chính được làm lại theo phong cách trung tính "Dark Studio".
    // Chỉ thay đổi cách hiển thị; toàn bộ callback và luồng chức năng được giữ nguyên.
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        // Truy cập rõ receiver để tránh cảnh báo UnusedBoxWithConstraintsScope ở một số bản Android Studio/K2.
        val availableHeight = this.maxHeight
        val availableWidth = this.maxWidth
        val density = LocalDensity.current
        val effectiveHeightDp = availableHeight.value / density.fontScale.coerceAtLeast(1f)
        val heightScale = (effectiveHeightDp / 680f).coerceIn(0.52f, 1f)
        val compactHeight = effectiveHeightDp < 650f
        val ultraCompactHeight = effectiveHeightDp < 500f
        val compactWidth = availableWidth < 350.dp

        fun metricDp(normal: Float, minimum: Float): Dp =
            (normal * heightScale).coerceAtLeast(minimum).dp

        fun metricSp(normal: Float, minimum: Float) =
            (normal * heightScale).coerceAtLeast(minimum).sp

        fun removeStepNumber(value: String): String =
            value.replace(Regex("^\\s*\\d+\\s*[\\.:\\-]?\\s*"), "").trim()

        val panelColor = surfaceColor.copy(alpha = 0.94f)
        val panelBorderColor = textColor.copy(alpha = 0.10f)
        val mutedTextColor = textColor.copy(alpha = 0.58f)
        val softTextColor = textColor.copy(alpha = 0.74f)
        val selectedFillColor = tunaGreen.copy(alpha = 0.14f)
        val selectedBorderColor = tunaGreen.copy(alpha = 0.48f)

        val hardAccent = Color(0xFFD3A34B)
        val expertAccent = Color(0xFFD96868)
        val fingerAccent = Color(0xFF6D91E8)

        val topPadding = metricDp(2f, 0f)
        val headerHeight = metricDp(40f, 28f)
        val headerGap = metricDp(5f, 1f)
        val sectionSpacing = metricDp(if (ultraCompactHeight) 5f else if (compactHeight) 7f else 11f, 2f)
        val labelGap = metricDp(4f, 1f)
        val labelFontSize = metricSp(if (compactHeight) 11f else 12f, 8f)
        val titleFontSize = metricSp(if (compactHeight) 18f else 20f, 14f)
        val selectorHeight = metricDp(if (ultraCompactHeight) 38f else if (compactHeight) 42f else 48f, 30f)
        val selectorPadding = metricDp(4f, 2f)
        val selectorIconSize = metricDp(if (compactWidth) 17f else 20f, 14f)
        val selectorTextSize = metricSp(if (compactWidth) 10.5f else 12f, 8.5f)
        val selectorGap = metricDp(if (compactWidth) 3f else 6f, 2f)
        val difficultyRowHeight = metricDp(if (ultraCompactHeight) 39f else if (compactHeight) 43f else 55f, 29f)
        val toolRowHeight = metricDp(if (ultraCompactHeight) 39f else if (compactHeight) 43f else 52f, 29f)
        val rowHorizontalPadding = metricDp(12f, 7f)
        val rowIconBoxSize = metricDp(if (compactHeight) 30f else 36f, 23f)
        val rowIconSize = metricDp(if (compactHeight) 17f else 20f, 13f)
        val rowTitleSize = metricSp(if (compactHeight) 12f else 13.5f, 9f)
        val rowDescriptionSize = metricSp(10.5f, 8f)
        val arrowSize = metricDp(18f, 13f)
        val showDescriptions =
            !compactHeight && availableHeight >= 650.dp && density.fontScale <= 1.15f

        // Mot nhip dung chung cho hai nhan NEW: chu do vua nhap nhay vua phong to/thu nho.
        val newBadgeTransition = rememberInfiniteTransition(label = "practice_new_badge")
        val newBadgeAlpha by newBadgeTransition.animateFloat(
            initialValue = 0.55f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 620),
                repeatMode = RepeatMode.Reverse
            ),
            label = "practice_new_badge_alpha"
        )
        val newBadgeScale by newBadgeTransition.animateFloat(
            initialValue = 0.86f,
            targetValue = 1.14f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 620),
                repeatMode = RepeatMode.Reverse
            ),
            label = "practice_new_badge_scale"
        )

        val panelShape = RoundedCornerShape(metricDp(14f, 9f))
        val selectorShape = RoundedCornerShape(metricDp(12f, 8f))
        val segmentShape = RoundedCornerShape(metricDp(9f, 6f))
        val iconShape = RoundedCornerShape(metricDp(10f, 7f))
        val compactTextStyle = androidx.compose.ui.text.TextStyle(
            platformStyle = androidx.compose.ui.text.PlatformTextStyle(
                includeFontPadding = false
            )
        )

        val instrumentSectionTitle =
            removeStepNumber(CoreTranslator.getString("step_select_inst", lang))
        val contentSectionTitle =
            removeStepNumber(CoreTranslator.getString("step_learn_prac", lang))
        val difficultySectionTitle = if (lang == "vi") "Chọn cấp độ" else "Choose difficulty"
        val toolsSectionTitle = if (lang == "vi") "Công cụ hỗ trợ" else "Practice tools"

        @Composable
        fun SectionLabel(value: String) {
            Text(
                text = value,
                color = softTextColor,
                fontSize = labelFontSize,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                style = compactTextStyle
            )
        }

        @Composable
        fun NeutralPanel(content: @Composable ColumnScope.() -> Unit) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(panelShape)
                    .background(panelColor)
                    .border(1.dp, panelBorderColor, panelShape),
                content = content
            )
        }

        @Composable
        fun DifficultyLevelIcon(
            level: Int,
            accent: Color,
            modifier: Modifier = Modifier
        ) {
            val safeLevel = level.coerceIn(1, 3)
            Canvas(modifier = modifier) {
                if (size.width <= 0f || size.height <= 0f) return@Canvas

                val gap = size.width * 0.10f
                val barWidth = (size.width - gap * 2f) / 3f
                val bottom = size.height * 0.90f
                val maxBarHeight = size.height * 0.78f
                val heightRatios = floatArrayOf(0.42f, 0.68f, 1f)
                val corner = CornerRadius(barWidth * 0.30f, barWidth * 0.30f)

                heightRatios.forEachIndexed { index, ratio ->
                    val barHeight = maxBarHeight * ratio
                    val left = index * (barWidth + gap)
                    val barColor = if (index < safeLevel) {
                        accent
                    } else {
                        accent.copy(alpha = 0.22f)
                    }

                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(left, bottom - barHeight),
                        size = Size(barWidth, barHeight),
                        cornerRadius = corner
                    )
                }
            }
        }

        @Composable
        fun DifficultyRow(
            level: Int,
            title: String,
            description: String,
            accent: Color,
            showDivider: Boolean,
            onClick: () -> Unit
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(difficultyRowHeight)
                    .clickable(onClick = onClick)
                    .padding(horizontal = rowHorizontalPadding),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(rowIconBoxSize)
                        .clip(iconShape)
                        .background(accent.copy(alpha = 0.13f)),
                    contentAlignment = Alignment.Center
                ) {
                    DifficultyLevelIcon(
                        level = level,
                        accent = accent,
                        modifier = Modifier.size(rowIconSize)
                    )
                }

                Spacer(modifier = Modifier.width(metricDp(10f, 6f)))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = title,
                        color = textColor,
                        fontSize = rowTitleSize,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        style = compactTextStyle
                    )
                    if (showDescriptions) {
                        Spacer(modifier = Modifier.height(metricDp(2f, 1f)))
                        Text(
                            text = description,
                            color = mutedTextColor,
                            fontSize = rowDescriptionSize,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            style = compactTextStyle
                        )
                    }
                }

                Spacer(modifier = Modifier.width(metricDp(6f, 3f)))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.30f),
                    modifier = Modifier.size(arrowSize)
                )
            }

            if (showDivider) {
                HorizontalDivider(
                    modifier = Modifier.padding(start = rowHorizontalPadding + rowIconBoxSize + metricDp(10f, 6f)),
                    thickness = 1.dp,
                    color = panelBorderColor
                )
            }
        }

        @Composable
        fun ToolRow(
            title: String,
            description: String,
            accent: Color,
            showDivider: Boolean,
            onClick: () -> Unit,
            showNewBadge: Boolean = false,
            iconContent: @Composable () -> Unit
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(toolRowHeight)
                    .clickable(onClick = onClick)
                    .padding(horizontal = rowHorizontalPadding),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(rowIconBoxSize)
                        .clip(iconShape)
                        .background(accent.copy(alpha = 0.13f)),
                    contentAlignment = Alignment.Center
                ) {
                    iconContent()
                }

                Spacer(modifier = Modifier.width(metricDp(10f, 6f)))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = title,
                            color = textColor,
                            fontSize = rowTitleSize,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            style = compactTextStyle,
                            modifier = Modifier.weight(1f)
                        )

                        if (showNewBadge) {
                            Spacer(modifier = Modifier.width(metricDp(6f, 3f)))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0xFFFFEB3B))
                                    .border(
                                        width = 1.dp,
                                        color = Color.White.copy(alpha = 0.32f),
                                        shape = RoundedCornerShape(50)
                                    )
                                    .padding(
                                        horizontal = metricDp(6f, 4f),
                                        vertical = metricDp(2.5f, 1.5f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "NEW",
                                    color = Color.Red.copy(alpha = newBadgeAlpha),
                                    fontSize = metricSp(8.5f, 7f),
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1,
                                    style = compactTextStyle,
                                    modifier = Modifier.graphicsLayer {
                                        scaleX = newBadgeScale
                                        scaleY = newBadgeScale
                                    }
                                )
                            }
                        }
                    }
                    if (showDescriptions) {
                        Spacer(modifier = Modifier.height(metricDp(2f, 1f)))
                        Text(
                            text = description,
                            color = mutedTextColor,
                            fontSize = rowDescriptionSize,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            style = compactTextStyle
                        )
                    }
                }

                Spacer(modifier = Modifier.width(metricDp(6f, 3f)))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.30f),
                    modifier = Modifier.size(arrowSize)
                )
            }

            if (showDivider) {
                HorizontalDivider(
                    modifier = Modifier.padding(start = rowHorizontalPadding + rowIconBoxSize + metricDp(10f, 6f)),
                    thickness = 1.dp,
                    color = panelBorderColor
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = topPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(headerHeight),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = CoreTranslator.getString("practice_mode", lang),
                    color = textColor,
                    fontSize = titleFontSize,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    style = compactTextStyle,
                    modifier = Modifier.weight(1f)
                )

                Box(
                    modifier = Modifier
                        .size(headerHeight)
                        .clip(CircleShape)
                        .background(surfaceColor.copy(alpha = 0.78f))
                        .border(1.dp, panelBorderColor, CircleShape)
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = textColor.copy(alpha = 0.88f),
                        modifier = Modifier.size(metricDp(20f, 16f))
                    )
                }
            }

            Spacer(modifier = Modifier.height(headerGap))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = metricDp(8f, 4f)),
                verticalArrangement = Arrangement.spacedBy(sectionSpacing)
            ) {
                // Chọn nhạc cụ
                Column(modifier = Modifier.fillMaxWidth()) {
                    SectionLabel(instrumentSectionTitle)
                    Spacer(modifier = Modifier.height(labelGap))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(selectorHeight)
                            .clip(selectorShape)
                            .background(panelColor)
                            .border(1.dp, panelBorderColor, selectorShape)
                            .padding(selectorPadding)
                    ) {
                        val instruments = listOf("Guitar", "Ukulele", "Piano")
                        instruments.forEach { inst ->
                            val isSelected = currentInstrument == inst
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(segmentShape)
                                    .background(if (isSelected) selectedFillColor else Color.Transparent)
                                    .then(
                                        if (isSelected) {
                                            Modifier.border(1.dp, selectedBorderColor, segmentShape)
                                        } else Modifier
                                    )
                                    .clickable { onInstrumentChange(inst) }
                                    .padding(horizontal = metricDp(4f, 2f)),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = getInstIcon(inst)),
                                    contentDescription = inst,
                                    modifier = Modifier
                                        .size(selectorIconSize)
                                        .graphicsLayer {
                                            alpha = if (isSelected) 1f else 0.62f
                                        }
                                )
                                Spacer(modifier = Modifier.width(selectorGap))
                                Text(
                                    text = inst,
                                    color = if (isSelected) tunaGreen else softTextColor,
                                    fontSize = selectorTextSize,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    style = compactTextStyle
                                )
                            }
                        }
                    }
                }

                // Chọn nội dung luyện tập
                Column(modifier = Modifier.fillMaxWidth()) {
                    SectionLabel(contentSectionTitle)
                    Spacer(modifier = Modifier.height(labelGap))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(selectorHeight)
                            .clip(selectorShape)
                            .background(panelColor)
                            .border(1.dp, panelBorderColor, selectorShape)
                            .padding(selectorPadding)
                    ) {
                        val categories: List<Triple<PracticeCategory, String, ImageVector>> = listOf(
                            Triple(
                                PracticeCategory.CHORDS,
                                CoreTranslator.getString("prac_chords", lang),
                                CustomIcons.Chord
                            ),
                            Triple(
                                PracticeCategory.NOTES,
                                CoreTranslator.getString("prac_notes", lang),
                                CustomIcons.MusicScore
                            )
                        )

                        categories.forEach { (category, title, icon) ->
                            val isSelected = practiceCategory == category
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(segmentShape)
                                    .background(if (isSelected) selectedFillColor else Color.Transparent)
                                    .then(
                                        if (isSelected) {
                                            Modifier.border(1.dp, selectedBorderColor, segmentShape)
                                        } else Modifier
                                    )
                                    .clickable { practiceCategory = category }
                                    .padding(horizontal = metricDp(4f, 2f)),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = title,
                                    tint = if (isSelected) tunaGreen else mutedTextColor,
                                    modifier = Modifier.size(selectorIconSize)
                                )
                                Spacer(modifier = Modifier.width(selectorGap))
                                Text(
                                    text = title,
                                    color = if (isSelected) tunaGreen else softTextColor,
                                    fontSize = selectorTextSize,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    style = compactTextStyle
                                )
                            }
                        }
                    }
                }

                // Chọn cấp độ
                Column(modifier = Modifier.fillMaxWidth()) {
                    SectionLabel(difficultySectionTitle)
                    Spacer(modifier = Modifier.height(labelGap))

                    val easyDesc = if (practiceCategory == PracticeCategory.CHORDS) {
                        CoreTranslator.getString("desc_easy_chord", lang)
                    } else {
                        CoreTranslator.getString("desc_easy_note", lang)
                    }
                    val hardDesc = if (practiceCategory == PracticeCategory.CHORDS) {
                        CoreTranslator.getString("desc_hard_chord", lang)
                    } else {
                        CoreTranslator.getString("desc_hard_note", lang)
                    }
                    val expertDesc = if (practiceCategory == PracticeCategory.CHORDS) {
                        CoreTranslator.getString("desc_expert_chord", lang)
                    } else {
                        CoreTranslator.getString("desc_expert_note", lang)
                    }

                    NeutralPanel {
                        DifficultyRow(
                            level = 1,
                            title = CoreTranslator.getString("diff_easy", lang),
                            description = easyDesc,
                            accent = tunaGreen,
                            showDivider = true
                        ) {
                            tempItemCount = Difficulty.EASY.itemCount
                            selectedDifficultyForDialog = Difficulty.EASY
                        }
                        DifficultyRow(
                            level = 2,
                            title = CoreTranslator.getString("diff_hard", lang),
                            description = hardDesc,
                            accent = hardAccent,
                            showDivider = true
                        ) {
                            tempItemCount = Difficulty.HARD.itemCount
                            selectedDifficultyForDialog = Difficulty.HARD
                        }
                        DifficultyRow(
                            level = 3,
                            title = CoreTranslator.getString("diff_expert", lang),
                            description = expertDesc,
                            accent = expertAccent,
                            showDivider = false
                        ) {
                            tempItemCount = Difficulty.EXPERT.itemCount
                            selectedDifficultyForDialog = Difficulty.EXPERT
                        }
                    }
                }

                // Các công cụ hỗ trợ được gom vào một thẻ trung tính để giao diện gọn và đồng nhất.
                Column(modifier = Modifier.fillMaxWidth()) {
                    SectionLabel(toolsSectionTitle)
                    Spacer(modifier = Modifier.height(labelGap))

                    val exploreTitle = CoreTranslator.getString("open_note_board", lang)
                    val exploreDescription = if (lang == "vi") {
                        "Tra cứu nhanh trên $currentInstrument"
                    } else {
                        "Quick reference for $currentInstrument"
                    }
                    val fingerTitle = if (lang == "vi") {
                        "Luyện ngón & Cao độ"
                    } else {
                        "Finger & Pitch Training"
                    }
                    val fingerDescription = if (lang == "vi") {
                        "Lộ trình cho người mới: luyện ngón và nhận diện nốt theo 5 bước"
                    } else {
                        "A beginner path for finger training and five-step pitch practice"
                    }
                    val materialTitle = if (lang == "vi") "Tài liệu học đàn" else "Learning materials"
                    val materialDescription = if (lang == "vi") {
                        "Hình ảnh, PDF và video"
                    } else {
                        "Images, PDF and video"
                    }
                    NeutralPanel {
                        ToolRow(
                            title = "$exploreTitle ($currentInstrument)",
                            description = exploreDescription,
                            accent = tunaGreen,
                            showDivider = true,
                            onClick = { onSelect(Difficulty.EASY, PracticeCategory.EXPLORE, 0) }
                        ) {
                            if (currentInstrument == "Piano") {
                                MiniPianoIcon(
                                    modifier = Modifier.size(rowIconSize),
                                    color = tunaGreen
                                )
                            } else {
                                val numStrings = if (currentInstrument == "Guitar") 6 else 4
                                MiniFretboardIcon(
                                    modifier = Modifier.size(rowIconSize),
                                    color = tunaGreen,
                                    numStrings = numStrings
                                )
                            }
                        }

                        ToolRow(
                            title = fingerTitle,
                            description = fingerDescription,
                            accent = fingerAccent,
                            showDivider = true,
                            onClick = onOpenFingerTraining,
                            showNewBadge = true
                        ) {
                            Icon(
                                imageVector = Icons.Default.PanTool,
                                contentDescription = null,
                                tint = fingerAccent,
                                modifier = Modifier.size(rowIconSize)
                            )
                        }
                        val folderYellow = Color(0xFFF5A623)

                        ToolRow(
                            title = materialTitle,
                            description = materialDescription,
                            accent = folderYellow,
                            showDivider = false,
                            onClick = onOpenLearningMaterials,
                            showNewBadge = true
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = folderYellow,
                                modifier = Modifier.size(rowIconSize)
                            )
                        }
                    }
                }
            }
        }
    }

}

@Composable
fun DifficultyButton(icon: ImageVector, title: String, desc: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(26.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, color = color.copy(alpha = 0.8f), fontSize = 11.sp)
        }
    }
}

@Composable
fun RealGuitarStaffDiagram(
    instrument: String,
    targetGroups: List<PracticeTarget>,
    activeIndex: Int,
    correctStates: List<Boolean?>,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    timeSig: Int = 4,
    showNoteName: Boolean = true,
    noteSpacingDp: Dp = 60.dp,
    showLyrics: Boolean = false,
    isWaitingForNext: Boolean = false,
    hitMidis: Set<Int> = emptySet(),
    playbackCursorIndex: Int = -1
) {
    fun getStaffStep(midi: Int, instrument: String): Int {
        val writtenMidi = if (instrument == "Guitar") midi + 12 else midi
        val stepOffsets = arrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
        val octave = (writtenMidi / 12) - 1
        val noteIdx = writtenMidi % 12
        val cStep = (octave - 4) * 7 - 2
        return cStep + stepOffsets[noteIdx]
    }

    val density = LocalDensity.current
    val noteSpacingPx = with(density) { noteSpacingDp.toPx() }
    val startMarginPx = with(density) { 84.dp.toPx() }
    val endMarginPx = with(density) { 40.dp.toPx() }
    val canvasWidthPx = startMarginPx + targetGroups.size * noteSpacingPx + endMarginPx
    val canvasWidthDp = with(density) { canvasWidthPx.toDp() }

    if (targetGroups.isEmpty()) return

    Canvas(
        modifier = Modifier
            .width(canvasWidthDp)
            .fillMaxHeight()
            .padding(horizontal = 8.dp)
            .pointerInput(targetGroups, instrument) {
                detectTapGestures { tapOffset ->
                    val tapX = tapOffset.x
                    val groupIndex = ((tapX - startMarginPx + noteSpacingPx / 2) / noteSpacingPx).toInt()
                    if (groupIndex in targetGroups.indices) {
                        try { CoreAudioPlayer.playChord(targetGroups[groupIndex].midis, instrument) } catch (e: Exception) {}
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val lineSpacing = h / 13f
        val startY = h * 0.25f
        val bottomLineY = startY + 4 * lineSpacing
        val stepHeight = lineSpacing / 2f
        val noteHeight = lineSpacing * 0.62f
        val noteWidth = lineSpacing * 0.92f

        for (i in 0..4) {
            val y = startY + i * lineSpacing
            drawLine(color = textColor.copy(alpha = 0.4f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 3f)
        }

        drawLine(color = textColor.copy(alpha = 0.4f), start = Offset(0f, startY), end = Offset(0f, bottomLineY), strokeWidth = 3f)
        drawLine(color = textColor.copy(alpha = 0.4f), start = Offset(w, startY), end = Offset(w, bottomLineY), strokeWidth = 3f)

        // Con trỏ nằm trên các dòng khuông nhưng dưới đầu nốt, thân nốt và chữ.
        if (playbackCursorIndex in targetGroups.indices) {
            val cursorX = startMarginPx + playbackCursorIndex * noteSpacingPx
            drawLine(
                color = tunaGreen.copy(alpha = 0.90f),
                start = Offset(cursorX, 0f),
                end = Offset(cursorX, h),
                strokeWidth = with(density) { 2.dp.toPx() },
                cap = StrokeCap.Round
            )
            val markerSize = with(density) { 6.dp.toPx() }
            val topMarker = androidx.compose.ui.graphics.Path().apply {
                moveTo(cursorX - markerSize, 0f)
                lineTo(cursorX + markerSize, 0f)
                lineTo(cursorX, markerSize * 1.35f)
                close()
            }
            drawPath(topMarker, color = tunaGreen)
        }

        val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

        var accumulatedBeats = 0f

        targetGroups.forEachIndexed { groupIndex, practiceTarget ->
            val noteCenterX = startMarginPx + groupIndex * noteSpacingPx
            val chordMidis = practiceTarget.midis
            val duration = practiceTarget.durationBeats

            val stemColor = when {
                correctStates.getOrNull(groupIndex) == true -> tunaGreen
                correctStates.getOrNull(groupIndex) == false -> Color.Red
                groupIndex == activeIndex -> Color(0xFF409EFF)
                else -> textColor
            }

            val steps = chordMidis.map { getStaffStep(it, instrument) }
            val minStep = steps.minOrNull() ?: 0
            val maxStep = steps.maxOrNull() ?: 0
            val isStemDown = maxStep >= 4

            val stemX = if (isStemDown) noteCenterX - noteWidth / 2f + 2f else noteCenterX + noteWidth / 2f - 2f
            val stemStartY = bottomLineY - (maxStep * stepHeight)
            val stemEndY = bottomLineY - (minStep * stepHeight) + (if (isStemDown) lineSpacing * 3.5f else -lineSpacing * 3.5f)

            val isChord = chordMidis.size > 1

            if (duration < 4f || isChord) {
                drawLine(color = stemColor, start = Offset(stemX, stemStartY), end = Offset(stemX, stemEndY), strokeWidth = 2.2f)

                if (duration <= 0.5f) {
                    val flagWidth = noteWidth * 1.2f
                    val flagHeight = lineSpacing * 2.8f
                    val dir = if (isStemDown) -1f else 1f

                    fun drawFlag(startY: Float) {
                        val path = androidx.compose.ui.graphics.Path().apply {
                            moveTo(stemX, startY)
                            cubicTo(
                                x1 = stemX + flagWidth * 0.25f, y1 = startY + dir * flagHeight * 0.25f,
                                x2 = stemX + flagWidth * 1.15f, y2 = startY + dir * flagHeight * 0.55f,
                                x3 = stemX + flagWidth * 0.05f, y3 = startY + dir * flagHeight
                            )
                            cubicTo(
                                x1 = stemX + flagWidth * 0.9f,  y1 = startY + dir * flagHeight * 0.7f,
                                x2 = stemX + flagWidth * 0.35f, y2 = startY + dir * flagHeight * 0.35f,
                                x3 = stemX,                     y3 = startY + dir * flagHeight * 0.15f
                            )
                            close()
                        }
                        drawPath(path = path, color = stemColor, style = androidx.compose.ui.graphics.drawscope.Fill)
                    }

                    drawFlag(stemEndY)
                    if (duration <= 0.25f) {
                        val flagSpacing = dir * lineSpacing * 0.9f
                        drawFlag(stemEndY + flagSpacing)
                    }
                }
            }

            chordMidis.forEach { midi ->
                val step = getStaffStep(midi, instrument)
                val noteCenterY = bottomLineY - (step * stepHeight)
                val ledgerWidth = noteWidth * 1.8f

                if (step < 0) {
                    for (s in -2 downTo step step 2) {
                        val ledgerY = bottomLineY - (s * stepHeight)
                        drawLine(color = textColor, start = Offset(noteCenterX - ledgerWidth / 2, ledgerY), end = Offset(noteCenterX + ledgerWidth / 2, ledgerY), strokeWidth = 3f)
                    }
                } else if (step > 8) {
                    for (s in 10..step step 2) {
                        val ledgerY = bottomLineY - (s * stepHeight)
                        drawLine(color = textColor, start = Offset(noteCenterX - ledgerWidth / 2, ledgerY), end = Offset(noteCenterX + ledgerWidth / 2, ledgerY), strokeWidth = 3f)
                    }
                }

                val isHit = hitMidis.contains(midi)
                val nextTargetMidi = if (!isWaitingForNext) chordMidis.firstOrNull { !hitMidis.contains(it) } else null
                val isNextTarget = (midi == nextTargetMidi)

                val individualNoteColor = when {
                    correctStates.getOrNull(groupIndex) == true -> tunaGreen
                    correctStates.getOrNull(groupIndex) == false -> Color.Red
                    groupIndex == activeIndex && isHit -> tunaGreen
                    groupIndex == activeIndex && isNextTarget -> Color.White
                    groupIndex == activeIndex -> Color(0xFF409EFF)
                    else -> textColor
                }

                rotate(degrees = -25f, pivot = Offset(noteCenterX, noteCenterY)) {
                    // Che con trỏ phía sau đầu nốt; cần thiết cả với nốt rỗng.
                    drawOval(
                        color = surfaceColor,
                        topLeft = Offset(noteCenterX - noteWidth * 0.58f, noteCenterY - noteHeight * 0.62f),
                        size = Size(noteWidth * 1.16f, noteHeight * 1.24f)
                    )
                    if (duration >= 2f) {
                        drawOval(color = individualNoteColor, topLeft = Offset(noteCenterX - noteWidth / 2, noteCenterY - noteHeight / 2), size = Size(noteWidth, noteHeight), style = Stroke(width = 3.2f))
                    } else {
                        drawOval(color = individualNoteColor, topLeft = Offset(noteCenterX - noteWidth / 2, noteCenterY - noteHeight / 2), size = Size(noteWidth, noteHeight))
                    }
                }
            }

            val labelPaint = android.graphics.Paint().apply {
                // Tên nốt cần dễ đọc dù khoảng cách giữa các nốt đã được thu nhỏ.
                textSize = with(density) { (if (showLyrics) 10.sp else 13.sp).toPx() }
                textAlign = android.graphics.Paint.Align.CENTER
                color = stemColor.toArgb()
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                isAntiAlias = true
            }

            val lowestNoteY = bottomLineY - (minStep * stepHeight)
            val defaultLabelY = bottomLineY + lineSpacing * 3.25f
            val labelY = maxOf(defaultLabelY, lowestNoteY + lineSpacing * 1.65f)

            if (showLyrics && practiceTarget.lyric.isNotEmpty()) {
                val label = practiceTarget.lyric
                if (groupIndex == playbackCursorIndex) {
                    val padX = with(density) { 3.dp.toPx() }
                    val padY = with(density) { 1.dp.toPx() }
                    val labelWidth = labelPaint.measureText(label) + padX * 2f
                    val labelHeight = labelPaint.textSize + padY * 2f
                    drawRoundRect(
                        color = surfaceColor,
                        topLeft = Offset(noteCenterX - labelWidth / 2f, labelY - labelHeight * 0.78f),
                        size = Size(labelWidth, labelHeight),
                        cornerRadius = CornerRadius(labelHeight * 0.20f, labelHeight * 0.20f)
                    )
                }
                drawContext.canvas.nativeCanvas.drawText(label, noteCenterX, labelY, labelPaint)
            } else if (!showLyrics && showNoteName) {
                val firstMidi = chordMidis.firstOrNull() ?: 60
                val noteName = noteNames[firstMidi % 12]
                if (groupIndex == playbackCursorIndex) {
                    val padX = with(density) { 3.dp.toPx() }
                    val padY = with(density) { 1.dp.toPx() }
                    val labelWidth = labelPaint.measureText(noteName) + padX * 2f
                    val labelHeight = labelPaint.textSize + padY * 2f
                    drawRoundRect(
                        color = surfaceColor,
                        topLeft = Offset(noteCenterX - labelWidth / 2f, labelY - labelHeight * 0.78f),
                        size = Size(labelWidth, labelHeight),
                        cornerRadius = CornerRadius(labelHeight * 0.20f, labelHeight * 0.20f)
                    )
                }
                drawContext.canvas.nativeCanvas.drawText(noteName, noteCenterX, labelY, labelPaint)
            }

            accumulatedBeats += duration
            val isMeasureEnd = (Math.round(accumulatedBeats * 100) % (timeSig * 100)) == 0

            if (isMeasureEnd && groupIndex < targetGroups.size - 1) {
                val barLineX = noteCenterX + noteSpacingPx / 2f
                drawLine(color = textColor.copy(alpha = 0.6f), start = Offset(barLineX, startY), end = Offset(barLineX, bottomLineY), strokeWidth = 3f)
            }
        }
    }
}


/**
 * TAB 6 dây/4 dây được căn chung trục X với khuông nhạc phía trên.
 * Mỗi PracticeTarget dùng cùng noteSpacingDp nên nốt trên khuông và số ngăn trên TAB
 * luôn nằm thẳng cột với nhau trong bố cục dọc.
 */
@Composable
fun RealGuitarTabDiagram(
    instrument: String,
    targetGroups: List<PracticeTarget>,
    activeIndex: Int,
    correctStates: List<Boolean?>,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    timeSig: Int = 4,
    noteSpacingDp: Dp = 60.dp,
    hitMidis: Set<Int> = emptySet(),
    playbackCursorIndex: Int = -1
) {
    if (targetGroups.isEmpty() || instrument == "Piano") return

    val numStrings = if (instrument == "Ukulele") 4 else 6
    val density = LocalDensity.current
    val noteSpacingPx = with(density) { noteSpacingDp.toPx() }
    val startMarginPx = with(density) { 84.dp.toPx() }
    val endMarginPx = with(density) { 40.dp.toPx() }
    val canvasWidthPx = startMarginPx + targetGroups.size * noteSpacingPx + endMarginPx
    val canvasWidthDp = with(density) { canvasWidthPx.toDp() }

    Canvas(
        modifier = Modifier
            .width(canvasWidthDp)
            .fillMaxHeight()
            .padding(horizontal = 8.dp)
    ) {
        val w = size.width
        val h = size.height
        val top = h * 0.16f
        val bottom = h * 0.84f
        val stringSpacing = if (numStrings > 1) (bottom - top) / (numStrings - 1) else 0f

        fun stringY(stringIndex: Int): Float = top + stringIndex.coerceIn(0, numStrings - 1) * stringSpacing

        for (stringIndex in 0 until numStrings) {
            drawLine(
                color = textColor.copy(alpha = 0.46f),
                start = Offset(0f, stringY(stringIndex)),
                end = Offset(w, stringY(stringIndex)),
                strokeWidth = 2f
            )
        }

        drawLine(
            color = textColor.copy(alpha = 0.55f),
            start = Offset(0f, top),
            end = Offset(0f, bottom),
            strokeWidth = 2.5f
        )
        drawLine(
            color = textColor.copy(alpha = 0.55f),
            start = Offset(w, top),
            end = Offset(w, bottom),
            strokeWidth = 2.5f
        )

        // Con trỏ nằm trên các dây TAB nhưng dưới nền và chữ số ngăn.
        if (playbackCursorIndex in targetGroups.indices) {
            val cursorX = startMarginPx + playbackCursorIndex * noteSpacingPx
            drawLine(
                color = tunaGreen.copy(alpha = 0.90f),
                start = Offset(cursorX, 0f),
                end = Offset(cursorX, h),
                strokeWidth = with(density) { 2.dp.toPx() },
                cap = StrokeCap.Round
            )
            val markerSize = with(density) { 6.dp.toPx() }
            val bottomMarker = androidx.compose.ui.graphics.Path().apply {
                moveTo(cursorX - markerSize, h)
                lineTo(cursorX + markerSize, h)
                lineTo(cursorX, h - markerSize * 1.35f)
                close()
            }
            drawPath(bottomMarker, color = tunaGreen)
        }

        var accumulatedBeats = 0f

        targetGroups.forEachIndexed { groupIndex, target ->
            val centerX = startMarginPx + groupIndex * noteSpacingPx
            val groupColor = when {
                correctStates.getOrNull(groupIndex) == true -> tunaGreen
                correctStates.getOrNull(groupIndex) == false -> Color(0xFFF56C6C)
                groupIndex == activeIndex -> Color(0xFF409EFF)
                else -> textColor
            }

            val validPositions = target.midis.mapNotNull { midi ->
                val position = getInstrumentNotePosition(midi, instrument)
                if (position.stringIdx in 0 until numStrings && position.fret >= 0) {
                    midi to position
                } else null
            }

            validPositions.forEachIndexed { positionIndex, (midi, position) ->
                val localOffset = (positionIndex - (validPositions.size - 1) / 2f) * 12f
                val x = centerX + localOffset
                val y = stringY(position.stringIdx)
                val isHit = hitMidis.contains(midi)
                val color = when {
                    correctStates.getOrNull(groupIndex) == true -> tunaGreen
                    correctStates.getOrNull(groupIndex) == false -> Color(0xFFF56C6C)
                    groupIndex == activeIndex && isHit -> tunaGreen
                    groupIndex == activeIndex -> Color(0xFF409EFF)
                    else -> groupColor
                }

                // Số ngăn trên TAB phải đủ lớn để đọc rõ trên màn hình dọc.
                // Dùng SP thay vì pixel cố định để không bị quá nhỏ trên máy có mật độ cao.
                val fretLabel = position.fret.toString()
                val fretPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    textSize = maxOf(
                        with(density) { 10.sp.toPx() },
                        stringSpacing * 0.88f
                    ).coerceAtMost(with(density) { 12.sp.toPx() })
                    this.color = color.toArgb()
                }
                val labelPaddingX = with(density) { 3.dp.toPx() }
                val labelPaddingY = with(density) { 1.5.dp.toPx() }
                val labelWidth = maxOf(
                    fretPaint.measureText(fretLabel) + labelPaddingX * 2f,
                    with(density) { 15.dp.toPx() }
                )
                val labelHeight = maxOf(
                    fretPaint.textSize + labelPaddingY * 2f,
                    with(density) { 17.dp.toPx() }
                )

                drawRoundRect(
                    color = if (groupIndex == playbackCursorIndex) {
                        surfaceColor
                    } else if (groupIndex == activeIndex || isHit) {
                        color.copy(alpha = 0.22f)
                    } else {
                        surfaceColor.copy(alpha = 0.82f)
                    },
                    topLeft = Offset(x - labelWidth / 2f, y - labelHeight / 2f),
                    size = Size(labelWidth, labelHeight),
                    cornerRadius = CornerRadius(labelHeight * 0.24f, labelHeight * 0.24f)
                )

                val baseline = y - (fretPaint.descent() + fretPaint.ascent()) / 2f
                drawContext.canvas.nativeCanvas.drawText(fretLabel, x, baseline, fretPaint)
            }

            accumulatedBeats += target.durationBeats
            val isMeasureEnd = (Math.round(accumulatedBeats * 100) % (timeSig * 100)) == 0
            if (isMeasureEnd && groupIndex < targetGroups.lastIndex) {
                val barLineX = centerX + noteSpacingPx / 2f
                drawLine(
                    color = textColor.copy(alpha = 0.55f),
                    start = Offset(barLineX, top),
                    end = Offset(barLineX, bottom),
                    strokeWidth = 2.5f
                )
            }
        }
    }
}




/**
 * Một hệ khuông nhạc + TAB thu gọn dành cho màn hình dọc.
 * Hai hệ có thể hiển thị đồng thời mà không cần cuộn ngang. Nốt trên khuông
 * và số ngăn trên TAB dùng chung một trục X nên luôn thẳng cột.
 */
@Composable
private fun CompactStaffTabSystem(
    instrument: String,
    targetGroups: List<PracticeTarget>,
    globalStartIndex: Int,
    activeGlobalIndex: Int,
    correctStates: List<Boolean?>,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    timeSig: Int,
    showNoteName: Boolean,
    showLyrics: Boolean,
    hitMidis: Set<Int>,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val numStrings = if (instrument == "Ukulele") 4 else 6
    val leftLabelPx = with(density) { if (instrument == "Piano") 34.dp.toPx() else 42.dp.toPx() }
    val rightPaddingPx = with(density) { 6.dp.toPx() }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        val contentLeft = leftLabelPx
        val contentRight = (w - rightPaddingPx).coerceAtLeast(contentLeft + 1f)
        val slots = targetGroups.size.coerceAtLeast(1)
        val slotWidth = (contentRight - contentLeft) / slots.toFloat()

        val staffTop = h * 0.10f
        val staffBottom = if (instrument == "Piano") h * 0.78f else h * 0.43f
        val lineSpacing = (staffBottom - staffTop) / 4f
        val stepHeight = lineSpacing / 2f
        val noteWidth = (lineSpacing * 1.10f).coerceAtLeast(5f)
        val noteHeight = (lineSpacing * 0.72f).coerceAtLeast(3.5f)

        // Khuông nhạc.
        for (line in 0..4) {
            val y = staffTop + line * lineSpacing
            drawLine(
                color = textColor.copy(alpha = 0.42f),
                start = Offset(0f, y),
                end = Offset(contentRight, y),
                strokeWidth = with(density) { 0.85.dp.toPx() }
            )
        }

        val clefPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.create(
                android.graphics.Typeface.SERIF,
                android.graphics.Typeface.NORMAL
            )
            textSize = lineSpacing * 4.05f
            color = textColor.copy(alpha = 0.88f).toArgb()
        }
        drawContext.canvas.nativeCanvas.drawText(
            "𝄞",
            leftLabelPx * 0.45f,
            staffTop + lineSpacing * 3.22f,
            clefPaint
        )

        fun getStaffStep(midi: Int): Int {
            val writtenMidi = if (instrument == "Guitar") midi + 12 else midi
            val stepOffsets = arrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
            val octave = (writtenMidi / 12) - 1
            val noteIndex = ((writtenMidi % 12) + 12) % 12
            val cStep = (octave - 4) * 7 - 2
            return cStep + stepOffsets[noteIndex]
        }

        val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val tabTop = h * 0.61f
        val tabBottom = h * 0.92f
        val tabStringSpacing = if (numStrings > 1) {
            (tabBottom - tabTop) / (numStrings - 1).toFloat()
        } else {
            0f
        }
        fun tabY(stringIndex: Int): Float = tabTop + stringIndex.coerceIn(0, numStrings - 1) * tabStringSpacing

        if (instrument != "Piano") {
            val tabLabelPaint = android.graphics.Paint().apply {
                isAntiAlias = true
                textAlign = android.graphics.Paint.Align.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                textSize = (tabStringSpacing * 0.72f).coerceIn(8f, 18f)
                color = textColor.copy(alpha = 0.72f).toArgb()
            }
            drawContext.canvas.nativeCanvas.drawText(
                "TAB",
                leftLabelPx * 0.45f,
                (tabTop + tabBottom) / 2f - (tabLabelPaint.descent() + tabLabelPaint.ascent()) / 2f,
                tabLabelPaint
            )

            for (stringIndex in 0 until numStrings) {
                drawLine(
                    color = textColor.copy(alpha = 0.38f),
                    start = Offset(0f, tabY(stringIndex)),
                    end = Offset(contentRight, tabY(stringIndex)),
                    strokeWidth = with(density) { 0.70.dp.toPx() }
                )
            }
        }

        var accumulatedBeats = 0f
        targetGroups.forEachIndexed { localIndex, target ->
            val globalIndex = globalStartIndex + localIndex
            val centerX = contentLeft + (localIndex + 0.5f) * slotWidth
            val state = correctStates.getOrNull(globalIndex)
            val groupActive = globalIndex == activeGlobalIndex
            val groupColor = when {
                state == true -> tunaGreen
                state == false -> Color(0xFFF56C6C)
                groupActive -> Color(0xFF409EFF)
                else -> textColor
            }

            val steps = target.midis.map(::getStaffStep)
            val minStep = steps.minOrNull() ?: 0
            val maxStep = steps.maxOrNull() ?: 0
            val stemDown = maxStep >= 4
            val stemX = if (stemDown) centerX - noteWidth / 2f else centerX + noteWidth / 2f
            val highestY = staffBottom - maxStep * stepHeight
            val lowestY = staffBottom - minStep * stepHeight

            if (target.durationBeats < 4f || target.midis.size > 1) {
                val stemEndY = if (stemDown) {
                    lowestY + lineSpacing * 2.55f
                } else {
                    highestY - lineSpacing * 2.55f
                }
                drawLine(
                    color = groupColor,
                    start = Offset(stemX, if (stemDown) highestY else lowestY),
                    end = Offset(stemX, stemEndY),
                    strokeWidth = with(density) { 1.05.dp.toPx() }
                )
            }

            target.midis.forEach { midi ->
                val step = getStaffStep(midi)
                val noteY = staffBottom - step * stepHeight
                val ledgerHalf = noteWidth * 0.95f

                if (step < 0) {
                    for (ledgerStep in -2 downTo step step 2) {
                        val ledgerY = staffBottom - ledgerStep * stepHeight
                        drawLine(
                            color = textColor.copy(alpha = 0.82f),
                            start = Offset(centerX - ledgerHalf, ledgerY),
                            end = Offset(centerX + ledgerHalf, ledgerY),
                            strokeWidth = with(density) { 0.85.dp.toPx() }
                        )
                    }
                } else if (step > 8) {
                    for (ledgerStep in 10..step step 2) {
                        val ledgerY = staffBottom - ledgerStep * stepHeight
                        drawLine(
                            color = textColor.copy(alpha = 0.82f),
                            start = Offset(centerX - ledgerHalf, ledgerY),
                            end = Offset(centerX + ledgerHalf, ledgerY),
                            strokeWidth = with(density) { 0.85.dp.toPx() }
                        )
                    }
                }

                val isHit = midi in hitMidis && groupActive
                val noteColor = when {
                    state == true -> tunaGreen
                    state == false -> Color(0xFFF56C6C)
                    isHit -> tunaGreen
                    groupActive -> Color(0xFF409EFF)
                    else -> textColor
                }
                rotate(-18f, Offset(centerX, noteY)) {
                    drawOval(
                        color = noteColor,
                        topLeft = Offset(centerX - noteWidth / 2f, noteY - noteHeight / 2f),
                        size = Size(noteWidth, noteHeight)
                    )
                }
            }

            if (showNoteName || (showLyrics && target.lyric.isNotBlank())) {
                val labelPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    textSize = (lineSpacing * 0.67f).coerceIn(7f, 14f)
                    color = groupColor.toArgb()
                }
                val label = if (showLyrics && target.lyric.isNotBlank()) {
                    target.lyric
                } else {
                    noteNames[((target.midis.firstOrNull() ?: 60) % 12 + 12) % 12]
                }
                val labelY = h * 0.545f
                drawContext.canvas.nativeCanvas.drawText(label, centerX, labelY, labelPaint)
            }

            if (instrument != "Piano") {
                val validPositions = target.midis.mapNotNull { midi ->
                    val position = getInstrumentNotePosition(midi, instrument)
                    if (position.stringIdx in 0 until numStrings && position.fret >= 0) {
                        midi to position
                    } else {
                        null
                    }
                }

                validPositions.forEachIndexed { positionIndex, (midi, position) ->
                    val xOffset = (positionIndex - (validPositions.size - 1) / 2f) *
                            minOf(slotWidth * 0.18f, with(density) { 5.dp.toPx() })
                    val x = centerX + xOffset
                    val y = tabY(position.stringIdx)
                    val isHit = midi in hitMidis && groupActive
                    val tabColor = when {
                        state == true -> tunaGreen
                        state == false -> Color(0xFFF56C6C)
                        isHit -> tunaGreen
                        groupActive -> Color(0xFF409EFF)
                        else -> textColor
                    }
                    val fretPaint = android.graphics.Paint().apply {
                        isAntiAlias = true
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        textSize = (tabStringSpacing * 0.76f).coerceIn(8f, 17f)
                        color = tabColor.toArgb()
                    }
                    drawRoundRect(
                        color = surfaceColor,
                        topLeft = Offset(x - fretPaint.textSize * 0.42f, y - fretPaint.textSize * 0.62f),
                        size = Size(fretPaint.textSize * 0.84f, fretPaint.textSize * 1.18f),
                        cornerRadius = CornerRadius(fretPaint.textSize * 0.20f, fretPaint.textSize * 0.20f)
                    )
                    drawContext.canvas.nativeCanvas.drawText(
                        position.fret.toString(),
                        x,
                        y - (fretPaint.descent() + fretPaint.ascent()) / 2f,
                        fretPaint
                    )
                }
            }

            accumulatedBeats += target.durationBeats
            val measureEnd = (Math.round(accumulatedBeats * 100) % (timeSig * 100)) == 0
            if (measureEnd && localIndex < targetGroups.lastIndex) {
                val barX = contentLeft + (localIndex + 1f) * slotWidth
                drawLine(
                    color = textColor.copy(alpha = 0.52f),
                    start = Offset(barX, staffTop),
                    end = Offset(barX, staffBottom),
                    strokeWidth = with(density) { 0.90.dp.toPx() }
                )
                if (instrument != "Piano") {
                    drawLine(
                        color = textColor.copy(alpha = 0.52f),
                        start = Offset(barX, tabTop),
                        end = Offset(barX, tabBottom),
                        strokeWidth = with(density) { 0.90.dp.toPx() }
                    )
                }
            }
        }
    }
}

/** Phần nhãn cố định bên trái cho khuông nhạc và TAB trong màn hình dọc. */
@Composable
private fun FixedStaffAndTabOverlay(
    instrument: String,
    textColor: Color,
    surfaceColor: Color,
    modifier: Modifier = Modifier
) {
    val numStrings = if (instrument == "Ukulele") 4 else 6

    Column(
        modifier = modifier
            .width(72.dp)
            .fillMaxHeight()
            .shadow(elevation = 10.dp, spotColor = Color.Black)
            .background(surfaceColor)
            // Phải dùng đúng cùng padding dọc với cột khuông + TAB có thể cuộn.
            // Nếu thiếu 4.dp này, chiều cao thực tế của hai vùng khác nhau nên
            // các dòng kẻ ở mép nối giữa overlay và Canvas sẽ bị lệch.
            .padding(vertical = 4.dp)
    ) {
        Box(modifier = Modifier.weight(1.35f).fillMaxWidth()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val lineSpacing = h / 13f
                val startY = h * 0.25f

                for (i in 0..4) {
                    val y = startY + i * lineSpacing
                    drawLine(
                        color = textColor.copy(alpha = 0.40f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 3f
                    )
                }

                val clefPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textSize = lineSpacing * 4.7f
                    textAlign = android.graphics.Paint.Align.CENTER
                    color = textColor.copy(alpha = 0.86f).toArgb()
                    typeface = android.graphics.Typeface.create(
                        android.graphics.Typeface.SERIF,
                        android.graphics.Typeface.NORMAL
                    )
                }
                drawContext.canvas.nativeCanvas.drawText(
                    "𝄞",
                    w * 0.50f,
                    startY + lineSpacing * 3.25f,
                    clefPaint
                )
            }
        }

        HorizontalDivider(color = textColor.copy(alpha = 0.10f), thickness = 1.dp)

        Box(modifier = Modifier.weight(0.80f).fillMaxWidth()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val top = h * 0.16f
                val bottom = h * 0.84f
                val gap = if (numStrings > 1) (bottom - top) / (numStrings - 1) else 0f

                for (i in 0 until numStrings) {
                    val y = top + i * gap
                    drawLine(
                        color = textColor.copy(alpha = 0.46f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 2f
                    )
                }

                val tabPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textSize = (h * 0.20f).coerceIn(18f, 28f)
                    textAlign = android.graphics.Paint.Align.CENTER
                    color = textColor.copy(alpha = 0.84f).toArgb()
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                }
                val baseline = h * 0.50f - (tabPaint.descent() + tabPaint.ascent()) / 2f
                drawContext.canvas.nativeCanvas.drawText("TAB", w * 0.50f, baseline, tabPaint)
            }
        }
    }
}


@Composable
private fun PracticeModePickerDialog(
    visible: Boolean,
    lang: String,
    items: List<Triple<String, String, String>>,
    currentPracticeType: String,
    currentReadingMode: String,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    onDismiss: () -> Unit,
    onSelected: (String, String) -> Unit
) {
    if (!visible) return

    fun descriptionFor(practiceType: String, readingMode: String): String {
        return when (practiceType to readingMode) {
            "NOTE" to "FREE" -> if (lang == "vi") {
                "Đọc và chơi từng nốt theo tốc độ của bạn."
            } else {
                "Read and play notes at your own pace."
            }

            "NOTE" to "RHYTHM" -> if (lang == "vi") {
                "Chơi đúng nốt theo BPM và con trỏ đang chạy."
            } else {
                "Play the correct notes with BPM and the moving cursor."
            }

            "CHORD" to "FREE" -> if (lang == "vi") {
                "Quan sát và luyện từng hợp âm không giới hạn thời gian."
            } else {
                "Study and practise chords without a time limit."
            }

            "CHORD" to "RHYTHM" -> if (lang == "vi") {
                "Bấm hoặc rải hợp âm đều theo nhịp đã chọn."
            } else {
                "Strum or arpeggiate chords at the selected tempo."
            }

            else -> if (lang == "vi") {
                "Luyện khuông nhạc, TAB, lời bài hát và vị trí trên cần đàn."
            } else {
                "Practise staff, TAB, lyrics and fretboard positions."
            }
        }
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 530.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = surfaceColor),
            border = BorderStroke(1.dp, textColor.copy(alpha = 0.12f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 13.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == "vi") "Chọn chế độ luyện" else "Choose practice mode",
                            color = textColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = if (lang == "vi") {
                                "Chọn một nội dung để mở trực tiếp màn luyện tập."
                            } else {
                                "Choose one mode to open its practice screen."
                            },
                            color = textColor.copy(alpha = 0.56f),
                            fontSize = 10.5.sp
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .background(textColor.copy(alpha = 0.06f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = textColor.copy(alpha = 0.82f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items.forEachIndexed { index, (practiceType, readingMode, label) ->
                        item(key = "$practiceType-$readingMode") {
                            val selected = practiceType == currentPracticeType &&
                                    readingMode == currentReadingMode
                            val rowShape = RoundedCornerShape(14.dp)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 62.dp)
                                    .clip(rowShape)
                                    .background(
                                        if (selected) tunaGreen.copy(alpha = 0.13f)
                                        else textColor.copy(alpha = 0.035f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (selected) tunaGreen.copy(alpha = 0.52f)
                                        else textColor.copy(alpha = 0.08f),
                                        shape = rowShape
                                    )
                                    .clickable {
                                        onSelected(practiceType, readingMode)
                                        onDismiss()
                                    }
                                    .padding(horizontal = 11.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (selected) tunaGreen
                                            else textColor.copy(alpha = 0.08f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = (index + 1).toString().padStart(2, '0'),
                                        color = if (selected) Color.White
                                        else textColor.copy(alpha = 0.70f),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = label,
                                        color = if (selected) tunaGreen else textColor,
                                        fontSize = 13.sp,
                                        lineHeight = 15.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        maxLines = 2,
                                        softWrap = true
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = descriptionFor(practiceType, readingMode),
                                        color = textColor.copy(alpha = 0.58f),
                                        fontSize = 10.sp,
                                        lineHeight = 13.sp,
                                        maxLines = 2,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.width(7.dp))

                                if (selected) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(tunaGreen),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "✓",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                } else {
                                    Text(
                                        text = "›",
                                        color = textColor.copy(alpha = 0.34f),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Light
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RealGuitarReadingPhase(
    instrument: String,
    lang: String,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    tunerViewModel: TunerViewModel,
    initialPracticeType: String = "NOTE",
    initialReadingMode: String = "FREE",
    initialAutoEvaluate: Boolean = false,
    onClose: () -> Unit
) {
    val basicMidis = remember(instrument) {
        when (instrument) {
            "Guitar" -> listOf(40, 41, 43, 45, 47, 48, 50, 52, 53, 55, 57, 59, 60, 62, 64, 65, 67)
            "Ukulele" -> listOf(60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 77, 79)
            "Piano" -> listOf(48, 50, 52, 53, 55, 57, 59, 60, 62, 64, 65, 67, 69, 71, 72)
            else -> listOf(60, 62, 64, 65, 67, 69, 71, 72)
        }
    }

    val basicChords = remember(instrument) {
        when (instrument) {
            "Guitar" -> listOf(
                listOf(48, 52, 55, 60, 64),
                listOf(43, 47, 50, 55, 59, 67),
                listOf(50, 57, 62, 66),
                listOf(45, 52, 57, 61, 64),
                listOf(40, 47, 52, 56, 59, 64),
                listOf(45, 52, 57, 60, 64),
                listOf(40, 47, 52, 55, 59, 64),
                listOf(50, 57, 62, 65)
            )
            "Ukulele" -> listOf(
                listOf(60, 64, 67, 72),
                listOf(62, 67, 71, 74),
                listOf(60, 65, 69),
                listOf(60, 64, 69)
            )
            "Piano" -> listOf(
                listOf(60, 64, 67),
                listOf(65, 69, 72),
                listOf(67, 71, 74),
                listOf(69, 72, 76)
            )
            else -> listOf(listOf(60, 64, 67))
        }
    }

    val safeInitialPracticeType = remember(initialPracticeType) {
        initialPracticeType.takeIf { it in setOf("NOTE", "CHORD", "SONG") } ?: "NOTE"
    }
    val safeInitialReadingMode = remember(initialReadingMode, safeInitialPracticeType) {
        if (safeInitialPracticeType == "SONG") "RHYTHM"
        else initialReadingMode.takeIf { it in setOf("FREE", "RHYTHM") } ?: "FREE"
    }

    var readingMode by remember(safeInitialReadingMode) { mutableStateOf(safeInitialReadingMode) }
    var practiceType by remember(safeInitialPracticeType) { mutableStateOf(safeInitialPracticeType) }

    fun generateRandomItem(type: String): PracticeTarget {
        return if (type == "NOTE") PracticeTarget(listOf(basicMidis.random()), 2f)
        else PracticeTarget(basicChords.random(), 1f)
    }

    val scaleMidis = remember(instrument) {
        if (instrument == "Guitar") listOf(48, 50, 52, 53, 55, 57, 59, 60)
        else listOf(60, 62, 64, 65, 67, 69, 71, 72)
    }

    val sequenceMidisForFreeMode = remember(instrument) {
        if (instrument == "Guitar") {
            listOf(48, 50, 52, 53, 55, 57, 59, 60, 59, 57, 55, 53, 52, 50, 48)
        } else {
            listOf(60, 62, 64, 65, 67, 69, 71, 72, 71, 69, 67, 65, 64, 62, 60)
        }
    }

    var freeSequence by remember { mutableStateOf(scaleMidis.map { PracticeTarget(listOf(it), 1f) }) }
    var activeFreeStep by remember { mutableIntStateOf(0) }
    var freeCorrectStates by remember { mutableStateOf(MutableList<Boolean?>(scaleMidis.size) { null }) }
    var lastStepChangeTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var consecutiveWrongCount by remember { mutableIntStateOf(0) }

    var deafUntil by remember { mutableLongStateOf(0L) }
    var currentHitMidis by remember { mutableStateOf(setOf<Int>()) }
    var isWaitingForNext by remember { mutableStateOf(false) }
    var lastStableMidi by remember { mutableIntStateOf(-1) }
    var stableMidiCount by remember { mutableIntStateOf(0) }

    var timeSig by remember { mutableIntStateOf(5) }
    var bpm by remember { mutableFloatStateOf(60f) }
    var isPlaying by remember { mutableStateOf(false) }
    var isAscending by remember { mutableStateOf(false) }
    var startCountdown by remember { mutableIntStateOf(0) }
    var countdownJob by remember { mutableStateOf<Job?>(null) }

    var isDemoPlaying by remember { mutableStateOf(false) }
    var demoJob by remember { mutableStateOf<Job?>(null) }

    var selectedSong by remember { mutableStateOf(builtInSongs[0]) }
    var isSongDropdownExpanded by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    var rhythmSequence by remember { mutableStateOf(List(timeSig) { generateRandomItem(practiceType) }) }
    var activeBeat by remember { mutableIntStateOf(0) }
    var rhythmCorrectStates by remember { mutableStateOf(MutableList<Boolean?>(timeSig) { null }) }

    fun cancelStartCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        startCountdown = 0
    }

    fun startPlaybackWithCountdown() {
        if (isPlaying || startCountdown > 0) return

        demoJob?.cancel()
        demoJob = null
        isDemoPlaying = false
        currentHitMidis = emptySet()
        cancelStartCountdown()

        countdownJob = coroutineScope.launch {
            for (value in 3 downTo 1) {
                startCountdown = value
                delay(1000L)
            }
            startCountdown = 0
            countdownJob = null
            isPlaying = true
        }
    }

    val context = LocalContext.current
    val activity = context as? Activity

    val detectedNoteName by tunerViewModel.noteName.collectAsState()
    val detectedOctave by tunerViewModel.octave.collectAsState()
    val detectedFreq by tunerViewModel.frequency.collectAsState()

    var showMicText by remember { mutableStateOf(true) }
    var showLyrics by remember(safeInitialPracticeType) { mutableStateOf(safeInitialPracticeType == "SONG") }
    var showNoteNames by remember { mutableStateOf(true) }
    var isFretboardVertical by remember { mutableStateOf(false) }
    var showChordTip by remember { mutableStateOf(false) }
    var isMenuVisible by remember { mutableStateOf(true) }
    var isModeDropdownExpanded by remember { mutableStateOf(false) }
    var isAutoEvaluate by remember(initialAutoEvaluate) { mutableStateOf(initialAutoEvaluate) }

    LaunchedEffect(practiceType) {
        if (practiceType == "CHORD") {
            showChordTip = true
            delay(3000L)
            showChordTip = false
        } else {
            showChordTip = false
        }
    }

    BackHandler {
        cancelStartCountdown()
        demoJob?.cancel()
        demoJob = null
        isDemoPlaying = false
        isPlaying = false
        onClose()
    }

    DisposableEffect(activity) {
        val previousOrientation = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        tunerViewModel.setAutoMode()
        tunerViewModel.startListening()
        onDispose {
            cancelStartCountdown()
            demoJob?.cancel()
            if (activity != null && previousOrientation != null) {
                activity.requestedOrientation = previousOrientation
            }
            tunerViewModel.stopListening()
        }
    }

    LaunchedEffect(instrument) {
        tunerViewModel.setInstrument("Chromatic")
    }

    LaunchedEffect(Unit) {
        delay(3000L)
        showMicText = false
    }

    LaunchedEffect(timeSig, isAscending, practiceType, readingMode, selectedSong, instrument) {
        cancelStartCountdown()
        isPlaying = false
        if (practiceType == "SONG") {
            bpm = selectedSong.recommendedBpm
            rhythmSequence = selectedSong.sequence
            rhythmCorrectStates = MutableList(selectedSong.sequence.size) { null }

            if (timeSig != selectedSong.timeSig) {
                timeSig = selectedSong.timeSig
            }
        } else {
            val newSequence = List(timeSig) { generateRandomItem(practiceType) }
            rhythmSequence = if (isAscending && practiceType == "NOTE") newSequence.sortedBy { it.midis.first() } else newSequence
            rhythmCorrectStates = MutableList(timeSig) { null }
        }

        val newFreeSeq = if (practiceType == "NOTE") {
            if (readingMode == "FREE") {
                sequenceMidisForFreeMode.map { PracticeTarget(listOf(it), 1f) }
            } else {
                scaleMidis.map { PracticeTarget(listOf(it), 1f) }
            }
        } else {
            basicChords.shuffled().take(4).map { PracticeTarget(it, 1f) }
        }
        freeSequence = newFreeSeq
        activeFreeStep = 0
        freeCorrectStates = MutableList<Boolean?>(freeSequence.size) { null }
        activeBeat = 0
        isDemoPlaying = false

        currentHitMidis = emptySet()
        deafUntil = 0L
    }

    LaunchedEffect(currentHitMidis) {
        if (currentHitMidis.isNotEmpty()) {
            isWaitingForNext = true
            delay(500L)
            isWaitingForNext = false
        } else {
            isWaitingForNext = false
        }
    }

    LaunchedEffect(detectedNoteName, detectedOctave, detectedFreq) {
        if (System.currentTimeMillis() < deafUntil) return@LaunchedEffect

        if (detectedFreq > 0f && detectedNoteName != "-") {
            val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
            val noteIdx = noteNames.indexOf(detectedNoteName)

            if (noteIdx != -1) {
                val detectedMidi = (detectedOctave + 1) * 12 + noteIdx
                val currentTarget = if (readingMode == "FREE") freeSequence.getOrNull(activeFreeStep) else rhythmSequence.getOrNull(activeBeat)

                if (currentTarget != null) {
                    val targetMidis = currentTarget.midis
                    val nextExpectedIndex = currentHitMidis.size

                    if (nextExpectedIndex < targetMidis.size) {
                        val nextExpectedMidi = targetMidis[nextExpectedIndex]

                        if (detectedMidi == nextExpectedMidi) {
                            currentHitMidis = currentHitMidis + detectedMidi
                        }
                    }
                }
            }
        }
    }

    LaunchedEffect(isPlaying, activeBeat, isAscending, timeSig, bpm, isDemoPlaying) {
        if (readingMode == "RHYTHM" && isPlaying && !isDemoPlaying && activeBeat < rhythmSequence.size) {
            val currentTarget = rhythmSequence[activeBeat]
            val msPerBeat = 60000f / bpm
            val targetDurationMs = (msPerBeat * currentTarget.durationBeats).toLong()

            delay(targetDurationMs)

            if (rhythmCorrectStates[activeBeat] == null) {
                val newStates = rhythmCorrectStates.toMutableList()
                newStates[activeBeat] = false
                rhythmCorrectStates = newStates
            }

            currentHitMidis = emptySet()

            if (activeBeat < rhythmSequence.size - 1) {
                activeBeat++
            } else {
                if (practiceType == "SONG") {
                    isPlaying = false
                    activeBeat = 0
                    rhythmCorrectStates = MutableList(rhythmSequence.size) { null }
                } else {
                    val newSequence = List(timeSig) { generateRandomItem(practiceType) }
                    rhythmSequence = if (isAscending && practiceType == "NOTE") newSequence.sortedBy { it.midis.first() } else newSequence
                    rhythmCorrectStates = MutableList(timeSig) { null }
                    activeBeat = 0
                }
            }
        }
    }

    LaunchedEffect(currentHitMidis, isDemoPlaying) {
        if (!isDemoPlaying && currentHitMidis.isNotEmpty()) {
            if (readingMode == "FREE") {
                if (activeFreeStep < freeSequence.size) {
                    val currentTarget = freeSequence[activeFreeStep]

                    if (currentHitMidis.containsAll(currentTarget.midis)) {
                        val now = System.currentTimeMillis()

                        if (now - lastStepChangeTime < 300L) return@LaunchedEffect

                        consecutiveWrongCount = 0
                        val newStates = freeCorrectStates.toMutableList()
                        newStates[activeFreeStep] = true
                        freeCorrectStates = newStates
                        playHitSound(context)

                        currentHitMidis = emptySet()

                        if (activeFreeStep < freeSequence.size - 1) {
                            activeFreeStep++
                            lastStepChangeTime = now
                        } else {
                            activeFreeStep++

                            coroutineScope.launch {
                                delay(400L)
                                activeFreeStep = 0
                                freeCorrectStates = MutableList(freeSequence.size) { null }
                                lastStepChangeTime = System.currentTimeMillis()
                            }
                        }
                    } else if (isAutoEvaluate && freeCorrectStates.getOrNull(activeFreeStep) == null) {
                        val now = System.currentTimeMillis()
                        if (now - lastStepChangeTime > 800L) {
                            consecutiveWrongCount++
                            if (consecutiveWrongCount >= 3) {
                                consecutiveWrongCount = 0

                                val newStates = freeCorrectStates.toMutableList()
                                newStates[activeFreeStep] = true
                                freeCorrectStates = newStates

                                playHitSound(context)
                                deafUntil = now + 800L

                                currentHitMidis = emptySet()

                                if (activeFreeStep < freeSequence.size - 1) {
                                    activeFreeStep++
                                    lastStepChangeTime = now
                                } else {
                                    activeFreeStep++
                                    coroutineScope.launch {
                                        delay(400L)
                                        activeFreeStep = 0
                                        freeCorrectStates = MutableList(freeSequence.size) { null }
                                        lastStepChangeTime = System.currentTimeMillis()
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (readingMode == "RHYTHM" && isPlaying && activeBeat < rhythmSequence.size) {
                val targetMidis = rhythmSequence[activeBeat].midis

                val isHit = if (practiceType == "CHORD" || practiceType == "SONG") {
                    currentHitMidis.contains(targetMidis.first())
                } else {
                    currentHitMidis.containsAll(targetMidis)
                }

                if (isHit && rhythmCorrectStates[activeBeat] != true) {
                    val now = System.currentTimeMillis()

                    val newStates = rhythmCorrectStates.toMutableList()
                    newStates[activeBeat] = true
                    rhythmCorrectStates = newStates

                    playHitSound(context)

                    currentHitMidis = emptySet()

                    val msPerBeat = (60000f / bpm).toLong()
                    deafUntil = now + msPerBeat
                }
            }
        }
    }

    val staffScrollState = rememberScrollState()
    val density = LocalDensity.current
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    // Thu nhỏ khoảng cách để cùng lúc nhìn thấy nhiều nốt hơn, nhưng vẫn giữ cuộn ngang.
    val noteSpacingDp = if (configuration.screenWidthDp < 380) 34.dp else 38.dp

    LaunchedEffect(activeBeat, activeFreeStep, isPlaying, isDemoPlaying, readingMode, noteSpacingDp) {
        val currentIndex = if (readingMode == "RHYTHM") activeBeat else activeFreeStep
        val shouldFollow = if (readingMode == "RHYTHM") {
            isPlaying || isDemoPlaying
        } else {
            currentIndex > 0
        }

        if (shouldFollow && currentIndex >= 0) {
            val targetScrollPx = with(density) {
                val noteX = 84.dp.toPx() + currentIndex * noteSpacingDp.toPx()
                val viewportCenter = configuration.screenWidthDp.dp.toPx() * 0.52f
                (noteX - viewportCenter).toInt()
            }
            staffScrollState.animateScrollTo(maxOf(0, targetScrollPx))
        } else if (activeBeat == 0 && activeFreeStep == 0) {
            staffScrollState.scrollTo(0)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        val compactHeight = configuration.screenHeightDp < 700
        val headerHeight = if (compactHeight) 44.dp else 50.dp
        val modeRowHeight = if (compactHeight) 40.dp else 44.dp
        val noteSpacingPortrait = noteSpacingDp

        val scoreSequence = if (readingMode == "FREE") freeSequence else rhythmSequence
        val scoreCorrectStates = if (readingMode == "FREE") freeCorrectStates else rhythmCorrectStates
        val scoreActiveIndex = if (readingMode == "FREE") {
            activeFreeStep
        } else if (isPlaying || isDemoPlaying) {
            activeBeat
        } else {
            -1
        }
        // Hiển thị con trỏ trên tất cả chế độ:
        // - Tự do: luôn bám bước đang chờ người dùng chơi.
        // - Theo nhịp/Bài hát: chỉ chạy khi đang Play hoặc phát mẫu.
        val scorePlaybackCursorIndex = when {
            readingMode == "FREE" && activeFreeStep in scoreSequence.indices -> activeFreeStep
            readingMode == "RHYTHM" && (isPlaying || isDemoPlaying) &&
                    activeBeat in scoreSequence.indices -> activeBeat
            else -> -1
        }
        val scoreWidthDp = with(density) {
            (
                    84.dp.toPx() +
                            scoreSequence.size * noteSpacingPortrait.toPx() +
                            40.dp.toPx()
                    ).toDp()
        }

        // Dùng nhãn một dòng đầy đủ thay vì chuỗi dịch cũ có ký tự xuống dòng
        // như "Nốt\n(Tự Do)". Khi Text chỉ cho 1 dòng, chuỗi đó bị hiển thị
        // thành "Nốt..." dù khung vẫn còn đủ chiều rộng.
        val isVietnameseUi = lang.startsWith("vi", ignoreCase = true)
        val modeItems = if (isVietnameseUi) {
            listOf(
                Triple("NOTE", "FREE", "Nốt tự do"),
                Triple("NOTE", "RHYTHM", "Nốt theo nhịp"),
                Triple("CHORD", "FREE", "Hợp âm tự do"),
                Triple("CHORD", "RHYTHM", "Hợp âm theo nhịp"),
                Triple("SONG", "RHYTHM", "Bài hát")
            )
        } else {
            listOf(
                Triple("NOTE", "FREE", "Notes - Free"),
                Triple("NOTE", "RHYTHM", "Notes - Rhythm"),
                Triple("CHORD", "FREE", "Chords - Free"),
                Triple("CHORD", "RHYTHM", "Chords - Rhythm"),
                Triple("SONG", "RHYTHM", "Song")
            )
        }
        val currentModeLabel = modeItems.firstOrNull {
            it.first == practiceType && it.second == readingMode
        }?.third ?: modeItems.first().third

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(headerHeight),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        cancelStartCountdown()
                        demoJob?.cancel()
                        demoJob = null
                        isDemoPlaying = false
                        isPlaying = false
                        onClose()
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .background(surfaceColor, CircleShape)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor)
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = CoreTranslator.getString("practice_sheet_real", lang),
                        color = textColor,
                        fontSize = if (compactHeight) 15.sp else 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$instrument · $currentModeLabel",
                        color = textColor.copy(alpha = 0.52f),
                        fontSize = when {
                            currentModeLabel.length >= 18 -> 8.5.sp
                            compactHeight -> 9.sp
                            else -> 10.sp
                        },
                        maxLines = 1,
                        softWrap = false
                    )
                }

                if (detectedFreq > 0f && detectedNoteName != "-") {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = tunaGreen.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, tunaGreen.copy(alpha = 0.40f))
                    ) {
                        Text(
                            text = "$detectedNoteName$detectedOctave",
                            color = tunaGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(5.dp))
                }

                IconButton(
                    onClick = { isMenuVisible = !isMenuVisible },
                    modifier = Modifier
                        .size(38.dp)
                        .background(surfaceColor, CircleShape)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = textColor)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(modeRowHeight),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .background(surfaceColor)
                            .border(1.dp, textColor.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
                            .clickable { isModeDropdownExpanded = true }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == "vi") "Chế độ luyện" else "Practice mode",
                                color = textColor.copy(alpha = 0.48f),
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = currentModeLabel,
                                color = textColor,
                                fontSize = if (currentModeLabel.length >= 18) 11.sp else 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = tunaGreen)
                    }
                }

                Row(
                    modifier = Modifier
                        .height(modeRowHeight)
                        .clip(RoundedCornerShape(12.dp))
                        .background(surfaceColor)
                        .border(1.dp, textColor.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
                        .clickable { isAutoEvaluate = !isAutoEvaluate }
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == "vi") "Tự động" else "Auto",
                        color = textColor.copy(alpha = 0.78f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Switch(
                        checked = isAutoEvaluate,
                        onCheckedChange = { isAutoEvaluate = it },
                        modifier = Modifier.scale(0.72f),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = tunaGreen,
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = textColor.copy(alpha = 0.14f)
                        )
                    )
                }
            }

            if (isMenuVisible) {
                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(13.dp),
                    colors = CardDefaults.cardColors(containerColor = surfaceColor),
                    border = BorderStroke(1.dp, textColor.copy(alpha = 0.08f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        if (practiceType == "SONG") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(36.dp)
                                            .clip(RoundedCornerShape(9.dp))
                                            .background(textColor.copy(alpha = 0.04f))
                                            .clickable { isSongDropdownExpanded = true }
                                            .padding(horizontal = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = selectedSong.name,
                                            color = textColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = textColor)
                                    }
                                    DropdownMenu(
                                        expanded = isSongDropdownExpanded,
                                        onDismissRequest = { isSongDropdownExpanded = false },
                                        modifier = Modifier.background(surfaceColor)
                                    ) {
                                        builtInSongs.forEach { song ->
                                            DropdownMenuItem(
                                                text = { Text(song.name, color = textColor) },
                                                onClick = {
                                                    selectedSong = song
                                                    isSongDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .height(36.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(textColor.copy(alpha = 0.04f))
                                        .clickable { showLyrics = !showLyrics }
                                        .padding(horizontal = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (lang == "vi") "Lời" else "Lyrics",
                                        color = textColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Switch(
                                        checked = showLyrics,
                                        onCheckedChange = { showLyrics = it },
                                        modifier = Modifier.scale(0.62f),
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = tunaGreen
                                        )
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        cancelStartCountdown()
                                        if (isDemoPlaying) {
                                            demoJob?.cancel()
                                            demoJob = null
                                            isDemoPlaying = false
                                            activeBeat = 0
                                            rhythmCorrectStates = MutableList(rhythmSequence.size) { null }
                                        } else {
                                            isPlaying = false
                                            isDemoPlaying = true
                                            activeBeat = 0
                                            rhythmCorrectStates = MutableList(rhythmSequence.size) { null }
                                            demoJob = coroutineScope.launch {
                                                val msPerBeat = 60000f / bpm
                                                for (i in rhythmSequence.indices) {
                                                    if (!isActive) break
                                                    activeBeat = i
                                                    val target = rhythmSequence[i]
                                                    val newStates = rhythmCorrectStates.toMutableList()
                                                    newStates[i] = true
                                                    rhythmCorrectStates = newStates
                                                    try {
                                                        CoreAudioPlayer.playChord(target.midis, instrument)
                                                    } catch (_: Exception) {
                                                    }
                                                    delay((msPerBeat * target.durationBeats).toLong())
                                                }
                                                isDemoPlaying = false
                                                activeBeat = 0
                                                rhythmCorrectStates = MutableList(rhythmSequence.size) { null }
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            if (isDemoPlaying) Color(0xFFF56C6C) else textColor.copy(alpha = 0.05f),
                                            CircleShape
                                        )
                                ) {
                                    Icon(
                                        imageVector = if (isDemoPlaying) Icons.Default.Stop else Icons.Default.VolumeUp,
                                        contentDescription = "Demo",
                                        tint = if (isDemoPlaying) Color.White else tunaGreen
                                    )
                                }
                            }
                        }

                        if (readingMode == "RHYTHM") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val nextTimeSig = if (timeSig >= 6) 2 else timeSig + 1
                                        timeSig = nextTimeSig
                                        bpm = when (nextTimeSig) {
                                            2 -> 80f
                                            3 -> 90f
                                            4 -> 60f
                                            5 -> 70f
                                            6 -> 80f
                                            else -> 60f
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = textColor.copy(alpha = 0.06f)),
                                    contentPadding = PaddingValues(horizontal = 9.dp),
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text(
                                        text = "$timeSig/4",
                                        color = textColor,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (practiceType != "SONG") {
                                    Row(
                                        modifier = Modifier
                                            .height(34.dp)
                                            .clip(RoundedCornerShape(9.dp))
                                            .background(textColor.copy(alpha = 0.04f))
                                            .clickable { isAscending = !isAscending }
                                            .padding(horizontal = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (lang == "vi") "Thấp → cao" else "Low → high",
                                            color = textColor,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Switch(
                                            checked = isAscending,
                                            onCheckedChange = { isAscending = it },
                                            modifier = Modifier.scale(0.60f),
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = tunaGreen
                                            )
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(textColor.copy(alpha = 0.04f))
                                        .padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${bpm.toInt()} BPM",
                                        color = textColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Slider(
                                        value = bpm,
                                        onValueChange = { bpm = it },
                                        valueRange = 40f..140f,
                                        modifier = Modifier.weight(1f),
                                        colors = SliderDefaults.colors(
                                            thumbColor = Color.White,
                                            activeTrackColor = tunaGreen,
                                            inactiveTrackColor = textColor.copy(alpha = 0.12f)
                                        )
                                    )
                                }

                                Button(
                                    onClick = {
                                        when {
                                            isPlaying -> isPlaying = false
                                            startCountdown > 0 -> cancelStartCountdown()
                                            else -> startPlaybackWithCountdown()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when {
                                            isPlaying -> Color(0xFFF56C6C)
                                            startCountdown > 0 -> Color(0xFFE6A23C)
                                            else -> tunaGreen
                                        }
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp),
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying || startCountdown > 0) {
                                            Icons.Default.Stop
                                        } else {
                                            Icons.Default.PlayArrow
                                        },
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = when {
                                            isPlaying -> CoreTranslator.getString("btn_stop_play", lang)
                                            startCountdown > 0 -> startCountdown.toString()
                                            else -> CoreTranslator.getString("btn_start_play", lang)
                                        },
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(textColor.copy(alpha = 0.04f))
                                        .clickable { showNoteNames = !showNoteNames }
                                        .padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (lang == "vi") "Hiện tên nốt" else "Show note names",
                                        color = textColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = showNoteNames,
                                        onCheckedChange = { showNoteNames = it },
                                        modifier = Modifier.scale(0.62f),
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = tunaGreen
                                        )
                                    )
                                }

                                Button(
                                    onClick = {
                                        if (practiceType == "NOTE") {
                                            freeSequence = sequenceMidisForFreeMode.map {
                                                PracticeTarget(listOf(it), 1f)
                                            }
                                        } else {
                                            freeSequence = basicChords.shuffled().take(4).map {
                                                PracticeTarget(it, 1f)
                                            }
                                        }
                                        activeFreeStep = 0
                                        freeCorrectStates = MutableList(freeSequence.size) { null }
                                        currentHitMidis = emptySet()
                                        deafUntil = 0L
                                        lastStepChangeTime = System.currentTimeMillis()
                                        consecutiveWrongCount = 0
                                        coroutineScope.launch { staffScrollState.scrollTo(0) }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                                    contentPadding = PaddingValues(horizontal = 11.dp),
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = CoreTranslator.getString("btn_next_step", lang),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(if (instrument == "Piano") 1.08f else if (isFretboardVertical) 0.96f else 1.22f),
                shape = RoundedCornerShape(15.dp),
                colors = CardDefaults.cardColors(containerColor = surfaceColor),
                border = BorderStroke(1.dp, textColor.copy(alpha = 0.08f))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(staffScrollState)
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Box(
                            modifier = Modifier
                                .width(scoreWidthDp)
                                .fillMaxHeight()
                        ) {

                            if (instrument == "Piano") {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    RealGuitarStaffDiagram(
                                        instrument = instrument,
                                        targetGroups = scoreSequence,
                                        activeIndex = scoreActiveIndex,
                                        correctStates = scoreCorrectStates,
                                        textColor = textColor,
                                        surfaceColor = surfaceColor,
                                        tunaGreen = tunaGreen,
                                        timeSig = timeSig,
                                        noteSpacingDp = noteSpacingPortrait,
                                        showLyrics = showLyrics,
                                        showNoteName = showNoteNames,
                                        hitMidis = currentHitMidis,
                                        isWaitingForNext = isWaitingForNext,
                                        playbackCursorIndex = scorePlaybackCursorIndex
                                    )
                                }
                            } else {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1.35f)
                                    ) {
                                        RealGuitarStaffDiagram(
                                            instrument = instrument,
                                            targetGroups = scoreSequence,
                                            activeIndex = scoreActiveIndex,
                                            correctStates = scoreCorrectStates,
                                            textColor = textColor,
                                            surfaceColor = surfaceColor,
                                            tunaGreen = tunaGreen,
                                            timeSig = timeSig,
                                            noteSpacingDp = noteSpacingPortrait,
                                            showLyrics = showLyrics,
                                            showNoteName = showNoteNames,
                                            hitMidis = currentHitMidis,
                                            isWaitingForNext = isWaitingForNext,
                                            playbackCursorIndex = scorePlaybackCursorIndex
                                        )
                                    }

                                    HorizontalDivider(
                                        color = textColor.copy(alpha = 0.10f),
                                        thickness = 1.dp
                                    )

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(0.80f)
                                    ) {
                                        RealGuitarTabDiagram(
                                            instrument = instrument,
                                            targetGroups = scoreSequence,
                                            activeIndex = scoreActiveIndex,
                                            correctStates = scoreCorrectStates,
                                            textColor = textColor,
                                            surfaceColor = surfaceColor,
                                            tunaGreen = tunaGreen,
                                            timeSig = timeSig,
                                            noteSpacingDp = noteSpacingPortrait,
                                            hitMidis = currentHitMidis,
                                            playbackCursorIndex = scorePlaybackCursorIndex
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (instrument == "Piano") {
                        FixedClefOverlay(textColor = textColor, surfaceColor = surfaceColor)
                    } else {
                        FixedStaffAndTabOverlay(
                            instrument = instrument,
                            textColor = textColor,
                            surfaceColor = surfaceColor
                        )
                    }

                    if (readingMode == "RHYTHM") {
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 5.dp, end = 6.dp)
                                .clip(RoundedCornerShape(50))
                                .background(surfaceColor.copy(alpha = 0.90f))
                                .border(1.dp, textColor.copy(alpha = 0.08f), RoundedCornerShape(50))
                                .padding(horizontal = 7.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val currentBeatInMeasure = if (practiceType == "SONG") {
                                var accumulatedBeats = 0f
                                for (j in 0 until activeBeat.coerceAtMost(rhythmSequence.size)) {
                                    accumulatedBeats += rhythmSequence[j].durationBeats
                                }
                                Math.round(accumulatedBeats).toInt() % timeSig
                            } else {
                                activeBeat % timeSig
                            }

                            for (i in 0 until timeSig) {
                                val isCurrentBeat = (isPlaying || isDemoPlaying) && i == currentBeatInMeasure
                                Box(
                                    modifier = Modifier
                                        .size(if (isCurrentBeat) 8.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isCurrentBeat) tunaGreen else textColor.copy(alpha = 0.18f)
                                        )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    // Ở hướng 12h, dành thêm chiều cao để tách riêng hàng tên dây,
                    // hàng nốt dây buông và mặt cần đàn mà không làm chúng đè lên nhau.
                    .weight(if (instrument == "Piano") 0.90f else if (isFretboardVertical) 1.72f else 1.12f),
                shape = RoundedCornerShape(15.dp),
                colors = CardDefaults.cardColors(containerColor = surfaceColor),
                border = BorderStroke(1.dp, textColor.copy(alpha = 0.08f))
            ) {
                val currentTargetGroup = if (readingMode == "FREE") {
                    freeSequence.getOrNull(activeFreeStep)
                } else {
                    rhythmSequence.getOrNull(activeBeat)
                }
                val noteNamesLocal = arrayOf(
                    "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
                )
                val activeMidis = currentTargetGroup?.midis ?: emptyList()

                val handleNoteClick: (Int) -> Unit = { clickedMidi ->
                    try {
                        CoreAudioPlayer.playChord(listOf(clickedMidi), instrument)
                    } catch (_: Exception) {
                    }

                    if (readingMode == "FREE" && practiceType == "NOTE") {
                        val matchedIndex = freeSequence.indexOfFirst { it.midis.contains(clickedMidi) }
                        if (matchedIndex != -1) {
                            val newStates = freeCorrectStates.toMutableList()
                            newStates[matchedIndex] = true
                            freeCorrectStates = newStates
                            activeFreeStep = matchedIndex

                            coroutineScope.launch {
                                delay(400L)
                                if (activeFreeStep < freeSequence.lastIndex) {
                                    activeFreeStep++
                                }
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            horizontal = if (isFretboardVertical) 4.dp else 8.dp,
                            vertical = if (isFretboardVertical) 3.dp else 6.dp
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isFretboardVertical) 22.dp else 27.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (instrument == "Piano") {
                                if (lang == "vi") "Vị trí trên phím đàn" else "Keyboard position"
                            } else {
                                if (lang == "vi") "Vị trí trên cần đàn" else "Fretboard position"
                            },
                            color = textColor,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.weight(1f))

                        val isCurrentCorrect = if (readingMode == "FREE") {
                            freeCorrectStates.getOrNull(activeFreeStep) == true
                        } else {
                            rhythmCorrectStates.getOrNull(activeBeat) == true
                        }
                        val statusText = when {
                            isCurrentCorrect -> CoreTranslator.getString("status_correct", lang)
                            detectedFreq > 0f && detectedNoteName != "-" -> "$detectedNoteName$detectedOctave"
                            else -> if (lang == "vi") "Đang nghe..." else "Listening..."
                        }
                        // Ở hướng 12h bỏ dòng trạng thái tại đây để dành tối đa không gian
                        // cho cần đàn; trạng thái microphone vẫn còn ở thanh dưới màn hình.
                        if (!isFretboardVertical) {
                            Text(
                                text = statusText,
                                color = if (isCurrentCorrect) tunaGreen else textColor.copy(alpha = 0.64f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }

                        if (instrument != "Piano") {
                            Spacer(modifier = Modifier.width(6.dp))
                            Row(
                                modifier = Modifier
                                    .height(24.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(tunaGreen.copy(alpha = 0.10f))
                                    .border(
                                        1.dp,
                                        tunaGreen.copy(alpha = 0.34f),
                                        RoundedCornerShape(50)
                                    )
                                    .clickable {
                                        isFretboardVertical = !isFretboardVertical
                                    }
                                    .padding(horizontal = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = if (isFretboardVertical) {
                                        if (lang == "vi") "Xoay cần đàn về hướng 9 giờ" else "Rotate fretboard to 9 o'clock"
                                    } else {
                                        if (lang == "vi") "Xoay cần đàn sang hướng 12 giờ" else "Rotate fretboard to 12 o'clock"
                                    },
                                    tint = tunaGreen,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = if (isFretboardVertical) "9h" else "12h",
                                    color = tunaGreen,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        if (instrument == "Piano") {
                            val targetPosList = if (readingMode == "FREE" && practiceType == "NOTE") {
                                freeSequence
                                    .flatMap { it.midis }
                                    .distinct()
                                    .map { NotePosition(noteNamesLocal[it % 12], midi = it) }
                            } else {
                                currentTargetGroup?.midis?.map {
                                    NotePosition(noteNamesLocal[it % 12], midi = it)
                                } ?: emptyList()
                            }
                            SingleNotePianoDiagram(
                                targetNotes = targetPosList,
                                showName = true,
                                textColor = textColor,
                                tunaGreen = tunaGreen,
                                activeMidis = activeMidis,
                                onNoteClick = handleNoteClick
                            )
                        } else {
                            val targetPosList = remember(scoreSequence, instrument) {
                                scoreSequence
                                    .flatMap { it.midis }
                                    .distinct()
                                    .map { getInstrumentNotePosition(it, instrument) }
                                    .distinctBy { Triple(it.stringIdx, it.fret, it.midi) }
                            }
                            SingleNoteFretboardDiagramCompact(
                                instrument = instrument,
                                targetNotes = targetPosList,
                                hitMidis = currentHitMidis,
                                showName = true,
                                textColor = textColor,
                                tunaGreen = tunaGreen,
                                activeMidis = activeMidis,
                                verticalOrientation = isFretboardVertical,
                                modifier = Modifier.fillMaxSize(),
                                onNoteClick = handleNoteClick
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(5.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(surfaceColor)
                    .border(1.dp, textColor.copy(alpha = 0.08f), RoundedCornerShape(11.dp))
                    .padding(horizontal = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = if (detectedFreq > 0f) tunaGreen else textColor.copy(alpha = 0.42f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (detectedFreq > 0f && detectedNoteName != "-") {
                        if (lang == "vi") {
                            "Mic đang nghe: $detectedNoteName$detectedOctave · ${"%.1f".format(detectedFreq)} Hz"
                        } else {
                            "Mic: $detectedNoteName$detectedOctave · ${"%.1f".format(detectedFreq)} Hz"
                        }
                    } else {
                        CoreTranslator.getString("listening_mic", lang)
                    },
                    color = textColor.copy(alpha = 0.74f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
        }

        PracticeModePickerDialog(
            visible = isModeDropdownExpanded,
            lang = lang,
            items = modeItems,
            currentPracticeType = practiceType,
            currentReadingMode = readingMode,
            surfaceColor = surfaceColor,
            textColor = textColor,
            tunaGreen = tunaGreen,
            onDismiss = { isModeDropdownExpanded = false },
            onSelected = { pType, rMode ->
                cancelStartCountdown()
                demoJob?.cancel()
                demoJob = null
                isDemoPlaying = false
                isPlaying = false
                practiceType = pType
                readingMode = rMode
            }
        )

        if (showMicText) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = CoreTranslator.getString("listening_mic", lang),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.72f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 22.dp, vertical = 11.dp)
                )
            }
        }

        if (showChordTip) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = CoreTranslator.getString("tip_arpeggio", lang),
                    color = Color(0xFFF2C94C),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.86f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 22.dp, vertical = 14.dp)
                )
            }
        }

        if (startCountdown > 0) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.size(78.dp),
                    shape = CircleShape,
                    color = surfaceColor.copy(alpha = 0.96f),
                    border = BorderStroke(2.dp, tunaGreen),
                    shadowElevation = 8.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = startCountdown.toString(),
                            color = tunaGreen,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SingleNoteFretboardDiagramCompact(
    instrument: String,
    targetNotes: List<NotePosition>,
    hitMidis: Set<Int> = emptySet(),
    showName: Boolean,
    textColor: Color,
    tunaGreen: Color,
    activeMidis: List<Int> = emptyList(),
    verticalOrientation: Boolean = false,
    modifier: Modifier = Modifier,
    onNoteClick: ((Int) -> Unit)? = null
) {
    if (verticalOrientation) {
        SingleNoteFretboardDiagramVertical(
            instrument = instrument,
            targetNotes = targetNotes,
            hitMidis = hitMidis,
            showName = showName,
            textColor = textColor,
            tunaGreen = tunaGreen,
            activeMidis = activeMidis,
            modifier = modifier,
            onNoteClick = onNoteClick
        )
        return
    }

    val isUkulele = instrument == "Ukulele"
    val stringNumbers = if (isUkulele) {
        listOf(4, 3, 2, 1)
    } else {
        listOf(6, 5, 4, 3, 2, 1)
    }
    val stringNames = if (isUkulele) {
        mapOf(4 to "G", 3 to "C", 2 to "E", 1 to "A")
    } else {
        mapOf(6 to "E", 5 to "A", 4 to "D", 3 to "G", 2 to "B", 1 to "e")
    }
    val density = LocalDensity.current

    val visibleNotes = remember(targetNotes, stringNumbers) {
        targetNotes.filter { note ->
            note.stringIdx in 0 until stringNumbers.size && note.fret >= 0
        }
    }
    val positiveFrets = remember(visibleNotes) {
        visibleNotes.map { it.fret }.filter { it > 0 }
    }
    // Chỉ dùng đúng vùng ngăn có nốt trong bài tập, không kéo dài mặc định 1-12.
    val visibleStartFret = positiveFrets.minOrNull() ?: 1
    val visibleEndFret = positiveFrets.maxOrNull() ?: visibleStartFret
    val fretCount = (visibleEndFret - visibleStartFret + 1).coerceAtLeast(1)
    val hasOpenNotes = visibleNotes.any { it.fret == 0 }

    val activeStringNumbers = remember(visibleNotes, activeMidis) {
        visibleNotes
            .filter { it.midi in activeMidis }
            .map { it.stringIdx + 1 }
            .toSet()
    }

    val labelAreaPx = with(density) { 35.dp.toPx() }
    val openAreaPx = with(density) { if (hasOpenNotes) 21.dp.toPx() else 5.dp.toPx() }
    val rightPaddingPx = with(density) { 7.dp.toPx() }
    val topPaddingPx = with(density) { 5.dp.toPx() }
    val bottomLabelPx = with(density) { 28.dp.toPx() }
    val maxRadiusPx = with(density) { 13.dp.toPx() }
    val maxTextPx = with(density) { 9.sp.toPx() }

    Canvas(
        modifier = modifier
            .padding(horizontal = 2.dp, vertical = 1.dp)
            .pointerInput(
                visibleNotes,
                visibleStartFret,
                visibleEndFret,
                activeMidis,
                hitMidis,
                onNoteClick
            ) {
                detectTapGestures { tap ->
                    if (onNoteClick == null || size.width <= 0f || size.height <= 0f) {
                        return@detectTapGestures
                    }

                    val neckLeft = labelAreaPx + openAreaPx
                    val neckRight = (size.width - rightPaddingPx).coerceAtLeast(neckLeft + 1f)
                    val neckTop = topPaddingPx
                    val neckBottom = (size.height - bottomLabelPx).coerceAtLeast(neckTop + 1f)
                    val stringSpacing = if (stringNumbers.size > 1) {
                        (neckBottom - neckTop) / (stringNumbers.size - 1).toFloat()
                    } else {
                        neckBottom - neckTop
                    }
                    val fretSpacing = (neckRight - neckLeft) / fretCount.toFloat()

                    fun yForString(stringNumber: Int): Float {
                        val row = stringNumbers.indexOf(stringNumber).coerceAtLeast(0)
                        return neckTop + row * stringSpacing
                    }

                    fun xForFret(fret: Int): Float {
                        return if (fret == 0) {
                            neckLeft - openAreaPx * 0.52f
                        } else {
                            neckLeft + (fret - visibleStartFret + 0.5f) * fretSpacing
                        }
                    }

                    val hitRadius = minOf(
                        stringSpacing * 0.58f,
                        fretSpacing * 0.42f,
                        with(density) { 20.dp.toPx() }
                    ).coerceAtLeast(with(density) { 9.dp.toPx() })

                    visibleNotes
                        .sortedByDescending { note ->
                            when {
                                note.midi in activeMidis -> 3
                                note.midi in hitMidis -> 2
                                else -> 1
                            }
                        }
                        .firstOrNull { note ->
                            val center = Offset(
                                xForFret(note.fret),
                                yForString(note.stringIdx + 1)
                            )
                            Math.hypot(
                                (tap.x - center.x).toDouble(),
                                (tap.y - center.y).toDouble()
                            ) <= hitRadius
                        }
                        ?.let { onNoteClick(it.midi) }
                }
            }
    ) {
        if (size.width <= 0f || size.height <= 0f) return@Canvas

        val neckLeft = labelAreaPx + openAreaPx
        val neckRight = (size.width - rightPaddingPx).coerceAtLeast(neckLeft + 1f)
        val neckTop = topPaddingPx
        val neckBottom = (size.height - bottomLabelPx).coerceAtLeast(neckTop + 1f)
        val stringSpacing = if (stringNumbers.size > 1) {
            (neckBottom - neckTop) / (stringNumbers.size - 1).toFloat()
        } else {
            neckBottom - neckTop
        }
        val fretSpacing = (neckRight - neckLeft) / fretCount.toFloat()

        fun yForString(stringNumber: Int): Float {
            val row = stringNumbers.indexOf(stringNumber).coerceAtLeast(0)
            return neckTop + row * stringSpacing
        }

        fun xForFret(fret: Int): Float {
            return if (fret == 0) {
                neckLeft - openAreaPx * 0.52f
            } else {
                neckLeft + (fret - visibleStartFret + 0.5f) * fretSpacing
            }
        }

        val woodTop = neckTop - stringSpacing * 0.36f
        val woodBottom = neckBottom + stringSpacing * 0.36f
        val corner = with(density) { 8.dp.toPx() }

        // Mặt cần đàn nằm ngang; tên dây đặt ở mép trái hướng 9 giờ.
        drawRoundRect(
            color = Color(0xFF191615),
            topLeft = Offset(neckLeft, woodTop),
            size = Size(neckRight - neckLeft, woodBottom - woodTop),
            cornerRadius = CornerRadius(corner, corner)
        )
        for (column in 0 until fretCount) {
            val x = neckLeft + column * fretSpacing
            drawRect(
                color = if (column % 2 == 0) {
                    Color(0xFF251E1B)
                } else {
                    Color(0xFF1D1918)
                },
                topLeft = Offset(x, woodTop),
                size = Size(fretSpacing, woodBottom - woodTop)
            )
        }

        // Chấm định vị ở đúng ngăn thực tế.
        val markerFrets = setOf(3, 5, 7, 9, 12, 15, 17, 19)
        val markerRadius = minOf(
            with(density) { 3.dp.toPx() },
            minOf(fretSpacing, woodBottom - woodTop) * 0.10f
        ).coerceAtLeast(with(density) { 1.5.dp.toPx() })
        for (fret in visibleStartFret..visibleEndFret) {
            if (fret !in markerFrets) continue
            val x = xForFret(fret)
            if (fret % 12 == 0 && stringNumbers.size >= 4) {
                drawCircle(
                    color = textColor.copy(alpha = 0.25f),
                    radius = markerRadius,
                    center = Offset(x, neckTop + (neckBottom - neckTop) * 0.38f)
                )
                drawCircle(
                    color = textColor.copy(alpha = 0.25f),
                    radius = markerRadius,
                    center = Offset(x, neckTop + (neckBottom - neckTop) * 0.62f)
                )
            } else {
                drawCircle(
                    color = textColor.copy(alpha = 0.23f),
                    radius = markerRadius,
                    center = Offset(x, (neckTop + neckBottom) / 2f)
                )
            }
        }

        // Thanh nut và thanh phím nằm dọc.
        for (line in 0..fretCount) {
            val x = neckLeft + line * fretSpacing
            drawLine(
                color = if (line == 0) {
                    Color(0xFFE5C986)
                } else {
                    Color(0xFFC2C6CA).copy(alpha = 0.72f)
                },
                start = Offset(x, woodTop),
                end = Offset(x, woodBottom),
                strokeWidth = if (line == 0) {
                    with(density) { 3.2.dp.toPx() }
                } else {
                    with(density) { 0.9.dp.toPx() }
                },
                cap = StrokeCap.Round
            )
        }

        val bassColor = Color(0xFFC78A4D)
        val trebleColor = Color(0xFFD8DCE0)
        stringNumbers.forEach { stringNumber ->
            val y = yForString(stringNumber)
            val active = stringNumber in activeStringNumbers
            val widthDp = if (isUkulele) {
                when (stringNumber) {
                    3 -> 1.55f
                    4 -> 1.10f
                    else -> 1.30f
                }
            } else {
                when (stringNumber) {
                    6 -> 2.20f
                    5 -> 1.90f
                    4 -> 1.60f
                    3 -> 1.22f
                    2 -> 0.96f
                    else -> 0.76f
                }
            }
            val normalColor = if (isUkulele) {
                textColor.copy(alpha = 0.66f)
            } else if (stringNumber >= 4) {
                bassColor
            } else {
                trebleColor
            }
            drawLine(
                color = if (active) Color(0xFF409EFF) else normalColor,
                start = Offset(neckLeft, y),
                end = Offset(neckRight, y),
                strokeWidth = with(density) {
                    (widthDp + if (active) 0.25f else 0f).dp.toPx()
                },
                cap = StrokeCap.Round
            )
        }

        // Nhãn 6E, 5A, 4D, 3G, 2B, 1e nằm bên trái (hướng 9 giờ).
        val stringPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textSize = with(density) { 8.5.sp.toPx() }
        }
        val labelRadius = minOf(
            stringSpacing * 0.38f,
            with(density) { 10.dp.toPx() }
        ).coerceAtLeast(with(density) { 6.dp.toPx() })
        val labelX = labelAreaPx * 0.47f
        stringNumbers.forEach { stringNumber ->
            val active = stringNumber in activeStringNumbers
            val center = Offset(labelX, yForString(stringNumber))
            drawCircle(
                color = if (active) {
                    Color(0xFF409EFF).copy(alpha = 0.16f)
                } else {
                    textColor.copy(alpha = 0.06f)
                },
                radius = labelRadius,
                center = center
            )
            drawCircle(
                color = if (active) Color(0xFF409EFF) else textColor.copy(alpha = 0.28f),
                radius = labelRadius,
                center = center,
                style = Stroke(width = with(density) { 0.8.dp.toPx() })
            )
            stringPaint.color = if (active) Color(0xFF409EFF).toArgb() else textColor.toArgb()
            val label = "$stringNumber${stringNames[stringNumber].orEmpty()}"
            drawContext.canvas.nativeCanvas.drawText(
                label,
                center.x,
                center.y - (stringPaint.descent() + stringPaint.ascent()) / 2f,
                stringPaint
            )
        }

        // Số ngăn nằm hẳn bên dưới mặt cần đàn. Chừa vùng đáy lớn hơn để
        // số không bị nốt ở dây 1 hoặc mép Card che khuất.
        val fretPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textSize = with(density) { 9.sp.toPx() }
            color = textColor.copy(alpha = 0.72f).toArgb()
        }
        val fretNumberBaseline = size.height - with(density) { 2.dp.toPx() }
        for (fret in visibleStartFret..visibleEndFret) {
            drawContext.canvas.nativeCanvas.drawText(
                fret.toString(),
                xForFret(fret),
                fretNumberBaseline,
                fretPaint
            )
        }

        val noteRadius = minOf(
            stringSpacing * 0.40f,
            fretSpacing * 0.22f,
            maxRadiusPx
        ).coerceAtLeast(with(density) { 4.5.dp.toPx() })

        visibleNotes
            .sortedBy { note ->
                when {
                    note.midi in activeMidis -> 3
                    note.midi in hitMidis -> 2
                    else -> 1
                }
            }
            .forEach { note ->
                val center = Offset(
                    xForFret(note.fret),
                    yForString(note.stringIdx + 1)
                )
                val active = note.midi in activeMidis
                val hit = note.midi in hitMidis
                val radius = when {
                    active -> noteRadius * 1.12f
                    hit -> noteRadius
                    else -> noteRadius * 0.90f
                }

                if (active) {
                    drawCircle(
                        color = Color(0xFF409EFF).copy(alpha = 0.16f),
                        radius = radius * 1.50f,
                        center = center
                    )
                }

                if (note.fret == 0 && !active && !hit) {
                    drawCircle(
                        color = textColor.copy(alpha = 0.84f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = with(density) { 1.2.dp.toPx() })
                    )
                } else {
                    drawCircle(
                        color = when {
                            hit -> tunaGreen
                            active -> Color(0xFF409EFF)
                            activeMidis.isEmpty() -> textColor.copy(alpha = 0.48f)
                            else -> textColor.copy(alpha = 0.28f)
                        },
                        radius = radius,
                        center = center
                    )
                }

                if (active && !hit) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.74f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = with(density) { 0.8.dp.toPx() })
                    )
                }

                val notePaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    textSize = minOf(maxTextPx, radius * 1.05f)
                    color = when {
                        hit || active -> android.graphics.Color.WHITE
                        note.fret == 0 -> textColor.toArgb()
                        activeMidis.isEmpty() -> android.graphics.Color.WHITE
                        else -> android.graphics.Color.rgb(54, 57, 60)
                    }
                }
                val label = if (showName) note.name else "?"
                drawContext.canvas.nativeCanvas.drawText(
                    label,
                    center.x,
                    center.y - (notePaint.descent() + notePaint.ascent()) / 2f,
                    notePaint
                )
            }
    }
}


private data class VerticalFretboardBounds(
    val neckLeft: Float,
    val neckRight: Float,
    val neckTop: Float,
    val neckBottom: Float
)

@Composable
private fun SingleNoteFretboardDiagramVertical(
    instrument: String,
    targetNotes: List<NotePosition>,
    hitMidis: Set<Int>,
    showName: Boolean,
    textColor: Color,
    tunaGreen: Color,
    activeMidis: List<Int>,
    modifier: Modifier = Modifier,
    onNoteClick: ((Int) -> Unit)? = null
) {
    val isUkulele = instrument == "Ukulele"
    val stringNumbers = if (isUkulele) {
        listOf(4, 3, 2, 1)
    } else {
        listOf(6, 5, 4, 3, 2, 1)
    }
    val stringNames = if (isUkulele) {
        mapOf(4 to "G", 3 to "C", 2 to "E", 1 to "A")
    } else {
        mapOf(6 to "E", 5 to "A", 4 to "D", 3 to "G", 2 to "B", 1 to "e")
    }
    val density = LocalDensity.current

    val visibleNotes = remember(targetNotes, stringNumbers) {
        targetNotes.filter { note ->
            note.stringIdx in 0 until stringNumbers.size && note.fret >= 0
        }
    }
    val positiveFrets = remember(visibleNotes) {
        visibleNotes.map { it.fret }.filter { it > 0 }
    }
    val visibleStartFret = positiveFrets.minOrNull() ?: 1
    val visibleEndFret = positiveFrets.maxOrNull() ?: visibleStartFret
    val fretCount = (visibleEndFret - visibleStartFret + 1).coerceAtLeast(1)
    val hasOpenNotes = visibleNotes.any { it.fret == 0 }

    val activeStringNumbers = remember(visibleNotes, activeMidis) {
        visibleNotes
            .filter { it.midi in activeMidis }
            .map { it.stringIdx + 1 }
            .toSet()
    }

    // Thu gọn vùng nhãn và padding để mặt cần đàn tận dụng tốt khoảng trống
    // phía trên và hai bên của Card khi hiển thị theo hướng 12 giờ.
    val leftLabelPx = with(density) { 19.dp.toPx() }
    val rightPaddingPx = with(density) { 2.dp.toPx() }
    // Hướng 12h dùng hai dải riêng biệt ở phía trên:
    // 1) hàng ký hiệu dây 6E..1e; 2) hàng nốt dây buông.
    // Khoảng tách này ngăn vòng tròn nốt đè lên ký hiệu dây.
    val topLabelPx = with(density) { 29.dp.toPx() }
    val openAreaPx = with(density) { if (hasOpenNotes) 30.dp.toPx() else 3.dp.toPx() }
    val bottomPaddingPx = with(density) { 2.dp.toPx() }
    val maxRadiusPx = with(density) { 17.dp.toPx() }
    val maxTextPx = with(density) { 11.sp.toPx() }

    // Ở hướng 12 giờ, không kéo mặt cần đàn tràn toàn bộ chiều ngang của Card.
    // Giữ tỷ lệ dọc gần giống một phiên bản xoay 90 độ của hướng 9 giờ:
    // cần đàn cao, hẹp và được căn giữa. Nếu vùng chứa thấp, toàn bộ cần đàn
    // được thu nhỏ đồng đều thay vì bị ép dẹt theo chiều cao.
    fun calculateVerticalBounds(width: Float, height: Float): VerticalFretboardBounds {
        val availableLeft = leftLabelPx + with(density) { 2.dp.toPx() }
        val availableRight = (width - rightPaddingPx).coerceAtLeast(availableLeft + 1f)
        val availableTop = topLabelPx + openAreaPx
        val availableBottom = (height - bottomPaddingPx).coerceAtLeast(availableTop + 1f)

        val availableWidth = (availableRight - availableLeft).coerceAtLeast(1f)
        val availableHeight = (availableBottom - availableTop).coerceAtLeast(1f)

        // Khoảng cách giữa hai ngăn theo chiều dọc lớn hơn khoảng cách giữa
        // hai dây. Tỷ lệ này tạo cảm giác giống đúng mặt cần đàn ở hướng 9h
        // sau khi xoay sang 12h, thay vì một hình chữ nhật ngang bị bóp.
        val stringGapCount = (stringNumbers.size - 1).coerceAtLeast(1).toFloat()
        // Giữ tỷ lệ dọc tự nhiên nhưng mở rộng đáng kể theo chiều ngang.
        // Với 4-5 ngăn, mặt cần đàn sẽ chiếm khoảng 70-85% chiều cao theo bề rộng,
        // thay vì bị bó hẹp như phiên bản trước.
        val targetStringSpanToFretSpan =
            (stringGapCount / (fretCount.toFloat() * 1.45f)).coerceIn(0.62f, 0.90f)

        // Mặt gỗ rộng hơn trục từ dây ngoài cùng đến dây ngoài cùng khoảng
        // 0.35 khoảng dây ở mỗi bên. Trừ phần này trước để toàn bộ mặt gỗ
        // vẫn nằm gọn trong Card.
        val woodWidthFactor = 1f + 0.52f / stringGapCount
        val maxStringSpan = availableWidth / woodWidthFactor

        var neckHeight = availableHeight
        var neckWidth = neckHeight * targetStringSpanToFretSpan
        if (neckWidth > maxStringSpan) {
            neckWidth = maxStringSpan
            neckHeight = neckWidth / targetStringSpanToFretSpan
        }

        val neckLeft = availableLeft + (availableWidth - neckWidth) / 2f
        val neckTop = availableTop + (availableHeight - neckHeight) / 2f
        return VerticalFretboardBounds(
            neckLeft = neckLeft,
            neckRight = neckLeft + neckWidth,
            neckTop = neckTop,
            neckBottom = neckTop + neckHeight
        )
    }

    Canvas(
        modifier = modifier
            .padding(horizontal = 2.dp, vertical = 1.dp)
            .pointerInput(
                visibleNotes,
                visibleStartFret,
                visibleEndFret,
                activeMidis,
                hitMidis,
                onNoteClick
            ) {
                detectTapGestures { tap ->
                    if (onNoteClick == null || size.width <= 0 || size.height <= 0) {
                        return@detectTapGestures
                    }

                    val bounds = calculateVerticalBounds(
                        width = size.width.toFloat(),
                        height = size.height.toFloat()
                    )
                    val neckLeft = bounds.neckLeft
                    val neckRight = bounds.neckRight
                    val neckTop = bounds.neckTop
                    val neckBottom = bounds.neckBottom
                    val stringSpacing = if (stringNumbers.size > 1) {
                        (neckRight - neckLeft) / (stringNumbers.size - 1).toFloat()
                    } else {
                        neckRight - neckLeft
                    }
                    val fretSpacing = (neckBottom - neckTop) / fretCount.toFloat()

                    fun xForString(stringNumber: Int): Float {
                        val column = stringNumbers.indexOf(stringNumber).coerceAtLeast(0)
                        return neckLeft + column * stringSpacing
                    }

                    fun yForFret(fret: Int): Float {
                        return if (fret == 0) {
                            neckTop - openAreaPx * 0.30f
                        } else {
                            neckTop + (fret - visibleStartFret + 0.5f) * fretSpacing
                        }
                    }

                    val hitRadius = minOf(
                        stringSpacing * 0.42f,
                        fretSpacing * 0.42f,
                        with(density) { 20.dp.toPx() }
                    ).coerceAtLeast(with(density) { 9.dp.toPx() })

                    visibleNotes
                        .sortedByDescending { note ->
                            when {
                                note.midi in activeMidis -> 3
                                note.midi in hitMidis -> 2
                                else -> 1
                            }
                        }
                        .firstOrNull { note ->
                            val center = Offset(
                                xForString(note.stringIdx + 1),
                                yForFret(note.fret)
                            )
                            Math.hypot(
                                (tap.x - center.x).toDouble(),
                                (tap.y - center.y).toDouble()
                            ) <= hitRadius
                        }
                        ?.let { onNoteClick(it.midi) }
                }
            }
    ) {
        if (size.width <= 0f || size.height <= 0f) return@Canvas

        val bounds = calculateVerticalBounds(size.width, size.height)
        val neckLeft = bounds.neckLeft
        val neckRight = bounds.neckRight
        val neckTop = bounds.neckTop
        val neckBottom = bounds.neckBottom
        val stringSpacing = if (stringNumbers.size > 1) {
            (neckRight - neckLeft) / (stringNumbers.size - 1).toFloat()
        } else {
            neckRight - neckLeft
        }
        val fretSpacing = (neckBottom - neckTop) / fretCount.toFloat()

        fun xForString(stringNumber: Int): Float {
            val column = stringNumbers.indexOf(stringNumber).coerceAtLeast(0)
            return neckLeft + column * stringSpacing
        }

        fun yForFret(fret: Int): Float {
            return if (fret == 0) {
                neckTop - openAreaPx * 0.30f
            } else {
                neckTop + (fret - visibleStartFret + 0.5f) * fretSpacing
            }
        }

        val woodLeft = neckLeft - stringSpacing * 0.35f
        val woodRight = neckRight + stringSpacing * 0.35f
        val corner = with(density) { 8.dp.toPx() }

        drawRoundRect(
            color = Color(0xFF191615),
            topLeft = Offset(woodLeft, neckTop),
            size = Size(woodRight - woodLeft, neckBottom - neckTop),
            cornerRadius = CornerRadius(corner, corner)
        )

        for (row in 0 until fretCount) {
            val y = neckTop + row * fretSpacing
            drawRect(
                color = if (row % 2 == 0) Color(0xFF251E1B) else Color(0xFF1D1918),
                topLeft = Offset(woodLeft, y),
                size = Size(woodRight - woodLeft, fretSpacing)
            )
        }

        val markerFrets = setOf(3, 5, 7, 9, 12, 15, 17, 19)
        val markerRadius = minOf(
            with(density) { 3.dp.toPx() },
            minOf(stringSpacing, fretSpacing) * 0.13f
        ).coerceAtLeast(with(density) { 1.5.dp.toPx() })
        for (fret in visibleStartFret..visibleEndFret) {
            if (fret !in markerFrets) continue
            val y = yForFret(fret)
            if (fret % 12 == 0 && stringNumbers.size >= 4) {
                drawCircle(
                    color = textColor.copy(alpha = 0.25f),
                    radius = markerRadius,
                    center = Offset(neckLeft + (neckRight - neckLeft) * 0.38f, y)
                )
                drawCircle(
                    color = textColor.copy(alpha = 0.25f),
                    radius = markerRadius,
                    center = Offset(neckLeft + (neckRight - neckLeft) * 0.62f, y)
                )
            } else {
                drawCircle(
                    color = textColor.copy(alpha = 0.23f),
                    radius = markerRadius,
                    center = Offset((neckLeft + neckRight) / 2f, y)
                )
            }
        }

        // Thanh nut ở phía trên khi bắt đầu từ ngăn 1; nếu đang xem vùng cao,
        // đường đầu tiên chỉ là thanh phím bình thường.
        for (line in 0..fretCount) {
            val y = neckTop + line * fretSpacing
            val isNut = line == 0 && visibleStartFret == 1
            drawLine(
                color = if (isNut) {
                    Color(0xFFE5C986)
                } else {
                    Color(0xFFC2C6CA).copy(alpha = 0.72f)
                },
                start = Offset(woodLeft, y),
                end = Offset(woodRight, y),
                strokeWidth = if (isNut) {
                    with(density) { 3.2.dp.toPx() }
                } else {
                    with(density) { 0.9.dp.toPx() }
                },
                cap = StrokeCap.Round
            )
        }

        val bassColor = Color(0xFFC78A4D)
        val trebleColor = Color(0xFFD8DCE0)
        stringNumbers.forEach { stringNumber ->
            val x = xForString(stringNumber)
            val active = stringNumber in activeStringNumbers
            val widthDp = if (isUkulele) {
                when (stringNumber) {
                    3 -> 1.55f
                    4 -> 1.10f
                    else -> 1.30f
                }
            } else {
                when (stringNumber) {
                    6 -> 2.20f
                    5 -> 1.90f
                    4 -> 1.60f
                    3 -> 1.22f
                    2 -> 0.96f
                    else -> 0.76f
                }
            }
            val normalColor = if (isUkulele) {
                textColor.copy(alpha = 0.66f)
            } else if (stringNumber >= 4) {
                bassColor
            } else {
                trebleColor
            }
            drawLine(
                color = if (active) Color(0xFF409EFF) else normalColor,
                start = Offset(x, neckTop),
                end = Offset(x, neckBottom),
                strokeWidth = with(density) {
                    (widthDp + if (active) 0.25f else 0f).dp.toPx()
                },
                cap = StrokeCap.Round
            )
        }

        // Tên dây nằm ở phía trên, đúng hướng 12 giờ.
        val stringPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textSize = with(density) { 9.5.sp.toPx() }
        }
        val labelRadius = minOf(
            stringSpacing * 0.42f,
            with(density) { 11.5.dp.toPx() }
        ).coerceAtLeast(with(density) { 7.dp.toPx() })
        val labelY = (
                neckTop - openAreaPx - labelRadius - with(density) { 3.dp.toPx() }
                ).coerceAtLeast(labelRadius + with(density) { 1.dp.toPx() })
        stringNumbers.forEach { stringNumber ->
            val active = stringNumber in activeStringNumbers
            val center = Offset(xForString(stringNumber), labelY)
            drawCircle(
                color = if (active) {
                    Color(0xFF409EFF).copy(alpha = 0.16f)
                } else {
                    textColor.copy(alpha = 0.06f)
                },
                radius = labelRadius,
                center = center
            )
            drawCircle(
                color = if (active) Color(0xFF409EFF) else textColor.copy(alpha = 0.28f),
                radius = labelRadius,
                center = center,
                style = Stroke(width = with(density) { 0.8.dp.toPx() })
            )
            stringPaint.color = if (active) Color(0xFF409EFF).toArgb() else textColor.toArgb()
            drawContext.canvas.nativeCanvas.drawText(
                "$stringNumber${stringNames[stringNumber].orEmpty()}",
                center.x,
                center.y - (stringPaint.descent() + stringPaint.ascent()) / 2f,
                stringPaint
            )
        }

        val fretPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textSize = with(density) { 9.5.sp.toPx() }
            color = textColor.copy(alpha = 0.72f).toArgb()
        }
        val fretNumberX = (neckLeft - with(density) { 12.dp.toPx() })
            .coerceAtLeast(with(density) { 7.dp.toPx() })
        for (fret in visibleStartFret..visibleEndFret) {
            val y = yForFret(fret)
            drawContext.canvas.nativeCanvas.drawText(
                fret.toString(),
                fretNumberX,
                y - (fretPaint.descent() + fretPaint.ascent()) / 2f,
                fretPaint
            )
        }

        val noteRadius = minOf(
            stringSpacing * 0.47f,
            fretSpacing * 0.38f,
            maxRadiusPx
        ).coerceAtLeast(with(density) { 6.dp.toPx() })

        visibleNotes
            .sortedBy { note ->
                when {
                    note.midi in activeMidis -> 3
                    note.midi in hitMidis -> 2
                    else -> 1
                }
            }
            .forEach { note ->
                val center = Offset(
                    xForString(note.stringIdx + 1),
                    yForFret(note.fret)
                )
                val active = note.midi in activeMidis
                val hit = note.midi in hitMidis
                // Nốt dây buông có vùng riêng phía dưới hàng ký hiệu dây.
                // Giới hạn nhẹ bán kính của riêng nốt dây buông để cả vòng sáng
                // của nốt hiện tại cũng không chạm vào nhãn 6E..1e.
                val baseRadius = if (note.fret == 0) {
                    minOf(
                        noteRadius,
                        openAreaPx * 0.34f,
                        with(density) { 12.dp.toPx() }
                    )
                } else {
                    noteRadius
                }
                val radius = when {
                    active -> baseRadius * 1.10f
                    hit -> baseRadius
                    else -> baseRadius * 0.90f
                }

                if (active) {
                    drawCircle(
                        color = Color(0xFF409EFF).copy(alpha = 0.16f),
                        radius = radius * 1.50f,
                        center = center
                    )
                }

                if (note.fret == 0 && !active && !hit) {
                    drawCircle(
                        color = textColor.copy(alpha = 0.84f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = with(density) { 1.2.dp.toPx() })
                    )
                } else {
                    drawCircle(
                        color = when {
                            hit -> tunaGreen
                            active -> Color(0xFF409EFF)
                            activeMidis.isEmpty() -> textColor.copy(alpha = 0.48f)
                            else -> textColor.copy(alpha = 0.28f)
                        },
                        radius = radius,
                        center = center
                    )
                }

                if (active && !hit) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.74f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = with(density) { 0.8.dp.toPx() })
                    )
                }

                val notePaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    textSize = minOf(maxTextPx, radius * 1.05f)
                    color = when {
                        hit || active -> android.graphics.Color.WHITE
                        note.fret == 0 -> textColor.toArgb()
                        activeMidis.isEmpty() -> android.graphics.Color.WHITE
                        else -> android.graphics.Color.rgb(54, 57, 60)
                    }
                }
                drawContext.canvas.nativeCanvas.drawText(
                    if (showName) note.name else "?",
                    center.x,
                    center.y - (notePaint.descent() + notePaint.ascent()) / 2f,
                    notePaint
                )
            }
    }
}

@Composable
fun SingleNotePianoDiagram(
    targetNotes: List<NotePosition>,
    showName: Boolean,
    textColor: Color,
    tunaGreen: Color,
    activeMidis: List<Int> = emptyList(),
    onNoteClick: ((Int) -> Unit)? = null
) {
    val minMidi = if(targetNotes.isNotEmpty()) targetNotes.minOf { it.midi } else 60
    val startMidi = minMidi - 18
    val whiteKeyMidis = mutableListOf<Int>()
    for (m in startMidi..startMidi+36) {
        val noteIdx = m % 12
        if (noteIdx == 0 || noteIdx == 2 || noteIdx == 4 || noteIdx == 5 || noteIdx == 7 || noteIdx == 9 || noteIdx == 11) whiteKeyMidis.add(m)
    }

    val targetMidis = targetNotes.map { it.midi }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .pointerInput(whiteKeyMidis) {
                detectTapGestures { tapOffset ->
                    if (onNoteClick == null) return@detectTapGestures
                    val w = size.width
                    val h = size.height
                    val keyW = w / whiteKeyMidis.size
                    val blackKeyW = keyW * 0.6f
                    val blackKeyH = h * 0.4f

                    for (i in 0 until whiteKeyMidis.size - 1) {
                        if (whiteKeyMidis[i + 1] - whiteKeyMidis[i] == 2) {
                            val blackMidi = whiteKeyMidis[i] + 1
                            val bLeft = (i + 1) * keyW - (blackKeyW / 2f)
                            if (tapOffset.x >= bLeft && tapOffset.x <= bLeft + blackKeyW && tapOffset.y <= blackKeyH) {
                                onNoteClick(blackMidi)
                                return@detectTapGestures
                            }
                        }
                    }
                    val whiteIdx = (tapOffset.x / keyW).toInt()
                    if (whiteIdx in whiteKeyMidis.indices) {
                        onNoteClick(whiteKeyMidis[whiteIdx])
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val keyW = w / whiteKeyMidis.size
        val blackKeyW = keyW * 0.6f
        val blackKeyH = h * 0.4f
        val radius = CornerRadius(4f, 4f)

        val paint = android.graphics.Paint().apply { textSize = keyW * 0.5f; textAlign = android.graphics.Paint.Align.CENTER; color = android.graphics.Color.BLACK; typeface = android.graphics.Typeface.DEFAULT_BOLD }

        for (i in whiteKeyMidis.indices) {
            val midi = whiteKeyMidis[i]
            val isTarget = targetMidis.contains(midi)
            val isActive = activeMidis.contains(midi)

            val keyColor = when {
                isActive -> Color(0xFF409EFF)
                isTarget && activeMidis.isEmpty() -> tunaGreen
                isTarget -> tunaGreen.copy(alpha = 0.2f)
                else -> Color.White
            }

            drawRoundRect(color = keyColor, topLeft = Offset(i * keyW, 0f), size = Size(keyW, h), cornerRadius = radius)
            drawRoundRect(color = Color.Black, topLeft = Offset(i * keyW, 0f), size = Size(keyW, h), cornerRadius = radius, style = Stroke(width = 2f))
            if (isTarget) {
                val tName = targetNotes.find { it.midi == midi }?.name ?: "?"
                drawContext.canvas.nativeCanvas.drawText(if(showName) tName else "?", i * keyW + keyW / 2, h - 20f, paint)
            }
        }

        for (i in 0 until whiteKeyMidis.size - 1) {
            if (whiteKeyMidis[i + 1] - whiteKeyMidis[i] == 2) {
                val blackMidi = whiteKeyMidis[i] + 1
                val isTarget = targetMidis.contains(blackMidi)
                val isActive = activeMidis.contains(blackMidi)

                val keyColor = when {
                    isActive -> Color(0xFF409EFF)
                    isTarget && activeMidis.isEmpty() -> tunaGreen
                    isTarget -> tunaGreen.copy(alpha = 0.4f)
                    else -> Color(0xFF262626)
                }

                val bLeft = (i + 1) * keyW - (blackKeyW / 2f)
                drawRoundRect(color = keyColor, topLeft = Offset(bLeft, 0f), size = Size(blackKeyW, blackKeyH), cornerRadius = CornerRadius(2f, 2f))
                if (isTarget) {
                    val tName = targetNotes.find { it.midi == blackMidi }?.name ?: "?"
                    val wPaint = android.graphics.Paint().apply { textSize = keyW * 0.5f; textAlign = android.graphics.Paint.Align.CENTER; color = android.graphics.Color.WHITE; typeface = android.graphics.Typeface.DEFAULT_BOLD }
                    drawContext.canvas.nativeCanvas.drawText(if(showName) tName else "?", bLeft + blackKeyW / 2, blackKeyH - 10f, wPaint)
                }
            }
        }
    }
}

@Composable
fun LearnNotePhase(note: NotePosition, currentIndex: Int, total: Int, instrument: String, lang: String, textColor: Color, surfaceColor: Color, tunaGreen: Color, onNext: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(CoreTranslator.getString("memo_pos", lang), color = textColor.copy(alpha = 0.7f), fontSize = 16.sp)
            Text("${currentIndex + 1}/$total", color = tunaGreen, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(note.name, color = tunaGreen, fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.weight(1f))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(surfaceColor, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .padding(vertical = 32.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val actualMidi = if (note.midi != -1) note.midi else {
                    val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                    if (note.stringIdx < openMidi.size) openMidi[note.stringIdx] + note.fret else 60
                }
                SingleNoteStaffDiagram(
                    midi = actualMidi, instrument = instrument, textColor = textColor, tunaGreen = tunaGreen,
                    modifier = Modifier.fillMaxWidth().height(100.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = textColor.copy(alpha = 0.1f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 32.dp))
                Spacer(modifier = Modifier.height(16.dp))

                if (instrument == "Piano") {
                    SingleNotePianoDiagram(listOf(note), true, textColor, tunaGreen, onNoteClick = {
                        try { CoreAudioPlayer.playChord(listOf(it), instrument) } catch (e: Exception) {}
                    })
                } else {
                    SingleNoteFretboardDiagram(instrument, note, true, textColor, modifier = Modifier.fillMaxWidth().height(250.dp))
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                try {
                    val actualMidi = if (note.midi != -1) note.midi else {
                        val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                        if (note.stringIdx < openMidi.size) openMidi[note.stringIdx] + note.fret else 60
                    }
                    CoreAudioPlayer.playChord(listOf(actualMidi), instrument)
                } catch (e: Exception) { e.printStackTrace() }
            },
            colors = ButtonDefaults.buttonColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            modifier = Modifier.size(72.dp), shape = CircleShape // Tăng kích thước nút bấm từ 56.dp lên 72.dp
        ) {
            Icon(Icons.Default.VolumeUp, contentDescription = "Hear", tint = tunaGreen, modifier = Modifier.size(58.dp)) // Tăng kích thước icon loa từ 32.dp lên 48.dp
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onNext,
            colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp)
        ) {
            Text(text = if (currentIndex == total - 1) CoreTranslator.getString("ready_quiz", lang) else CoreTranslator.getString("next_btn", lang), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun LearnPhase(chord: ChordModel, currentIndex: Int, total: Int, instrument: String, lang: String, textColor: Color, surfaceColor: Color, tunaGreen: Color, onNext: () -> Unit) {
    val positions = chord.positions
    val itemsPerPage = 2
    val totalPages = (positions.size + itemsPerPage - 1) / itemsPerPage
    var currentPage by remember(chord) { mutableStateOf(0) }
    var maxPageViewed by remember(chord) { mutableStateOf(0) }
    val hasViewedAll = maxPageViewed >= totalPages - 1 || totalPages == 0

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(CoreTranslator.getString("memo_pos", lang), color = textColor.copy(alpha = 0.7f), fontSize = 16.sp)
            Text("${currentIndex + 1}/$total", color = tunaGreen, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))
        val displaySuffix = when (chord.suffix) { "major" -> ""; "minor" -> "m"; else -> chord.suffix }
        val chordName = "${chord.key}$displaySuffix".toMusicSymbols()
        Text(chordName, color = tunaGreen, fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.weight(1f))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            val visiblePositions = positions.subList(currentPage * itemsPerPage, minOf((currentPage + 1) * itemsPerPage, positions.size))

            if (visiblePositions.size == 1 && instrument != "Piano") Spacer(modifier = Modifier.weight(0.5f))

            visiblePositions.forEach { pos ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(surfaceColor, RoundedCornerShape(12.dp))
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            try {
                                CoreAudioPlayer.playChord(pos.midi, instrument)
                            } catch (e: Exception) { e.printStackTrace() }
                        }
                        .padding(vertical = 32.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(modifier = Modifier.graphicsLayer { scaleX = 1.0f; scaleY = 1.0f }) {
                        if (instrument == "Piano") PianoKeyboardDiagram(chordName, pos.midi, textColor, tunaGreen)
                        else PracticeFretboardDiagram(chordName, pos.frets, pos.fingers, pos.baseFret, if (instrument == "Guitar") 6 else 4, textColor, tunaGreen)
                    }
                }
            }

            if (visiblePositions.size == 1 && instrument != "Piano") Spacer(modifier = Modifier.weight(0.5f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (totalPages > 1) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {

                val isPrevEnabled = currentPage > 0
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (isPrevEnabled) surfaceColor else surfaceColor.copy(alpha = 0.3f))
                        .border(
                            width = 1.5.dp,
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = if (isPrevEnabled) listOf(Color.White.copy(alpha = 0.25f), Color.Black.copy(alpha = 0.5f))
                                else listOf(Color.White.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.2f))
                            ),
                            shape = CircleShape
                        )
                        .clickable(enabled = isPrevEnabled) { if (currentPage > 0) currentPage-- },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Prev", tint = if (isPrevEnabled) tunaGreen else textColor.copy(alpha = 0.3f), modifier = Modifier.size(24.dp))
                }

                Text(
                    text = "${currentPage + 1} / $totalPages",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )

                val isNextEnabled = currentPage < totalPages - 1
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (isNextEnabled) surfaceColor else surfaceColor.copy(alpha = 0.3f))
                        .border(
                            width = 1.5.dp,
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = if (isNextEnabled) listOf(Color.White.copy(alpha = 0.25f), Color.Black.copy(alpha = 0.5f))
                                else listOf(Color.White.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.2f))
                            ),
                            shape = CircleShape
                        )
                        .clickable(enabled = isNextEnabled) {
                            if (currentPage < totalPages - 1) {
                                currentPage++
                                if (currentPage > maxPageViewed) maxPageViewed = currentPage
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = if (isNextEnabled) tunaGreen else textColor.copy(alpha = 0.3f), modifier = Modifier.size(24.dp))
                }
            }
        } else {
            Text(CoreTranslator.getString("all_pos_viewed", lang), color = textColor.copy(alpha=0.6f), fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = onNext, enabled = hasViewedAll,
            colors = ButtonDefaults.buttonColors(containerColor = tunaGreen, disabledContainerColor = surfaceColor.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp)
        ) {
            Text(text = if (currentIndex == total - 1) CoreTranslator.getString("ready_quiz", lang) else CoreTranslator.getString("next_chord", lang), color = if (hasViewedAll) Color.White else textColor.copy(alpha = 0.5f), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AudioQuizPhase(
    question: PitchQuizQuestion, currentIndex: Int, total: Int, timeLeft: Int, timeLimit: Int,
    score: Int, totalElapsedTime: Int,
    instrument: String, lang: String, textColor: Color, surfaceColor: Color, tunaGreen: Color,
    isAnswered: Boolean, selectedAnswer: String?, onAnswerSelected: (String, Boolean) -> Unit, onNext: () -> Unit, onStop: () -> Unit
) {
    val progress by animateFloatAsState(targetValue = timeLeft.toFloat() / timeLimit.toFloat(), label = "")
    val correctName = question.correctName

    val totalAnswered = if (isAnswered) currentIndex + 1 else currentIndex
    val wrongCount = totalAnswered - score
    val accuracy = if (totalAnswered == 0) 0 else (score * 100) / totalAnswered
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", totalElapsedTime / 60, totalElapsedTime % 60)

    LaunchedEffect(currentIndex) {
        try {
            CoreAudioPlayer.playChord(question.midis, instrument)
        } catch (e: Exception) { e.printStackTrace() }
    }

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val statModifier = Modifier.background(surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp)).border(1.dp, textColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 6.dp)
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("⏱️", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text(timeString, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("✅", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text("$score", color = tunaGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("❌", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text("$wrongCount", color = Color(0xFFF56C6C), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) { Text("🎯", fontSize = 12.sp); Spacer(modifier = Modifier.width(4.dp)); Text("$accuracy%", color = Color(0xFF409EFF), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${CoreTranslator.getString("question_lbl", lang)} ${currentIndex + 1}/$total", color = textColor.copy(alpha = 0.7f), fontWeight = FontWeight.Bold)
            Text("${timeLeft}s", color = if (timeLeft <= 2) Color.Red else tunaGreen, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), color = if (timeLeft <= 2) Color.Red else tunaGreen, trackColor = surfaceColor)

        Spacer(modifier = Modifier.weight(1f))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (question.isChord) CoreTranslator.getString("listen_chord_lbl", lang) else CoreTranslator.getString("listen_note_lbl", lang),
                color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    try { CoreAudioPlayer.playChord(question.midis, instrument) } catch (e: Exception) {}
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9C27B0).copy(alpha = 0.2f)),
                shape = CircleShape,
                modifier = Modifier.size(120.dp).border(2.dp, Color(0xFF9C27B0), CircleShape)
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = "Play Sound", tint = Color(0xFF9C27B0), modifier = Modifier.size(60.dp))
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        question.options.chunked(2).forEach { rowOptions ->
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowOptions.forEach { opt ->
                    val isCorrectOpt = opt == correctName
                    val btnColor = if (isAnswered) { if (isCorrectOpt) tunaGreen else if (opt == selectedAnswer) Color.Red else surfaceColor.copy(alpha = 0.3f) } else surfaceColor
                    val btnText = if (isAnswered) { if (isCorrectOpt) "$opt ✓" else if (opt == selectedAnswer) "$opt ✗" else opt } else opt

                    Button(
                        onClick = { onAnswerSelected(opt, isCorrectOpt) }, enabled = !isAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = btnColor), shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(60.dp).border(1.dp, tunaGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    ) { Text(btnText, color = if(isAnswered && (isCorrectOpt || opt == selectedAnswer)) Color.White else textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (isAnswered) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(
                    onClick = onStop,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF56C6C)),
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(CoreTranslator.getString("stop_btn", lang), color = Color.White, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onNext,
                    colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(CoreTranslator.getString("next_btn", lang), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}

@Composable
fun QuizPhase(
    question: QuizQuestion, currentIndex: Int, total: Int, timeLeft: Int, timeLimit: Int,
    score: Int, totalElapsedTime: Int,
    instrument: String, lang: String, textColor: Color, surfaceColor: Color, tunaGreen: Color,
    isAnswered: Boolean, selectedAnswer: String?, onAnswerSelected: (String, Boolean) -> Unit, onNext: () -> Unit, onStop: () -> Unit
) {
    val progress by animateFloatAsState(targetValue = timeLeft.toFloat() / timeLimit.toFloat())
    val correctName = "${question.chord.key}${if(question.chord.suffix == "minor") "m" else if(question.chord.suffix == "major") "" else question.chord.suffix}".toMusicSymbols()

    val totalAnswered = if (isAnswered) currentIndex + 1 else currentIndex
    val wrongCount = totalAnswered - score
    val accuracy = if (totalAnswered == 0) 0 else (score * 100) / totalAnswered
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", totalElapsedTime / 60, totalElapsedTime % 60)

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val statModifier = Modifier
                .background(surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .border(1.dp, textColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)

            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("⏱️", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(timeString, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("✅", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text("$score", color = tunaGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("❌", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text("$wrongCount", color = Color(0xFFF56C6C), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("🎯", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text("$accuracy%", color = Color(0xFF409EFF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${CoreTranslator.getString("question_lbl", lang)} ${currentIndex + 1}/$total", color = textColor.copy(alpha = 0.7f), fontWeight = FontWeight.Bold)
            Text("${timeLeft}s", color = if (timeLeft <= 2) Color.Red else tunaGreen, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), color = if (timeLeft <= 2) Color.Red else tunaGreen, trackColor = surfaceColor)
        Spacer(modifier = Modifier.weight(1f))
        Box(modifier = Modifier.fillMaxWidth(0.9f).background(surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp)).padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
            Box(modifier = Modifier.graphicsLayer { scaleX = 1.4f; scaleY = 1.4f }) {
                if (instrument == "Piano") PianoKeyboardDiagram("?", question.position.midi, textColor, tunaGreen)
                else PracticeFretboardDiagram("?", question.position.frets, question.position.fingers, question.position.baseFret, if (instrument == "Guitar") 6 else 4, textColor, tunaGreen)
            }
        }
        Spacer(modifier = Modifier.weight(1f))
        question.options.chunked(2).forEach { rowOptions ->
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowOptions.forEach { opt ->
                    val isCorrectOpt = opt == correctName
                    val btnColor = if (isAnswered) { if (isCorrectOpt) tunaGreen else if (opt == selectedAnswer) Color.Red else surfaceColor.copy(alpha = 0.3f) } else surfaceColor
                    val btnText = if (isAnswered) { if (isCorrectOpt) "$opt ✓" else if (opt == selectedAnswer) "$opt ✗" else opt } else opt

                    Button(
                        onClick = { onAnswerSelected(opt, isCorrectOpt) }, enabled = !isAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = btnColor), shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(60.dp).border(1.dp, tunaGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    ) { Text(btnText, color = if(isAnswered && (isCorrectOpt || opt == selectedAnswer)) Color.White else textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (isAnswered) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(
                    onClick = {
                        if (!isAnswered) onAnswerSelected("", false)
                        onStop()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF56C6C)),
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(CoreTranslator.getString("stop_btn", lang), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button(onClick = onNext, colors = ButtonDefaults.buttonColors(containerColor = tunaGreen), modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(8.dp)) { Text(CoreTranslator.getString("next_btn", lang), color = Color.White, fontWeight = FontWeight.Bold) }
            }
        } else { Spacer(modifier = Modifier.height(50.dp)) }
    }
}

@Composable
fun QuizNotePhase(
    question: NoteQuizQuestion, currentIndex: Int, total: Int, timeLeft: Int, timeLimit: Int,
    score: Int, totalElapsedTime: Int,
    instrument: String, lang: String, textColor: Color, surfaceColor: Color, tunaGreen: Color,
    isAnswered: Boolean, selectedAnswer: String?, onAnswerSelected: (String, Boolean) -> Unit, onNext: () -> Unit, onStop: () -> Unit
) {
    val progress by animateFloatAsState(targetValue = timeLeft.toFloat() / timeLimit.toFloat())
    val correctName = question.targetNote.name

    val totalAnswered = if (isAnswered) currentIndex + 1 else currentIndex
    val wrongCount = totalAnswered - score
    val accuracy = if (totalAnswered == 0) 0 else (score * 100) / totalAnswered
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", totalElapsedTime / 60, totalElapsedTime % 60)

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val statModifier = Modifier
                .background(surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .border(1.dp, textColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)

            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("⏱️", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(timeString, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("✅", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text("$score", color = tunaGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("❌", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text("$wrongCount", color = Color(0xFFF56C6C), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = statModifier, verticalAlignment = Alignment.CenterVertically) {
                Text("🎯", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text("$accuracy%", color = Color(0xFF409EFF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${CoreTranslator.getString("question_lbl", lang)} ${currentIndex + 1}/$total", color = textColor.copy(alpha = 0.7f))
            Text("${timeLeft}s", color = if (timeLeft <= 2) Color.Red else tunaGreen, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), color = if (timeLeft <= 2) Color.Red else tunaGreen, trackColor = surfaceColor)
        Spacer(modifier = Modifier.weight(1f))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(surfaceColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(vertical = 20.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val actualMidi = if (question.targetNote.midi != -1) question.targetNote.midi else {
                val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                if (question.targetNote.stringIdx < openMidi.size) openMidi[question.targetNote.stringIdx] + question.targetNote.fret else 60
            }

            SingleNoteStaffDiagram(
                midi = actualMidi, instrument = instrument, textColor = textColor, tunaGreen = tunaGreen,
                modifier = Modifier.fillMaxWidth().height(100.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = textColor.copy(alpha = 0.1f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 32.dp))
            Spacer(modifier = Modifier.height(8.dp))

            if (instrument == "Piano") SingleNotePianoDiagram(listOf(question.targetNote), false, textColor, tunaGreen)
            else SingleNoteFretboardDiagram(instrument, question.targetNote, false, textColor)
        }
        Spacer(modifier = Modifier.weight(1f))
        question.options.chunked(2).forEach { rowOptions ->
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowOptions.forEach { opt ->
                    val isCorrectOpt = opt == correctName
                    val btnColor = if (isAnswered) { if (isCorrectOpt) tunaGreen else if (opt == selectedAnswer) Color.Red else surfaceColor.copy(alpha = 0.3f) } else surfaceColor
                    val btnText = if (isAnswered) { if (isCorrectOpt) "$opt ✓" else if (opt == selectedAnswer) "$opt ✗" else opt } else opt

                    Button(
                        onClick = { onAnswerSelected(opt, isCorrectOpt) }, enabled = !isAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = btnColor), shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(60.dp).border(1.dp, tunaGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    ) { Text(btnText, color = if(isAnswered && (isCorrectOpt || opt == selectedAnswer)) Color.White else textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (isAnswered) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = onStop, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF56C6C)), modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(8.dp)) { Text(CoreTranslator.getString("stop_btn", lang), color = Color.White, fontWeight = FontWeight.Bold) }
                Button(onClick = onNext, colors = ButtonDefaults.buttonColors(containerColor = tunaGreen), modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(8.dp)) { Text(CoreTranslator.getString("next_btn", lang), color = Color.White, fontWeight = FontWeight.Bold) }
            }
        } else { Spacer(modifier = Modifier.height(50.dp)) }
    }
}

@Composable
fun SingleNoteFretboardDiagram(
    instrument: String,
    targetNote: NotePosition,
    showName: Boolean,
    textColor: Color,
    modifier: Modifier = Modifier.fillMaxWidth().height(250.dp)
) {
    val numStrings = if (instrument == "Guitar") 6 else 4
    val numFrets = maxOf(targetNote.fret + 1, 5) // Hiển thị tối thiểu 5 phím

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val nutX = w * 0.1f
        val endX = w * 0.95f // Điểm kết thúc của cần đàn (Bỏ đi khoảng trống)

        // Tính toán chia tỷ lệ phím đàn lấp đầy toàn bộ khoảng trống từ nutX đến endX
        val r = Math.pow(2.0, -1.0 / 12.0).toFloat()
        var totalR = 0f
        for (i in 0 until numFrets) {
            totalR += Math.pow(r.toDouble(), i.toDouble()).toFloat()
        }
        val unit = (endX - nutX) / totalR

        fun getFretX(n: Int): Float {
            var x = nutX
            for (i in 0 until n) {
                x += unit * Math.pow(r.toDouble(), i.toDouble()).toFloat()
            }
            return x
        }

        val neckW = h * 0.85f
        fun getY(s: Int): Float = (h - neckW) / 2f + s * (neckW / (numStrings - 1))

        // Vẽ các chấm tròn (dots)
        val dotFrets = if (instrument == "Ukulele") listOf(5, 7, 10, 12, 15) else listOf(3, 5, 7, 9, 12, 15)
        val dotColor = textColor.copy(alpha = 0.15f)
        dotFrets.forEach { fret ->
            if (fret <= numFrets) {
                val midX = (getFretX(fret - 1) + getFretX(fret)) / 2f
                if (fret == 12) {
                    drawCircle(color = dotColor, radius = 12f, center = Offset(midX, getY(1)))
                    drawCircle(color = dotColor, radius = 12f, center = Offset(midX, getY(numStrings - 2)))
                } else {
                    val midY = (getY(0) + getY(numStrings - 1)) / 2f
                    drawCircle(color = dotColor, radius = 14f, center = Offset(midX, midY))
                }
            }
        }

        // Vẽ các thanh phím (Frets) - Đã sửa: Không vẽ dư +1 nữa
        for (i in 1..numFrets) {
            val x = getFretX(i)
            drawLine(color = textColor.copy(alpha = 0.4f), start = Offset(x, getY(0)), end = Offset(x, getY(numStrings - 1)), strokeWidth = 4f)
        }
        drawLine(color = textColor, start = Offset(nutX, getY(0)), end = Offset(nutX, getY(numStrings - 1)), strokeWidth = 14f)

        // Vẽ dây đàn - Đã sửa: Dây đàn kết thúc tại endX (cắt bỏ phần đuôi)
        for (s in 0 until numStrings) {
            val stringStrokeWidth = if (instrument == "Guitar") {
                (s + 1) * 1.8f
            } else {
                when(s) {
                    0 -> 1.8f; 1 -> 3.6f; 2 -> 7.2f; 3 -> 2.5f; else -> 1.8f
                }
            }
            drawLine(color = textColor.copy(alpha = 0.7f), start = Offset(nutX, getY(s)), end = Offset(endX, getY(s)), strokeWidth = stringStrokeWidth)
        }

        val fretTextPaint = android.graphics.Paint().apply {
            textSize = 28f
            textAlign = android.graphics.Paint.Align.CENTER
            color = android.graphics.Color.GRAY
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        for (i in 1..numFrets) {
            val midX = (getFretX(i - 1) + getFretX(i)) / 2f
            drawContext.canvas.nativeCanvas.drawText(i.toString(), midX, getY(numStrings - 1) + 80f, fretTextPaint)
        }

        val noteX = if (targetNote.fret == 0) nutX - 40f else (getFretX(targetNote.fret - 1) + getFretX(targetNote.fret)) / 2f
        val noteY = getY(targetNote.stringIdx)

        val stringSpacing = neckW / (numStrings - 1)
        val dynamicRadius = minOf(if (instrument == "Ukulele") 26f else 34f, stringSpacing * 0.35f)

        drawCircle(color = Color(0xFF00C853), radius = dynamicRadius, center = Offset(noteX, noteY))

        val dynamicTextSize = dynamicRadius * 0.85f
        val paint = android.graphics.Paint().apply { textSize = dynamicTextSize; textAlign = android.graphics.Paint.Align.CENTER; color = android.graphics.Color.WHITE; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        drawContext.canvas.nativeCanvas.drawText(if (showName) targetNote.name else "?", noteX, noteY - ((paint.descent() + paint.ascent()) / 2), paint)
    }
}

@Composable
fun ResultPhase(
    score: Int,
    total: Int,
    totalElapsedTime: Int,
    wrongAnswers: List<WrongAnswerData>,
    lang: String,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    gameType: String = "", // Cờ xác định loại game (Ví dụ: "MATCHING")
    wrongMatchCount: Int = 0, // Số lần bấm nối sai trong game Pikachu
    onClose: () -> Unit
) {
    // SỬA Ở ĐÂY: Nếu là game Pikachu thì lấy số lần nối sai, ngược lại tính như bình thường
    val actualWrongCount = if (gameType == "MATCHING") wrongMatchCount else total - score
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", totalElapsedTime / 60, totalElapsedTime % 60)
    val gson = remember { com.google.gson.Gson() }

    // Đổi Dialog thành dạng phủ toàn màn hình hoặc Card lớn để có không gian cuộn
    androidx.compose.ui.window.Dialog(
        onDismissRequest = { /* Không cho tắt khi bấm ra ngoài */ },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false) // Mở rộng full màn hình
    ) {
        Card(
            modifier = Modifier.fillMaxSize().padding(16.dp), // Phủ toàn màn hình có padding
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = surfaceColor),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = CoreTranslator.getString("quiz_result", lang).uppercase(),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = tunaGreen
                )
                Spacer(modifier = Modifier.height(16.dp))

                // BẢNG THỐNG KÊ ĐIỂM
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Đổi nhãn text tùy thuộc vào loại game
                    val totalLabel = if (gameType == "MATCHING") CoreTranslator.getString("lbl_total_pairs", lang) else CoreTranslator.getString("total_questions", lang)
                    val correctLabel = if (gameType == "MATCHING") CoreTranslator.getString("lbl_matched_pairs", lang) else CoreTranslator.getString("correct_lbl", lang)
                    val wrongLabel = if (gameType == "MATCHING") CoreTranslator.getString("lbl_wrong_picks", lang) else CoreTranslator.getString("wrong_lbl", lang)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(totalLabel, color = textColor, fontSize = 16.sp); Text("$total", color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(correctLabel, color = Color(0xFF4CAF50), fontSize = 16.sp); Text("$score", color = Color(0xFF4CAF50), fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(wrongLabel, color = Color(0xFFF56C6C), fontSize = 16.sp); Text("$actualWrongCount", color = Color(0xFFF56C6C), fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(CoreTranslator.getString("time_lbl", lang), color = textColor, fontSize = 16.sp); Text(timeString, color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = textColor.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(16.dp))

                // DANH SÁCH CÂU SAI HOẶC CÂU THÔNG BÁO TỔNG KẾT
                if (wrongAnswers.isNotEmpty()) {
                    Text(
                        text = CoreTranslator.getString("review_mistakes", lang),
                        color = textColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start).padding(bottom = 12.dp)
                    )

                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(wrongAnswers) { wrongAnswer ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // CỘT 1: Chữ
                                    Column(modifier = Modifier.weight(1.2f)) {
                                        val typeText = when {
                                            wrongAnswer.questionType.contains("CHORD") -> CoreTranslator.getString("prac_chords", lang)
                                            wrongAnswer.questionType.contains("NOTE") -> CoreTranslator.getString("prac_notes", lang)
                                            else -> CoreTranslator.getString("game_pitch_title", lang)
                                        }

                                        Text(text = "${CoreTranslator.getString("lbl_type", lang)} $typeText", color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = "${CoreTranslator.getString("lbl_you_chose", lang)} ${wrongAnswer.selectedOption}", color = Color(0xFFF56C6C), fontSize = 13.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = "${CoreTranslator.getString("lbl_correct_ans", lang)} ${wrongAnswer.correctOption}", color = tunaGreen, fontSize = 13.sp)
                                    }

                                    // CỘT 2: Hình ảnh
                                    if (wrongAnswer.imageDataJson.isNotEmpty()) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                            if (wrongAnswer.questionType.contains("CHORD")) {
                                                val position = gson.fromJson(wrongAnswer.imageDataJson, ChordPosition::class.java)
                                                ChordStaffDiagram(position.midi, wrongAnswer.instrument, textColor, tunaGreen, Modifier.fillMaxWidth().height(60.dp))
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (wrongAnswer.instrument == "Piano") {
                                                    Box(modifier = Modifier.fillMaxWidth().height(60.dp).padding(4.dp)) {
                                                        CompactChordPianoDiagram(wrongAnswer.correctOption, position.midi, textColor, tunaGreen)
                                                    }
                                                } else {
                                                    Box(modifier = Modifier.graphicsLayer { scaleX = 0.75f; scaleY = 0.75f }) {
                                                        FretboardDiagram(wrongAnswer.correctOption, position.frets, position.fingers, position.baseFret, if (wrongAnswer.instrument == "Guitar") 6 else 4, textColor, tunaGreen)
                                                    }
                                                }
                                            } else if (wrongAnswer.questionType.contains("NOTE")) {
                                                val position = gson.fromJson(wrongAnswer.imageDataJson, NotePosition::class.java)
                                                val actualMidi = if (position.midi != -1) position.midi else {
                                                    val openMidi = if (wrongAnswer.instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                                                    if (position.stringIdx != -1 && position.stringIdx < openMidi.size) openMidi[position.stringIdx] + position.fret else 60
                                                }
                                                SingleNoteStaffDiagram(actualMidi, wrongAnswer.instrument, textColor, tunaGreen, Modifier.fillMaxWidth().height(60.dp))
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (wrongAnswer.instrument == "Piano") {
                                                    Box(modifier = Modifier.fillMaxWidth().height(50.dp)) {
                                                        SingleNotePianoDiagram(listOf(position), true, textColor, tunaGreen)
                                                    }
                                                } else {
                                                    SingleNoteFretboardDiagram(wrongAnswer.instrument, position, true, textColor, Modifier.fillMaxWidth().height(90.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (gameType == "MATCHING" && actualWrongCount > 0) {
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = CoreTranslator.getString("game_over", lang) + "\n" + CoreTranslator.getString("you_made_wrong_picks", lang).replace("%d", actualWrongCount.toString()),
                        color = Color(0xFFF56C6C),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.weight(1f))
                } else if (actualWrongCount > 0) {
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = CoreTranslator.getString("game_over", lang),
                        color = Color(0xFFF56C6C),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.weight(1f))
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                    Text(CoreTranslator.getString("perfect_no_mistakes", lang), color = tunaGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = tunaGreen),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text(CoreTranslator.getString("confirm_btn", lang), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
@Composable
fun FixedClefOverlay(textColor: Color, surfaceColor: Color) {
    Box(
        modifier = Modifier
            .width(80.dp)
            .fillMaxHeight()
            .shadow(elevation = 12.dp, spotColor = Color.Black)
            .background(surfaceColor)
            .padding(vertical = 8.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val lineSpacing = h / 13f
            val startY = h * 0.25f

            for (i in 0..4) {
                val y = startY + i * lineSpacing
                drawLine(
                    color = textColor.copy(alpha = 0.4f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 3f
                )
            }

            val clefPaint = android.graphics.Paint().apply {
                textSize = lineSpacing * 5f
                textAlign = android.graphics.Paint.Align.CENTER
                color = textColor.copy(alpha = 0.8f).toArgb()
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
            }
            drawContext.canvas.nativeCanvas.drawText("𝄞", w * 0.5f, startY + lineSpacing * 3.3f, clefPaint)
        }
    }
}

@Composable
fun SingleNoteStaffDiagram(
    midi: Int,
    instrument: String,
    textColor: Color,
    tunaGreen: Color,
    modifier: Modifier = Modifier
) {
    fun getStaffStep(m: Int, inst: String): Int {
        val writtenMidi = if (inst == "Guitar") m + 12 else m
        val stepOffsets = arrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
        val octave = (writtenMidi / 12) - 1
        val noteIdx = writtenMidi % 12
        val cStep = (octave - 4) * 7 - 2
        return cStep + stepOffsets[noteIdx]
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val lineSpacing = h / 8f
        val startY = h * 0.3f
        val bottomLineY = startY + 4 * lineSpacing
        val stepHeight = lineSpacing / 2f
        val noteHeight = lineSpacing * 0.9f
        val noteWidth = lineSpacing * 1.3f

        for (i in 0..4) {
            val y = startY + i * lineSpacing
            drawLine(color = textColor.copy(alpha = 0.3f), start = Offset(w * 0.05f, y), end = Offset(w * 0.95f, y), strokeWidth = 3f)
        }

        val clefPaint = android.graphics.Paint().apply {
            textSize = lineSpacing * 5f
            textAlign = android.graphics.Paint.Align.CENTER
            color = textColor.copy(alpha = 0.6f).toArgb()
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
        }
        drawContext.canvas.nativeCanvas.drawText("𝄞", w * 0.25f, startY + lineSpacing * 3.3f, clefPaint)

        val step = getStaffStep(midi, instrument)
        val noteCenterX = w * 0.65f
        val noteCenterY = bottomLineY - (step * stepHeight)

        val ledgerWidth = noteWidth * 1.8f
        if (step < 0) {
            for (s in -2 downTo step step 2) {
                val ledgerY = bottomLineY - (s * stepHeight)
                drawLine(color = textColor, start = Offset(noteCenterX - ledgerWidth / 2, ledgerY), end = Offset(noteCenterX + ledgerWidth / 2, ledgerY), strokeWidth = 3f)
            }
        } else if (step > 8) {
            for (s in 10..step step 2) {
                val ledgerY = bottomLineY - (s * stepHeight)
                drawLine(color = textColor, start = Offset(noteCenterX - ledgerWidth / 2, ledgerY), end = Offset(noteCenterX + ledgerWidth / 2, ledgerY), strokeWidth = 3f)
            }
        }

        rotate(degrees = -25f, pivot = Offset(noteCenterX, noteCenterY)) {
            drawOval(
                color = tunaGreen,
                topLeft = Offset(noteCenterX - noteWidth / 2, noteCenterY - noteHeight / 2),
                size = Size(noteWidth, noteHeight),
                style = Stroke(width = 4.5f)
            )
        }
    }
}
@Composable
fun NoteModeSelectionPhase(
    lang: String,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    onSelectMode: (NoteGameMode) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = CoreTranslator.getString("game_note_title", lang),
                color = textColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Nút 1: Trắc nghiệm
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectMode(NoteGameMode.QUIZ) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(50.dp).background(tunaGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = tunaGreen, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = CoreTranslator.getString("quiz_mode", lang),
                        color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CoreTranslator.getString("desc_quiz_note", lang),
                        color = textColor.copy(alpha = 0.7f), fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Nút 2: Nhanh tay lẹ mắt (Nốt chạy)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectMode(NoteGameMode.RUNNING_NOTES) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(50.dp).background(Color(0xFFE6A23C).copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = Color(0xFFE6A23C), modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = CoreTranslator.getString("game_running_notes_title", lang),
                        color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CoreTranslator.getString("desc_run_note", lang),
                        color = textColor.copy(alpha = 0.7f), fontSize = 13.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Nút 3: Tìm Cặp Tương Đồng (Game nối hình Pikachu)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectMode(NoteGameMode.MATCHING) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(50.dp).background(Color(0xFF9C27B0).copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.GridView, contentDescription = null, tint = Color(0xFF9C27B0), modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = CoreTranslator.getString("game_matching_note_title", lang),
                        color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = CoreTranslator.getString("desc_match_note", lang),
                        color = textColor.copy(alpha = 0.7f), fontSize = 13.sp
                    )
                }
            }
        }
    }
}
@Composable
fun RunningNotesGamePhase(
    instrument: String,
    lang: String,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    bgColor: Color,
    initialTime: Int = 60,
    initialBpm: Int = 30,
    onClose: () -> Unit
) {
    val context = LocalContext.current

    // Trạng thái Game
    var isPlaying by remember { mutableStateOf(true) }
    var timeLeft by remember { mutableIntStateOf(initialTime) }
    var correctCount by remember { mutableIntStateOf(0) }
    var wrongCount by remember { mutableIntStateOf(0) }
    var bpm by remember { mutableIntStateOf(initialBpm) }
    // Thêm biến lưu trữ sai cho game nốt
    var currentWrongAnswers by remember { mutableStateOf<List<WrongAnswerData>>(emptyList()) }
    // BIẾN MỚI: Kích hoạt khi người chơi chủ động dừng
    var isForceStopped by remember { mutableStateOf(false) }

    val notes = remember { mutableStateListOf<RunningNote>() }
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val accuracy = if (correctCount + wrongCount == 0) 0 else (correctCount * 100) / (correctCount + wrongCount)
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", timeLeft / 60, timeLeft % 60)

    // Xác định dải âm (MIDI) phù hợp cho từng loại nhạc cụ (Chơi trong khoảng 4 ngăn đầu tiên)
    val naturalMidis = remember(instrument) {
        val range = when (instrument) {
            "Guitar" -> 40..68   // Từ E2 (dây 6 buông) đến G#4 (dây 1 ngăn 4)
            "Ukulele" -> 60..73  // Từ C4 (dây 3 buông) đến C#5 (dây 1 ngăn 4)
            else -> 60..71       // Piano: C4 đến B4
        }
        // Lọc chỉ giữ lại các nốt có chỉ số chia dư cho 12 thuộc C, D, E, F, G, A, B
        range.filter { midi ->
            val noteIdx = midi % 12
            noteIdx in listOf(0, 2, 4, 5, 7, 9, 11)
        }
    }

    // Vòng lặp thời gian thực cho Animation
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            withFrameMillis {
                currentTime = System.currentTimeMillis()
                val targetMs = 3000L
                val missMs = targetMs + 500L

                notes.forEachIndexed { index, note ->
                    if (note.state == NoteState.ACTIVE && (currentTime - note.spawnTime) > missMs) {
                        notes[index] = note.copy(state = NoteState.MISSED)
                        wrongCount++

// LƯU LỊCH SỬ SAI: Hết thời gian (Bỏ lỡ)
                        val noteNamesList = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
                        val correctName = noteNamesList[note.midi % 12]

                        // ĐÃ SỬA: Dùng hàm getInstrumentNotePosition để tự động tính ra đúng vị trí dây và ngăn thay vì -1
                        val actualNote = getInstrumentNotePosition(note.midi, instrument)
                        val imageData = com.google.gson.Gson().toJson(actualNote)
                        currentWrongAnswers = currentWrongAnswers + WrongAnswerData("NOTE", "Missed", correctName, imageData, instrument)

                        playQuizSound(context, false)
                    }
                }
            }
        }
    }

    // Đếm ngược thời gian
    LaunchedEffect(isPlaying) {
        while (isPlaying && timeLeft > 0) {
            delay(1000L)
            timeLeft--
            if (timeLeft == 0) isPlaying = false
        }
    }

    // Sinh nốt nhạc mới dựa trên BPM
    LaunchedEffect(isPlaying, bpm) {
        while (isPlaying) {
            val intervalMs = (60000L / bpm)
            delay(intervalMs)
            // SỬA Ở ĐÂY: Dùng naturalMidis thay vì playRange
            notes.add(RunningNote(id = System.currentTimeMillis(), midi = naturalMidis.random(), spawnTime = System.currentTimeMillis()))

            // Tăng độ khó dần
            if (notes.size % 5 == 0 && bpm < 120) bpm += 2
        }
    }

    // ==========================================
    // HÀM XỬ LÝ KHI NGƯỜI CHƠI BẤM PHÍM/NGĂN ĐÀN
    // ==========================================
    val handleNoteTap: (Int) -> Unit = { pressedMidi ->
        try { CoreAudioPlayer.playChord(listOf(pressedMidi), instrument) } catch(e:Exception){}

        val targetMs = 3000L
        var hitFound = false

        for (i in notes.indices) {
            val note = notes[i]
            if (note.state == NoteState.ACTIVE) {
                val elapsed = currentTime - note.spawnTime
                // Sai số cho phép: +/- 400ms quanh vạch đích
                if (Math.abs(elapsed - targetMs) < 400L) {
                    val isMatch = (note.midi % 12) == (pressedMidi % 12)
                    if (isMatch) {
                        notes[i] = note.copy(state = NoteState.HIT)
                        correctCount++
                        // Âm thanh của nốt nhạc đã được phát ở dòng `CoreAudioPlayer`.playChord ngay phía trên
                        // XÓA BỎ playQuizSound(context, true) Ở ĐÂY ĐỂ TRÁNH BỊ CHỒNG ÂM THANH
                        hitFound = true
                        break
                    }
                }
            }
        }

        if (!hitFound) {
            wrongCount++

// LƯU LỊCH SỬ SAI: Bấm sai nốt hoặc sai thời điểm
            val oldestActive = notes.firstOrNull { it.state == NoteState.ACTIVE }
            if (oldestActive != null) {
                val noteNamesList = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
                val correctName = noteNamesList[oldestActive.midi % 12]
                val pressedName = noteNamesList[pressedMidi % 12]

                // ĐÃ SỬA: Dùng hàm getInstrumentNotePosition để tự động tính ra đúng vị trí dây và ngăn
                val actualNote = getInstrumentNotePosition(oldestActive.midi, instrument)
                val imageData = com.google.gson.Gson().toJson(actualNote)
                currentWrongAnswers = currentWrongAnswers + WrongAnswerData("NOTE", pressedName, correctName, imageData, instrument)

                // Đổi trạng thái nốt đó thành MISSED để vòng lặp hết giờ không tính trùng nữa
                val idx = notes.indexOf(oldestActive)
                if (idx != -1) {
                    notes[idx] = oldestActive.copy(state = NoteState.MISSED)
                }
            }

            playQuizSound(context, false)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(bgColor).padding(16.dp)
    ) {
        // Header
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    val totalQ = correctCount + wrongCount
                    if (totalQ > 0) {
                        // KÍCH HOẠT HIỂN THỊ BẢNG KẾT QUẢ VÀ LƯU
                        isPlaying = false
                        isForceStopped = true
                    } else {
                        // Thoát luôn không lưu nếu chưa chơi câu nào
                        onClose()
                    }
                },
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor) // SỬA: Dùng textColor
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                CoreTranslator.getString("game_running_notes_title", lang),
                color = textColor, // SỬA: Dùng textColor
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Stats Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(
                title = CoreTranslator.getString("stat_time", lang),
                value = timeString,
                valueColor = textColor // SỬA: Dùng textColor
            )
            StatItem(
                title = CoreTranslator.getString("stat_right", lang),
                value = "$correctCount",
                valueColor = tunaGreen
            )
            StatItem(
                title = CoreTranslator.getString("stat_wrong", lang),
                value = "$wrongCount",
                valueColor = Color(0xFFF56C6C)
            )
            StatItem(
                title = CoreTranslator.getString("stat_accuracy", lang),
                value = "$accuracy%",
                valueColor = Color(0xFFE6A23C)
            )
            StatItem(title = "BPM", value = "$bpm", valueColor = tunaGreen)
        }
        Spacer(modifier = Modifier.height(24.dp))

        // Music Staff Area
        Box(modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp))) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                val lineSpacing = h / 35f
                val startY = h * 0.45f
                val stepHeight = lineSpacing / 2f
                val targetX = w * 0.28f

                for (i in 0..4) {
                    val y = startY + i * lineSpacing
                    drawLine(
                        color = Color.White.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 2f
                    )
                }

                val clefPaint = android.graphics.Paint().apply {
                    textSize = lineSpacing * 8.5f
                    textAlign = android.graphics.Paint.Align.CENTER
                    color = Color.White.toArgb()
                    typeface = android.graphics.Typeface.create(
                        android.graphics.Typeface.SERIF,
                        android.graphics.Typeface.NORMAL
                    )
                }
                drawContext.canvas.nativeCanvas.drawText(
                    "𝄞",
                    w * 0.12f,
                    startY + lineSpacing * 4.65f,
                    clefPaint
                )

// --- TÍNH TOÁN HIỆU ỨNG VẠCH ĐÍCH (HIT ZONE) ---
                val targetMsStatic = 3000f
                var minDistanceMs = Float.MAX_VALUE
                for (note in notes) {
                    if (note.state == NoteState.ACTIVE) {
                        val elapsed = currentTime - note.spawnTime
                        val distance = Math.abs(elapsed - targetMsStatic)
                        if (distance < minDistanceMs) minDistanceMs = distance.toFloat()
                    }
                }

// Chớp đỏ và zoom to vạch khi nốt đến gần tâm (sai số 250ms)
                val crossThreshold = 250f
                val (lineColor, lineWidth) = if (minDistanceMs <= crossThreshold) {
                    val zoomFactor = 1f - (minDistanceMs / crossThreshold)
                    Pair(Color.Red, 4f + (zoomFactor * 7f))
                } else {
                    Pair(tunaGreen.copy(alpha = 0.8f), 4f)
                }

                drawLine(
                    color = lineColor,
                    start = Offset(targetX, startY - lineSpacing * 2f),
                    end = Offset(targetX, startY + 6f * lineSpacing),
                    strokeWidth = lineWidth,
                    cap = StrokeCap.Round
                )
                fun getStaffStep(midi: Int): Int {
                    // Xử lý dịch quãng 8 cho Guitar
                    val writtenMidi = if (instrument == "Guitar") midi + 12 else midi
                    val stepOffsets = arrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
                    val octave = (writtenMidi / 12) - 1
                    val noteIdx = writtenMidi % 12
                    val cStep = (octave - 4) * 7 - 2
                    return cStep + stepOffsets[noteIdx]
                }

                val noteWidth = lineSpacing * 1.8f
                val noteHeight = lineSpacing * 1.2f
                val targetMs = 3000f

                for (note in notes) {
                    if (note.state == NoteState.MISSED) continue

                    val elapsed = currentTime - note.spawnTime
                    val currentX = w - ((w - targetX) * (elapsed / targetMs))

                    if (currentX < w * 0.16f) continue

                    val step = getStaffStep(note.midi)
                    val noteCenterY = (startY + 4 * lineSpacing) - (step * stepHeight)

                    if (step < 0) {
                        for (s in -2 downTo step step 2) {
                            val ledgerY = (startY + 4 * lineSpacing) - (s * stepHeight)
                            drawLine(
                                color = Color.White,
                                start = Offset(currentX - noteWidth * 1.1f, ledgerY),
                                end = Offset(currentX + noteWidth * 1.1f, ledgerY),
                                strokeWidth = 2.5f
                            )
                        }
                    } else if (step > 8) {
                        for (s in 10..step step 2) {
                            val ledgerY = (startY + 4 * lineSpacing) - (s * stepHeight)
                            drawLine(
                                color = Color.White,
                                start = Offset(currentX - noteWidth * 1.1f, ledgerY),
                                end = Offset(currentX + noteWidth * 1.1f, ledgerY),
                                strokeWidth = 2.5f
                            )
                        }
                    }

                    val noteColor = if (note.state == NoteState.HIT) tunaGreen else Color.White
                    rotate(degrees = -15f, pivot = Offset(currentX, noteCenterY)) {
                        drawOval(
                            color = noteColor,
                            topLeft = Offset(
                                currentX - noteWidth / 2,
                                noteCenterY - noteHeight / 2
                            ),
                            size = Size(noteWidth, noteHeight)
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // ==========================================
        // KHU VỰC NHẠC CỤ TƯƠNG TÁC Ở ĐÁY MÀN HÌNH
        // ==========================================
        if (instrument == "Piano") {
            val whiteKeys = listOf("C", "D", "E", "F", "G", "A", "B")
            Box(modifier = Modifier.fillMaxWidth().height(160.dp)) {
                Canvas(
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                        detectTapGestures { tapOffset ->
                            if (!isPlaying) return@detectTapGestures
                            val keyW = size.width / whiteKeys.size
                            val whiteIdx =
                                (tapOffset.x / keyW).toInt().coerceIn(0, whiteKeys.size - 1)
                            val pressedMidi = 60 + when (whiteIdx) {
                                0 -> 0; 1 -> 2; 2 -> 4; 3 -> 5; 4 -> 7; 5 -> 9; 6 -> 11; else -> 0
                            }
                            handleNoteTap(pressedMidi)
                        }
                    }
                ) {
                    val w = size.width;
                    val h = size.height
                    val keyW = w / whiteKeys.size
                    val blackKeyW = keyW * 0.55f
                    val blackKeyH = h * 0.6f

                    val whitePaint = android.graphics.Paint().apply {
                        textSize = keyW * 0.4f; textAlign =
                        android.graphics.Paint.Align.CENTER; color =
                        android.graphics.Color.BLACK; typeface =
                        android.graphics.Typeface.DEFAULT_BOLD
                    }
                    for (i in whiteKeys.indices) {
                        drawRoundRect(
                            color = Color(0xFFE0E0E0),
                            topLeft = Offset(i * keyW, 0f),
                            size = Size(keyW, h),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                        drawRoundRect(
                            color = Color.Black,
                            topLeft = Offset(i * keyW, 0f),
                            size = Size(keyW, h),
                            style = Stroke(width = 2f),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                        drawContext.canvas.nativeCanvas.drawText(
                            whiteKeys[i],
                            i * keyW + keyW / 2,
                            h - 20f,
                            whitePaint
                        )
                    }

                    val blackKeyOffsets = listOf(1, 2, 4, 5, 6)
                    for (i in blackKeyOffsets) {
                        val bLeft = i * keyW - (blackKeyW / 2f)
                        drawRoundRect(
                            color = Color(0xFF1E1E1E),
                            topLeft = Offset(bLeft, 0f),
                            size = Size(blackKeyW, blackKeyH),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                }
            }
        } else {
            // FRETBOARD CHO GUITAR VÀ UKULELE
            val numStrings = if (instrument == "Guitar") 6 else 4
            val openMidis = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(
                69,
                64,
                60,
                67
            )
            val stringNames =
                if (instrument == "Guitar") listOf("e", "B", "G", "D", "A", "E") else listOf(
                    "A",
                    "E",
                    "C",
                    "G"
                )
            val numFretsDisplay = 4

            // State dùng để hiện hiệu ứng chấm tròn ngắn hạn khi người dùng bấm vào cần đàn
            var lastTappedFret by remember { mutableStateOf<Pair<Int, Int>?>(null) }
            var lastTapTime by remember { mutableLongStateOf(0L) }

            // ĐÃ SỬA: Tăng chiều cao lên 240.dp để cần đàn bự ra
            Box(modifier = Modifier.fillMaxWidth().height(240.dp)) {
                Canvas(
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                        detectTapGestures { tapOffset ->
                            if (!isPlaying) return@detectTapGestures
                            val w = size.width
                            val h = size.height

                            val nutX = w * 0.12f
                            val endX = w * 0.95f
                            val fretSpacing = (endX - nutX) / numFretsDisplay
                            val neckW = h * 0.8f
                            val stringSpacing = neckW / (numStrings - 1)
                            val startY = (h - neckW) / 2f

                            // Tìm dây được bấm (trục Y)
                            var tappedString = -1
                            for (s in 0 until numStrings) {
                                val stringY = startY + s * stringSpacing
                                if (Math.abs(tapOffset.y - stringY) < stringSpacing / 2f + 15f) {
                                    tappedString = s
                                    break
                                }
                            }

                            // Tìm ngăn được bấm (trục X)
                            var tappedFret = -1
                            if (tapOffset.x < nutX + fretSpacing / 2f) {
                                // Nếu bấm ở mép trái ngoài nut -> Tính là đánh dây buông (ngăn 0)
                                tappedFret = if (tapOffset.x < nutX) 0 else 1
                            } else {
                                for (f in 1..numFretsDisplay) {
                                    val fretX = nutX + f * fretSpacing
                                    if (tapOffset.x > fretX - fretSpacing && tapOffset.x <= fretX) {
                                        tappedFret = f
                                        break
                                    }
                                }
                            }

                            if (tappedString != -1 && tappedFret != -1) {
                                lastTappedFret = Pair(tappedString, tappedFret)
                                lastTapTime = System.currentTimeMillis()

                                val pressedMidi = openMidis[tappedString] + tappedFret
                                handleNoteTap(pressedMidi)
                            }
                        }
                    }
                ) {
                    val w = size.width
                    val h = size.height
                    val nutX = w * 0.12f
                    val endX = w * 0.95f
                    val fretSpacing = (endX - nutX) / numFretsDisplay
                    val neckW = h * 0.8f
                    val stringSpacing = neckW / (numStrings - 1)
                    val startY = (h - neckW) / 2f

                    // Vẽ các thanh phím (Frets)
                    for (i in 0..numFretsDisplay) {
                        val x = nutX + i * fretSpacing
                        val isNut = i == 0
                        drawLine(
                            color = textColor.copy(alpha = if (isNut) 1f else 0.4f),
                            start = Offset(x, startY),
                            end = Offset(x, startY + neckW),
                            strokeWidth = if (isNut) 14f else 4f
                        )
                    }

                    // Vẽ các dây đàn (Strings)
                    for (s in 0 until numStrings) {
                        val y = startY + s * stringSpacing
                        val stringStrokeWidth = if (instrument == "Guitar") (s + 1f) * 1.5f else 3f
                        drawLine(
                            color = textColor.copy(alpha = 0.8f),
                            start = Offset(nutX, y),
                            end = Offset(endX, y),
                            strokeWidth = stringStrokeWidth
                        )

                        // Tên dây buông
                        val paint = android.graphics.Paint().apply {
                            textSize = 40f; // ĐÃ SỬA: Tăng từ 32f lên 40f
                            textAlign = android.graphics.Paint.Align.CENTER; color =
                            textColor.toArgb(); typeface = android.graphics.Typeface.DEFAULT_BOLD
                        }
                        drawContext.canvas.nativeCanvas.drawText(
                            stringNames[s],
                            nutX / 2f,
                            y - ((paint.descent() + paint.ascent()) / 2),
                            paint
                        )
                    }

                    // Hiệu ứng "nhấp nháy" khi bấm vào mặt phím
                    lastTappedFret?.let { (s, f) ->
                        if (System.currentTimeMillis() - lastTapTime < 250L) {
                            val y = startY + s * stringSpacing
                            val x = if (f == 0) nutX - 25f else nutX + (f - 0.5f) * fretSpacing

                            // Vẽ vòng tròn nền
                            drawCircle(
                                color = tunaGreen.copy(alpha = 0.9f),
                                radius = 46f, // ĐÃ SỬA: Tăng từ 32f lên 46f
                                center = Offset(x, y)
                            )

                            // Tính toán tên nốt nhạc
                            val pressedMidi = openMidis[s] + f
                            val noteNamesList = arrayOf(
                                "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
                            )
                            val noteName = noteNamesList[pressedMidi % 12]

                            // Vẽ tên nốt nhạc ở giữa vòng tròn
                            val textPaint = android.graphics.Paint().apply {
                                textSize = 38f // ĐÃ SỬA: Tăng từ 30f lên 38f
                                textAlign = android.graphics.Paint.Align.CENTER
                                color = android.graphics.Color.WHITE
                                typeface = android.graphics.Typeface.DEFAULT_BOLD
                            }
                            drawContext.canvas.nativeCanvas.drawText(
                                noteName,
                                x,
                                y - ((textPaint.descent() + textPaint.ascent()) / 2),
                                textPaint
                            )
                        }
                    }
                }
            }
        }
    }
    // Bảng kết quả khi kết thúc (Hết giờ HOẶC chủ động dừng)
// Bảng kết quả khi kết thúc (Hết giờ HOẶC chủ động dừng)
    if (!isPlaying && (timeLeft == 0 || isForceStopped)) {
        val playedTime = initialTime - timeLeft
        // LƯU TOÀN BỘ DATA VÀO DATABASE
        LaunchedEffect(Unit) {
            val gson = com.google.gson.Gson()
            val wrongAnswersJson = gson.toJson(currentWrongAnswers)
            val totalQ = correctCount + wrongCount
            saveGameHistory(context, instrument, "NOTE_RUN", correctCount, totalQ, playedTime, wrongAnswersJson)
        }
        ResultPhase(
            score = correctCount,
            total = correctCount + wrongCount,
            totalElapsedTime = playedTime,
            wrongAnswers = currentWrongAnswers, // <--- THÊM DÒNG NÀY VÀO ĐÂY
            lang = lang, textColor = textColor, surfaceColor = surfaceColor, tunaGreen = tunaGreen
        ) { onClose() }
    }
}
@Composable
fun StatItem(title: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, color = Color.Gray, fontSize = 12.sp)
        Text(text = value, color = valueColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}
@Composable
fun ChordModeSelectionPhase(
    lang: String,
    textColor: Color,
    surfaceColor: Color,
    tunaGreen: Color,
    onSelectMode: (NoteGameMode) -> Unit,
    onClose: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose, modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(CoreTranslator.getString("game_chord_title", lang), color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(32.dp))

        // Nút 1: Trắc nghiệm tĩnh
        Card(
            modifier = Modifier.fillMaxWidth().clickable { onSelectMode(NoteGameMode.QUIZ) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(50.dp).background(tunaGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = tunaGreen, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(CoreTranslator.getString("quiz_mode", lang), color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(CoreTranslator.getString("desc_quiz_chord", lang), color = textColor.copy(alpha = 0.7f), fontSize = 13.sp)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

// Nút 2: Hợp âm chạy
        Card(
            modifier = Modifier.fillMaxWidth().clickable { onSelectMode(NoteGameMode.RUNNING_CHORDS) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(50.dp).background(Color(0xFFE6A23C).copy(alpha = 0.2f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = Color(0xFFE6A23C), modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(CoreTranslator.getString("game_running_chords_title", lang), color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(CoreTranslator.getString("desc_run_chord", lang), color = textColor.copy(alpha = 0.7f), fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // NÚT 3: TÌM CẶP TƯƠNG ĐỒNG (GAME NỐI HÌNH PIKACHU)
        Card(
            modifier = Modifier.fillMaxWidth().clickable { onSelectMode(NoteGameMode.MATCHING) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, textColor.copy(alpha = 0.1f))
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(50.dp).background(Color(0xFF9C27B0).copy(alpha = 0.2f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.GridView, contentDescription = null, tint = Color(0xFF9C27B0), modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(CoreTranslator.getString("game_matching_chord_title", lang), color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(CoreTranslator.getString("desc_match_chord", lang), color = textColor.copy(alpha = 0.7f), fontSize = 13.sp)
                }
            }
        }
    }
}
@Composable
fun RunningChordsGamePhase(
    allChords: List<ChordModel>,
    instrument: String,
    lang: String,
    textColor: Color,
    surfaceColor: Color,
    bgColor: Color,
    tunaGreen: Color,
    initialTime: Int = 60,
    initialBpm: Int = 30,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var timeLeft by remember { mutableIntStateOf(initialTime) }
    var correctCount by remember { mutableIntStateOf(0) }
    var wrongCount by remember { mutableIntStateOf(0) }
    var bpm by remember { mutableIntStateOf(initialBpm) }
    // Thêm biến lưu trữ sai cho game nốt
    var currentWrongAnswers by remember { mutableStateOf<List<WrongAnswerData>>(emptyList()) }

    // THÊM BIẾN NÀY VÀO ĐỂ HẾT BÁO LỖI:
    var isForceStopped by remember { mutableStateOf(false) }

    val chords = remember { mutableStateListOf<RunningChord>() }
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val accuracy = if (correctCount + wrongCount == 0) 0 else (correctCount * 100) / (correctCount + wrongCount)
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", timeLeft / 60, timeLeft % 60)

    val chordPool = remember(allChords) {
        allChords.filter { !it.key.contains("#") && !it.key.contains("b") && (it.suffix == "major" || it.suffix == "minor" || it.suffix.contains("7")) }.filter { it.positions.isNotEmpty() }
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            withFrameMillis {
                currentTime = System.currentTimeMillis()
                val targetMs = 3000L
                val missMs = targetMs + 500L

                chords.forEachIndexed { index, chord ->
                    if (chord.state == NoteState.ACTIVE && (currentTime - chord.spawnTime) > missMs) {
                        chords[index] = chord.copy(state = NoteState.MISSED)
                        wrongCount++

                        // LƯU LỊCH SỬ SAI: Bỏ lỡ (Timeout)
                        val correctOpt = chord.options.find { it.name == chord.correctName }
                        val imageData = if (correctOpt != null) com.google.gson.Gson().toJson(correctOpt.position) else ""
                        // SỬA "CHORD_RUN" THÀNH "CHORD"
                        currentWrongAnswers = currentWrongAnswers + WrongAnswerData("CHORD", "Missed", chord.correctName, imageData, instrument)

                        playQuizSound(context, false)
                    }
                }
            }
        }
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying && timeLeft > 0) {
            delay(1000L)
            timeLeft--
            if (timeLeft == 0) isPlaying = false
        }
    }

    LaunchedEffect(isPlaying, bpm) {
        while (isPlaying && chordPool.isNotEmpty()) {
            val intervalMs = (60000L / bpm) * 1.5f
            delay(intervalMs.toLong())

            // --- THUẬT TOÁN TĂNG TIẾN ĐỘ KHÓ ---
            val spawnedCount = chords.size
            val allowedChords = when {
                spawnedCount < 6 -> {
                    // Giai đoạn 1 (Dễ): Chỉ hợp âm Trưởng và Thứ
                    chordPool.filter { it.suffix == "major" || it.suffix == "minor" }
                }
                spawnedCount < 15 -> {
                    // Giai đoạn 2 (Trung bình): Thêm hợp âm 7 và thứ 7
                    chordPool.filter { it.suffix == "major" || it.suffix == "minor" || it.suffix == "7" || it.suffix == "m7" }
                }
                else -> {
                    // Giai đoạn 3 (Khó): Ra toàn bộ hợp âm có trong Pool (maj7, dim, aug, sus...)
                    chordPool
                }
            }

            // Đề phòng trường hợp bộ lọc bị rỗng, fallback về toàn bộ pool
            val activePool = if (allowedChords.isNotEmpty()) allowedChords else chordPool

            // 1. Chọn hợp âm ĐÚNG từ nhóm độ khó hiện tại
            val randomChord = activePool.random()
            val correctPos = randomChord.positions.random()
            val correctName = "${randomChord.key}${if(randomChord.suffix == "minor") "m" else if(randomChord.suffix == "major") "" else randomChord.suffix}".toMusicSymbols()
            val correctOption = ChordOption(correctName, correctPos)

            // 2. Chọn 3 hợp âm SAI cũng nằm trong nhóm độ khó hiện tại (để người chơi không bị loạn)
            val wrongChords = activePool.filter { it.key != randomChord.key || it.suffix != randomChord.suffix }.shuffled().take(3)
            val wrongOptions = wrongChords.map { wChord ->
                val wName = "${wChord.key}${if(wChord.suffix == "minor") "m" else if(wChord.suffix == "major") "" else wChord.suffix}".toMusicSymbols()
                ChordOption(wName, wChord.positions.random())
            }

            val allOptions = (wrongOptions + listOf(correctOption)).shuffled()

            chords.add(RunningChord(id = System.currentTimeMillis(), midis = correctPos.midi, correctName = correctName, options = allOptions, spawnTime = System.currentTimeMillis()))

            // Cứ qua 5 hợp âm thì tăng tốc độ rơi một chút
            if (chords.size % 5 == 0 && bpm < 100) bpm += 2
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0F0F0F)).padding(16.dp)) {
        // Header & Stats
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    val totalQ = correctCount + wrongCount
                    if (totalQ > 0) {
                        // KÍCH HOẠT HIỂN THỊ BẢNG KẾT QUẢ VÀ LƯU
                        isPlaying = false
                        isForceStopped = true
                    } else {
                        // Thoát luôn không lưu nếu chưa chơi câu nào
                        onClose()
                    }
                },
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(CoreTranslator.getString("game_running_chords_title", lang), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            StatItem(title = CoreTranslator.getString("stat_time", lang), value = timeString, valueColor = Color.White)
            StatItem(title = CoreTranslator.getString("stat_right", lang), value = "$correctCount", valueColor = tunaGreen)
            StatItem(title = CoreTranslator.getString("stat_wrong", lang), value = "$wrongCount", valueColor = Color(0xFFF56C6C))
            StatItem(title = CoreTranslator.getString("stat_accuracy", lang), value = "$accuracy%", valueColor = Color(0xFFE6A23C))
            StatItem(title = "BPM", value = "$bpm", valueColor = tunaGreen)
        }
        Spacer(modifier = Modifier.height(24.dp))

        // Music Staff
        Box(modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp))) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // --- KHOẢNG CÁCH VÀ VỊ TRÍ ĐƯỢC CHỈNH LẠI ---
                // Thu nhỏ tỷ lệ một chút và đẩy toàn bộ khuông nhạc xuống thấp hơn
                // để Khóa Sol và các nốt cao của Guitar không bị cắt mất đỉnh
                val lineSpacing = h / 14.5f
                val startY = h * 0.36f
                val stepHeight = lineSpacing / 2f
                val targetX = w * 0.32f

                // Vẽ 5 dòng kẻ
                for (i in 0..4) {
                    val y = startY + i * lineSpacing
                    drawLine(color = Color.White.copy(alpha = 0.5f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 2.5f)
                }

                // Căn chỉnh Khóa Sol
                val clefPaint = android.graphics.Paint().apply {
                    textSize = lineSpacing * 6f
                    textAlign = android.graphics.Paint.Align.CENTER
                    color = Color.White.toArgb()
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
                }
                drawContext.canvas.nativeCanvas.drawText("𝄞", w * 0.12f, startY + lineSpacing * 3.8f, clefPaint)

                val targetMs = 3000f

                // --- TÍNH TOÁN HIỆU ỨNG VẠCH ĐÍCH (HIT ZONE) ---
                var minDistanceMs = Float.MAX_VALUE
                for (chord in chords) {
                    if (chord.state == NoteState.ACTIVE) {
                        val elapsed = currentTime - chord.spawnTime
                        val distance = Math.abs(elapsed - targetMs)
                        if (distance < minDistanceMs) minDistanceMs = distance.toFloat()
                    }
                }

                // Ngưỡng thời gian nốt nhạc đi ngang qua vạch (250ms)
                val crossThreshold = 250f
                val (lineColor, lineWidth) = if (minDistanceMs <= crossThreshold) {
                    // Chuyển màu Đỏ & Zoom to lên khi nốt nhạc ở gần tâm vạch
                    val zoomFactor = 1f - (minDistanceMs / crossThreshold)
                    Pair(Color.Red, 5f + (zoomFactor * 9f))
                } else {
                    Pair(tunaGreen.copy(alpha = 0.8f), 5f)
                }

                // Vẽ Vạch đích với hiệu ứng động
                // (Kéo dài vạch đích lên trên và xuống dưới để cắt ngang qua cả các nốt cao nhất)
                drawLine(
                    color = lineColor,
                    start = Offset(targetX, startY - lineSpacing * 5.5f),
                    end = Offset(targetX, startY + 6.5f * lineSpacing),
                    strokeWidth = lineWidth,
                    cap = StrokeCap.Round
                )

                fun getStaffStep(midi: Int): Int {
                    val writtenMidi = if (instrument == "Guitar") midi + 12 else midi
                    val stepOffsets = arrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
                    val octave = (writtenMidi / 12) - 1
                    val noteIdx = writtenMidi % 12
                    val cStep = (octave - 4) * 7 - 2
                    return cStep + stepOffsets[noteIdx]
                }

                // --- TỶ LỆ NỐT NHẠC CHUẨN XÁC ---
                // Khi nốt xoay nghiêng (-15 độ), chiều cao thực tế sẽ bị dội lên.
                // Do đó noteHeight = lineSpacing * 0.55f đảm bảo nốt nằm lọt thỏm giữa 2 dòng kẻ mà không dính nhau.
                val noteWidth = lineSpacing * 1.1f
                val noteHeight = lineSpacing * 0.55f
                // Đã xóa dòng val targetMs = 3000f bị lặp ở đây để hết báo lỗi đỏ

                for (chord in chords) {
                    if (chord.state == NoteState.MISSED) continue

                    val elapsed = currentTime - chord.spawnTime
                    val currentX = w - ((w - targetX) * (elapsed / targetMs))
                    if (currentX < w * 0.18f) continue

                    val steps = chord.midis.map { getStaffStep(it) }.distinct()
                    if (steps.isEmpty()) continue

                    val chordColor = if (chord.state == NoteState.HIT) tunaGreen else Color.White

                    // Vẽ đường nối nốt (Stem)
                    val minStep = steps.minOrNull() ?: 0
                    val maxStep = steps.maxOrNull() ?: 0
                    val minY = (startY + 4 * lineSpacing) - (maxStep * stepHeight)
                    val maxY = (startY + 4 * lineSpacing) - (minStep * stepHeight)

                    // Dịch thanh dọc (stem) sát vào mép phải
                    val stemX = currentX + noteWidth / 2f - 1.5f
                    drawLine(color = chordColor, start = Offset(stemX, minY), end = Offset(stemX, maxY), strokeWidth = 3f)

                    for (step in steps) {
                        val noteCenterY = (startY + 4 * lineSpacing) - (step * stepHeight)

                        // Kẻ dòng phụ (Ledger lines)
                        if (step < 0 || step > 8) {
                            val limit = if (step < 0) -2 downTo step step 2 else 10..step step 2
                            for (s in limit) {
                                val ledgerY = (startY + 4 * lineSpacing) - (s * stepHeight)
                                drawLine(color = Color.White, start = Offset(currentX - noteWidth * 1.3f, ledgerY), end = Offset(currentX + noteWidth * 1.3f, ledgerY), strokeWidth = 3f)
                            }
                        }

                        // Vẽ nốt nhạc
                        rotate(degrees = -15f, pivot = Offset(currentX, noteCenterY)) {
                            drawOval(color = chordColor, topLeft = Offset(currentX - noteWidth / 2, noteCenterY - noteHeight / 2), size = Size(noteWidth, noteHeight))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

// ==========================================
        // 4 NÚT HÌNH ẢNH SƠ ĐỒ HỢP ÂM
        // ==========================================
        val targetMs = 3000L
        // YÊU CẦU 1: Hiển thị 4 nút hợp âm ngay lập tức khi nốt vừa xuất hiện (Bỏ điều kiện trễ thời gian)
        val activeChord = chords.firstOrNull { it.state == NoteState.ACTIVE }

        Box(modifier = Modifier.fillMaxWidth().height(330.dp), contentAlignment = Alignment.Center) {
            if (activeChord != null) {
                Column(modifier = Modifier.fillMaxSize()) {
                    activeChord.options.chunked(2).forEach { rowOptions ->
                        Row(modifier = Modifier.fillMaxWidth().weight(1f).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowOptions.forEach { opt ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(surfaceColor.copy(alpha = 0.8f))
                                        .border(1.dp, tunaGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .clickable {
                                            // YÊU CẦU 2: Tính toán thời gian thực để tạo vùng Hit Zone
                                            val elapsed = currentTime - activeChord.spawnTime
                                            // Chỉ cho phép đúng nếu nốt nhạc giao với vạch màu xanh (+/- 400ms)
                                            val isWithinHitZone = Math.abs(elapsed - targetMs) <= 400L

                                            if (isWithinHitZone) {
                                                if (opt.name == activeChord.correctName) {
                                                    activeChord.state = NoteState.HIT
                                                    correctCount++
                                                    try { CoreAudioPlayer.playChord(activeChord.midis, instrument) } catch(e:Exception){}
                                                } else {
                                                    activeChord.state = NoteState.MISSED
                                                    wrongCount++

                                                    // LƯU LỊCH SỬ SAI: Chọn sai đáp án
                                                    val correctOpt = activeChord.options.find { it.name == activeChord.correctName }
                                                    val imageData = if (correctOpt != null) com.google.gson.Gson().toJson(correctOpt.position) else ""
                                                    // SỬA "CHORD_RUN" THÀNH "CHORD"
                                                    currentWrongAnswers = currentWrongAnswers + WrongAnswerData("CHORD", opt.name, activeChord.correctName, imageData, instrument)

                                                    playQuizSound(context, false)
                                                }
                                            } else {
                                                activeChord.state = NoteState.MISSED
                                                wrongCount++

                                                // LƯU LỊCH SỬ SAI: Bấm quá sớm
                                                val correctOpt = activeChord.options.find { it.name == activeChord.correctName }
                                                val imageData = if (correctOpt != null) com.google.gson.Gson().toJson(correctOpt.position) else ""
                                                // SỬA "CHORD_RUN" THÀNH "CHORD"
                                                currentWrongAnswers = currentWrongAnswers + WrongAnswerData("CHORD", "Sớm", activeChord.correctName, imageData, instrument)

                                                playQuizSound(context, false)
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (instrument == "Piano") {
                                        // KHÔNG DÙNG SCALE CHO PIANO: Ép Box full size, bỏ padding thừa
                                        Box(modifier = Modifier.fillMaxSize().padding(4.dp)) {
                                            CompactChordPianoDiagram(opt.name, opt.position.midi, textColor, tunaGreen)
                                        }
                                    } else {
                                        // Vẫn giữ Scale 0.85 cho Guitar/Ukulele để vừa vặn
                                        Box(modifier = Modifier.padding(2.dp).graphicsLayer { scaleX = 0.85f; scaleY = 0.85f }) {
                                            PracticeFretboardDiagram(
                                                opt.name,
                                                opt.position.frets,
                                                opt.position.fingers,
                                                opt.position.baseFret,
                                                if (instrument == "Guitar") 6 else 4,
                                                textColor,
                                                tunaGreen
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Text(if (lang == "vi") "Đang đợi hợp âm trôi tới..." else "Waiting for chord...", color = textColor.copy(alpha = 0.5f), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Bảng kết quả khi kết thúc (Hết giờ HOẶC chủ động dừng)
// Bảng kết quả khi kết thúc (Hết giờ HOẶC chủ động dừng)
        if (!isPlaying && (timeLeft == 0 || isForceStopped)) {
            val playedTime = initialTime - timeLeft
            // LƯU TOÀN BỘ DATA VÀO DATABASE
            LaunchedEffect(Unit) {
                val gson = com.google.gson.Gson()
                val wrongAnswersJson = gson.toJson(currentWrongAnswers)
                val totalQ = correctCount + wrongCount
                saveGameHistory(context, instrument, "CHORD_RUN", correctCount, totalQ, playedTime, wrongAnswersJson)
            }
            ResultPhase(
                score = correctCount,
                total = correctCount + wrongCount,
                totalElapsedTime = playedTime,
                wrongAnswers = currentWrongAnswers, // <--- VÀ THÊM DÒNG NÀY VÀO ĐÂY NỮA
                lang = lang, textColor = textColor, surfaceColor = surfaceColor, tunaGreen = tunaGreen
            ) { onClose() }
        }
    }
}
@Composable
fun CompactChordPianoDiagram(
    chordName: String,
    targetMidis: List<Int>,
    textColor: Color,
    tunaGreen: Color
) {
    val minMidi = targetMidis.minOrNull() ?: 60
    val maxMidi = targetMidis.maxOrNull() ?: 64

    // Tự động tìm dải phím vừa đủ (Dư 1 phím trắng ở bên trái)
    var startMidi = minMidi - 1
    while (startMidi % 12 !in listOf(0, 2, 4, 5, 7, 9, 11)) startMidi--

    // Dư 1 phím trắng ở bên phải
    var endMidi = maxMidi + 1
    while (endMidi % 12 !in listOf(0, 2, 4, 5, 7, 9, 11)) endMidi++

    val whiteKeyMidis = mutableListOf<Int>()
    var currentMidi = startMidi
    while (currentMidi <= endMidi) {
        if (currentMidi % 12 in listOf(0, 2, 4, 5, 7, 9, 11)) {
            whiteKeyMidis.add(currentMidi)
        }
        currentMidi++
    }

    // Đảm bảo tối thiểu 7 phím trắng để form đàn trông tự nhiên nhất
    while (whiteKeyMidis.size < 7) {
        if (whiteKeyMidis.size % 2 == 0) {
            var nextMidi = whiteKeyMidis.last() + 1
            while (nextMidi % 12 !in listOf(0, 2, 4, 5, 7, 9, 11)) nextMidi++
            whiteKeyMidis.add(nextMidi)
        } else {
            var prevMidi = whiteKeyMidis.first() - 1
            while (prevMidi % 12 !in listOf(0, 2, 4, 5, 7, 9, 11)) prevMidi--
            whiteKeyMidis.add(0, prevMidi)
        }
    }

    val noteNamesList = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    // Giảm padding Canvas để trải dài ra mép Box tối đa
    Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 6.dp)) {
        val w = size.width
        val maxAvailableH = size.height - 35f // Không gian cho phím (chừa 35f cho tên hợp âm ở trên)

        // Phím cao hơn một chút (0.65x Width) để to và dễ bấm
        val idealH = w * 0.65f
        val h = minOf(maxAvailableH, idealH)

        val startY = 35f + (maxAvailableH - h) / 2f

        val keyW = w / whiteKeyMidis.size
        val blackKeyW = keyW * 0.65f
        val blackKeyH = h * 0.6f
        val radius = CornerRadius(6f, 6f)

        // Vẽ tên hợp âm
        val namePaint = android.graphics.Paint().apply {
            textSize = 34f
            textAlign = android.graphics.Paint.Align.CENTER
            color = textColor.toArgb()
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        drawContext.canvas.nativeCanvas.drawText(chordName, w / 2, 28f, namePaint)

        val whiteTextPaint = android.graphics.Paint().apply {
            textSize = (keyW * 0.4f).coerceAtMost(30f) // Giới hạn size để không bị tràn phím
            textAlign = android.graphics.Paint.Align.CENTER
            color = android.graphics.Color.BLACK
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        // Vẽ phím trắng
        for (i in whiteKeyMidis.indices) {
            val midi = whiteKeyMidis[i]
            val isTarget = targetMidis.contains(midi)

            val keyColor = if (isTarget) tunaGreen else Color.White

            drawRoundRect(color = keyColor, topLeft = Offset(i * keyW, startY), size = Size(keyW, h), cornerRadius = radius)
            drawRoundRect(color = Color.Black, topLeft = Offset(i * keyW, startY), size = Size(keyW, h), cornerRadius = radius, style = Stroke(width = 2f))

            if (isTarget) {
                drawContext.canvas.nativeCanvas.drawText(noteNamesList[midi % 12], i * keyW + keyW / 2, startY + h - 12f, whiteTextPaint)
            }
        }

        // Vẽ phím đen
        for (i in 0 until whiteKeyMidis.size - 1) {
            if (whiteKeyMidis[i + 1] - whiteKeyMidis[i] == 2) {
                val blackMidi = whiteKeyMidis[i] + 1
                val isTarget = targetMidis.contains(blackMidi)

                val keyColor = if (isTarget) tunaGreen else Color(0xFF262626)
                val bLeft = (i + 1) * keyW - (blackKeyW / 2f)

                // 1. Vẽ nền phím (tô màu xanh hoặc xám đen)
                drawRoundRect(
                    color = keyColor,
                    topLeft = Offset(bLeft, startY),
                    size = Size(blackKeyW, blackKeyH),
                    cornerRadius = CornerRadius(4f, 4f)
                )

                // 2. VẼ THÊM VIỀN ĐEN Ở ĐÂY (Sẽ bọc viền đen bao quanh phím xanh)
                drawRoundRect(
                    color = Color.Black,
                    topLeft = Offset(bLeft, startY),
                    size = Size(blackKeyW, blackKeyH),
                    cornerRadius = CornerRadius(4f, 4f),
                    style = Stroke(width = 2.5f) // Để 2.5f cho viền rõ nét
                )

                if (isTarget) {
                    val dynamicTextPaint = android.graphics.Paint().apply {
                        textSize = (keyW * 0.35f).coerceAtMost(26f)
                        textAlign = android.graphics.Paint.Align.CENTER
                        color = android.graphics.Color.BLACK
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }
                    drawContext.canvas.nativeCanvas.drawText(noteNamesList[blackMidi % 12], bLeft + blackKeyW / 2, startY + blackKeyH - 12f, dynamicTextPaint)
                }
            }
        }
    }
}
@Composable
fun ChordStaffDiagram(
    midis: List<Int>,
    instrument: String,
    textColor: Color,
    tunaGreen: Color,
    modifier: Modifier = Modifier
) {
    fun getStaffStep(m: Int, inst: String): Int {
        val writtenMidi = if (inst == "Guitar") m + 12 else m
        val stepOffsets = arrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
        val octave = (writtenMidi / 12) - 1
        val noteIdx = writtenMidi % 12
        val cStep = (octave - 4) * 7 - 2
        return cStep + stepOffsets[noteIdx]
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val lineSpacing = h / 11.5f
        val startY = h * 0.25f
        val bottomLineY = startY + 4 * lineSpacing
        val stepHeight = lineSpacing / 2f
        val noteHeight = lineSpacing * 0.9f
        val noteWidth = lineSpacing * 1.3f

        // Vẽ 5 dòng kẻ
        for (i in 0..4) {
            val y = startY + i * lineSpacing
            drawLine(color = textColor.copy(alpha = 0.3f), start = Offset(w * 0.05f, y), end = Offset(w * 0.95f, y), strokeWidth = 3f)
        }

        // Vẽ khóa Sol
        val clefPaint = android.graphics.Paint().apply {
            textSize = lineSpacing * 5f
            textAlign = android.graphics.Paint.Align.CENTER
            color = textColor.copy(alpha = 0.6f).toArgb()
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
        }
        drawContext.canvas.nativeCanvas.drawText("𝄞", w * 0.25f, startY + lineSpacing * 3.3f, clefPaint)

        // Trục X gốc (căn lùi sang trái một tí để lấy chỗ cho nốt bị đẩy sang phải)
        val baseNoteCenterX = w * 0.55f

        // --- THUẬT TOÁN XỬ LÝ SO LE NỐT NHẠC ---
        // 1. Tính toán bậc (step) của tất cả các nốt trong hợp âm
        val stepMap = midis.associateWith { getStaffStep(it, instrument) }
        val sortedSteps = stepMap.values.sorted()

        // 2. Tìm ra những bậc nào cần bị đẩy sang phải
        val shiftedSteps = mutableSetOf<Int>()
        var lastStep = -999
        var lastWasShifted = false

        for (step in sortedSteps) {
            // Nếu nốt này nằm ngay sát nốt trước đó (ví dụ nốt trước ở dòng kẻ, nốt này ở khe ngay trên)
            // VÀ nốt trước đó chưa bị đẩy sang phải -> Đẩy nốt này sang phải
            if (step == lastStep + 1 && !lastWasShifted) {
                shiftedSteps.add(step)
                lastWasShifted = true
            } else {
                lastWasShifted = false
            }
            lastStep = step
        }
        // ---------------------------------------

        // Vẽ từng nốt trong hợp âm
        midis.forEach { midi ->
            val step = stepMap[midi] ?: 0
            val noteCenterY = bottomLineY - (step * stepHeight)

            // Nếu nốt nằm trong danh sách so le, đẩy trục X sang phải 1 khoảng bằng 85% chiều rộng nốt
            val isShifted = shiftedSteps.contains(step)
            val noteCenterX = if (isShifted) baseNoteCenterX + noteWidth * 0.85f else baseNoteCenterX

            val ledgerWidth = noteWidth * 1.8f

            // Vẽ dòng kẻ phụ (Ledger lines) nếu nốt nằm ngoài khuông nhạc
            if (step < 0) {
                for (s in -2 downTo step step 2) {
                    val ledgerY = bottomLineY - (s * stepHeight)
                    drawLine(color = textColor, start = Offset(noteCenterX - ledgerWidth / 2, ledgerY), end = Offset(noteCenterX + ledgerWidth / 2, ledgerY), strokeWidth = 3f)
                }
            } else if (step > 8) {
                for (s in 10..step step 2) {
                    val ledgerY = bottomLineY - (s * stepHeight)
                    drawLine(color = textColor, start = Offset(noteCenterX - ledgerWidth / 2, ledgerY), end = Offset(noteCenterX + ledgerWidth / 2, ledgerY), strokeWidth = 3f)
                }
            }

            // Vẽ hạt nốt nhạc
            rotate(degrees = -25f, pivot = Offset(noteCenterX, noteCenterY)) {
                drawOval(
                    color = tunaGreen,
                    topLeft = Offset(noteCenterX - noteWidth / 2, noteCenterY - noteHeight / 2),
                    size = Size(noteWidth, noteHeight),
                    style = Stroke(width = 4.5f)
                )
            }
        }
    }
}
data class MatchTile(
    val x: Int, val y: Int,
    val chord: ChordModel,
    val position: ChordPosition,
    val isStaff: Boolean, // Xác định ô này vẽ Khuông Nhạc hay Cần Đàn
    val uniqueId: String
)
data class NoteMatchTile(
    val x: Int, val y: Int,
    val note: NotePosition,
    val isStaff: Boolean, // Xác định ô này vẽ Khuông Nhạc hay Cần Đàn/Phím
    val uniqueId: String
)
@Composable
fun MatchingGamePhase(
    allChords: List<ChordModel>, instrument: String, lang: String,
    textColor: Color, surfaceColor: Color, bgColor: Color, tunaGreen: Color, onClose: () -> Unit // THÊM bgColor: Color, VÀO ĐÂY
) {
    val context = LocalContext.current
    val columns = 3
    val rows = 6
    val totalPairs = (columns * rows) / 2

    // Trạng thái Game (THÊM THỜI GIAN VÀ BIẾN ĐẾM)
    var isPlaying by remember { mutableStateOf(true) }
    var isForceStopped by remember { mutableStateOf(false) }
    var timeLeft by remember { mutableIntStateOf(120) } // 2 phút cho 1 ván
    var wrongCount by remember { mutableIntStateOf(0) } // Đếm số lần nối sai

    var board by remember { mutableStateOf<Array<Array<MatchTile?>>>(emptyArray()) }
    var selectedTile by remember { mutableStateOf<MatchTile?>(null) }
    var checkingTile by remember { mutableStateOf<MatchTile?>(null) } // Lưu ô thứ 2 đang check
    var isEvaluating by remember { mutableStateOf(false) } // Khóa click khi đang check
    val coroutineScope = rememberCoroutineScope() // Scope để tạo delay
    var matchedPairs by remember { mutableIntStateOf(0) }
    var matchLines by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }

    // Thống kê thời gian thực
    val accuracy = if (matchedPairs + wrongCount == 0) 0 else (matchedPairs * 100) / (matchedPairs + wrongCount)
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", timeLeft / 60, timeLeft % 60)

    // Khởi tạo Map
// Khởi tạo Map
    LaunchedEffect(Unit) {
        // SỬA TẠI ĐÂY: Thêm điều kiện chỉ lấy hợp âm trưởng, thứ, 7, và m7
        val validChords = allChords.filter {
            !it.key.contains("#") && !it.key.contains("b") &&
                    (it.suffix == "major" || it.suffix == "minor" || it.suffix == "7" || it.suffix == "m7")
        }.filter { it.positions.isNotEmpty() }

        val selectedChords = mutableListOf<ChordModel>()

        // Thêm an toàn phòng trường hợp mảng bị rỗng
        if (validChords.isNotEmpty()) {
            while (selectedChords.size < totalPairs) {
                selectedChords.add(validChords.random())
            }
        }

        val tileList = mutableListOf<MatchTile>()
        selectedChords.forEachIndexed { index, chord ->
            val pos = chord.positions.random()
            tileList.add(MatchTile(0, 0, chord, pos, isStaff = true, uniqueId = "${index}_STAFF"))
            tileList.add(MatchTile(0, 0, chord, pos, isStaff = false, uniqueId = "${index}_BOARD"))
        }
        tileList.shuffle()

        val newBoard = Array(columns + 2) { Array<MatchTile?>(rows + 2) { null } }
        var listIndex = 0
        for (x in 1..columns) {
            for (y in 1..rows) {
                newBoard[x][y] = tileList[listIndex].copy(x = x, y = y)
                listIndex++
            }
        }
        board = newBoard
    }

    // Đếm ngược thời gian (THÊM MỚI)
    LaunchedEffect(isPlaying) {
        while (isPlaying && timeLeft > 0) {
            delay(1000L)
            timeLeft--
            if (timeLeft == 0) isPlaying = false
        }
    }

    // Tự động kết thúc khi ăn hết (THÊM MỚI)
    LaunchedEffect(matchedPairs) {
        if (matchedPairs == totalPairs && totalPairs > 0) {
            isPlaying = false
        }
    }

    fun findPath(x1: Int, y1: Int, x2: Int, y2: Int): List<Pair<Int, Int>>? {
        if (x1 == x2 && y1 == y2) return null
        val queue = ArrayDeque<Triple<Pair<Int, Int>, List<Pair<Int, Int>>, Pair<Int, Int>>>()
        val visited = mutableSetOf<Triple<Int, Int, Pair<Int, Int>>>()

        val directions = listOf(Pair(0, -1), Pair(0, 1), Pair(-1, 0), Pair(1, 0))
        for (dir in directions) {
            queue.add(Triple(Pair(x1, y1), listOf(Pair(x1, y1)), dir))
        }

        while (queue.isNotEmpty()) {
            val (current, path, currentDir) = queue.removeFirst()
            val turns = path.zipWithNext().zipWithNext().count { (a, b) ->
                val dir1 = Pair(a.second.first - a.first.first, a.second.second - a.first.second)
                val dir2 = Pair(b.second.first - b.first.first, b.second.second - b.first.second)
                dir1 != dir2
            }
            if (turns > 2) continue

            if (current.first == x2 && current.second == y2) return path

            for (dir in directions) {
                val nx = current.first + dir.first
                val ny = current.second + dir.second

                if (nx in 0..(columns + 1) && ny in 0..(rows + 1)) {
                    val isEnd = (nx == x2 && ny == y2)
                    if (board[nx][ny] == null || isEnd) {
                        val state = Triple(nx, ny, dir)
                        if (!visited.contains(state)) {
                            visited.add(state)
                            queue.add(Triple(Pair(nx, ny), path + Pair(nx, ny), dir))
                        }
                    }
                }
            }
        }
        return null
    }

    LaunchedEffect(matchLines) {
        if (matchLines.isNotEmpty()) {
            delay(400)
            matchLines = emptyList()
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(bgColor).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) { // SỬA: Dùng bgColor
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    if (matchedPairs > 0 || wrongCount > 0) {
                        isPlaying = false
                        isForceStopped = true
                    } else {
                        onClose()
                    }
                },
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = textColor) // SỬA: Dùng textColor
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(CoreTranslator.getString("game_matching_note_title", lang), color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold) // SỬA: Dùng textColor
        }
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(title = CoreTranslator.getString("stat_time", lang), value = timeString, valueColor = textColor) // SỬA: Dùng textColor
            StatItem(title = CoreTranslator.getString("stat_matched", lang), value = "$matchedPairs", valueColor = tunaGreen)
            StatItem(title = CoreTranslator.getString("stat_wrong", lang), value = "$wrongCount", valueColor = Color(0xFFF56C6C))
            StatItem(title = CoreTranslator.getString("stat_accuracy", lang), value = "$accuracy%", valueColor = Color(0xFF409EFF))
        }
        Spacer(modifier = Modifier.height(24.dp))

// BÀN CHƠI GAME
        if (board.isNotEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                    for (y in 1..rows) {
                        // SỬA ĐỔI 1: Thêm weight(1f) vào Row để 6 hàng giãn đều lấp đầy khoảng trống dọc của màn hình
                        Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            for (x in 1..columns) {
                                val tile = board[x][y]
                                // SỬA ĐỔI 2: Thay aspectRatio bằng fillMaxHeight để ô cờ trở thành hình chữ nhật (cao hơn)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .padding(3.dp)
                                ) {
                                    if (tile != null) {
                                        val isSelected = selectedTile?.uniqueId == tile.uniqueId
                                        val isChecking = checkingTile?.uniqueId == tile.uniqueId // Check xem có phải ô thứ 2 không

                                        // Chuyển màu ô thứ 2 thành tím nhạt
                                        val cardBgColor = when {
                                            isSelected -> tunaGreen.copy(alpha = 0.5f)
                                            isChecking -> Color(0xFFB388FF).copy(alpha = 0.5f) // Màu tím nhạt
                                            else -> surfaceColor
                                        }
                                        val cardBorderColor = when {
                                            isSelected -> tunaGreen
                                            isChecking -> Color(0xFFB388FF)
                                            else -> surfaceColor.copy(alpha = 0.5f)
                                        }

                                        Card(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clickable {
                                                    if (!isPlaying || isEvaluating) return@clickable // Khóa click khi đang delay

                                                    if (selectedTile == null) {
                                                        selectedTile = tile
                                                    } else {
                                                        if (selectedTile?.uniqueId != tile.uniqueId) {
                                                            checkingTile = tile // Đánh dấu ô thứ 2
                                                            isEvaluating = true // Bật cờ đang chấm điểm

                                                            // Tạo delay để hiện màu tím trước khi check
                                                            coroutineScope.launch {
                                                                kotlinx.coroutines.delay(350) // Khựng lại 350ms

                                                                val isMatchInfo = selectedTile!!.chord.key == tile.chord.key &&
                                                                        selectedTile!!.chord.suffix == tile.chord.suffix &&
                                                                        selectedTile!!.isStaff != tile.isStaff

                                                                if (isMatchInfo) {
                                                                    val path = findPath(selectedTile!!.x, selectedTile!!.y, tile.x, tile.y)
                                                                    if (path != null) {
                                                                        val newBoard = board.map { it.clone() }.toTypedArray()
                                                                        newBoard[selectedTile!!.x][selectedTile!!.y] = null
                                                                        newBoard[tile.x][tile.y] = null
                                                                        board = newBoard
                                                                        matchLines = path
                                                                        matchedPairs++
                                                                        try { playHitSound(context) } catch (e: Exception) {}
                                                                    } else {
                                                                        wrongCount++
                                                                        try { playQuizSound(context, false) } catch (e: Exception) {}
                                                                    }
                                                                } else {
                                                                    wrongCount++
                                                                    try { playQuizSound(context, false) } catch (e: Exception) {}
                                                                }

                                                                // Kết thúc đánh giá, reset màu cả 2 ô
                                                                selectedTile = null
                                                                checkingTile = null
                                                                isEvaluating = false
                                                            }
                                                        } else {
                                                            // Bấm lại ô thứ 1 thì hủy chọn
                                                            selectedTile = null
                                                        }
                                                    }
                                                },
                                            colors = CardDefaults.cardColors(containerColor = cardBgColor),
                                            border = BorderStroke(2.dp, cardBorderColor)
                                        ) {
                                            if (tile.isStaff) {
                                                Box(
                                                    modifier = Modifier.fillMaxSize().wrapContentSize(Alignment.Center, unbounded = true),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    // Trả size về nhỏ gọn và zoom out xuống 0.7f để vừa vặn trong ô cờ
                                                    Box(modifier = Modifier.requiredSize(120.dp, 85.dp).graphicsLayer { scaleX = 0.7f; scaleY = 0.7f }) {
                                                        ChordStaffDiagram(
                                                            midis = tile.position.midi, instrument = instrument,
                                                            textColor = textColor, tunaGreen = tunaGreen,
                                                            modifier = Modifier.fillMaxSize()
                                                        )
                                                    }
                                                }
                                            }else {
                                                val chordName = "${tile.chord.key}${if (tile.chord.suffix == "minor") "m" else if (tile.chord.suffix == "major") "" else tile.chord.suffix}".toMusicSymbols()

                                                Column(
                                                    // Trả lại Center để tổng thể chữ và đàn nằm cân đối giữa ô
                                                    modifier = Modifier.fillMaxSize(),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    val nameSize = if (chordName.length > 5) 12.sp else 16.sp // Tăng size chữ lên một tí cho dễ đọc
                                                    Text(
                                                        text = chordName,
                                                        color = textColor,
                                                        fontSize = nameSize,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1
                                                    )

                                                    if (instrument == "Piano") {
                                                        Box(
                                                            modifier = Modifier
                                                                .requiredSize(150.dp, 90.dp)
                                                                // Kéo giật Piano lên trên 10dp để ăn bớt khoảng trống
                                                                .offset(y = (-10).dp)
                                                                .graphicsLayer { scaleX = 0.85f; scaleY = 0.85f },
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            CompactChordPianoDiagram("", tile.position.midi, textColor, tunaGreen)
                                                        }
                                                    } else {
                                                        Box(
                                                            modifier = Modifier
                                                                .requiredSize(130.dp, 120.dp)
                                                                // SỬA TẠI ĐÂY: Tăng y lên 16.dp để đẩy toàn bộ cần đàn tụt xuống dưới
                                                                .offset(x = (-8).dp, y = 16.dp)
                                                                .graphicsLayer { scaleX = 0.65f; scaleY = 0.65f },
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            PracticeFretboardDiagram(
                                                                chordName = "",
                                                                frets = tile.position.frets,
                                                                fingers = tile.position.fingers,
                                                                baseFret = tile.position.baseFret,
                                                                numStrings = if (instrument == "Guitar") 6 else 4,
                                                                textColor = textColor,
                                                                tunaGreen = tunaGreen
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // (Đoạn mã vẽ tia sét nối hình matchLines giữ nguyên như cũ của bạn)
                if (matchLines.isNotEmpty()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cellW = size.width / columns
                        val cellH = size.height / rows

                        val path = androidx.compose.ui.graphics.Path()
                        matchLines.forEachIndexed { index, pair ->
                            // SỬA Ở ĐÂY: Ép tọa độ mép ngoài (0 và cột+1/hàng+1) lùi vào 16 pixel để nằm gọn trong màn hình
                            val px = when (pair.first) {
                                0 -> 16f
                                columns + 1 -> size.width - 16f
                                else -> (pair.first - 1) * cellW + cellW / 2
                            }

                            val py = when (pair.second) {
                                0 -> 16f
                                rows + 1 -> size.height - 16f
                                else -> (pair.second - 1) * cellH + cellH / 2
                            }

                            if (index == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }

                        drawPath(
                            path = path,
                            color = Color(0xFF00E5FF),
                            style = Stroke(width = 8f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
                        )
                    }
                }
            }
        }

        // BẢNG KẾT QUẢ KHI KẾT THÚC (THÊM MỚI)
        if (!isPlaying && (timeLeft == 0 || isForceStopped || matchedPairs == totalPairs)) {
            val playedTime = 120 - timeLeft
            LaunchedEffect(Unit) {
                val gson = com.google.gson.Gson()
                val wrongAnswersJson = gson.toJson(emptyList<WrongAnswerData>())
                saveGameHistory(context, instrument, "MATCHING", matchedPairs, totalPairs, playedTime, wrongAnswersJson)
            }
            ResultPhase(
                score = matchedPairs,
                total = totalPairs, // <-- SỬA LẠI THÀNH totalPairs (Chỉ hiển thị 9)
                totalElapsedTime = playedTime,
                wrongAnswers = emptyList(),
                lang = lang, textColor = textColor, surfaceColor = surfaceColor, tunaGreen = tunaGreen,
                gameType = "MATCHING",       // <-- Truyền cờ nhận diện game
                wrongMatchCount = wrongCount // <-- Truyền số lần bấm sai vào
            ) { onClose() }
        }
    }
}
@Composable
fun PracticeFretboardDiagram(
    chordName: String,
    frets: List<Int>,
    fingers: List<Int> = emptyList(),
    baseFret: Int,
    numStrings: Int,
    textColor: Color,
    tunaGreen: Color
) {
    val textPaint = remember {
        android.graphics.Paint().apply {
            textSize = if (numStrings == 4) 22f else 28f
            textAlign = android.graphics.Paint.Align.CENTER
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (chordName.isNotEmpty()) {
            Text(text = chordName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = textColor)
            Spacer(modifier = Modifier.height(20.dp))
        }

        Box(contentAlignment = Alignment.TopStart) {
            Canvas(modifier = Modifier.width(100.dp).height(120.dp)) {
                val w = size.width
                val h = size.height
                val numFrets = 4
                val stringSpacing = w / (numStrings - 1)
                val fretSpacing = h / numFrets

                // SỬA TẠI ĐÂY: Thu nhỏ bán kính nốt bấm riêng cho Ukulele (numStrings == 4)
                val dotRadius = if (numStrings == 4) stringSpacing * 0.28f else stringSpacing * 0.45f

                for (i in 0..numFrets) {
                    val y = i * fretSpacing
                    val isNut = (i == 0 && baseFret == 1)
                    drawLine(
                        color = if (isNut) textColor else textColor.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = if (isNut) 12f else 3f
                    )
                }

                for (i in 0 until numStrings) {
                    val x = i * stringSpacing
                    drawLine(
                        color = textColor.copy(alpha = 0.8f),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 3f
                    )
                }

                val pressedFingers = fingers.filterIndexed { index, finger -> finger == 1 && frets.getOrNull(index) ?: 0 > 0 }
                if (pressedFingers.size > 1) {
                    val barreFretIndex = frets.indexOfFirst { fingers.getOrNull(frets.indexOf(it)) == 1 && it > 0 }
                    if (barreFretIndex != -1) {
                        val barreFret = frets[barreFretIndex]
                        val minString = frets.indexOfFirst { it == barreFret && fingers.getOrNull(frets.indexOf(it)) == 1 }
                        val maxString = frets.indexOfLast { it == barreFret && fingers.getOrNull(frets.indexOf(it)) == 1 }

                        if (maxString > minString) {
                            val startX = minString * stringSpacing
                            val endX = maxString * stringSpacing
                            val y = (barreFret - 0.5f) * fretSpacing

                            drawLine(
                                color = tunaGreen,
                                start = Offset(startX, y),
                                end = Offset(endX, y),
                                // SỬA TẠI ĐÂY: Ukulele 1.5f, Guitar (phần else) giảm còn 1.2f cho cân đối với nốt to
                                strokeWidth = if (numStrings == 4) dotRadius * 1.5f else dotRadius * 1.2f,
                                cap = StrokeCap.Round
                            )

                            drawContext.canvas.nativeCanvas.drawText(
                                "1",
                                startX,
                                y - ((textPaint.descent() + textPaint.ascent()) / 2),
                                textPaint
                            )
                        }
                    }
                }

                frets.forEachIndexed { stringIndex, fretPosition ->
                    val x = stringIndex * stringSpacing

                    when {
                        fretPosition == -1 -> {
                            val xSize = dotRadius * 0.6f
                            val topY = -fretSpacing * 0.5f
                            drawLine(textColor, Offset(x - xSize, topY - xSize), Offset(x + xSize, topY + xSize), 4f, StrokeCap.Round)
                            drawLine(textColor, Offset(x + xSize, topY - xSize), Offset(x - xSize, topY + xSize), 4f, StrokeCap.Round)
                        }
                        fretPosition == 0 -> {
                            drawCircle(
                                color = textColor,
                                radius = dotRadius * 0.6f,
                                center = Offset(x, -fretSpacing * 0.5f),
                                style = Stroke(width = 4f)
                            )
                        }
                        fretPosition > 0 -> {
                            val fingerNum = fingers.getOrNull(stringIndex) ?: 0
                            val y = (fretPosition - 0.5f) * fretSpacing

                            val isPartOfBarre = fingerNum == 1 && frets.count { it == fretPosition && fingers.getOrNull(frets.indexOf(it)) == 1 } > 1

                            if (!isPartOfBarre) {
                                drawCircle(color = tunaGreen, radius = dotRadius, center = Offset(x, y))

                                if (fingerNum > 0) {
                                    drawContext.canvas.nativeCanvas.drawText(
                                        fingerNum.toString(),
                                        x,
                                        y - ((textPaint.descent() + textPaint.ascent()) / 2),
                                        textPaint
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (baseFret > 1) {
                Text(
                    text = "${baseFret}fr",
                    color = textColor.copy(alpha = 0.6f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.offset(x = 112.dp, y = 8.dp)
                )
            }
        }
    }
}
@Composable
fun NoteMatchingGamePhase(
    instrument: String, lang: String,
    textColor: Color, surfaceColor: Color, bgColor: Color, tunaGreen: Color, onClose: () -> Unit // THÊM bgColor: Color, VÀO ĐÂY
) {
    val context = LocalContext.current
    val columns = 3
    val rows = 6
    val totalPairs = (columns * rows) / 2

    var isPlaying by remember { mutableStateOf(true) }
    var isForceStopped by remember { mutableStateOf(false) }
    var timeLeft by remember { mutableIntStateOf(120) }
    var wrongCount by remember { mutableIntStateOf(0) }

    var board by remember { mutableStateOf<Array<Array<NoteMatchTile?>>>(emptyArray()) }
    var selectedTile by remember { mutableStateOf<NoteMatchTile?>(null) }
    var checkingTile by remember { mutableStateOf<NoteMatchTile?>(null) }
    var isEvaluating by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    var matchedPairs by remember { mutableIntStateOf(0) }
    var matchLines by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }

    val accuracy = if (matchedPairs + wrongCount == 0) 0 else (matchedPairs * 100) / (matchedPairs + wrongCount)
    val timeString = String.format(java.util.Locale.getDefault(), "%02d:%02d", timeLeft / 60, timeLeft % 60)

    // Khởi tạo Map
// Khởi tạo Map
    LaunchedEffect(Unit) {
        val noteNamesList = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val validNotes = mutableListOf<NotePosition>()

        // Giới hạn vùng bốc nốt để sơ đồ không bị quá dị
        if (instrument == "Piano") {
            for (m in 60..71) { // C4 đến B4
                validNotes.add(NotePosition(noteNamesList[m % 12], -1, -1, m))
            }
        } else {
            val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
            for (s in openMidi.indices) {
                for (f in 0..4) { // Lấy 4 ngăn đầu
                    val m = openMidi[s] + f
                    validNotes.add(NotePosition(noteNamesList[m % 12], s, f, m))
                }
            }
        }

        // Lọc bỏ nốt có dấu hóa (#/b)
        val easyNotes = validNotes.filter { !it.name.contains("#") && !it.name.contains("b") }
        val selectedNotes = mutableListOf<NotePosition>()

        // BẢO VỆ CHỐNG VĂNG APP: Nếu không có nốt, tạo nốt mặc định
        if (easyNotes.isNotEmpty()) {
            while (selectedNotes.size < totalPairs) {
                selectedNotes.add(easyNotes.random())
            }
        } else {
            while (selectedNotes.size < totalPairs) {
                selectedNotes.add(NotePosition("C", 0, 0, 60)) // Fallback an toàn
            }
        }

        val tileList = mutableListOf<NoteMatchTile>()
        selectedNotes.forEachIndexed { index, note ->
            tileList.add(NoteMatchTile(0, 0, note, isStaff = true, uniqueId = "${index}_STAFF"))
            tileList.add(NoteMatchTile(0, 0, note, isStaff = false, uniqueId = "${index}_BOARD"))
        }
        tileList.shuffle()

        val newBoard = Array(columns + 2) { Array<NoteMatchTile?>(rows + 2) { null } }
        var listIndex = 0
        for (x in 1..columns) {
            for (y in 1..rows) {
                if (listIndex < tileList.size) { // Đảm bảo an toàn vòng lặp
                    newBoard[x][y] = tileList[listIndex].copy(x = x, y = y)
                    listIndex++
                }
            }
        }
        board = newBoard
    }
    LaunchedEffect(isPlaying) {
        while (isPlaying && timeLeft > 0) {
            delay(1000L)
            timeLeft--
            if (timeLeft == 0) isPlaying = false
        }
    }

    LaunchedEffect(matchedPairs) {
        if (matchedPairs == totalPairs && totalPairs > 0) {
            isPlaying = false
        }
    }

    fun findPath(x1: Int, y1: Int, x2: Int, y2: Int): List<Pair<Int, Int>>? {
        if (x1 == x2 && y1 == y2) return null
        val queue = ArrayDeque<Triple<Pair<Int, Int>, List<Pair<Int, Int>>, Pair<Int, Int>>>()
        val visited = mutableSetOf<Triple<Int, Int, Pair<Int, Int>>>()

        val directions = listOf(Pair(0, -1), Pair(0, 1), Pair(-1, 0), Pair(1, 0))
        for (dir in directions) {
            queue.add(Triple(Pair(x1, y1), listOf(Pair(x1, y1)), dir))
        }

        while (queue.isNotEmpty()) {
            val (current, path, currentDir) = queue.removeFirst()
            val turns = path.zipWithNext().zipWithNext().count { (a, b) ->
                val dir1 = Pair(a.second.first - a.first.first, a.second.second - a.first.second)
                val dir2 = Pair(b.second.first - b.first.first, b.second.second - b.first.second)
                dir1 != dir2
            }
            if (turns > 2) continue

            if (current.first == x2 && current.second == y2) return path

            for (dir in directions) {
                val nx = current.first + dir.first
                val ny = current.second + dir.second

                if (nx in 0..(columns + 1) && ny in 0..(rows + 1)) {
                    val isEnd = (nx == x2 && ny == y2)
                    if (board[nx][ny] == null || isEnd) {
                        val state = Triple(nx, ny, dir)
                        if (!visited.contains(state)) {
                            visited.add(state)
                            queue.add(Triple(Pair(nx, ny), path + Pair(nx, ny), dir))
                        }
                    }
                }
            }
        }
        return null
    }

    LaunchedEffect(matchLines) {
        if (matchLines.isNotEmpty()) {
            delay(400)
            matchLines = emptyList()
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0F0F0F)).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    if (matchedPairs > 0 || wrongCount > 0) {
                        isPlaying = false
                        isForceStopped = true
                    } else {
                        onClose()
                    }
                },
                modifier = Modifier.background(surfaceColor, CircleShape).size(36.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(CoreTranslator.getString("game_matching_note_title", lang), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(title = CoreTranslator.getString("stat_time", lang), value = timeString, valueColor = Color.White)
            StatItem(title = CoreTranslator.getString("stat_matched", lang), value = "$matchedPairs", valueColor = tunaGreen)
            StatItem(title = CoreTranslator.getString("stat_wrong", lang), value = "$wrongCount", valueColor = Color(0xFFF56C6C))
            StatItem(title = CoreTranslator.getString("stat_accuracy", lang), value = "$accuracy%", valueColor = Color(0xFF409EFF))
        }
        Spacer(modifier = Modifier.height(24.dp))

        if (board.isNotEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                    for (y in 1..rows) {
                        Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            for (x in 1..columns) {
                                val tile = board[x][y]
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .padding(3.dp)
                                ) {
                                    if (tile != null) {
                                        val isSelected = selectedTile?.uniqueId == tile.uniqueId
                                        val isChecking = checkingTile?.uniqueId == tile.uniqueId

                                        val cardBgColor = when {
                                            isSelected -> tunaGreen.copy(alpha = 0.5f)
                                            isChecking -> Color(0xFFB388FF).copy(alpha = 0.5f)
                                            else -> surfaceColor
                                        }
                                        val cardBorderColor = when {
                                            isSelected -> tunaGreen
                                            isChecking -> Color(0xFFB388FF)
                                            else -> surfaceColor.copy(alpha = 0.5f)
                                        }

                                        Card(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clickable {
                                                    if (!isPlaying || isEvaluating) return@clickable

                                                    if (selectedTile == null) {
                                                        selectedTile = tile
                                                    } else {
                                                        if (selectedTile?.uniqueId != tile.uniqueId) {
                                                            checkingTile = tile
                                                            isEvaluating = true

                                                            coroutineScope.launch {
                                                                kotlinx.coroutines.delay(350)

                                                                // Định nghĩa lại logic Match: 2 ô phải đại diện cho CÙNG 1 nốt nhạc (Dây/Ngăn/Midi) nhưng 1 ô là hình ảnh 1 ô là chữ/khuông
                                                                val isMatchInfo = selectedTile!!.note.name == tile.note.name &&
                                                                        selectedTile!!.note.stringIdx == tile.note.stringIdx &&
                                                                        selectedTile!!.note.fret == tile.note.fret &&
                                                                        selectedTile!!.isStaff != tile.isStaff

                                                                if (isMatchInfo) {
                                                                    val path = findPath(selectedTile!!.x, selectedTile!!.y, tile.x, tile.y)
                                                                    if (path != null) {
                                                                        val newBoard = board.map { it.clone() }.toTypedArray()
                                                                        newBoard[selectedTile!!.x][selectedTile!!.y] = null
                                                                        newBoard[tile.x][tile.y] = null
                                                                        board = newBoard
                                                                        matchLines = path
                                                                        matchedPairs++
                                                                        try { playHitSound(context) } catch (e: Exception) {}
                                                                    } else {
                                                                        wrongCount++
                                                                        try { playQuizSound(context, false) } catch (e: Exception) {}
                                                                    }
                                                                } else {
                                                                    wrongCount++
                                                                    try { playQuizSound(context, false) } catch (e: Exception) {}
                                                                }

                                                                selectedTile = null
                                                                checkingTile = null
                                                                isEvaluating = false
                                                            }
                                                        } else {
                                                            selectedTile = null
                                                        }
                                                    }
                                                },
                                            colors = CardDefaults.cardColors(containerColor = cardBgColor),
                                            border = BorderStroke(2.dp, cardBorderColor)
                                        ) {
                                            if (tile.isStaff) {
                                                val actualMidi = if (tile.note.midi != -1) tile.note.midi else {
                                                    val openMidi = if (instrument == "Guitar") listOf(64, 59, 55, 50, 45, 40) else listOf(69, 64, 60, 67)
                                                    if (tile.note.stringIdx != -1 && tile.note.stringIdx < openMidi.size) openMidi[tile.note.stringIdx] + tile.note.fret else 60
                                                }
                                                Box(
                                                    modifier = Modifier.fillMaxSize().wrapContentSize(Alignment.Center, unbounded = true),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    // SỬA TẠI ĐÂY: Giảm scaleX và scaleY xuống 0.7f
                                                    Box(modifier = Modifier.requiredSize(120.dp, 85.dp).graphicsLayer { scaleX = 0.7f; scaleY = 0.7f }) {
                                                        SingleNoteStaffDiagram(
                                                            midi = actualMidi, instrument = instrument,
                                                            textColor = textColor, tunaGreen = tunaGreen,
                                                            modifier = Modifier.fillMaxSize()
                                                        )
                                                    }
                                                }
                                            } else {
                                                Column(
                                                    modifier = Modifier.fillMaxSize(),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    Text(
                                                        text = tile.note.name,
                                                        color = textColor,
                                                        fontSize = 18.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1
                                                    )

                                                    if (instrument == "Piano") {
                                                        Box(
                                                            modifier = Modifier
                                                                .requiredSize(150.dp, 90.dp)
                                                                .offset(y = (-10).dp)
                                                                .graphicsLayer { scaleX = 0.85f; scaleY = 0.85f },
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            SingleNotePianoDiagram(listOf(tile.note), false, textColor, tunaGreen)
                                                        }
                                                    } else {
                                                        // BẮT ĐẦU SỬA TỪ ĐÂY
                                                        Box(
                                                            modifier = Modifier
                                                                .requiredSize(130.dp, 120.dp) // Cân lại height chuẩn
                                                                .offset(x = (-8).dp, y = 16.dp) // Đẩy xuống để không lẹm chữ
                                                                .graphicsLayer { scaleX = 0.65f; scaleY = 0.65f },
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            VerticalSingleNoteFretboardDiagram(
                                                                instrument = instrument,
                                                                targetNote = tile.note,
                                                                textColor = textColor,
                                                                tunaGreen = tunaGreen
                                                            )
                                                        }
                                                        // KẾT THÚC ĐOẠN SỬA
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (matchLines.isNotEmpty()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cellW = size.width / columns
                        val cellH = size.height / rows

                        val path = androidx.compose.ui.graphics.Path()
                        matchLines.forEachIndexed { index, pair ->
                            val px = when (pair.first) {
                                0 -> 16f
                                columns + 1 -> size.width - 16f
                                else -> (pair.first - 1) * cellW + cellW / 2
                            }

                            val py = when (pair.second) {
                                0 -> 16f
                                rows + 1 -> size.height - 16f
                                else -> (pair.second - 1) * cellH + cellH / 2
                            }

                            if (index == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }

                        drawPath(
                            path = path,
                            color = Color(0xFF00E5FF),
                            style = Stroke(width = 8f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
                        )
                    }
                }
            }
        }

        if (!isPlaying && (timeLeft == 0 || isForceStopped || matchedPairs == totalPairs)) {
            val playedTime = 120 - timeLeft
            LaunchedEffect(Unit) {
                val gson = com.google.gson.Gson()
                val wrongAnswersJson = gson.toJson(emptyList<WrongAnswerData>())
                saveGameHistory(context, instrument, "NOTE_MATCHING", matchedPairs, totalPairs, playedTime, wrongAnswersJson)
            }
            ResultPhase(
                score = matchedPairs,
                total = totalPairs,
                totalElapsedTime = playedTime,
                wrongAnswers = emptyList(),
                lang = lang, textColor = textColor, surfaceColor = surfaceColor, tunaGreen = tunaGreen,
                gameType = "MATCHING",
                wrongMatchCount = wrongCount
            ) { onClose() }
        }
    }
}
@Composable
fun VerticalSingleNoteFretboardDiagram(
    instrument: String,
    targetNote: NotePosition,
    textColor: Color,
    tunaGreen: Color
) {
    val numStrings = if (instrument == "Guitar") 6 else 4
    val numFrets = 4

    Box(contentAlignment = Alignment.TopStart) {
        Canvas(modifier = Modifier.width(100.dp).height(120.dp)) {
            val w = size.width
            val h = size.height
            val stringSpacing = w / (numStrings - 1)
            val fretSpacing = h / numFrets

            val dotRadius = if (numStrings == 4) stringSpacing * 0.28f else stringSpacing * 0.45f

            // 1. Vẽ Lược đàn và các phím
            for (i in 0..numFrets) {
                val y = i * fretSpacing
                val isNut = (i == 0)
                drawLine(
                    color = if (isNut) textColor else textColor.copy(alpha = 0.5f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = if (isNut) 12f else 3f
                )
            }

            // 2. Vẽ Dây đàn
            for (i in 0 until numStrings) {
                val x = i * stringSpacing
                drawLine(
                    color = textColor.copy(alpha = 0.8f),
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 3f
                )
            }

            // 3. Vẽ vị trí Nốt bấm
            if (targetNote.stringIdx != -1 && targetNote.fret != -1) {
                // Đảo ngược index dây: Dây trầm (bass) nằm bên trái cùng
                val mappedIdx = (numStrings - 1) - targetNote.stringIdx
                val x = mappedIdx * stringSpacing

                if (targetNote.fret == 0) {
                    // Dây buông: Vẽ vòng tròn rỗng ở trên lược đàn
                    drawCircle(
                        color = tunaGreen,
                        radius = dotRadius * 0.7f,
                        center = Offset(x, -fretSpacing * 0.35f),
                        style = Stroke(width = 5f)
                    )
                } else if (targetNote.fret > 0) {
                    // Bấm phím: Vẽ chấm tròn đặc giữa ngăn đàn
                    val y = (targetNote.fret - 0.5f) * fretSpacing
                    drawCircle(color = tunaGreen, radius = dotRadius, center = Offset(x, y))
                }
            }
        }
    }
}