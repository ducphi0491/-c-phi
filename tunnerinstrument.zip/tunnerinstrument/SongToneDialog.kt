package ducphi.tunnerinstrument

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Chức năng gợi ý tone giọng hát cấp độ 1.
 *
 * Toàn bộ UI, thu microphone, nhận diện cao độ và chấm điểm tone đều nằm trong
 * duy nhất file này. Không dùng API/PHP và không thay đổi dữ liệu bài hát gốc.
 */

private const val SONG_TONE_RECORD_DURATION_MS = 7_000L
private const val SONG_TONE_SAMPLE_RATE = 44_100
private const val SONG_TONE_FRAME_SIZE = 4_096

private enum class SongToneStage {
    INTRO,
    COUNTDOWN,
    LISTENING,
    ANALYZING,
    RESULT,
    PERMISSION_DENIED,
    ERROR
}

private data class SongToneObservation(
    val midi: Double,
    val confidence: Float,
    val rms: Float
)

private data class SongToneCapture(
    val observations: List<SongToneObservation>,
    val acceptedFrames: Int,
    val heardPitchClasses: List<Int>
)

private data class SongToneCandidate(
    val rootPitchClass: Int,
    val offsetFromOriginal: Int,
    val score: Double
)

private data class SongToneAnalysis(
    val candidates: List<SongToneCandidate>,
    val confidence: Float,
    val acceptedFrames: Int,
    val heardPitchClasses: List<Int>
)

private data class ParsedSongKey(
    val rootPitchClass: Int,
    val isMinor: Boolean
)

/**
 * Chuỗi dùng chung cho icon nằm trong SongDetailHeader và nội dung dialog.
 * Không cần sửa translations.json; ngôn ngữ mới được giữ trong file này.
 */
fun songToneText(key: String, currentLang: String): String {
    val language = currentLang.lowercase().substringBefore('-').substringBefore('_')
    val english = SONG_TONE_TRANSLATIONS.getValue("en")
    val selected = SONG_TONE_TRANSLATIONS[language] ?: english
    return selected[key] ?: english[key] ?: key
}

@Composable
fun SongToneDialog(
    currentLang: String,
    baseTone: String,
    currentTransposeOffset: Int,
    tunaGreen: Color,
    surfaceColor: Color,
    textColor: Color,
    onDismiss: () -> Unit,
    onApplyOffset: (Int) -> Unit
) {
    val context = LocalContext.current
    val isDark = textColor.red + textColor.green + textColor.blue > 1.5f
    val mutedText = if (isDark) Color(0xFFA9A9A9) else Color(0xFF666666)
    val cardBorder = if (isDark) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.14f)
    val innerSurface = if (isDark) Color(0xFF1A1A1A) else Color(0xFFF5F5F5)
    val softButtonColor = if (isDark) Color.White.copy(alpha = 0.92f) else Color(0xFFF4F4F4)
    val softButtonTextColor = Color(0xFF171717)
    val softButtonBorder = if (isDark) Color.White.copy(alpha = 0.22f) else Color.Black.copy(alpha = 0.12f)

    var stage by remember { mutableStateOf(SongToneStage.INTRO) }
    var captureToken by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(3) }
    var progress by remember { mutableFloatStateOf(0f) }
    var liveNote by remember { mutableStateOf("--") }
    var analysis by remember { mutableStateOf<SongToneAnalysis?>(null) }
    var selectedCandidateIndex by remember { mutableIntStateOf(0) }
    var errorMessage by remember { mutableStateOf("") }
    var showGuide by remember { mutableStateOf(false) }

    val startDetection: () -> Unit = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            captureToken += 1
        } else {
            stage = SongToneStage.PERMISSION_DENIED
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            captureToken += 1
        } else {
            stage = SongToneStage.PERMISSION_DENIED
        }
    }

    LaunchedEffect(captureToken) {
        if (captureToken <= 0) return@LaunchedEffect

        analysis = null
        selectedCandidateIndex = 0
        progress = 0f
        liveNote = "--"
        errorMessage = ""
        showGuide = false

        try {
            stage = SongToneStage.COUNTDOWN
            for (value in 3 downTo 1) {
                countdown = value
                delay(700L)
            }

            stage = SongToneStage.LISTENING
            val capture = SongToneEngine.captureVoice(
                durationMs = SONG_TONE_RECORD_DURATION_MS,
                onProgress = { value, note ->
                    progress = value
                    if (note.isNotBlank()) liveNote = note
                }
            )

            stage = SongToneStage.ANALYZING
            delay(350L)

            val result = SongToneEngine.analyzeTone(capture, baseTone)
            if (result == null || result.candidates.isEmpty()) {
                errorMessage = songToneText("insufficient_body", currentLang)
                stage = SongToneStage.ERROR
            } else {
                analysis = result
                stage = SongToneStage.RESULT
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (security: SecurityException) {
            errorMessage = songToneText("permission_body", currentLang)
            stage = SongToneStage.PERMISSION_DENIED
        } catch (throwable: Throwable) {
            errorMessage = throwable.message?.takeIf { it.isNotBlank() }
                ?: songToneText("generic_error", currentLang)
            stage = SongToneStage.ERROR
        }
    }

    val currentTone = SongToneEngine.displayTone(baseTone, currentTransposeOffset)
    val diagnosedTone = analysis
        ?.candidates
        ?.getOrNull(selectedCandidateIndex.coerceAtLeast(0))
        ?.let { SongToneEngine.displayTone(baseTone, it.offsetFromOriginal) }
        ?: "--"

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .widthIn(max = 430.dp),
            shape = RoundedCornerShape(20.dp),
            color = surfaceColor,
            tonalElevation = 8.dp,
            shadowElevation = 18.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, cardBorder)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(tunaGreen.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = tunaGreen,
                            modifier = Modifier.size(21.dp)
                        )
                    }

                    Spacer(Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = songToneText("title", currentLang),
                            color = textColor,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = songToneText("subtitle", currentLang),
                            color = mutedText,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (stage == SongToneStage.INTRO) {
                        IconButton(
                            onClick = { showGuide = !showGuide },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = songToneText("sing_hint", currentLang),
                                tint = if (showGuide) tunaGreen else mutedText,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = songToneText("close", currentLang),
                            tint = mutedText,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = cardBorder)
                Spacer(Modifier.height(12.dp))

                SongToneComparisonCard(
                    currentLang = currentLang,
                    currentTone = currentTone,
                    diagnosedTone = diagnosedTone,
                    tunaGreen = tunaGreen,
                    innerSurface = innerSurface,
                    textColor = textColor,
                    mutedText = mutedText
                )

                if (stage == SongToneStage.INTRO && showGuide) {
                    Spacer(Modifier.height(10.dp))
                    SongToneGuideCard(
                        currentLang = currentLang,
                        tunaGreen = tunaGreen,
                        innerSurface = innerSurface,
                        mutedText = mutedText
                    )
                }

                Spacer(Modifier.height(14.dp))

                when (stage) {
                    SongToneStage.INTRO -> {
                        SongToneIntroContent(
                            currentLang = currentLang,
                            tunaGreen = tunaGreen,
                            innerSurface = innerSurface,
                            textColor = textColor,
                            softButtonColor = softButtonColor,
                            softButtonTextColor = softButtonTextColor,
                            softButtonBorder = softButtonBorder,
                            onStart = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    startDetection()
                                } else {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        )
                    }

                    SongToneStage.COUNTDOWN -> {
                        Text(
                            text = songToneText("prepare", currentLang),
                            color = mutedText,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(9.dp))
                        Box(
                            modifier = Modifier
                                .size(78.dp)
                                .background(innerSurface, CircleShape)
                                .border(1.dp, tunaGreen.copy(alpha = 0.35f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = countdown.toString(),
                                color = tunaGreen,
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    SongToneStage.LISTENING -> {
                        SongToneListeningContent(
                            currentLang = currentLang,
                            progress = progress,
                            liveNote = liveNote,
                            tunaGreen = tunaGreen,
                            textColor = textColor,
                            mutedText = mutedText,
                            innerSurface = innerSurface
                        )
                    }

                    SongToneStage.ANALYZING -> {
                        CircularProgressIndicator(
                            color = tunaGreen,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = songToneText("analyzing", currentLang),
                            color = textColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = songToneText("analyzing_hint", currentLang),
                            color = mutedText,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    SongToneStage.RESULT -> {
                        val value = analysis
                        if (value != null && value.candidates.isNotEmpty()) {
                            SongToneResultContent(
                                currentLang = currentLang,
                                baseTone = baseTone,
                                currentTransposeOffset = currentTransposeOffset,
                                analysis = value,
                                selectedIndex = selectedCandidateIndex,
                                onSelectedIndexChange = { selectedCandidateIndex = it },
                                tunaGreen = tunaGreen,
                                innerSurface = innerSurface,
                                textColor = textColor,
                                mutedText = mutedText,
                                softButtonColor = softButtonColor,
                                softButtonTextColor = softButtonTextColor,
                                softButtonBorder = softButtonBorder,
                                onRetry = { captureToken += 1 },
                                onApply = {
                                    val chosen = value.candidates[selectedCandidateIndex.coerceIn(value.candidates.indices)]
                                    onApplyOffset(chosen.offsetFromOriginal)
                                }
                            )
                        }
                    }

                    SongToneStage.PERMISSION_DENIED -> {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = mutedText,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(Modifier.height(9.dp))
                        Text(
                            text = songToneText("permission_title", currentLang),
                            color = textColor,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(5.dp))
                        Text(
                            text = songToneText("permission_body", currentLang),
                            color = mutedText,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            modifier = Modifier.widthIn(min = 160.dp, max = 210.dp).height(40.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = softButtonColor,
                                contentColor = softButtonTextColor
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, softButtonBorder),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp)
                        ) {
                            Text(
                                text = songToneText("grant_permission", currentLang),
                                color = softButtonTextColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    SongToneStage.ERROR -> {
                        Text(
                            text = songToneText("insufficient_title", currentLang),
                            color = textColor,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = errorMessage.ifBlank { songToneText("insufficient_body", currentLang) },
                            color = mutedText,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = onDismiss,
                                modifier = Modifier.width(122.dp).height(40.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = softButtonColor,
                                    contentColor = softButtonTextColor
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, softButtonBorder),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text(
                                    songToneText("close", currentLang),
                                    color = softButtonTextColor,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Button(
                                onClick = { captureToken += 1 },
                                modifier = Modifier.width(122.dp).height(40.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = softButtonColor,
                                    contentColor = softButtonTextColor
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, softButtonBorder),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Icon(Icons.Default.Replay, contentDescription = null, tint = softButtonTextColor, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    songToneText("retry", currentLang),
                                    color = softButtonTextColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(11.dp))
                Text(
                    text = songToneText("local_only", currentLang),
                    color = mutedText.copy(alpha = 0.72f),
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun SongToneComparisonCard(
    currentLang: String,
    currentTone: String,
    diagnosedTone: String,
    tunaGreen: Color,
    innerSurface: Color,
    textColor: Color,
    mutedText: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(innerSurface, RoundedCornerShape(12.dp))
            .border(1.dp, mutedText.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = songToneText("current_tone", currentLang),
                color = mutedText,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = currentTone,
                color = textColor,
                fontSize = 23.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
        }

        Box(
            modifier = Modifier
                .size(30.dp)
                .background(tunaGreen.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = tunaGreen,
                modifier = Modifier.size(17.dp)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = songToneText("suggested_tone", currentLang),
                color = mutedText,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = diagnosedTone,
                color = if (diagnosedTone == "--") mutedText else tunaGreen,
                fontSize = 23.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SongToneGuideCard(
    currentLang: String,
    tunaGreen: Color,
    innerSurface: Color,
    mutedText: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(innerSurface, RoundedCornerShape(10.dp))
            .border(1.dp, tunaGreen.copy(alpha = 0.20f), RoundedCornerShape(10.dp))
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .background(tunaGreen.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = tunaGreen,
                modifier = Modifier.size(17.dp)
            )
        }
        Spacer(Modifier.width(9.dp))
        Text(
            text = songToneText("sing_hint", currentLang),
            color = mutedText,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SongToneIntroContent(
    currentLang: String,
    tunaGreen: Color,
    innerSurface: Color,
    textColor: Color,
    softButtonColor: Color,
    softButtonTextColor: Color,
    softButtonBorder: Color,
    onStart: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(innerSurface, CircleShape)
                .border(1.dp, tunaGreen.copy(alpha = 0.30f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(29.dp)
            )
        }

        Spacer(Modifier.height(14.dp))

        Button(
            onClick = onStart,
            modifier = Modifier.widthIn(min = 160.dp, max = 195.dp).height(40.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = softButtonColor,
                contentColor = softButtonTextColor
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, softButtonBorder),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 14.dp)
        ) {
            Icon(Icons.Default.Mic, contentDescription = null, tint = softButtonTextColor, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                text = songToneText("start", currentLang),
                color = softButtonTextColor,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SongToneListeningContent(
    currentLang: String,
    progress: Float,
    liveNote: String,
    tunaGreen: Color,
    textColor: Color,
    mutedText: Color,
    innerSurface: Color
) {
    val remainingSeconds = ceil((SONG_TONE_RECORD_DURATION_MS * (1f - progress.coerceIn(0f, 1f))) / 1000f)
        .toInt()
        .coerceAtLeast(0)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        SongToneWaveIndicator(color = tunaGreen)
        Spacer(Modifier.height(8.dp))
        Text(
            text = songToneText("listening", currentLang),
            color = textColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(innerSurface, RoundedCornerShape(10.dp))
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(songToneText("heard_note", currentLang), color = mutedText, fontSize = 10.sp)
                Text(liveNote, color = tunaGreen, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(songToneText("remaining", currentLang), color = mutedText, fontSize = 10.sp)
                Text("${remainingSeconds}s", color = textColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = progress.coerceIn(0f, 1f),
            modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
            color = tunaGreen,
            trackColor = tunaGreen.copy(alpha = 0.16f)
        )
    }
}

@Composable
private fun SongToneResultContent(
    currentLang: String,
    baseTone: String,
    currentTransposeOffset: Int,
    analysis: SongToneAnalysis,
    selectedIndex: Int,
    onSelectedIndexChange: (Int) -> Unit,
    tunaGreen: Color,
    innerSurface: Color,
    textColor: Color,
    mutedText: Color,
    softButtonColor: Color,
    softButtonTextColor: Color,
    softButtonBorder: Color,
    onRetry: () -> Unit,
    onApply: () -> Unit
) {
    val safeIndex = selectedIndex.coerceIn(analysis.candidates.indices)
    val selected = analysis.candidates[safeIndex]
    val relativeAdjustment = SongToneEngine.normalizeSignedOffset(selected.offsetFromOriginal - currentTransposeOffset)
    val confidenceKey = when {
        analysis.confidence >= 0.72f -> "confidence_high"
        analysis.confidence >= 0.48f -> "confidence_medium"
        else -> "confidence_low"
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            analysis.candidates.take(3).forEachIndexed { index, candidate ->
                val selectedCandidate = index == safeIndex
                val tone = SongToneEngine.displayTone(baseTone, candidate.offsetFromOriginal)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (selectedCandidate) tunaGreen.copy(alpha = 0.16f) else innerSurface)
                        .border(
                            width = if (selectedCandidate) 1.5.dp else 1.dp,
                            color = if (selectedCandidate) tunaGreen else mutedText.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(9.dp)
                        )
                        .clickable { onSelectedIndexChange(index) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tone,
                        color = if (selectedCandidate) tunaGreen else textColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(Modifier.height(11.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(innerSurface, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 9.dp)
        ) {
            ResultInfoRow(
                label = songToneText("adjustment", currentLang),
                value = SongToneEngine.formatAdjustment(relativeAdjustment, currentLang),
                labelColor = mutedText,
                valueColor = if (relativeAdjustment == 0) textColor else tunaGreen
            )
            Spacer(Modifier.height(6.dp))
            ResultInfoRow(
                label = songToneText("confidence", currentLang),
                value = songToneText(confidenceKey, currentLang),
                labelColor = mutedText,
                valueColor = textColor
            )
            Spacer(Modifier.height(6.dp))
            ResultInfoRow(
                label = songToneText("stable_notes", currentLang),
                value = analysis.heardPitchClasses.joinToString(" · ") { SongToneEngine.pitchClassName(it) },
                labelColor = mutedText,
                valueColor = textColor
            )
        }

        Spacer(Modifier.height(9.dp))
        Text(
            text = songToneText("result_note", currentLang),
            color = mutedText,
            fontSize = 9.sp,
            lineHeight = 13.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onRetry,
                modifier = Modifier.width(126.dp).height(40.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = softButtonColor,
                    contentColor = softButtonTextColor
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, softButtonBorder),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 7.dp)
            ) {
                Icon(Icons.Default.Replay, contentDescription = null, tint = softButtonTextColor, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    songToneText("retry", currentLang),
                    color = softButtonTextColor,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.width(10.dp))

            Button(
                onClick = onApply,
                modifier = Modifier.width(126.dp).height(40.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = softButtonColor,
                    contentColor = softButtonTextColor
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, softButtonBorder),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 7.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = softButtonTextColor, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    songToneText("apply", currentLang),
                    color = softButtonTextColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ResultInfoRow(
    label: String,
    value: String,
    labelColor: Color,
    valueColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = labelColor, fontSize = 11.sp)
        Spacer(Modifier.width(10.dp))
        Text(
            value,
            color = valueColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SongToneWaveIndicator(color: Color) {
    val transition = rememberInfiniteTransition(label = "song_tone_wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "song_tone_wave_phase"
    )

    Row(
        modifier = Modifier.height(42.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(7) { index ->
            val wave = ((cos((phase + index * 0.85f).toDouble()) + 1.0) / 2.0).toFloat()
            val height = 9.dp + 25.dp * wave
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(height)
                    .background(color.copy(alpha = 0.55f + wave * 0.45f), CircleShape)
            )
        }
    }
}

private object SongToneEngine {
    private val noteNames = listOf("C", "C♯", "D", "E♭", "E", "F", "F♯", "G", "A♭", "A", "B♭", "B")
    private val sharpNames = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val flatNames = listOf("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")

    // Krumhansl-Schmuckler key profiles.
    private val majorProfile = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val minorProfile = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    @SuppressLint("MissingPermission")
    suspend fun captureVoice(
        durationMs: Long,
        onProgress: (Float, String) -> Unit
    ): SongToneCapture = withContext(Dispatchers.Default) {
        val minBuffer = AudioRecord.getMinBufferSize(
            SONG_TONE_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        if (minBuffer <= 0) {
            throw IllegalStateException("AudioRecord buffer unavailable")
        }

        val bufferSizeBytes = max(minBuffer, SONG_TONE_FRAME_SIZE * 2 * 2)
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SONG_TONE_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSizeBytes
        )

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            throw IllegalStateException("Microphone initialization failed")
        }

        val observations = mutableListOf<SongToneObservation>()
        val buffer = ShortArray(SONG_TONE_FRAME_SIZE)
        val startedAt = android.os.SystemClock.elapsedRealtime()
        var lastUiUpdate = 0L
        var lastDisplayedNote = "--"

        try {
            recorder.startRecording()

            while (currentCoroutineContext().isActive) {
                val elapsed = android.os.SystemClock.elapsedRealtime() - startedAt
                if (elapsed >= durationMs) break

                val read = recorder.read(buffer, 0, buffer.size)
                if (read <= 0) continue

                val detected = detectPitch(buffer, read, SONG_TONE_SAMPLE_RATE)
                if (detected != null) {
                    val midi = 69.0 + 12.0 * log2(detected.frequency / 440.0)
                    val nearestMidi = midi.roundToInt()
                    val cents = (midi - nearestMidi) * 100.0

                    if (abs(cents) <= 47.0 && detected.confidence >= 0.72f) {
                        observations += SongToneObservation(
                            midi = midi,
                            confidence = detected.confidence,
                            rms = detected.rms
                        )
                        lastDisplayedNote = midiName(nearestMidi)
                    }
                }

                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastUiUpdate >= 90L) {
                    lastUiUpdate = now
                    val value = ((now - startedAt).toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main.immediate) {
                        onProgress(value, lastDisplayedNote)
                    }
                }
            }
        } finally {
            try {
                if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop()
            } catch (_: Throwable) {
            }
            recorder.release()
        }

        withContext(Dispatchers.Main.immediate) {
            onProgress(1f, lastDisplayedNote)
        }

        val pitchClasses = observations
            .groupingBy { positiveMod(it.midi.roundToInt(), 12) }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(6)
            .map { it.key }

        SongToneCapture(
            observations = observations,
            acceptedFrames = observations.size,
            heardPitchClasses = pitchClasses
        )
    }

    fun analyzeTone(capture: SongToneCapture, baseTone: String): SongToneAnalysis? {
        if (capture.observations.size < 12) return null

        val parsedKey = parseKey(baseTone) ?: ParsedSongKey(rootPitchClass = 0, isMinor = false)
        val histogram = DoubleArray(12)
        var confidenceSum = 0.0

        capture.observations.forEach { observation ->
            val pitchClass = positiveMod(observation.midi.roundToInt(), 12)
            val loudnessWeight = (observation.rms / 0.08f).coerceIn(0.25f, 1f)
            val weight = observation.confidence.toDouble() * loudnessWeight.toDouble()
            histogram[pitchClass] += weight
            confidenceSum += observation.confidence
        }

        val totalWeight = histogram.sum()
        if (totalWeight <= 0.0) return null

        val distinctPitchClasses = histogram.count { it > totalWeight * 0.025 }
        if (distinctPitchClasses < 3) return null

        val profile = if (parsedKey.isMinor) minorProfile else majorProfile
        val lastPitchClass = capture.observations.lastOrNull()?.midi?.roundToInt()?.let { positiveMod(it, 12) }

        val candidates = (0 until 12).map { candidateRoot ->
            var dot = 0.0
            var histogramNorm = 0.0
            var profileNorm = 0.0

            for (degree in 0 until 12) {
                val observed = histogram[(candidateRoot + degree) % 12]
                val expected = profile[degree]
                dot += observed * expected
                histogramNorm += observed * observed
                profileNorm += expected * expected
            }

            var score = if (histogramNorm > 0.0 && profileNorm > 0.0) {
                dot / (sqrt(histogramNorm) * sqrt(profileNorm))
            } else {
                0.0
            }

            // Một câu hát thường kết thúc ở chủ âm hoặc bậc 5; dùng bonus nhỏ để phá hòa.
            if (lastPitchClass == candidateRoot) score += 0.035
            if (lastPitchClass == (candidateRoot + 7) % 12) score += 0.015

            SongToneCandidate(
                rootPitchClass = candidateRoot,
                offsetFromOriginal = signedOffset(parsedKey.rootPitchClass, candidateRoot),
                score = score
            )
        }.sortedByDescending { it.score }

        val best = candidates.firstOrNull() ?: return null
        val second = candidates.getOrNull(1)
        val scoreGap = if (second != null) (best.score - second.score).coerceAtLeast(0.0) else 0.0
        val gapQuality = (scoreGap / 0.075).coerceIn(0.0, 1.0)
        val frameQuality = (capture.observations.size / 45.0).coerceIn(0.0, 1.0)
        val diversityQuality = (distinctPitchClasses / 6.0).coerceIn(0.0, 1.0)
        val averagePitchConfidence = (confidenceSum / capture.observations.size).coerceIn(0.0, 1.0)

        val overallConfidence = (
                0.34 * gapQuality +
                        0.26 * frameQuality +
                        0.18 * diversityQuality +
                        0.22 * averagePitchConfidence
                ).toFloat().coerceIn(0f, 1f)

        // Loại ứng viên trùng offset (phòng trường hợp mở rộng thuật toán sau này).
        val topCandidates = candidates
            .distinctBy { it.offsetFromOriginal }
            .take(3)

        return SongToneAnalysis(
            candidates = topCandidates,
            confidence = overallConfidence,
            acceptedFrames = capture.acceptedFrames,
            heardPitchClasses = capture.heardPitchClasses
        )
    }

    fun displayTone(baseTone: String, offset: Int): String {
        val safeBase = baseTone.trim().ifBlank { "C" }
        val canonicalBase = Regex("^([A-Ga-g])([#b♯♭]?)(.*)$")
            .find(safeBase)
            ?.let { match ->
                match.groupValues[1].uppercase() +
                        match.groupValues[2].replace("♯", "#").replace("♭", "b") +
                        match.groupValues[3]
            }
            ?: "C"

        return try {
            formatChordForDisplay(transposeSingleChord(canonicalBase, offset))
        } catch (_: Throwable) {
            val parsed = parseKey(canonicalBase) ?: ParsedSongKey(0, false)
            val root = pitchClassName(positiveMod(parsed.rootPitchClass + offset, 12))
            if (parsed.isMinor) "${root}m" else root
        }
    }

    fun pitchClassName(pitchClass: Int): String = noteNames[positiveMod(pitchClass, 12)]

    fun formatAdjustment(offset: Int, currentLang: String): String {
        return when {
            offset == 0 -> songToneText("no_change", currentLang)
            offset > 0 -> "+$offset ${songToneText("semitone", currentLang)}"
            else -> "$offset ${songToneText("semitone", currentLang)}"
        }
    }

    fun normalizeSignedOffset(value: Int): Int {
        var normalized = positiveMod(value, 12)
        if (normalized > 6) normalized -= 12
        return normalized
    }

    private data class PitchDetection(
        val frequency: Double,
        val confidence: Float,
        val rms: Float
    )

    private fun detectPitch(samples: ShortArray, count: Int, sampleRate: Int): PitchDetection? {
        if (count < 2_048) return null

        val downSampleFactor = 2
        val available = min(count / downSampleFactor, 2_048)
        if (available < 1_024) return null

        val data = FloatArray(available)
        var mean = 0.0

        for (index in 0 until available) {
            val sourceIndex = index * downSampleFactor
            val first = samples[sourceIndex].toFloat()
            val second = samples[min(sourceIndex + 1, count - 1)].toFloat()
            val value = ((first + second) * 0.5f) / 32_768f
            data[index] = value
            mean += value
        }
        mean /= available.toDouble()

        var rmsSum = 0.0
        for (index in data.indices) {
            val centered = data[index] - mean.toFloat()
            val window = 0.5f - 0.5f * cos((2.0 * Math.PI * index) / (data.size - 1)).toFloat()
            data[index] = centered * window
            rmsSum += centered * centered
        }

        val rms = sqrt(rmsSum / available.toDouble()).toFloat()
        if (rms < 0.010f) return null

        val effectiveRate = sampleRate / downSampleFactor
        val minFrequency = 70.0
        val maxFrequency = 1_000.0
        val minTau = max(2, (effectiveRate / maxFrequency).toInt())
        val maxTau = min(available / 2, (effectiveRate / minFrequency).toInt())
        if (maxTau <= minTau + 2) return null

        val difference = FloatArray(maxTau + 1)
        val comparisonLength = available - maxTau

        for (tau in minTau..maxTau) {
            var sum = 0.0
            var index = 0
            while (index < comparisonLength) {
                val delta = data[index] - data[index + tau]
                sum += delta * delta
                index++
            }
            difference[tau] = sum.toFloat()
        }

        val cumulative = FloatArray(maxTau + 1)
        cumulative[0] = 1f
        var runningSum = 0.0
        for (tau in 1..maxTau) {
            runningSum += difference[tau]
            cumulative[tau] = if (runningSum <= 1e-12) 1f else (difference[tau] * tau / runningSum).toFloat()
        }

        var selectedTau = -1
        var tau = minTau
        while (tau < maxTau) {
            if (cumulative[tau] < 0.18f) {
                while (tau + 1 <= maxTau && cumulative[tau + 1] < cumulative[tau]) tau++
                selectedTau = tau
                break
            }
            tau++
        }

        if (selectedTau < 0) {
            selectedTau = (minTau..maxTau).minByOrNull { cumulative[it] } ?: return null
            if (cumulative[selectedTau] > 0.30f) return null
        }

        val refinedTau = parabolicTau(cumulative, selectedTau)
        if (refinedTau <= 0.0) return null

        val frequency = effectiveRate / refinedTau
        if (frequency !in minFrequency..maxFrequency) return null

        val confidence = (1f - cumulative[selectedTau]).coerceIn(0f, 1f)
        return PitchDetection(frequency = frequency, confidence = confidence, rms = rms)
    }

    private fun parabolicTau(values: FloatArray, index: Int): Double {
        if (index <= 0 || index >= values.lastIndex) return index.toDouble()
        val left = values[index - 1].toDouble()
        val center = values[index].toDouble()
        val right = values[index + 1].toDouble()
        val denominator = left - 2.0 * center + right
        if (abs(denominator) < 1e-12) return index.toDouble()
        val adjustment = 0.5 * (left - right) / denominator
        return index + adjustment.coerceIn(-1.0, 1.0)
    }

    private fun parseKey(rawTone: String): ParsedSongKey? {
        val normalized = rawTone
            .trim()
            .replace("♯", "#")
            .replace("♭", "b")

        val match = Regex("^([A-Ga-g])([#b]?)(.*)$").find(normalized) ?: return null
        val rootText = match.groupValues[1].uppercase() + match.groupValues[2]
        val suffix = match.groupValues[3].lowercase()

        var root = sharpNames.indexOf(rootText)
        if (root < 0) root = flatNames.indexOf(rootText)
        if (root < 0) return null

        val isMinor = suffix.startsWith("m") && !suffix.startsWith("maj")
        return ParsedSongKey(rootPitchClass = root, isMinor = isMinor)
    }

    private fun signedOffset(fromPitchClass: Int, toPitchClass: Int): Int {
        var value = positiveMod(toPitchClass - fromPitchClass, 12)
        if (value > 6) value -= 12
        return value
    }

    private fun midiName(midi: Int): String {
        val pitchClass = positiveMod(midi, 12)
        val octave = midi / 12 - 1
        return "${pitchClassName(pitchClass)}$octave"
    }

    private fun positiveMod(value: Int, divisor: Int): Int {
        val result = value % divisor
        return if (result < 0) result + divisor else result
    }

    private fun log2(value: Double): Double = ln(value) / ln(2.0)
}

private val SONG_TONE_TRANSLATIONS: Map<String, Map<String, String>> = mapOf(
    "vi" to mapOf(
        "button" to "Dò tone",
        "title" to "Gợi ý tone theo giọng hát",
        "subtitle" to "Hát một câu để tìm tone phù hợp",
        "intro" to "Ứng dụng sẽ nghe cao độ trong khoảng 7 giây và gợi ý cách dịch tone. Dữ liệu âm thanh chỉ được xử lý trên thiết bị.",
        "start" to "Bắt đầu nhận diện",
        "prepare" to "Chuẩn bị hát",
        "sing_hint" to "Hát rõ một câu, để giọng tự nhiên và không mở nhạc nền.",
        "listening" to "Đang lắng nghe giọng hát...",
        "keep_singing" to "Tiếp tục hát đều cho đến khi thanh tiến trình hoàn tất.",
        "heard_note" to "Nốt đang nghe",
        "remaining" to "Còn lại",
        "analyzing" to "Đang phân tích tone...",
        "analyzing_hint" to "Đang lọc các nốt ổn định và so sánh với tone bài hát.",
        "current_tone" to "Tone hiện tại",
        "suggested_tone" to "Tone gợi ý",
        "adjustment" to "Dịch giọng",
        "confidence" to "Độ tin cậy",
        "confidence_high" to "Cao",
        "confidence_medium" to "Trung bình",
        "confidence_low" to "Thấp",
        "stable_notes" to "Các nốt ổn định",
        "retry" to "Hát lại",
        "apply" to "Áp dụng tone",
        "close" to "Đóng",
        "permission_title" to "Cần quyền microphone",
        "permission_body" to "Hãy cấp quyền microphone để ứng dụng nghe và phân tích cao độ giọng hát.",
        "grant_permission" to "Cấp quyền microphone",
        "insufficient_title" to "Chưa đủ tín hiệu",
        "insufficient_body" to "Ứng dụng chưa thu được đủ nốt ổn định. Hãy hát rõ hơn, gần microphone và thử lại.",
        "generic_error" to "Không thể phân tích giọng hát. Vui lòng thử lại.",
        "no_change" to "Giữ nguyên",
        "semitone" to "bán cung",
        "result_note" to "Đây là gợi ý từ một câu hát ngắn. Bạn có thể chọn một trong ba kết quả trước khi áp dụng.",
        "local_only" to "Âm thanh được xử lý trực tiếp trên máy và không tải lên máy chủ."
    ),
    "en" to mapOf(
        "button" to "Find key",
        "title" to "Vocal key suggestion",
        "subtitle" to "Sing one line to find a comfortable key",
        "intro" to "The app listens to your pitch for about 7 seconds and suggests a transposition. Audio is processed only on this device.",
        "start" to "Start detection",
        "prepare" to "Get ready to sing",
        "sing_hint" to "Sing one clear line naturally and keep background music off.",
        "listening" to "Listening to your voice...",
        "keep_singing" to "Keep singing steadily until the progress bar finishes.",
        "heard_note" to "Detected note",
        "remaining" to "Remaining",
        "analyzing" to "Analyzing key...",
        "analyzing_hint" to "Filtering stable notes and comparing them with the song key.",
        "current_tone" to "Current key",
        "suggested_tone" to "Suggested key",
        "adjustment" to "Transpose",
        "confidence" to "Confidence",
        "confidence_high" to "High",
        "confidence_medium" to "Medium",
        "confidence_low" to "Low",
        "stable_notes" to "Stable notes",
        "retry" to "Sing again",
        "apply" to "Apply key",
        "close" to "Close",
        "permission_title" to "Microphone permission required",
        "permission_body" to "Allow microphone access so the app can listen to and analyze your singing pitch.",
        "grant_permission" to "Allow microphone",
        "insufficient_title" to "Not enough signal",
        "insufficient_body" to "Not enough stable notes were captured. Sing more clearly, move closer to the microphone, and try again.",
        "generic_error" to "Your voice could not be analyzed. Please try again.",
        "no_change" to "No change",
        "semitone" to "semitones",
        "result_note" to "This is an estimate from one short phrase. You can select one of the three results before applying it.",
        "local_only" to "Audio is processed on-device and is not uploaded to a server."
    ),
    "fr" to mapOf(
        "button" to "Clé vocale", "title" to "Suggestion de tonalité vocale", "subtitle" to "Chantez une phrase pour trouver une tonalité confortable",
        "intro" to "L’application écoute votre hauteur pendant environ 7 secondes et suggère une transposition.", "start" to "Commencer", "prepare" to "Préparez-vous à chanter",
        "sing_hint" to "Chantez clairement une phrase sans musique de fond.", "listening" to "Écoute de votre voix...", "keep_singing" to "Continuez à chanter régulièrement.",
        "heard_note" to "Note détectée", "remaining" to "Temps restant", "analyzing" to "Analyse de la tonalité...", "analyzing_hint" to "Filtrage des notes stables.",
        "current_tone" to "Tonalité actuelle", "suggested_tone" to "Tonalité suggérée", "adjustment" to "Transposition", "confidence" to "Confiance",
        "confidence_high" to "Élevée", "confidence_medium" to "Moyenne", "confidence_low" to "Faible", "stable_notes" to "Notes stables", "retry" to "Rechanter",
        "apply" to "Appliquer", "close" to "Fermer", "permission_title" to "Autorisation du microphone requise", "permission_body" to "Autorisez le microphone pour analyser votre voix.",
        "grant_permission" to "Autoriser le microphone", "insufficient_title" to "Signal insuffisant", "insufficient_body" to "Chantez plus clairement et réessayez.",
        "generic_error" to "Analyse impossible. Réessayez.", "no_change" to "Aucun changement", "semitone" to "demi-tons", "result_note" to "Estimation basée sur une courte phrase.",
        "local_only" to "L’audio est traité sur l’appareil et n’est pas envoyé au serveur."
    ),
    "es" to mapOf(
        "button" to "Tono vocal", "title" to "Sugerencia de tono vocal", "subtitle" to "Canta una frase para encontrar un tono cómodo",
        "intro" to "La aplicación escucha tu afinación durante unos 7 segundos y sugiere una transposición.", "start" to "Iniciar detección", "prepare" to "Prepárate para cantar",
        "sing_hint" to "Canta una frase clara sin música de fondo.", "listening" to "Escuchando tu voz...", "keep_singing" to "Sigue cantando de forma estable.",
        "heard_note" to "Nota detectada", "remaining" to "Restante", "analyzing" to "Analizando el tono...", "analyzing_hint" to "Filtrando notas estables.",
        "current_tone" to "Tono actual", "suggested_tone" to "Tono sugerido", "adjustment" to "Transposición", "confidence" to "Confianza",
        "confidence_high" to "Alta", "confidence_medium" to "Media", "confidence_low" to "Baja", "stable_notes" to "Notas estables", "retry" to "Cantar de nuevo",
        "apply" to "Aplicar tono", "close" to "Cerrar", "permission_title" to "Se necesita permiso del micrófono", "permission_body" to "Permite el micrófono para analizar tu voz.",
        "grant_permission" to "Permitir micrófono", "insufficient_title" to "Señal insuficiente", "insufficient_body" to "Canta con más claridad y vuelve a intentarlo.",
        "generic_error" to "No se pudo analizar tu voz.", "no_change" to "Sin cambios", "semitone" to "semitonos", "result_note" to "Estimación basada en una frase corta.",
        "local_only" to "El audio se procesa en el dispositivo y no se sube al servidor."
    ),
    "de" to mapOf(
        "button" to "Stimmton", "title" to "Tonart für Ihre Stimme", "subtitle" to "Singen Sie eine Zeile, um eine passende Tonart zu finden",
        "intro" to "Die App hört Ihre Tonhöhe etwa 7 Sekunden lang und schlägt eine Transposition vor.", "start" to "Erkennung starten", "prepare" to "Bereit zum Singen",
        "sing_hint" to "Singen Sie eine klare Zeile ohne Hintergrundmusik.", "listening" to "Stimme wird aufgenommen...", "keep_singing" to "Bitte gleichmäßig weitersingen.",
        "heard_note" to "Erkannter Ton", "remaining" to "Verbleibend", "analyzing" to "Tonart wird analysiert...", "analyzing_hint" to "Stabile Töne werden gefiltert.",
        "current_tone" to "Aktuelle Tonart", "suggested_tone" to "Vorgeschlagene Tonart", "adjustment" to "Transponieren", "confidence" to "Sicherheit",
        "confidence_high" to "Hoch", "confidence_medium" to "Mittel", "confidence_low" to "Niedrig", "stable_notes" to "Stabile Töne", "retry" to "Erneut singen",
        "apply" to "Tonart anwenden", "close" to "Schließen", "permission_title" to "Mikrofonzugriff erforderlich", "permission_body" to "Erlauben Sie den Mikrofonzugriff zur Stimmanalyse.",
        "grant_permission" to "Mikrofon erlauben", "insufficient_title" to "Signal nicht ausreichend", "insufficient_body" to "Singen Sie deutlicher und versuchen Sie es erneut.",
        "generic_error" to "Die Stimme konnte nicht analysiert werden.", "no_change" to "Keine Änderung", "semitone" to "Halbtöne", "result_note" to "Schätzung aus einer kurzen Phrase.",
        "local_only" to "Audio wird nur auf dem Gerät verarbeitet."
    ),
    "it" to mapOf(
        "button" to "Tono voce", "title" to "Suggerimento tonalità vocale", "subtitle" to "Canta una frase per trovare una tonalità comoda",
        "intro" to "L’app ascolta l’intonazione per circa 7 secondi e suggerisce una trasposizione.", "start" to "Avvia rilevamento", "prepare" to "Preparati a cantare",
        "sing_hint" to "Canta una frase chiara senza musica di sottofondo.", "listening" to "Ascolto della voce...", "keep_singing" to "Continua a cantare in modo regolare.",
        "heard_note" to "Nota rilevata", "remaining" to "Rimanente", "analyzing" to "Analisi tonalità...", "analyzing_hint" to "Filtro delle note stabili.",
        "current_tone" to "Tonalità attuale", "suggested_tone" to "Tonalità suggerita", "adjustment" to "Trasposizione", "confidence" to "Affidabilità",
        "confidence_high" to "Alta", "confidence_medium" to "Media", "confidence_low" to "Bassa", "stable_notes" to "Note stabili", "retry" to "Canta di nuovo",
        "apply" to "Applica tonalità", "close" to "Chiudi", "permission_title" to "Permesso microfono richiesto", "permission_body" to "Consenti il microfono per analizzare la voce.",
        "grant_permission" to "Consenti microfono", "insufficient_title" to "Segnale insufficiente", "insufficient_body" to "Canta più chiaramente e riprova.",
        "generic_error" to "Impossibile analizzare la voce.", "no_change" to "Nessuna modifica", "semitone" to "semitoni", "result_note" to "Stima basata su una breve frase.",
        "local_only" to "L’audio viene elaborato sul dispositivo."
    ),
    "pt" to mapOf(
        "button" to "Tom vocal", "title" to "Sugestão de tom vocal", "subtitle" to "Cante uma frase para encontrar um tom confortável",
        "intro" to "O app ouve sua afinação por cerca de 7 segundos e sugere uma transposição.", "start" to "Iniciar detecção", "prepare" to "Prepare-se para cantar",
        "sing_hint" to "Cante uma frase clara sem música de fundo.", "listening" to "Ouvindo sua voz...", "keep_singing" to "Continue cantando de forma estável.",
        "heard_note" to "Nota detectada", "remaining" to "Restante", "analyzing" to "Analisando o tom...", "analyzing_hint" to "Filtrando notas estáveis.",
        "current_tone" to "Tom atual", "suggested_tone" to "Tom sugerido", "adjustment" to "Transposição", "confidence" to "Confiança",
        "confidence_high" to "Alta", "confidence_medium" to "Média", "confidence_low" to "Baixa", "stable_notes" to "Notas estáveis", "retry" to "Cantar novamente",
        "apply" to "Aplicar tom", "close" to "Fechar", "permission_title" to "Permissão do microfone necessária", "permission_body" to "Permita o microfone para analisar sua voz.",
        "grant_permission" to "Permitir microfone", "insufficient_title" to "Sinal insuficiente", "insufficient_body" to "Cante mais claramente e tente novamente.",
        "generic_error" to "Não foi possível analisar sua voz.", "no_change" to "Sem alteração", "semitone" to "semitons", "result_note" to "Estimativa baseada em uma frase curta.",
        "local_only" to "O áudio é processado no dispositivo."
    ),
    "ru" to mapOf(
        "button" to "Тон голоса", "title" to "Тональность для вашего голоса", "subtitle" to "Спойте одну строку для подбора удобной тональности",
        "intro" to "Приложение слушает высоту голоса около 7 секунд и предлагает транспонирование.", "start" to "Начать распознавание", "prepare" to "Приготовьтесь петь",
        "sing_hint" to "Спойте одну фразу без фоновой музыки.", "listening" to "Слушаем ваш голос...", "keep_singing" to "Продолжайте петь ровно.",
        "heard_note" to "Распознанная нота", "remaining" to "Осталось", "analyzing" to "Анализ тональности...", "analyzing_hint" to "Фильтрация устойчивых нот.",
        "current_tone" to "Текущая тональность", "suggested_tone" to "Предлагаемая тональность", "adjustment" to "Транспонирование", "confidence" to "Уверенность",
        "confidence_high" to "Высокая", "confidence_medium" to "Средняя", "confidence_low" to "Низкая", "stable_notes" to "Устойчивые ноты", "retry" to "Спеть снова",
        "apply" to "Применить", "close" to "Закрыть", "permission_title" to "Нужен доступ к микрофону", "permission_body" to "Разрешите доступ к микрофону для анализа голоса.",
        "grant_permission" to "Разрешить микрофон", "insufficient_title" to "Недостаточно сигнала", "insufficient_body" to "Пойте четче и повторите попытку.",
        "generic_error" to "Не удалось проанализировать голос.", "no_change" to "Без изменений", "semitone" to "полутонов", "result_note" to "Оценка по короткой фразе.",
        "local_only" to "Аудио обрабатывается только на устройстве."
    ),
    "ja" to mapOf(
        "button" to "キー判定", "title" to "歌声に合うキー", "subtitle" to "1フレーズ歌って歌いやすいキーを探します",
        "intro" to "約7秒間の音程を端末内で解析し、移調を提案します。", "start" to "検出を開始", "prepare" to "歌う準備をしてください",
        "sing_hint" to "伴奏を止め、自然な声で1フレーズ歌ってください。", "listening" to "歌声を聴いています...", "keep_singing" to "進行バーが終わるまで歌い続けてください。",
        "heard_note" to "検出中の音", "remaining" to "残り", "analyzing" to "キーを解析中...", "analyzing_hint" to "安定した音程を抽出しています。",
        "current_tone" to "現在のキー", "suggested_tone" to "おすすめキー", "adjustment" to "移調", "confidence" to "信頼度",
        "confidence_high" to "高い", "confidence_medium" to "中", "confidence_low" to "低い", "stable_notes" to "安定した音", "retry" to "もう一度歌う",
        "apply" to "キーを適用", "close" to "閉じる", "permission_title" to "マイク権限が必要です", "permission_body" to "歌声を解析するためマイクを許可してください。",
        "grant_permission" to "マイクを許可", "insufficient_title" to "信号が不足しています", "insufficient_body" to "マイクに近づき、はっきり歌ってください。",
        "generic_error" to "歌声を解析できませんでした。", "no_change" to "変更なし", "semitone" to "半音", "result_note" to "短いフレーズからの推定結果です。",
        "local_only" to "音声は端末内のみで処理されます。"
    ),
    "ko" to mapOf(
        "button" to "키 찾기", "title" to "목소리에 맞는 키", "subtitle" to "한 소절을 불러 편한 키를 찾습니다",
        "intro" to "약 7초 동안 음정을 기기에서 분석하여 조옮김을 제안합니다.", "start" to "감지 시작", "prepare" to "노래할 준비를 하세요",
        "sing_hint" to "반주를 끄고 한 소절을 또렷하게 불러 주세요.", "listening" to "목소리를 듣는 중...", "keep_singing" to "진행이 끝날 때까지 안정적으로 불러 주세요.",
        "heard_note" to "감지된 음", "remaining" to "남은 시간", "analyzing" to "키 분석 중...", "analyzing_hint" to "안정적인 음을 추출하고 있습니다.",
        "current_tone" to "현재 키", "suggested_tone" to "추천 키", "adjustment" to "조옮김", "confidence" to "신뢰도",
        "confidence_high" to "높음", "confidence_medium" to "보통", "confidence_low" to "낮음", "stable_notes" to "안정적인 음", "retry" to "다시 부르기",
        "apply" to "키 적용", "close" to "닫기", "permission_title" to "마이크 권한 필요", "permission_body" to "목소리 분석을 위해 마이크를 허용해 주세요.",
        "grant_permission" to "마이크 허용", "insufficient_title" to "신호가 부족합니다", "insufficient_body" to "마이크 가까이에서 더 또렷하게 불러 주세요.",
        "generic_error" to "목소리를 분석할 수 없습니다.", "no_change" to "변경 없음", "semitone" to "반음", "result_note" to "짧은 프레이즈를 바탕으로 한 추정입니다.",
        "local_only" to "오디오는 기기에서만 처리됩니다."
    ),
    "zh" to mapOf(
        "button" to "检测调性", "title" to "人声调性建议", "subtitle" to "唱一句以寻找舒适的调",
        "intro" to "应用会在设备上分析约7秒的音高并建议移调。", "start" to "开始识别", "prepare" to "准备演唱",
        "sing_hint" to "请关闭伴奏，自然清晰地唱一句。", "listening" to "正在聆听您的声音...", "keep_singing" to "请持续稳定演唱直到进度结束。",
        "heard_note" to "检测到的音", "remaining" to "剩余", "analyzing" to "正在分析调性...", "analyzing_hint" to "正在筛选稳定音高。",
        "current_tone" to "当前调", "suggested_tone" to "建议调", "adjustment" to "移调", "confidence" to "置信度",
        "confidence_high" to "高", "confidence_medium" to "中", "confidence_low" to "低", "stable_notes" to "稳定音", "retry" to "重新演唱",
        "apply" to "应用调性", "close" to "关闭", "permission_title" to "需要麦克风权限", "permission_body" to "请允许麦克风以分析您的歌声音高。",
        "grant_permission" to "允许麦克风", "insufficient_title" to "信号不足", "insufficient_body" to "请靠近麦克风并唱得更清晰。",
        "generic_error" to "无法分析您的声音。", "no_change" to "无需更改", "semitone" to "半音", "result_note" to "结果根据一小段演唱估算。",
        "local_only" to "音频仅在设备上处理。"
    ),
    "th" to mapOf(
        "button" to "คีย์เสียง", "title" to "คีย์ที่เหมาะกับเสียงร้อง", "subtitle" to "ร้องหนึ่งประโยคเพื่อค้นหาคีย์ที่สบาย",
        "intro" to "แอปจะวิเคราะห์ระดับเสียงประมาณ 7 วินาทีบนอุปกรณ์และแนะนำการเปลี่ยนคีย์", "start" to "เริ่มตรวจจับ", "prepare" to "เตรียมร้อง",
        "sing_hint" to "ร้องหนึ่งประโยคให้ชัดเจนโดยไม่เปิดเพลงพื้นหลัง", "listening" to "กำลังฟังเสียงของคุณ...", "keep_singing" to "ร้องต่อเนื่องจนแถบความคืบหน้าสิ้นสุด",
        "heard_note" to "โน้ตที่ตรวจพบ", "remaining" to "เหลือ", "analyzing" to "กำลังวิเคราะห์คีย์...", "analyzing_hint" to "กำลังคัดกรองโน้ตที่คงที่",
        "current_tone" to "คีย์ปัจจุบัน", "suggested_tone" to "คีย์แนะนำ", "adjustment" to "เปลี่ยนคีย์", "confidence" to "ความมั่นใจ",
        "confidence_high" to "สูง", "confidence_medium" to "ปานกลาง", "confidence_low" to "ต่ำ", "stable_notes" to "โน้ตที่คงที่", "retry" to "ร้องอีกครั้ง",
        "apply" to "ใช้คีย์", "close" to "ปิด", "permission_title" to "ต้องใช้สิทธิ์ไมโครโฟน", "permission_body" to "อนุญาตไมโครโฟนเพื่อวิเคราะห์เสียงร้อง",
        "grant_permission" to "อนุญาตไมโครโฟน", "insufficient_title" to "สัญญาณไม่เพียงพอ", "insufficient_body" to "ร้องให้ชัดขึ้นและลองอีกครั้ง",
        "generic_error" to "ไม่สามารถวิเคราะห์เสียงได้", "no_change" to "ไม่เปลี่ยน", "semitone" to "ครึ่งเสียง", "result_note" to "เป็นการประมาณจากประโยคสั้น ๆ",
        "local_only" to "เสียงถูกประมวลผลบนอุปกรณ์เท่านั้น"
    ),
    "id" to mapOf(
        "button" to "Nada vokal", "title" to "Saran nada vokal", "subtitle" to "Nyanyikan satu baris untuk mencari nada yang nyaman",
        "intro" to "Aplikasi mendengar pitch sekitar 7 detik dan menyarankan transposisi di perangkat.", "start" to "Mulai deteksi", "prepare" to "Bersiap untuk bernyanyi",
        "sing_hint" to "Nyanyikan satu baris dengan jelas tanpa musik latar.", "listening" to "Mendengarkan suara Anda...", "keep_singing" to "Terus bernyanyi dengan stabil.",
        "heard_note" to "Nada terdeteksi", "remaining" to "Tersisa", "analyzing" to "Menganalisis nada...", "analyzing_hint" to "Menyaring nada yang stabil.",
        "current_tone" to "Nada saat ini", "suggested_tone" to "Nada yang disarankan", "adjustment" to "Transposisi", "confidence" to "Keyakinan",
        "confidence_high" to "Tinggi", "confidence_medium" to "Sedang", "confidence_low" to "Rendah", "stable_notes" to "Nada stabil", "retry" to "Nyanyi lagi",
        "apply" to "Terapkan nada", "close" to "Tutup", "permission_title" to "Izin mikrofon diperlukan", "permission_body" to "Izinkan mikrofon untuk menganalisis suara Anda.",
        "grant_permission" to "Izinkan mikrofon", "insufficient_title" to "Sinyal belum cukup", "insufficient_body" to "Bernyanyilah lebih jelas dan coba lagi.",
        "generic_error" to "Suara tidak dapat dianalisis.", "no_change" to "Tidak berubah", "semitone" to "semitone", "result_note" to "Perkiraan dari satu frasa pendek.",
        "local_only" to "Audio diproses hanya di perangkat."
    ),
    "ar" to mapOf(
        "button" to "طبقة صوت", "title" to "اقتراح طبقة مناسبة لصوتك", "subtitle" to "غنِّ جملة واحدة للعثور على طبقة مريحة",
        "intro" to "يحلل التطبيق طبقة صوتك لمدة 7 ثوانٍ على الجهاز ويقترح النقل.", "start" to "بدء التحليل", "prepare" to "استعد للغناء",
        "sing_hint" to "غنِّ جملة بوضوح من دون موسيقى خلفية.", "listening" to "جارٍ الاستماع إلى صوتك...", "keep_singing" to "استمر في الغناء بثبات.",
        "heard_note" to "النغمة المكتشفة", "remaining" to "المتبقي", "analyzing" to "جارٍ تحليل الطبقة...", "analyzing_hint" to "جارٍ تصفية النغمات المستقرة.",
        "current_tone" to "الطبقة الحالية", "suggested_tone" to "الطبقة المقترحة", "adjustment" to "النقل", "confidence" to "الثقة",
        "confidence_high" to "عالية", "confidence_medium" to "متوسطة", "confidence_low" to "منخفضة", "stable_notes" to "النغمات المستقرة", "retry" to "الغناء مجددًا",
        "apply" to "تطبيق الطبقة", "close" to "إغلاق", "permission_title" to "إذن الميكروفون مطلوب", "permission_body" to "اسمح بالميكروفون لتحليل صوتك.",
        "grant_permission" to "السماح بالميكروفون", "insufficient_title" to "الإشارة غير كافية", "insufficient_body" to "غنِّ بوضوح أكبر ثم حاول مرة أخرى.",
        "generic_error" to "تعذر تحليل الصوت.", "no_change" to "بدون تغيير", "semitone" to "نصف درجة", "result_note" to "تقدير مبني على جملة قصيرة.",
        "local_only" to "تتم معالجة الصوت على الجهاز فقط."
    ),
    "hi" to mapOf(
        "button" to "वोकल की", "title" to "आवाज़ के लिए की सुझाव", "subtitle" to "आरामदायक की खोजने के लिए एक पंक्ति गाएँ",
        "intro" to "ऐप लगभग 7 सेकंड तक आपकी पिच का विश्लेषण कर ट्रांसपोज़ सुझाव देता है।", "start" to "पहचान शुरू करें", "prepare" to "गाने के लिए तैयार हों",
        "sing_hint" to "बिना बैकग्राउंड संगीत के एक पंक्ति साफ़ गाएँ।", "listening" to "आपकी आवाज़ सुन रहे हैं...", "keep_singing" to "प्रगति पूरी होने तक स्थिर स्वर में गाएँ।",
        "heard_note" to "पहचाना गया नोट", "remaining" to "शेष", "analyzing" to "की का विश्लेषण...", "analyzing_hint" to "स्थिर नोट छाँटे जा रहे हैं।",
        "current_tone" to "वर्तमान की", "suggested_tone" to "सुझाई गई की", "adjustment" to "ट्रांसपोज़", "confidence" to "विश्वसनीयता",
        "confidence_high" to "उच्च", "confidence_medium" to "मध्यम", "confidence_low" to "कम", "stable_notes" to "स्थिर नोट", "retry" to "फिर गाएँ",
        "apply" to "की लागू करें", "close" to "बंद करें", "permission_title" to "माइक्रोफ़ोन अनुमति आवश्यक", "permission_body" to "आवाज़ का विश्लेषण करने के लिए माइक्रोफ़ोन की अनुमति दें।",
        "grant_permission" to "माइक्रोफ़ोन अनुमति दें", "insufficient_title" to "सिग्नल पर्याप्त नहीं", "insufficient_body" to "और स्पष्ट गाएँ और फिर प्रयास करें।",
        "generic_error" to "आवाज़ का विश्लेषण नहीं हो सका।", "no_change" to "कोई बदलाव नहीं", "semitone" to "सेमीटोन", "result_note" to "यह छोटी पंक्ति पर आधारित अनुमान है।",
        "local_only" to "ऑडियो केवल डिवाइस पर प्रोसेस होता है।"
    )
)