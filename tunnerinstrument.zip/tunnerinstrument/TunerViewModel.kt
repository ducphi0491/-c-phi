package ducphi.tunnerinstrument

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.SystemClock
import android.util.Log
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

private data class GuitarStringTarget(
    val noteName: String,
    val octave: Int,
    val frequency: Float,
    val midi: Int,
    val displayNote: String = noteName
) {
    val id: String get() = "$noteName$octave"
    val displayWithOctave: String get() = "$displayNote$octave"
}

private data class GuitarTuningPreset(
    val id: String,
    val translationKey: String,
    val vietnameseFallback: String,
    val englishFallback: String,
    val stringsLowToHigh: List<GuitarStringTarget>
) {
    val sequenceLabel: String
        get() = stringsLowToHigh.joinToString(" ") { it.displayNote }
}

private val GUITAR_TUNING_PRESETS = listOf(
    GuitarTuningPreset(
        id = "standard",
        translationKey = "tuning_standard",
        vietnameseFallback = "Tiêu chuẩn",
        englishFallback = "Standard",
        stringsLowToHigh = listOf(
            GuitarStringTarget("E", 2, 82.41f, 40),
            GuitarStringTarget("A", 2, 110.00f, 45),
            GuitarStringTarget("D", 3, 146.83f, 50),
            GuitarStringTarget("G", 3, 196.00f, 55),
            GuitarStringTarget("B", 3, 246.94f, 59),
            GuitarStringTarget("E", 4, 329.63f, 64)
        )
    ),
    GuitarTuningPreset(
        id = "drop_d",
        translationKey = "tuning_drop_d",
        vietnameseFallback = "Drop D",
        englishFallback = "Drop D",
        stringsLowToHigh = listOf(
            GuitarStringTarget("D", 2, 73.42f, 38),
            GuitarStringTarget("A", 2, 110.00f, 45),
            GuitarStringTarget("D", 3, 146.83f, 50),
            GuitarStringTarget("G", 3, 196.00f, 55),
            GuitarStringTarget("B", 3, 246.94f, 59),
            GuitarStringTarget("E", 4, 329.63f, 64)
        )
    ),
    GuitarTuningPreset(
        id = "half_step_down",
        translationKey = "tuning_half_step_down",
        vietnameseFallback = "Hạ nửa cung",
        englishFallback = "Half step down",
        stringsLowToHigh = listOf(
            GuitarStringTarget("D#", 2, 77.78f, 39, "E♭"),
            GuitarStringTarget("G#", 2, 103.83f, 44, "A♭"),
            GuitarStringTarget("C#", 3, 138.59f, 49, "D♭"),
            GuitarStringTarget("F#", 3, 185.00f, 54, "G♭"),
            GuitarStringTarget("A#", 3, 233.08f, 58, "B♭"),
            GuitarStringTarget("D#", 4, 311.13f, 63, "E♭")
        )
    ),
    GuitarTuningPreset(
        id = "whole_step_down",
        translationKey = "tuning_whole_step_down",
        vietnameseFallback = "Hạ một cung",
        englishFallback = "Whole step down",
        stringsLowToHigh = listOf(
            GuitarStringTarget("D", 2, 73.42f, 38),
            GuitarStringTarget("G", 2, 98.00f, 43),
            GuitarStringTarget("C", 3, 130.81f, 48),
            GuitarStringTarget("F", 3, 174.61f, 53),
            GuitarStringTarget("A", 3, 220.00f, 57),
            GuitarStringTarget("D", 4, 293.66f, 62)
        )
    ),
    GuitarTuningPreset(
        id = "dadgad",
        translationKey = "tuning_dadgad",
        vietnameseFallback = "DADGAD",
        englishFallback = "DADGAD",
        stringsLowToHigh = listOf(
            GuitarStringTarget("D", 2, 73.42f, 38),
            GuitarStringTarget("A", 2, 110.00f, 45),
            GuitarStringTarget("D", 3, 146.83f, 50),
            GuitarStringTarget("G", 3, 196.00f, 55),
            GuitarStringTarget("A", 3, 220.00f, 57),
            GuitarStringTarget("D", 4, 293.66f, 62)
        )
    ),
    GuitarTuningPreset(
        id = "open_g",
        translationKey = "tuning_open_g",
        vietnameseFallback = "Open G",
        englishFallback = "Open G",
        stringsLowToHigh = listOf(
            GuitarStringTarget("D", 2, 73.42f, 38),
            GuitarStringTarget("G", 2, 98.00f, 43),
            GuitarStringTarget("D", 3, 146.83f, 50),
            GuitarStringTarget("G", 3, 196.00f, 55),
            GuitarStringTarget("B", 3, 246.94f, 59),
            GuitarStringTarget("D", 4, 293.66f, 62)
        )
    ),
    GuitarTuningPreset(
        id = "open_d",
        translationKey = "tuning_open_d",
        vietnameseFallback = "Open D",
        englishFallback = "Open D",
        stringsLowToHigh = listOf(
            GuitarStringTarget("D", 2, 73.42f, 38),
            GuitarStringTarget("A", 2, 110.00f, 45),
            GuitarStringTarget("D", 3, 146.83f, 50),
            GuitarStringTarget("F#", 3, 185.00f, 54, "F♯"),
            GuitarStringTarget("A", 3, 220.00f, 57),
            GuitarStringTarget("D", 4, 293.66f, 62)
        )
    ),
    GuitarTuningPreset(
        id = "drop_c",
        translationKey = "tuning_drop_c",
        vietnameseFallback = "Drop C",
        englishFallback = "Drop C",
        stringsLowToHigh = listOf(
            GuitarStringTarget("C", 2, 65.41f, 36),
            GuitarStringTarget("G", 2, 98.00f, 43),
            GuitarStringTarget("C", 3, 130.81f, 48),
            GuitarStringTarget("F", 3, 174.61f, 53),
            GuitarStringTarget("A", 3, 220.00f, 57),
            GuitarStringTarget("D", 4, 293.66f, 62)
        )
    )
)

private fun tunerTranslatedText(
    currentLang: String,
    key: String,
    vietnameseFallback: String,
    englishFallback: String
): String {
    val value = runCatching { CoreTranslator.getString(key, currentLang) }.getOrDefault("")
    return if (value.isBlank() || value == key || value.contains("missing translation", ignoreCase = true)) {
        if (currentLang == "vi") vietnameseFallback else englishFallback
    } else {
        value
    }
}

class TunerViewModel : ViewModel() {
    private val _noteName = MutableStateFlow("-")
    val noteName = _noteName.asStateFlow()

    private val _octave = MutableStateFlow(0)
    val octave = _octave.asStateFlow()

    private val _frequency = MutableStateFlow(0f)
    val frequency = _frequency.asStateFlow()

    private val _deviation = MutableStateFlow(0f)
    val deviation = _deviation.asStateFlow()

    // Thêm biến trạng thái nhận biết có âm thanh thực tế
    private val _hasSound = MutableStateFlow(false)
    val hasSound = _hasSound.asStateFlow()

    // Biến trạng thái báo hiệu tần số đang dao động (không bị đóng băng)
    private val _isFluctuating = MutableStateFlow(false)
    val isFluctuating = _isFluctuating.asStateFlow()

    // [THÊM MỚI] Biến báo hiệu: Có âm thanh VÀ âm thanh đó là NỐT NHẠC HỢP LỆ (không phải tiếng quạt)
    private val _hasValidPitch = MutableStateFlow(false)
    val hasValidPitch = _hasValidPitch.asStateFlow()

    private val audioRecordLock = Any()
    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    @Volatile private var isListening = false
    @Volatile private var captureGeneration = 0L
    @Volatile private var chimeStartedAtMs = 0L

    @Volatile
    var isChimePlaying = false
        set(value) {
            field = value
            if (value) {
                chimeStartedAtMs = SystemClock.elapsedRealtime()
            }
        }

    @Volatile private var isAutoMode = true
    @Volatile private var targetFreq = 0f
    @Volatile private var targetNote = "-"
    @Volatile private var targetOct = 0
    @Volatile private var currentInstrument = "Guitar 6-string"
    @Volatile private var currentGuitarTuningFrequencies: List<Float> =
        GUITAR_TUNING_PRESETS.first().stringsLowToHigh.map { it.frequency }

    @Volatile private var transpositionOffset = 0

    private var smoothedDeviation = 0f
    private var smoothedFrequency = 0f

    fun setInstrument(instrument: String) {
        if (currentInstrument != instrument) {
            currentInstrument = instrument
            transpositionOffset = if (instrument == "Saxophone") 9 else 0
            if (isListening) {
                stopListening()
                startListening()
            }
        }
    }

    /**
     * Changes only the six target frequencies used for Guitar auto tuning.
     * Microphone capture, pitch detection, filtering and smoothing remain unchanged.
     */
    fun setGuitarTuningFrequencies(frequencies: List<Float>) {
        val safeFrequencies = frequencies.take(6).toList()
        if (safeFrequencies.size != 6) return

        val tuningChanged = safeFrequencies != currentGuitarTuningFrequencies
        val modeChanged = !isAutoMode
        if (!tuningChanged && !modeChanged) return

        currentGuitarTuningFrequencies = safeFrequencies
        isAutoMode = true
        targetFreq = 0f
        targetNote = "-"
        targetOct = 0
        _noteName.value = "-"
        _octave.value = 0
        _frequency.value = 0f
        _deviation.value = 0f
        _hasSound.value = false
        _isFluctuating.value = false
        _hasValidPitch.value = false
        smoothedDeviation = 0f
        smoothedFrequency = 0f

        if (isListening && currentInstrument == "Guitar 6-string") {
            stopListening()
            startListening()
        }
    }

    fun setAutoMode() {
        if (!isAutoMode) {
            isAutoMode = true
            _noteName.value = "-"
            _octave.value = 0
            _frequency.value = 0f
            _deviation.value = 0f
            smoothedDeviation = 0f
            smoothedFrequency = 0f

            if (isListening) {
                stopListening()
                startListening()
            }
        }
    }

    fun setManualMode(note: String, oct: Int, freq: Float) {
        isAutoMode = false
        targetNote = note
        targetOct = oct
        targetFreq = freq

        _noteName.value = note
        _octave.value = oct
        _frequency.value = 0f
        smoothedDeviation = 0f
        smoothedFrequency = 0f

        if (isListening) {
            stopListening()
            startListening()
        }
    }

    private val notesArray = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    private data class PitchResult(val noteName: String, val octave: Int, val frequency: Float, val centsDeviation: Float)

    private fun getExpectedStringsForInstrument(instrument: String): List<Float> {
        return when (instrument) {
            "Guitar 6-string" -> currentGuitarTuningFrequencies
            "Bass 4-string" -> listOf(41.20f, 55.00f, 73.42f, 98.00f)
            "Bass 5-string" -> listOf(30.87f, 41.20f, 55.00f, 73.42f, 98.00f)
            "Ukulele" -> listOf(261.63f, 329.63f, 392.00f, 440.00f)
            "Violin" -> listOf(196.00f, 293.66f, 440.00f, 659.25f)
            else -> emptyList()
        }
    }

    private fun processPitch(pitchInHz: Float): PitchResult? {
        if (pitchInHz < 20f || pitchInHz > 2000f) return null

        var currentTargetFreq = 0f
        val currentNoteName: String
        val currentOctave: Int

        if (isAutoMode) {
            val expectedStrings = getExpectedStringsForInstrument(currentInstrument)

            if (expectedStrings.isNotEmpty()) {
                var closestStringFreq = expectedStrings[0]
                var minCentsDiff = Float.MAX_VALUE
                var bestAbsDiff = Float.MAX_VALUE

                for (stringFreq in expectedStrings) {
                    var p = pitchInHz
                    while (p > stringFreq * 1.5f) p /= 2f
                    while (p < stringFreq * 0.75f) p *= 2f

                    val cents = kotlin.math.abs(1200 * log2(p / stringFreq).toFloat())
                    val absDiff = kotlin.math.abs(pitchInHz - stringFreq)

                    if (cents < minCentsDiff - 3f) {
                        minCentsDiff = cents
                        closestStringFreq = stringFreq
                        bestAbsDiff = absDiff
                    } else if (kotlin.math.abs(cents - minCentsDiff) <= 3f) {
                        if (absDiff < bestAbsDiff) {
                            minCentsDiff = cents
                            closestStringFreq = stringFreq
                            bestAbsDiff = absDiff
                        }
                    }
                }

                currentTargetFreq = closestStringFreq
                val midi = (69 + 12 * log2(currentTargetFreq / 440.0f)).roundToInt()
                currentNoteName = notesArray[(midi % 12 + 12) % 12]
                currentOctave = (midi / 12) - 1

            } else {
                val actualMidi = (69 + 12 * log2(pitchInHz / 440.0f)).roundToInt()
                currentTargetFreq = (440.0 * 2.0.pow((actualMidi - 69) / 12.0)).toFloat()
                val displayMidi = actualMidi + transpositionOffset
                currentNoteName = notesArray[(displayMidi % 12 + 12) % 12]
                currentOctave = (displayMidi / 12) - 1
            }
        } else {
            currentTargetFreq = targetFreq
            currentNoteName = targetNote
            currentOctave = targetOct
        }

        var adjustedPitch = pitchInHz
        while (adjustedPitch > currentTargetFreq * 1.5f) {
            adjustedPitch /= 2.0f
        }
        while (adjustedPitch < currentTargetFreq * 0.75f) {
            adjustedPitch *= 2.0f
        }

        var displayFreq = adjustedPitch
        var offsetHz = 0f

        when (currentInstrument) {
            "Ukulele" -> {
                when (currentNoteName) {
                    "G" -> offsetHz = 2.5f
                    "C" -> offsetHz = 0.9f
                    "E" -> offsetHz = 1.1f
                }
            }
        }

        if (offsetHz > 0f) {
            displayFreq -= offsetHz
            adjustedPitch -= offsetHz
        }

        val cents = 1200 * log2(adjustedPitch / currentTargetFreq).toFloat()
        return PitchResult(currentNoteName, currentOctave, displayFreq, cents)
    }

    private fun safeStopAndRelease(recorder: AudioRecord?) {
        if (recorder == null) return

        runCatching {
            if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                recorder.stop()
            }
        }.onFailure {
            Log.w("TunerAudio", "AudioRecord.stop() failed: ${it.message}")
        }

        runCatching { recorder.release() }
            .onFailure { Log.w("TunerAudio", "AudioRecord.release() failed: ${it.message}") }
    }

    /**
     * Prevents the tuner from listening to its own success sound. The time guard is
     * important: MediaPlayer completion callbacks are not guaranteed after an audio
     * interruption, so a plain Boolean can otherwise remain true forever.
     */
    private fun shouldPausePitchForChime(): Boolean {
        if (!isChimePlaying) return false

        val elapsed = SystemClock.elapsedRealtime() - chimeStartedAtMs
        if (elapsed >= 2500L) {
            isChimePlaying = false
            return false
        }
        return true
    }

    @SuppressLint("MissingPermission")
    fun startListening() {
        var staleRecorder: AudioRecord? = null
        var staleJob: Job? = null
        val sessionId: Long

        synchronized(audioRecordLock) {
            val currentRecorder = audioRecord
            val captureIsHealthy =
                isListening &&
                        recordingJob?.isActive == true &&
                        currentRecorder?.state == AudioRecord.STATE_INITIALIZED &&
                        currentRecorder?.recordingState == AudioRecord.RECORDSTATE_RECORDING

            if (captureIsHealthy) return

            // A previous worker may already have died while isListening stayed true.
            // Invalidate it and create a new capture generation.
            isListening = true
            captureGeneration += 1L
            sessionId = captureGeneration

            staleRecorder = currentRecorder
            staleJob = recordingJob
            audioRecord = null
            recordingJob = null
        }

        staleJob?.cancel()
        safeStopAndRelease(staleRecorder)

        val newJob = viewModelScope.launch(
            context = Dispatchers.IO,
            start = CoroutineStart.LAZY
        ) {
            var recorder: AudioRecord? = null
            var hadSuccessfulRead = false

            try {
                val sampleRate = 44100
                val windowSize = 4096
                val stepSize = 2048

                val minBufferSize = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_FLOAT
                )

                if (minBufferSize <= 0) {
                    throw IllegalStateException("Invalid AudioRecord buffer size: $minBufferSize")
                }

                val actualBufferSize = maxOf(windowSize * 2, minBufferSize)
                val createdRecorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_FLOAT,
                    actualBufferSize
                )
                recorder = createdRecorder

                if (createdRecorder.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("AudioRecord is not initialized")
                }

                synchronized(audioRecordLock) {
                    if (!isListening || captureGeneration != sessionId) {
                        return@launch
                    }
                    audioRecord = createdRecorder
                }

                createdRecorder.startRecording()
                if (createdRecorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    throw IllegalStateException("AudioRecord failed to enter RECORDING state")
                }

                val slidingBuffer = FloatArray(windowSize)
                val readBuffer = FloatArray(stepSize)

                var isNeedleFrozen = true
                var silentFrames = 0
                var artifactFrames = 0
                var consecutiveReadErrors = 0

                // Buffer of recent pitch results used by the existing mode filter.
                val pitchBuffer = java.util.ArrayDeque<PitchResult>()
                val maxBufferSize = 7

                while (
                    isActive &&
                    isListening &&
                    captureGeneration == sessionId
                ) {
                    val readResult = createdRecorder.read(
                        readBuffer,
                        0,
                        stepSize,
                        AudioRecord.READ_BLOCKING
                    )

                    if (readResult <= 0) {
                        consecutiveReadErrors++

                        val fatalReadError =
                            readResult == AudioRecord.ERROR_DEAD_OBJECT ||
                                    readResult == AudioRecord.ERROR_INVALID_OPERATION ||
                                    readResult == AudioRecord.ERROR_BAD_VALUE

                        if (fatalReadError || consecutiveReadErrors >= 3) {
                            throw IllegalStateException(
                                "AudioRecord.read failed: code=$readResult, count=$consecutiveReadErrors"
                            )
                        }

                        delay(20L)
                        continue
                    }

                    consecutiveReadErrors = 0
                    hadSuccessfulRead = true

                    System.arraycopy(slidingBuffer, readResult, slidingBuffer, 0, windowSize - readResult)
                    System.arraycopy(readBuffer, 0, slidingBuffer, windowSize - readResult, readResult)

                    var sum = 0f
                    for (i in 0 until readResult) {
                        sum += readBuffer[i] * readBuffer[i]
                    }
                    val rms = sqrt(sum / readResult)

                    // Keep the existing noise gate values unchanged.
                    val noiseGate = if (isAutoMode) 0.02f else 0.015f

                    if (rms < noiseGate) {
                        silentFrames++
                        if (silentFrames > 5) {
                            isNeedleFrozen = true
                            _hasSound.value = false
                            _isFluctuating.value = false
                            _hasValidPitch.value = false
                        }
                        continue
                    } else {
                        silentFrames = 0
                        isNeedleFrozen = false
                        _hasSound.value = true
                        _isFluctuating.value = true
                    }

                    if (isNeedleFrozen) continue

                    val pitchInHz = TunerPitchEngine.processAudioData(slidingBuffer, sampleRate)

                    // A watchdog prevents this state from blocking pitch analysis forever.
                    if (shouldPausePitchForChime()) continue

                    if (pitchInHz < 20f) {
                        _hasValidPitch.value = false
                    } else {
                        _hasValidPitch.value = true
                    }

                    val minHz = when (currentInstrument) {
                        "Bass 5-string" -> 20f
                        "Bass 4-string" -> 25f
                        "Guitar 6-string" -> 50f
                        "Violin" -> 140f
                        "Ukulele" -> 200f
                        else -> 20f
                    }

                    if (pitchInHz > minHz && pitchInHz < 2000f) {
                        val pitchResult = processPitch(pitchInHz)
                        if (pitchResult != null) {
                            val maxAllowedDeviation = if (isAutoMode) 350f else 300f

                            if (kotlin.math.abs(pitchResult.centsDeviation) > maxAllowedDeviation) {
                                artifactFrames++
                                if (artifactFrames > 10) {
                                    smoothedFrequency = 0f
                                    isNeedleFrozen = true
                                    pitchBuffer.clear()
                                }
                                continue
                            }

                            if (pitchBuffer.size >= maxBufferSize) {
                                pitchBuffer.removeFirst()
                            }
                            pitchBuffer.addLast(pitchResult)

                            val bestPitchGroup = pitchBuffer
                                .groupBy { (it.frequency * 5).roundToInt() }
                                .maxByOrNull { it.value.size }?.value

                            val rawFreq = bestPitchGroup
                                ?.map { it.frequency }
                                ?.average()
                                ?.toFloat()
                                ?: pitchResult.frequency
                            val rawDeviation = bestPitchGroup
                                ?.map { it.centsDeviation }
                                ?.average()
                                ?.toFloat()
                                ?: pitchResult.centsDeviation
                            val finalNoteName = bestPitchGroup?.first()?.noteName ?: pitchResult.noteName
                            val finalOctave = bestPitchGroup?.first()?.octave ?: pitchResult.octave

                            if (smoothedFrequency > 0f) {
                                val freqDiff = kotlin.math.abs(rawFreq - smoothedFrequency)
                                if (freqDiff > 12f) {
                                    artifactFrames++
                                    if (artifactFrames < 4) {
                                        continue
                                    }
                                } else {
                                    artifactFrames = 0
                                }
                            } else {
                                artifactFrames = 0
                            }

                            _noteName.value = finalNoteName
                            _octave.value = finalOctave

                            val diff = kotlin.math.abs(rawDeviation - smoothedDeviation)
                            val alpha = when {
                                diff > 10f -> 0.60f
                                diff > 3f -> 0.20f
                                else -> 0.15f
                            }

                            smoothedDeviation =
                                (alpha * rawDeviation) + ((1f - alpha) * smoothedDeviation)
                            _deviation.value = smoothedDeviation

                            if (smoothedFrequency == 0f) {
                                smoothedFrequency = rawFreq
                            } else {
                                val freqDiffUI = kotlin.math.abs(rawFreq - smoothedFrequency)
                                val freqAlpha = if (freqDiffUI > 2f) 0.5f else 0.1f
                                smoothedFrequency =
                                    (freqAlpha * rawFreq) + ((1f - freqAlpha) * smoothedFrequency)
                            }
                            _frequency.value = smoothedFrequency
                        }
                    }
                }
            } catch (e: Exception) {
                if (isActive && isListening && captureGeneration == sessionId) {
                    Log.e("TunerAudio", "Microphone capture stopped unexpectedly", e)
                }
            } finally {
                safeStopAndRelease(recorder)

                val shouldRestart = synchronized(audioRecordLock) {
                    if (audioRecord === recorder) {
                        audioRecord = null
                    }
                    if (captureGeneration == sessionId) {
                        recordingJob = null
                    }
                    isListening && captureGeneration == sessionId
                }

                if (shouldRestart) {
                    _frequency.value = 0f
                    _hasSound.value = false
                    _isFluctuating.value = false
                    _hasValidPitch.value = false
                    smoothedDeviation = 0f
                    smoothedFrequency = 0f

                    // If Android temporarily revokes the microphone (call, recorder,
                    // camera, SpeechRecognizer...), recreate AudioRecord automatically.
                    viewModelScope.launch {
                        delay(if (hadSuccessfulRead) 300L else 700L)
                        val stillNeeded = synchronized(audioRecordLock) {
                            isListening &&
                                    captureGeneration == sessionId &&
                                    recordingJob == null
                        }
                        if (stillNeeded) {
                            startListening()
                        }
                    }
                }
            }
        }

        synchronized(audioRecordLock) {
            if (!isListening || captureGeneration != sessionId) {
                newJob.cancel()
                return
            }
            recordingJob = newJob
        }
        newJob.start()
    }

    fun stopListening() {
        val jobToCancel: Job?
        val recorderToRelease: AudioRecord?

        synchronized(audioRecordLock) {
            isListening = false
            captureGeneration += 1L
            jobToCancel = recordingJob
            recorderToRelease = audioRecord
            recordingJob = null
            audioRecord = null
        }

        jobToCancel?.cancel()
        safeStopAndRelease(recorderToRelease)
        isChimePlaying = false

        _frequency.value = 0f
        _noteName.value = "-"
        _octave.value = 0
        _deviation.value = 0f
        _hasSound.value = false
        _isFluctuating.value = false
        _hasValidPitch.value = false
        smoothedDeviation = 0f
        smoothedFrequency = 0f
    }

    override fun onCleared() {
        super.onCleared()
        stopListening()
    }
}

// =========================================================================
// UI COMPOSABLES
// =========================================================================

private enum class TunerHintState {
    UNSTABLE,
    DETECTED,
    NEAR,
    PERFECT,
    ALL_STRINGS_COMPLETE
}

private data class TunerCompletionMessage(
    val stringCount: Int,
    val descriptionKey: String,
    val vietnameseDescription: String,
    val englishDescription: String
)

/**
 * Contextual tuner hint shown as a compact overlay over the tuning graph.
 *
 * The component only reads UI state already produced by [TunerViewModel].
 * It does not change microphone capture, pitch filtering or tuning recognition.
 */
@Composable
private fun SmartTuningHintBanner(
    currentLang: String,
    state: TunerHintState,
    noteLabel: String,
    tunedStringLabel: String? = null,
    completionMessage: TunerCompletionMessage? = null,
    usesStringTuning: Boolean = false,
    isDarkMode: Boolean,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color,
    modifier: Modifier = Modifier
) {
    fun translated(key: String, viFallback: String, enFallback: String): String {
        val value = runCatching { CoreTranslator.getString(key, currentLang) }.getOrDefault("")
        return if (value.isBlank() || value == key || value.contains("missing translation", ignoreCase = true)) {
            if (currentLang == "vi") viFallback else enFallback
        } else {
            value
        }
    }

    // Chuỗi riêng cho nhạc cụ có dây. Giữ trong file Kotlin để không buộc phải
    // thay translations.json chỉ vì đổi nội dung từ "nốt" sang "dây".
    fun tunedStringDescriptionTemplate(): String {
        val key = "tuner_hint_perfect_string_desc"
        val translatedValue = runCatching { CoreTranslator.getString(key, currentLang) }.getOrDefault("")
        if (
            translatedValue.isNotBlank() &&
            translatedValue != key &&
            !translatedValue.contains("missing translation", ignoreCase = true)
        ) {
            return translatedValue
        }

        return when (currentLang.lowercase(java.util.Locale.ROOT).substringBefore('-')) {
            "vi" -> "Dây %1\$s đã chuẩn"
            "es" -> "La cuerda %1\$s está afinada"
            "fr" -> "La corde %1\$s est accordée"
            "de" -> "Saite %1\$s ist richtig gestimmt"
            "ru" -> "Струна %1\$s настроена"
            "ja" -> "弦 %1\$s のチューニングが合いました"
            "zh" -> "%1\$s 弦已调准"
            "th" -> "สาย %1\$s ตรงแล้ว"
            "lo" -> "ສາຍ %1\$s ກົງແລ້ວ"
            "km" -> "ខ្សែ %1\$s ត្រូវហើយ"
            "ko" -> "%1\$s 현이 정확히 조율되었습니다"
            "pt" -> "A corda %1\$s está afinada"
            "sw" -> "Uzi %1\$s uko sawa"
            "ar" -> "الوتر %1\$s مضبوط"
            else -> "String %1\$s is in tune"
        }
    }

    val accentTarget = when (state) {
        TunerHintState.UNSTABLE -> Color(0xFFE6A23C)
        TunerHintState.DETECTED -> tunaGreen.copy(alpha = 0.92f)
        TunerHintState.NEAR -> Color(0xFFFFC107)
        TunerHintState.PERFECT -> tunaGreen
        TunerHintState.ALL_STRINGS_COMPLETE -> tunaGreen
    }
    val accentColor by animateColorAsState(
        targetValue = accentTarget,
        animationSpec = tween(durationMillis = 180),
        label = "TunerHintAccent"
    )

    val cardColorTarget = if (isDarkMode) {
        surfaceColor.copy(alpha = 0.96f)
    } else {
        Color.White.copy(alpha = 0.98f)
    }
    val cardColor by animateColorAsState(
        targetValue = cardColorTarget,
        animationSpec = tween(durationMillis = 180),
        label = "TunerHintCard"
    )

    val pulseTransition = rememberInfiniteTransition(label = "TunerHintPulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "TunerHintPulseScale"
    )

    val title: String
    val rawDescription: String
    val icon = when (state) {
        TunerHintState.UNSTABLE -> Icons.Default.Info
        TunerHintState.DETECTED -> Icons.Default.GraphicEq
        TunerHintState.NEAR -> Icons.Default.GraphicEq
        TunerHintState.PERFECT -> Icons.Default.CheckCircle
        TunerHintState.ALL_STRINGS_COMPLETE -> Icons.Default.CheckCircle
    }

    when (state) {
        TunerHintState.UNSTABLE -> {
            title = translated(
                "tuner_hint_noise_title",
                "Tín hiệu chưa ổn định",
                "Unstable signal"
            )
            rawDescription = translated(
                "tuner_hint_noise_desc",
                "Đưa điện thoại gần đàn hơn, tránh quạt và loa",
                "Move the phone closer; avoid fans and speakers"
            )
        }

        TunerHintState.DETECTED -> {
            title = translated(
                "tuner_hint_signal_title",
                "Đang nhận diện tốt",
                "Pitch detected"
            )
            rawDescription = if (usesStringTuning) {
                translated(
                    "tuner_hint_signal_desc",
                    "Chỉnh dây chậm và đều",
                    "Tune slowly and evenly"
                )
            } else {
                translated(
                    "tuner_hint_signal_desc_pitch",
                    "Giữ âm ổn định và điều chỉnh cao độ từ từ",
                    "Hold a steady tone and adjust the pitch gradually"
                )
            }
        }

        TunerHintState.NEAR -> {
            title = translated(
                "tuner_hint_near_title",
                "Gần chuẩn rồi",
                "Almost in tune"
            )
            rawDescription = if (usesStringTuning) {
                translated(
                    "tuner_hint_near_desc",
                    "Xoay khóa thật nhẹ",
                    "Turn the tuning peg very gently"
                )
            } else {
                translated(
                    "tuner_hint_near_desc_pitch",
                    "Điều chỉnh cao độ thật nhẹ",
                    "Adjust the pitch very gently"
                )
            }
        }

        TunerHintState.PERFECT -> {
            title = translated(
                "tuner_hint_perfect_title",
                "Hoàn hảo!",
                "Perfect!"
            )
            rawDescription = if (!tunedStringLabel.isNullOrBlank()) {
                tunedStringDescriptionTemplate()
            } else {
                translated(
                    "tuner_hint_perfect_desc",
                    "Nốt %1\$s đã chuẩn",
                    "Note %1\$s is in tune"
                )
            }
        }

        TunerHintState.ALL_STRINGS_COMPLETE -> {
            val safeCompletion = completionMessage ?: TunerCompletionMessage(
                stringCount = 0,
                descriptionKey = "tuner_complete_generic_desc",
                vietnameseDescription = "Đã hoàn tất chỉnh dây",
                englishDescription = "Instrument tuning is complete"
            )
            val titleTemplate = translated(
                "tuner_all_strings_title",
                "Cả %1\$d dây đã chuẩn",
                "All %1\$d strings are in tune"
            )
            title = runCatching {
                String.format(java.util.Locale.getDefault(), titleTemplate, safeCompletion.stringCount)
            }.getOrElse {
                titleTemplate
                    .replace("%1\$d", safeCompletion.stringCount.toString())
                    .replace("%d", safeCompletion.stringCount.toString())
            }
            rawDescription = translated(
                safeCompletion.descriptionKey,
                safeCompletion.vietnameseDescription,
                safeCompletion.englishDescription
            )
        }
    }

    val description = if (state == TunerHintState.PERFECT) {
        // Với Guitar/Bass/Ukulele/Violin, ưu tiên tên DÂY vật lý
        // (ví dụ: "4 (D)") thay vì cao độ kỹ thuật "D3".
        val safeTarget = tunedStringLabel?.takeIf { it.isNotBlank() }
            ?: noteLabel.ifBlank { "--" }
        runCatching {
            String.format(java.util.Locale.getDefault(), rawDescription, safeTarget)
        }.getOrElse {
            rawDescription.replace("%1\$s", safeTarget).replace("%s", safeTarget)
        }
    } else {
        rawDescription
    }

    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = modifier
            // Chỉ rộng theo đúng nội dung, không kéo gần hết màn hình.
            .widthIn(min = 150.dp, max = 300.dp)
            .wrapContentWidth()
            .heightIn(min = 32.dp)
            .clip(shape)
            .background(cardColor)
            .border(1.dp, accentColor.copy(alpha = 0.42f), shape)
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .scale(
                    if (
                        state == TunerHintState.UNSTABLE ||
                        state == TunerHintState.ALL_STRINGS_COMPLETE
                    ) pulseScale else 1f
                )
                .background(accentColor.copy(alpha = 0.14f), CircleShape)
                .border(1.dp, accentColor.copy(alpha = 0.28f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(14.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        Column(
            modifier = Modifier.widthIn(max = 238.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                color = accentColor,
                fontSize = 11.sp,
                lineHeight = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = description,
                color = textColor.copy(alpha = if (isDarkMode) 0.70f else 0.72f),
                fontSize = 9.sp,
                lineHeight = 10.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TunerView(
    viewModel: TunerViewModel,
    currentLang: String,
    isDarkMode: Boolean,
    bgColor: Color,
    surfaceColor: Color,
    textColor: Color,
    tunaGreen: Color
) {
    val note by viewModel.noteName.collectAsState()
    val octave by viewModel.octave.collectAsState()
    val freq by viewModel.frequency.collectAsState()
    val deviation by viewModel.deviation.collectAsState()
    val hasSound by viewModel.hasSound.collectAsState()
    val isFluctuating by viewModel.isFluctuating.collectAsState()
    val hasValidPitch by viewModel.hasValidPitch.collectAsState() // [THÊM MỚI] Lắng nghe nốt hợp lệ

    var isAutoMode by remember { mutableStateOf(true) }
    var tunerStyle by remember { mutableIntStateOf(0) }
    var selectedString by remember { mutableStateOf("") }

    val instruments = listOf("Guitar 6-string", "Violin", "Ukulele", "Bass 4-string", "Bass 5-string", "Saxophone", "Piano")
    var selectedInstrument by remember { mutableStateOf(instruments[0]) }
    var isDropdownExpanded by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val tunerPrefs = remember(context) { context.getSharedPreferences("TunerPrefs", Context.MODE_PRIVATE) }
    var selectedGuitarTuningId by remember {
        mutableStateOf(tunerPrefs.getString("guitarTuningId", "standard") ?: "standard")
    }
    val selectedGuitarTuning = GUITAR_TUNING_PRESETS.firstOrNull { it.id == selectedGuitarTuningId }
        ?: GUITAR_TUNING_PRESETS.first()
    var isTuningDropdownExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(selectedGuitarTuning.id) {
        viewModel.setGuitarTuningFrequencies(
            selectedGuitarTuning.stringsLowToHigh.map { it.frequency }
        )
    }

    LaunchedEffect(key1 = selectedInstrument) {
        viewModel.setInstrument(selectedInstrument)
        CoreAudioPlayer.init()
        CoreAudioPlayer.loadInstrument(context, selectedInstrument.substringBefore(" "))
    }

    val animatedDeviation by animateFloatAsState(targetValue = deviation, animationSpec = tween(durationMillis = 150), label = "Needle")

    // Thêm hiệu ứng chạy từ dưới lên cho đường 12h
    val centerLineFill by animateFloatAsState(
        // [SỬA ĐIỀU KIỆN]: Chỉ lấp đầy màu xanh khi có âm thanh VÀ âm thanh đó là NỐT NHẠC (có tần số > 20Hz)
        targetValue = if (hasSound && isFluctuating && hasValidPitch) 1f else 0f,
        animationSpec = tween(durationMillis = 250, easing = LinearOutSlowInEasing),
        label = "CenterLineFill"
    )

    val isInTune = deviation in -3f..3f

    val targetAccentColor = if (freq > 0f) {
        val absDev = kotlin.math.abs(deviation)
        when {
            absDev <= 3f -> tunaGreen
            absDev <= 10f -> Color(0xFFAEEA00)
            absDev <= 20f -> Color(0xFFFFC107)
            absDev <= 30f -> Color(0xFFFF5722)
            else -> Color(0xFFF44336)
        }
    } else {
        textColor
    }
    val accentColor by animateColorAsState(targetValue = targetAccentColor, animationSpec = tween(durationMillis = 200), label = "Color")

    val infiniteTransition = rememberInfiniteTransition(label = "Grid")
    val gridOffsetY by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 45f, animationSpec = infiniteRepeatable(animation = tween(1000, easing = LinearEasing)), label = "GridY"
    )

    val deviationHistory = remember { mutableStateListOf<Float>() }

    LaunchedEffect(freq) {
        if (freq <= 0f) deviationHistory.clear()
    }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(30)
            if (freq > 0f) {
                deviationHistory.add(0, animatedDeviation)
                if (deviationHistory.size > 80) {
                    deviationHistory.removeAt(deviationHistory.lastIndex)
                }
            }
        }
    }

    var hasPlayedTuneSound by remember { mutableStateOf(false) }
    var lastTunedNote by remember { mutableStateOf("") } // Thêm biến nhớ nốt
    val mContext = LocalContext.current

    LaunchedEffect(selectedGuitarTuning.id) {
        hasPlayedTuneSound = false
        lastTunedNote = ""
        selectedString = ""
    }

    val tuningSequences = mapOf(
        "Bass 4-string" to listOf("E1", "A1", "D2", "G2"),
        "Bass 5-string" to listOf("B0", "E1", "A1", "D2", "G2"),
        "Ukulele" to listOf("G4", "C4", "E4", "A4"),
        "Violin" to listOf("G3", "D4", "A4", "E5")
    )

    val currentSequence = if (selectedInstrument == "Guitar 6-string") {
        selectedGuitarTuning.stringsLowToHigh.map { it.id }
    } else {
        tuningSequences[selectedInstrument] ?: emptyList()
    }

    // Chỉ các nhạc cụ có dây mới có thông báo hoàn thành toàn bộ dây.
    // Saxophone và Piano tiếp tục dùng thông báo từng nốt, không hiển thị "dây".
    val completionMessage = when (selectedInstrument) {
        "Guitar 6-string" -> TunerCompletionMessage(
            stringCount = 6,
            descriptionKey = "tuner_complete_guitar_desc",
            vietnameseDescription = "Đã hoàn tất chỉnh dây guitar",
            englishDescription = "Guitar tuning is complete"
        )
        "Ukulele" -> TunerCompletionMessage(
            stringCount = 4,
            descriptionKey = "tuner_complete_ukulele_desc",
            vietnameseDescription = "Đã hoàn tất chỉnh dây ukulele",
            englishDescription = "Ukulele tuning is complete"
        )
        "Violin" -> TunerCompletionMessage(
            stringCount = 4,
            descriptionKey = "tuner_complete_violin_desc",
            vietnameseDescription = "Đã hoàn tất chỉnh dây violin",
            englishDescription = "Violin tuning is complete"
        )
        "Bass 4-string" -> TunerCompletionMessage(
            stringCount = 4,
            descriptionKey = "tuner_complete_bass4_desc",
            vietnameseDescription = "Đã hoàn tất chỉnh dây bass 4 dây",
            englishDescription = "4-string bass tuning is complete"
        )
        "Bass 5-string" -> TunerCompletionMessage(
            stringCount = 5,
            descriptionKey = "tuner_complete_bass5_desc",
            vietnameseDescription = "Đã hoàn tất chỉnh dây bass 5 dây",
            englishDescription = "5-string bass tuning is complete"
        )
        else -> null
    }
    val usesStringTuning = completionMessage != null

    val tunedStrings = remember(selectedInstrument, selectedGuitarTuning.id, isAutoMode) {
        mutableStateListOf<String>()
    }
    var currentTargetIndex by remember(selectedInstrument, selectedGuitarTuning.id, isAutoMode) {
        mutableIntStateOf(0)
    }
    var allStringsMessageVisible by remember(
        selectedInstrument,
        selectedGuitarTuning.id,
        isAutoMode
    ) {
        mutableStateOf(false)
    }
    var hasShownAllStringsMessage by remember(
        selectedInstrument,
        selectedGuitarTuning.id,
        isAutoMode
    ) {
        mutableStateOf(false)
    }
    val targetStr = currentSequence.getOrNull(currentTargetIndex)

    val currentPlayingString = "${note}${octave}"

    LaunchedEffect(isInTune, currentPlayingString) {
        if (isAutoMode && isInTune && freq > 0f && currentSequence.isNotEmpty()) {
            // Kiểm tra xem dây đang gảy có thuộc nhạc cụ này không (không cần đúng thứ tự)
            if (currentSequence.contains(currentPlayingString)) {
                kotlinx.coroutines.delay(500)

                // Tránh việc nhảy số trong 500ms chờ
                if (isInTune && "${viewModel.noteName.value}${viewModel.octave.value}" == currentPlayingString) {

                    // Thêm dây vừa chỉnh vào danh sách hoàn thành (sáng xanh)
                    if (!tunedStrings.contains(currentPlayingString)) {
                        tunedStrings.add(currentPlayingString)
                    }

                    // Cập nhật vòng sáng gợi ý (target) sang dây tiếp theo chưa được chỉnh
                    val currentIndex = currentSequence.indexOf(currentPlayingString)
                    var nextTarget = currentIndex + 1

                    // Bỏ qua các dây đã xanh, tìm dây untuned kế tiếp
                    while (nextTarget < currentSequence.size && tunedStrings.contains(currentSequence[nextTarget])) {
                        nextTarget++
                    }

                    // Giữ nguyên viền gợi ý nếu đã đến cuối dây
                    if (nextTarget < currentSequence.size) {
                        currentTargetIndex = nextTarget
                    }
                }
            }
        }
    }

    // Hiển thị một lần thông báo hoàn thành khi toàn bộ dây của nhạc cụ đã chuẩn.
    // Áp dụng cho Guitar, Ukulele, Violin, Bass 4 dây và Bass 5 dây.
    LaunchedEffect(
        tunedStrings.size,
        selectedInstrument,
        selectedGuitarTuning.id,
        isAutoMode,
        currentSequence.size,
        completionMessage?.stringCount
    ) {
        val allStringsTuned =
            completionMessage != null &&
                    isAutoMode &&
                    currentSequence.isNotEmpty() &&
                    currentSequence.size == completionMessage.stringCount &&
                    currentSequence.all { tunedStrings.contains(it) }

        if (allStringsTuned && !hasShownAllStringsMessage) {
            hasShownAllStringsMessage = true
            allStringsMessageVisible = true
            kotlinx.coroutines.delay(3500L)
            allStringsMessageVisible = false
        }
    }

    LaunchedEffect(isInTune, freq, note, octave) {
        val currentString = "$note$octave"

        if (freq > 0f) {
            if (isInTune) {
                // 1. Đổi sang nốt khác -> reset cờ để cho phép kêu dây mới
                if (currentString != lastTunedNote) {
                    hasPlayedTuneSound = false
                }

                if (!hasPlayedTuneSound) {
                    hasPlayedTuneSound = true
                    lastTunedNote = currentString // 2. Lưu lại nốt vừa kêu thành công

                    try {
                        viewModel.isChimePlaying = true
                        val mediaPlayer = MediaPlayer.create(mContext, R.raw.sound_perfect)

                        if (mediaPlayer == null) {
                            // MediaPlayer.create() may return null without throwing.
                            viewModel.isChimePlaying = false
                        } else {
                            mediaPlayer.setOnCompletionListener {
                                runCatching { it.release() }
                                viewModel.isChimePlaying = false
                            }
                            mediaPlayer.setOnErrorListener { player, _, _ ->
                                runCatching { player.release() }
                                viewModel.isChimePlaying = false
                                true
                            }
                            mediaPlayer.start()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        viewModel.isChimePlaying = false
                    }
                }
            } else if (kotlin.math.abs(deviation) > 6f) {
                // 3. Lệch kim quá 6 cents (bị out of tune) -> reset cờ và xóa bộ nhớ
                hasPlayedTuneSound = false
                lastTunedNote = ""
            }
        }
    }

    fun getInstrumentIcon(instName: String) = when (instName) {
        "Guitar 6-string" -> R.drawable.logo_guitar
        "Violin" -> R.drawable.logo_violon
        "Ukulele" -> R.drawable.logo_ukulele
        "Bass 4-string" -> R.drawable.logo_bass_4_string
        "Bass 5-string" -> R.drawable.logo_bass_5_string
        "Saxophone" -> R.drawable.logo_sacsophone
        "Piano" -> R.drawable.logo_piano
        else -> R.drawable.logo_guitar
    }

    val detectedGuitarTarget = if (selectedInstrument == "Guitar 6-string") {
        selectedGuitarTuning.stringsLowToHigh.firstOrNull {
            it.noteName == note && it.octave == octave
        }
    } else {
        null
    }
    val detectedNoteDisplay = detectedGuitarTarget?.displayWithOctave
        ?: if (note != "-") "$note$octave" else ""

    // Nhãn dây vật lý để thông báo chính xác người dùng vừa chỉnh xong dây nào.
    // Ví dụ với Standard EADGBE: D3 là dây số 4, vì vậy hiển thị "4 (D)".
    // Cách đánh số luôn từ dây mỏng nhất = 1 đến dây dày nhất = tổng số dây.
    val detectedStringLabel: String? = when (selectedInstrument) {
        "Guitar 6-string" -> detectedGuitarTarget?.let { target ->
            val lowToHighIndex = selectedGuitarTuning.stringsLowToHigh
                .indexOfFirst { it.id == target.id }
            if (lowToHighIndex >= 0) {
                val stringNumber = selectedGuitarTuning.stringsLowToHigh.size - lowToHighIndex
                "$stringNumber (${target.displayNote})"
            } else {
                target.displayNote
            }
        }

        "Bass 4-string", "Bass 5-string", "Ukulele", "Violin" -> {
            val lowToHighIndex = currentSequence.indexOf(currentPlayingString)
            if (lowToHighIndex >= 0) {
                val stringNumber = currentSequence.size - lowToHighIndex
                val displayNote = note
                    .replace("#", "♯")
                    .replace("b", "♭")
                "$stringNumber ($displayNote)"
            } else {
                null
            }
        }

        else -> null
    }

    // Automatic realtime hints are shown only after a valid musical pitch is detected.
    // The ambient-noise advice appears for about 3 seconds whenever the Tuner tab is entered.
    val contextualHintState: TunerHintState? = when {
        !hasSound -> null
        !hasValidPitch || !isFluctuating || freq <= 0f -> null
        kotlin.math.abs(deviation) <= 3f -> TunerHintState.PERFECT
        kotlin.math.abs(deviation) <= 10f -> TunerHintState.NEAR
        else -> TunerHintState.DETECTED
    }

    var contextualVisibleHint by remember { mutableStateOf<TunerHintState?>(null) }

    // A new TunerView composition is created each time the user returns to the Tune tab,
    // so this advice is shown again for 3 seconds on every tab entry.
    var isAdviceVisible by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(3000L)
        isAdviceVisible = false
    }

    LaunchedEffect(contextualHintState, isAdviceVisible) {
        // The explicit 3-second advice always has priority over realtime feedback.
        contextualVisibleHint = null
        if (isAdviceVisible) return@LaunchedEffect

        val nextState = contextualHintState ?: return@LaunchedEffect
        contextualVisibleHint = nextState

        // Keep realtime feedback responsive while the initial advice lasts 3 seconds.
        val visibleDuration = when (nextState) {
            TunerHintState.UNSTABLE -> 3000L // Reserved for the explicit advice above.
            TunerHintState.DETECTED -> 1400L
            TunerHintState.NEAR -> 1400L
            TunerHintState.PERFECT -> 1500L
            TunerHintState.ALL_STRINGS_COMPLETE -> 3500L
        }
        kotlinx.coroutines.delay(visibleDuration)
        if (contextualVisibleHint == nextState) {
            contextualVisibleHint = null
        }
    }

    val visibleHintState: TunerHintState? = when {
        allStringsMessageVisible -> TunerHintState.ALL_STRINGS_COMPLETE
        isAdviceVisible -> TunerHintState.UNSTABLE
        else -> contextualVisibleHint
    }

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row {
                Text(text = "Tuner ", color = textColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(text = "Tools", color = tunaGreen, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = CoreTranslator.getString("auto", currentLang), color = textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Switch(checked = isAutoMode, onCheckedChange = { isAutoMode = it; if (it) { selectedString = ""; viewModel.setAutoMode() } }, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = tunaGreen, uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color.DarkGray, checkedBorderColor = Color.Transparent, uncheckedBorderColor = Color.Transparent), modifier = Modifier.scale(0.8f))
            }
        }


        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { isDropdownExpanded = true }.padding(vertical = 8.dp, horizontal = 4.dp)
                ) {
                    Image(painter = painterResource(id = getInstrumentIcon(selectedInstrument)), contentDescription = "Icon", modifier = Modifier.size(36.dp), contentScale = ContentScale.Fit)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = selectedInstrument, color = textColor, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                    Icon(Icons.Default.ArrowDropDown, "Select", tint = textColor)
                }
                DropdownMenu(expanded = isDropdownExpanded, onDismissRequest = { isDropdownExpanded = false }, modifier = Modifier.background(surfaceColor)) {
                    instruments.forEach { inst ->
                        DropdownMenuItem(text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(painter = painterResource(id = getInstrumentIcon(inst)), contentDescription = null, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(inst, color = textColor)
                            }
                        }, onClick = { selectedInstrument = inst; isDropdownExpanded = false; isAutoMode = true; viewModel.setAutoMode() })
                    }
                }
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(surfaceColor.copy(alpha = 0.4f))
                    .border(
                        width = 1.5.dp,
                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(Color.Black.copy(alpha = 0.4f), Color.White.copy(alpha = 0.05f))
                        ),
                        shape = CircleShape
                    )
                    .padding(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isGridActive = tunerStyle == 0
                    Row(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(
                                brush = if (isGridActive) {
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(tunaGreen.copy(alpha = 0.7f), tunaGreen)
                                    )
                                } else androidx.compose.ui.graphics.SolidColor(Color.Transparent)
                            )
                            .then(
                                if (isGridActive) {
                                    Modifier.border(
                                        width = 1.dp,
                                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                            colors = listOf(Color.White.copy(alpha = 0.4f), Color.Black.copy(alpha = 0.2f))
                                        ),
                                        shape = CircleShape
                                    )
                                } else Modifier
                            )
                            .clickable { tunerStyle = 0 }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val gridTxt = if (isGridActive) Color.White else textColor.copy(alpha = 0.6f)
                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = gridTxt, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(CoreTranslator.getString("grid_view", currentLang), color = gridTxt, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.width(2.dp))

                    val isDialActive = tunerStyle == 1
                    Row(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(
                                brush = if (isDialActive) {
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(tunaGreen.copy(alpha = 0.7f), tunaGreen)
                                    )
                                } else androidx.compose.ui.graphics.SolidColor(Color.Transparent)
                            )
                            .then(
                                if (isDialActive) {
                                    Modifier.border(
                                        width = 1.dp,
                                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                            colors = listOf(Color.White.copy(alpha = 0.4f), Color.Black.copy(alpha = 0.2f))
                                        ),
                                        shape = CircleShape
                                    )
                                } else Modifier
                            )
                            .clickable { tunerStyle = 1 }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val dialTxt = if (isDialActive) Color.White else textColor.copy(alpha = 0.6f)
                        Icon(Icons.Default.Speed, contentDescription = null, tint = dialTxt, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(CoreTranslator.getString("dial_view", currentLang), color = dialTxt, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (selectedInstrument == "Guitar 6-string") {
                Box(modifier = Modifier.align(Alignment.CenterStart)) {
                    val tuningShape = RoundedCornerShape(50)
                    Row(
                        modifier = Modifier
                            .widthIn(max = 108.dp)
                            .height(30.dp)
                            .clip(tuningShape)
                            .background(surfaceColor.copy(alpha = 0.74f))
                            .border(1.dp, textColor.copy(alpha = 0.13f), tuningShape)
                            .clickable { isTuningDropdownExpanded = true }
                            .padding(horizontal = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tunerTranslatedText(
                                currentLang,
                                selectedGuitarTuning.translationKey,
                                selectedGuitarTuning.vietnameseFallback,
                                selectedGuitarTuning.englishFallback
                            ),
                            color = textColor.copy(alpha = 0.88f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = tunerTranslatedText(
                                currentLang,
                                "tuner_tuning_label",
                                "Kiểu lên dây",
                                "Tuning"
                            ),
                            tint = textColor.copy(alpha = 0.72f),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = isTuningDropdownExpanded,
                        onDismissRequest = { isTuningDropdownExpanded = false },
                        modifier = Modifier
                            .widthIn(min = 235.dp, max = 300.dp)
                            .heightIn(max = 390.dp)
                            .background(surfaceColor)
                    ) {
                        GUITAR_TUNING_PRESETS.forEach { tuning ->
                            val isSelectedTuning = tuning.id == selectedGuitarTuning.id
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = tunerTranslatedText(
                                                currentLang,
                                                tuning.translationKey,
                                                tuning.vietnameseFallback,
                                                tuning.englishFallback
                                            ),
                                            color = if (isSelectedTuning) tunaGreen else textColor,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelectedTuning) FontWeight.Bold else FontWeight.Medium
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = tuning.sequenceLabel,
                                            color = textColor.copy(alpha = 0.56f),
                                            fontSize = 10.sp,
                                            letterSpacing = 0.4.sp
                                        )
                                    }
                                },
                                leadingIcon = {
                                    if (isSelectedTuning) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = tunaGreen,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        Box(modifier = Modifier.size(18.dp))
                                    }
                                },
                                onClick = {
                                    selectedGuitarTuningId = tuning.id
                                    tunerPrefs.edit().putString("guitarTuningId", tuning.id).apply()
                                    isTuningDropdownExpanded = false
                                    isAutoMode = true
                                    selectedString = ""
                                    viewModel.setGuitarTuningFrequencies(
                                        tuning.stringsLowToHigh.map { it.frequency }
                                    )
                                }
                            )
                        }
                    }
                }
            }

            Text(
                text = if (freq > 0f) String.format(java.util.Locale.US, "%.1f Hz", freq) else "-- Hz",
                color = if (freq > 0f) accentColor else Color.Gray,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.TopCenter) {

            val textPaint = remember(textColor) {
                android.graphics.Paint().apply {
                    color = textColor.toArgb()
                    textSize = 60f
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                }
            }
            val smallTextPaint = remember(textColor) {
                android.graphics.Paint().apply {
                    color = textColor.toArgb()
                    alpha = 150
                    textSize = 30f
                    textAlign = android.graphics.Paint.Align.CENTER
                }
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                if (tunerStyle == 0) {
                    val step = 45f
                    val gridColor = textColor.copy(alpha = 0.2f)

                    drawContext.canvas.nativeCanvas.drawText("♭", 50f, h * 0.35f + 20f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("♯", w - 50f, h * 0.35f + 20f, textPaint)

                    var x = w / 2
                    while (x < w) { drawLine(gridColor, Offset(x, 0f), Offset(x, h), 2f); x += step }
                    x = w / 2 - step
                    while (x > 0f) { drawLine(gridColor, Offset(x, 0f), Offset(x, h), 2f); x -= step }

                    var y = (h / 2) % step - step + gridOffsetY
                    while (y <= h + step) {
                        if (y > 2f && y < h - 2f) drawLine(gridColor, Offset(0f, y), Offset(w, y), 2f)
                        y += step
                    }

                    // 1. Luôn vẽ đường trục giữa màu xám mờ
                    val centerLineColor = textColor.copy(alpha = 0.3f)
                    drawLine(centerLineColor, Offset(w / 2, 0f), Offset(w / 2, h), 4f)

                    // 2. [SỬA LẠI ĐIỀU KIỆN LẤP ĐẦY MÀU]
                    // Phải đảm bảo CÓ tần số hợp lệ (freq > 0f) VÀ mic ĐANG THU ĐƯỢC TIẾNG (hasSound == true)
                    // (Tránh trường hợp tần số đóng băng nhưng mic lại im lặng)
                    if (freq > 0f && hasSound && centerLineFill > 0f) {
                        // Màu của thanh lấp đầy sẽ giống màu chữ và kim (accentColor)
                        drawLine(
                            color = accentColor,
                            start = Offset(w / 2, h),
                            end = Offset(w / 2, h * (1f - centerLineFill)),
                            strokeWidth = 4f
                        )
                    }

                    if (freq > 0) {
                        val centerY = h * 0.35f

                        if (deviationHistory.size > 1) {
                            val trailPath = Path()
                            val firstDev = deviationHistory[0].coerceIn(-50f, 50f)
                            val firstX = w / 2f + (firstDev / 50f) * (w / 2f - 40f)

                            val needleBottomY = centerY + 75f
                            trailPath.moveTo(firstX, needleBottomY)

                            for (i in 1 until deviationHistory.size) {
                                val pastDev = deviationHistory[i].coerceIn(-50f, 50f)
                                val pastX = w / 2f + (pastDev / 50f) * (w / 2f - 40f)

                                val pastY = needleBottomY + (i * 10f)
                                trailPath.lineTo(pastX, pastY)
                            }

                            drawPath(
                                path = trailPath,
                                color = accentColor.copy(alpha = 0.5f),
                                style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }

                        val clampedDev = animatedDeviation.coerceIn(-50f, 50f)
                        val currentX = w / 2f + (clampedDev / 50f) * (w / 2f - 40f)

                        val needleTopPath = Path().apply {
                            moveTo(currentX - 8f, centerY - 48f)
                            lineTo(currentX + 8f, centerY - 48f)
                            lineTo(currentX, centerY - 75f)
                            close()
                        }
                        drawPath(needleTopPath, color = accentColor)

                        drawLine(
                            color = accentColor,
                            start = Offset(currentX, centerY + 48f),
                            end = Offset(currentX, centerY + 75f),
                            strokeWidth = 6f,
                            cap = StrokeCap.Round
                        )

                        if (isInTune) {
                            drawCircle(color = tunaGreen, radius = 48f, center = Offset(currentX, centerY))
                        } else {
                            drawCircle(color = bgColor, radius = 48f, center = Offset(currentX, centerY))
                        }

                        drawCircle(color = accentColor, radius = 48f, center = Offset(currentX, centerY), style = Stroke(width = 6f))

                        if (isInTune) {
                            val tickPath = Path().apply {
                                moveTo(currentX - 15f, centerY + 2f)
                                lineTo(currentX - 3f, centerY + 14f)
                                lineTo(currentX + 18f, centerY - 10f)
                            }
                            drawPath(
                                path = tickPath,
                                color = bgColor,
                                style = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        } else {
                            val devInt = deviation.roundToInt()

                            // Xác định chữ UP/DOWN và chuỗi số
                            val actionText = if (devInt < 0) "UP" else "DOWN"
                            val devText = if (devInt > 0) "+$devInt" else "$devInt"

                            // 1. Paint cho chữ UP/DOWN (nằm ở nửa trên)
                            val actionTextPaint = android.graphics.Paint().apply {
                                color = accentColor.toArgb()
                                textSize = 20f // Size nhỏ vừa vặn
                                textAlign = android.graphics.Paint.Align.CENTER
                                typeface = android.graphics.Typeface.DEFAULT_BOLD
                            }

                            // 2. Paint cho con số (nằm ở nửa dưới)
                            val numberTextPaint = android.graphics.Paint().apply {
                                color = accentColor.toArgb()
                                textSize = 26f // Số to hơn chữ một chút để làm điểm nhấn
                                textAlign = android.graphics.Paint.Align.CENTER
                                typeface = android.graphics.Typeface.DEFAULT_BOLD
                            }

                            // Vẽ chữ UP / DOWN (Đẩy tọa độ Y lên một chút: centerY - 4f)
                            drawContext.canvas.nativeCanvas.drawText(
                                actionText,
                                currentX,
                                centerY - 4f,
                                actionTextPaint
                            )

                            // Vẽ con số VD: -15, +12 (Kéo tọa độ Y xuống một chút: centerY + 24f)
                            drawContext.canvas.nativeCanvas.drawText(
                                devText,
                                currentX,
                                centerY + 24f,
                                numberTextPaint
                            )
                        }
                    } else {
                        // [THÊM MỚI] Vẽ kim mờ tĩnh ở ngay giữa giao diện khi chưa có âm thanh
                        val centerY = h * 0.35f
                        val currentX = w / 2f // Trục X luôn trỏ vào chính giữa

                        // Vẽ chóp kim
                        val needleTopPath = Path().apply {
                            moveTo(currentX - 8f, centerY - 48f)
                            lineTo(currentX + 8f, centerY - 48f)
                            lineTo(currentX, centerY - 75f)
                            close()
                        }
                        drawPath(needleTopPath, color = textColor.copy(alpha = 0.2f))

                        // Vẽ đuôi kim
                        drawLine(
                            color = textColor.copy(alpha = 0.2f),
                            start = Offset(currentX, centerY + 48f),
                            end = Offset(currentX, centerY + 75f),
                            strokeWidth = 6f,
                            cap = StrokeCap.Round
                        )

                        // Vẽ vòng tròn tâm kim
                        drawCircle(color = bgColor, radius = 48f, center = Offset(currentX, centerY))
                        drawCircle(color = textColor.copy(alpha = 0.2f), radius = 48f, center = Offset(currentX, centerY), style = Stroke(width = 6f))

                        // Chữ "--" ở giữa để báo hiệu đang chờ âm thanh
                        val bubbleTextPaint = android.graphics.Paint().apply {
                            color = textColor.toArgb()
                            alpha = 70 // Làm mờ chữ đi cho đồng bộ với độ mờ của kim
                            textSize = 28f
                            textAlign = android.graphics.Paint.Align.CENTER
                            typeface = android.graphics.Typeface.DEFAULT_BOLD
                        }
                        drawContext.canvas.nativeCanvas.drawText(
                            "--",
                            currentX,
                            centerY + 10f,
                            bubbleTextPaint
                        )
                    }
                } else {
                    // Đây là khu vực của Chế độ Dial View (tunerStyle == 1)
                    val cx = w / 2
                    val cy = h * 0.85f
                    val radius = kotlin.math.min(w, h) * 0.85f

                    val flatRad = Math.toRadians((-75 - 90).toDouble())
                    val sharpRad = Math.toRadians((75 - 90).toDouble())
                    val symbolRadius = radius - 30f
                    drawContext.canvas.nativeCanvas.drawText("♭", cx + symbolRadius * kotlin.math.cos(flatRad).toFloat(), cy + symbolRadius * kotlin.math.sin(flatRad).toFloat() + 20f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("♯", cx + symbolRadius * kotlin.math.cos(sharpRad).toFloat(), cy + symbolRadius * kotlin.math.sin(sharpRad).toFloat() + 20f, textPaint)

                    for (i in -25..25) {
                        if (i % 5 != 0 && i % 2 != 0) continue

                        val angle = i * 2.4f
                        val rad = Math.toRadians((angle - 90).toDouble())
                        val isCenter = i == 0
                        val isMajor = i % 5 == 0

                        val lineLen = if (isCenter) 40f else if (isMajor) 24f else 12f
                        val strokeW = if (isCenter) 6f else if (isMajor) 3f else 1.5f
                        val color = if (isCenter) tunaGreen else textColor.copy(alpha = if (isMajor) 0.5f else 0.2f)

                        val startX = cx + (radius - lineLen) * kotlin.math.cos(rad).toFloat()
                        val startY = cy + (radius - lineLen) * kotlin.math.sin(rad).toFloat()
                        val endX = cx + radius * kotlin.math.cos(rad).toFloat()
                        val endY = cy + radius * kotlin.math.sin(rad).toFloat()

                        drawLine(color, Offset(startX, startY), Offset(endX, endY), strokeW, StrokeCap.Round)

                        if (i % 10 == 0 || i == -25 || i == 25) {
                            val textRadius = radius - lineLen - 30f
                            val textX = cx + textRadius * kotlin.math.cos(rad).toFloat()
                            val textY = cy + textRadius * kotlin.math.sin(rad).toFloat() + 10f
                            val textValue = if (i == 0) "0" else (i * 2).toString()
                            drawContext.canvas.nativeCanvas.drawText(textValue, textX, textY, smallTextPaint)
                        }
                    }

                    drawArc(
                        color = textColor.copy(alpha = 0.1f),
                        startAngle = 210f, sweepAngle = 120f, useCenter = false,
                        topLeft = Offset(cx - radius, cy - radius), size = Size(radius * 2, radius * 2),
                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                    )

                    if (freq > 0) {
                        val clampedDev = animatedDeviation.coerceIn(-50f, 50f)
                        val currentAngle = (clampedDev / 50f) * 60f
                        val rad = Math.toRadians((currentAngle - 90).toDouble())

                        val needleLength = radius - 45f
                        val needleEndX = cx + needleLength * kotlin.math.cos(rad).toFloat()
                        val needleEndY = cy + needleLength * kotlin.math.sin(rad).toFloat()

                        drawLine(Color.Black.copy(alpha = 0.3f), Offset(cx + 4f, cy + 4f), Offset(needleEndX + 4f, needleEndY + 4f), 8f, StrokeCap.Round)
                        drawLine(accentColor, Offset(cx, cy), Offset(needleEndX, needleEndY), 6f, StrokeCap.Round)

                        drawCircle(bgColor, 20f, Offset(cx, cy))
                        drawCircle(accentColor, 20f, Offset(cx, cy), style = Stroke(width = 6f))
                        drawCircle(accentColor, 6f, Offset(cx, cy))
                    } else {
                        val rad = Math.toRadians(-90.0)
                        val needleEndX = cx + (radius - 45f) * kotlin.math.cos(rad).toFloat()
                        val needleEndY = cy + (radius - 45f) * kotlin.math.sin(rad).toFloat()

                        drawLine(textColor.copy(alpha = 0.2f), Offset(cx, cy), Offset(needleEndX, needleEndY), 6f, StrokeCap.Round)
                        drawCircle(bgColor, 20f, Offset(cx, cy))
                        drawCircle(textColor.copy(alpha = 0.2f), 20f, Offset(cx, cy), style = Stroke(width = 6f))
                    }
                }
            }

        }

        // [BẮT ĐẦU THÊM MỚI] Khai báo hiệu ứng Pop (Zoom to rồi thu nhỏ)
        var isNotePopping by remember { mutableStateOf(false) }

        // Lắng nghe sự thay đổi của isInTune và tên nốt để kích hoạt pop
        LaunchedEffect(isInTune, note, octave) {
            if (isInTune && freq > 0f) {
                isNotePopping = true
                kotlinx.coroutines.delay(150) // Phóng to trong 150ms
                isNotePopping = false         // Trở về bình thường
            }
        }

        // Tạo chuyển động mượt mà cho thuộc tính scale
        val noteBoxScale by animateFloatAsState(
            targetValue = if (isNotePopping) 1.25f else 1f,
            animationSpec = tween(durationMillis = 150, easing = FastOutSlowInEasing),
            label = "NoteBoxScale"
        )
        // [KẾT THÚC THÊM MỚI]

        Box(
            modifier = Modifier
                .padding(top = 8.dp, bottom = 4.dp)
                .scale(noteBoxScale) // Áp dụng hiệu ứng zoom vào Box
                .background(surfaceColor, RoundedCornerShape(50))
                .border(
                    width = if (isInTune && freq > 0f) 2.dp else 0.dp, // Chỉ hiện viền khi phán định đúng
                    color = if (isInTune && freq > 0f) accentColor else Color.Transparent, // Border giống màu chữ
                    shape = RoundedCornerShape(50)
                )
                // [ĐÃ SỬA] Giảm padding ngang từ 36->24, dọc từ 12->8 để khung bọc nhỏ lại
                .padding(horizontal = 24.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            val selectedManualGuitarTarget = if (selectedInstrument == "Guitar 6-string") {
                selectedGuitarTuning.stringsLowToHigh.firstOrNull { it.id == selectedString }
            } else {
                null
            }
            val displayString = if (!isAutoMode && selectedString.isNotEmpty()) {
                selectedManualGuitarTarget?.displayWithOctave ?: selectedString
            } else if (freq > 0f && note != "-") {
                detectedNoteDisplay
            } else {
                "--"
            }

            Text(
                text = displayString,
                color = if (freq > 0f) accentColor else textColor,
                // [ĐÃ SỬA] Giảm font size từ 24.sp xuống 20.sp cho chữ nhỏ gọn hơn
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Hiển thị thông báo ngay bên dưới nốt đang nhận diện (ví dụ D3),
        // tách hoàn toàn khỏi vùng kim để không che biểu đồ.
        // Giữ một vùng nhỏ cố định giúp hình nhạc cụ không bị nhảy khi banner hiện/ẩn.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(
                targetState = visibleHintState,
                animationSpec = tween(durationMillis = 180),
                label = "ContextualTunerHintBelowNote"
            ) { hintState ->
                if (hintState != null) {
                    SmartTuningHintBanner(
                        currentLang = currentLang,
                        state = hintState,
                        noteLabel = if (freq > 0f) detectedNoteDisplay else "",
                        tunedStringLabel = if (freq > 0f) detectedStringLabel else null,
                        completionMessage = completionMessage,
                        usesStringTuning = usesStringTuning,
                        isDarkMode = isDarkMode,
                        surfaceColor = surfaceColor,
                        textColor = textColor,
                        tunaGreen = tunaGreen
                    )
                }
            }
        }

        Box(modifier = Modifier.fillMaxWidth().weight(1.3f), contentAlignment = Alignment.Center) {
            when (selectedInstrument) {
                "Guitar 6-string" -> {
                    Image(
                        painter = painterResource(id = R.drawable.logo_guitar),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth(0.6f).fillMaxHeight(),
                        contentScale = ContentScale.Fit
                    )

                    // Index order is string 6 -> string 1. Peg positions follow the guitar headstock.
                    val pegTargets = listOf(
                        selectedGuitarTuning.stringsLowToHigh[2] to BiasAlignment(-0.75f, -0.6f),
                        selectedGuitarTuning.stringsLowToHigh[1] to BiasAlignment(-0.75f, 0.0f),
                        selectedGuitarTuning.stringsLowToHigh[0] to BiasAlignment(-0.75f, 0.6f),
                        selectedGuitarTuning.stringsLowToHigh[3] to BiasAlignment(0.75f, -0.6f),
                        selectedGuitarTuning.stringsLowToHigh[4] to BiasAlignment(0.75f, 0.0f),
                        selectedGuitarTuning.stringsLowToHigh[5] to BiasAlignment(0.75f, 0.6f)
                    )

                    pegTargets.forEach { (target, alignment) ->
                        PegButton(
                            noteLabel = target.displayNote,
                            isActive = if (isAutoMode) {
                                note == target.noteName && octave == target.octave && freq > 0f
                            } else {
                                selectedString == target.id
                            },
                            isTuned = tunedStrings.contains(target.id),
                            isTarget = isAutoMode && targetStr == target.id,
                            accentColor = tunaGreen,
                            modifier = Modifier.align(alignment),
                            textSize = if (target.displayNote.length > 1) 18.sp else 22.sp
                        ) {
                            isAutoMode = false
                            selectedString = target.id
                            viewModel.setManualMode(target.noteName, target.octave, target.frequency)
                            CoreAudioPlayer.playChord(listOf(target.midi), "Guitar")
                        }
                    }
                }
                "Violin" -> {
                    Image(painter = painterResource(id = R.drawable.logo_violon), contentDescription = null, modifier = Modifier.fillMaxWidth(0.6f).fillMaxHeight(), contentScale = ContentScale.Fit)
                    PegButton("D",
                        isActive = if (isAutoMode) (note == "D") else (selectedString == "D4"),
                        isTuned = tunedStrings.contains("D4"),
                        isTarget = isAutoMode && targetStr == "D4",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.7f, -0.3f))
                    ) { isAutoMode = false; selectedString = "D4"; viewModel.setManualMode("D", 4, 293.66f); CoreAudioPlayer.playChord(listOf(62), "Violin") }

                    PegButton("G",
                        isActive = if (isAutoMode) (note == "G" && freq < 250f) else (selectedString == "G3"),
                        isTuned = tunedStrings.contains("G3"),
                        isTarget = isAutoMode && targetStr == "G3",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.7f, 0.5f))
                    ) { isAutoMode = false; selectedString = "G3"; viewModel.setManualMode("G", 3, 196.00f); CoreAudioPlayer.playChord(listOf(55), "Violin") }

                    PegButton("A",
                        isActive = if (isAutoMode) (note == "A") else (selectedString == "A4"),
                        isTuned = tunedStrings.contains("A4"),
                        isTarget = isAutoMode && targetStr == "A4",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(0.7f, -0.3f))
                    ) { isAutoMode = false; selectedString = "A4"; viewModel.setManualMode("A", 4, 440.00f); CoreAudioPlayer.playChord(listOf(69), "Violin") }

                    PegButton("E",
                        isActive = if (isAutoMode) (note == "E" && freq > 400f) else (selectedString == "E5"),
                        isTuned = tunedStrings.contains("E5"),
                        isTarget = isAutoMode && targetStr == "E5",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(0.7f, 0.5f))
                    ) { isAutoMode = false; selectedString = "E5"; viewModel.setManualMode("E", 5, 659.25f); CoreAudioPlayer.playChord(listOf(76), "Violin") }
                }
                "Ukulele" -> {
                    Image(painter = painterResource(id = R.drawable.logo_ukulele), contentDescription = null, modifier = Modifier.fillMaxWidth(0.6f).fillMaxHeight(), contentScale = ContentScale.Fit)
                    PegButton("G",
                        isActive = if (isAutoMode) (note == "G") else (selectedString == "G4"),
                        isTuned = tunedStrings.contains("G4"),
                        isTarget = isAutoMode && targetStr == "G4",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.7f, -0.3f))
                    ) { isAutoMode = false; selectedString = "G4"; viewModel.setManualMode("G", 4, 392.00f); CoreAudioPlayer.playChord(listOf(67), "Ukulele") }

                    PegButton("C",
                        isActive = if (isAutoMode) (note == "C") else (selectedString == "C4"),
                        isTuned = tunedStrings.contains("C4"),
                        isTarget = isAutoMode && targetStr == "C4",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.7f, 0.4f))
                    ) { isAutoMode = false; selectedString = "C4"; viewModel.setManualMode("C", 4, 261.63f); CoreAudioPlayer.playChord(listOf(60), "Ukulele") }

                    PegButton("A",
                        isActive = if (isAutoMode) (note == "A") else (selectedString == "A4"),
                        isTuned = tunedStrings.contains("A4"),
                        isTarget = isAutoMode && targetStr == "A4",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(0.7f, -0.3f))
                    ) { isAutoMode = false; selectedString = "A4"; viewModel.setManualMode("A", 4, 440.00f); CoreAudioPlayer.playChord(listOf(69), "Ukulele") }

                    PegButton("E",
                        isActive = if (isAutoMode) (note == "E") else (selectedString == "E4"),
                        isTuned = tunedStrings.contains("E4"),
                        isTarget = isAutoMode && targetStr == "E4",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(0.7f, 0.4f))
                    ) { isAutoMode = false; selectedString = "E4"; viewModel.setManualMode("E", 4, 329.63f); CoreAudioPlayer.playChord(listOf(64), "Ukulele") }
                }
                "Bass 4-string" -> {
                    Image(painter = painterResource(id = R.drawable.logo_bass_4_string), contentDescription = null, modifier = Modifier.fillMaxWidth(0.6f).fillMaxHeight(), contentScale = ContentScale.Fit)
                    PegButton("G",
                        isActive = if (isAutoMode) (note == "G") else (selectedString == "G2"),
                        isTuned = tunedStrings.contains("G2"),
                        isTarget = isAutoMode && targetStr == "G2",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, -0.7f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "G2"; viewModel.setManualMode("G", 2, 98.00f); CoreAudioPlayer.playChord(listOf(43), "Bass") }

                    PegButton("D",
                        isActive = if (isAutoMode) (note == "D") else (selectedString == "D2"),
                        isTuned = tunedStrings.contains("D2"),
                        isTarget = isAutoMode && targetStr == "D2",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, -0.2f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "D2"; viewModel.setManualMode("D", 2, 73.42f); CoreAudioPlayer.playChord(listOf(38), "Bass") }

                    PegButton("A",
                        isActive = if (isAutoMode) (note == "A") else (selectedString == "A1"),
                        isTuned = tunedStrings.contains("A1"),
                        isTarget = isAutoMode && targetStr == "A1",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, 0.3f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "A1"; viewModel.setManualMode("A", 1, 55.00f); CoreAudioPlayer.playChord(listOf(33), "Bass") }

                    PegButton("E",
                        isActive = if (isAutoMode) (note == "E") else (selectedString == "E1"),
                        isTuned = tunedStrings.contains("E1"),
                        isTarget = isAutoMode && targetStr == "E1",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, 0.8f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "E1"; viewModel.setManualMode("E", 1, 41.20f); CoreAudioPlayer.playChord(listOf(28), "Bass") }
                }
                "Bass 5-string" -> {
                    Image(painter = painterResource(id = R.drawable.logo_bass_5_string), contentDescription = null, modifier = Modifier.fillMaxWidth(0.6f).fillMaxHeight(), contentScale = ContentScale.Fit)
                    PegButton("B",
                        isActive = if (isAutoMode) (note == "B" && freq < 40f) else (selectedString == "B0"),
                        isTuned = tunedStrings.contains("B0"),
                        isTarget = isAutoMode && targetStr == "B0",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, -0.6f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "B0"; viewModel.setManualMode("B", 0, 30.87f); CoreAudioPlayer.playChord(listOf(23), "Bass") }

                    PegButton("E",
                        isActive = if (isAutoMode) (note == "E" && freq < 45f) else (selectedString == "E1"),
                        isTuned = tunedStrings.contains("E1"),
                        isTarget = isAutoMode && targetStr == "E1",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, 0.0f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "E1"; viewModel.setManualMode("E", 1, 41.20f); CoreAudioPlayer.playChord(listOf(28), "Bass") }

                    PegButton("A",
                        isActive = if (isAutoMode) (note == "A" && freq < 60f) else (selectedString == "A1"),
                        isTuned = tunedStrings.contains("A1"),
                        isTarget = isAutoMode && targetStr == "A1",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(-0.75f, 0.6f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "A1"; viewModel.setManualMode("A", 1, 55.00f); CoreAudioPlayer.playChord(listOf(33), "Bass") }

                    PegButton("D",
                        isActive = if (isAutoMode) (note == "D" && freq < 80f) else (selectedString == "D2"),
                        isTuned = tunedStrings.contains("D2"),
                        isTarget = isAutoMode && targetStr == "D2",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(0.75f, -0.3f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "D2"; viewModel.setManualMode("D", 2, 73.42f); CoreAudioPlayer.playChord(listOf(38), "Bass") }

                    PegButton("G",
                        isActive = if (isAutoMode) (note == "G" && freq < 120f) else (selectedString == "G2"),
                        isTuned = tunedStrings.contains("G2"),
                        isTarget = isAutoMode && targetStr == "G2",
                        accentColor = tunaGreen,
                        modifier = Modifier.align(BiasAlignment(0.75f, 0.3f)), buttonSize = 55.dp
                    ) { isAutoMode = false; selectedString = "G2"; viewModel.setManualMode("G", 2, 98.00f); CoreAudioPlayer.playChord(listOf(43), "Bass") }
                }
                "Saxophone" -> {
                    Image(painter = painterResource(id = R.drawable.logo_sacsophone), contentDescription = null, modifier = Modifier.fillMaxWidth(0.6f).fillMaxHeight(), contentScale = ContentScale.Fit)
                    PegButton("G4",
                        isActive = if (isAutoMode) (note == "G" && octave == 4) else (selectedString == "G4"),
                        modifier = Modifier.align(BiasAlignment(-0.6f, 0.0f))
                    ) { isAutoMode = false; selectedString = "G4"; viewModel.setManualMode("G", 4, 233.08f); CoreAudioPlayer.playChord(listOf(67), "Saxophone") }

                    PegButton("G5",
                        isActive = if (isAutoMode) (note == "G" && octave == 5) else (selectedString == "G5"),
                        modifier = Modifier.align(BiasAlignment(0.6f, 0.0f))
                    ) { isAutoMode = false; selectedString = "G5"; viewModel.setManualMode("G", 5, 466.16f); CoreAudioPlayer.playChord(listOf(79), "Saxophone") }
                }
                "Piano" -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxSize()) {
                        Image(painter = painterResource(id = R.drawable.logo_piano), contentDescription = null, modifier = Modifier.fillMaxWidth(0.7f).weight(1f), contentScale = ContentScale.Fit)

                        val notesList = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
                        val octavesList = (0..8).toList()
                        var targetNote by remember { mutableStateOf("C") }
                        var targetOctave by remember { mutableStateOf(4) }
                        var isNoteExpanded by remember { mutableStateOf(false) }
                        var isOctaveExpanded by remember { mutableStateOf(false) }

                        fun playAndSetPiano() {
                            val noteIndex = notesList.indexOf(targetNote)
                            val midiNumber = (targetOctave + 1) * 12 + noteIndex
                            val freqTarget = 440.0 * 2.0.pow((midiNumber - 69) / 12.0)
                            isAutoMode = false; selectedString = "$targetNote$targetOctave"
                            viewModel.setManualMode(targetNote, targetOctave, freqTarget.toFloat())
                            CoreAudioPlayer.playChord(listOf(midiNumber), "Piano")
                        }

                        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
                            Box {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.background(surfaceColor, RoundedCornerShape(8.dp)).clickable { isNoteExpanded = true }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                                    Text(targetNote, color = tunaGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = tunaGreen)
                                }
                                DropdownMenu(expanded = isNoteExpanded, onDismissRequest = { isNoteExpanded = false }, modifier = Modifier.background(surfaceColor).heightIn(max = 250.dp)) {
                                    notesList.forEach { n -> DropdownMenuItem(text = { Text(n, color = textColor) }, onClick = { targetNote = n; isNoteExpanded = false; playAndSetPiano() }) }
                                }
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Box {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.background(surfaceColor, RoundedCornerShape(8.dp)).clickable { isOctaveExpanded = true }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                                    Text(targetOctave.toString(), color = tunaGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = tunaGreen)
                                }
                                DropdownMenu(expanded = isOctaveExpanded, onDismissRequest = { isOctaveExpanded = false }, modifier = Modifier.background(surfaceColor).heightIn(max = 250.dp)) {
                                    octavesList.forEach { oct -> DropdownMenuItem(text = { Text(oct.toString(), color = textColor) }, onClick = { targetOctave = oct; isOctaveExpanded = false; playAndSetPiano() }) }
                                }
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Box(modifier = Modifier.background(tunaGreen, CircleShape).clickable { playAndSetPiano() }.padding(14.dp)) {
                                Icon(Icons.Default.MusicNote, contentDescription = "Play", tint = bgColor)
                            }
                        }
                    }
                }
            }

        }
    }
}

@Composable
fun PegButton(
    noteLabel: String,
    isActive: Boolean,
    isTuned: Boolean = false,
    isTarget: Boolean = false,
    modifier: Modifier = Modifier,
    accentColor: Color = Color(0xFF15B27D),
    surfaceColor: Color = Color(0xFF2A2A30),
    textColor: Color = Color.White,
    bgColor: Color = Color(0xFF1B1C20),
    buttonSize: Dp = 58.dp,
    textSize: TextUnit = 22.sp,
    onClick: () -> Unit
) {
    val btnBgColor = if (isActive) textColor else surfaceColor.copy(alpha = 0.9f)
    val btnTextColor = if (isActive) bgColor else textColor

    val borderColor = when {
        isTuned -> accentColor
        isTarget -> textColor
        else -> Color.Transparent
    }
    val borderWidth = if (isTuned || isTarget) 2.5.dp else 0.dp

    Box(
        modifier = modifier
            .size(buttonSize)
            .background(btnBgColor, CircleShape)
            .border(borderWidth, borderColor, CircleShape)
            .clip(CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text = noteLabel, color = btnTextColor, fontSize = textSize, fontWeight = FontWeight.Bold)
    }
}