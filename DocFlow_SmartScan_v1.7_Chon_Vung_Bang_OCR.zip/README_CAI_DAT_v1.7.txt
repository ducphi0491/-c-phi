DOCFLOW SMART SCAN v1.7 - CHON VUNG BANG TRUOC OCR
================================================
BAN GIAO: CHI 2 FILE KOTLIN CHINH SUA
- DocumentEngines.kt
- DocumentScreens.kt

DUONG DAN THAY THE:
app/src/main/java/com/docflowoffline/

Khong can sua AndroidManifest.xml, build.gradle.kts, assets/tessdata, hay cac file Kotlin khac.
Hay sao luu code dang chay truoc khi thay the.

SU DUNG
1. Mo Smart Scan, chup anh hoac chon hinh tu thu vien.
2. Neu ket qua co do tin cay thap, bam "Khoanh vung bang de doc lai".
   Co the vao tab "Anh goc" > "Chon vung bang trong anh goc".
3. Tren anh goc, keo 1 ngon tay tu goc trai tren den goc phai duoi cua 1 BANG.
4. Bam "Doc lai vung" de thay trang hien tai, hoac "Them trang" de them mot bang khac tu CUNG anh.
5. Kiem tra tung o/cot voi anh goc, sua neu can. Voi ket qua OCR tin cay duoi 55%,
   phai xac nhan da kiem tra truoc khi co the xuat Excel / Word.
6. Khi co 2 bang rieng: quet bang 1 -> them trang de quet bang 2 -> xuat Excel.

KY THUAT
- Anh duoc crop tu pixel goc truoc khi thu nho, giu chat luong chu nho hon ban cu.
- OCR bang: su dung PSM_SPARSE_TEXT, khong xoa duong ke bang bang net trang 7px.
- Phan tich duong ke phan biet nen anh mau xam va net ke that.
- Khong tai du lieu len Internet. Chi su dung OCR vie+eng da dong goi trong app.

GIOI HAN
- OCR KHONG the bao dam so, chu va o gop chinh xac 100%.
- Anh chup man hinh bi mo, nghieng, moire hoac ky tu qua nho van de sai.
- Ban v1.7 chua co tu dong chinh phoi canh 4 goc/nhan dien bang phuc tap.
- Neu co file XLSX goc, doc truc tiep se chinh xac hon chuyen tu anh chup.

KIEM TRA
- Da kiem tra cu phap Kotlin voi Kotlin PSI: 0 loi cu phap trong hai file.
- Da kiem tra hinh hoc vung cat voi goc xoay 0/90/180/270.
- Chua build APK voi Android SDK, chua chay tren Xiaomi cua ban.
- Chua kiem chung accuracy OCR tren file anh chup goc vi nguoi dung chi gui screenshot ung dung Gallery.
