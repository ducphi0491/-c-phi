# DocFlow Offline v0.6 — source đầy đủ

Ứng dụng Kotlin / Jetpack Compose hoạt động offline. Giao diện Trang chủ cải tiến từ hình minh họa của bạn; 7 logo định dạng trong `res/drawable-nodpi` được tách từ bản minh họa tạo trong cuộc trò chuyện. Ứng dụng không gửi file lên máy chủ.

## Phương án dễ nhất: sử dụng dự án Android Studio đang build được

1. Sao lưu các file Kotlin hiện tại trong `app/src/main/java/com/docflowoffline/`.
2. Xóa **các file Kotlin cũ đã gộp** (như `DocFlowApp.kt`, `Theme.kt`, `ExcelGrid.kt`, `CatalogScreens.kt`, v.v.). Giữ đúng 5 file `.kt` trong gói này, tránh trùng class.
3. Chép 5 file trong `app/src/main/java/com/docflowoffline/` vào đúng thư mục package của ứng dụng.
4. Chép 7 ảnh `.png` từ `app/src/main/res/drawable-nodpi/` vào cùng đường dẫn trong ứng dụng, tạo thư mục nếu chưa có.
5. Giữ `AndroidManifest.xml` và `build.gradle.kts` hiện đang hoạt động; nếu muốn đổi logo launcher và version, có thể dùng hai file cung cấp trong dự án này.
6. Kiểm tra 3 file mẫu trong `app/src/main/assets/`: `blank.docx`, `blank.xlsx`, `blank.pptx`.
7. Gradle Sync -> Build -> Rebuild Project -> Run.

## Mở như một dự án mới

Mở thư mục `DocFlowOffline` trong Android Studio. Sử dụng JDK 17 và Android SDK Platform 35.

Thư mục có mã Gradle và `gradle/wrapper/gradle-wrapper.properties` dành cho Gradle 8.9. Do môi trường đóng gói không có Gradle/Android SDK và Gradle wrapper JAR, trong dự án ZIP không có `gradle-wrapper.jar`; nếu Android Studio yêu cầu, sử dụng wrapper đã hoạt động của project hiện tại hoặc tạo wrapper bằng `gradle wrapper --gradle-version 8.9` trên máy có Gradle.

## Mục tiêu và giới hạn

- Có 5 file Kotlin: `MainActivity.kt`, `DocumentStorage.kt`, `DocumentScreens.kt`, `ExcelEditor.kt`, `DocumentEngines.kt`.
- Trang chủ: logo nhiều lớp, phân loại PDF/Excel/Word/PowerPoint/Văn bản, quản lý thư mục được chọn, mở tệp, tìm kiếm, tạo mới, lịch sử.
- Excel: lưới, zoom, thanh công thức, các tab chức năng cơ bản từ v0.5, lưu bản sao để giữ tệp gốc.
- PDF/Word/PPTX và công cụ chuyển đổi: giữ các chức năng của v0.5. Hạn chế của bộ engine OOXML nhẹ **chưa thay đổi**.
- Đây **không phải** bộ Office hoàn chỉnh giống Microsoft Excel 100%: chưa có LibreOffice/Collabora Native. Những tính năng như PivotTable, VBA, hiển thị Office WYSIWYG đầy đủ vẫn chưa hỗ trợ.
- Logo là hình minh họa định dạng theo mẫu tạo ra, không phải bằng chứng ứng dụng có quan hệ thương mại với Microsoft hoặc Adobe. Trước khi phát hành trên Google Play nên tự rà soát quy tắc thương hiệu và giấy phép đi kèm thư viện.

## Kiểm thử

Mã nguồn được đóng gói cùng tài nguyên và đã qua kiểm tra cấu trúc XML, khai báo package, liên kết mã nguồn và kiểm tra lõi OOXML trên JVM; **chưa được build APK hoặc chạy trên Android Studio trong môi trường này**.
