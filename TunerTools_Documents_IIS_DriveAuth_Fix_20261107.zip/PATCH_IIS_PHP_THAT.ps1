param(
    [string]$IisPhp = 'C:\TunerTools\Web\API\api_documents.php',
    [string]$PhpExe = '',
    [switch]$Apply
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Write-Host '=== TUNERTOOLS DOCUMENTS IIS REAL-PHP PATCH V1 ===' -ForegroundColor Cyan
Write-Host ('Source : ' + $IisPhp)
Write-Host ('Mode   : ' + $(if ($Apply) { 'APPLY' } else { 'PREVIEW ONLY' }))

if (-not (Test-Path -LiteralPath $IisPhp -PathType Leaf)) {
    throw 'Real IIS PHP file does not exist. Check the path.'
}
$encoding = [System.Text.UTF8Encoding]::new($false)
$original = [System.IO.File]::ReadAllText($IisPhp, $encoding)
if ($original.Length -lt 60000) {
    throw 'PHP file too small; refusing to patch a stub or redirector.'
}
$marker = 'TT_DOCUMENTS_DRIVE_AUTH_V1_BEGIN'
if ($original.Contains($marker)) {
    Write-Host 'Drive authorization block already installed. No edits made.' -ForegroundColor Green
    exit 0
}
$required = @(
    'function authorizeDocumentAction(',
    'function createDocumentTicket(',
    'function requireDocumentSession(',
    'function permissionCanAccessDocumentPath(',
    'function parentRelativePath(',
    '$db = documentDatabase();'
)
foreach ($needle in $required) {
    if (-not $original.Contains($needle)) {
        throw ('Incompatible real PHP: missing ' + $needle + '. No changes made.')
    }
}
$anchor = '    if ($action === ''auth_login'') {'
$index = $original.IndexOf($anchor, [System.StringComparison]::Ordinal)
if ($index -lt 0 -or $original.IndexOf($anchor, $index + 1, [System.StringComparison]::Ordinal) -ge 0) {
    throw 'Expected unique auth_login dispatch anchor not found. No changes made.'
}
$dbPos = $original.IndexOf('$db = documentDatabase();', [System.StringComparison]::Ordinal)
if ($dbPos -lt 0 -or $dbPos -gt $index) {
    throw 'Wrong placement of DB initialization/dispatcher. No changes made.'
}
$fragmentFile = Join-Path $PSScriptRoot 'drive_authorize_fragment.txt'
if (-not (Test-Path -LiteralPath $fragmentFile)) { throw 'Missing patch fragment.' }
$fragment = [System.IO.File]::ReadAllText($fragmentFile, $encoding)
if (-not $fragment.Contains($marker)) { throw 'Patch fragment marker is missing.' }
$crlf = $original.Contains("`r`n")
if ($crlf) { $fragment = $fragment.Replace("`r`n", "`n").Replace("`n", "`r`n") }
$patched = $original.Insert($index, $fragment + $(if ($crlf) { "`r`n" } else { "`n" }))
$backupDir = 'C:\TunerTools\Backups\DocumentsIIS_DriveAuth'
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$preview = Join-Path $backupDir ('api_documents.PREVIEW_' + $stamp + '.php')
[System.IO.File]::WriteAllText($preview, $patched, $encoding)
Write-Host ('Prepared: ' + $preview)

if ([string]::IsNullOrWhiteSpace($PhpExe)) {
    $known = Get-Command php.exe -ErrorAction SilentlyContinue
    if ($known) { $PhpExe = $known.Source }
}
if ([string]::IsNullOrWhiteSpace($PhpExe)) {
    foreach ($candidate in @(
        'C:\PHP\php.exe',
        'C:\Program Files\PHP\php.exe',
        'C:\TunerTools\Tools\PHP\php.exe',
        'C:\Program Files (x86)\PHP\php.exe'
    )) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            $PhpExe = $candidate
            break
        }
    }
}
if ([string]::IsNullOrWhiteSpace($PhpExe) -or -not (Test-Path -LiteralPath $PhpExe -PathType Leaf)) {
    Write-Warning 'PHP CLI was not located. The real IIS PHP was NOT modified.'
    Write-Host 'Re-run with -PhpExe pointing to php.exe, or install a PHP CLI for linting.'
    exit 2
}
Write-Host ('PHP CLI: ' + $PhpExe)
$lint = & $PhpExe -l $preview 2>&1
$lintCode = $LASTEXITCODE
$lint | ForEach-Object { Write-Host $_ }
if ($lintCode -ne 0) {
    throw 'PHP syntax check failed. The real IIS PHP was NOT modified.'
}
if (-not $Apply) {
    Write-Host 'Preview OK. To install, run the same command with -Apply.' -ForegroundColor Yellow
    exit 0
}

$backup = Join-Path $backupDir ('api_documents.ORIGINAL_' + $stamp + '.php')
Copy-Item -LiteralPath $IisPhp -Destination $backup -Force
try {
    [System.IO.File]::WriteAllText($IisPhp, $patched, $encoding)
    $actualLint = & $PhpExe -l $IisPhp 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ('Live PHP failed syntax check: ' + ($actualLint -join ' '))
    }
    $written = [System.IO.File]::ReadAllText($IisPhp, $encoding)
    if (-not $written.Contains($marker)) { throw 'Inserted block was not found after writing.' }
    Write-Host 'PATCH APPLIED. PHP syntax check OK.' -ForegroundColor Green
    Write-Host ('ORIGINAL BACKUP: ' + $backup)
    Write-Host 'Do not delete the backup until public list and media are tested.'
} catch {
    Copy-Item -LiteralPath $backup -Destination $IisPhp -Force
    throw ('Patch failed; original IIS PHP restored. Error: ' + $_.Exception.Message)
}
