$ErrorActionPreference = 'Stop'
Write-Host '=== IIS Documents Drive authorization check (NO LOGIN) ===' -ForegroundColor Cyan
$url = 'https://tunertools.top/api_documents.php'
try {
    $body = @{
        action = 'drive_authorize'
        purpose = 'list'
        instrument = 'guitar'
        path = ''
        children_json = '[]'
    }
    $r = Invoke-WebRequest -Uri $url -Method Post -Body $body -UseBasicParsing -TimeoutSec 25
    Write-Host ('HTTP: ' + [int]$r.StatusCode)
    Write-Host 'Unexpected anonymous success; check authentication before deployment!' -ForegroundColor Red
} catch [System.Net.WebException] {
    $r = $_.Exception.Response
    if ($null -eq $r) { throw }
    $status = [int]$r.StatusCode
    Write-Host ('HTTP: ' + $status)
    if ($status -eq 401) {
        Write-Host 'EXPECTED: endpoint exists and requires a valid session.' -ForegroundColor Green
    } elseif ($status -eq 403) {
        Write-Host 'Endpoint rejected access. Inspect HTTP response code in server logs.' -ForegroundColor Yellow
    } else {
        Write-Host 'Endpoint may not be ready or configuration differs.' -ForegroundColor Yellow
    }
}
