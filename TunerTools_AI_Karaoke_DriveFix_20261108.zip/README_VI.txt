TUNERTOOLS AI - DRIVE-FIRST KARAOKE DIAGNOSTIC & REPAIR (2026-11-08)

Nguon: SongMainScreen.kt, SongRepository.kt Drive-first da gui truoc.

Sua 3 van de trong Kotlin:
1. Chuoi mau loi bai hat (SongScraper.getLyricsSample) bo so thu tu doan 1., 2)...
   Truoc do "1. Mot chieu thu ..." thanh "1 Mot chieu thu..." nen so sanh JSON Zing bi sai.
2. Neu zingMp3Id o chi tiet bai hat thieu, tim lai theo TEN BAI + CA SI chinh xac
   trong API Google Drive cached_songs; chi chap nhan DUY NHAT mot Zing ID.
3. Neu file JSON tren Drive co ten khac ten metadata SQLite, tim ten theo danh sach
   cached_songs, giu dung ban ca si, doi chieu cau loi dau truoc khi hien thi.
4. Ghi log AiDriveSource chi ro source/fallback/ly do khong tim thay karaoke.

KHONG DOI api_ai_media_drive.php: ban PHP Alwaysdata hien tai da co action=cached_songs,
lookup/stream/lyrics. Khong can upload PHP lai.

CACH CAI:
- Sao luu 2 file Kotlin hien tai trong Android Studio.
- Thay SongMainScreen.kt va SongRepository.kt bang file trong ZIP.
- Build APK va cai moi len dien thoai thu nghiem.
- Logcat: tag:AiDriveSource
- Thu bai "Don Dau Vo Cung" (DATKAA), che do Karaoke; sau do che do Ca Si.

CHECK CHUAN DAU RA:
- "Zing karaoke JSON: google_drive..." -> dung JSON Drive.
- "Zing audio prepared: google_drive" / "google_drive_download" -> dung audio Drive.
- "ZING_MP3 karaoke failed..." -> doc log du lieu thieu, khong phai loi media player.
- Neu Drive chi co audio ma chua co JSON cho bai nay, Karaoke van can Python de
  xu ly. Tham so "has_lyrics_cache" trong cached_songs cho biet JSON da co.
- Che do ZING_MP3 la karaoke chu/chay chu, khong tu phat audio giong Ca Si.

LUU Y:
- Khong xoa cache tren Windows, khong thay doi ZING_AUDIO, khong them token.
- Khong test Gradle/Android APK day du vi khong co toan bo du an.
- SongMainScreen.kt quan ly ca player; cho du co JSON dung, neu am thanh van
  khong phat thi xem tiep Logcat tag AiDriveSource cua Zing audio prepared.
