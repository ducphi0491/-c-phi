param(
    [string]$Title = 'Đớn Đau Vô Cùng',
    [string]$Singer = 'DATKAA'
)
$ErrorActionPreference = 'Stop'
$baseUrl = 'https://tuner.alwaysdata.net/api_ai_media_drive.php'
Write-Host '===== TUNERTOOLS ZING KARAOKE / GOOGLE DRIVE CHECK =====' -ForegroundColor Cyan
Write-Host "Requested song: $Title / $Singer"
Write-Host '1. Checking cached_songs (no Drive token needed on this PC)...'
$catalog = Invoke-RestMethod -Uri "$baseUrl?action=cached_songs" -TimeoutSec 120
if (-not $catalog.ok -or $catalog.source -ne 'google_drive') {
    throw 'Alwaysdata did not return a valid Drive catalog.'
}
$matches = @($catalog.songs | Where-Object {
    $_.source -eq 'zing' -and $_.title -eq $Title -and $_.singer -eq $Singer
})
if ($matches.Count -eq 0) {
    Write-Warning 'No exact Zing title+singer match in Drive cached_songs.'
    Write-Host 'Related entries:'
    @($catalog.songs | Where-Object { $_.source -eq 'zing' -and $_.title -like "*$Title*" } |
      Select-Object -First 15 id,title,singer,has_audio_cache,has_lyrics_cache) |
      Format-Table -AutoSize
    return
}
$matches | Select-Object id,title,singer,has_audio_cache,has_lyrics_cache | Format-Table -AutoSize
foreach ($song in $matches) {
    $id = [string]$song.id
    if ($song.has_lyrics_cache) {
        $filename = "${id}_$($song.title)_$($song.singer).json"
        $encoded = [uri]::EscapeDataString($filename)
        $lyricUrl = "${baseUrl}?action=lookup&kind=lyrics&filename=$encoded"
        $lyric = Invoke-RestMethod -Uri $lyricUrl -TimeoutSec 45
        Write-Host "Lyrics: found=$($lyric.found) filename=$filename"
        if ($lyric.found) {
            $jsonUrl = "${baseUrl}?action=lyrics&filename=$encoded"
            $json = Invoke-RestMethod -Uri $jsonUrl -TimeoutSec 45
            Write-Host "Timed sentences: $(@($json.data.sentences).Count)"
        }
    } else {
        Write-Warning "Zing ID $id has no lyrics JSON in the Drive index. Karaoke will need Python or a JSON sync."
    }
    foreach ($ext in @('ogg','mp3','wav')) {
        $audioName = "zing_acapella_${id}.${ext}"
        $audioUrl = "${baseUrl}?action=lookup&filename=$([uri]::EscapeDataString($audioName))"
        try {
            $audio = Invoke-RestMethod -Uri $audioUrl -TimeoutSec 45
            if ($audio.found) {
                Write-Host "Audio: found=True filename=$audioName bytes=$($audio.size_bytes)"
                break
            }
        } catch {
            Write-Warning "Audio lookup $audioName failed: $($_.Exception.Message)"
        }
    }
}
