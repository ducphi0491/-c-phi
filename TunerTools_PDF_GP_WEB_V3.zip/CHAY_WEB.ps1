param([switch]$Reinstall)

# Windows PowerShell 5.1 and Windows 10/11. No administrator rights required.
# The app listens ONLY on 127.0.0.1, not on a public network interface.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root
$Venv = Join-Path $Root '.venv'
$Python = Join-Path $Venv 'Scripts\python.exe'

Write-Host ''
Write-Host '===========================================' -ForegroundColor Cyan
Write-Host ' TunerTools - PDF / Anh - Khuong + TAB V3' -ForegroundColor Cyan
Write-Host '===========================================' -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath $Python)) {
    Write-Host 'Tao moi truong Python rieng ...' -ForegroundColor Yellow
    $created = $false
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3.11 -m venv $Venv
        $created = ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python))
        if (-not $created) {
            & py -3.12 -m venv $Venv
            $created = ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python))
        }
    }
    if (-not $created -and (Get-Command python -ErrorAction SilentlyContinue)) {
        & python -m venv $Venv
        $created = ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Python))
    }
    if (-not $created) {
        Write-Host 'LOI: Can cai Python 3.11 hoac 3.12 (64-bit), bat Add Python to PATH.' -ForegroundColor Red
        exit 1
    }
}

$Marker = Join-Path $Root '.deps_installed_v3'
if ((-not (Test-Path -LiteralPath $Marker)) -or $Reinstall) {
    Write-Host 'Cai thu vien web, OCR, Guitar Pro ... (can Internet o lan dau)' -ForegroundColor Yellow
    & $Python -m pip install --disable-pip-version-check -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'LOI: Khong cai duoc thu vien Python. Kiem tra ket noi mang va dong bao loi.' -ForegroundColor Red
        exit 1
    }

    & $Python -c "import pdf_to_gp5"
    $NeedsEngine = ($LASTEXITCODE -ne 0)
    if (-not $NeedsEngine) {
        Write-Host '[OK] Bo PDF-to-GP5 da cai tu ban web truoc; khong can tai lai GitHub.' -ForegroundColor Green
    } else {
        # Obtain the MIT-licensed converter from its original project. Do not use
        # the proprietary EZMusic Orpheus models as a redistribution dependency.
        Write-Host 'Cai bo nhan dien PDF-to-GP5 ma nguon mo (MIT) ...' -ForegroundColor Yellow
        $Archive = Join-Path $Root '.pdf-to-gp5-main.zip'
        $Source = Join-Path $Root '.pdf-to-gp5-source'
        $Urls = @(
            'https://codeload.github.com/F100Pilot/PDF-to-GP5/zip/refs/heads/main',
            'https://github.com/F100Pilot/PDF-to-GP5/archive/refs/heads/main.zip'
        )
        $got = $false
        $Manual = Join-Path $Root 'PDF-to-GP5-main.zip'
        if ((Test-Path -LiteralPath $Manual) -and ((Get-Item -LiteralPath $Manual).Length -gt 1000)) {
            Copy-Item -LiteralPath $Manual -Destination $Archive -Force
            $got = $true
            Write-Host 'Su dung file engine tai thu cong: PDF-to-GP5-main.zip' -ForegroundColor Yellow
        }
        if (-not $got) {
            foreach ($url in $Urls) {
                try {
                    Invoke-WebRequest -Uri $url -OutFile $Archive -TimeoutSec 90 -UseBasicParsing
                    if ((Test-Path -LiteralPath $Archive) -and ((Get-Item -LiteralPath $Archive).Length -gt 1000)) {
                        $got = $true
                        break
                    }
                } catch {
                    Write-Host ('Khong tai duoc tu URL nay: ' + $_.Exception.Message) -ForegroundColor Yellow
                }
            }
        }
        if (-not $got) {
            Write-Host 'LOI: Khong tai duoc engine PDF-to-GP5 tu GitHub.' -ForegroundColor Red
            Write-Host 'Huong dan: https://github.com/F100Pilot/PDF-to-GP5 (Code -> Download ZIP)' -ForegroundColor Yellow
            exit 1
        }
        try {
            if (Test-Path -LiteralPath $Source) { Remove-Item -LiteralPath $Source -Recurse -Force }
            Expand-Archive -LiteralPath $Archive -DestinationPath $Source -Force
        } catch {
            Write-Host ('LOI giai nen engine: ' + $_.Exception.Message) -ForegroundColor Red
            exit 1
        }
        $Project = Get-ChildItem -LiteralPath $Source -Directory | Where-Object {
            Test-Path -LiteralPath (Join-Path $_.FullName 'pyproject.toml')
        } | Select-Object -First 1
        if (-not $Project) {
            Write-Host 'LOI: File GitHub tai ve khong dung cau truc engine.' -ForegroundColor Red
            exit 1
        }
        & $Python -m pip install --disable-pip-version-check $Project.FullName
        if ($LASTEXITCODE -ne 0) {
            Write-Host 'LOI: Cai bo nhan dien PDF-to-GP5 khong thanh cong.' -ForegroundColor Red
            exit 1
        }
    }
    # Verify imports so a broken installation is not recorded as successful.
    & $Python -c "import fastapi, guitarpro, pdf_to_gp5, rapidocr_onnxruntime; print('Thiet lap thu vien thanh cong')"
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'LOI: Thieu thu vien. Thu chay lai voi -Reinstall.' -ForegroundColor Red
        exit 1
    }
    Set-Content -LiteralPath $Marker -Value 'Installed successfully; PDF-to-GP5 upstream main, checked imports.' -Encoding UTF8
}

# Optional visual renderer: local alphaTab + Bravura + SoundFont (MPL/OFL/Apache).
# If download fails, the built-in offline SVG renderer still shows both staff and TAB.
$AlphaJs = Join-Path $Root 'static\alphatab\alphaTab.min.js'
$AlphaSound = Join-Path $Root 'static\alphatab\soundfont\sonivox.sf2'
if (-not (Test-Path -LiteralPath $AlphaJs) -or -not (Test-Path -LiteralPath $AlphaSound)) {
    Write-Host 'Cai bo hien thi khuong nhac alphaTab cho lan dau ...' -ForegroundColor Yellow
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root 'CAI_ALPHATAB.ps1')
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'CHU Y: Khong cai duoc alphaTab. Van dung duoc khuong nhac SVG co ban.' -ForegroundColor Yellow
    }
}

$Port = 8021
$Url = "http://127.0.0.1:$Port"
# Prevent accidentally displaying an older instance still bound to port 8021.
try {
    $Existing = Invoke-WebRequest -Uri ($Url + '/api/health') -TimeoutSec 2 -UseBasicParsing -ErrorAction Stop
    if ($Existing.StatusCode -eq 200) {
        Write-Host 'LOI: Port 8021 van dang co web cu chay. Hay quay lai cua so CHAY_WEB cu, nhan ENTER de dung.' -ForegroundColor Red
        Write-Host 'Sau do hay chay lai file CHAY_WEB.bat moi; nhan Ctrl+F5 tren trinh duyet.' -ForegroundColor Yellow
        exit 1
    }
} catch { }
Write-Host ('Mo server local: ' + $Url) -ForegroundColor Green

# Start the local server. A separate process allows the script to open the
# browser only after its health endpoint responds (rather than showing a 404).
$server = Start-Process -FilePath $Python -ArgumentList @('-m','uvicorn','app:app','--host','127.0.0.1','--port',"$Port",'--workers','1') -WorkingDirectory $Root -PassThru
if (-not $server) {
    Write-Host 'LOI: Khong khoi dong duoc server.' -ForegroundColor Red
    exit 1
}
$ready = $false
for ($i=0; $i -lt 40; $i++) {
    try {
        $res = Invoke-WebRequest -Uri ($Url + '/api/health') -TimeoutSec 2 -UseBasicParsing
        if ($res.StatusCode -eq 200) { $ready = $true; break }
    } catch { Start-Sleep -Milliseconds 500 }
    if ($server.HasExited) { break }
}
if (-not $ready) {
    Write-Host 'LOI: Server khong san sang. Kiem tra port 8021 va Python.' -ForegroundColor Red
    if (-not $server.HasExited) { Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue }
    exit 1
}
Start-Process $Url
Write-Host ''
Write-Host 'Da mo giao dien tren trinh duyet.' -ForegroundColor Green
Write-Host 'KHONG mo cong 8021 ra Internet; moi file duoc xu ly tren may tinh.'
Write-Host 'Nhan ENTER tai cua so nay de dung server.' -ForegroundColor Cyan
$null = Read-Host
Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
