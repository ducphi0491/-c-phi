TUNERTOOLS AI - KOTLIN + PHP

1. SongMainScreen.kt: replace the existing SongMainScreen.kt in Android Studio.
2. SongMainScreen.txt: identical content to .kt, use if download of .kt fails.
3. api_ai_media_drive.php: upload to Alwaysdata in the same directory as other Drive APIs.

This bundle includes the AI Google Drive phase-1 read/fallback code from the prior release.
It does NOT change the Python backend or automatically upload new AI results.
Do not expose OAuth tokens on the website.

Before switching traffic, test the PHP health endpoint and an actual track.
