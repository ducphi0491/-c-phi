GOOGLE DRIVE AI JSON CACHE SYNC - 07/11/2026

NGUYEN NHAN:
API https://tuner.alwaysdata.net/api_ai_media_drive.php?action=cached_songs
tra ve audio_entries_scanned=1342, json_entries_scanned=0.
PHP da doc duoc stream_cache tren Google Drive nhung khong thay file JSON trong folder lyrics.
Vi vay danh sach hien 'Zing <ID>' va has_lyrics_cache=false.

DUONG DAN NGUON WINDOWS:
C:\TunerTools\Audio\AI_Music\ZING_JSON\*.json
C:\TunerTools\Audio\AI_Music\YOUTUBE_CACHE\lyrics_*.json va meta_*.json

DUONG DAN DICH DRIVE:
My Drive/TunerTools_AppBackup/AI_Music/lyrics

SCRIPT: CHAY_UPLOAD_AI_JSON.ps1 dung Python 3.10+ va thu vien chuan, khong can pip.
Mac dinh chi PREVIEW, khong upload. Phai co -Upload moi tao file moi tren Drive.
Khong xoa/doi ten/ghi de file, khong sua token OAuth, khong tai len PHP.
Script doc private drive_token.json cua cong cu GP (co the truyen -TokenFile),
KHONG dua token len server cong khai va KHONG gui token cho ai.

BUOC 1 - Giai nen 3 file nay chung mot thu muc tren WINDOWS.
BUOC 2 - Mo PowerShell tai thu muc da giai nen:

    .\CHAY_UPLOAD_AI_JSON.ps1 -OnlyId "18JJ0AEDF3CO"

BUOC 3 - Neu preview thay MISSING > 0, upload RIENG bai kiem thu:

    .\CHAY_UPLOAD_AI_JSON.ps1 -OnlyId "18JJ0AEDF3CO" -Upload

BUOC 4 - Kiem tra file tren Drive bang API, vi du file co ten:
    18JJ0AEDF3CO_Dong Song Mua Thu_<CaSi>.json
    https://tuner.alwaysdata.net/api_ai_media_drive.php?action=lookup&kind=lyrics&filename=<URL-encoded-file-name>
Doi cache PHP het han (600 giay), sau do:
    https://tuner.alwaysdata.net/api_ai_media_drive.php?action=cached_songs
    json_entries_scanned phai > 0, ten bai va ca si lay tu ten file JSON.

BUOC 5 - Dong bo tat ca JSON:

    .\CHAY_UPLOAD_AI_JSON.ps1 -Upload

BAO CAO:
C:\TunerTools\Audio\AI_Music\KET_QUA_UPLOAD_JSON_DRIVE.json

THANH PHAN KHONG CAN THAY:
api_ai_media_drive.php (vi action=cached_songs da hoat dong),
SongRepository.kt, SongMainScreen.kt, app.py, api_songs.php.

LUU Y:
- Cach lam tren chi dong bo JSON da ton tai, KHONG tao loi moi / JSON moi.
- Ten file JSON phai khop dung Zing ID. PHP dang danh sach theo ten file,
  KHONG doc truc tiep noi dung JSON de kiem tra dung bai/ca si.
- Neu JSON cu sai ten/ca si, can kiem tra du lieu truoc khi phan phoi.
- Script co the bao loi quyen Drive, token khong hop le, hoac Drive quota.
- Script khong lam thay doi Windows ZING_AUDIO, ZING_JSON, YOUTUBE_CACHE.
- Neu dang test doi ZING_AUDIO2, doi lai ZING_AUDIO de app cu/Python khong bi anh huong.
