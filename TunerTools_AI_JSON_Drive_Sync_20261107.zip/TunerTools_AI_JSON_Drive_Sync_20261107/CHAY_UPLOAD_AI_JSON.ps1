param(
    [string]$SourceDir = "C:\TunerTools\Audio\AI_Music",
    [string]$TokenFile = "",
    [string]$OnlyId = "",
    [switch]$Upload
)
$ErrorActionPreference = "Stop"
$scriptFile = Join-Path $PSScriptRoot 'UPLOAD_AI_JSON_DRIVE.py'
if (-not (Test-Path $scriptFile)) { throw "Missing: $scriptFile" }
$arguments = @($scriptFile, '--source', $SourceDir)
if ($TokenFile) { $arguments += @('--token', $TokenFile) }
if ($OnlyId) { $arguments += @('--only-id', $OnlyId) }
if ($Upload) { $arguments += '--upload' }
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 @arguments
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python @arguments
} else { throw 'Python 3.10+ not found.' }
if ($LASTEXITCODE -ne 0) { throw "Upload JSON check failed (exit code: $LASTEXITCODE)" }
