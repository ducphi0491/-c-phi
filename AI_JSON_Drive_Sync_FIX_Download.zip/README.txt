TunerTools AI JSON -> Google Drive (Windows Server)

1) Giai nen ZIP vao C:\TunerTools\Tools\AI_JSON_Drive_Sync
2) Mo Windows PowerShell:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Drive_Sync\CHAY_UPLOAD_AI_JSON.ps1" -OnlyId "18JJ0AEDF3CO"
3) Neu PREVIEW OK va MISSING > 0, upload THU mot bai:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Drive_Sync\CHAY_UPLOAD_AI_JSON.ps1" -OnlyId "18JJ0AEDF3CO" -Upload
4) Sau khi xac nhan Drive co JSON, dong bo tat ca:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Drive_Sync\CHAY_UPLOAD_AI_JSON.ps1" -Upload

Source folders:
C:\TunerTools\Audio\AI_Music\ZING_JSON
C:\TunerTools\Audio\AI_Music\YOUTUBE_CACHE

Private Google Drive destination: My Drive/TunerTools_AppBackup/AI_Music/lyrics

Default run is preview (no upload); -Upload creates files missing on Google Drive.
No deletion or overwrite; reads existing private token from known BackupScripts paths.
Python 3.10+ needed. Keep these 3 files together in the same directory.
To specify a token path explicitly: -TokenFile "C:\path\to\drive_token.json".
Do not share token contents.
