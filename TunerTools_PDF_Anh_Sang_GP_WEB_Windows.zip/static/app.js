'use strict';

const $ = id => document.getElementById(id);
const state = { file: null, blobURL: null, jobId: null, response: null, track: 0,
  audio: null, interval: null, isPlaying: false, positionQ: 0, startQ: 0, startAt: 0,
  events: [], nextEvent: 0, maxQ: 0, activeNote: null, editing: null, demo: false };
const FILE_MAX = 35 * 1024 * 1024;
const n2 = n => String(n).padStart(2, '0');
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c])); }
function fmtTime(sec) { sec = Math.max(0, Math.floor(sec)); return `${n2(Math.floor(sec/60))}:${n2(sec%60)}`; }
function getBpm() { return Math.min(300, Math.max(30, Number($('playBpm').value) || 100)); }
function getSpeed() { return Number($('speedSelect').value) || 1; }
function secPerQuarter() { return 60 / (getBpm()*getSpeed()); }
function loadFile(file) {
  if (!file) return;
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (!['pdf','png','jpg','jpeg','webp','gp3','gp4','gp5'].includes(ext)) return showError('Chỉ hỗ trợ PDF, PNG, JPG, WebP và GP3/GP4/GP5.');
  if (file.size > FILE_MAX) return showError('File lớn hơn 35 MB, vui lòng chọn file nhỏ hơn.');
  clearError(); stopPlayer();
  state.file = file; state.jobId = null; state.response = null; state.demo = false;
  $('fileName').textContent = file.name;
  $('fileSize').textContent = (file.size/1024/1024).toFixed(2)+' MB';
  $('selectedFile').classList.remove('hidden');
  $('convertBtn').disabled = false;
  setSource(file);
  resetScore();
}
function setSource(file) {
  if (state.blobURL) URL.revokeObjectURL(state.blobURL);
  state.blobURL = URL.createObjectURL(file);
  $('emptySource').classList.add('hidden'); $('pdfViewer').classList.add('hidden'); $('imgViewer').classList.add('hidden');
  const ext = file.name.split('.').pop().toLowerCase();
  if (ext === 'pdf') { $('pdfViewer').src = state.blobURL; $('pdfViewer').classList.remove('hidden'); }
  else if (['png','jpg','jpeg','webp'].includes(ext)) { $('imgViewer').src = state.blobURL; $('imgViewer').classList.remove('hidden'); }
  else { $('emptySource').classList.remove('hidden'); $('emptySource').querySelector('h3').textContent = 'Đầu vào Guitar Pro không có ảnh/PDF gốc'; }
}
function resetScore() {
  $('emptyScore').classList.remove('hidden'); $('scoreContent').classList.add('hidden');
  $('report').classList.add('hidden'); $('trackPicker').innerHTML='';
  for(const el of ['gp5Btn','gp4Btn','gp3Btn','downloadAllBtn','playBtn','stopBtn','prevBtn','playBpm','speedSelect','positionSlider']) $(el).disabled = true;
  $('currentTime').textContent='00:00'; $('totalTime').textContent='00:00'; $('positionSlider').value=0;
}
function showError(message) { $('errorBox').textContent = message; $('errorBox').classList.remove('hidden'); }
function clearError() { $('errorBox').textContent=''; $('errorBox').classList.add('hidden'); }
function switchTab(which) {
  for(const tab of document.querySelectorAll('.tab')) tab.classList.toggle('active',tab.dataset.tab===which);
  for(const view of document.querySelectorAll('.tab-view')) view.classList.toggle('hidden',view.id!==which);
}
async function convert() {
  if (!state.file) return;
  clearError(); stopPlayer();
  $('convertBtn').disabled=true;
  $('processing').classList.remove('hidden');
  $('processingTitle').textContent='Đang nhận diện TAB và tạo file Guitar Pro…';
  const form = new FormData(); form.append('file', state.file);
  const bpm = $('bpmInput').value.trim(); if(bpm) form.append('bpm',bpm);
  try {
    const reply = await fetch('/api/convert',{method:'POST',body:form});
    const body = await reply.json();
    if(!reply.ok) throw Error(typeof body.detail==='string'?body.detail:`Lỗi HTTP ${reply.status}`);
    state.jobId=body.id; state.demo=false; displayResult(body);
    switchTab('tabScore');
  } catch(err) { showError(err.message||String(err)); }
  finally { $('processing').classList.add('hidden'); $('convertBtn').disabled=false; }
}
function displayResult(result) {
  stopPlayer();state.response=result; state.track=0;state.positionQ=0;
  const score=result.score;
  $('emptyScore').classList.add('hidden'); $('scoreContent').classList.remove('hidden');
  $('songTitle').textContent=score.title||state.file?.name||'Bản nhạc';
  $('songMeta').textContent=`${score.total_measures} ô nhịp · ${score.total_notes} nốt · ${score.tracks.length} track`;
  $('scoreStatus').textContent=state.demo?'DEMO PHÁT ÂM THANH':'CHƯA ĐỐI CHIẾU PDF';
  $('trackPicker').innerHTML=score.tracks.map((t,i)=>`<option value="${i}">${esc(t.name||'Guitar')} (${t.strings} dây)</option>`).join('');
  $('trackPicker').value='0'; $('playBpm').value=score.tempo||100;
  for(const id of ['playBtn','stopBtn','prevBtn','playBpm','speedSelect','positionSlider']) $(id).disabled=false;
  for(const fmt of ['gp5','gp4','gp3']) $(fmt+'Btn').disabled=!result.formats?.includes(fmt);
  $('downloadAllBtn').disabled=!result.formats?.length;
  const out=score.total_measures;
  $('stats').innerHTML=`<div><strong>${out}</strong><span>Ô nhịp</span></div><div><strong>${score.total_notes}</strong><span>Nốt ghi nhận</span></div><div><strong>${score.tracks.length}</strong><span>Track</span></div><div><strong>${score.tempo}</strong><span>BPM gốc</span></div>`;
  const warnings=[];
  if(state.demo) warnings.push('Bản nhạc demo chỉ dùng để thử phát âm thanh; không có file GP xuất được.');
  else warnings.push('Kết quả OCR là bản nháp; cần so sánh từng ô nhịp với PDF/ảnh gốc trước khi xuất hoặc phát hành.');
  for(const w of (result.warnings||[]).slice(0,12)) warnings.push(w);
  for(const [fmt,w] of Object.entries(result.export_warnings||{})) warnings.push(`${fmt.toUpperCase()}: ${w}`);
  $('warnings').innerHTML=warnings.map(w=>`<div>⚠ ${esc(w)}</div>`).join('');
  $('report').classList.remove('hidden');
  renderTrack();
}
function midiLabel(midi) { const names=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];return names[((midi%12)+12)%12]; }
function renderTrack() {
  stopPlayer();
  const score=state.response?.score;if (!score) return;
  const track=score.tracks[state.track];if(!track) return;
  const container=$('tabNotation'); container.innerHTML='';
  const count=Math.max(1,Number(track.strings)||6);
  let html='';
  for(const measure of track.measures) {
    // A column means an event at a beat position (different voices are kept distinct).
    const beats=measure.beats.slice().sort((a,b)=>a.position-b.position||a.voice-b.voice||a.beat-b.beat);
    const columns=Math.max(beats.length,1);
    html+=`<div class="bar-score" data-measure="${measure.index}"><div class="bar-no">${measure.number}</div><div class="time-no">${esc(measure.time)}</div><div class="tab-strings">`;
    for(let string=1;string<=count;string++) {
      const label=midiLabel(Number(track.tuning[string]||40));
      html+=`<div class="tab-string"><span class="string-name">${esc(label)}</span><div class="cells" style="--cols:${columns}">`;
      if (!beats.length) html+='<div class="note-cell"><span class="rest-num">—</span></div>';
      for(const beat of beats) {
        const ns=beat.notes.filter(n=>n.string===string);
        html+='<div class="note-cell">';
        for (const n of ns) {
          html+=`<button class="fret-note" title="Sửa số ngăn; ô ${measure.number}, dây ${string}" data-track="${state.track}" data-measure="${measure.index}" data-voice="${beat.voice}" data-beat="${beat.beat}" data-note="${n.note}" data-string="${string}" data-fret="${n.fret}" data-start="${measure.start+beat.position}" data-length="${beat.length}">${esc(n.fret)}</button>`;
        }
        html+='</div>';
      }
      html+='</div></div>';
    }
    html+='</div></div>';
  }
  container.innerHTML=html||'<p>Track không chứa ô nhịp có thể hiển thị.</p>';
  state.events=[]; state.maxQ=track.duration_quarters||0;
  for(const measure of track.measures){
    for(const beat of measure.beats){
      for(const n of beat.notes){
        state.events.push({at:measure.start+beat.position,length:beat.length,pitch:n.pitch,
          velocity:n.velocity,measure:measure.index,string:n.string,fret:n.fret,
          key:`${state.track}:${measure.index}:${beat.voice}:${beat.beat}:${n.note}`});
      }
    }
  }
  state.events.sort((a,b)=>a.at-b.at);
  state.positionQ=0; syncTime();
}
function tone(ctx, pitch, at, len, velocity) {
  // Lightweight sound to preview the note contour, not a Guitar Pro/SoundFont renderer.
  const hz=440*Math.pow(2,(pitch-69)/12);
  const gain=ctx.createGain();
  gain.gain.setValueAtTime(0.0001,at);
  gain.gain.exponentialRampToValueAtTime(Math.min(.13,.08*(velocity||95)/95)+.0001,at+.012);
  gain.gain.exponentialRampToValueAtTime(0.0001,at+Math.min(Math.max(.14,len),2.7));
  gain.connect(ctx.destination);
  for(const [type,mul,level] of [['triangle',1,.8],['sine',2,.18]]) {
    const osc=ctx.createOscillator();osc.type=type;osc.frequency.setValueAtTime(hz*mul,at);
    const g=ctx.createGain();g.gain.value=level;osc.connect(g);g.connect(gain);
    osc.start(at);osc.stop(at+Math.min(Math.max(.14,len),2.7)+.04);
  }
}
function currentQuarter() {
  if (!state.isPlaying || !state.audio) return state.positionQ;
  return Math.min(state.maxQ,state.startQ+(state.audio.currentTime-state.startAt)/secPerQuarter());
}
function syncTime() {
  const max=state.maxQ||0;
  const sec=secPerQuarter();
  $('currentTime').textContent=fmtTime(state.positionQ*sec);
  $('totalTime').textContent=fmtTime(max*sec);
  $('positionSlider').value=max?Math.floor(1000*state.positionQ/max):0;
}
function clearHighlights() {
  document.querySelectorAll('.bar-score.playing').forEach(el=>el.classList.remove('playing'));
  document.querySelectorAll('.fret-note.active').forEach(el=>el.classList.remove('active'));
}
function highlight(q) {
  if (!state.events.length) return;
  const tr=state.response.score.tracks[state.track];
  const measure=tr.measures.find(m=>q>=m.start && q<m.start+m.length) || tr.measures.at(-1);
  if(!measure) return;
  const bar=document.querySelector(`.bar-score[data-measure="${measure.index}"]`);
  if(!bar) return;
  if(state.activeNote!==measure.index) {
    clearHighlights();bar.classList.add('playing');state.activeNote=measure.index;
    if (state.isPlaying) bar.scrollIntoView({block:'nearest',behavior:'smooth'});
  }
  for(const el of bar.querySelectorAll('.fret-note')){
    const at=Number(el.dataset.start);
    el.classList.toggle('active',q>=at && q<at+Math.max(.08,Number(el.dataset.length)||.25));
  }
}
function tick() {
  if(!state.isPlaying || !state.audio)return;
  const now=state.audio.currentTime;
  state.positionQ=currentQuarter();
  const ahead=now+.2;
  while(state.nextEvent<state.events.length){
    const ev=state.events[state.nextEvent];
    const when=state.startAt+(ev.at-state.startQ)*secPerQuarter();
    if(when>ahead) break;
    if(when>=now-.1) tone(state.audio,ev.pitch,Math.max(when,now+.002),ev.length*secPerQuarter(),ev.velocity);
    state.nextEvent++;
  }
  highlight(state.positionQ);syncTime();
  if(state.positionQ>=state.maxQ-.005) stopPlayer(true);
}
async function playPlayer() {
  if(!state.response)return;
  if(state.isPlaying) return pausePlayer();
  try {
    if(!state.audio) state.audio=new(window.AudioContext||window.webkitAudioContext)();
    await state.audio.resume();
  }catch(e){return showError('Không mở được WebAudio: '+e.message);}
  if(state.positionQ>=state.maxQ)state.positionQ=0;
  state.startQ=state.positionQ;state.startAt=state.audio.currentTime+.06;
  state.nextEvent=state.events.findIndex(e=>e.at>=state.startQ-.0001);
  if(state.nextEvent<0)state.nextEvent=state.events.length;
  state.isPlaying=true;$('playBtn').textContent='Ⅱ';$('playBtn').ariaLabel='Tạm dừng';
  state.interval=setInterval(tick,35);tick();
}
function pausePlayer() {
  if(state.isPlaying)state.positionQ=currentQuarter();
  state.isPlaying=false;
  if(state.interval)clearInterval(state.interval);
  state.interval=null;$('playBtn').textContent='▶';$('playBtn').ariaLabel='Phát bản nhạc';syncTime();
}
function stopPlayer(end=false) {
  pausePlayer();state.positionQ=end?state.maxQ:0;
  state.activeNote=null;clearHighlights();syncTime();
}
function seekQuarter(q) {
  const playing=state.isPlaying;
  pausePlayer();state.positionQ=Math.max(0,Math.min(state.maxQ,q));syncTime();highlight(state.positionQ);
  if(playing)playPlayer();
}
function triggerDownload(fmt){
  if(!state.jobId)return;
  const url=fmt==='zip'?`/api/download-all/${state.jobId}`:`/api/download/${state.jobId}/${fmt}`;
  const a=document.createElement('a');a.href=url;a.download='';document.body.appendChild(a);a.click();a.remove();
}
function openEdit(button) {
  if(state.demo) return showError('Bản demo chỉ dùng thử âm thanh, không lưu các nốt. Hãy chọn PDF/ảnh thật.');
  const d=button.dataset;
  state.editing={track:Number(d.track),measure:Number(d.measure),voice:Number(d.voice),beat:Number(d.beat),note:Number(d.note)};
  $('editContext').textContent=`Ô ${state.editing.measure+1} · dây ${d.string} · ngăn hiện tại ${d.fret}`;
  $('editFret').value=d.fret;$('editString').value=d.string;$('editError').classList.add('hidden');$('editDialog').showModal();
}
async function saveEdit(e) {
  e.preventDefault();
  if(!state.editing||!state.jobId)return;
  const fret=Number($('editFret').value);
  const string=Number($('editString').value);
  if(!Number.isInteger(fret)||fret<0||fret>36||!Number.isInteger(string)||string<1||string>8)return;
  $('saveEdit').disabled=true;
  try{
    const r=await fetch(`/api/edit/${state.jobId}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...state.editing,fret,string})});
    const payload=await r.json();
    if(!r.ok)throw Error(payload.detail||`Lỗi ${r.status}`);
    const selectedTrack=state.track;
    displayResult(payload);state.track=selectedTrack;$('trackPicker').value=String(selectedTrack);renderTrack();
    $('editDialog').close();
  }catch(err){$('editError').textContent=err.message;$('editError').classList.remove('hidden');}
  finally{$('saveEdit').disabled=false;}
}
function loadDemo(){
  clearError();stopPlayer();state.jobId=null;state.demo=true;
  const melody=[0,2,3,0,3,5,7,5,3,2,0,2,3,0,2,0];
  const bars=[];for(let m=0;m<4;m++){
    bars.push({index:m,number:m+1,start:m*4,length:4,time:'4/4',beats:melody.slice(m*4,m*4+4).map((f,i)=>({voice:0,beat:i,position:i,length:1,notes:[{note:0,string:1,fret:f,pitch:64+f,velocity:95}]}))});
  }
  displayResult({id:null,formats:[],warnings:[],export_warnings:{},score:{title:'Guitar demo – 4 ô nhịp',tempo:100,artist:'',total_notes:16,total_measures:4,tracks:[{index:0,name:'Guitar Demo',strings:6,tuning:{1:64,2:59,3:55,4:50,5:45,6:40},measures:bars,duration_quarters:16}]}});
  switchTab('tabScore');
}
async function checkServer() {
  try{
    const r=await fetch('/api/health');const data=await r.json();
    const el=$('engineStatus');
    if(data.engine&&data.guitarpro){
      el.textContent=data.ocr?'● Sẵn sàng đọc PDF và ảnh':'● PDF sẵn sàng · OCR ảnh chưa cài';el.className='server-state ok';
    }else{el.textContent='● Chưa cài bộ nhận diện, xem hướng dẫn';el.className='server-state bad';}
  }catch(e){const el=$('engineStatus');el.textContent='● Mất kết nối máy chủ cục bộ';el.className='server-state bad';}
}

$('dropzone').addEventListener('click',()=> $('fileInput').click());
$('dropzone').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('fileInput').click();}});
$('fileInput').addEventListener('change',e=>loadFile(e.target.files?.[0]));
for(const evt of ['dragenter','dragover'])$('dropzone').addEventListener(evt,e=>{e.preventDefault();$('dropzone').classList.add('drag')});
for(const evt of ['dragleave','drop'])$('dropzone').addEventListener(evt,e=>{e.preventDefault();$('dropzone').classList.remove('drag')});
$('dropzone').addEventListener('drop',e=>loadFile(e.dataTransfer.files?.[0]));
$('clearFile').addEventListener('click',()=>{state.file=null;$('fileInput').value='';$('selectedFile').classList.add('hidden');$('convertBtn').disabled=true;resetScore();stopPlayer();if(state.blobURL)URL.revokeObjectURL(state.blobURL);$('emptySource').classList.remove('hidden');$('pdfViewer').classList.add('hidden');$('imgViewer').classList.add('hidden');});
$('convertBtn').addEventListener('click',convert);
$('demoBtn').addEventListener('click',loadDemo);
$('navPreview').addEventListener('click',()=>switchTab('tabScore'));
for(const b of document.querySelectorAll('.tab'))b.addEventListener('click',()=>switchTab(b.dataset.tab));
$('trackPicker').addEventListener('change',e=>{state.track=Number(e.target.value)||0;renderTrack()});
$('tabNotation').addEventListener('click',e=>{const b=e.target.closest('button.fret-note');if(b)openEdit(b)});
$('playBtn').addEventListener('click',playPlayer);
$('stopBtn').addEventListener('click',()=>stopPlayer(false));
$('prevBtn').addEventListener('click',()=>seekQuarter(0));
$('positionSlider').addEventListener('input',e=>{if(state.maxQ)seekQuarter(Number(e.target.value)/1000*state.maxQ)});
$('playBpm').addEventListener('change',()=>{if(state.isPlaying){const current=currentQuarter();pausePlayer();state.positionQ=current;playPlayer();}else syncTime()});
$('speedSelect').addEventListener('change',()=>{if(state.isPlaying){const current=currentQuarter();pausePlayer();state.positionQ=current;playPlayer();}else syncTime()});
for(const fmt of ['gp5','gp4','gp3'])$(fmt+'Btn').addEventListener('click',()=>triggerDownload(fmt));
$('downloadAllBtn').addEventListener('click',()=>triggerDownload('zip'));
$('editForm').addEventListener('submit',saveEdit);
$('cancelEdit').addEventListener('click',()=>$('editDialog').close());
checkServer();
