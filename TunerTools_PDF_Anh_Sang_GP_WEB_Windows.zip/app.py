"""TunerTools PDF/IMG -> GP Web (local-only).

Recognition is delegated to F100Pilot PDF-to-GP5 (MIT); writing GP3/4/5 uses
PyGuitarPro (LGPL-3.0). No proprietary EZMusic model is bundled or called.
"""
from __future__ import annotations

import io
import json
import logging
import re
import tempfile
import time
import uuid
import zipfile
from pathlib import Path
from threading import RLock
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

ROOT = Path(__file__).resolve().parent
DATA_LIMIT = 35 * 1024 * 1024
ALLOWED_EXT = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".gp3", ".gp4", ".gp5"}
EXPORTS = ("gp3", "gp4", "gp5")
app = FastAPI(title="TunerTools PDF/IMG to Guitar Pro", version="0.1.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
STORE: dict[str, dict[str, Any]] = {}
STORE_LOCK = RLock()
LOG = logging.getLogger("tunertools_gp_web")


class EditRequest(BaseModel):
    track: int = Field(ge=0)
    measure: int = Field(ge=0)
    voice: int = Field(ge=0)
    beat: int = Field(ge=0)
    note: int = Field(ge=0)
    fret: int = Field(ge=0, le=36)
    string: int | None = Field(default=None, ge=1, le=8)


def safe_stem(value: str) -> str:
    text = re.sub(r"[^\w\- ]+", "_", Path(value).stem, flags=re.UNICODE).strip(" _-")
    return text[:80] or "ban_nhac"


def get_job(job_id: str) -> dict[str, Any]:
    with STORE_LOCK:
        job = STORE.get(job_id)
    if job is None:
        raise HTTPException(404, "Không tìm thấy phiên làm việc. Hãy chọn lại file.")
    return job


def cleanup_store() -> None:
    now = time.time()
    with STORE_LOCK:
        for key in list(STORE):
            if now - STORE[key]["created"] > 3600:
                del STORE[key]
        while len(STORE) > 15:
            first = min(STORE, key=lambda k: STORE[k]["created"])
            del STORE[first]


def import_guitarpro():
    try:
        import guitarpro
    except ImportError as exc:
        raise RuntimeError("Chưa cài PyGuitarPro. Chạy lại CHAY_WEB.bat để cài thư viện.") from exc
    return guitarpro


def load_song(data: bytes):
    return import_guitarpro().parse(io.BytesIO(data))


def write_song(song: Any, fmt: str) -> bytes:
    gp = import_guitarpro()
    with tempfile.TemporaryDirectory(prefix="ttgp_") as tmp:
        filename = Path(tmp) / f"output.{fmt}"
        gp.write(song, str(filename))
        value = filename.read_bytes()
        if len(value) < 50:
            raise RuntimeError(f"Kết quả .{fmt} quá nhỏ, từ chối xuất")
        gp.parse(io.BytesIO(value))  # ensure it opens, not just a renamed extension
        return value


def signature(song: Any) -> tuple[tuple[int, int, int, int, int, int, int], ...]:
    items = []
    for it, track in enumerate(song.tracks):
        for im, measure in enumerate(track.measures):
            for iv, voice in enumerate(measure.voices):
                for ib, beat in enumerate(voice.beats):
                    for note in beat.notes:
                        items.append((it, im, iv, ib, int(note.string), int(note.value), int(getattr(note, 'velocity', 95))))
    return tuple(items)


def rhythm_signature(song: Any) -> tuple:
    """Check number of bars/voices, time signature, and rhythmic beat patterns."""
    track_sigs = []
    for track in song.tracks:
        bars = []
        for measure in track.measures:
            header = getattr(measure, "header", None)
            ts = getattr(header, "timeSignature", None)
            top = int(getattr(ts, "numerator", 4) or 4)
            bottom = int(getattr(getattr(ts, "denominator", None), "value", 4) or 4)
            voices = []
            for voice in measure.voices:
                durations = []
                for beat in voice.beats:
                    d = getattr(beat, "duration", None)
                    t = getattr(d, "tuplet", None)
                    durations.append((int(getattr(d, "value", 4) or 4),
                                      bool(getattr(d, "isDotted", False)),
                                      bool(getattr(d, "isDoubleDotted", False)),
                                      int(getattr(t, "enters", 1) or 1),
                                      int(getattr(t, "times", 1) or 1)))
                voices.append(tuple(durations))
            bars.append((top, bottom, tuple(voices)))
        track_sigs.append(tuple(bars))
    return tuple(track_sigs)


def build_exports(gp5: bytes) -> tuple[dict[str, bytes], dict[str, str]]:
    song = load_song(gp5)
    baseline = signature(song)
    baseline_rhythm = rhythm_signature(song)
    results = {"gp5": gp5}
    warnings: dict[str, str] = {}
    for fmt in ("gp4", "gp3"):
        try:
            data = write_song(song, fmt)
            actual = signature(load_song(data))
            if tuple((x[:6] for x in actual)) != tuple((x[:6] for x in baseline)):
                warnings[fmt] = "Dây/ngăn hoặc số nốt khác GP5. Cần xem lại trước khi dùng."
                continue  # don't offer mismatched output as correct
            if rhythm_signature(load_song(data)) != baseline_rhythm:
                warnings[fmt] = "Ô nhịp hoặc trường độ khác GP5. Không cho xuất để tránh sai nhạc."
                continue
            results[fmt] = data
        except Exception as exc:
            LOG.exception("Export %s failed", fmt)
            warnings[fmt] = str(exc)
    return results, warnings


def extract_score(gp5: bytes) -> dict[str, Any]:
    song = load_song(gp5)
    tempo = int(getattr(song, "tempo", 120) or 120)
    tracks: list[dict[str, Any]] = []
    note_total = 0
    for it, track in enumerate(song.tracks):
        strings = list(getattr(track, "strings", []))
        tuning = {int(s.number): int(s.value) for s in strings}
        if not tuning:
            tuning = {1: 64, 2: 59, 3: 55, 4: 50, 5: 45, 6: 40}
        strings_count = len(tuning)
        measures = []
        total_quarters = 0.0
        for im, measure in enumerate(track.measures):
            header = getattr(measure, "header", None)
            timesig = getattr(header, "timeSignature", None)
            numerator = int(getattr(timesig, "numerator", 4) or 4)
            denominator = getattr(getattr(timesig, "denominator", None), "value", 4)
            denominator = int(denominator or 4)
            measure_quarters = float(numerator * 4 / denominator)
            beats = []
            for iv, voice in enumerate(measure.voices):
                position = 0.0
                for ib, beat in enumerate(voice.beats):
                    dur = getattr(beat, "duration", None)
                    val = int(getattr(dur, "value", 4) or 4)
                    length = 4.0 / max(1, val)
                    if bool(getattr(dur, "isDotted", False)):
                        length *= 1.5
                    if bool(getattr(dur, "isDoubleDotted", False)):
                        length *= 1.75
                    tuplet = getattr(dur, "tuplet", None)
                    enters, times = int(getattr(tuplet, "enters", 1) or 1), int(getattr(tuplet, "times", 1) or 1)
                    length = length * times / enters
                    notes = []
                    for i, note in enumerate(beat.notes):
                        string = int(note.string)
                        fret = int(note.value)
                        pitch = tuning.get(string, 40) + fret
                        notes.append({"note": i, "string": string, "fret": fret, "pitch": pitch,
                                      "velocity": int(getattr(note, "velocity", 95))})
                    note_total += len(notes)
                    beats.append({"voice": iv, "beat": ib, "position": round(position, 5),
                                  "length": round(length, 5), "notes": notes})
                    position += length
            measures.append({"index": im, "number": im + 1, "start": round(total_quarters, 5),
                             "length": round(measure_quarters, 5), "time": f"{numerator}/{denominator}",
                             "beats": beats})
            total_quarters += measure_quarters
        tracks.append({"index": it, "name": str(getattr(track, "name", "Guitar") or "Guitar"),
                       "strings": strings_count, "tuning": tuning, "measures": measures,
                       "duration_quarters": round(total_quarters, 5)})
    return {"title": str(getattr(song, "title", "") or "Bản nhạc"),
            "artist": str(getattr(song, "artist", "") or ""), "tempo": tempo,
            "tracks": tracks, "total_notes": note_total,
            "total_measures": max((len(t["measures"]) for t in tracks), default=0)}


def recognize(data: bytes, *, filename: str, bpm: int | None) -> tuple[bytes, dict]:
    try:
        from pdf_to_gp5 import i18n
        from pdf_to_gp5.converter import ConversionOptions, TrackOptions
        from pdf_to_gp5.sandbox import run_isolated
    except ImportError as exc:
        raise RuntimeError("Chưa cài bộ nhận diện PDF-to-GP5. Chạy CHAY_WEB.bat để cài đặt.") from exc
    i18n.use("en")
    options = ConversionOptions(
        title="",  # let the converter read the song title from the source PDF
        tempo=bpm,
        tracks=(TrackOptions(filename=filename, name="Guitar"),),
        max_pages=40,
        max_image_pages=15,
    )
    result = run_isolated([data], options, timeout_s=240, total_s=600, memory_mb=2048)
    if not result.gp5:
        raise RuntimeError("Bộ nhận diện không tạo ra dữ liệu GP5.")
    return result.gp5, result.report


def conversion_pipeline(data: bytes, filename: str, bpm: int | None) -> dict:
    ext = Path(filename).suffix.lower()
    if ext.startswith(".gp") and ext in {".gp3", ".gp4", ".gp5"}:
        song = load_song(data)
        gp5 = data if ext == ".gp5" else write_song(song, "gp5")
        report: dict[str, Any] = {"mode": "existing_gp", "warnings": []}
    else:
        gp5, report = recognize(data, filename=filename, bpm=bpm)
    files, export_warnings = build_exports(gp5)
    return {"gp5": gp5, "files": files, "score": extract_score(gp5),
            "report": report, "export_warnings": export_warnings}


def as_public(job_id: str, job: dict) -> dict:
    report = job.get("report") or {}
    warnings = report.get("warnings", []) if isinstance(report, dict) else []
    if not isinstance(warnings, list):
        warnings = [str(warnings)]
    return {"id": job_id, "name": job["name"], "score": job["score"],
            "formats": list(job["files"]), "warnings": [str(w) for w in warnings][:30],
            "export_warnings": job["export_warnings"],
            "verification": "Cần đối chiếu lại từng ô nhịp với PDF/ảnh gốc; OCR chưa bảo đảm chính xác."}


@app.get("/")
async def root():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/api/health")
async def health():
    try:
        import guitarpro
        gp = True
    except ImportError:
        gp = False
    try:
        import pdf_to_gp5
        engine = True
    except ImportError:
        engine = False
    try:
        import rapidocr_onnxruntime
        ocr = True
    except ImportError:
        ocr = False
    return {"ok": True, "engine": engine, "guitarpro": gp, "ocr": ocr,
            "local_only": True, "version": "0.1.0"}


@app.post("/api/convert")
async def convert(file: UploadFile = File(...), bpm: int | None = Form(None)):
    filename = Path(file.filename or "unknown").name
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(415, "Chỉ hỗ trợ PDF, PNG/JPG/WebP, GP3, GP4, GP5.")
    if bpm is not None and (bpm < 30 or bpm > 300):
        raise HTTPException(422, "BPM phải trong khoảng 30–300")
    data = await file.read(DATA_LIMIT + 1)
    await file.close()
    if len(data) == 0 or len(data) > DATA_LIMIT:
        raise HTTPException(413, "File rỗng hoặc lớn hơn 35 MB.")
    try:
        job = await run_in_threadpool(conversion_pipeline, data, filename, bpm)
    except Exception as exc:
        LOG.exception("Conversion error")
        raise HTTPException(422, f"Không chuyển được file: {str(exc)[:400]}") from exc
    job_id = str(uuid.uuid4())
    job.update({"created": time.time(), "name": safe_stem(filename)})
    cleanup_store()
    with STORE_LOCK:
        STORE[job_id] = job
    return as_public(job_id, job)


@app.get("/api/download/{job_id}/{fmt}")
async def download(job_id: str, fmt: str):
    job = get_job(job_id)
    fmt = fmt.lower()
    data = job["files"].get(fmt)
    if data is None:
        raise HTTPException(404, f"Chưa có bản {fmt.upper()} được kiểm tra hợp lệ.")
    filename = f"{job['name']}.{fmt}"
    return Response(data, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"',
                             "Cache-Control": "no-store"})


@app.get("/api/download-all/{job_id}")
async def download_all(job_id: str):
    job = get_job(job_id)
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for ext, contents in job["files"].items():
            archive.writestr(f"{job['name']}.{ext}", contents)
        archive.writestr("README.txt", "Generated from user file by TunerTools PDF/IMG GP Web. Verify notes, rhythms and techniques against original before use.\n")
    filename = f"{job['name']}_GP.zip"
    return Response(bio.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/api/edit/{job_id}")
async def edit(job_id: str, payload: EditRequest):
    job = get_job(job_id)
    def update():
        gp5 = job["gp5"]
        song = load_song(gp5)
        try:
            target = song.tracks[payload.track].measures[payload.measure].voices[payload.voice].beats[payload.beat].notes[payload.note]
        except IndexError as exc:
            raise ValueError("Nốt nhạc không tồn tại") from exc
        target.value = payload.fret
        if payload.string is not None:
            track = song.tracks[payload.track]
            valid_strings = {int(s.number) for s in track.strings}
            if payload.string not in valid_strings:
                raise ValueError("Số dây không thuộc track này")
            beat_obj = track.measures[payload.measure].voices[payload.voice].beats[payload.beat]
            if any(n is not target and int(n.string) == payload.string for n in beat_obj.notes):
                raise ValueError("Phách này đã có nốt trên dây được chọn")
            target.string = payload.string
        new_gp5 = write_song(song, "gp5")
        files, warnings = build_exports(new_gp5)
        return new_gp5, files, warnings, extract_score(new_gp5)
    try:
        new_gp5, files, warnings, score = await run_in_threadpool(update)
    except Exception as exc:
        raise HTTPException(422, f"Không sửa được nốt: {exc}") from exc
    with STORE_LOCK:
        job.update(gp5=new_gp5, files=files, export_warnings=warnings, score=score)
    return as_public(job_id, job)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8021, workers=1)
