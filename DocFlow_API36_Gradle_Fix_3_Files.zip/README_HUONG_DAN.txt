DocFlow Offline - Cap nhat Android SDK 36 (2026-10-22)

DA KIEM TRA:
- File app/build.gradle.kts nguoi dung gui dat compileSdk=36, targetSdk=36; cu phap hop le.
- File settings.gradle.kts nguoi dung gui KHONG CAN SUA.
- File build.gradle.kts o thu muc goc va gradle/wrapper/gradle-wrapper.properties KHONG duoc gui trong lan nay. Hai file de xuat trong goi dua tren cau truc DocFlowOffline v0.6 da cung cap truoc do. Hay kiem tra file goc hien tai truoc khi ghi de, neu co plugins thu ba thi giu lai.

CAU HINH DE XUAT:
- Android Gradle Plugin (AGP) 8.10.1
- Kotlin Android & Kotlin Compose plugin 2.2.20
- Gradle Wrapper 8.13
- compileSdk 36, targetSdk 36, minSdk 26
- JDK 17
- Cai Android 16 API 36 trong Android Studio > SDK Manager > SDK Platforms.

DANH SACH FILE:
1. app/build.gradle.kts - lay tu file user gui, GIU NGUYEN applicationId=ducphi.docflow, versionCode=1, versionName=0.0.0; chi bo ghi chu SDK35 da cu.
2. build.gradle.kts (thu muc goc) - nang AGP/Kotlin. DOI CHIEU voi file goc hien tai truoc khi thay.
3. gradle/wrapper/gradle-wrapper.properties - doi wrapper thanh Gradle 8.13.
4. settings.gradle.kts - KHONG SUA.

THAO TAC:
1. Sao luu cac file Gradle cua du an.
2. Thay/doi chieu 3 file theo duong dan trong ZIP.
3. Android Studio > Settings > Build Tools > Gradle > Gradle JDK: JDK 17.
4. Tools > SDK Manager > SDK Platforms > Android 16 (API 36): cai neu chua co.
5. File > Sync Project with Gradle Files, sau do Build > Rebuild Project.
6. Neu build that bai, doc dong loi dau tien trong Build Output, khong chi nhin gach do o editor.

LUU Y QUAN TRONG:
- applicationId va versionCode/versionName trong file app do user gui van duoc GIU NGUYEN. Neu app da phat hanh tren Google Play, can dam bao applicationId khop app dang phat hanh va versionCode moi lon hon versionCode da dang.
- targetSdk 36 co the thay doi hanh vi runtime (giao dien edge-to-edge...) tren Android 16; build thanh cong KHONG dong nghia hoat dong da tuong thich hoan toan.
- Chua kiem thu build APK/Android Studio trong moi truong nay vi khong co Android SDK va du an hien hanh day du.

Tai lieu chinh thuc:
https://developer.android.com/build/releases/about-agp
https://developer.android.com/build/releases/agp-8-10-0-release-notes
https://kotlinlang.org/docs/gradle-configure-project.html
