package duc_phi.music

import android.content.Context
import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.media.RingtoneManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun LibraryScreen(
    controller: MusicController,
    onScanLocal: () -> Unit,
    onAuthorizePersonalDrive: () -> Unit,
    onSettings: () -> Unit,
    onOpenPremium: () -> Unit
) {
    val colors = LocalMusicColors.current
    val songs = controller.filteredLibrarySongs()
    var actionSong by remember { mutableStateOf<SongItem?>(null) }
    var showInternetDialog by remember { mutableStateOf(false) }
    var selectedSmartTarget by remember { mutableStateOf<SmartPlaylistTarget?>(null) }
    // A folder tap opens a browsable track list instead of immediately starting playback.
    var selectedFolder by remember { mutableStateOf<Pair<String, List<SongItem>>?>(null) }
    var editingSmartPlaylist by remember { mutableStateOf<SmartPlaylistDraft?>(null) }
    var deletingSmartPlaylist by remember { mutableStateOf<SmartPlaylistDefinition?>(null) }
    var showDuplicateManager by remember { mutableStateOf(false) }
    var duplicateScanResult by remember { mutableStateOf<List<SmartDuplicateGroup>>(emptyList()) }
    var duplicateScanDone by remember { mutableStateOf(false) }
    var duplicateScanBusy by remember { mutableStateOf(false) }
    val smartScope = rememberCoroutineScope()
    val smartPremiumLocked = MeloWarePremiumAccess.smartPlaylistRequiresPremium
    val drivePremiumLocked = MeloWarePremiumAccess.googleDriveRequiresPremium

    LaunchedEffect(drivePremiumLocked, controller.librarySource) {
        if (drivePremiumLocked && controller.librarySource in setOf(
                LibrarySource.PERSONAL_DRIVE,
                LibrarySource.PUBLIC_DRIVE
            )
        ) {
            controller.librarySource = LibrarySource.ALL
            controller.showPublicDriveDialog = false
        }
    }

    LaunchedEffect(controller.localSongs.size) {
        duplicateScanResult = emptyList()
        duplicateScanDone = false
        duplicateScanBusy = false
        showDuplicateManager = false
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            PlayerBottomArea(
                controller = controller,
                selectedScreen = MusicScreen.LIBRARY
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(colors.background, colors.backgroundSoft, colors.background)
                    )
                )
                .padding(padding)
                // Safe area for screen cutouts, punch-hole cameras and visible system bars.
                // Use safeDrawing once (instead of stacking statusBarsPadding) to avoid double top inset.
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top)),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                LibraryHeader(onSettings)
            }

            // The search bar stays immediately under the Library heading, before the
            // Songs / Albums / Artists tabs and before the source cards.
            item {
                LibrarySearch(
                    value = controller.libraryQuery,
                    onValueChange = { controller.libraryQuery = it }
                )
            }

            item {
                LibraryTabs(
                    selected = controller.libraryTab,
                    onSelected = { controller.libraryTab = it }
                )
            }

            item {
                SourceOverview(
                    controller = controller,
                    drivePremiumLocked = drivePremiumLocked,
                    onScanLocal = onScanLocal,
                    onAuthorizePersonalDrive = onAuthorizePersonalDrive,
                    onOpenPremium = onOpenPremium
                )
            }

            item {
                SourceFilterChips(
                    controller = controller,
                    drivePremiumLocked = drivePremiumLocked,
                    onOpenPremium = onOpenPremium
                )
            }

            // This is the only Picker entry point when Drive already has saved songs.
            // Tapping the Google Drive source card above never asks for OAuth again.
            if (controller.librarySource == LibrarySource.PERSONAL_DRIVE &&
                controller.personalDriveSongs.isNotEmpty() &&
                controller.libraryTab == LibraryTab.SONGS
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onAuthorizePersonalDrive,
                            enabled = !controller.personalDriveBusy
                        ) {
                            Icon(
                                Icons.Rounded.PlaylistAdd,
                                contentDescription = null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(mwString("library.add_from_drive", "Thêm nhạc từ Drive"), color = colors.purpleBright)
                        }
                    }
                }
            }

            if (controller.librarySource == LibrarySource.PERSONAL_DRIVE &&
                (controller.personalDriveBusy || controller.personalDriveError != null)
            ) {
                item {
                    PersonalDrivePickerStatus(
                        busy = controller.personalDriveBusy,
                        error = controller.personalDriveError,
                        onOpenPicker = onAuthorizePersonalDrive
                    )
                }
            }

            if (controller.librarySource == LibrarySource.INTERNET) {
                item {
                    Surface(color = colors.backgroundSoft, shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, colors.border)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Wifi, contentDescription = null,
                                tint = if (controller.internetSession.dataChannelOpen) colors.green else colors.textMuted)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(mwString("library.internet_folder", "Thư mục MeloWare Internet"), color = colors.textPrimary,
                                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(if (controller.internetSession.dataChannelOpen)
                                    mwString("library.internet_connected", "Đã kết nối · nghe trực tiếp từ máy A · không cần tải về")
                                else mwString("library.internet_disconnected", "Chưa kết nối với máy A"),
                                    color = colors.textSecondary, fontSize = 11.sp)
                            }
                            TextButton(onClick = { showInternetDialog = true }) {
                                Text(mwString("library.manage", "Quản lý"), color = colors.purpleBright, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            when (controller.libraryTab) {
                LibraryTab.SONGS -> {
                    if (songs.isEmpty()) {
                        item {
                            val isDrive = controller.librarySource == LibrarySource.PERSONAL_DRIVE
                            EmptyLibraryState(
                                title = if (isDrive) mwString("library.no_drive_music", "Chưa có nhạc từ Google Drive") else mwString("library.no_matching_songs", "Không có bài hát phù hợp"),
                                description = if (isDrive) {
                                    mwString("library.picker_instruction", "Mở Google Picker và chọn các file hoặc thư mục âm thanh bạn muốn chia sẻ với MeloWare.")
                                } else {
                                    mwString("library.scan_instruction", "Hãy quét nhạc trên máy hoặc thêm một nguồn Google Drive.")
                                },
                                buttonText = if (isDrive) mwString("library.open_picker", "Mở Google Picker") else mwString("home.scan_local", "Quét nhạc trên máy"),
                                onButton = if (isDrive) onAuthorizePersonalDrive else onScanLocal
                            )
                        }
                    } else {
                        items(songs, key = { it.id }) { song ->
                            LaunchedEffect(song.id) { controller.ensureArtwork(song) }
                            SongRow(
                                song = song,
                                artworkUrl = controller.artworkFor(song),
                                isCurrent = controller.currentSong?.id == song.id,
                                isFavorite = controller.isFavorite(song),
                                onClick = { controller.playSong(song, songs) },
                                onFavorite = { controller.toggleFavorite(song) },
                                onMore = if (controller.canUseLocalAudioTools(song)) {
                                    { actionSong = song }
                                } else null
                            )
                        }
                    }
                }

                LibraryTab.ALBUMS -> {
                    val groups = controller.groupedAlbums().toList()
                    if (groups.isEmpty()) item { EmptyGroupState(mwString("library.no_albums", "Chưa có album")) }
                    else items(groups, key = { it.first }) { (name, albumSongs) ->
                        GroupCard(
                            icon = Icons.Rounded.Album,
                            title = name,
                            subtitle = mwString("library.count_songs", "{count} bài hát", "count" to albumSongs.size),
                            artworkSong = albumSongs.firstOrNull(),
                            artworkUrl = albumSongs.firstOrNull()?.let(controller::artworkFor),
                            onClick = { controller.playCollection(albumSongs, 0) }
                        )
                    }
                }

                LibraryTab.ARTISTS -> {
                    val groups = controller.groupedArtists().toList()
                    if (groups.isEmpty()) item { EmptyGroupState(mwString("library.no_artists", "Chưa có nghệ sĩ")) }
                    else items(groups, key = { it.first }) { (name, artistSongs) ->
                        GroupCard(
                            icon = Icons.Rounded.Person,
                            title = mwArtistLabel(name),
                            subtitle = mwString("library.count_songs", "{count} bài hát", "count" to artistSongs.size),
                            artworkSong = artistSongs.firstOrNull(),
                            artworkUrl = artistSongs.firstOrNull()?.let(controller::artworkFor),
                            onClick = { controller.playCollection(artistSongs, 0) }
                        )
                    }
                }

                LibraryTab.FOLDERS -> {
                    val groups = controller.groupedFolders().toList()
                    if (groups.isEmpty()) item { EmptyGroupState(mwString("library.no_folders", "Chưa có thư mục")) }
                    else items(groups, key = { it.first }) { (name, folderSongs) ->
                        GroupCard(
                            icon = Icons.Rounded.Folder,
                            title = name,
                            subtitle = mwString("library.count_media", "{count} tệp phương tiện", "count" to folderSongs.size),
                            artworkSong = folderSongs.firstOrNull(),
                            artworkUrl = folderSongs.firstOrNull()?.let(controller::artworkFor),
                            onClick = { selectedFolder = name to folderSongs }
                        )
                    }
                }

                LibraryTab.PLAYLISTS -> {
                    item {
                        SmartPlaylistProSection(
                            controller = controller,
                            premiumLocked = smartPremiumLocked,
                            onOpenPremium = onOpenPremium,
                            onOpenBuiltIn = { type -> selectedSmartTarget = SmartPlaylistTarget.BuiltIn(type) },
                            onOpenCustom = { definition -> selectedSmartTarget = SmartPlaylistTarget.Custom(definition) },
                            onCreateCustom = { editingSmartPlaylist = SmartPlaylistDraft() },
                            onEditCustom = { definition -> editingSmartPlaylist = definition.toDraft() },
                            onDeleteCustom = { definition -> deletingSmartPlaylist = definition },
                            duplicateGroups = duplicateScanResult,
                            duplicateScanDone = duplicateScanDone,
                            duplicateScanBusy = duplicateScanBusy,
                            onOpenDuplicates = {
                                if (duplicateScanDone) {
                                    showDuplicateManager = true
                                } else if (!duplicateScanBusy) {
                                    duplicateScanBusy = true
                                    val expectedSongCount = controller.localSongs.size
                                    smartScope.launch {
                                        val scanResult = runCatching {
                                            withContext(Dispatchers.Default) {
                                                controller.smartDuplicateGroups()
                                            }
                                        }.getOrDefault(emptyList())
                                        duplicateScanBusy = false
                                        if (controller.localSongs.size == expectedSongCount) {
                                            duplicateScanResult = scanResult
                                            duplicateScanDone = true
                                            showDuplicateManager = true
                                        }
                                    }
                                }
                            }
                        )
                    }
                    item {
                        PlaylistSummaryCard(
                            title = mwString("library.queue", "Danh sách đang phát"),
                            subtitle = mwString("library.count_songs", "{count} bài hát", "count" to controller.queue.size),
                            icon = Icons.Rounded.PlaylistPlay,
                            onClick = {
                                if (controller.queue.isNotEmpty()) {
                                    controller.playQueueIndex(controller.currentIndex.coerceAtLeast(0))
                                }
                            }
                        )
                    }
                    item {
                        PlaylistSummaryCard(
                            title = mwString("library.favorite_songs", "Bài hát yêu thích"),
                            subtitle = mwString("library.count_songs", "{count} bài hát", "count" to controller.sourceCount(LibrarySource.FAVORITES)),
                            icon = Icons.Rounded.Favorite,
                            onClick = {
                                controller.librarySource = LibrarySource.FAVORITES
                                controller.libraryTab = LibraryTab.SONGS
                            }
                        )
                    }
                    item {
                        PlaylistSummaryCard(
                            title = mwString("library.downloaded_offline", "Đã tải để nghe Offline"),
                            subtitle = mwString("library.count_songs", "{count} bài hát", "count" to controller.sourceCount(LibrarySource.DOWNLOADED)),
                            icon = Icons.Rounded.Download,
                            onClick = {
                                controller.librarySource = LibrarySource.DOWNLOADED
                                controller.libraryTab = LibraryTab.SONGS
                            }
                        )
                    }
                }
            }
        }
    }

    if (showInternetDialog) {
        MeloWareInternetDialog(controller = controller, onDismiss = { showInternetDialog = false })
    }

    if (controller.showPublicDriveDialog) {
        PublicDriveDialog(
            controller = controller,
            onDismiss = { controller.showPublicDriveDialog = false }
        )
    }

    actionSong?.let { selectedSong ->
        SongToolsHost(
            controller = controller,
            song = selectedSong,
            onDismiss = { actionSong = null }
        )
    }

    selectedFolder?.let { (folderName, folderSongs) ->
        SmartPlaylistSongsDialog(
            controller = controller,
            title = folderName,
            songs = folderSongs,
            onDismiss = { selectedFolder = null },
            onMore = { song ->
                selectedFolder = null
                actionSong = song
            },
            folderMode = true
        )
    }

    selectedSmartTarget?.let { target ->
        val title = when (target) {
            is SmartPlaylistTarget.BuiltIn -> smartBuiltInTitle(target.type)
            is SmartPlaylistTarget.Custom -> target.definition.playlist.name
        }
        val smartSongs = when (target) {
            is SmartPlaylistTarget.BuiltIn -> controller.builtInSmartPlaylistSongs(target.type)
            is SmartPlaylistTarget.Custom -> controller.customSmartPlaylistSongs(target.definition)
        }
        SmartPlaylistSongsDialog(
            controller = controller,
            title = title,
            songs = smartSongs,
            onDismiss = { selectedSmartTarget = null },
            onMore = { song ->
                selectedSmartTarget = null
                actionSong = song
            }
        )
    }

    editingSmartPlaylist?.let { draft ->
        SmartPlaylistEditorDialog(
            initial = draft,
            onDismiss = { editingSmartPlaylist = null },
            onSave = { savedDraft ->
                controller.saveSmartPlaylist(savedDraft)
                editingSmartPlaylist = null
            }
        )
    }

    deletingSmartPlaylist?.let { definition ->
        SmartPlaylistDeleteDialog(
            name = definition.playlist.name,
            onDismiss = { deletingSmartPlaylist = null },
            onConfirm = {
                controller.deleteSmartPlaylist(definition.playlist.id)
                deletingSmartPlaylist = null
            }
        )
    }

    if (showDuplicateManager) {
        SmartDuplicateManagerDialog(
            controller = controller,
            groups = duplicateScanResult,
            onDismiss = { showDuplicateManager = false },
            onMore = { song ->
                showDuplicateManager = false
                actionSong = song
            }
        )
    }
}

@Composable
private fun LibraryHeader(onSettings: () -> Unit) {
    val colors = LocalMusicColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = mwString("nav.library", "Thư viện"),
                color = colors.textPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = mwString("library.subtitle", "Tất cả nhạc của bạn, một nơi"),
                color = colors.textSecondary,
                fontSize = 15.sp
            )
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Rounded.Settings, contentDescription = mwString("settings.title", "Cài đặt"), tint = colors.textPrimary)
        }
    }
}

@Composable
private fun LibraryTabs(
    selected: LibraryTab,
    onSelected: (LibraryTab) -> Unit
) {
    val tabs = listOf(
        LibraryTab.SONGS to (mwString("library.tabs.songs", "Bài hát") to Icons.Rounded.MusicNote),
        LibraryTab.ALBUMS to (mwString("library.tabs.albums", "Album") to Icons.Rounded.Album),
        LibraryTab.ARTISTS to (mwString("library.tabs.artists", "Nghệ sĩ") to Icons.Rounded.Person),
        LibraryTab.FOLDERS to (mwString("library.tabs.folders", "Thư mục") to Icons.Rounded.Folder),
        LibraryTab.PLAYLISTS to (mwString("library.tabs.playlists", "Playlist") to Icons.Rounded.PlaylistPlay)
    )
    val colors = LocalMusicColors.current
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(tabs, key = { it.first.name }) { (tab, data) ->
            val isSelected = selected == tab
            Surface(
                modifier = Modifier.clickable { onSelected(tab) },
                shape = RoundedCornerShape(14.dp),
                color = if (isSelected) colors.purple else colors.cardRaised,
                border = BorderStroke(1.dp, if (isSelected) colors.purpleBright else colors.border)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        data.second,
                        contentDescription = null,
                        tint = if (isSelected) Color.White else colors.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        data.first,
                        color = if (isSelected) Color.White else colors.textSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun SourceOverview(
    controller: MusicController,
    drivePremiumLocked: Boolean,
    onScanLocal: () -> Unit,
    onAuthorizePersonalDrive: () -> Unit,
    onOpenPremium: () -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(end = 8.dp)
    ) {
        item {
            LibrarySourceCard(
                title = mwString("library.local_music", "Nhạc trên máy"),
                count = controller.sourceCount(LibrarySource.LOCAL),
                icon = Icons.Rounded.Smartphone,
                gradient = listOf(Color(0xFF0A4E7A), Color(0xFF052B4A)),
                onClick = {
                    onScanLocal()
                    controller.librarySource = LibrarySource.LOCAL
                    controller.libraryTab = LibraryTab.SONGS
                }
            )
        }
        item {
            LibrarySourceCard(
                title = "Google Drive",
                count = controller.sourceCount(LibrarySource.PERSONAL_DRIVE),
                icon = Icons.Rounded.Cloud,
                gradient = listOf(Color(0xFF4B176E), Color(0xFF28113F)),
                locked = drivePremiumLocked,
                onClick = {
                    if (drivePremiumLocked) {
                        onOpenPremium()
                    } else {
                        // Show existing Google Drive tracks immediately. OAuth/Picker is
                        // launched ONLY from an explicit Add music action below.
                        controller.librarySource = LibrarySource.PERSONAL_DRIVE
                        controller.libraryTab = LibraryTab.SONGS
                        controller.libraryQuery = "" // Clear stale search so saved songs are visible.
                    }
                }
            )
        }
        item {
            LibrarySourceCard(
                title = mwString("home.drive_link", "Link Drive"),
                count = controller.sourceCount(LibrarySource.PUBLIC_DRIVE),
                icon = Icons.Rounded.Link,
                gradient = listOf(Color(0xFF72183E), Color(0xFF361127)),
                locked = drivePremiumLocked,
                onClick = {
                    if (drivePremiumLocked) {
                        onOpenPremium()
                    } else {
                        controller.showPublicDriveDialog = true
                        controller.librarySource = LibrarySource.PUBLIC_DRIVE
                    }
                }
            )
        }
        item {
            LibrarySourceCard(
                title = "MeloWare Internet",
                count = controller.sourceCount(LibrarySource.INTERNET),
                icon = Icons.Rounded.Wifi,
                gradient = listOf(Color(0xFF0C6774), Color(0xFF102A48)),
                onClick = {
                    controller.librarySource = LibrarySource.INTERNET
                    controller.libraryTab = LibraryTab.FOLDERS
                    controller.libraryQuery = ""
                }
            )
        }
        item {
            LibrarySourceCard(
                title = mwString("library.downloaded_source", "Đã tải Offline"),
                count = controller.sourceCount(LibrarySource.DOWNLOADED),
                icon = Icons.Rounded.Download,
                gradient = listOf(Color(0xFF087A57), Color(0xFF06402F)),
                onClick = {
                    controller.librarySource = LibrarySource.DOWNLOADED
                    controller.libraryTab = LibraryTab.SONGS
                }
            )
        }
    }
}

@Composable
private fun LibrarySourceCard(
    title: String,
    count: Int,
    icon: ImageVector,
    gradient: List<Color>,
    locked: Boolean = false,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    val tileGradient = if (colors.isDark) gradient else listOf(
        androidx.compose.ui.graphics.lerp(Color.White, gradient.first(), 0.12f),
        androidx.compose.ui.graphics.lerp(Color.White, gradient.last(), 0.05f)
    )
    Surface(
        modifier = Modifier
            .width(155.dp)
            .height(116.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, colors.border)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(tileGradient))
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (colors.isDark) Color.White else gradient.first(),
                    modifier = Modifier.size(32.dp)
                )
                if (locked) {
                    Surface(
                        modifier = Modifier.align(Alignment.TopEnd).size(24.dp),
                        shape = CircleShape,
                        color = Color(0xFF25152F),
                        border = BorderStroke(1.dp, Color(0xFFFFD54F))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.Lock,
                                contentDescription = mwString("premium.required", "Premium"),
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
            Column {
                Text(title,
                    color = if (colors.isDark) Color.White else colors.textPrimary,
                    fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(mwString("library.count_songs", "{count} bài hát", "count" to count),
                    color = if (colors.isDark) Color.White.copy(alpha = 0.72f) else colors.textSecondary,
                    fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun LibrarySearch(
    value: String,
    onValueChange: (String) -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(19.dp),
        color = colors.cardRaised,
        border = BorderStroke(1.dp, colors.border)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Search, contentDescription = null, tint = colors.textSecondary)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(color = colors.textPrimary, fontSize = 14.sp),
                singleLine = true,
                cursorBrush = SolidColor(colors.purpleBright),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (value.isBlank()) {
                            Text(
                                mwString("home.search_hint", "Tìm bài hát, ca sĩ, album, thể loại..."),
                                color = colors.textMuted,
                                fontSize = 14.sp
                            )
                        }
                        inner()
                    }
                }
            )
            Icon(Icons.Rounded.Mic, contentDescription = null, tint = colors.textSecondary)
        }
    }
}

@Composable
private fun PersonalDrivePickerStatus(
    busy: Boolean,
    error: String?,
    onOpenPicker: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (error == null) colors.cardRaised else colors.red.copy(alpha = 0.10f),
        border = BorderStroke(
            1.dp,
            if (error == null) colors.borderSoft else colors.red.copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (busy) {
                CircularProgressIndicator(
                    modifier = Modifier.size(21.dp),
                    strokeWidth = 2.dp,
                    color = colors.purpleBright
                )
            } else {
                Icon(Icons.Rounded.Cloud, contentDescription = null, tint = colors.red)
            }
            Text(
                text = if (busy) mwString("library.importing_drive", "Đang nhập nhạc đã chọn từ Google Drive...") else error.orEmpty(),
                color = if (error == null) colors.textSecondary else colors.red,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            if (!busy && error != null) {
                TextButton(onClick = onOpenPicker) {
                    Text(mwString("library.select_again", "Chọn lại"), color = colors.purpleBright)
                }
            }
        }
    }
}

@Composable
private fun SourceFilterChips(
    controller: MusicController,
    drivePremiumLocked: Boolean,
    onOpenPremium: () -> Unit
) {
    val sources = listOf(
        LibrarySource.ALL to mwString("library.all_count", "Tất cả ({count})", "count" to controller.sourceCount(LibrarySource.ALL)),
        LibrarySource.LOCAL to mwString("library.local_music", "Nhạc trên máy"),
        LibrarySource.PERSONAL_DRIVE to mwString("home.my_drive", "Drive của tôi"),
        LibrarySource.PUBLIC_DRIVE to mwString("library.shared_drive", "Drive chia sẻ"),
        LibrarySource.INTERNET to "Internet P2P",
        LibrarySource.FAVORITES to mwString("library.favorites", "Yêu thích"),
        LibrarySource.DOWNLOADED to mwString("library.downloaded_short", "Đã tải")
    )
    HorizontalChips(
        items = sources.map { (source, label) ->
            val lockedLabel = if (
                drivePremiumLocked && source in setOf(
                    LibrarySource.PERSONAL_DRIVE,
                    LibrarySource.PUBLIC_DRIVE
                )
            ) "$label  👑" else label
            lockedLabel to (controller.librarySource == source)
        },
        onClick = { index ->
            val source = sources[index].first
            if (drivePremiumLocked && source in setOf(
                    LibrarySource.PERSONAL_DRIVE,
                    LibrarySource.PUBLIC_DRIVE
                )
            ) {
                onOpenPremium()
            } else {
                controller.librarySource = source
            }
        }
    )
}

@Composable
private fun GroupCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    artworkSong: SongItem?,
    artworkUrl: String?,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.borderSoft)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (artworkSong != null) {
                ArtworkImage(
                    song = artworkSong,
                    artworkUrl = artworkUrl,
                    modifier = Modifier.size(62.dp),
                    cornerRadius = 13
                )
            } else {
                Surface(
                    modifier = Modifier.size(62.dp),
                    shape = RoundedCornerShape(13.dp),
                    color = colors.purple.copy(alpha = 0.14f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(icon, contentDescription = null, tint = colors.purpleBright)
                    }
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(subtitle, color = colors.textSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = colors.textMuted)
        }
    }
}

@Composable
private fun PlaylistSummaryCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.border)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(54.dp),
                shape = RoundedCornerShape(15.dp),
                color = colors.purple.copy(alpha = 0.17f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(28.dp))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = colors.textPrimary, fontWeight = FontWeight.Bold)
                Text(subtitle, color = colors.textSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = colors.textMuted)
        }
    }
}

private sealed interface SmartPlaylistTarget {
    data class BuiltIn(val type: BuiltInSmartPlaylist) : SmartPlaylistTarget
    data class Custom(val definition: SmartPlaylistDefinition) : SmartPlaylistTarget
}

@Composable
private fun SmartPlaylistProSection(
    controller: MusicController,
    premiumLocked: Boolean,
    onOpenPremium: () -> Unit,
    onOpenBuiltIn: (BuiltInSmartPlaylist) -> Unit,
    onOpenCustom: (SmartPlaylistDefinition) -> Unit,
    onCreateCustom: () -> Unit,
    onEditCustom: (SmartPlaylistDefinition) -> Unit,
    onDeleteCustom: (SmartPlaylistDefinition) -> Unit,
    duplicateGroups: List<SmartDuplicateGroup>,
    duplicateScanDone: Boolean,
    duplicateScanBusy: Boolean,
    onOpenDuplicates: () -> Unit
) {
    val colors = LocalMusicColors.current
    val builtIns = listOf(
        Triple(BuiltInSmartPlaylist.MOST_PLAYED, Icons.Rounded.Headphones, true),
        Triple(BuiltInSmartPlaylist.RECENTLY_PLAYED, Icons.Rounded.History, false),
        Triple(BuiltInSmartPlaylist.NEWLY_ADDED, Icons.Rounded.NewReleases, false),
        Triple(BuiltInSmartPlaylist.NEVER_PLAYED, Icons.Rounded.MusicNote, true),
        Triple(BuiltInSmartPlaylist.LONG_NOT_HEARD, Icons.Rounded.RestartAlt, true)
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            colors.purple.copy(alpha = if (colors.isDark) 0.42f else 0.18f),
                            colors.blue.copy(alpha = if (colors.isDark) 0.26f else 0.12f),
                            colors.card
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(48.dp),
                        shape = RoundedCornerShape(15.dp),
                        color = colors.purple.copy(alpha = 0.20f),
                        border = BorderStroke(1.dp, colors.purpleBright.copy(alpha = 0.40f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(27.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                mwString("smart.title", "Smart Playlist Pro"),
                                color = colors.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(Modifier.width(7.dp))
                            Text("PRO", color = colors.purpleBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            mwString(
                                "smart.subtitle",
                                "Playlist tự cập nhật theo thói quen nghe và quy tắc của bạn"
                            ),
                            color = colors.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                    if (premiumLocked) {
                        IconButton(onClick = onOpenPremium) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, tint = colors.purpleBright)
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        mwString("smart.local_db", "Hoạt động trên thiết bị · Không cần máy chủ"),
                        color = colors.textMuted,
                        fontSize = 10.5.sp
                    )
                    Text(
                        if (controller.smartPlaylists.ready) mwString("smart.ready", "Đã sẵn sàng")
                        else mwString("smart.loading", "Đang khởi tạo"),
                        color = if (controller.smartPlaylists.ready) colors.green else colors.textMuted,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(end = 4.dp)
        ) {
            items(builtIns, key = { it.first.name }) { (type, icon, _) ->
                val locked = premiumLocked
                val count = controller.builtInSmartPlaylistCount(type)
                SmartBuiltInPlaylistCard(
                    type = type,
                    icon = icon,
                    count = count,
                    locked = locked,
                    onClick = {
                        if (locked) onOpenPremium() else onOpenBuiltIn(type)
                    }
                )
            }
        }

        OutlinedButton(
            onClick = {
                if (premiumLocked) onOpenPremium() else onCreateCustom()
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp),
            border = BorderStroke(1.dp, colors.purpleBright.copy(alpha = 0.75f))
        ) {
            Icon(
                if (premiumLocked) Icons.Rounded.Lock else Icons.Rounded.Add,
                contentDescription = null,
                tint = colors.purpleBright,
                modifier = Modifier.size(19.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                mwString("smart.create", "Tạo playlist thông minh"),
                color = colors.purpleBright,
                fontWeight = FontWeight.Bold
            )
        }

        if (controller.smartPlaylists.customPlaylists.isNotEmpty()) {
            Text(
                mwString("smart.your_playlists", "Playlist thông minh của bạn"),
                color = colors.textPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            controller.smartPlaylists.customPlaylists.forEach { definition ->
                SmartCustomPlaylistRow(
                    definition = definition,
                    count = controller.customSmartPlaylistCount(definition),
                    locked = premiumLocked,
                    onOpen = {
                        if (premiumLocked) onOpenPremium() else onOpenCustom(definition)
                    },
                    onEdit = {
                        if (premiumLocked) onOpenPremium() else onEditCustom(definition)
                    },
                    onDelete = { onDeleteCustom(definition) }
                )
            }
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (premiumLocked) onOpenPremium() else onOpenDuplicates()
                },
            shape = RoundedCornerShape(17.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(46.dp),
                    shape = RoundedCornerShape(13.dp),
                    color = colors.blue.copy(alpha = 0.14f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = colors.blue)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        mwString("smart.duplicates", "Bài hát có thể bị trùng"),
                        color = colors.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        when {
                            duplicateScanBusy -> mwString("smart.duplicate_scanning", "Đang quét thư viện…")
                            !duplicateScanDone -> mwString("smart.duplicate_scan_hint", "Nhấn để kiểm tra kho nhạc")
                            else -> mwString(
                                "smart.duplicate_count",
                                "{groups} nhóm · {files} file",
                                "groups" to duplicateGroups.size,
                                "files" to duplicateGroups.sumOf { it.songs.size }
                            )
                        },
                        color = colors.textSecondary,
                        fontSize = 12.sp
                    )
                }
                Icon(
                    if (premiumLocked) Icons.Rounded.Lock else Icons.Rounded.ChevronRight,
                    contentDescription = null,
                    tint = if (premiumLocked) colors.purpleBright else colors.textMuted
                )
            }
        }

        controller.smartPlaylists.lastError?.let { error ->
            Surface(
                color = colors.red.copy(alpha = 0.10f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, colors.red.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(error, color = colors.red, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = controller.smartPlaylists::clearError, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = null, tint = colors.red, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartBuiltInPlaylistCard(
    type: BuiltInSmartPlaylist,
    icon: ImageVector,
    count: Int,
    locked: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier
            .width(154.dp)
            .height(126.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = colors.card,
        border = BorderStroke(
            1.dp,
            if (locked) colors.border else colors.purpleBright.copy(alpha = 0.32f)
        )
    ) {
        Column(
            modifier = Modifier.padding(13.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(38.dp),
                    shape = RoundedCornerShape(11.dp),
                    color = colors.purple.copy(alpha = 0.14f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(icon, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(21.dp))
                    }
                }
                Spacer(Modifier.weight(1f))
                if (locked) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = colors.textMuted, modifier = Modifier.size(17.dp))
                }
            }
            Column {
                Text(
                    smartBuiltInTitle(type),
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    mwString("library.count_songs", "{count} bài hát", "count" to count),
                    color = colors.textSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun SmartCustomPlaylistRow(
    definition: SmartPlaylistDefinition,
    count: Int,
    locked: Boolean,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.borderSoft)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpen)
                .padding(start = 12.dp, top = 9.dp, bottom = 9.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(12.dp),
                color = colors.purple.copy(alpha = 0.14f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Tune, contentDescription = null, tint = colors.purpleBright)
                }
            }
            Spacer(Modifier.width(11.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    definition.playlist.name,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    mwString(
                        "smart.custom_meta",
                        "{count} bài · {rules} điều kiện",
                        "count" to count,
                        "rules" to definition.rules.size
                    ),
                    color = colors.textSecondary,
                    fontSize = 11.sp
                )
            }
            if (locked) {
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = colors.textMuted, modifier = Modifier.padding(8.dp))
            } else {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Rounded.Edit, contentDescription = mwString("common.edit", "Sửa"), tint = colors.textSecondary)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = mwString("common.delete", "Xóa"), tint = colors.red)
            }
        }
    }
}

@Composable
private fun SmartPlaylistSongsDialog(
    controller: MusicController,
    title: String,
    songs: List<SongItem>,
    onDismiss: () -> Unit,
    onMore: (SongItem) -> Unit,
    folderMode: Boolean = false
) {
    val colors = LocalMusicColors.current
    // Multi-selection is scoped to this folder/playlist. A new folder starts clean.
    val selectedIds = remember(title, songs.map { it.id }) { mutableStateListOf<String>() }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(22.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(44.dp),
                        shape = RoundedCornerShape(13.dp),
                        color = colors.purple.copy(alpha = 0.16f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (folderMode) Icons.Rounded.Folder else Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = colors.purpleBright
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            title,
                            color = colors.textPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (folderMode) {
                                mwString("library.count_songs", "{count} bài hát", "count" to songs.size)
                            } else {
                                mwString("smart.auto_updated", "{count} bài · Cập nhật tự động", "count" to songs.size)
                            },
                            color = colors.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = mwString("common.close", "Đóng"), tint = colors.textSecondary)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (songs.isNotEmpty()) {
                                controller.playCollection(songs, 0)
                                if (folderMode) onDismiss()
                            }
                        },
                        enabled = songs.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(mwString("smart.play_all", "Phát tất cả"))
                    }
                    OutlinedButton(
                        onClick = {
                            if (songs.isNotEmpty()) {
                                controller.playCollection(songs.shuffled(), 0)
                                if (folderMode) onDismiss()
                            }
                        },
                        enabled = songs.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp),
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(mwString("smart.shuffle", "Ngẫu nhiên"), color = colors.purpleBright)
                    }
                }

                if (songs.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${selectedIds.size}/${songs.size} bài đã chọn",
                            color = colors.textSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            if (selectedIds.size == songs.size) {
                                selectedIds.clear()
                            } else {
                                selectedIds.clear()
                                selectedIds.addAll(songs.map { it.id })
                            }
                        }) {
                            Text(
                                if (selectedIds.size == songs.size)
                                    mwString("library.unselect_all", "Bỏ chọn")
                                else mwString("library.select_all", "Chọn tất cả"),
                                color = colors.purpleBright
                            )
                        }
                    }
                    Button(
                        onClick = {
                            val chosen = songs.filter { it.id in selectedIds }
                            if (chosen.isNotEmpty()) {
                                controller.playCollection(chosen, 0)
                                onDismiss()
                            }
                        },
                        enabled = selectedIds.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Phát đã chọn (${selectedIds.size})")
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (songs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.FilterList, contentDescription = null, tint = colors.textMuted, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (folderMode) "Thư mục này chưa có bài hát" else
                                    mwString("smart.no_matching", "Chưa có bài hát phù hợp với điều kiện"),
                                color = colors.textSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(songs, key = { it.id }) { song ->
                            LaunchedEffect(song.id) { controller.ensureArtwork(song) }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = song.id in selectedIds,
                                    onCheckedChange = { checked ->
                                        if (checked) {
                                            if (song.id !in selectedIds) selectedIds.add(song.id)
                                        } else selectedIds.remove(song.id)
                                    },
                                    modifier = Modifier.size(40.dp),
                                    colors = CheckboxDefaults.colors(checkedColor = colors.purple)
                                )
                                SongRow(
                                    song = song,
                                    artworkUrl = controller.artworkFor(song),
                                    isCurrent = controller.currentSong?.id == song.id,
                                    isFavorite = controller.isFavorite(song),
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        if (folderMode) {
                                            // Tapping the track (not its checkbox) plays only that song.
                                            controller.playCollection(listOf(song), 0)
                                            onDismiss()
                                        } else {
                                            controller.playSong(song, songs)
                                            onDismiss()
                                        }
                                    },
                                    onFavorite = { controller.toggleFavorite(song) },
                                    onMore = if (controller.canUseLocalAudioTools(song)) {
                                        { onMore(song) }
                                    } else null
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartPlaylistEditorDialog(
    initial: SmartPlaylistDraft,
    onDismiss: () -> Unit,
    onSave: (SmartPlaylistDraft) -> Unit
) {
    val colors = LocalMusicColors.current
    var name by remember(initial.id, initial.name) { mutableStateOf(initial.name) }
    var matchMode by remember(initial.id, initial.matchMode) { mutableStateOf(initial.matchMode) }
    var sortType by remember(initial.id, initial.sortType) { mutableStateOf(initial.sortType) }
    var maxItems by remember(initial.id, initial.maxItems) { mutableStateOf(initial.maxItems) }
    val rules = remember(initial.id, initial.rules.hashCode()) {
        mutableStateListOf<SmartPlaylistRuleDraft>().apply {
            addAll(initial.rules.ifEmpty { listOf(SmartPlaylistRuleDraft()) })
        }
    }
    val canSave = name.trim().isNotEmpty() && rules.isNotEmpty() && rules.all(::smartRuleIsValid)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.93f),
            shape = RoundedCornerShape(22.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Tune, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(9.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (initial.id > 0L) mwString("smart.edit_title", "Sửa Smart Playlist")
                            else mwString("smart.create_title", "Tạo Smart Playlist"),
                            color = colors.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            mwString("smart.editor_desc", "Danh sách sẽ tự cập nhật khi thư viện hoặc thói quen nghe thay đổi"),
                            color = colors.textSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = mwString("common.close", "Đóng"), tint = colors.textSecondary)
                    }
                }

                Spacer(Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(11.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(80) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text(mwString("smart.name", "Tên playlist")) },
                        placeholder = { Text(mwString("smart.name_example", "Ví dụ: Ballad yêu thích")) }
                    )

                    Text(
                        mwString("smart.match", "Khớp điều kiện"),
                        color = colors.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmartChoicePill(
                            text = mwString("smart.match_all", "Tất cả (AND)"),
                            selected = matchMode == SmartMatchMode.ALL,
                            modifier = Modifier.weight(1f),
                            onClick = { matchMode = SmartMatchMode.ALL }
                        )
                        SmartChoicePill(
                            text = mwString("smart.match_any", "Ít nhất một (OR)"),
                            selected = matchMode == SmartMatchMode.ANY,
                            modifier = Modifier.weight(1f),
                            onClick = { matchMode = SmartMatchMode.ANY }
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            mwString("smart.conditions", "Điều kiện"),
                            color = colors.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            "${rules.size}/12",
                            color = colors.textMuted,
                            fontSize = 11.sp
                        )
                    }

                    rules.forEachIndexed { index, rule ->
                        SmartRuleEditorCard(
                            index = index,
                            rule = rule,
                            canDelete = rules.size > 1,
                            onChange = { updated -> rules[index] = updated },
                            onDelete = { if (rules.size > 1) rules.removeAt(index) }
                        )
                    }

                    if (rules.size < 12) {
                        TextButton(
                            onClick = { rules.add(SmartPlaylistRuleDraft()) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = colors.purpleBright)
                            Spacer(Modifier.width(6.dp))
                            Text(mwString("smart.add_condition", "Thêm điều kiện"), color = colors.purpleBright)
                        }
                    }

                    Text(
                        mwString("smart.sort", "Sắp xếp"),
                        color = colors.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    SmartSortPicker(selected = sortType, onSelected = { sortType = it })

                    Text(
                        mwString("smart.limit", "Giới hạn số bài"),
                        color = colors.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf(20, 50, 100, 0)) { value ->
                            SmartChoicePill(
                                text = if (value == 0) mwString("smart.all", "Tất cả") else value.toString(),
                                selected = maxItems == value,
                                onClick = { maxItems = value }
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Text(mwString("common.cancel", "Hủy"), color = colors.textSecondary)
                    }
                    Button(
                        onClick = {
                            onSave(
                                initial.copy(
                                    name = name.trim(),
                                    matchMode = matchMode,
                                    sortType = sortType,
                                    maxItems = maxItems,
                                    rules = rules.toList()
                                )
                            )
                        },
                        enabled = canSave,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(mwString("common.save", "Lưu"))
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartRuleEditorCard(
    index: Int,
    rule: SmartPlaylistRuleDraft,
    canDelete: Boolean,
    onChange: (SmartPlaylistRuleDraft) -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        shape = RoundedCornerShape(15.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.borderSoft)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    mwString("smart.condition_number", "Điều kiện {number}", "number" to (index + 1)),
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )
                if (canDelete) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = null, tint = colors.red, modifier = Modifier.size(17.dp))
                    }
                }
            }

            SmartFieldPicker(
                selected = rule.field,
                onSelected = { field ->
                    onChange(
                        rule.copy(
                            field = field,
                            operator = smartRuleDefaultOperator(field),
                            value = if (field == SmartRuleField.FAVORITE) "true" else "",
                            secondValue = ""
                        )
                    )
                }
            )
            SmartOperatorPicker(
                field = rule.field,
                selected = rule.operator,
                onSelected = { operator -> onChange(rule.copy(operator = operator)) }
            )

            when (rule.field) {
                SmartRuleField.FAVORITE -> {
                    Text(
                        if (rule.operator == SmartRuleOperator.IS_FALSE)
                            mwString("smart.not_favorite", "Chỉ lấy bài chưa yêu thích")
                        else mwString("smart.is_favorite", "Chỉ lấy bài đã yêu thích"),
                        color = colors.textSecondary,
                        fontSize = 11.sp
                    )
                }

                SmartRuleField.SOURCE -> {
                    SmartSourcePicker(
                        selectedName = rule.value,
                        onSelected = { source -> onChange(rule.copy(value = source.name)) }
                    )
                }

                else -> {
                    val numeric = rule.field in setOf(
                        SmartRuleField.DURATION_MINUTES,
                        SmartRuleField.PLAY_COUNT,
                        SmartRuleField.DATE_ADDED_DAYS,
                        SmartRuleField.LAST_PLAYED_DAYS
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = rule.value,
                            onValueChange = { onChange(rule.copy(value = it.take(200))) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text(smartRuleValueLabel(rule.field, first = true)) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text,
                                imeAction = ImeAction.Next
                            )
                        )
                        if (rule.operator == SmartRuleOperator.BETWEEN) {
                            OutlinedTextField(
                                value = rule.secondValue,
                                onValueChange = { onChange(rule.copy(secondValue = it.take(200))) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                label = { Text(smartRuleValueLabel(rule.field, first = false)) },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartFieldPicker(
    selected: SmartRuleField,
    onSelected: (SmartRuleField) -> Unit
) {
    val options = SmartRuleField.values().map { it to smartFieldLabel(it) }
    SmartTextDropdown(
        selectedLabel = smartFieldLabel(selected),
        options = options,
        onSelected = onSelected
    )
}

@Composable
private fun SmartOperatorPicker(
    field: SmartRuleField,
    selected: SmartRuleOperator,
    onSelected: (SmartRuleOperator) -> Unit
) {
    val available = smartRuleOperators(field)
    val safeSelected = selected.takeIf { it in available } ?: available.first()
    val options = available.map { it to smartOperatorLabel(it) }
    SmartTextDropdown(
        selectedLabel = smartOperatorLabel(safeSelected),
        options = options,
        onSelected = onSelected
    )
}

@Composable
private fun SmartSortPicker(
    selected: SmartSortType,
    onSelected: (SmartSortType) -> Unit
) {
    val options = SmartSortType.values().map { it to smartSortLabel(it) }
    SmartTextDropdown(
        selectedLabel = smartSortLabel(selected),
        options = options,
        onSelected = onSelected
    )
}

@Composable
private fun SmartSourcePicker(
    selectedName: String,
    onSelected: (SongSource) -> Unit
) {
    val selected = SongSource.values().firstOrNull { it.name == selectedName }
    val options = SongSource.values().map { it to smartSourceLabel(it) }
    SmartTextDropdown(
        selectedLabel = selected?.let { smartSourceLabel(it) }
            ?: mwString("smart.choose_source", "Chọn nguồn nhạc"),
        options = options,
        onSelected = onSelected
    )
}

@Composable
private fun <T> SmartTextDropdown(
    selectedLabel: String,
    options: List<Pair<T, String>>,
    onSelected: (T) -> Unit
) {
    val colors = LocalMusicColors.current
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true },
            shape = RoundedCornerShape(12.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    selectedLabel,
                    color = colors.textPrimary,
                    fontSize = 12.5.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text("▾", color = colors.purpleBright, fontSize = 16.sp)
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.widthIn(min = 210.dp, max = 330.dp)
                .background(colors.card)
        ) {
            options.forEach { (value, label) ->
                DropdownMenuItem(
                    text = { Text(label, color = colors.textPrimary, fontSize = 12.sp) },
                    onClick = {
                        expanded = false
                        onSelected(value)
                    }
                )
            }
        }
    }
}

@Composable
private fun SmartChoicePill(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) colors.purple.copy(alpha = 0.16f) else colors.card,
        border = BorderStroke(1.dp, if (selected) colors.purpleBright else colors.border)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (selected) {
                Icon(Icons.Rounded.Check, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
            }
            Text(
                text,
                color = if (selected) colors.purpleBright else colors.textSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun SmartPlaylistDeleteDialog(
    name: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    mwString("smart.delete_title", "Xóa Smart Playlist?"),
                    color = colors.textPrimary,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp
                )
                Text(
                    mwString(
                        "smart.delete_desc",
                        "Chỉ xóa quy tắc playlist “{name}”. Các file nhạc không bị xóa.",
                        "name" to name
                    ),
                    color = colors.textSecondary,
                    fontSize = 12.5.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(mwString("common.cancel", "Hủy"), color = colors.textSecondary)
                    }
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.red),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(mwString("common.delete", "Xóa"))
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartDuplicateManagerDialog(
    controller: MusicController,
    groups: List<SmartDuplicateGroup>,
    onDismiss: () -> Unit,
    onMore: (SongItem) -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.92f),
            shape = RoundedCornerShape(22.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(44.dp),
                        shape = RoundedCornerShape(13.dp),
                        color = colors.blue.copy(alpha = 0.14f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = colors.blue)
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            mwString("smart.duplicates", "Bài hát có thể bị trùng"),
                            color = colors.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            mwString(
                                "smart.duplicate_count",
                                "{groups} nhóm · {files} file",
                                "groups" to groups.size,
                                "files" to groups.sumOf { it.songs.size }
                            ),
                            color = colors.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = mwString("common.close", "Đóng"), tint = colors.textSecondary)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    mwString(
                        "smart.duplicate_note",
                        "MeloWave chỉ gợi ý theo tên, nghệ sĩ và thời lượng. Hãy nghe thử trước khi xóa."
                    ),
                    color = colors.textMuted,
                    fontSize = 10.5.sp
                )
                Spacer(Modifier.height(8.dp))

                if (groups.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = colors.green, modifier = Modifier.size(46.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                mwString("smart.no_duplicates", "Chưa phát hiện bài hát trùng"),
                                color = colors.textSecondary
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 8.dp)
                    ) {
                        items(groups, key = { it.key }) { group ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = colors.card,
                                border = BorderStroke(1.dp, colors.borderSoft)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        group.title,
                                        color = colors.textPrimary,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${mwArtistLabel(group.artist)} · ${group.songs.size} file",
                                        color = colors.textSecondary,
                                        fontSize = 11.sp
                                    )
                                    Spacer(Modifier.height(5.dp))
                                    group.songs.forEachIndexed { index, song ->
                                        DuplicateSongCompactRow(
                                            controller = controller,
                                            song = song,
                                            onPlay = { controller.playCollection(group.songs, index) },
                                            onMore = { onMore(song) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DuplicateSongCompactRow(
    controller: MusicController,
    song: SongItem,
    onPlay: () -> Unit,
    onMore: () -> Unit
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .clickable(onClick = onPlay)
            .padding(vertical = 7.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtworkImage(
            song = song,
            artworkUrl = controller.artworkFor(song),
            modifier = Modifier.size(43.dp),
            cornerRadius = 10
        )
        Spacer(Modifier.width(9.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                song.title,
                color = colors.textPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                buildString {
                    append(song.folderName.ifBlank { controller.sourceLabel(song.source) })
                    append(" · ")
                    append(controller.formatBadge(song))
                    append(" · ")
                    append(song.durationLabel)
                },
                color = colors.textSecondary,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onMore, modifier = Modifier.size(34.dp)) {
            Icon(Icons.Rounded.MoreVert, contentDescription = null, tint = colors.textSecondary)
        }
    }
}

private fun smartRuleIsValid(rule: SmartPlaylistRuleDraft): Boolean {
    if (rule.field == SmartRuleField.FAVORITE) return true
    if (rule.value.isBlank()) return false

    val numericField = rule.field in setOf(
        SmartRuleField.DURATION_MINUTES,
        SmartRuleField.PLAY_COUNT,
        SmartRuleField.DATE_ADDED_DAYS,
        SmartRuleField.LAST_PLAYED_DAYS
    )
    if (numericField) {
        val first = rule.value.replace(',', '.').toDoubleOrNull() ?: return false
        if (first < 0.0) return false
        if (rule.operator == SmartRuleOperator.BETWEEN) {
            val second = rule.secondValue.replace(',', '.').toDoubleOrNull() ?: return false
            if (second < 0.0) return false
        }
    } else if (rule.operator == SmartRuleOperator.BETWEEN && rule.secondValue.isBlank()) {
        return false
    }
    return true
}

@Composable
private fun smartBuiltInTitle(type: BuiltInSmartPlaylist): String = when (type) {
    BuiltInSmartPlaylist.MOST_PLAYED -> mwString("smart.most_played", "Nghe nhiều nhất")
    BuiltInSmartPlaylist.RECENTLY_PLAYED -> mwString("smart.recently_played", "Nghe gần đây")
    BuiltInSmartPlaylist.NEWLY_ADDED -> mwString("smart.newly_added", "Mới thêm")
    BuiltInSmartPlaylist.NEVER_PLAYED -> mwString("smart.never_played", "Chưa từng nghe")
    BuiltInSmartPlaylist.LONG_NOT_HEARD -> mwString("smart.long_not_heard", "Lâu chưa nghe")
}

@Composable
private fun smartFieldLabel(field: SmartRuleField): String = when (field) {
    SmartRuleField.ARTIST -> mwString("smart.field.artist", "Nghệ sĩ")
    SmartRuleField.ALBUM -> mwString("smart.field.album", "Album")
    SmartRuleField.GENRE -> mwString("smart.field.genre", "Thể loại")
    SmartRuleField.FOLDER -> mwString("smart.field.folder", "Thư mục")
    SmartRuleField.SOURCE -> mwString("smart.field.source", "Nguồn nhạc")
    SmartRuleField.DURATION_MINUTES -> mwString("smart.field.duration", "Thời lượng (phút)")
    SmartRuleField.PLAY_COUNT -> mwString("smart.field.play_count", "Số lượt nghe")
    SmartRuleField.DATE_ADDED_DAYS -> mwString("smart.field.date_added", "Ngày thêm")
    SmartRuleField.LAST_PLAYED_DAYS -> mwString("smart.field.last_played", "Lần nghe gần nhất")
    SmartRuleField.FAVORITE -> mwString("smart.field.favorite", "Yêu thích")
}

@Composable
private fun smartOperatorLabel(operator: SmartRuleOperator): String = when (operator) {
    SmartRuleOperator.EQUALS -> mwString("smart.op.equals", "Bằng")
    SmartRuleOperator.NOT_EQUALS -> mwString("smart.op.not_equals", "Không bằng")
    SmartRuleOperator.CONTAINS -> mwString("smart.op.contains", "Có chứa")
    SmartRuleOperator.NOT_CONTAINS -> mwString("smart.op.not_contains", "Không chứa")
    SmartRuleOperator.GREATER_THAN -> mwString("smart.op.greater", "Lớn hơn")
    SmartRuleOperator.LESS_THAN -> mwString("smart.op.less", "Nhỏ hơn")
    SmartRuleOperator.BETWEEN -> mwString("smart.op.between", "Trong khoảng")
    SmartRuleOperator.WITHIN_DAYS -> mwString("smart.op.within_days", "Trong số ngày gần đây")
    SmartRuleOperator.OLDER_THAN_DAYS -> mwString("smart.op.older_days", "Cũ hơn số ngày")
    SmartRuleOperator.IS_TRUE -> mwString("smart.op.yes", "Có")
    SmartRuleOperator.IS_FALSE -> mwString("smart.op.no", "Không")
}

@Composable
private fun smartSortLabel(sort: SmartSortType): String = when (sort) {
    SmartSortType.MOST_PLAYED -> mwString("smart.sort.most_played", "Nghe nhiều nhất")
    SmartSortType.RECENTLY_PLAYED -> mwString("smart.sort.recent", "Nghe gần đây")
    SmartSortType.NEWEST_ADDED -> mwString("smart.sort.newest", "Mới thêm trước")
    SmartSortType.TITLE -> mwString("smart.sort.title", "Tên bài A–Z")
    SmartSortType.ARTIST -> mwString("smart.sort.artist", "Nghệ sĩ A–Z")
    SmartSortType.DURATION_ASC -> mwString("smart.sort.duration_asc", "Thời lượng ngắn trước")
    SmartSortType.DURATION_DESC -> mwString("smart.sort.duration_desc", "Thời lượng dài trước")
    SmartSortType.DAILY_RANDOM -> mwString("smart.sort.random", "Ngẫu nhiên theo ngày")
}

@Composable
private fun smartSourceLabel(source: SongSource): String = when (source) {
    SongSource.LOCAL_MEDIASTORE -> mwString("smart.source.local", "Nhạc trên máy")
    SongSource.PERSONAL_DRIVE -> mwString("smart.source.my_drive", "Google Drive của tôi")
    SongSource.PUBLIC_DRIVE -> mwString("smart.source.public_drive", "Drive chia sẻ")
    SongSource.DOWNLOADED -> mwString("smart.source.downloaded", "Đã tải Offline")
    SongSource.ONLINE_HTTP -> mwString("smart.source.online", "Nhạc trực tuyến")
    SongSource.INTERNET_P2P -> mwString("smart.source.p2p", "MeloWave Internet")
    SongSource.MOVIE -> mwString("smart.source.movie", "Movie")
    SongSource.APP_RESOURCE -> mwString("smart.source.app", "Âm thanh ứng dụng")
}

@Composable
private fun smartRuleValueLabel(field: SmartRuleField, first: Boolean): String = when (field) {
    SmartRuleField.DURATION_MINUTES -> if (first) mwString("smart.value.min", "Từ / giá trị")
    else mwString("smart.value.max", "Đến")
    SmartRuleField.PLAY_COUNT -> if (first) mwString("smart.value.count", "Số lượt")
    else mwString("smart.value.count_to", "Đến lượt")
    SmartRuleField.DATE_ADDED_DAYS,
    SmartRuleField.LAST_PLAYED_DAYS -> mwString("smart.value.days", "Số ngày")
    else -> if (first) mwString("smart.value.text", "Giá trị")
    else mwString("smart.value.second", "Giá trị 2")
}


@Composable
private fun EmptyGroupState(text: String) {
    Text(
        text,
        color = LocalMusicColors.current.textSecondary,
        modifier = Modifier.padding(28.dp)
    )
}

@Composable
private fun PersonalDriveDialog(
    controller: MusicController,
    onAuthorize: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current

    LaunchedEffect(controller.hasPersonalDriveAuthorization) {
        if (
            controller.hasPersonalDriveAuthorization &&
            controller.personalDrivePath.isEmpty() &&
            !controller.personalDriveBusy
        ) {
            controller.openPersonalDriveRoot()
        }
    }

    Dialog(
        onDismissRequest = { if (!controller.personalDriveBusy) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.91f),
            shape = RoundedCornerShape(20.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Cloud,
                        contentDescription = null,
                        tint = colors.purpleBright
                    )
                    Spacer(Modifier.size(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = mwString("library.personal_drive_title", "Google Drive của tôi"),
                            color = colors.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = controller.personalDriveAccountEmail
                                ?: mwString("library.picker_file", "Chọn file bằng Google Picker"),
                            color = colors.textSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss, enabled = !controller.personalDriveBusy) {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = mwString("common.close", "Đóng"),
                            tint = colors.textSecondary
                        )
                    }
                }

                if (!controller.hasPersonalDriveAuthorization) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                Icons.Rounded.Cloud,
                                contentDescription = null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = mwString("library.picker_privacy", "MeloWare chỉ truy cập các file hoặc thư mục bạn chủ động chọn bằng Google Picker."),
                                color = colors.textSecondary,
                                fontSize = 13.sp
                            )
                            Button(
                                onClick = onAuthorize,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                            ) {
                                Text(mwString("library.open_picker", "Mở Google Picker"))
                            }
                        }
                    }
                    controller.personalDriveError?.let { error ->
                        Text(error, color = colors.red, fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    return@Column
                }

                if (controller.personalDriveBusy) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.size(10.dp))
                        Text(mwString("library.reading_drive", "Đang đọc Google Drive..."), color = colors.textSecondary)
                    }
                }

                controller.personalDriveError?.let { error ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = colors.red.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, colors.red.copy(alpha = 0.35f))
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(error, color = colors.red, fontSize = 12.sp)
                            if (controller.personalDriveNeedsAuthorization) {
                                TextButton(onClick = onAuthorize) {
                                    Text(mwString("library.reauthorize", "Cấp lại quyền"), color = colors.purpleBright)
                                }
                            }
                        }
                    }
                }

                val currentFolder = controller.personalDrivePath.lastOrNull()
                if (currentFolder != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = controller::goBackPersonalDrive,
                            enabled = controller.personalDrivePath.size > 1 && !controller.personalDriveBusy
                        ) {
                            Icon(
                                Icons.Rounded.ArrowBack,
                                contentDescription = mwString("library.back", "Trở lại"),
                                tint = colors.textPrimary
                            )
                        }
                        Text(
                            text = controller.personalDrivePath.joinToString(" / ") { it.name },
                            color = colors.textPrimary,
                            fontSize = 13.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    val playable = controller.personalDriveEntries.filter(controller::isPersonalDrivePlayable)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            mwString("library.folder_song_count", "{folders} thư mục · {songs} bài", "folders" to controller.personalDriveEntries.count { it.isFolder }, "songs" to playable.size),
                            color = colors.textSecondary,
                            fontSize = 12.sp
                        )
                        TextButton(
                            onClick = controller::toggleAllPersonalDrivePlayable,
                            enabled = !controller.personalDriveBusy && playable.isNotEmpty()
                        ) {
                            val allSelected = playable.isNotEmpty() &&
                                    playable.all { controller.personalDriveSelectedIds.containsKey(it.id) }
                            Text(if (allSelected) mwString("library.unselect_all", "Bỏ chọn") else mwString("library.select_all", "Chọn tất cả"))
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(controller.personalDriveEntries, key = { it.id }) { entry ->
                            val isPlayable = controller.isPersonalDrivePlayable(entry)
                            val isSelected = controller.personalDriveSelectedIds.containsKey(entry.id)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(
                                        enabled = !controller.personalDriveBusy &&
                                                (entry.isFolder || isPlayable)
                                    ) {
                                        if (entry.isFolder) {
                                            controller.openPersonalDriveFolder(entry)
                                        } else {
                                            controller.togglePersonalDriveSelection(entry)
                                        }
                                    }
                                    .padding(vertical = 9.dp, horizontal = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (entry.isFolder) {
                                        Icons.Rounded.Folder
                                    } else {
                                        Icons.Rounded.MusicNote
                                    },
                                    contentDescription = null,
                                    tint = if (entry.isFolder) {
                                        colors.purpleBright
                                    } else {
                                        colors.textSecondary
                                    }
                                )
                                Spacer(Modifier.size(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        entry.name,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        color = colors.textPrimary,
                                        fontSize = 13.sp
                                    )
                                    if (!entry.isFolder && !isPlayable) {
                                        Text(
                                            mwString("library.file_not_downloadable", "Không hỗ trợ hoặc file không cho phép tải"),
                                            color = colors.textMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                if (entry.isFolder) {
                                    Icon(
                                        Icons.Rounded.ChevronRight,
                                        contentDescription = null,
                                        tint = colors.textSecondary
                                    )
                                } else if (isPlayable) {
                                    Text(
                                        if (isSelected) "☑" else "□",
                                        color = colors.purpleBright,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { controller.addSelectedPersonalDrive(playNow = false) },
                            enabled = controller.personalDriveSelectedIds.isNotEmpty() &&
                                    !controller.personalDriveBusy,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = colors.cardRaised)
                        ) {
                            Text(mwString("library.add_count", "Thêm {count}", "count" to controller.personalDriveSelectedIds.size))
                        }
                        Button(
                            onClick = { controller.addSelectedPersonalDrive(playNow = true) },
                            enabled = controller.personalDriveSelectedIds.isNotEmpty() &&
                                    !controller.personalDriveBusy,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = colors.blue)
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text(mwString("library.play", "Phát"))
                        }
                    }

                    Button(
                        onClick = { controller.addCurrentPersonalDriveFolder(playNow = true) },
                        enabled = !controller.personalDriveBusy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                    ) {
                        Text(mwString("library.play_folder_recursive", "Phát toàn bộ thư mục này (gồm thư mục con)"))
                    }
                } else if (!controller.personalDriveBusy) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(mwString("library.folder_load_failed", "Chưa tải được danh sách thư mục"), color = colors.textSecondary)
                            TextButton(onClick = controller::openPersonalDriveRoot) {
                                Text(mwString("library.reload", "Tải lại"), color = colors.purpleBright)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PublicDriveDialog(
    controller: MusicController,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    var showLinkHistory by remember { mutableStateOf(false) }
    var showArtistView by remember { mutableStateOf(true) }
    var expandedArtistFolderKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(controller.publicRoot?.folderId) {
        showArtistView = true
        expandedArtistFolderKey = null
    }
    Dialog(
        onDismissRequest = { if (!controller.publicDriveBusy) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(24.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.55f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Link, contentDescription = null, tint = colors.purpleBright)
                    Spacer(Modifier.width(9.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            mwString("library.public_drive_title", "Google Drive - Link công khai"),
                            color = colors.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            mwString("library.public_drive_hint", "Dán link thư mục được chia sẻ Anyone with the link"),
                            color = colors.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss, enabled = !controller.publicDriveBusy) {
                        Icon(Icons.Rounded.Close, contentDescription = mwString("common.close", "Đóng"), tint = colors.textSecondary)
                    }
                }

                // Tap to choose any previously opened Drive link. New URLs can still be pasted.
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { showLinkHistory = true },
                        enabled = !controller.publicDriveBusy,
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, colors.border),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Icon(Icons.Rounded.Folder, contentDescription = null,
                            tint = colors.purpleBright, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            mwString("library.drive_saved_links", "Link đã lưu") +
                                " (${controller.savedPublicDriveLinks.size})",
                            color = colors.textPrimary,
                            modifier = Modifier.weight(1f),
                            maxLines = 1
                        )
                        Icon(Icons.Rounded.ArrowDropDown,
                            contentDescription = mwString("library.drive_choose_link", "Chọn link"),
                            tint = colors.purpleBright)
                    }
                    DropdownMenu(
                        expanded = showLinkHistory,
                        onDismissRequest = { showLinkHistory = false },
                        modifier = Modifier.fillMaxWidth(0.85f).heightIn(max = 310.dp)
                    ) {
                        if (controller.savedPublicDriveLinks.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text(mwString("library.drive_no_saved_links", "Chưa có link đã lưu")) },
                                enabled = false,
                                onClick = {}
                            )
                        } else {
                            controller.savedPublicDriveLinks.forEach { saved ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(saved.name, maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                fontWeight = FontWeight.SemiBold)
                                            Text(saved.url, maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                fontSize = 10.sp,
                                                color = colors.textSecondary)
                                        }
                                    },
                                    onClick = {
                                        showLinkHistory = false
                                        controller.selectSavedPublicDriveLink(saved)
                                    },
                                    trailingIcon = {
                                        IconButton(
                                            onClick = { controller.forgetSavedPublicDriveLink(saved) },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(Icons.Rounded.Close,
                                                contentDescription = mwString("library.drive_forget_link", "Bỏ link đã lưu"),
                                                tint = colors.textMuted)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = colors.cardRaised,
                    border = BorderStroke(1.dp, colors.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = controller.publicLinkText,
                        onValueChange = controller::setPublicLink,
                        enabled = !controller.publicDriveBusy,
                        singleLine = true,
                        textStyle = TextStyle(color = colors.textPrimary, fontSize = 13.sp),
                        cursorBrush = SolidColor(colors.purpleBright),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Go
                        ),
                        keyboardActions = KeyboardActions(
                            onGo = { controller.openPublicDriveLink() }
                        ),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                        decorationBox = { inner ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Link, contentDescription = null, tint = colors.textMuted)
                                Spacer(Modifier.width(9.dp))
                                Box(modifier = Modifier.weight(1f)) {
                                    if (controller.publicLinkText.isBlank()) {
                                        Text(
                                            "https://drive.google.com/drive/folders/...",
                                            color = colors.textMuted,
                                            fontSize = 12.sp
                                        )
                                    }
                                    inner()
                                }
                                if (controller.publicLinkText.isNotBlank()) {
                                    IconButton(onClick = controller::clearPublicLink, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Rounded.Close, contentDescription = mwString("library.clear_link", "Xóa link"), tint = colors.textSecondary)
                                    }
                                }
                            }
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                            val clip = clipboard?.primaryClip
                            val text = if (clip != null && clip.itemCount > 0) {
                                clip.getItemAt(0).coerceToText(context).toString()
                            } else ""
                            if (text.isNotBlank()) controller.setPublicLink(text)
                        },
                        enabled = !controller.publicDriveBusy
                    ) {
                        Text(mwString("library.paste_clipboard", "Dán từ bộ nhớ tạm"), color = colors.purpleBright)
                    }
                    Button(
                        onClick = controller::openPublicDriveLink,
                        enabled = !controller.publicDriveBusy && controller.publicLinkText.isNotBlank(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(mwString("library.open_link", "Mở link"), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                if (controller.publicDriveBusy) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = colors.purpleBright
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(mwString("library.reading_drive", "Đang đọc Google Drive..."), color = colors.textSecondary)
                    }
                }

                controller.publicDriveError?.let { error ->
                    Text(error, color = colors.red, fontSize = 12.sp)
                }

                if (controller.publicPendingCount > 0 || controller.publicMixedFolderCount > 0) {
                    Text(
                        mwString("library.drive_mix_status", "Thư mục tổng hợp: {saved} bài · Đang chọn: {pending}",
                            "saved" to controller.publicMixedFolderCount,
                            "pending" to controller.publicPendingCount) +
                            if (controller.publicPendingArtistCount > 0) {
                                " · " + mwString("library.drive_selected_artists", "{count} thư mục ca sĩ",
                                    "count" to controller.publicPendingArtistCount)
                            } else "",
                        color = colors.purpleBright,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2
                    )
                }

                if (controller.publicPath.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            true to mwString("library.drive_artist_view", "Thư mục ca sĩ"),
                            false to mwString("library.drive_folder_view", "Thư mục Drive")
                        ).forEach { (artists, label) ->
                            Surface(
                                modifier = Modifier.weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showArtistView = artists },
                                shape = RoundedCornerShape(12.dp),
                                color = if (showArtistView == artists) colors.purple.copy(alpha = 0.23f)
                                    else colors.cardRaised,
                                border = BorderStroke(1.dp,
                                    if (showArtistView == artists) colors.purpleBright else colors.border)
                            ) {
                                Text(label,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 10.dp),
                                    color = if (showArtistView == artists) colors.purpleBright
                                        else colors.textSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }

                if (controller.publicPath.isNotEmpty() && !showArtistView) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = controller::goBackPublicFolder,
                            enabled = controller.publicPath.size > 1 && !controller.publicDriveBusy
                        ) {
                            Icon(Icons.Rounded.ArrowBack, contentDescription = mwString("library.back", "Quay lại"), tint = colors.textPrimary)
                        }
                        Text(
                            controller.publicPath.joinToString(" / ") { it.name },
                            color = colors.textPrimary,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                val playableEntries = controller.publicEntries.filter(controller::isPublicEntryPlayable)
                if (!showArtistView && playableEntries.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            mwString("library.folder_song_count", "{folders} thư mục · {songs} bài", "folders" to controller.publicEntries.count { it.isFolder }, "songs" to playableEntries.size),
                            color = colors.textSecondary,
                            fontSize = 12.sp
                        )
                        TextButton(
                            onClick = controller::toggleAllPublicEntries,
                            enabled = !controller.publicDriveBusy
                        ) {
                            val allSelected = playableEntries.all {
                                controller.publicSelectedIds[it.id] == true
                            }
                            Text(
                                if (allSelected) mwString("library.unselect_all", "Bỏ chọn") else mwString("library.select_all", "Chọn tất cả"),
                                color = colors.purpleBright
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (showArtistView) {
                        if (controller.publicArtistLoading) {
                            item(key = "artist_loading") {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp,
                                        color = colors.purpleBright
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(mwString("library.drive_group_loading", "Đang phân nhóm thư mục ca sĩ..."),
                                        color = colors.textSecondary, fontSize = 12.sp)
                                }
                            }
                        }
                        controller.publicArtistError?.let { error ->
                            item(key = "artist_error") {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(error, color = colors.red, fontSize = 12.sp)
                                    Text(mwString("library.drive_group_fallback",
                                        "Bạn vẫn có thể chọn từng thư mục ở tab Thư mục Drive."),
                                        color = colors.textSecondary, fontSize = 11.sp)
                                }
                            }
                        }
                        if (controller.publicRoot != null && !controller.publicArtistLoading &&
                            controller.publicArtistFolders.isEmpty() && controller.publicArtistError == null) {
                            item(key = "artist_empty") {
                                Text(
                                    mwString("library.drive_group_empty",
                                        "Không có bài hát để phân theo ca sĩ trong link này."),
                                    modifier = Modifier.padding(14.dp),
                                    color = colors.textSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        items(controller.publicArtistFolders, key = { "artist_${it.key}" }) { folder ->
                            val selected = controller.isPublicArtistFolderSelected(folder)
                            val expanded = expandedArtistFolderKey == folder.key
                            Column(
                                modifier = Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(13.dp))
                                    .background(if (selected) colors.purple.copy(alpha = 0.14f)
                                        else colors.cardRaised.copy(alpha = 0.55f))
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable {
                                            expandedArtistFolderKey = if (expanded) null else folder.key
                                        }
                                        .padding(horizontal = 6.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = selected,
                                        onCheckedChange = { controller.togglePublicArtistFolder(folder) },
                                        colors = CheckboxDefaults.colors(checkedColor = colors.purple)
                                    )
                                    Icon(Icons.Rounded.Folder, contentDescription = null,
                                        tint = colors.purpleBright, modifier = Modifier.size(21.dp))
                                    Spacer(Modifier.width(9.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(folder.name, color = colors.textPrimary,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            mwString("library.count_songs", "{count} bài hát",
                                                "count" to folder.songs.size) + " · " + folder.linkName,
                                            color = colors.textSecondary, fontSize = 11.sp,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Icon(
                                        if (expanded) Icons.Rounded.ArrowDropDown else Icons.Rounded.ChevronRight,
                                        contentDescription = null, tint = colors.textSecondary
                                    )
                                }
                                if (expanded) {
                                    folder.songs.take(35).forEach { song ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth()
                                                .padding(start = 56.dp, end = 12.dp, bottom = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Rounded.MusicNote, contentDescription = null,
                                                tint = colors.textMuted, modifier = Modifier.size(15.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text(song.title, color = colors.textSecondary,
                                                fontSize = 11.sp, maxLines = 1,
                                                overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                    if (folder.songs.size > 35) {
                                        Text("+${folder.songs.size - 35}",
                                            color = colors.purpleBright, fontSize = 11.sp,
                                            modifier = Modifier.padding(start = 58.dp, bottom = 8.dp))
                                    }
                                }
                            }
                        }
                    } else {
                        items(controller.publicEntries, key = { "file_${it.id}" }) { entry ->
                            val playable = controller.isPublicEntryPlayable(entry)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(13.dp))
                                    .clickable(enabled = entry.isFolder || playable) {
                                        if (entry.isFolder) controller.openPublicFolder(entry)
                                        else controller.togglePublicEntry(entry)
                                    }
                                    .background(
                                        if (controller.publicSelectedIds[entry.id] == true) {
                                            colors.purple.copy(alpha = 0.15f)
                                        } else Color.Transparent
                                    )
                                    .padding(horizontal = 8.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (entry.isFolder) {
                                    Icon(Icons.Rounded.Folder, contentDescription = null, tint = colors.purpleBright)
                                } else {
                                    Checkbox(
                                        checked = controller.publicSelectedIds[entry.id] == true,
                                        onCheckedChange = { controller.togglePublicEntry(entry) },
                                        enabled = playable,
                                        colors = CheckboxDefaults.colors(checkedColor = colors.purple)
                                    )
                                }
                                Spacer(Modifier.width(9.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        entry.name,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        when {
                                            entry.isFolder -> mwString("library.tabs.folders", "Thư mục")
                                            playable -> if (entry.mimeType.isBlank()) mwString("library.audio_file", "Tệp âm thanh") else entry.mimeType
                                            else -> mwString("library.owner_blocked", "Không hỗ trợ hoặc chủ sở hữu đã chặn tải")
                                        },
                                        color = if (!entry.isFolder && !playable) colors.textMuted else colors.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                if (entry.isFolder) {
                                    Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = colors.textMuted)
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { controller.addSelectedPublicSongs(playImmediately = false) },
                        enabled = controller.publicPendingCount > 0 && !controller.publicDriveBusy,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.cardRaised)
                    ) {
                        Text(mwString("library.drive_add_to_mix", "Ghép vào thư mục"), color = colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = { controller.addSelectedPublicSongs(playImmediately = true) },
                        enabled = (controller.publicPendingCount > 0 || controller.publicMixedFolderCount > 0) && !controller.publicDriveBusy,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(5.dp))
                        Text(mwString("library.play", "Phát"), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                if (!showArtistView) {
                    TextButton(
                        onClick = { controller.addCurrentPublicFolder(playImmediately = false) },
                        enabled = controller.publicPath.isNotEmpty() && !controller.publicDriveBusy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(mwString("library.add_current_folder", "Thêm toàn bộ thư mục hiện tại"),
                            color = colors.purpleBright)
                    }
                }
            }
        }
    }
}

private enum class SongToolPage { MENU, EDIT, DELETE, CUT, MERGE, RINGTONE }
private enum class SongConsentAction { NONE, EDIT, DELETE }

/** Used in both Library and NowPlaying so the same actions are restored everywhere. */
@Composable
internal fun SongToolsHost(
    controller: MusicController,
    song: SongItem,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val jobScope = rememberCoroutineScope()
    var page by remember(song.id) { mutableStateOf(SongToolPage.MENU) }
    var busy by remember(song.id) { mutableStateOf(false) }
    var actionError by remember(song.id) { mutableStateOf<String?>(null) }
    var pendingConsent by remember(song.id) { mutableStateOf(SongConsentAction.NONE) }
    var editTitle by remember(song.id) { mutableStateOf(song.title) }
    var editArtist by remember(song.id) { mutableStateOf(song.artist) }

    val consentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val action = pendingConsent
        pendingConsent = SongConsentAction.NONE
        if (result.resultCode != Activity.RESULT_OK) {
            actionError = "Bạn đã hủy cấp quyền trên Android; tệp nhạc chưa bị thay đổi."
        } else {
            busy = true
            jobScope.launch {
                val outcome = when (action) {
                    SongConsentAction.EDIT -> controller.updateLocalSongInfo(song, editTitle, editArtist, consentGranted = true)
                    SongConsentAction.DELETE -> controller.deleteLocalSongFromDevice(song, consentGranted = true)
                    SongConsentAction.NONE -> LocalSongMutationResult.Failed("Không có yêu cầu nào đang chờ xác nhận.")
                }
                busy = false
                when (outcome) {
                    LocalSongMutationResult.Completed,
                    LocalSongMutationResult.LibraryOnly -> onDismiss()
                    is LocalSongMutationResult.Failed -> actionError = outcome.message
                    is LocalSongMutationResult.NeedsConsent -> actionError = "Android vẫn chưa cấp quyền. Hãy thử lại thao tác."
                }
            }
        }
    }

    fun runAction(action: SongConsentAction) {
        if (busy) return
        actionError = null
        busy = true
        jobScope.launch {
            val outcome = when (action) {
                SongConsentAction.EDIT -> controller.updateLocalSongInfo(song, editTitle, editArtist)
                SongConsentAction.DELETE -> controller.deleteLocalSongFromDevice(song)
                SongConsentAction.NONE -> LocalSongMutationResult.Failed("Yêu cầu không hợp lệ")
            }
            busy = false
            when (outcome) {
                LocalSongMutationResult.Completed,
                LocalSongMutationResult.LibraryOnly -> onDismiss()
                is LocalSongMutationResult.Failed -> actionError = outcome.message
                is LocalSongMutationResult.NeedsConsent -> {
                    pendingConsent = action
                    runCatching {
                        consentLauncher.launch(IntentSenderRequest.Builder(outcome.intentSender).build())
                    }.onFailure {
                        pendingConsent = SongConsentAction.NONE
                        actionError = "Không thể mở xác nhận Android: ${it.localizedMessage ?: "Lỗi không xác định"}"
                    }
                }
            }
        }
    }

    val legacyWritePermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { approved ->
        if (approved) runAction(pendingConsent)
        else actionError = "Cần cấp quyền bộ nhớ để sửa hoặc xóa tệp nhạc trên Android cũ."
        pendingConsent = SongConsentAction.NONE
    }

    fun doAction(action: SongConsentAction) {
        // Android 9 and earlier require WRITE_EXTERNAL_STORAGE for external audio files.
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingConsent = action
            legacyWritePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else runAction(action)
    }

    when (page) {
        SongToolPage.MENU -> SongToolsMenuDialog(
            song = song,
            busy = controller.audioToolBusy || busy,
            onEdit = { page = SongToolPage.EDIT; actionError = null },
            onDelete = { page = SongToolPage.DELETE; actionError = null },
            onCut = { page = SongToolPage.CUT },
            onMerge = { page = SongToolPage.MERGE },
            onRingtone = { page = SongToolPage.RINGTONE },
            onDismiss = onDismiss
        )
        SongToolPage.EDIT -> EditSongInfoDialog(
            song = song,
            title = editTitle,
            artist = editArtist,
            onTitleChange = { editTitle = it },
            onArtistChange = { editArtist = it },
            busy = busy,
            error = actionError,
            onSave = { doAction(SongConsentAction.EDIT) },
            onBack = { if (!busy) page = SongToolPage.MENU },
            onDismiss = onDismiss
        )
        SongToolPage.DELETE -> DeleteSongConfirmDialog(
            song = song,
            busy = busy,
            error = actionError,
            onConfirm = { doAction(SongConsentAction.DELETE) },
            onBack = { if (!busy) page = SongToolPage.MENU },
            onDismiss = onDismiss
        )
        SongToolPage.CUT -> CutSongDialog(
            controller = controller,
            song = song,
            onBack = { page = SongToolPage.MENU },
            onDismiss = onDismiss
        )
        SongToolPage.MERGE -> MergeSongDialog(
            controller = controller,
            baseSong = song,
            onBack = { page = SongToolPage.MENU },
            onDismiss = onDismiss
        )
        SongToolPage.RINGTONE -> RingtoneSongDialog(
            controller = controller,
            song = song,
            onBack = { page = SongToolPage.MENU },
            onDismiss = onDismiss
        )
    }
}

@Composable
private fun SongToolsMenuDialog(
    song: SongItem,
    busy: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCut: () -> Unit,
    onMerge: () -> Unit,
    onRingtone: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.42f))
        ) {
            Column(modifier = Modifier.heightIn(max = 630.dp).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mwString("library.audio_tools", "Công cụ âm thanh"), color = colors.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(song.title, color = colors.purpleBright, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = onDismiss, enabled = !busy) {
                        Icon(Icons.Rounded.Close, contentDescription = mwString("common.close", "Đóng"), tint = colors.textSecondary)
                    }
                }
                AudioToolRow(Icons.Rounded.Edit, mwString("library.edit_song_info", "Sửa thông tin bài hát"),
                    mwString("library.edit_song_info_desc", "Đổi tên bài hát và ca sĩ / nghệ sĩ"), onEdit)
                AudioToolRow(Icons.Rounded.ContentCut, mwString("library.cut", "Cắt nhạc"), mwString("library.cut_desc", "Chọn đoạn và lưu thành tệp M4A mới"), onCut)
                AudioToolRow(Icons.Rounded.PlaylistAdd, mwString("library.merge", "Ghép nhạc"), mwString("library.merge_desc", "Nối bài này với một bài hát khác"), onMerge)
                AudioToolRow(Icons.Rounded.NotificationsActive, mwString("library.ringtone", "Đặt làm nhạc chuông"), mwString("library.ringtone_desc", "Cuộc gọi hoặc âm báo thông báo"), onRingtone)
                AudioToolRow(Icons.Rounded.DeleteForever, mwString("library.delete_song", "Xóa bài hát khỏi máy"),
                    mwString("library.delete_song_desc", "Xóa file nhạc trên điện thoại (cần xác nhận)"), onDelete)
                if (busy) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = colors.purpleBright)
                        Text(mwString("library.processing_audio", "Đang xử lý tệp âm thanh..."), color = colors.textSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EditSongInfoDialog(
    song: SongItem,
    title: String,
    artist: String,
    onTitleChange: (String) -> Unit,
    onArtistChange: (String) -> Unit,
    busy: Boolean,
    error: String?,
    onSave: () -> Unit,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
            color = colors.card, border = BorderStroke(1.dp, colors.border)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DialogToolHeader(mwString("library.edit_song_info", "Sửa thông tin bài hát"), song.title, onBack,
                    { if (!busy) onDismiss() })
                OutlinedTextField(
                    value = title, onValueChange = onTitleChange,
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(mwString("library.track_title", "Tên bài hát"), color = colors.textSecondary) },
                    textStyle = TextStyle(color = colors.textPrimary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
                OutlinedTextField(
                    value = artist, onValueChange = onArtistChange,
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(mwString("library.track_artist", "Ca sĩ / nghệ sĩ"), color = colors.textSecondary) },
                    textStyle = TextStyle(color = colors.textPrimary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                )
                Text(mwString("library.edit_song_note", "Tên hiển thị được lưu trong MeloWave và cập nhật MediaStore khi Android cho phép. Tag âm thanh bên trong file không bị ghi đè."),
                    color = colors.textSecondary, fontSize = 11.sp)
                if (!error.isNullOrBlank()) {
                    Text(error, color = Color(0xFFEF5350), fontSize = 12.sp)
                }
                Button(onClick = onSave,
                    enabled = !busy && title.isNotBlank() && title.length <= 200 && artist.length <= 200,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.purple),
                    shape = RoundedCornerShape(14.dp)) {
                    Text(if (busy) mwString("library.saving_song", "Đang lưu...") else mwString("common.save", "Lưu thay đổi"))
                }
            }
        }
    }
}

@Composable
private fun DeleteSongConfirmDialog(
    song: SongItem,
    busy: Boolean,
    error: String?,
    onConfirm: () -> Unit,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
            color = colors.card, border = BorderStroke(1.dp, colors.border)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DialogToolHeader(mwString("library.delete_song", "Xóa bài hát khỏi máy"), song.title, onBack,
                    { if (!busy) onDismiss() })
                Text(mwString("library.delete_song_warning", "Bạn có chắc muốn xóa vĩnh viễn tệp nhạc này khỏi điện thoại? Không thể hoàn tác."),
                    color = colors.textPrimary, fontSize = 14.sp)
                Text("${song.title} • ${mwArtistLabel(song.artist)}", color = colors.textSecondary, maxLines = 2)
                if (!error.isNullOrBlank()) {
                    Text(error, color = Color(0xFFEF5350), fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onBack, modifier = Modifier.weight(1f), enabled = !busy) {
                        Text(mwString("common.cancel", "Hủy"), color = colors.textSecondary)
                    }
                    Button(onClick = onConfirm, enabled = !busy,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E)),
                        shape = RoundedCornerShape(12.dp)) {
                        Text(if (busy) mwString("library.deleting_song", "Đang xóa...") else mwString("library.confirm_delete", "Xóa khỏi máy"), color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioToolRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = colors.cardRaised,
        border = BorderStroke(1.dp, colors.borderSoft)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(modifier = Modifier.size(42.dp), shape = CircleShape, color = colors.purple.copy(alpha = 0.16f)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(22.dp))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = colors.textSecondary, fontSize = 11.sp)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = colors.textMuted)
        }
    }
}

@Composable
private fun CutSongDialog(
    controller: MusicController,
    song: SongItem,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    val maxDuration = song.durationMs.coerceAtLeast(1_000L).toFloat()
    var selectedRange by remember(song.id, maxDuration) { mutableStateOf(0f..maxDuration) }
    Dialog(onDismissRequest = { if (!controller.audioToolBusy) onDismiss() }) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                DialogToolHeader(mwString("library.cut", "Cắt nhạc"), song.title, onBack, onDismiss)
                RangeSlider(
                    value = selectedRange,
                    onValueChange = { proposed ->
                        if (proposed.endInclusive - proposed.start >= 1_000f) selectedRange = proposed
                    },
                    valueRange = 0f..maxDuration,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.purpleBright,
                        activeTrackColor = colors.purple,
                        inactiveTrackColor = colors.borderSoft
                    )
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatDuration(selectedRange.start.toLong()), color = colors.textSecondary)
                    Text(formatDuration(selectedRange.endInclusive.toLong()), color = colors.textSecondary)
                }
                Surface(shape = RoundedCornerShape(14.dp), color = colors.backgroundSoft) {
                    Text(
                        text = mwString("library.cut_length", "Độ dài đoạn cắt: {time}", "time" to formatDuration((selectedRange.endInclusive - selectedRange.start).toLong())),
                        color = colors.textPrimary,
                        modifier = Modifier.padding(14.dp)
                    )
                }
                Button(
                    onClick = {
                        controller.cutLocalSong(song, selectedRange.start.toLong(), selectedRange.endInclusive.toLong())
                        onDismiss()
                    },
                    enabled = !controller.audioToolBusy && selectedRange.endInclusive > selectedRange.start,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                ) {
                    Icon(Icons.Rounded.ContentCut, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(mwString("library.cut_save", "Cắt và lưu"))
                }
            }
        }
    }
}

@Composable
private fun MergeSongDialog(
    controller: MusicController,
    baseSong: SongItem,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    val candidates = controller.localAudioToolSongs(baseSong.id)

    var step by remember(baseSong.id) { mutableStateOf(0) }
    var selected by remember(baseSong.id) { mutableStateOf<SongItem?>(null) }

    val firstMaxDuration = baseSong.durationMs.coerceAtLeast(1_000L).toFloat()
    val secondMaxDuration = selected?.durationMs?.coerceAtLeast(1_000L)?.toFloat() ?: 1_000f
    var firstRange by remember(baseSong.id, firstMaxDuration) {
        mutableStateOf(0f..firstMaxDuration)
    }
    var secondRange by remember(selected?.id, secondMaxDuration) {
        mutableStateOf(0f..secondMaxDuration)
    }

    val previewPlayer = remember { ExoPlayer.Builder(context).build() }
    var previewPrepared by remember { mutableStateOf(false) }
    var previewPlaying by remember { mutableStateOf(false) }
    var previewPositionMs by remember { mutableStateOf(0L) }
    var previewDragging by remember { mutableStateOf(false) }
    var draggedPreviewMs by remember { mutableStateOf(0f) }

    val firstSegmentDuration = (firstRange.endInclusive - firstRange.start)
        .toLong()
        .coerceAtLeast(1L)
    val secondSegmentDuration = (secondRange.endInclusive - secondRange.start)
        .toLong()
        .coerceAtLeast(1L)
    val previewTotalMs = (firstSegmentDuration + secondSegmentDuration).coerceAtLeast(1L)
    val latestPreviewTotalMs by rememberUpdatedState(previewTotalMs)

    fun clippedMediaItem(
        song: SongItem,
        range: ClosedFloatingPointRange<Float>
    ): MediaItem = MediaItem.Builder()
        .setUri(song.uri)
        .setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(range.start.toLong())
                .setEndPositionMs(range.endInclusive.toLong())
                .build()
        )
        .build()

    fun seekPreview(targetMs: Long) {
        val clamped = targetMs.coerceIn(0L, previewTotalMs)
        if (clamped < firstSegmentDuration) {
            previewPlayer.seekTo(0, clamped)
        } else {
            previewPlayer.seekTo(1, (clamped - firstSegmentDuration).coerceAtLeast(0L))
        }
        previewPositionMs = clamped
    }

    fun preparePreview(targetMs: Long = 0L, autoPlay: Boolean = false) {
        val secondSong = selected ?: return
        previewPlayer.pause()
        previewPlayer.setMediaItems(
            listOf(
                clippedMediaItem(baseSong, firstRange),
                clippedMediaItem(secondSong, secondRange)
            )
        )
        previewPlayer.prepare()
        previewPrepared = true
        seekPreview(targetMs)
        if (autoPlay) previewPlayer.play()
    }

    DisposableEffect(previewPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                previewPlaying = isPlaying
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    previewPlaying = false
                    previewPositionMs = latestPreviewTotalMs
                }
            }
        }
        previewPlayer.addListener(listener)
        onDispose {
            previewPlayer.removeListener(listener)
            previewPlayer.release()
        }
    }

    LaunchedEffect(selected?.id, firstRange, secondRange) {
        previewPlayer.pause()
        previewPlayer.clearMediaItems()
        previewPrepared = false
        previewPlaying = false
        previewPositionMs = 0L
        draggedPreviewMs = 0f
    }

    LaunchedEffect(previewPrepared, previewPlayer, firstSegmentDuration, previewTotalMs) {
        while (previewPrepared) {
            if (!previewDragging && previewPlayer.mediaItemCount > 0) {
                val combinedPosition = when (previewPlayer.currentMediaItemIndex) {
                    0 -> previewPlayer.currentPosition
                    1 -> firstSegmentDuration + previewPlayer.currentPosition
                    else -> previewPositionMs
                }
                previewPositionMs = combinedPosition.coerceIn(0L, previewTotalMs)
            }
            delay(100L)
        }
    }

    Dialog(onDismissRequest = { if (!controller.audioToolBusy) onDismiss() }) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(24.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                DialogToolHeader(
                    title = if (step == 0) mwString("library.merge", "Ghép nhạc") else mwString("library.trim_then_merge", "Cắt đoạn rồi ghép"),
                    songTitle = if (step == 0) baseSong.title else "${baseSong.title} + ${selected?.title.orEmpty()}",
                    onBack = {
                        if (step == 0) {
                            onBack()
                        } else {
                            previewPlayer.pause()
                            step = 0
                        }
                    },
                    onDismiss = onDismiss
                )
                Spacer(Modifier.height(10.dp))

                if (step == 0) {
                    Text(mwString("library.first_song", "Bài thứ nhất"), color = colors.textSecondary, fontSize = 12.sp)
                    MergeSelectedSongCard(
                        index = 1,
                        song = baseSong,
                        controller = controller,
                        selected = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(mwString("library.choose_second_song", "Chọn bài hát thứ hai"), color = colors.textSecondary, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))

                    if (candidates.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(mwString("library.no_other_songs_to_merge", "Không có bài hát cục bộ khác để ghép"), color = colors.textSecondary)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(candidates, key = { it.id }) { candidate ->
                                val active = selected?.id == candidate.id
                                MergeSelectedSongCard(
                                    index = 2,
                                    song = candidate,
                                    controller = controller,
                                    selected = active,
                                    onClick = { selected = candidate }
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { step = 1 },
                        enabled = selected != null && !controller.audioToolBusy,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                    ) {
                        Icon(Icons.Rounded.ContentCut, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text(mwString("library.continue_trim", "Tiếp tục cắt hai bài"))
                    }
                } else {
                    val secondSong = selected
                    if (secondSong == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(mwString("library.no_second_song", "Chưa chọn bài hát thứ hai"), color = colors.textSecondary)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(bottom = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                MergeTrimCard(
                                    index = 1,
                                    song = baseSong,
                                    range = firstRange,
                                    maxDuration = firstMaxDuration,
                                    onRangeChange = { firstRange = it }
                                )
                            }
                            item {
                                MergeTrimCard(
                                    index = 2,
                                    song = secondSong,
                                    range = secondRange,
                                    maxDuration = secondMaxDuration,
                                    onRangeChange = { secondRange = it }
                                )
                            }
                            item {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(18.dp),
                                    color = colors.backgroundSoft,
                                    border = BorderStroke(1.dp, colors.borderSoft)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            mwString("library.preview_merged", "Nghe thử kết quả sau khi ghép"),
                                            color = colors.textPrimary,
                                            fontWeight = FontWeight.SemiBold
                                        )

                                        Slider(
                                            value = if (previewDragging) draggedPreviewMs else previewPositionMs.toFloat(),
                                            onValueChange = { value ->
                                                previewDragging = true
                                                draggedPreviewMs = value
                                            },
                                            onValueChangeFinished = {
                                                previewDragging = false
                                                val target = draggedPreviewMs.toLong()
                                                if (!previewPrepared) preparePreview(target, autoPlay = false)
                                                else seekPreview(target)
                                            },
                                            valueRange = 0f..previewTotalMs.toFloat(),
                                            colors = SliderDefaults.colors(
                                                thumbColor = colors.purpleBright,
                                                activeTrackColor = colors.purple,
                                                inactiveTrackColor = colors.borderSoft
                                            )
                                        )

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                formatDuration(
                                                    if (previewDragging) draggedPreviewMs.toLong()
                                                    else previewPositionMs
                                                ),
                                                color = colors.textSecondary,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                formatDuration(previewTotalMs),
                                                color = colors.textSecondary,
                                                fontSize = 12.sp
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                if (previewPlaying) {
                                                    previewPlayer.pause()
                                                } else if (!previewPrepared) {
                                                    preparePreview(previewPositionMs, autoPlay = true)
                                                } else {
                                                    if (previewPositionMs >= previewTotalMs ||
                                                        previewPlayer.playbackState == Player.STATE_ENDED
                                                    ) {
                                                        seekPreview(0L)
                                                    }
                                                    previewPlayer.play()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(13.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = colors.cardRaised)
                                        ) {
                                            Icon(
                                                if (previewPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                                contentDescription = null,
                                                tint = colors.purpleBright
                                            )
                                            Spacer(Modifier.width(7.dp))
                                            Text(
                                                if (previewPlaying) mwString("library.pause_preview", "Tạm dừng nghe thử") else mwString("library.preview_two", "Nghe thử hai đoạn"),
                                                color = colors.textPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                previewPlayer.pause()
                                controller.mergeLocalSongs(
                                    first = baseSong,
                                    second = secondSong,
                                    firstStartMs = firstRange.start.toLong(),
                                    firstEndMs = firstRange.endInclusive.toLong(),
                                    secondStartMs = secondRange.start.toLong(),
                                    secondEndMs = secondRange.endInclusive.toLong()
                                )
                                onDismiss()
                            },
                            enabled = !controller.audioToolBusy &&
                                    firstRange.endInclusive > firstRange.start &&
                                    secondRange.endInclusive > secondRange.start,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                        ) {
                            Icon(Icons.Rounded.PlaylistAdd, contentDescription = null)
                            Spacer(Modifier.width(7.dp))
                            Text(mwString("library.trim_merge_save", "Cắt hai đoạn, ghép và lưu"))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MergeSelectedSongCard(
    index: Int,
    song: SongItem,
    controller: MusicController,
    selected: Boolean,
    onClick: (() -> Unit)? = null
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(if (selected) colors.purple.copy(alpha = 0.20f) else Color.Transparent)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(26.dp),
            shape = CircleShape,
            color = colors.purple.copy(alpha = 0.18f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(index.toString(), color = colors.purpleBright, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(9.dp))
        ArtworkImage(song, controller.artworkFor(song), Modifier.size(48.dp), 10)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (selected) colors.purpleBright else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${mwArtistLabel(song.artist)} · ${song.durationLabel}",
                color = colors.textSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (selected) {
            Icon(Icons.Rounded.Check, contentDescription = null, tint = colors.purpleBright)
        }
    }
}

@Composable
private fun MergeTrimCard(
    index: Int,
    song: SongItem,
    range: ClosedFloatingPointRange<Float>,
    maxDuration: Float,
    onRangeChange: (ClosedFloatingPointRange<Float>) -> Unit
) {
    val colors = LocalMusicColors.current
    val minimumSegment = minOf(1_000f, maxDuration)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = colors.backgroundSoft,
        border = BorderStroke(1.dp, colors.borderSoft)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(28.dp),
                    shape = CircleShape,
                    color = colors.purple.copy(alpha = 0.18f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(index.toString(), color = colors.purpleBright, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.width(9.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        song.title,
                        color = colors.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        mwString("library.drag_trim_handles", "Kéo hai đầu để chọn đoạn cần ghép"),
                        color = colors.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            RangeSlider(
                value = range,
                onValueChange = { proposed ->
                    if (proposed.endInclusive - proposed.start >= minimumSegment) {
                        onRangeChange(proposed)
                    }
                },
                valueRange = 0f..maxDuration,
                colors = SliderDefaults.colors(
                    thumbColor = colors.purpleBright,
                    activeTrackColor = colors.purple,
                    inactiveTrackColor = colors.borderSoft
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    mwString("library.start_at", "Bắt đầu {time}", "time" to formatDuration(range.start.toLong())),
                    color = colors.textSecondary,
                    fontSize = 12.sp
                )
                Text(
                    mwString("library.end_at", "Kết thúc {time}", "time" to formatDuration(range.endInclusive.toLong())),
                    color = colors.textSecondary,
                    fontSize = 12.sp
                )
            }
            Text(
                mwString("library.selected_clip", "Đoạn được chọn: {time}", "time" to formatDuration((range.endInclusive - range.start).toLong())),
                color = colors.purpleBright,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun RingtoneSongDialog(
    controller: MusicController,
    song: SongItem,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DialogToolHeader(mwString("library.ringtone", "Đặt làm nhạc chuông"), song.title, onBack, onDismiss)
                Button(
                    onClick = {
                        controller.setAsRingtone(song, RingtoneManager.TYPE_RINGTONE)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                ) {
                    Icon(Icons.Rounded.PhoneInTalk, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(mwString("library.call_ringtone", "Nhạc chuông cuộc gọi"))
                }
                Button(
                    onClick = {
                        controller.setAsRingtone(song, RingtoneManager.TYPE_NOTIFICATION)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.blue)
                ) {
                    Icon(Icons.Rounded.NotificationsActive, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(mwString("library.notification_sound", "Âm báo thông báo"))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = { controller.restoreDefaultRingtone(RingtoneManager.TYPE_RINGTONE) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(mwString("library.restore_ringtone", "Khôi phục cuộc gọi"), fontSize = 11.sp)
                    }
                    TextButton(
                        onClick = { controller.restoreDefaultRingtone(RingtoneManager.TYPE_NOTIFICATION) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(mwString("library.restore_notification", "Khôi phục thông báo"), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DialogToolHeader(
    title: String,
    songTitle: String,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = mwString("library.back", "Quay lại"), tint = colors.textSecondary)
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 5.dp)) {
            Text(title, color = colors.textPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(songTitle, color = colors.purpleBright, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Rounded.Close, contentDescription = mwString("common.close", "Đóng"), tint = colors.textSecondary)
        }
    }
}