MELOWARE PREMIUM - GIAO DIEN NGAN GON (14/10/2026)

Nguon: MeloWare_15_10_Premium_UI_Full_FIX_Kotlin_20261014.zip.

CHi CAN THAY 2 FILE:
1. MeloWarePremium.kt -> D:\music\app\src\main\java\duc_phi\music\MeloWarePremium.kt
2. meloware_languages.json -> D:\music\app\src\main\assets\meloware_languages.json

GIU NGUYEN cac file khac (dac biet MainActivity.kt, MusicController.kt, build.gradle.kts).
Billling trong Gradle van la com.android.billingclient:billing:9.1.0.

GIAO DIEN MOI:
- Giai thich ngan gon 3 quyen loi DU KIEN: nghe khong quang cao,
  Equalizer nang cao, Google Drive & chia se nang cao.
- Co ghi ro quyen loi CHUA MO, can xac nhan cac tinh nang truoc khi ra mat.
- Dung thu 30 ngay chua kich hoat.
- Chon 6 thang (du kien 1 USD), 12 thang (du kien 2 USD).
- Neu Google Play co bang gia, lay gia theo quoc gia/thong tin Google Play.
- Nut thanh toan VAN DUOC VO HIEU HOA, khong tu dong thu tien hay mo quyen.
- Bo bot van ban dai/bo cuc du so voi man hinh cu; co cuon neu man hinh nho.
- Da ngon ngu: 15 ngon ngu trong file JSON da duoc them 11 key moi/ngon ngu.

LUU Y QUAN TRONG:
Day la giao dien minh hoa quyen loi du kien. Hien tai CHUA co co che
kiem soat quyen Premium, khong co chuc nang an quang cao/chan Equalizer/
chan Drive theo thoi han. Phai duoc nguoi quan ly ung dung chot danh sach
quyen loi va trien khai purchase verification + entitlement + trial truoc khi
mo thanh toan that. Khong chao ban cac quyen loi chua san sang.

SAU KHI CHEP FILE:
Android Studio -> Sync Project with Gradle Files -> Rebuild Project.
Khong can sua SQL/Firebase hay cac file UI khac.

Da kiem tra diff file goc va tinh hop le JSON. Chua build APK/AAB trong moi truong nay.
