DOCFLOW API 36 - SỬA ĐÚNG VỊ TRÍ FILE GRADLE (2026-10-22)

KIỂM TRA BỘ FILE ĐÃ GỬI:
- DOC (2).zip: DOC/build.gradle.kts có AGP 8.10.1, Kotlin 2.2.20: hợp lệ cho API 36.
- DOC/gradle.properties trong ZIP chứa distributionUrl (cấu hình Gradle Wrapper) nhưng đặt sai tên file.
- DOC (2).zip không chứa app/build.gradle.kts hoặc Build Output mới, nên không thể xác minh nguyên nhân lỗi còn lại trên Android Studio.

THAY HAI FILE VÀO DỰ ÁN D:\DocFlowOffline\:
1. gradle.properties (file ngay tại thư mục gốc, KHÔNG ở trong gradle/wrapper/)
2. gradle/wrapper/gradle-wrapper.properties (file BÊN TRONG thư mục gradle/wrapper)

NÊN SAO LƯU CÁC FILE HIỆN CÓ TRƯỚC KHI THAY.
Chỉ áp dụng gradle.properties mẫu nếu file cũ đang chứa dòng distributionUrl như bản ZIP cung cấp.
Nếu file gradle.properties hiện tại có cấu hình riêng, không ghi đè; chỉ đưa distributionUrl sang đúng file wrapper và giữ các thuộc tính Gradle cũ.

GIỮ NGUYÊN:
- build.gradle.kts (Project) với AGP 8.10.1 và Kotlin 2.2.20
- app/build.gradle.kts, đặc biệt applicationId, versionCode, dependency, compileSdk=36, targetSdk=36
- settings.gradle.kts
- Tất cả file Kotlin và AndroidManifest.xml

KIỂM TRA TRÊN WINDOWS POWERSHELL:
cd D:\DocFlowOffline
.\gradlew.bat --version
.\gradlew.bat :app:assembleDebug --console=plain *> "$env:USERPROFILE\Desktop\docflow_sdk36_build.txt"
Sau đó mở file docflow_sdk36_build.txt, gửi khoảng 30-60 dòng đầu tiên chứa 'FAILURE:' hoặc 'e:' / 'What went wrong'.

KIỂM TRA TRONG ANDROID STUDIO:
- Sync Project with Gradle Files
- SDK Manager: Android API 36 đã được cài
- Gradle JDK: JDK 17
- Quan sát Build Output, không suy lỗi chỉ từ dấu gạch chân đỏ ở targetSdk.

LƯU Ý: BỘ PATCH CHỈ SỬA VỊ TRÍ FILE CẤU HÌNH, CHƯA BUILD ĐƯỢC APK trong môi trường này; ZIP người dùng cung cấp không phải project Android hoàn chỉnh.
