TUNERTOOLS AI - SUA DANH SACH BAI HAT TAI TU GOOGLE DRIVE
Ngay: 07-11-2026

NGUYEN NHAN DA XAC NHAN:
- SongRepository.kt -> SongScraper.getAvailableCachedSongs() ban truoc chi goi Python:
  https://api.tunertools.top/api/get_cached_songs
- Python quet ZING_JSON, su dung ZING_AUDIO de gan co has_audio_cache.
  Neu doi ten ZING_AUDIO tren Windows, Python bao cache audio=false.
- api_ai_media_drive.php ban truoc chi co health/lookup/stream/lyrics,
  CHUA co API danh sach. Test HTTP 206 chi chung minh STREAM hoat dong.

CAC FILE TRONG GOI:
1. api_ai_media_drive.php  (DA SUA) -> UPLOAD len Alwaysdata, thay file cu:
   https://tuner.alwaysdata.net/api_ai_media_drive.php
2. SongRepository.kt    (DA SUA) -> Android Studio:
   app/src/main/java/ducphi/tunnerinstrument/SongRepository.kt
3. SongMainScreen.kt    (GIU NGUYEN so voi ban Drive-first 07/11) -> kem de dong bo ban.
4. Hai file .txt co noi dung giong file .kt, dung neu trinh duyet chan tai .kt.
5. TEST_DRIVE_CACHED_LIST.ps1 -> kiem tra API danh sach tren Drive.

THAY DOI:
A. PHP Alwaysdata them action=cached_songs. No lay danh sach tu Drive:
   My Drive/TunerTools_AppBackup/AI_Music/stream_cache (audio)
   My Drive/TunerTools_AppBackup/AI_Music/lyrics (JSON / metadata).
   Truyen Google Drive files.list co phan trang, cache 600 giay.
   Khong can Python hay duong dan ZING_AUDIO o Windows cho danh sach tren Drive.
   Tra ve ID, ten bai, ca si, co audio, co loi. Khong tra ve Drive file ID.
   Neu chua co JSON metadata tren Drive, bai co the hien ten 'Zing <ID>'.
   YouTube co the hien 'YouTube <ID>' khi chua co metadata server.
   Giu cac phien ban Zing JSON cung ID nhung khac ca si.
B. SongRepository.kt: goi action=cached_songs tren Drive truoc.
   Sau do hop nhat voi Python catalog de bo sung cac bai CHUA upload Drive,
   tuyet doi khong de Python has_audio_cache=false ghi de Drive=true.
   Neu Python mat ket noi, van co danh sach Drive; nguoc lai co Python fallback.
   Logcat: AiDriveSource -> Cached catalog: drive=..., python=..., result=...
C. SongMainScreen.kt khong doi: phat audio van dung uu tien Drive-first da sua.
D. KHONG SUA api_songs.php IIS, api_gp_drive.php, drive_token.json, app.py.

THU TU TRIỂN KHAI:
1. Neu ban da doi ten ZING_AUDIO -> ZING_AUDIO2 tren may chu production,
   DOI TEN LAI ZING_AUDIO DE TRA LAI TRANG THAI CU CHO APP DANG DUNG.
2. Sao luu api_ai_media_drive.php dang chay tren Alwaysdata.
3. Upload api_ai_media_drive.php trong ZIP len Alwaysdata dung folder dang chay API cu.
   Khong ghi de drive_token.json va khong public token.
4. Kiem tra API nhu sau:
   https://tuner.alwaysdata.net/api_ai_media_drive.php?action=health
   https://tuner.alwaysdata.net/api_ai_media_drive.php?action=cached_songs
   Hoac PowerShell:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\PATH\TEST_DRIVE_CACHED_LIST.ps1"
5. Phai thay SongRepository.kt trong Android Studio, Sync/Build APK moi.
   SongMainScreen.kt chi can thay neu chua ap dung ban Drive-first truoc do.
6. Mo danh sach AI tren dien thoai, xem Logcat AiDriveSource.
   Kiem tra Drive >0, result >0, has_audio_cache=true voi Zing ID co tren Drive.
7. Khi da co API moi va APK moi, kiem tra trong moi truong test; KHONG
   doi ten thu muc cache production de tranh anh huong nguoi dung cu.

LUU Y:
- API catalog chi doc file; khong xoa, doi ten, upload hay phan tich AI.
- Ket qua health/lookup/HTTP 206 da test truoc KHONG khang dinh catalog hoat dong.
- PHP lint: PASS. Ham tach catalog thu bang file mau: PASS.
- Phan Kotlin moi da compile voi stub API: PASS; test hop nhat hai ca si: PASS.
- CHUA build toan bo Android Gradle, CHUA trien khai hay test catalog tren Alwaysdata that.
- Phan cong khai danh sach TEN BAI HAT/CA SI tuong duong endpoint Python cu;
  khong su dung neu metadata chua duoc phep cong khai.
- Ket qua duoc cache toi da 600 giay. Neu vua upload file moi, can doi cache het han.
