$ErrorActionPreference = 'Stop'
$url = 'https://tuner.alwaysdata.net/api_ai_media_drive.php?action=cached_songs'
Write-Host '=== TUNERTOOLS AI DRIVE CATALOG TEST ===' -ForegroundColor Cyan
try {
    $result = Invoke-RestMethod -Uri $url -TimeoutSec 120
    if (-not $result.ok -or $result.source -ne 'google_drive') {
        throw 'API did not return ok=true / source=google_drive.'
    }
    $all = @($result.songs)
    Write-Host "Source    : $($result.source)"
    Write-Host "Songs     : $($all.Count)"
    Write-Host "AudioFiles: $($result.audio_entries_scanned)"
    Write-Host "JsonFiles : $($result.json_entries_scanned)"
    Write-Host 'Zing example (18JJ0AEDF3CO):'
    $all | Where-Object { $_.id -eq '18JJ0AEDF3CO' } |
        Select-Object -First 5 id, title, singer, has_audio_cache, has_lyrics_cache |
        Format-Table -AutoSize
    if ($all.Count -eq 0) {
        Write-Warning 'Drive catalog empty: check files in /AI_Music/stream_cache and /lyrics.'
    }
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        Write-Host "HTTP: $([int]$_.Exception.Response.StatusCode)" -ForegroundColor Red
    }
    exit 1
}
