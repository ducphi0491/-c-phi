/* Downloads only a locally generated, privacy-filtered ZIP. No outbound data transfer. */
'use strict';
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.kind !== 'ledutu-save-report-v3') return false;
  let allowed = false;
  try {const u = new URL(sender.url || sender.tab?.url || ''); allowed = (u.protocol === 'https:' && (u.hostname === 'ledutu.com' || u.hostname === 'www.ledutu.com'));} catch (_) {}
  if (!allowed || typeof message.base64 !== 'string' || message.base64.length < 100 || message.base64.length > 4000000 || !/^[A-Za-z0-9+/=]+$/.test(message.base64)) {
    sendResponse({ok:false, error:'Du lieu xuat khong hop le hoac tab khong phai Ledutu.'});
    return false;
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `Ledutu-Monitor/CHIA_SE_VOI_CHATGPT_${stamp}.zip`;
  chrome.downloads.download({url:'data:application/zip;base64,' + message.base64, filename, saveAs:false, conflictAction:'uniquify'}, (id) => {
    const err = chrome.runtime.lastError;
    if (err || !Number.isInteger(id)) sendResponse({ok:false, error:err?.message || 'Khong luu duoc tep ZIP.'});
    else sendResponse({ok:true, filename});
  });
  return true;
});
