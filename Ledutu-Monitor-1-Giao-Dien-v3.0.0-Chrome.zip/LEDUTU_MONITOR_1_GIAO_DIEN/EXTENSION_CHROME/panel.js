/* Ledutu Monitor 3.0 - all controls in one floating panel inside existing Chrome tab. */
(() => {
  'use strict';
  if (window.top !== window.self) return;
  const CHANNEL='ledutu-monitor-v3-ui-bridge';
  const STORAGE='ledutu-monitor-v3-session';
  const MAX_EVENTS=300;
  const ALLOWED=/^(model_terms|model_header|id|generation_id|job_id|task_id|status|state|stage|progress|percentage|percent|error_code|failure_code|model|model_name|model_id|model_version|model_type|pipeline|pipeline_version|engine|provider|worker|worker_type|stem|stems|stem_model|separation_model|transcription_model|transcriber|task_type|task_name|kind|type|version|ml_service|ml_backend|ml_provider|status_code|items_count|note|data|result|generation|job|task|meta|metadata|progress_info|error|details|payload|steps|stage_info|events)$/i;
  const BLOCK=/(token|secret|password|auth|cookie|session|credential|api.?key|signature|access.?key|csrf|email|phone|user|address|url|uri|youtube|video|lyrics|title|content|audio|file|path|signed|^name$)/i;
  const state={active:false,startedAt:'',events:[],dropped:0,lastStage:'Chua bat dau'};
  let ready=false;
  let saveWait=null;
  let shadow, host, ui;
  const safeText=(v,max=120) => {
    if (typeof v==='number') return Number.isFinite(v) ? v : null;
    if (typeof v==='boolean') return v;
    if (typeof v!=='string') return null;
    const text=v.trim();
    return text && text.length<=max && !/https?:\/\/|@|Bearer\s|[?&](?:key|token)=/i.test(text) && !/^[\w+/=-]{85,}$/.test(text) ? text : null;
  };
  function filterMeta(obj,depth=0) {
    if (!obj || typeof obj!=='object' || depth>4) return {};
    if (Array.isArray(obj)) return obj.slice(0,8).map(x=>(x&&typeof x==='object')?filterMeta(x,depth+1):safeText(x)).filter(x=>x!==null);
    const out={}; let count=0;
    for (const [k,v] of Object.entries(obj)) {
      if (++count>80) break;
      if (!ALLOWED.test(k)||BLOCK.test(k)) continue;
      if (typeof v==='object' && v!==null) out[k]=filterMeta(v,depth+1);
      else {const clean=safeText(v); if(clean!==null)out[k]=clean;}
    }
    return out;
  }
  function buildPanel() {
    host=document.createElement('div');
    host.id='ledutu-monitor-panel-v3';
    host.style.cssText='position:fixed!important;bottom:18px!important;right:18px!important;z-index:2147483647!important;max-width:calc(100vw - 24px)!important;';
    shadow=host.attachShadow({mode:'open'});
    const style=document.createElement('style');
    style.textContent=`
      :host{all:initial;color-scheme:light!important} *{box-sizing:border-box!important}
      .panel{width:354px;max-width:calc(100vw - 24px);background:#fff;color:#1f2937;font:13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;border:1px solid #cbd5e1;border-radius:15px;box-shadow:0 14px 45px rgba(14,27,47,.26);overflow:hidden}
      .header{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;color:white;background:#13345a}
      .head-main{display:flex;align-items:center;gap:8px;font-weight:700;font-size:14px}
      .dot{width:9px;height:9px;border-radius:50%;background:#a3b6c9;display:inline-block}
      .dot.on{background:#50e2a0;box-shadow:0 0 0 3px #50e2a02b}
      .head-mini{border:1px solid #6883a0;background:transparent;color:white;border-radius:6px;cursor:pointer;padding:2px 8px;font-size:16px}
      .body{padding:13px}.body.hidden{display:none}
      .intro{font-weight:700;margin-bottom:9px;font-size:14px}
      .steps{background:#f1f5f9;border-radius:8px;padding:9px 11px;font-size:12px;color:#334155;line-height:1.7}
      .status{margin-top:10px;font-weight:700;color:#334155;display:flex;align-items:center;gap:7px}
      .pill{border-radius:20px;background:#e8edf4;color:#475569;padding:2px 9px;font-size:11px;font-weight:700}
      .pill.on{background:#d1fae5;color:#065f46}.pill.done{background:#dbeafe;color:#1e40af}
      .line{margin:6px 0;color:#64748b;font-size:12px}.events{height:82px;overflow:auto;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:7px 8px;color:#475569;white-space:pre-line;font-size:11px}
      .buttons{display:flex;gap:8px;margin-top:10px}.btn{border:0;border-radius:8px;padding:9px 10px;cursor:pointer;font-size:12px;font-weight:700;flex:1;min-height:38px}
      .start{background:#087a5f;color:#fff}.save{background:#1e5e9a;color:#fff}.clear{background:#e9edf3;color:#334155;flex:0 0 70px}
      .btn[disabled]{opacity:.45;cursor:not-allowed}.notice{margin-top:10px;color:#6b7280;font-size:11px}.error{color:#b91c1c!important}
    `;
    shadow.appendChild(style);
    const container=document.createElement('div');
    container.className='panel';
    container.innerHTML=`
      <div class="header"><span class="head-main"><span class="dot" id="dot"></span> LEDUTU MONITOR <small style="font-weight:400;opacity:.75">v3.0</small></span><button class="head-mini" id="mini" title="Thu gon">−</button></div>
      <div class="body" id="body">
        <div class="intro">Ngay trên trang Ledutu này</div>
        <div class="steps">1. Bấm <b>BẮT ĐẦU</b>.<br>2. Dán link và tạo sheet như bình thường.<br>3. Có kết quả → bấm <b>XUẤT ZIP</b>.</div>
        <div class="status"><span class="pill" id="pill">CHƯA GHI</span><span id="stage">Sẵn sàng</span></div>
        <div class="line" id="count">0 sự kiện đã ghi</div>
        <div class="events" id="log">Chờ bạn bắt đầu...</div>
        <div class="buttons"><button class="btn start" id="start">BẮT ĐẦU</button><button class="btn save" id="export" disabled>XUẤT ZIP</button><button class="btn clear" id="reset" title="Xoa phien cu">LÀM MỚI</button></div>
        <div class="notice" id="notice">Không cần Python, BAT hoặc đăng nhập lại. Chỉ lưu thông tin kỹ thuật đã lọc.</div>
      </div>`;
    shadow.appendChild(container);
    ui={
      dot:shadow.getElementById('dot'),mini:shadow.getElementById('mini'),body:shadow.getElementById('body'),
      pill:shadow.getElementById('pill'),stage:shadow.getElementById('stage'),count:shadow.getElementById('count'),
      log:shadow.getElementById('log'),start:shadow.getElementById('start'),export:shadow.getElementById('export'),reset:shadow.getElementById('reset'),notice:shadow.getElementById('notice')
    };
    ui.start.addEventListener('click',()=>{
      if(state.active) {
        state.active=false; tellBridge('stop'); note('Da dung ghi. Bam XUẤT ZIP de luu.');
      } else {
        state.active=true;state.events=[];state.dropped=0;state.startedAt=new Date().toISOString();state.lastStage='Dang cho tao sheet';
        tellBridge('start');note('Dang theo doi; hay dan link va tao sheet ngay tren Ledutu.');
      }
      scheduleSave(true);refresh();
    });
    ui.export.addEventListener('click', exportZip);
    ui.reset.addEventListener('click',()=>{
      state.active=false;state.events=[];state.dropped=0;state.startedAt='';state.lastStage='Chua bat dau';
      tellBridge('stop');note('Da xoa phien ghi.');scheduleSave(true);refresh();
    });
    ui.mini.addEventListener('click',()=>{const isHidden=ui.body.classList.toggle('hidden');ui.mini.textContent=isHidden?'+':'−';});
    document.documentElement.appendChild(host);
    ready=true;
    refresh();
  }
  function tellBridge(action) {window.postMessage({channel:CHANNEL,direction:'panel-to-bridge',action},window.location.origin);}
  function scheduleSave(immediate=false) {
    if(saveWait)clearTimeout(saveWait);
    if (immediate) {chrome.storage.local.set({[STORAGE]:state});return;}
    saveWait=setTimeout(()=>{saveWait=null;chrome.storage.local.set({[STORAGE]:state});},250);
  }
  function note(text,isError=false) {if(ui){ui.notice.textContent=text;ui.notice.classList.toggle('error',isError);}}
  function detectStage(meta,depth=0) {
    if(!meta||typeof meta!=='object'||depth>4)return '';
    for(const [k,v] of Object.entries(meta)) if (/^(status|state|stage)$/i.test(k) && typeof v==='string' && v.length<70)return v;
    for(const v of Object.values(meta)) if(v&&typeof v==='object'){const s=detectStage(v,depth+1);if(s)return s;}
    return '';
  }
  function label(ev) {
    const meta=ev.metadata||{};
    const status=detectStage(meta);
    const code=ev.status_code||0;
    const path=ev.path.split('/').slice(0,6).join('/');
    return `${(ev.at||'').slice(11,19)}  ${status||ev.method+' '+path}  ${code||''}`;
  }
  function refresh() {
    if(!ready)return;
    ui.dot.classList.toggle('on',state.active);
    ui.pill.className='pill'+(state.active?' on':(/completed|finished|success|done/i.test(state.lastStage)?' done':''));
    ui.pill.textContent=state.active?'ĐANG GHI':'DỪNG GHI';
    ui.stage.textContent=state.lastStage;
    ui.count.textContent=`${state.events.length} su kien da loc${state.dropped?' (+'+state.dropped+' qua gioi han)':''}`;
    ui.start.textContent=state.active?'DỪNG GHI':'BẮT ĐẦU';
    ui.export.disabled=state.events.length===0;
    ui.log.textContent=state.events.length?state.events.slice(-7).map(label).join('\n'):'Chua co yeu cau API tao sheet nao.';
    ui.log.scrollTop=ui.log.scrollHeight;
  }
  function record(data) {
    if(!state.active)return;
    const path=typeof data.path==='string'?data.path:'';
    if(!/^\/(?:api\/(?:generations|jobs|transcriptions)|account\/scriptor|scriptor)(?:\/|$)/.test(path))return;
    const event={at:typeof data.at==='string'?data.at.slice(0,40):new Date().toISOString(), kind:safeText(data.kind,20)||'network', method:safeText(data.method,10)||'GET', path:path.slice(0,200),status_code:Number(data.status_code)||0, metadata:filterMeta(data.metadata)};
    if(state.events.length>=MAX_EVENTS){state.events.shift();state.dropped++;}
    state.events.push(event);
    const step=detectStage(event.metadata);
    const terminal = /^(completed|complete|finished|done|failed|cancelled|canceled|expired|success)$/i;
    if(step && !(terminal.test(state.lastStage) && !terminal.test(step)))state.lastStage=step;
    else if(!step && state.events.length===1)state.lastStage='Đang ghi API';
    if(/^(completed|complete|finished|done|failed|cancelled|canceled|expired|success)$/i.test(step))note('Da nhan trang thai ket thuc. Ban co the bam XUẤT ZIP.');
    scheduleSave();refresh();
  }
  window.addEventListener('message',(e)=>{
    if(e.source!==window||e.origin!==window.location.origin)return;
    const d=e.data;
    if(d?.channel===CHANNEL && d.direction==='bridge-to-panel')record(d);
  });
  function reportSummary() {
    const statuses=[]; const models=[];const errors=[];const ids=[];
    function collect(o) {
      if(!o||typeof o!=='object')return;
      if(Array.isArray(o)){o.slice(0,8).forEach(collect);return;}
      for(const [k,v] of Object.entries(o)){
        if(k==='model_terms' && Array.isArray(v)) v.forEach(t=>{if(typeof t==='string')models.push('model_terms = '+t);});
        else if(typeof v==='object')collect(v);
        else if(typeof v==='string') {
          if(/^(status|state|stage)$/i.test(k))statuses.push(v);
          if(/(?:model|pipeline|engine|provider|transcriber|ml_backend|stem_model)/i.test(k))models.push(k+' = '+v);
          if(/error_code|failure_code/i.test(k))errors.push(k+' = '+v);
          if(/^(id|generation_id|job_id|task_id)$/i.test(k))ids.push(k+' = '+v);
        }
      }
    }
    state.events.forEach(x=>collect(x.metadata));
    const uniq=(a)=>Array.from(new Set(a)).slice(0,60);
    return [
      'LEDUTU MONITOR v3.0 - BAO CAO THU THAP METADATA',
      'Bat dau: '+(state.startedAt||'khong ro'),
      'Xuat bao cao: '+new Date().toISOString(),
      'So su kien: '+state.events.length,
      'So su kien bi cat do gioi han: '+state.dropped,
      '', 'Trang thai:',...(uniq(statuses).length?uniq(statuses):['(khong thay trong response)']),
      '', 'Ma cong viec:',...(uniq(ids).length?uniq(ids):['(khong thay)']),
      '', 'Dau vet model / pipeline:',...(uniq(models).length?uniq(models):['(khong duoc server cong khai trong su kien da ghi)']),
      '', 'Ma loi:',...(uniq(errors).length?uniq(errors):['(khong co)']),
      '', 'GIOI HAN: Theo doi API nhin thay tu tab Ledutu; khong thay server-to-server hay ten model neu server khong gui. Khong the tu khang dinh model AI.',
      'BAO MAT: Khong ghi body request, cookie, header Authorization, YouTube URL, email hay mat khau. Van can mo va kiem tra bao cao truoc khi chia se.'
    ].join('\r\n');
  }
  // ZIP with STORE method, 100% local; no CDN, no remote reporting service.
  const utf8=new TextEncoder();
  const crcTable=(()=>{const a=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let j=0;j<8;j++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);a[n]=c>>>0;}return a;})();
  const crc=(bytes)=>{let c=0xFFFFFFFF;for(const b of bytes)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;};
  function makeZip(files) {
    const locals=[];const central=[];let offset=0;
    const now=new Date();const dosTime=((now.getHours()&31)<<11)|((now.getMinutes()&63)<<5)|((Math.floor(now.getSeconds()/2))&31);
    const dosDate=(((now.getFullYear()-1980)&127)<<9)|(((now.getMonth()+1)&15)<<5)|(now.getDate()&31);
    const short=(view,at,val)=>view.setUint16(at,val&65535,true);
    const long=(view,at,val)=>view.setUint32(at,val>>>0,true);
    for(const [name,contents] of files) {
      const n=utf8.encode(name), b=utf8.encode(contents), c=crc(b);
      const local=new Uint8Array(30+n.length),lv=new DataView(local.buffer);
      long(lv,0,0x04034b50);short(lv,4,20);short(lv,6,0x0800);short(lv,8,0);short(lv,10,dosTime);short(lv,12,dosDate);
      long(lv,14,c);long(lv,18,b.length);long(lv,22,b.length);short(lv,26,n.length);short(lv,28,0);local.set(n,30);
      locals.push(local,b);
      const cen=new Uint8Array(46+n.length),cv=new DataView(cen.buffer);
      long(cv,0,0x02014b50);short(cv,4,20);short(cv,6,20);short(cv,8,0x0800);short(cv,10,0);short(cv,12,dosTime);short(cv,14,dosDate);
      long(cv,16,c);long(cv,20,b.length);long(cv,24,b.length);short(cv,28,n.length);short(cv,30,0);short(cv,32,0);short(cv,34,0);short(cv,36,0);long(cv,38,0);long(cv,42,offset);cen.set(n,46);
      central.push(cen);offset+=local.length+b.length;
    }
    const centralSize=central.reduce((s,x)=>s+x.length,0);
    const end=new Uint8Array(22),v=new DataView(end.buffer);
    long(v,0,0x06054b50);short(v,4,0);short(v,6,0);short(v,8,files.length);short(v,10,files.length);
    long(v,12,centralSize);long(v,16,offset);short(v,20,0);
    const total=offset+centralSize+end.length;
    const all=new Uint8Array(total);let pos=0;
    for(const chunk of [...locals,...central,end]){all.set(chunk,pos);pos+=chunk.length;}
    return all;
  }
  function b64(bytes){let binary='';for(let i=0;i<bytes.length;i+=16000)binary+=String.fromCharCode(...bytes.subarray(i,i+16000));return btoa(binary);}
  async function exportZip() {
    if(!state.events.length){note('Chua ghi duoc API. Hay bam BẮT ĐẦU truoc khi tao sheet.',true);return;}
    try {
      // Stop to ensure a stable report, without changing the Ledutu tab or job.
      state.active=false;tellBridge('stop');scheduleSave(true);refresh();
      ui.export.disabled=true;note('Dang tao ZIP ngay trong Chrome...');
      const evidence={tool:'Ledutu Monitor v3.0',saved_at:new Date().toISOString(),started_at:state.startedAt,events:state.events,dropped:state.dropped,scope:'Only metadata from user-visible Ledutu requests; no private server internals'};
      const zipped=makeZip([
        ['BAO_CAO_CHIA_SE.txt',reportSummary()],
        ['evidence.json',JSON.stringify(evidence,null,2)],
        ['HUONG_DAN_GUI_LAI.txt','Gui ZIP nay vao ChatGPT. Du lieu da loc tu dong, nhung nen mo BAO_CAO_CHIA_SE.txt va evidence.json kiem tra truoc khi chia se. Khong gui profile Chrome hoac cookie.']
      ]);
      const encoded=b64(zipped);
      const result=await chrome.runtime.sendMessage({kind:'ledutu-save-report-v3',base64:encoded});
      if(!result?.ok)throw new Error(result?.error||'Chrome khong luu duoc ZIP.');
      note('DA TAI ZIP! Mo thu muc Downloads > Ledutu-Monitor.');
    } catch (err) {note('Loi khi tai ZIP: '+String(err?.message||err).slice(0,150),true);}
    finally {refresh();}
  }
  function mount() {if(ready)return; if(!document.documentElement){setTimeout(mount,30);return;}
    buildPanel();
    chrome.storage.local.get(STORAGE,(data)=>{
      const old=data?.[STORAGE];
      if(old&&typeof old==='object') {
        state.active=Boolean(old.active);
        state.startedAt=safeText(old.startedAt,50)||'';
        state.lastStage=safeText(old.lastStage,70)||'Sẵn sàng';
        state.events=Array.isArray(old.events)?old.events.slice(-MAX_EVENTS).map(x=>({at:safeText(x.at,40)||'',kind:safeText(x.kind,20)||'',method:safeText(x.method,10)||'',path:safeText(x.path,200)||'',status_code:Number(x.status_code)||0,metadata:filterMeta(x.metadata)})):[];
        state.dropped=Number(old.dropped)||0;
        if(state.active){tellBridge('start');note('Da tiep tuc phien ghi sau khi trang duoc tai lai.');}
      }
      refresh();
    });
  }
  if(document.documentElement)mount();else document.addEventListener('readystatechange',mount,{once:true});
  window.addEventListener('pagehide',()=>{if(ready)scheduleSave(true);});
})();
