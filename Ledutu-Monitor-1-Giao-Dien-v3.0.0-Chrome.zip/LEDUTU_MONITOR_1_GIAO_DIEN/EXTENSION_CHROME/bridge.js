/* Ledutu Monitor v3.0 - MAIN world: passive, restricted capture, no request mutation */
(() => {
  'use strict';
  if (window.__LEDUTU_MONITOR_BRIDGE_V30__) return;
  Object.defineProperty(window, '__LEDUTU_MONITOR_BRIDGE_V30__', { value: true });
  const CHANNEL = 'ledutu-monitor-v3-ui-bridge';
  let recording = false;
  let sequence = 0;
  const MAX_BODY = 380000;
  const MODEL_TERMS = /basic[ _-]?pitch|demucs|htdemucs(?:_ft)?|mdx[ _-]?net|\bmt3\b|tensorflow|pytorch|torchscript|\bonnx\b|onnxruntime|spleeter|open[ _-]?unmix|omnizart|music21|replicate|runpod|hugging[ _-]?face|modal(?:\.com)?|sagemaker|vertex[ _-]?ai|transkun/gi;
  const ALLOWED_KEY = /^(model_terms|model_header|id|generation_id|job_id|task_id|status|state|stage|progress|percentage|percent|error_code|failure_code|model|model_name|model_id|model_version|model_type|pipeline|pipeline_version|engine|provider|worker|worker_type|stem|stems|stem_model|separation_model|transcription_model|transcriber|task_type|task_name|kind|type|version|ml_service|ml_backend|ml_provider|status_code)$/i;
  const GROUP_KEY = /^(data|result|generation|job|task|meta|metadata|progress_info|error|details|payload|steps|stage_info|events)$/i;
  const SECRET_KEY = /(?:token|secret|password|auth|cookie|session|credential|api.?key|signature|access.?key|csrf|email|phone|user|address|url|uri|youtube|video|lyrics|title|content|audio|file|path|signed|^name$)/i;
  const LAST_PATH = /\/api\/generations(?:\/|$)|\/api\/transcriptions(?:\/|$)|\/api\/jobs(?:\/|$)|\/account\/scriptor(?:\/|$)|\/scriptor(?:\/|$)/i;
  function relevant(input) {
    try {
      const url = new URL(String(input || ''), window.location.href);
      if (url.origin !== window.location.origin || !LAST_PATH.test(url.pathname)) return null;
      return url.pathname.slice(0, 200);
    } catch (_) { return null; }
  }
  function str(value) {
    if (value === null || value === undefined) return null;
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    if (typeof value === 'boolean') return value;
    if (typeof value !== 'string') return null;
    const v = value.trim();
    if (!v || v.length > 120 || /@|https?:\/\/|Bearer\s|[?&](?:token|key)=/i.test(v)) return null;
    if (/^[A-Za-z0-9+/_-]{85,}={0,2}$/.test(v)) return null;
    if (/[\x00-\x08\x0e-\x1f]/.test(v)) return null;
    return v;
  }
  function filter(value, depth = 0, root = true) {
    if (depth > 4 || !value || typeof value !== 'object') return null;
    if (Array.isArray(value)) {
      const items = value.slice(0, 8).map(x => filter(x, depth + 1, false)).filter(x => x && Object.keys(x).length);
      return items.length ? items : {items_count: value.length};
    }
    const out = {};
    let limit = 0;
    for (const [key, val] of Object.entries(value)) {
      if (++limit > 80) break;
      if (SECRET_KEY.test(key)) continue;
      if (ALLOWED_KEY.test(key)) {
        if (key.toLowerCase() === 'id' && !root) continue;
        if (Array.isArray(val)) {
          out[key] = val.slice(0, 8).map(x => (typeof x === 'object' ? filter(x, depth + 1, false) : str(x))).filter(x => x !== null);
        } else if (val && typeof val === 'object') {
          const nested = filter(val, depth + 1, false); if (nested && Object.keys(nested).length) out[key] = nested;
        } else {
          const sanitized = str(val); if (sanitized !== null) out[key] = sanitized;
        }
      } else if (GROUP_KEY.test(key) && val && typeof val === 'object') {
        const nested = filter(val, depth + 1, false);
        if (nested && Object.keys(nested).length) out[key] = nested;
      }
    }
    return out;
  }
  function textMetadata(txt) {
    if (typeof txt !== 'string' || !txt || txt.length > MAX_BODY) return {note: 'bo qua noi dung response qua lon'};
    let parsed;
    try {parsed = JSON.parse(txt);} catch (_) {parsed = null;}
    const foundTerms = Array.from(new Set((txt.match(MODEL_TERMS) || []).map(s=>s.toLowerCase()))).slice(0, 16);
    const addTerms = (obj) => {if(foundTerms.length)obj.model_terms=foundTerms;return obj;};
    if (parsed && typeof parsed === 'object') return addTerms(filter(parsed) || {});
    if (parsed && typeof parsed !== 'object') return addTerms({});
    const candidates = [];
    const lines = txt.split(/[\r\n]+/).slice(0, 120);
    for (const line of lines) {
      if (/^(?:data\s*:|\d+\s*:)/.test(line.trim())) {
        let raw = line.trim().replace(/^(?:data\s*:|\d+\s*:)/, '').trim();
        try {const p = JSON.parse(raw); const x = filter(p); if (x && Object.keys(x).length) candidates.push(x);} catch (_) {}
      }
    }
    if (candidates.length) return addTerms({events: candidates.slice(0, 8)});
    // Parse only explicit metadata field names, never arbitrary text/URLs.
    const keys = '(?:generation_id|job_id|task_id|status|state|stage|progress|error_code|model(?:_name|_id|_version)?|pipeline(?:_version)?|engine|provider|worker|stem|transcriber)';
    const re = new RegExp('["\\\\]*(' + keys + ')["\\\\]*\\s*:\\s*["\\\\]*([^"\\\\,}\\r\\n]{1,70})', 'gi');
    const found = {}; let m; let iterations = 0;
    while ((m = re.exec(txt)) && ++iterations < 50) {
      const value = str(m[2]); if (value !== null) found[m[1]] = value;
    }
    return addTerms(found);
  }
  function headerMeta(get) {
    const out={};
    for(const [name,key] of [['x-model','model_header'],['x-model-version','model_version'],['x-pipeline-version','pipeline_version'],['x-worker','worker']]) {
      try {const val=str(get(name));if(val!==null)out[key]=val;} catch (_) {}
    }
    return out;
  }
  function notify(kind, path, method, code, metadata) {
    if (!recording || !path) return;
    const report = { channel: CHANNEL, direction: 'bridge-to-panel', kind, path, method: String(method || 'GET').slice(0, 10), status_code: Number(code) || 0, at: new Date().toISOString(), seq: ++sequence, metadata: metadata || {} };
    window.postMessage(report, window.location.origin);
  }
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== window.location.origin) return;
    const d = e.data;
    if (!d || d.channel !== CHANNEL || d.direction !== 'panel-to-bridge') return;
    if (d.action === 'start') recording = true;
    else if (d.action === 'stop') recording = false;
  });
  const savedFetch = window.fetch;
  if (typeof savedFetch === 'function') {
    window.fetch = function (...args) {
      const req = args[0];
      const path = relevant(typeof req === 'string' || req instanceof URL ? req : req?.url);
      const method = args[1]?.method || (req && typeof req === 'object' ? req.method : null) || 'GET';
      const promise = savedFetch.apply(this, args);
      if (!path || !recording) return promise;
      promise.then((response) => {
        const type = response.headers.get('content-type') || '';
        if (/json|text|event-stream|x-component/i.test(type)) {
          response.clone().text().then(t => notify('fetch', path, method, response.status, {...textMetadata(t),...headerMeta(n=>response.headers.get(n))})).catch(() => notify('fetch', path, method, response.status, headerMeta(n=>response.headers.get(n))));
        } else {notify('fetch', path, method, response.status, headerMeta(n=>response.headers.get(n)));}
      }, () => notify('fetch_error', path, method, 0, {}));
      return promise;
    };
  }
  const proto = window.XMLHttpRequest?.prototype;
  if (proto) {
    const oldOpen = proto.open, oldSend = proto.send;
    const info = new WeakMap();
    proto.open = function(method, url, ...args) {
      info.set(this, {path: relevant(url), method});
      return oldOpen.call(this, method, url, ...args);
    };
    proto.send = function(...args) {
      const m = info.get(this);
      if (m?.path && recording) {
        this.addEventListener('loadend', () => {
          let body = '';
          try {if (this.responseType === '' || this.responseType === 'text') body = this.responseText;} catch (_) {}
          notify('xhr', m.path, m.method, this.status, {...textMetadata(body),...headerMeta(n=>this.getResponseHeader(n))});
        }, {once:true});
      }
      return oldSend.apply(this, args);
    };
  }
  const OriginalEventSource = window.EventSource;
  if (typeof OriginalEventSource === 'function') {
    window.EventSource = class MonitoredEventSource extends OriginalEventSource {
      constructor(url, ...args) {
        super(url, ...args);
        const path = relevant(url);
        if (path) this.addEventListener('message', (ev) => {notify('sse', path, 'GET', 200, textMetadata(ev.data));});
      }
    };
  }
  window.postMessage({channel: CHANNEL, direction:'bridge-ready'}, window.location.origin);
})();
