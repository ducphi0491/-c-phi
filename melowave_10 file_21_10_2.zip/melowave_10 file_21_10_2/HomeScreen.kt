package duc_phi.music

import android.app.Activity
import android.graphics.Color as AndroidColor
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.provider.Settings
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import java.text.DateFormat
import java.util.Date
import org.json.JSONArray
import org.json.JSONObject
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import android.util.Log
import kotlin.math.pow
import coil.request.ImageRequest
// region Merged source: HomeScreen.kt
@Composable
internal fun HomeScreen(
    controller: MusicController,
    onScanLocal: () -> Unit,
    onOpenLocalFolders: () -> Unit,
    onOpenPersonalDrive: () -> Unit,
    onOpenPublicDrive: () -> Unit,
    onOpenPremium: () -> Unit,
    onSettings: () -> Unit,
    googleAccountEmail: String?,
    googleAccountName: String?,
    googleProfilePhotoUrl: String?,
    onGoogleLogin: () -> Unit,
    onGoogleLogout: () -> Unit
) {
    val colors = LocalMusicColors.current
    // Window height reflects split screen / small phones too. Keep typography
    // and touch targets readable when Android uses enlarged system font sizes.
    val window = LocalConfiguration.current
    val compactHome = window.screenHeightDp < 910 && window.fontScale <= 1.15f
    val homeGap = if (compactHome) 6.dp else 10.dp
    // Compact the recently played carousel instead of reclaiming the camera/notch area.
    // Keep a little more space when Android's accessibility text scaling is large.
    val recentArtSize = when {
        window.fontScale > 1.20f -> if (window.screenHeightDp < 750) 102.dp else 116.dp
        window.screenHeightDp < 710 || window.screenWidthDp < 350 -> 86.dp
        window.screenHeightDp < 910 || window.screenWidthDp < 390 -> 96.dp
        else -> 124.dp
    }
    // Keep the next section from peeking halfway behind the fixed player on the
    // first viewport. The gap is larger on short screens and smaller on tall
    // phones; users can still scroll normally to the recommendation section.
    val recommendationLeadSpace = when {
        window.fontScale > 1.20f && window.screenHeightDp < 850 -> 30.dp
        window.screenHeightDp < 720 -> 30.dp
        window.screenHeightDp < 820 -> 24.dp
        window.screenHeightDp < 940 -> 16.dp
        else -> 8.dp
    }
    // MainActivity intentionally hides the Android status bar. A normal statusBarsPadding()
    // would then be zero, even on some cutout/camera-hole devices. Read stable window
    // insets (ignoring visibility) and keep the platform's status-bar height as fallback.
    val localContext = LocalContext.current
    val rootInsets = ViewCompat.getRootWindowInsets(LocalView.current)
    val statusBarResource = localContext.resources.getIdentifier("status_bar_height", "dimen", "android")
    val fallbackStatusHeightPx = if (statusBarResource != 0) {
        localContext.resources.getDimensionPixelSize(statusBarResource)
    } else {
        with(LocalDensity.current) { 24.dp.roundToPx() }
    }
    val safeTopInsetPx = maxOf(
        fallbackStatusHeightPx,
        rootInsets?.getInsetsIgnoringVisibility(WindowInsetsCompat.Type.statusBars())?.top ?: 0,
        rootInsets?.getInsetsIgnoringVisibility(WindowInsetsCompat.Type.displayCutout())?.top ?: 0
    )
    val safeTopInset = with(LocalDensity.current) { safeTopInsetPx.toDp() }
    val recent = controller.recentForHome()
    val recommended = controller.recommendations()
    val driveSongs = controller.newlyAddedFromDrive()
    var showOnlineSearch by remember { mutableStateOf(false) }
    var showNetworkMenu by remember { mutableStateOf(false) }
    var activeAudioTool by remember { mutableStateOf<AudioToolMode?>(null) }
    var showGoogleAccount by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }
    val converterPremiumLocked = MeloWarePremiumAccess.audioConverterRequiresPremium
    val extractorPremiumLocked = MeloWarePremiumAccess.videoExtractorRequiresPremium
    val drivePremiumLocked = MeloWarePremiumAccess.googleDriveRequiresPremium
    val openPersonalDriveWithPremiumCheck: () -> Unit = {
        if (drivePremiumLocked) onOpenPremium() else onOpenPersonalDrive()
    }
    val openPublicDriveWithPremiumCheck: () -> Unit = {
        if (drivePremiumLocked) onOpenPremium() else onOpenPublicDrive()
    }
    LaunchedEffect(converterPremiumLocked, extractorPremiumLocked) {
        val shouldCloseTool = when (activeAudioTool) {
            AudioToolMode.CONVERT -> converterPremiumLocked
            AudioToolMode.EXTRACT -> extractorPremiumLocked
            null -> false
        }
        if (shouldCloseTool) activeAudioTool = null
    }
    val context = LocalContext.current
    var unreadNotificationCount by remember { mutableIntStateOf(HomeNotificationStore.unreadCount(context)) }
    val lifecycleOwner = LocalLifecycleOwner.current
    // Refresh the unread badge when returning from another app or a notification.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                unreadNotificationCount = HomeNotificationStore.unreadCount(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            PlayerBottomArea(
                controller = controller,
                selectedScreen = MusicScreen.HOME
            )
        }
    ) { padding ->
        // Scaffold padding may already include an inset on devices with visible system bars.
        // Only add the missing portion so the safe area is never counted twice.
        val missingTopInset = (safeTopInset - padding.calculateTopPadding()).coerceAtLeast(0.dp)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(colors.background, colors.backgroundSoft, colors.background)
                    )
                )
                // Bottom area remains measured by Scaffold; top camera/cutout is
                // accounted for by the missingTopInset in contentPadding.
                .padding(padding)
                .consumeWindowInsets(padding),
            contentPadding = PaddingValues(
                start = 12.dp, end = 12.dp,
                top = missingTopInset + (if (compactHome) 5.dp else 8.dp),
                bottom = 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(homeGap)
        ) {
            item {
                HomeHeader(
                    compact = compactHome,
                    googleAccountEmail = googleAccountEmail,
                    googleAccountName = googleAccountName,
                    googleProfilePhotoUrl = googleProfilePhotoUrl,
                    unreadNotifications = unreadNotificationCount,
                    onLogoFiveTap = { showOnlineSearch = true },
                    onOpenAccount = { showGoogleAccount = true },
                    onOpenNotifications = {
                        HomeNotificationStore.markAllRead(context)
                        unreadNotificationCount = 0
                        showNotifications = true
                    },
                    onSettings = onSettings
                )
            }

            item {
                HomeSearchBar(
                    compact = compactHome,
                    initialQuery = controller.libraryQuery,
                    onSearch = { query ->
                        val cleanQuery = query.trim()
                        if (cleanQuery.isNotBlank()) {
                            controller.libraryQuery = cleanQuery
                            controller.libraryTab = LibraryTab.SONGS
                            controller.openLibrary(LibrarySource.ALL)
                        }
                    }
                )
            }

            item {
                HeroMusicCard(
                    compact = compactHome,
                    onOpenNetworkTransfer = { showNetworkMenu = true },
                    onOpenLocalFolders = onOpenLocalFolders,
                    onOpenPersonalDrive = openPersonalDriveWithPremiumCheck,
                    onOpenPublicDrive = openPublicDriveWithPremiumCheck,
                    driveLocked = drivePremiumLocked
                )
            }

            // Keep the audio tools immediately after the source shortcuts,
            // before the scrolling rows of recently played songs.
            item {
                HomeAudioToolsPanel(
                    compact = compactHome,
                    convertLocked = converterPremiumLocked,
                    extractLocked = extractorPremiumLocked,
                    onConvert = {
                        if (converterPremiumLocked) onOpenPremium()
                        else activeAudioTool = AudioToolMode.CONVERT
                    },
                    onExtract = {
                        if (extractorPremiumLocked) onOpenPremium()
                        else activeAudioTool = AudioToolMode.EXTRACT
                    }
                )
            }

            if (recent.isNotEmpty()) {
                item {
                    HomeRecentSectionTitle(
                        compact = compactHome || window.screenWidthDp < 390,
                        onViewAll = { controller.openLibrary(LibrarySource.ALL) }
                    )
                }
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(if (recentArtSize < 110.dp) 8.dp else 12.dp),
                        contentPadding = PaddingValues(end = 10.dp)
                    ) {
                        items(recent, key = { it.id }) { song ->
                            LaunchedEffect(song.id) { controller.ensureArtwork(song) }
                            RecentSongCard(
                                song = song,
                                artworkSize = recentArtSize,
                                artworkUrl = controller.artworkFor(song),
                                onClick = { controller.playSong(song, recent) }
                            )
                        }
                    }
                }
            }

            if (recommended.isNotEmpty()) {
                if (recent.isNotEmpty()) {
                    item(key = "recommendation_lead_space") {
                        Spacer(Modifier.height(recommendationLeadSpace))
                    }
                }
                item {
                    SectionTitle(
                        title = mwString("home.recommended", "Đề xuất cho bạn"),
                        actionText = mwString("nav.library", "Thư viện"),
                        onAction = { controller.openLibrary() }
                    )
                }
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(end = 10.dp)
                    ) {
                        items(recommended, key = { it.id }) { song ->
                            LaunchedEffect(song.id) { controller.ensureArtwork(song) }
                            RecommendationCard(
                                song = song,
                                artworkUrl = controller.artworkFor(song),
                                onClick = { controller.playSong(song, recommended) }
                            )
                        }
                    }
                }
            }

            if (driveSongs.isNotEmpty()) {
                item {
                    SectionTitle(
                        title = mwString("home.new_drive", "Mới thêm từ Drive"),
                        actionText = mwString("home.view_all", "Xem tất cả"),
                        onAction = { controller.openLibrary(LibrarySource.PERSONAL_DRIVE) }
                    )
                }
                items(driveSongs.take(5), key = { it.id }) { song ->
                    LaunchedEffect(song.id) { controller.ensureArtwork(song) }
                    SongRow(
                        song = song,
                        artworkUrl = controller.artworkFor(song),
                        isCurrent = controller.currentSong?.id == song.id,
                        isFavorite = controller.isFavorite(song),
                        onClick = { controller.playSong(song, driveSongs) },
                        onFavorite = { controller.toggleFavorite(song) }
                    )
                }
            }

            if (recent.isEmpty() && recommended.isEmpty() && driveSongs.isEmpty()) {
                item {
                    EmptyLibraryState(
                        title = mwString("home.empty_title", "Chưa có bài hát"),
                        description = mwString("home.empty_desc", "Quét nhạc trên điện thoại hoặc kết nối Google Drive để bắt đầu."),
                        buttonText = mwString("home.scan_local", "Quét nhạc trên máy"),
                        onButton = onScanLocal
                    )
                }
            }
        }
    }

    if (showNetworkMenu) {
        MeloWareNetworkMenuDialog(
            controller = controller,
            onDismiss = { showNetworkMenu = false }
        )
    }

    activeAudioTool?.let { mode ->
        MeloWaveAudioToolDialog(
            mode = mode,
            onDismiss = { activeAudioTool = null }
        )
    }

    if (showOnlineSearch) {
        OnlineSearchDialog(
            controller = controller,
            onDismiss = { showOnlineSearch = false }
        )
    }

    if (showGoogleAccount) {
        HomeGoogleAccountDialog(
            email = googleAccountEmail,
            name = googleAccountName,
            photoUrl = googleProfilePhotoUrl,
            onLogin = { showGoogleAccount = false; onGoogleLogin() },
            onLogout = { showGoogleAccount = false; onGoogleLogout() },
            onOpenDrive = { showGoogleAccount = false; openPersonalDriveWithPremiumCheck() },
            onSettings = { showGoogleAccount = false; onSettings() },
            onDismiss = { showGoogleAccount = false }
        )
    }

    if (showNotifications) {
        HomeNotificationsDialog(onDismiss = { showNotifications = false })
    }
}

@Composable
private fun HomeAudioToolsPanel(
    compact: Boolean,
    convertLocked: Boolean,
    extractLocked: Boolean,
    onConvert: () -> Unit,
    onExtract: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(21.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, colors.purple.copy(alpha = if (colors.isDark) 0.40f else 0.24f))
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            lerp(colors.card, colors.purple, if (colors.isDark) 0.22f else 0.06f),
                            lerp(colors.card, colors.backgroundSoft, 0.55f),
                            lerp(colors.card, colors.purpleBright, if (colors.isDark) 0.12f else 0.05f)
                        )
                    )
                )
                .padding(if (compact) 4.dp else 8.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 2.dp else 5.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = colors.purpleBright,
                    modifier = Modifier.size(if (compact) 15.dp else 17.dp)
                )
                Spacer(Modifier.width(5.dp))
                Text(
                    mwString("audio_tools.section", "Công cụ âm thanh"),
                    modifier = Modifier.weight(1f),
                    fontSize = if (compact) 12.5.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Surface(
                    shape = RoundedCornerShape(30.dp),
                    color = Color(0xFFFFD54F).copy(alpha = if (colors.isDark) 0.12f else 0.10f),
                    border = BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.62f))
                ) {
                    Row(
                        modifier = Modifier.padding(
                            horizontal = if (compact) 6.dp else 7.dp,
                            vertical = if (compact) 2.dp else 3.dp
                        ),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            Icons.Rounded.WorkspacePremium,
                            contentDescription = null,
                            tint = Color(0xFFFFD54F),
                            modifier = Modifier.size(if (compact) 10.dp else 11.dp)
                        )
                        Text(
                            text = "PRO",
                            color = Color(0xFFFFD54F),
                            fontWeight = FontWeight.Bold,
                            fontSize = if (compact) 8.5.sp else 9.sp
                        )
                    }
                }
            }
            // Hai công cụ nằm CÙNG MỘT HÀNG: tối ưu chiều cao trang chủ.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 7.dp)
            ) {
                HomeAudioToolCompactCard(
                    compact = compact,
                    title = mwString("audio_tools.convert", "Chuyển đổi nhạc"),
                    subtitle = "MP3 · M4A · WAV",
                    iconKind = HomeFeatureIconKind.CONVERT,
                    locked = convertLocked,
                    onClick = onConvert,
                    modifier = Modifier.weight(1f)
                )
                HomeAudioToolCompactCard(
                    compact = compact,
                    title = mwString("audio_tools.extract", "Tách âm thanh"),
                    subtitle = mwString("audio_tools.from_video", "Từ video trong máy"),
                    iconKind = HomeFeatureIconKind.VIDEO,
                    locked = extractLocked,
                    onClick = onExtract,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * These three badges intentionally share one icon style. All gradient stops come
 * from LocalMusicColors, so every accent preset, custom hue, and dark/light mode
 * is handled automatically without adding any drawable resources.
 */
private enum class HomeFeatureIconKind { NETWORK, CONVERT, VIDEO }

@Composable
private fun HomeFeatureIconBadge(
    kind: HomeFeatureIconKind,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    val shape = RoundedCornerShape(11.dp)

    // Harmonized gradients: network -> primary/bright, conversion -> primary/
    // subtle cyan, video -> highlight/primary. Black is mixed in for contrast
    // so the white glyph stays visible even with amber and light themes.
    val (rawStart, rawEnd) = when (kind) {
        HomeFeatureIconKind.NETWORK -> Pair(colors.purpleBright, colors.purple)
        HomeFeatureIconKind.CONVERT -> Pair(
            lerp(colors.purple, colors.cyan, 0.13f), colors.purpleBright
        )
        HomeFeatureIconKind.VIDEO -> Pair(colors.magenta, colors.purple)
    }
    val darken = if (colors.isDark) 0.12f else 0.21f
    // Keep white foreground contrast on light accents (lime / amber / cyan),
    // not just on the default purple palette.
    fun badgeColor(raw: Color, extraShade: Float): Color {
        var candidate = lerp(raw, Color.Black, extraShade)
        repeat(8) {
            if (candidate.luminance() > 0.13f) {
                candidate = lerp(candidate, Color.Black, 0.18f)
            }
        }
        return candidate
    }
    val startColor = badgeColor(rawStart, darken)
    val endColor = badgeColor(rawEnd, darken + 0.09f)

    Box(
        modifier = modifier
            .shadow(
                elevation = 3.dp,
                shape = shape,
                ambientColor = colors.purple.copy(alpha = 0.18f),
                spotColor = colors.purple.copy(alpha = 0.30f)
            )
            .clip(shape)
            .background(Brush.linearGradient(listOf(startColor, endColor)))
            .border(
                width = 0.8.dp,
                color = Color.White.copy(alpha = if (colors.isDark) 0.27f else 0.36f),
                shape = shape
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = if (colors.isDark) 0.12f else 0.08f),
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.10f)
                    )
                )
            )
        )
        when (kind) {
            HomeFeatureIconKind.NETWORK -> TwoPhonesTransferIcon(
                tint = Color.White,
                modifier = Modifier.size(29.dp)
            )
            HomeFeatureIconKind.CONVERT -> Icon(
                imageVector = Icons.Rounded.CompareArrows,
                contentDescription = null,
                modifier = Modifier.size(26.dp),
                tint = Color.White
            )
            HomeFeatureIconKind.VIDEO -> Icon(
                imageVector = Icons.Rounded.Movie,
                contentDescription = null,
                modifier = Modifier.size(25.dp),
                tint = Color.White
            )
        }
    }
}

@Composable
private fun HomeAudioToolCompactCard(
    compact: Boolean,
    title: String,
    subtitle: String,
    iconKind: HomeFeatureIconKind,
    locked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    val accent = if (iconKind == HomeFeatureIconKind.CONVERT) colors.purpleBright else colors.magenta
    Surface(
        // 48dp is the minimum recommended tap target; the card never shrinks
        // below it, even on phones with a short viewport.
        modifier = modifier.height(if (compact) 48.dp else 56.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = Color.Transparent,
        border = BorderStroke(
            1.dp,
            lerp(colors.border, accent, if (colors.isDark) 0.23f else 0.14f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            colors.card.copy(alpha = if (colors.isDark) 0.93f else 0.97f),
                            lerp(colors.cardRaised, accent, if (colors.isDark) 0.10f else 0.055f)
                        )
                    )
                )
                .padding(horizontal = 6.dp, vertical = if (compact) 3.dp else 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                HomeFeatureIconBadge(
                    kind = iconKind,
                    modifier = Modifier.size(if (compact) 29.dp else 32.dp)
                )
                if (locked) {
                    Surface(
                        modifier = Modifier.offset(x = 4.dp, y = (-4).dp).size(15.dp),
                        shape = CircleShape,
                        color = Color(0xFF25152F),
                        border = BorderStroke(1.dp, Color(0xFFFFD54F))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.WorkspacePremium,
                                contentDescription = mwString("premium.required", "Premium"),
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.width(5.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    color = colors.textPrimary,
                    fontSize = if (compact) 9.8.sp else 10.3.sp,
                    lineHeight = if (compact) 11.3.sp else 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(if (compact) 1.dp else 2.dp))
                Text(
                    text = subtitle,
                    color = colors.textSecondary,
                    fontSize = if (compact) 8.5.sp else 8.8.sp,
                    lineHeight = if (compact) 9.5.sp else 10.3.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun HomeHeader(
    compact: Boolean,
    googleAccountEmail: String?,
    googleAccountName: String?,
    googleProfilePhotoUrl: String?,
    unreadNotifications: Int,
    onLogoFiveTap: () -> Unit,
    onOpenAccount: () -> Unit,
    onOpenNotifications: () -> Unit,
    onSettings: () -> Unit
) {
    val colors = LocalMusicColors.current
    var logoTapCount by remember { mutableIntStateOf(0) }
    var lastLogoTapAt by remember { mutableLongStateOf(0L) }

    fun registerLogoTap() {
        val now = SystemClock.elapsedRealtime()
        logoTapCount = if (now - lastLogoTapAt <= 1_800L) logoTapCount + 1 else 1
        lastLogoTapAt = now
        if (logoTapCount >= 5) {
            logoTapCount = 0
            lastLogoTapAt = 0L
            onLogoFiveTap()
        }
    }

    val fontScale = LocalConfiguration.current.fontScale
    val headerHeight = when {
        fontScale > 1.25f -> 54.dp
        fontScale > 1.10f -> 49.dp
        compact -> 45.dp
        else -> 48.dp
    }

    // Restore the original MeloWave image resource (used by the original HomeScreen).
    // Keep the logo compact enough for small screens with a notification bell,
    // settings and the Google avatar sharing the same header row.
    val narrowHeader = LocalConfiguration.current.screenWidthDp < 370
    val headerLogoSize = if (narrowHeader) 34.dp else 38.dp
    val headerTitleSize = if (narrowHeader) 21.sp else 24.sp

    Row(
        modifier = Modifier.fillMaxWidth().height(headerHeight),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f).clickable(onClick = ::registerLogoTap),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(headerLogoSize),
                shape = RoundedCornerShape(if (narrowHeader) 10.dp else 12.dp),
                color = Color.Black,
                border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.62f)),
                shadowElevation = 3.dp
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo MeloWave",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(Modifier.width(if (narrowHeader) 6.dp else 8.dp))
            Column(verticalArrangement = Arrangement.Center) {
                GradientText(
                    text = "MeloWave",
                    brush = Brush.horizontalGradient(listOf(colors.textPrimary, colors.purpleBright)),
                    fontSize = headerTitleSize,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = mwString("home.tagline", "Âm nhạc của bạn"),
                    modifier = Modifier.offset(y = (-2).dp),
                    color = colors.textSecondary,
                    fontSize = if (fontScale > 1.20f) 10.sp else 10.5.sp,
                    lineHeight = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Clip
                )
            }
        }
        Box(modifier = Modifier.size(37.dp), contentAlignment = Alignment.Center) {
            IconButton(onClick = onOpenNotifications, modifier = Modifier.fillMaxSize()) {
                Icon(
                    Icons.Rounded.NotificationsNone,
                    contentDescription = "Thông báo",
                    tint = colors.textPrimary,
                    modifier = Modifier.size(23.dp)
                )
            }
            if (unreadNotifications > 0) {
                Box(
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = 2.dp, top = 2.dp)
                        .size(8.dp).clip(CircleShape).background(Color(0xFFFF4557))
                )
            }
        }
        IconButton(onClick = onSettings, modifier = Modifier.size(37.dp)) {
            Icon(
                Icons.Rounded.Settings,
                contentDescription = mwString("settings.title", "Cài đặt"),
                tint = colors.textSecondary,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.width(4.dp))
        HomeGoogleAvatar(
            email = googleAccountEmail,
            name = googleAccountName,
            photoUrl = googleProfilePhotoUrl,
            onClick = onOpenAccount,
            modifier = Modifier.size(35.dp)
        )
    }
}

@Composable
private fun HomeGoogleAvatar(
    email: String?,
    name: String?,
    photoUrl: String?,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    val initial = (name?.trim()?.firstOrNull() ?: email?.firstOrNull())?.uppercaseChar()?.toString()
    // Both active Premium subscriptions and active Premium Trial get the crown.
    // Trial may be device-scoped, so a Google sign-in is not required for this badge.
    val showPremiumCrown = MeloWarePremiumAccess.canUsePaidFeatures &&
            MeloWarePremiumAccess.accessKind in listOf("paid", "trial")
    Box(
        modifier = modifier.then(if (onClick == null) Modifier else Modifier.clickable(onClick = onClick)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
                .padding(top = if (showPremiumCrown) 3.dp else 0.dp,
                    end = if (showPremiumCrown) 3.dp else 0.dp)
                .clip(CircleShape)
                .background(
                    if (!email.isNullOrBlank()) Brush.linearGradient(listOf(colors.purple, colors.magenta))
                    else Brush.linearGradient(listOf(colors.cardRaised, colors.card))
                )
                .border(1.dp, colors.border.copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (email.isNullOrBlank()) {
                Icon(
                    Icons.Rounded.AccountCircle,
                    contentDescription = "Đăng nhập Google",
                    tint = colors.textSecondary,
                    modifier = Modifier.fillMaxSize().padding(3.dp)
                )
            } else {
                Text(
                    text = initial ?: "G",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                if (!photoUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = photoUrl,
                        contentDescription = "Ảnh đại diện tài khoản Google",
                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
        if (showPremiumCrown) {
            // Tiny gold crown at the avatar's upper-right corner; does not clip with the photo.
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).size(16.dp),
                shape = CircleShape,
                color = Color(0xFF23162E),
                border = BorderStroke(1.dp, Color(0xFFFFD54F))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    MeloWarePremiumCrown(modifier = Modifier.size(13.dp))
                }
            }
        }
    }
}

@Composable
private fun HomeGoogleAccountDialog(
    email: String?,
    name: String?,
    photoUrl: String?,
    onLogin: () -> Unit,
    onLogout: () -> Unit,
    onOpenDrive: () -> Unit,
    onSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = colors.cardRaised,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(Modifier.fillMaxWidth().padding(19.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HomeGoogleAvatar(email, name, photoUrl, onClick = null, modifier = Modifier.size(49.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Tài khoản Google", color = colors.textPrimary, fontWeight = FontWeight.Bold)
                        Text(
                            if (email == null) "Chưa đăng nhập" else (name?.takeIf { it.isNotBlank() } ?: email),
                            color = colors.textSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (email != null && !name.isNullOrBlank()) {
                            Text(email, color = colors.textSecondary, fontSize = 11.sp, maxLines = 1)
                        }
                        if (email != null && MeloWarePremiumAccess.accessKind == "paid" &&
                            MeloWarePremiumAccess.canUsePaidFeatures
                        ) {
                            Text("MeloWave Premium", color = Color(0xFFFFD54F),
                                fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                        }
                    }
                }
                if (email == null) {
                    HomeDialogAction(mwString("settings.google_login", "Đăng nhập Google"), onLogin)
                } else {
                    HomeDialogAction("Mở Google Drive", onOpenDrive)
                    HomeDialogAction(mwString("settings.google_logout", "Đăng xuất"), onLogout)
                }
                HomeDialogAction(mwString("settings.title", "Cài đặt"), onSettings)
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("Đóng", color = colors.textSecondary)
                }
            }
        }
    }
}

@Composable
private fun HomeDialogAction(title: String, onClick: () -> Unit) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.border)
    ) {
        Text(
            title,
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 12.dp),
            color = colors.textPrimary,
            fontWeight = FontWeight.Medium
        )
    }
}

// Notification history only includes reminders actually posted by ReminderReceiver.
internal data class HomeNotice(val createdAt: Long, val title: String, val message: String)

internal object HomeNotificationStore {
    private const val PREFS = "melowave_in_app_notifications"
    private const val ENTRIES = "recent_entries"
    private const val LAST_READ = "last_read_time"

    fun record(context: Context, title: String, message: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldEntries = runCatching { JSONArray(prefs.getString(ENTRIES, "[]")) }.getOrDefault(JSONArray())
        val next = JSONArray().put(
            JSONObject().put("time", System.currentTimeMillis()).put("title", title).put("message", message)
        )
        for (i in 0 until minOf(oldEntries.length(), 19)) {
            oldEntries.optJSONObject(i)?.let { next.put(it) }
        }
        prefs.edit().putString(ENTRIES, next.toString()).apply()
    }

    fun getAll(context: Context): List<HomeNotice> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = runCatching { JSONArray(prefs.getString(ENTRIES, "[]")) }.getOrDefault(JSONArray())
        return buildList {
            for (index in 0 until array.length()) {
                val obj = array.optJSONObject(index) ?: continue
                add(HomeNotice(obj.optLong("time"), obj.optString("title"), obj.optString("message")))
            }
        }
    }

    fun unreadCount(context: Context): Int {
        val seen = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(LAST_READ, 0L)
        return getAll(context).count { it.createdAt > seen }
    }

    fun markAllRead(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(LAST_READ, System.currentTimeMillis()).apply()
    }
}

@Composable
private fun HomeNotificationsDialog(onDismiss: () -> Unit) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    val notices = remember { HomeNotificationStore.getAll(context) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = colors.cardRaised,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.NotificationsNone, contentDescription = null, tint = colors.purpleBright)
                    Spacer(Modifier.width(8.dp))
                    Text("Thông báo", modifier = Modifier.weight(1f), color = colors.textPrimary,
                        fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Đóng", tint = colors.textSecondary)
                    }
                }
                if (notices.isEmpty()) {
                    Text(
                        "Chưa có thông báo nào. Các lời nhắc nghe nhạc được gửi từ ứng dụng sẽ xuất hiện tại đây.",
                        color = colors.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                } else {
                    Column(
                        modifier = Modifier.heightIn(max = 335.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        notices.forEach { notice ->
                            Surface(
                                shape = RoundedCornerShape(13.dp),
                                color = colors.card,
                                border = BorderStroke(1.dp, colors.border.copy(alpha = 0.65f))
                            ) {
                                Column(Modifier.fillMaxWidth().padding(11.dp)) {
                                    Text(notice.title, color = colors.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(notice.message, color = colors.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
                                    Text(
                                        remember(notice.createdAt) {
                                            DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                                .format(Date(notice.createdAt))
                                        },
                                        color = colors.textSecondary.copy(alpha = 0.73f), fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
                TextButton(
                    onClick = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try {
                            context.startActivity(intent)
                        } catch (_: ActivityNotFoundException) {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:${context.packageName}"))
                            )
                        }
                        onDismiss()
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Cài đặt thông báo", color = colors.purpleBright)
                }
            }
        }
    }
}

@Composable
private fun HomeSearchBar(
    compact: Boolean,
    initialQuery: String,
    onSearch: (String) -> Unit
) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    val currentOnSearch by rememberUpdatedState(onSearch)
    var query by remember(initialQuery) { mutableStateOf(initialQuery) }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()?.trim().orEmpty()
            if (spokenText.isNotBlank()) {
                query = spokenText
                currentOnSearch(spokenText)
            }
        }
    }

    val voicePrompt = mwString("home.voice_prompt", "Nói tên bài hát, ca sĩ hoặc album")
    val voiceUnavailable = mwString("home.voice_unavailable", "Thiết bị chưa có dịch vụ nhận dạng giọng nói.")

    fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, voicePrompt)
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, voiceUnavailable, Toast.LENGTH_LONG).show()
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth().height(if (compact) 47.dp else 51.dp),
        shape = RoundedCornerShape(23.dp),
        color = colors.cardRaised.copy(alpha = 0.90f),
        border = BorderStroke(1.dp, colors.border)
    ) {
        Row(
            modifier = Modifier.padding(start = 5.dp, end = 5.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { if (query.isNotBlank()) currentOnSearch(query) },
                modifier = Modifier.size(37.dp)
            ) {
                Icon(
                    Icons.Rounded.Search,
                    contentDescription = mwString("home.search", "Tìm"),
                    tint = colors.textSecondary,
                    modifier = Modifier.size(21.dp)
                )
            }
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                textStyle = TextStyle(color = colors.textPrimary, fontSize = 13.sp),
                singleLine = true,
                cursorBrush = SolidColor(colors.purpleBright),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    if (query.isNotBlank()) currentOnSearch(query)
                }),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isBlank()) {
                            Text(
                                mwString("home.search_hint", "Tìm bài hát, ca sĩ, album, thể loại..."),
                                color = colors.textMuted,
                                fontSize = 12.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        inner()
                    }
                }
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(colors.purple.copy(alpha = if (colors.isDark) 0.26f else 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = ::startVoiceSearch, modifier = Modifier.size(39.dp)) {
                    Icon(
                        Icons.Rounded.Mic,
                        contentDescription = mwString("home.voice_search", "Tìm kiếm bằng giọng nói"),
                        tint = colors.purpleBright,
                        modifier = Modifier.size(23.dp)
                    )
                }
            }
        }
    }
}

/**
 * Banner: artwork WebP keeps its details; Kotlin draws all titles and action buttons.
 * All four shortcuts share ONE row: device / Google Drive / Drive link / network transfer.
 */
@Composable
private fun HeroMusicCard(
    compact: Boolean,
    onOpenNetworkTransfer: () -> Unit,
    onOpenLocalFolders: () -> Unit,
    onOpenPersonalDrive: () -> Unit,
    onOpenPublicDrive: () -> Unit,
    driveLocked: Boolean
) {
    val colors = LocalMusicColors.current
    val shape = RoundedCornerShape(22.dp)
    val artwork = heroBannerArtwork(colors)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        color = Color.Transparent,
        border = BorderStroke(1.dp, colors.purple.copy(alpha = if (colors.isDark) 0.76f else 0.36f))
    ) {
        // Keep the headphone image at 155dp for an uncropped arch. On short
        // displays the four shortcuts sit 11dp deeper in its dark shadow, while
        // all icons retain the same clickable 70dp height.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 204.dp else 215.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(colors.cardRaised, colors.card, colors.backgroundSoft)
                    )
                )
        ) {
            Box(modifier = Modifier.fillMaxWidth().height(155.dp)) {
                Image(
                    painter = painterResource(id = artwork.first),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopEnd,
                    colorFilter = artwork.second
                )
                Box(
                    modifier = Modifier.fillMaxSize().background(
                        Brush.horizontalGradient(
                            listOf(
                                (if (colors.isDark) Color(0xFF120527) else Color.White).copy(alpha = 0.27f),
                                Color.Transparent
                            )
                        )
                    )
                )
                Column(modifier = Modifier.padding(start = 13.dp, top = 13.dp)) {
                    Text(
                        text = mwString("home.unlimited", "Nhạc không\ngiới hạn"),
                        color = if (colors.isDark) Color.White else colors.textPrimary,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 27.sp,
                        maxLines = 2
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        text = mwString("home.hero_desc", "Nghe nhạc Offline và Google Drive\nchất lượng cao"),
                        modifier = Modifier.fillMaxWidth(0.63f),
                        color = if (colors.isDark) Color.White.copy(alpha = 0.89f) else colors.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            // One row of four independent, clickable sources; 19dp overlaps
            // the bottom artwork shadow, not the headphone's arch or text.
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 9.dp, end = 9.dp, bottom = 9.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                HeroSourceAction(
                    title = mwString("home.local_music", "Nhạc máy"),
                    sourceType = HeroSourceType.LOCAL_FOLDER,
                    onClick = onOpenLocalFolders,
                    modifier = Modifier.weight(1f)
                )
                HeroSourceAction(
                    title = "Google Drive",
                    sourceType = HeroSourceType.PERSONAL_DRIVE,
                    locked = driveLocked,
                    onClick = onOpenPersonalDrive,
                    modifier = Modifier.weight(1f)
                )
                HeroSourceAction(
                    title = mwString("home.drive_link", "Link Drive"),
                    sourceType = HeroSourceType.PUBLIC_LINK,
                    locked = driveLocked,
                    onClick = onOpenPublicDrive,
                    modifier = Modifier.weight(1f)
                )
                HeroSourceAction(
                    title = mwString("home.network_title", "Lấy nhạc qua mạng"),
                    sourceType = HeroSourceType.NETWORK_TRANSFER,
                    onClick = onOpenNetworkTransfer,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * Tám màu có sẵn: 8 ảnh × dark/light.
 * Màu tuỳ chỉnh: tái sử dụng ảnh gốc và xoay hue bằng ColorMatrix,
 * cho phép tai nghe/đường sóng đổi ngay cả khi kéo thanh chọn màu.
 */
private fun heroBannerArtwork(colors: MusicColors): Pair<Int, ColorFilter?> {
    val option = MusicAccentOptions.firstOrNull { entry ->
        colors.purple == (if (colors.isDark) entry.darkPrimary else entry.lightPrimary)
    }
    if (option == null) {
        val original = if (colors.isDark) DarkMusicColors.purpleBright else LightMusicColors.purpleBright
        val angle = heroHue(colors.purpleBright) - heroHue(original)
        val drawable = if (colors.isDark) R.drawable.hero_headphones_purple_dark
        else R.drawable.hero_headphones_purple_light
        return drawable to heroHueFilter(angle)
    }
    val imageRes = if (colors.isDark) {
        when (option.id) {
            "blue" -> R.drawable.hero_headphones_blue_dark
            "teal" -> R.drawable.hero_headphones_teal_dark
            "green" -> R.drawable.hero_headphones_green_dark
            "orange" -> R.drawable.hero_headphones_orange_dark
            "pink" -> R.drawable.hero_headphones_pink_dark
            "red" -> R.drawable.hero_headphones_red_dark
            "amber" -> R.drawable.hero_headphones_amber_dark
            else -> R.drawable.hero_headphones_purple_dark
        }
    } else {
        when (option.id) {
            "blue" -> R.drawable.hero_headphones_blue_light
            "teal" -> R.drawable.hero_headphones_teal_light
            "green" -> R.drawable.hero_headphones_green_light
            "orange" -> R.drawable.hero_headphones_orange_light
            "pink" -> R.drawable.hero_headphones_pink_light
            "red" -> R.drawable.hero_headphones_red_light
            "amber" -> R.drawable.hero_headphones_amber_light
            else -> R.drawable.hero_headphones_purple_light
        }
    }
    return imageRes to null
}

private fun heroHue(color: Color): Float {
    val hsv = FloatArray(3)
    AndroidColor.colorToHSV(color.toArgb(), hsv)
    return hsv[0]
}

/** Xoay sắc độ trong RGB, giữ độ sáng/chi tiết của ảnh WebP cho màu tùy chỉnh. */
private fun heroHueFilter(degrees: Float): ColorFilter {
    val radians = Math.toRadians(degrees.toDouble())
    val c = cos(radians).toFloat()
    val s = sin(radians).toFloat()
    return ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
        0.213f + 0.787f*c - 0.213f*s, 0.715f - 0.715f*c - 0.715f*s, 0.072f - 0.072f*c + 0.928f*s, 0f, 0f,
        0.213f - 0.213f*c + 0.143f*s, 0.715f + 0.285f*c + 0.140f*s, 0.072f - 0.072f*c - 0.283f*s, 0f, 0f,
        0.213f - 0.213f*c - 0.787f*s, 0.715f - 0.715f*c + 0.715f*s, 0.072f + 0.928f*c + 0.072f*s, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )))
}

private enum class HeroSourceType {
    LOCAL_FOLDER,
    PERSONAL_DRIVE,
    PUBLIC_LINK,
    NETWORK_TRANSFER
}

@Composable
private fun HeroSourceAction(
    title: String,
    sourceType: HeroSourceType,
    locked: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = modifier.height(70.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = if (colors.isDark) colors.background.copy(alpha = 0.85f)
        else Color.White.copy(alpha = 0.91f),
        border = BorderStroke(1.dp, if (colors.isDark) Color.White.copy(alpha = 0.15f) else colors.border)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Box(modifier = Modifier.size(32.dp), contentAlignment = Alignment.Center) {
                when (sourceType) {
                    HeroSourceType.LOCAL_FOLDER -> {
                        Surface(
                            modifier = Modifier.size(29.dp),
                            shape = RoundedCornerShape(9.dp),
                            color = if (colors.isDark) Color(0xFF123B5E) else Color(0xFFDDF2FF),
                            border = BorderStroke(1.dp, Color(0xFF39BDF8).copy(alpha = 0.55f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Rounded.Folder,
                                    contentDescription = null,
                                    tint = if (colors.isDark) Color(0xFF67D8FF) else Color(0xFF0078AD),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                    HeroSourceType.NETWORK_TRANSFER -> {
                        // Theme-aware gradient matches audio tool badges. Preserve
                        // the original two-phone arrows; only their presentation changes.
                        HomeFeatureIconBadge(
                            kind = HomeFeatureIconKind.NETWORK,
                            modifier = Modifier.size(33.dp)
                        )
                    }
                    HeroSourceType.PERSONAL_DRIVE -> GoogleDriveLogo(Modifier.size(29.dp))
                    HeroSourceType.PUBLIC_LINK -> {
                        // Dùng cùng icon cho Home và tiêu đề Link Drive công khai.
                        GoogleDrivePublicLinkIcon(modifier = Modifier.fillMaxSize())
                    }
                }
                if (locked) {
                    Surface(
                        modifier = Modifier.align(Alignment.TopEnd).size(14.dp),
                        shape = CircleShape,
                        color = Color(0xFF25152F),
                        border = BorderStroke(1.dp, Color(0xFFFFD54F))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.WorkspacePremium,
                                contentDescription = mwString("premium.required", "Premium"),
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(9.dp)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = title,
                color = colors.textPrimary,
                fontSize = 9.5.sp,
                lineHeight = 11.5.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Icon "Link Drive" được chia sẻ giữa thẻ Home và cửa sổ Google Drive công khai.
 * Giữ nguyên logo ba màu và badge liên kết hồng của bản Home gốc.
 */
@Composable
internal fun GoogleDrivePublicLinkIcon(
    modifier: Modifier = Modifier,
    logoSize: androidx.compose.ui.unit.Dp = 29.dp,
    badgeSize: androidx.compose.ui.unit.Dp = 14.dp
) {
    val colors = LocalMusicColors.current
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GoogleDriveLogo(modifier = Modifier.size(logoSize))
        Surface(
            modifier = Modifier.align(Alignment.BottomEnd).size(badgeSize),
            shape = CircleShape,
            color = colors.magenta,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.72f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Rounded.Link,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(9.dp)
                )
            }
        }
    }
}

/**
 * Google Drive logo: hai cạnh ngoài xiên THẲNG liên tục qua chỗ chuyển màu.
 * Chỉ bo cong ở đỉnh trên và hai góc đáy; tam giác rỗng ở giữa hướng xuống 6 giờ.
 * Vẽ trực tiếp trong Canvas, không cần thêm drawable/image.
 */
@Composable
private fun GoogleDriveLogo(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        // Ba điểm trên mỗi cạnh xiên nằm trên CÙNG MỘT ĐƯỜNG THẲNG:
        // trái: (0.29, 0.14) -> (0.12, 0.48) -> (0.04, 0.64)
        // phải: (0.71, 0.14) -> (0.88, 0.48) -> (0.96, 0.64)
        // Vì vậy hai cạnh không bị cong hay gãy ở ranh giới giữa các dải màu.
        val seamY = h * 0.48f
        val leftSeam = w * 0.12f
        val rightSeam = w * 0.88f
        val cutLeft = w * 0.36f
        val cutRight = w * 0.64f
        val cutTipY = h * 0.705f
        val bottom = h * 0.98f
        val bottomJoin = w * 0.615f

        // Xanh lá: phần vòm đỉnh và hai cạnh xiên thẳng tới ranh giới màu.
        val greenPath = Path().apply {
            moveTo(leftSeam, seamY)
            lineTo(w * 0.29f, h * 0.14f)
            cubicTo(
                w * 0.33f, h * 0.05f,
                w * 0.42f, h * 0.025f,
                w * 0.50f, h * 0.025f
            )
            cubicTo(
                w * 0.58f, h * 0.025f,
                w * 0.67f, h * 0.05f,
                w * 0.71f, h * 0.14f
            )
            lineTo(rightSeam, seamY)
            lineTo(cutRight, seamY)
            lineTo(cutLeft, seamY)
            close()
        }
        drawPath(
            path = greenPath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF49C8D7),
                    Color(0xFF10BE6B),
                    Color(0xFF0FBE69)
                ),
                start = androidx.compose.ui.geometry.Offset(w * 0.12f, h * 0.48f),
                end = androidx.compose.ui.geometry.Offset(w * 0.70f, h * 0.025f)
            )
        )

        // Xanh dương: cạnh ngoài bên trái là đường THẲNG từ mối nối
        // tới (0.04w, 0.64h); chỉ dùng Bézier tại góc đáy trái.
        val bluePath = Path().apply {
            moveTo(leftSeam, seamY)
            lineTo(cutLeft, seamY)
            lineTo(w * 0.50f, cutTipY)
            lineTo(bottomJoin, bottom)
            lineTo(w * 0.18f, bottom)
            cubicTo(
                0f, bottom,
                0f, h * 0.72f,
                w * 0.04f, h * 0.64f
            )
            close()
        }
        drawPath(
            path = bluePath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF4285F4),
                    Color(0xFF3B7FF4),
                    Color(0xFF8795FF)
                ),
                start = androidx.compose.ui.geometry.Offset(0f, h * 0.48f),
                end = androidx.compose.ui.geometry.Offset(w * 0.65f, h)
            )
        )

        // Vàng: đối xứng bên phải, cạnh xiên là đường THẲNG liên tục.
        val yellowPath = Path().apply {
            moveTo(cutRight, seamY)
            lineTo(rightSeam, seamY)
            lineTo(w * 0.96f, h * 0.64f)
            cubicTo(
                w, h * 0.72f,
                w, bottom,
                w * 0.82f, bottom
            )
            lineTo(bottomJoin, bottom)
            lineTo(w * 0.50f, cutTipY)
            close()
        }
        drawPath(
            path = yellowPath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFFFFD21A),
                    Color(0xFFFFCC00)
                ),
                start = androidx.compose.ui.geometry.Offset(w * 0.55f, h * 0.48f),
                end = androidx.compose.ui.geometry.Offset(w, bottom)
            )
        )
    }
}

@Composable
private fun HomeRecentSectionTitle(
    compact: Boolean,
    onViewAll: () -> Unit
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = mwString("home.recent", "Nghe gần đây"),
            modifier = Modifier.weight(1f),
            color = colors.textPrimary,
            fontSize = if (compact) 17.sp else 20.sp,
            lineHeight = if (compact) 20.sp else 24.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = mwString("home.view_all", "Xem tất cả"),
            color = colors.purpleBright,
            fontSize = if (compact) 11.5.sp else 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onViewAll)
                .padding(
                    horizontal = if (compact) 5.dp else 8.dp,
                    vertical = if (compact) 3.dp else 6.dp
                )
        )
    }
}

@Composable
private fun RecentSongCard(
    song: SongItem,
    artworkSize: androidx.compose.ui.unit.Dp,
    artworkUrl: String?,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    val compact = artworkSize < 110.dp
    val cornerRadius = if (compact) 12.dp else 16.dp
    Column(
        modifier = Modifier
            .width(artworkSize)
            .clip(RoundedCornerShape(cornerRadius))
            .clickable(onClick = onClick)
            .padding(bottom = if (compact) 2.dp else 4.dp)
    ) {
        Box {
            ArtworkImage(
                song = song,
                artworkUrl = artworkUrl,
                modifier = Modifier.size(artworkSize),
                cornerRadius = if (compact) 12 else 16
            )
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(if (compact) 5.dp else 8.dp)
                    .size(if (compact) 28.dp else 34.dp),
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.62f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.PlayArrow,
                        contentDescription = mwString("home.play", "Phát"),
                        tint = Color.White,
                        modifier = Modifier.size(if (compact) 18.dp else 20.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(if (compact) 3.dp else 7.dp))
        Text(
            song.title,
            color = colors.textPrimary,
            fontSize = if (compact) 11.sp else 13.sp,
            lineHeight = if (compact) 13.sp else 16.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            song.artist,
            color = colors.textSecondary,
            fontSize = if (compact) 9.5.sp else 11.sp,
            lineHeight = if (compact) 11.sp else 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun RecommendationCard(
    song: SongItem,
    artworkUrl: String?,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = Modifier
            .width(235.dp)
            .height(118.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.border)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArtworkImage(
                song = song,
                artworkUrl = artworkUrl,
                modifier = Modifier.size(88.dp),
                cornerRadius = 14
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    song.title,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    song.artist,
                    color = colors.textSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun OnlineSearchDialog(
    controller: MusicController,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    var query by remember(controller.onlineSearchQuery) {
        mutableStateOf(controller.onlineSearchQuery)
    }

    val onlineSpeechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()

            if (spokenText.isNotBlank()) {
                query = spokenText
                controller.onlineSearchQuery = spokenText
                controller.searchOnline(spokenText)
            }
        }
    }

    fun startOnlineVoiceSearch() {
        val sourceName = if (controller.onlineSearchMode == OnlineSearchMode.APPLE_MUSIC) {
            "Music"
        } else {
            "Movie"
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "Nói tên bài hát, ca sĩ hoặc video cần tìm trên $sourceName"
            )
        }

        try {
            onlineSpeechLauncher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(
                context,
                "Thiết bị chưa có dịch vụ nhận dạng giọng nói.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Dialog(
        onDismissRequest = { if (!controller.onlineSearchBusy) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.91f),
            shape = RoundedCornerShape(24.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
                    .padding(start = 16.dp, top = 10.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Tìm kiếm Music / Movie",
                            color = colors.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Nghe Music Preview hoặc xem Movie",
                            color = colors.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss, enabled = !controller.onlineSearchBusy) {
                        Icon(Icons.Rounded.Close, contentDescription = "Đóng", tint = colors.textSecondary)
                    }
                }

                // Hai nua Music / Movie chung mot vien thuoc, khong co khe ho.
                // Vien ngoai co be mat toi lom sau, nua dang chon noi tim sang.
                OnlineModeSelector(
                    selectedMode = controller.onlineSearchMode,
                    onSelectMusic = {
                        controller.changeOnlineSearchMode(OnlineSearchMode.APPLE_MUSIC)
                    },
                    onSelectMovie = {
                        controller.changeOnlineSearchMode(OnlineSearchMode.MOVIE)
                    }
                )

                OnlineSearchInput(
                    query = query,
                    mode = controller.onlineSearchMode,
                    busy = controller.onlineSearchBusy,
                    onQueryChange = { value ->
                        query = value
                        controller.onlineSearchQuery = value
                    },
                    onVoiceSearch = ::startOnlineVoiceSearch,
                    onClear = {
                        query = ""
                        controller.onlineSearchQuery = ""
                    },
                    onSearch = {
                        if (query.isNotBlank()) controller.searchOnline(query)
                    }
                )

                controller.onlineSearchError?.let { message ->
                    Text(
                        text = message,
                        color = colors.red,
                        fontSize = 12.sp
                    )
                }

                if (controller.onlineSearchResults.isEmpty() && !controller.onlineSearchBusy) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (controller.onlineSearchMode == OnlineSearchMode.APPLE_MUSIC) {
                                "Music sử dụng bản nghe thử từ iTunes Search."
                            } else {
                                "Kết quả Movie sẽ được phát tại màn hình Đang phát."
                            },
                            color = colors.textSecondary,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        contentPadding = PaddingValues(bottom = 8.dp)
                    ) {
                        items(controller.onlineSearchResults, key = { it.id }) { song ->
                            SongRow(
                                song = song,
                                artworkUrl = controller.artworkFor(song),
                                isCurrent = controller.currentSong?.id == song.id,
                                isFavorite = controller.isFavorite(song),
                                onClick = {
                                    controller.playOnlineResult(song)
                                    onDismiss()
                                },
                                onFavorite = { controller.toggleFavorite(song) }
                            )
                        }
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Đóng", color = colors.textSecondary)
                }
            }
        }
    }
}

@Composable
private fun OnlineSearchInput(
    query: String,
    mode: OnlineSearchMode,
    busy: Boolean,
    onQueryChange: (String) -> Unit,
    onVoiceSearch: () -> Unit,
    onClear: () -> Unit,
    onSearch: () -> Unit
) {
    val colors = LocalMusicColors.current
    val isApple = mode == OnlineSearchMode.APPLE_MUSIC
    val placeholder = if (isApple) {
        "Tên bài hát, ca sĩ hoặc album..."
    } else {
        "Tên video, bài hát hoặc kênh..."
    }
    val helperText = if (isApple) {
        "Tìm Music · Nhấn micro để tìm bằng giọng nói"
    } else {
        "Tìm Movie · Nhấn micro để tìm bằng giọng nói"
    }
    val modeIcon = if (isApple) Icons.Rounded.MusicNote else Icons.Rounded.Tv
    val canSearch = query.isNotBlank() && !busy

    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = colors.cardRaised,
            border = BorderStroke(
                1.dp,
                if (query.isNotBlank()) colors.purpleBright.copy(alpha = 0.72f) else colors.border
            )
        ) {
            Row(
                modifier = Modifier.padding(start = 13.dp, end = 6.dp, top = 7.dp, bottom = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = modeIcon,
                    contentDescription = null,
                    tint = colors.purpleBright,
                    modifier = Modifier.size(21.dp)
                )

                Spacer(Modifier.width(10.dp))

                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(
                        color = colors.textPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    cursorBrush = SolidColor(colors.purpleBright),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = { if (canSearch) onSearch() }
                    ),
                    decorationBox = { innerTextField ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isBlank()) {
                                Text(
                                    text = placeholder,
                                    color = colors.textMuted,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                // Khi người dùng bắt đầu gõ, micro tự ẩn để dành chỗ cho xóa/tìm.
                if (query.isBlank() && !busy) {
                    IconButton(
                        onClick = onVoiceSearch,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Mic,
                            contentDescription = "Tìm kiếm bằng giọng nói",
                            tint = colors.purpleBright,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }

                if (query.isNotBlank() && !busy) {
                    IconButton(
                        onClick = onClear,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = "Xóa từ khóa",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onSearch,
                    enabled = canSearch,
                    modifier = Modifier.size(38.dp)
                ) {
                    if (busy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(19.dp),
                            strokeWidth = 2.dp,
                            color = colors.purpleBright
                        )
                    } else {
                        Icon(
                            Icons.Rounded.Search,
                            contentDescription = "Tìm kiếm",
                            tint = if (canSearch) colors.purpleBright else colors.textMuted,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }
            }
        }

        Text(
            text = helperText,
            color = colors.textSecondary,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 5.dp)
        )
    }
}

/**
 * Music / Movie segmented selector.
 * One dark recessed outer capsule, two contiguous segments, one elevated purple active half.
 * Search mode and actual online playback callbacks are not changed here.
 */
@Composable
private fun OnlineModeSelector(
    selectedMode: OnlineSearchMode,
    onSelectMusic: () -> Unit,
    onSelectMovie: () -> Unit
) {
    val colors = LocalMusicColors.current
    val outerShape = RoundedCornerShape(28.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .shadow(
                elevation = 11.dp,
                shape = outerShape,
                ambientColor = Color.Black.copy(alpha = 0.52f),
                spotColor = colors.purple.copy(alpha = 0.22f)
            )
            .clip(outerShape)
            .background(
                // Nền rãnh chìm phía ngoài hai nửa viên thuốc.
                Brush.verticalGradient(
                    if (colors.isDark) listOf(
                        Color(0xFF01040D),
                        Color(0xFF071020),
                        Color(0xFF0F2138)
                    ) else listOf(colors.cardRaised, colors.card, colors.backgroundSoft)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        colors.purpleBright.copy(alpha = 0.36f),
                        Color.White.copy(alpha = 0.09f),
                        colors.purple.copy(alpha = 0.26f)
                    )
                ),
                shape = outerShape
            )
            .padding(4.dp)
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            OnlineModeButton(
                title = "Music",
                icon = Icons.Rounded.MusicNote,
                selected = selectedMode == OnlineSearchMode.APPLE_MUSIC,
                onClick = onSelectMusic,
                modifier = Modifier.weight(1f)
            )
            OnlineModeButton(
                title = "Movie",
                icon = Icons.Rounded.Tv,
                selected = selectedMode == OnlineSearchMode.MOVIE,
                onClick = onSelectMovie,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun OnlineModeButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val segmentShape = RoundedCornerShape(25.dp)
    val colors = LocalMusicColors.current
    val originalPurple = colors.purple == (if (colors.isDark) DarkMusicColors.purple else LightMusicColors.purple)
    val activeTop by animateColorAsState(
        targetValue = if (selected) (if (originalPurple) Color(0xFFAB40FB) else colors.purpleBright) else Color.Transparent,
        animationSpec = tween(durationMillis = 220),
        label = "onlineModeTop"
    )
    val activeBottom by animateColorAsState(
        targetValue = if (selected) (if (originalPurple) Color(0xFF6223CE) else colors.purple) else Color.Transparent,
        animationSpec = tween(durationMillis = 220),
        label = "onlineModeBottom"
    )
    val labelColor by animateColorAsState(
        targetValue = if (selected) Color.White else if (colors.isDark) Color(0xFFAFBCD3) else colors.textSecondary,
        animationSpec = tween(durationMillis = 220),
        label = "onlineModeText"
    )

    Box(
        modifier = modifier
            .fillMaxHeight()
            .shadow(
                elevation = if (selected) 7.dp else 0.dp,
                shape = segmentShape,
                ambientColor = (if (originalPurple) Color(0xFF902BF2) else colors.purple).copy(alpha = if (selected) 0.42f else 0f),
                spotColor = (if (originalPurple) Color(0xFFAF4FFF) else colors.purpleBright).copy(alpha = if (selected) 0.56f else 0f)
            )
            .clip(segmentShape)
            .background(Brush.verticalGradient(listOf(activeTop, activeBottom)))
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = if (selected) 0.55f else 0f),
                        Color.White.copy(alpha = if (selected) 0.06f else 0f)
                    )
                ),
                shape = segmentShape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 9.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = labelColor,
                modifier = Modifier.size(19.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = title,
                color = labelColor,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GradientText(
    text: String,
    brush: Brush,
    fontSize: androidx.compose.ui.unit.TextUnit,
    lineHeight: androidx.compose.ui.unit.TextUnit,
    fontWeight: FontWeight
) {
    androidx.compose.material3.Text(
        text = text,
        style = TextStyle(
            brush = brush,
            fontSize = fontSize,
            lineHeight = lineHeight,
            fontWeight = fontWeight
        ),
        maxLines = 1,
        overflow = TextOverflow.Clip
    )
}
// endregion Merged source: HomeScreen.kt

// region Merged source: MusicUiComponents.kt
@Immutable
internal data class MusicColors(
    val background: Color = Color(0xFF020812),
    val backgroundSoft: Color = Color(0xFF06111E),
    val card: Color = Color(0xFF091625),
    val cardRaised: Color = Color(0xFF0E2033),
    val border: Color = Color(0xFF21364D),
    val borderSoft: Color = Color(0xFF172B40),
    val purple: Color = Color(0xFF8D35FF),
    val purpleBright: Color = Color(0xFFB64DFF),
    val magenta: Color = Color(0xFFF22EDB),
    val blue: Color = Color(0xFF2F8BFF),
    val cyan: Color = Color(0xFF24C8FF),
    val green: Color = Color(0xFF21D483),
    val textPrimary: Color = Color(0xFFF7F8FC),
    val textSecondary: Color = Color(0xFFA6B0C3),
    val textMuted: Color = Color(0xFF718096),
    val red: Color = Color(0xFFFF4F70),
    val isDark: Boolean = true
)

internal val DarkMusicColors = MusicColors()

internal val LightMusicColors = MusicColors(
    background = Color(0xFFF4F7FC),
    backgroundSoft = Color(0xFFE8EEF8),
    card = Color.White,
    cardRaised = Color(0xFFF0F4FA),
    border = Color(0xFFD3DFEE),
    borderSoft = Color(0xFFE2EAF4),
    purple = Color(0xFF7929E8),
    purpleBright = Color(0xFF8D35FF),
    magenta = Color(0xFFD921C5),
    blue = Color(0xFF1E75E8),
    cyan = Color(0xFF0589C7),
    green = Color(0xFF14995D),
    textPrimary = Color(0xFF111827),
    textSecondary = Color(0xFF475569),
    textMuted = Color(0xFF64748B),
    red = Color(0xFFEF4444),
    isDark = false
)

// Accent palette is independent of dark/light mode. Keep purple identical to the legacy theme.
// Internal IDs are saved in SharedPreferences; changing display names does not reset a selection.
internal data class MusicAccentOption(
    val id: String,
    val title: String,
    val preview: Color,
    val darkPrimary: Color,
    val darkBright: Color,
    val darkHighlight: Color,
    val lightPrimary: Color,
    val lightBright: Color,
    val lightHighlight: Color
)

internal val MusicAccentOptions = listOf(
    MusicAccentOption(
        "purple", "Tím", Color(0xFF8D35FF),
        Color(0xFF8D35FF), Color(0xFFB64DFF), Color(0xFFF22EDB),
        Color(0xFF7929E8), Color(0xFF8D35FF), Color(0xFFD921C5)
    ),
    MusicAccentOption(
        "blue", "Xanh dương", Color(0xFF2563EB),
        Color(0xFF2563EB), Color(0xFF60A5FA), Color(0xFF38BDF8),
        Color(0xFF1D4ED8), Color(0xFF2563EB), Color(0xFF0284C7)
    ),
    MusicAccentOption(
        "teal", "Xanh ngọc", Color(0xFF0D9488),
        Color(0xFF0F766E), Color(0xFF2DD4BF), Color(0xFF06B6D4),
        Color(0xFF0F766E), Color(0xFF0D9488), Color(0xFF0891B2)
    ),
    MusicAccentOption(
        "green", "Xanh lá", Color(0xFF16A34A),
        Color(0xFF15803D), Color(0xFF4ADE80), Color(0xFF22C55E),
        Color(0xFF15803D), Color(0xFF16A34A), Color(0xFF16A34A)
    ),
    MusicAccentOption(
        "orange", "Cam", Color(0xFFEA580C),
        Color(0xFFC2410C), Color(0xFFFB923C), Color(0xFFF59E0B),
        Color(0xFF9A3412), Color(0xFFEA580C), Color(0xFFD97706)
    ),
    MusicAccentOption(
        "pink", "Hồng", Color(0xFFDB2777),
        Color(0xFFBE185D), Color(0xFFF472B6), Color(0xFFEC4899),
        Color(0xFFBE185D), Color(0xFFDB2777), Color(0xFFBE185D)
    ),
    MusicAccentOption(
        "red", "Đỏ", Color(0xFFDC2626),
        Color(0xFFB91C1C), Color(0xFFF87171), Color(0xFFFB7185),
        Color(0xFFB91C1C), Color(0xFFDC2626), Color(0xFFBE123C)
    ),
    MusicAccentOption(
        "amber", "Hổ phách", Color(0xFFB45309),
        Color(0xFF92400E), Color(0xFFFBBF24), Color(0xFFF59E0B),
        Color(0xFF92400E), Color(0xFFB45309), Color(0xFFD97706)
    )
)

/**
 * Build an accessible accent from a free-form HSV hue. The eight original accent
 * presets do not use these colors, so their appearance stays exactly as before.
 * In light mode, white text/icons on the primary and bright colors get at least
 * WCAG AA (4.5:1) contrast. Dark mode is intentionally more vibrant.
 */
internal fun freeHueMusicAccent(hue: Float, isDark: Boolean): Triple<Color, Color, Color> {
    val h = ((hue.coerceIn(0f, 360f) % 360f) + 360f) % 360f
    if (isDark) {
        return Triple(
            Color.hsv(h, 0.72f, 0.94f),
            Color.hsv(h, 0.58f, 1.00f),
            Color.hsv((h + 24f) % 360f, 0.76f, 0.98f)
        )
    }

    fun linear(channel: Float): Double {
        val c = channel.toDouble()
        return if (c <= 0.04045) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
    }

    fun readable(saturation: Float, initialValue: Float): Color {
        var value = initialValue
        var candidate = Color.hsv(h, saturation, value)
        while (value > 0.32f) {
            val luminance = 0.2126 * linear(candidate.red) +
                    0.7152 * linear(candidate.green) + 0.0722 * linear(candidate.blue)
            if (1.05 / (luminance + 0.05) >= 4.5) break
            value = (value - 0.025f).coerceAtLeast(0.32f)
            candidate = Color.hsv(h, saturation, value)
        }
        return candidate
    }

    return Triple(
        readable(0.82f, 0.86f),
        readable(0.74f, 0.98f),
        readable(0.78f, 0.88f)
    )
}

internal data class MeloWareLanguageOption(
    val code: String,
    val nativeName: String
)

/**
 * Loads all UI translations from app/src/main/assets/meloware_languages.json.
 * Missing keys always fall back to Vietnamese text supplied by the caller,
 * so a damaged or incomplete JSON file can never prevent MeloWare from opening.
 */
internal class MeloWareTranslationCatalog private constructor(
    val defaultLanguage: String,
    val languages: List<MeloWareLanguageOption>,
    private val values: Map<String, Map<String, String>>
) {
    fun isSupported(code: String?): Boolean = resolveLanguage(code) != null

    fun resolveLanguage(rawCode: String?): String? {
        if (rawCode.isNullOrBlank()) return null
        val primary = rawCode.replace('_', '-').substringBefore('-').lowercase()
        val normalized = when (primary) {
            "in" -> "id" // Android legacy Indonesian code
            else -> primary
        }
        return languages.firstOrNull { it.code == normalized }?.code
    }

    fun text(
        language: String,
        key: String,
        fallback: String,
        replacements: Map<String, Any?> = emptyMap()
    ): String {
        val resolved = resolveLanguage(language) ?: defaultLanguage
        var result: String = values[resolved]?.get(key)
            ?: (if (resolved != defaultLanguage) values["en"]?.get(key) else null)
            ?: values[defaultLanguage]?.get(key)
            ?: fallback
        replacements.forEach { (name, value) ->
            result = result.replace("{$name}", value?.toString().orEmpty())
        }
        return result
    }

    companion object {
        private const val TAG = "MeloWareI18n"
        private const val ASSET_NAME = "meloware_languages.json"
        @Volatile private var cached: MeloWareTranslationCatalog? = null

        fun load(context: Context): MeloWareTranslationCatalog {
            cached?.let { return it }
            return synchronized(this) {
                cached ?: runCatching {
                    val json = context.assets.open(ASSET_NAME).bufferedReader(Charsets.UTF_8).use { it.readText() }
                    parse(json)
                }.onFailure {
                    Log.w(TAG, "Cannot load $ASSET_NAME; Vietnamese fallback will be used", it)
                }.getOrElse { fallbackCatalog() }.also { cached = it }
            }
        }

        private fun parse(json: String): MeloWareTranslationCatalog {
            val root = JSONObject(json)
            val defaultLanguage: String = root
                .optString("defaultLanguage", "vi")
                .orEmpty()
                .trim()
                .lowercase()
                .ifBlank { "vi" }
            val languageArray = root.optJSONArray("languages")
            val parsedLanguages = mutableListOf<MeloWareLanguageOption>()
            if (languageArray != null) {
                for (index in 0 until languageArray.length()) {
                    val item = languageArray.optJSONObject(index) ?: continue
                    val code = item.optString("code", "")
                        .orEmpty()
                        .trim()
                        .lowercase()
                    val name = item.optString("name", "")
                        .orEmpty()
                        .trim()
                    val alreadyAdded = parsedLanguages.any { option ->
                        option.code == code
                    }
                    if (code.isNotBlank() && name.isNotBlank() && !alreadyAdded) {
                        parsedLanguages.add(
                            MeloWareLanguageOption(
                                code = code,
                                nativeName = name
                            )
                        )
                    }
                }
            }
            if (parsedLanguages.isEmpty()) {
                parsedLanguages.addAll(fallbackLanguages())
            }
            val languages: List<MeloWareLanguageOption> = parsedLanguages.toList()

            val translations = linkedMapOf<String, Map<String, String>>()
            val translationRoot = root.optJSONObject("translations")
            if (translationRoot != null) {
                val languageKeys = translationRoot.keys()
                while (languageKeys.hasNext()) {
                    val code = languageKeys.next().orEmpty().lowercase()
                    val objectForLanguage = translationRoot.optJSONObject(code) ?: continue
                    val map = linkedMapOf<String, String>()
                    val keys = objectForLanguage.keys()
                    while (keys.hasNext()) {
                        val key = keys.next().orEmpty()
                        val value = objectForLanguage.optString(key).orEmpty()
                        if (value.isNotBlank()) map[key] = value
                    }
                    translations[code] = map
                }
            }
            return MeloWareTranslationCatalog(defaultLanguage, languages, translations)
        }

        private fun fallbackLanguages(): List<MeloWareLanguageOption> = listOf(
            MeloWareLanguageOption("vi", "Tiếng Việt"),
            MeloWareLanguageOption("en", "English"),
            MeloWareLanguageOption("zh", "简体中文"),
            MeloWareLanguageOption("ja", "日本語"),
            MeloWareLanguageOption("ko", "한국어"),
            MeloWareLanguageOption("es", "Español"),
            MeloWareLanguageOption("fr", "Français"),
            MeloWareLanguageOption("de", "Deutsch"),
            MeloWareLanguageOption("ru", "Русский"),
            MeloWareLanguageOption("pt", "Português"),
            MeloWareLanguageOption("id", "Bahasa Indonesia"),
            MeloWareLanguageOption("hi", "हिन्दी"),
            MeloWareLanguageOption("ar", "العربية"),
            MeloWareLanguageOption("th", "ไทย"),
            MeloWareLanguageOption("it", "Italiano")
        )

        fun fallbackCatalog() = MeloWareTranslationCatalog(
            defaultLanguage = "vi",
            languages = fallbackLanguages(),
            values = emptyMap()
        )
    }
}

internal val LocalMusicColors = compositionLocalOf { DarkMusicColors }
internal val LocalAppLanguage = compositionLocalOf { "vi" }
internal val LocalMeloWareTranslations = compositionLocalOf {
    MeloWareTranslationCatalog.fallbackCatalog()
}

@Composable
internal fun mwString(
    key: String,
    fallback: String,
    vararg replacements: Pair<String, Any?>
): String = LocalMeloWareTranslations.current.text(
    language = LocalAppLanguage.current,
    key = key,
    fallback = fallback,
    replacements = replacements.toMap()
)

internal enum class ShareGuideType {
    PHONE_COMPUTER,
    PHONE_PHONE,
    LINK_ANY_DEVICE,
    INTERNET
}

private data class ShareGuideStep(
    val icon: ImageVector,
    val key: String,
    val fallback: String
)

private data class ShareGuideSpec(
    val titleKey: String,
    val titleFallback: String,
    val introKey: String,
    val introFallback: String,
    val steps: List<ShareGuideStep>,
    val noteKey: String,
    val noteFallback: String
)

private fun shareGuideSpec(type: ShareGuideType): ShareGuideSpec = when (type) {
    ShareGuideType.PHONE_COMPUTER -> ShareGuideSpec(
        titleKey = "guide.phone_pc.title",
        titleFallback = "Hướng dẫn điện thoại ↔ máy tính",
        introKey = "guide.phone_pc.intro",
        introFallback = "Điện thoại tạo đường dẫn, máy tính mở bằng Chrome và chọn thư mục nhạc.",
        steps = listOf(
            ShareGuideStep(Icons.Rounded.Wifi, "guide.phone_pc.step1", "Kết nối điện thoại và máy tính vào cùng một mạng Wi-Fi."),
            ShareGuideStep(Icons.Rounded.Smartphone, "guide.phone_pc.step2", "Trên điện thoại nhấn Tạo link MeloWare."),
            ShareGuideStep(Icons.Rounded.Computer, "guide.phone_pc.step3", "Trên máy tính mở đường dẫn được hiển thị bằng Chrome hoặc Edge."),
            ShareGuideStep(Icons.Rounded.Folder, "guide.phone_pc.step4", "Trên trình duyệt nhấn Chọn thư mục nhạc và giữ tab trình duyệt đang mở."),
            ShareGuideStep(Icons.Rounded.PlayArrow, "guide.phone_pc.step5", "Quay lại điện thoại để duyệt, nghe online hoặc tải từng bài hát.")
        ),
        noteKey = "guide.phone_pc.note",
        noteFallback = "Nếu không mở được link, hãy kiểm tra hai thiết bị cùng Wi-Fi và không dùng mạng có chặn thiết bị nội bộ."
    )

    ShareGuideType.PHONE_PHONE -> ShareGuideSpec(
        titleKey = "guide.phone_phone.title",
        titleFallback = "Hướng dẫn điện thoại ↔ điện thoại",
        introKey = "guide.phone_phone.intro",
        introFallback = "Hai điện thoại cài MeloWare chia sẻ thư mục nhạc trực tiếp trong mạng Wi-Fi nội bộ.",
        steps = listOf(
            ShareGuideStep(Icons.Rounded.Wifi, "guide.phone_phone.step1", "Kết nối cả hai điện thoại vào cùng một mạng Wi-Fi."),
            ShareGuideStep(Icons.Rounded.Smartphone, "guide.phone_phone.step2", "Máy A chọn Máy gửi, chọn thư mục được phép chia sẻ rồi bật chia sẻ."),
            ShareGuideStep(Icons.Rounded.Search, "guide.phone_phone.step3", "Máy B chọn Máy nhận và nhấn Quét lại để tìm máy A."),
            ShareGuideStep(Icons.Rounded.Link, "guide.phone_phone.step4", "Chọn máy A, sau đó Duyệt thư mục hoặc Nghe đồng bộ."),
            ShareGuideStep(Icons.Rounded.Close, "guide.phone_phone.step5", "Khi kết thúc, nhấn Ngắt kết nối hoặc Dừng chia sẻ trên máy A.")
        ),
        noteKey = "guide.phone_phone.note",
        noteFallback = "Không nên dùng Wi-Fi công cộng. Nếu không thấy máy A, mạng có thể đang bật AP isolation."
    )

    ShareGuideType.LINK_ANY_DEVICE -> ShareGuideSpec(
        titleKey = "guide.link.title",
        titleFallback = "Hướng dẫn chia sẻ link",
        introKey = "guide.link.intro",
        introFallback = "MeloWare tạo một URL nội bộ để trình duyệt, VLC hoặc thiết bị khác mở bài nhạc.",
        steps = listOf(
            ShareGuideStep(Icons.Rounded.Smartphone, "guide.link.step1", "Trên điện thoại nhấn Bắt đầu phát qua Wi-Fi để tạo đường dẫn."),
            ShareGuideStep(Icons.Rounded.Wifi, "guide.link.step2", "Thiết bị nhận phải kết nối cùng mạng Wi-Fi với điện thoại."),
            ShareGuideStep(Icons.Rounded.ContentCopy, "guide.link.step3", "Nhấn Sao chép hoặc Chia sẻ để gửi URL cho thiết bị nhận."),
            ShareGuideStep(Icons.Rounded.Link, "guide.link.step4", "Mở URL bằng trình duyệt, VLC hoặc thiết bị âm thanh hỗ trợ URL mạng."),
            ShareGuideStep(Icons.Rounded.Close, "guide.link.step5", "Sau khi dùng xong, nhấn Dừng máy chủ Wi-Fi.")
        ),
        noteKey = "guide.link.note",
        noteFallback = "Đường dẫn chỉ hoạt động khi MeloWare còn mở máy chủ và hai thiết bị vẫn ở cùng mạng."
    )

    ShareGuideType.INTERNET -> ShareGuideSpec(
        titleKey = "guide.internet.title",
        titleFallback = "Hướng dẫn kết nối qua Internet",
        introKey = "guide.internet.intro",
        introFallback = "Hai người dùng MeloWare ở hai mạng khác nhau ghép nối bằng mã phòng WebRTC P2P.",
        steps = listOf(
            ShareGuideStep(Icons.Rounded.Public, "guide.internet.step1", "Máy A chọn Chia sẻ và nhấn Tạo mã kết nối."),
            ShareGuideStep(Icons.Rounded.Share, "guide.internet.step2", "Gửi riêng mã phòng qua Zalo, Messenger, email hoặc ứng dụng khác."),
            ShareGuideStep(Icons.Rounded.Link, "guide.internet.step3", "Máy B chọn Nghe, nhập mã nhận từ máy A và tham gia phòng."),
            ShareGuideStep(Icons.Rounded.CheckCircle, "guide.internet.step4", "Máy A chấp nhận máy B, sau đó chọn thư mục nhạc được phép chia sẻ."),
            ShareGuideStep(Icons.Rounded.Download, "guide.internet.step5", "Máy B có thể duyệt, phát online hoặc tải từng bài hay toàn bộ thư mục.")
        ),
        noteKey = "guide.internet.note",
        noteFallback = "P2P phụ thuộc loại mạng/NAT. Nếu ICE FAILED, hãy thử đổi Wi-Fi hoặc dữ liệu di động rồi tạo phòng mới."
    )
}

@Composable
internal fun ShareGuideButton(
    type: ShareGuideType,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    var showGuide by rememberSaveable { mutableStateOf(false) }
    IconButton(onClick = { showGuide = true }, modifier = modifier) {
        Icon(
            imageVector = Icons.Rounded.HelpOutline,
            contentDescription = mwString("common.help", "Hướng dẫn"),
            tint = colors.purpleBright
        )
    }
    if (showGuide) {
        ShareGuideDialog(type = type, onDismiss = { showGuide = false })
    }
}

@Composable
private fun ShareGuideDialog(
    type: ShareGuideType,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    val spec = remember(type) { shareGuideSpec(type) }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).heightIn(max = 690.dp),
            shape = RoundedCornerShape(24.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = colors.purple.copy(alpha = 0.16f)) {
                        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.HelpOutline, null, tint = colors.purpleBright)
                        }
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            mwString(spec.titleKey, spec.titleFallback),
                            color = colors.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            mwString(spec.introKey, spec.introFallback),
                            color = colors.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, mwString("common.close", "Đóng"), tint = colors.textSecondary)
                    }
                }

                spec.steps.forEachIndexed { index, step ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(15.dp),
                        color = colors.backgroundSoft,
                        border = BorderStroke(1.dp, colors.border)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(40.dp),
                                shape = CircleShape,
                                color = colors.purple.copy(alpha = 0.18f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(step.icon, null, tint = colors.purpleBright, modifier = Modifier.size(21.dp))
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${index + 1}",
                                    color = colors.purpleBright,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    mwString(step.key, step.fallback),
                                    color = colors.textPrimary,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = colors.purple.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.35f))
                ) {
                    Text(
                        mwString(spec.noteKey, spec.noteFallback),
                        modifier = Modifier.padding(12.dp),
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Start
                    )
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                ) {
                    Text(mwString("common.understood", "Đã hiểu"))
                }
            }
        }
    }
}

@Composable
internal fun TunertoolsTheme(
    isDark: Boolean = true,
    language: String = "vi",
    accentId: String = "purple",
    accentHue: Float = 275f,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val translationCatalog = remember(context.applicationContext) {
        MeloWareTranslationCatalog.load(context.applicationContext)
    }
    val base = if (isDark) DarkMusicColors else LightMusicColors
    val accent = MusicAccentOptions.firstOrNull { it.id == accentId }
    // No preference (or an invalid one) uses the original purple palette exactly.
    val colors = when {
        accentId == "custom" -> {
            val (primary, bright, highlight) = freeHueMusicAccent(accentHue, isDark)
            base.copy(purple = primary, purpleBright = bright, magenta = highlight)
        }
        accent == null || accent.id == "purple" -> base
        else -> base.copy(
            purple = if (isDark) accent.darkPrimary else accent.lightPrimary,
            purpleBright = if (isDark) accent.darkBright else accent.lightBright,
            magenta = if (isDark) accent.darkHighlight else accent.lightHighlight
        )
    }
    val material = if (isDark) {
        darkColorScheme(
            primary = colors.purple,
            secondary = colors.blue,
            background = colors.background,
            surface = colors.card,
            onPrimary = Color.White,
            onBackground = colors.textPrimary,
            onSurface = colors.textPrimary
        )
    } else {
        androidx.compose.material3.lightColorScheme(
            primary = colors.purple,
            secondary = colors.blue,
            background = colors.background,
            surface = colors.card,
            onPrimary = Color.White,
            onBackground = colors.textPrimary,
            onSurface = colors.textPrimary
        )
    }
    CompositionLocalProvider(
        LocalMusicColors provides colors,
        LocalAppLanguage provides language,
        LocalMeloWareTranslations provides translationCatalog
    ) {
        MaterialTheme(colorScheme = material, content = content)
    }
}

@Composable
internal fun ArtworkImage(
    song: SongItem,
    artworkUrl: String?,
    modifier: Modifier = Modifier,
    cornerRadius: Int = 16
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val shape = RoundedCornerShape(cornerRadius.dp)

    // Luon co anh du phong hai not nhac: khi chua co anh, dang tai hoac link anh loi.
    // Anh that (neu co) nam phia tren va phu kin placeholder sau khi Coil tai thanh cong.
    Box(modifier = modifier.clip(shape)) {
        DoubleNoteArtworkPlaceholder(modifier = Modifier.fillMaxSize())
        if (!artworkUrl.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(artworkUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Ảnh bìa ${song.title}",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun DoubleNoteArtworkPlaceholder(modifier: Modifier = Modifier) {
    val colors = LocalMusicColors.current
    val originalPurple = colors.purple == (if (colors.isDark) DarkMusicColors.purple else LightMusicColors.purple)
    Box(
        modifier = modifier.background(
            Brush.linearGradient(
                colors = if (colors.isDark) {
                    // Keep the original deep navy placeholder in Dark Mode.
                    listOf(
                        Color(0xFF05091A),
                        if (originalPurple) Color(0xFF171039) else androidx.compose.ui.graphics.lerp(colors.purple, Color.Black, 0.80f),
                        Color(0xFF071429)
                    )
                } else {
                    // Light Mode: muted lavender/blue like the surrounding library cards.
                    // The placeholder is only visible when album artwork is unavailable.
                    listOf(
                        androidx.compose.ui.graphics.lerp(Color.White, colors.purple, 0.06f),
                        androidx.compose.ui.graphics.lerp(Color.White, colors.blue, 0.05f),
                        Color(0xFFF0F4FB)
                    )
                }
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val unit = size.minDimension
            if (unit <= 0f) return@Canvas

            val center = Offset(size.width / 2f, size.height / 2f)
            val noteBrush = Brush.linearGradient(
                colors = if (colors.isDark) {
                    if (originalPurple) {
                        listOf(Color(0xFFFF46C7), Color(0xFFB43EFF), Color(0xFF3DAEFF))
                    } else {
                        listOf(colors.magenta, colors.purpleBright, colors.purple)
                    }
                } else if (originalPurple) {
                    // Softer double note, readable even on small 48 dp thumbnails.
                    listOf(Color(0xFF9C76CF), Color(0xFF865FBD), Color(0xFF7279BD))
                } else {
                    listOf(
                        androidx.compose.ui.graphics.lerp(colors.magenta, Color(0xFF8B96AD), 0.65f),
                        androidx.compose.ui.graphics.lerp(colors.purpleBright, Color(0xFF8794B1), 0.65f),
                        androidx.compose.ui.graphics.lerp(colors.blue, Color(0xFF86A6C3), 0.65f)
                    )
                },
                start = Offset(center.x - unit * 0.32f, center.y + unit * 0.24f),
                end = Offset(center.x + unit * 0.30f, center.y - unit * 0.30f)
            )

            // Glow nhe phia sau, khong lam bien dang bieu tuong.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        (if (originalPurple) Color(0xFF9E3BFF) else colors.purpleBright)
                            .copy(alpha = if (colors.isDark) 0.30f else 0.055f),
                        (if (originalPurple) Color(0xFF246BFF) else colors.magenta)
                            .copy(alpha = if (colors.isDark) 0.09f else 0.015f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = unit * 0.50f
                ),
                radius = unit * 0.50f,
                center = center
            )

            // Ty le cua cap not moc kep: dau not thap, than cao va beam nghieng nhe.
            val leftHeadCenter = Offset(center.x - unit * 0.205f, center.y + unit * 0.170f)
            val rightHeadCenter = Offset(center.x + unit * 0.165f, center.y + unit * 0.075f)
            val headWidth = unit * 0.245f
            val headHeight = unit * 0.155f
            val stemWidth = (unit * 0.047f).coerceAtLeast(1.5f)

            val leftStemX = leftHeadCenter.x + headWidth * 0.37f
            val rightStemX = rightHeadCenter.x + headWidth * 0.37f
            val leftStemTop = center.y - unit * 0.245f
            val rightStemTop = center.y - unit * 0.340f

            // Than not dung thang, cham vao mep phai dau not.
            drawLine(
                brush = noteBrush,
                start = Offset(leftStemX, leftHeadCenter.y - headHeight * 0.08f),
                end = Offset(leftStemX, leftStemTop),
                strokeWidth = stemWidth,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
            drawLine(
                brush = noteBrush,
                start = Offset(rightStemX, rightHeadCenter.y - headHeight * 0.08f),
                end = Offset(rightStemX, rightStemTop),
                strokeWidth = stemWidth,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )

            // Beam day va mem, noi hai than theo dung do nghieng cua not kep.
            val beamPath = Path().apply {
                moveTo(leftStemX - stemWidth * 0.52f, leftStemTop - unit * 0.008f)
                cubicTo(
                    leftStemX + unit * 0.105f,
                    leftStemTop - unit * 0.022f,
                    rightStemX - unit * 0.100f,
                    rightStemTop - unit * 0.012f,
                    rightStemX + stemWidth * 0.55f,
                    rightStemTop - unit * 0.004f
                )
                lineTo(rightStemX + stemWidth * 0.55f, rightStemTop + unit * 0.086f)
                cubicTo(
                    rightStemX - unit * 0.100f,
                    rightStemTop + unit * 0.076f,
                    leftStemX + unit * 0.105f,
                    leftStemTop + unit * 0.067f,
                    leftStemX - stemWidth * 0.52f,
                    leftStemTop + unit * 0.080f
                )
                close()
            }
            drawPath(beamPath, brush = noteBrush)

            // Dau not ellipse xoay nhe, khong ve thanh hinh tron.
            fun drawNoteHead(centerPoint: Offset) {
                withTransform({ rotate(-18f, pivot = centerPoint) }) {
                    drawOval(
                        brush = noteBrush,
                        topLeft = Offset(
                            centerPoint.x - headWidth / 2f,
                            centerPoint.y - headHeight / 2f
                        ),
                        size = Size(headWidth, headHeight)
                    )
                }
            }
            drawNoteHead(leftHeadCenter)
            drawNoteHead(rightHeadCenter)

            // Vet sang rat mong giup icon ro net o kich thuoc nho.
            drawLine(
                color = Color.White.copy(alpha = if (colors.isDark) 0.20f else 0.09f),
                start = Offset(leftStemX + stemWidth * 0.12f, leftStemTop + unit * 0.010f),
                end = Offset(rightStemX + stemWidth * 0.12f, rightStemTop + unit * 0.010f),
                strokeWidth = (unit * 0.010f).coerceAtLeast(0.8f),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

@Composable
internal fun SectionTitle(
    title: String,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            color = colors.textPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        if (!actionText.isNullOrBlank() && onAction != null) {
            Text(
                text = actionText,
                color = colors.purpleBright,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
internal fun SourceCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    colorsGradient: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = modifier
            .height(112.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, colors.border)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(colorsGradient))
                .padding(14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    modifier = Modifier.size(40.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.22f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/** Only translate the built-in unknown-artist placeholder; preserve real artist metadata. */
@Composable
internal fun mwArtistLabel(raw: String): String = when (raw.trim().lowercase()) {
    "nghệ sĩ chưa biết", "unknown artist", "<unknown>" ->
        mwString("library.unknown_artist", "Nghệ sĩ chưa biết")
    else -> raw
}

@Composable
internal fun SongRow(
    song: SongItem,
    artworkUrl: String?,
    isCurrent: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onMore: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCurrent) colors.purple.copy(alpha = 0.16f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtworkImage(
            song = song,
            artworkUrl = artworkUrl,
            modifier = Modifier.size(56.dp),
            cornerRadius = 12
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = if (isCurrent) colors.purpleBright else colors.textPrimary,
                fontSize = 15.sp,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${mwArtistLabel(song.artist)} • ${song.durationLabel}",
                color = colors.textSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onFavorite, modifier = Modifier.size(38.dp)) {
            Icon(
                imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = mwString("library.favorites", "Yêu thích"),
                tint = if (isFavorite) colors.magenta else colors.textMuted,
                modifier = Modifier.size(22.dp)
            )
        }
        if (onMore != null) {
            IconButton(onClick = onMore, modifier = Modifier.size(34.dp)) {
                Text("⋮", color = colors.textSecondary, fontSize = 24.sp)
            }
        }
    }
}

@Composable
internal fun MiniPlayer(
    song: SongItem,
    artworkUrl: String?,
    positionMs: Long,
    durationMs: Long,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
    compactHomeCard: Boolean = false
) {
    val colors = LocalMusicColors.current
    val shape = RoundedCornerShape(24.dp)
    val progress = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
    } else {
        0f
    }
    val shownPosition = positionMs.coerceIn(0L, durationMs.coerceAtLeast(0L))
    var isSeeking by remember(song.id) { mutableStateOf(false) }
    var seekFraction by remember(song.id) { mutableFloatStateOf(progress) }
    val displayedProgress = if (isSeeking) seekFraction else progress
    val displayedPosition = if (isSeeking && durationMs > 0L) {
        (durationMs.toDouble() * seekFraction.toDouble()).toLong()
            .coerceIn(0L, durationMs)
    } else {
        shownPosition
    }
    val glassOverlay = if (colors.isDark) {
        if (colors.purple == DarkMusicColors.purple) {
            listOf(
                Color(0xFF06101D).copy(alpha = 0.91f),
                Color(0xFF17152E).copy(alpha = 0.66f),
                Color(0xFF071726).copy(alpha = 0.84f)
            )
        } else {
            listOf(
                colors.backgroundSoft.copy(alpha = 0.91f),
                androidx.compose.ui.graphics.lerp(colors.purple, colors.card, 0.88f).copy(alpha = 0.66f),
                colors.background.copy(alpha = 0.84f)
            )
        }
    } else {
        listOf(
            Color.White.copy(alpha = 0.97f),
            colors.card.copy(alpha = 0.94f),
            Color.White.copy(alpha = 0.96f)
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(if (compactHomeCard) 108.dp else 116.dp)
            .clip(shape)
            .background(colors.card, shape)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        colors.purpleBright.copy(alpha = 0.88f),
                        colors.blue.copy(alpha = 0.52f),
                        colors.purple.copy(alpha = 0.78f)
                    )
                ),
                shape = shape
            )
            .clickable(onClick = onClick)
    ) {
        // The card stays a complete rounded rectangle. The raised Play button is
        // drawn later on top of its lower edge, matching the approved reference.
        if (!artworkUrl.isNullOrBlank()) {
            val context = androidx.compose.ui.platform.LocalContext.current
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(artworkUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        alpha = if (colors.isDark) 0.40f else 0.22f
                        scaleX = 1.10f
                        scaleY = 1.10f
                    }
            )
        } else {
            DoubleNoteArtworkPlaceholder(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = if (colors.isDark) 0.34f else 0.16f }
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.horizontalGradient(glassOverlay))
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = if (colors.isDark) 0.08f else 0.20f),
                            Color.Transparent,
                            Color.Black.copy(alpha = if (colors.isDark) 0.25f else 0.05f)
                        )
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 12.dp, top = 8.dp, end = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArtworkImage(
                song = song,
                artworkUrl = artworkUrl,
                modifier = Modifier.size(72.dp),
                cornerRadius = 15
            )
            Spacer(Modifier.width(12.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = colors.textPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = song.artist,
                            color = colors.textSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = onFavorite,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = mwString("library.favorites", "Yêu thích"),
                            tint = if (isFavorite) colors.magenta else colors.textPrimary.copy(alpha = 0.92f),
                            modifier = Modifier.size(25.dp)
                        )
                    }
                }

                Spacer(Modifier.height(5.dp))
                // Keep the seek timeline inside the measured bounds of the card.
                // The previous negative offset only moved the drawing, not its layout slot,
                // which caused the time labels to be clipped by the card bottom edge.
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .pointerInput(song.id, durationMs) {
                            if (durationMs <= 0L) return@pointerInput
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                down.consume()
                                isSeeking = true

                                fun updateSeekFraction(x: Float) {
                                    val width = size.width.toFloat().coerceAtLeast(1f)
                                    seekFraction = (x / width).coerceIn(0f, 1f)
                                }

                                updateSeekFraction(down.position.x)
                                var pointerPressed = true
                                while (pointerPressed) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == down.id }
                                        ?: break
                                    updateSeekFraction(change.position.x)
                                    pointerPressed = change.pressed
                                    change.consume()
                                }

                                val targetPosition =
                                    (durationMs.toDouble() * seekFraction.toDouble()).toLong()
                                        .coerceIn(0L, durationMs)
                                isSeeking = false
                                onSeek(targetPosition)
                            }
                        }
                ) {
                    val y = size.height / 2f
                    val stroke = 3.5.dp.toPx()
                    val thumbRadius = 4.5.dp.toPx()
                    val thumbX = (size.width * displayedProgress)
                        .coerceIn(thumbRadius, (size.width - thumbRadius).coerceAtLeast(thumbRadius))
                    drawLine(
                        color = colors.borderSoft.copy(alpha = 0.96f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = stroke,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(colors.purple, colors.magenta, colors.blue)
                        ),
                        start = Offset(0f, y),
                        end = Offset(thumbX, y),
                        strokeWidth = stroke,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                    drawCircle(
                        color = Color.White,
                        radius = thumbRadius,
                        center = Offset(thumbX, y)
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 1.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatDuration(displayedPosition),
                        color = colors.textSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = formatDuration(durationMs.coerceAtLeast(0L)),
                        color = colors.textPrimary.copy(alpha = 0.92f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
internal fun PlayerBottomArea(
    controller: MusicController,
    selectedScreen: MusicScreen,
    modifier: Modifier = Modifier
) {
    val song = controller.currentSong
    // Only the HOME mini-player is lowered by 8dp. Its dock remains anchored
    // to the same safe bottom position and other screens are unaffected.
    val compactHomeCard = selectedScreen == MusicScreen.HOME &&
            LocalConfiguration.current.fontScale <= 1.15f

    // Two independent layers: a complete glass song card and a detached black dock.
    // The circular Play control is painted after both layers and overlaps the card,
    // creating the visual indentation without cutting the card itself.
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = 12.dp, top = 3.dp, end = 12.dp, bottom = 4.dp)
            .height(if (song != null) (if (compactHomeCard) 194.dp else 202.dp) else 100.dp)
    ) {
        if (song != null) {
            MiniPlayer(
                compactHomeCard = compactHomeCard,
                song = song,
                artworkUrl = controller.artworkFor(song),
                positionMs = controller.positionMs,
                durationMs = controller.durationMs,
                isFavorite = controller.isFavorite(song),
                onClick = controller::openNowPlaying,
                onFavorite = { controller.toggleFavorite(song) },
                onSeek = controller::seekTo,
                modifier = Modifier.align(Alignment.TopCenter)
            )
        }

        BottomPlayerBar(
            selectedScreen = selectedScreen,
            isPlaying = controller.isPlaying,
            onHome = controller::openHome,
            onPrevious = controller::previous,
            onPlayPause = controller::togglePlayback,
            onNext = controller::next,
            onLibrary = { controller.openLibrary() },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
internal fun BottomPlayerBar(
    selectedScreen: MusicScreen,
    isPlaying: Boolean,
    onHome: () -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onLibrary: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    val playInteraction = remember { MutableInteractionSource() }
    val playPressed by playInteraction.collectIsPressedAsState()
    val playScale by animateFloatAsState(
        targetValue = if (playPressed) 0.90f else 1f,
        animationSpec = spring(dampingRatio = 0.70f, stiffness = 520f)
    )
    val ringTransition = rememberInfiniteTransition()
    val ringRotation by ringTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3_200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp)
    ) {
        // Detached black control dock, matching the reference image.
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(70.dp)
                .align(Alignment.BottomCenter),
            shape = RoundedCornerShape(35.dp),
            color = if (colors.isDark) Color(0xFF020611) else colors.card,
            border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.66f)),
            shadowElevation = 10.dp
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomNavItem(
                    icon = Icons.Rounded.Home,
                    label = mwString("nav.home", "Trang chủ"),
                    selected = selectedScreen == MusicScreen.HOME,
                    onClick = onHome,
                    edge = NavEnd.START,
                    modifier = Modifier.weight(1f)
                )
                BottomControlIcon(
                    icon = Icons.Rounded.SkipPrevious,
                    description = mwString("nav.previous", "Bài trước"),
                    onClick = onPrevious,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.weight(1.12f))
                BottomControlIcon(
                    icon = Icons.Rounded.SkipNext,
                    description = mwString("nav.next", "Bài tiếp theo"),
                    onClick = onNext,
                    modifier = Modifier.weight(1f)
                )
                BottomNavItem(
                    icon = Icons.Rounded.QueueMusic,
                    label = mwString("nav.library", "Thư viện"),
                    selected = selectedScreen == MusicScreen.LIBRARY,
                    onClick = onLibrary,
                    edge = NavEnd.END,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Animated spectrum ring at the exact intersection between the song card
        // and the black dock. The ring rotates continuously while the inner dark
        // halo keeps the Play/Pause button visually separated from both layers.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(98.dp)
                .graphicsLayer {
                    rotationZ = ringRotation
                    alpha = if (playPressed) 0.78f else 1f
                }
                .shadow(if (playPressed) 10.dp else 20.dp, CircleShape)
                .background(
                    Brush.sweepGradient(
                        listOf(
                            colors.purpleBright,
                            colors.magenta,
                            colors.cyan,
                            colors.blue,
                            colors.purple,
                            colors.purpleBright
                        )
                    ),
                    CircleShape
                )
                .padding(4.dp)
                .background(
                    if (colors.isDark) Color(0xFF01040B) else colors.background,
                    CircleShape
                )
                .border(
                    1.dp,
                    Color.White.copy(alpha = if (colors.isDark) 0.10f else 0.24f),
                    CircleShape
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 11.dp)
                .size(76.dp)
                .graphicsLayer {
                    scaleX = playScale
                    scaleY = playScale
                }
                .shadow(if (playPressed) 10.dp else 18.dp, CircleShape)
                .background(
                    if (colors.purple == (if (colors.isDark) DarkMusicColors.purple else LightMusicColors.purple)) Color(0xFF100C22) else colors.backgroundSoft,
                    CircleShape
                )
                .padding(4.dp)
                .background(
                    Brush.linearGradient(
                        listOf(colors.purpleBright, colors.purple, colors.magenta)
                    ),
                    CircleShape
                )
                .clickable(
                    interactionSource = playInteraction,
                    indication = null,
                    onClick = onPlayPause
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (isPlaying) "Tạm dừng" else "Phát",
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
        }
    }
}

private enum class NavEnd { START, END }

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    edge: NavEnd,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val iconScale by animateFloatAsState(
        targetValue = if (pressed) 0.85f else if (selected) 1.06f else 1f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 540f)
    )
    val glow by animateFloatAsState(
        targetValue = if (pressed) 1f else if (selected) 0.85f else 0f,
        animationSpec = tween(durationMillis = 250)
    )
    // Hai nut dau/cuoi om sat cung bo tron ngoai cua thanh menu.
    val itemShape = when (edge) {
        NavEnd.START -> RoundedCornerShape(topStart = 35.dp, bottomStart = 35.dp, topEnd = 16.dp, bottomEnd = 16.dp)
        NavEnd.END -> RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp, topEnd = 35.dp, bottomEnd = 35.dp)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(itemShape)
            .background(
                if (!colors.isDark && selected) colors.purple
                else colors.purple.copy(alpha = 0.43f * glow),
                itemShape
            )
            .border(
                1.5.dp,
                if (!colors.isDark && selected) colors.purpleBright
                else colors.purpleBright.copy(alpha = 0.80f * glow),
                itemShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 2.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) Color.White else colors.textSecondary,
                modifier = Modifier
                    .size(30.dp)
                    .graphicsLayer {
                        scaleX = iconScale
                        scaleY = iconScale
                    }
            )
        }
        // Labels sit closer to the icons; preserve the indicator and click area.
        Text(
            text = label,
            // Pull the label toward the icon without changing the dock height.
            modifier = Modifier.offset(y = (-3).dp),
            color = if (selected) Color.White else colors.textSecondary,
            fontSize = 10.sp,
            lineHeight = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        // Reserve the same space to keep icon/label alignment, but do not draw
        // an underline below the Home or Library labels.
        Spacer(modifier = Modifier.height(3.dp))
    }
}

@Composable
private fun BottomControlIcon(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.82f else 1f,
        animationSpec = spring(dampingRatio = 0.66f, stiffness = 620f)
    )

    Box(
        modifier = modifier
            .height(62.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .background(
                if (pressed) colors.purple.copy(alpha = 0.16f) else Color.Transparent,
                CircleShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = if (pressed) colors.purpleBright else colors.textPrimary,
            modifier = Modifier.size(if (pressed) 24.dp else 26.dp)
        )
    }
}

@Composable
internal fun EmptyLibraryState(
    title: String,
    description: String,
    buttonText: String,
    onButton: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            modifier = Modifier.size(70.dp),
            shape = CircleShape,
            color = colors.purple.copy(alpha = 0.16f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = colors.purpleBright,
                    modifier = Modifier.size(34.dp)
                )
            }
        }
        Text(title, color = colors.textPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(description, color = colors.textSecondary, fontSize = 13.sp)
        Button(
            onClick = onButton,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = colors.purple),
            contentPadding = PaddingValues(horizontal = 22.dp, vertical = 12.dp)
        ) {
            Text(buttonText, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

internal fun sourceIcon(source: LibrarySource): ImageVector = when (source) {
    LibrarySource.LOCAL -> Icons.Rounded.Smartphone
    LibrarySource.PERSONAL_DRIVE -> Icons.Rounded.Cloud
    LibrarySource.PUBLIC_DRIVE -> Icons.Rounded.Link
    LibrarySource.INTERNET -> Icons.Rounded.Link
    LibrarySource.DOWNLOADED -> Icons.Rounded.Download
    LibrarySource.FAVORITES -> Icons.Rounded.Favorite
    LibrarySource.ALL -> Icons.Rounded.MusicNote
}

@Composable
internal fun HorizontalChips(
    items: List<Pair<String, Boolean>>,
    onClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEachIndexed { index, (label, selected) ->
            Surface(
                modifier = Modifier.clickable { onClick(index) },
                shape = RoundedCornerShape(14.dp),
                color = if (selected) colors.purple else colors.cardRaised,
                border = BorderStroke(1.dp, if (selected) colors.purpleBright else colors.border)
            ) {
                Text(
                    text = label,
                    color = if (selected) Color.White else colors.textSecondary,
                    fontSize = 13.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 15.dp, vertical = 10.dp)
                )
            }
        }
    }
}
// endregion Merged source: MusicUiComponents.kt
