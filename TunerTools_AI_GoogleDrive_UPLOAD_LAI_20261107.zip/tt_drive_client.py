#!/usr/bin/env python3
"""TunerTools shared Google Drive uploader, Python 3.10+ standard library only.

Safe defaults: without --upload this ONLY reads local files and writes a local
inventory; Google Drive calls are made only when --upload is explicitly set.
Uses the same Drive OAuth client/refresh token as api_gp_drive.php (drive_token.json).
Does not modify the token, local source, or pre-existing browser-created folders.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import mimetypes
import os
import re
from pathlib import Path
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

CATEGORIES = ('songs', 'chords', 'tuner', 'metronome', 'training', 'documents', 'settings')
LANGUAGES = ('vi', 'en', 'es', 'fr', 'de', 'ru', 'ja', 'zh', 'th', 'lo', 'km', 'ko', 'pt', 'sw', 'ar')
FOLDER_MIME = 'application/vnd.google-apps.folder'
GOOGLE_DRIVE = 'https://www.googleapis.com/drive/v3/files'
GOOGLE_UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files'
CHUNK_SIZE = 4 * 1024 * 1024   # multiple of 256KiB for Drive resumable upload
RETRY_STATUSES = (408, 429, 500, 502, 503, 504)


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def dump_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.partial')
    with temp.open('w', encoding='utf-8', newline='\n') as out:
        json.dump(obj, out, indent=2, ensure_ascii=False)
        out.write('\n')
    os.replace(temp, path)


def file_hash(path: Path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with path.open('rb') as reader:
        while True:
            piece = reader.read(1024 * 1024)
            if not piece:
                break
            h.update(piece)
    return h.hexdigest()


def classify(relative: Path) -> str | None:
    chunks = relative.parts
    if len(chunks) < 3 or chunks[0] not in CATEGORIES:
        return None
    if re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,63}', chunks[1]) is None:
        return None
    if len(chunks) == 3 and chunks[2] == 'guide.json':
        return 'metadata'
    if len(chunks) == 3 and chunks[2] in ('thumbnail.jpg', 'thumbnail.png', 'thumbnail.webp'):
        return 'thumbnail'
    if len(chunks) == 4 and chunks[2] == 'videos' and chunks[3] == 'video.mp4':
        return 'video'
    if len(chunks) == 4 and chunks[2] == 'subtitles' and chunks[3] in {x + '.vtt' for x in LANGUAGES}:
        return 'subtitle'
    return None


def inventory(source: Path, calculate_hash: bool) -> tuple[list[dict], list[str]]:
    entries = []
    warnings = []
    for item in sorted(source.rglob('*')):
        if item.is_symlink():
            warnings.append('Skipped link: ' + str(item.relative_to(source)))
            continue
        if not item.is_file():
            continue
        rel = item.relative_to(source)
        kind = classify(rel)
        if not kind:
            warnings.append('Unrecognized guide file (not uploaded): ' + rel.as_posix())
            continue
        info = {
            'relative_path': rel.as_posix(),
            'type': kind,
            'size_bytes': item.stat().st_size,
            'md5': file_hash(item, 'md5') if calculate_hash else '',
            'sha256': file_hash(item, 'sha256') if calculate_hash else '',
            'drive_file_id': None,
            'status': 'local_only',
        }
        entries.append(info)
    return entries, warnings


class DriveError(RuntimeError):
    pass


class DriveClient:
    def __init__(self, token_path: Path):
        self.token_path = token_path
        with token_path.open('r', encoding='utf-8-sig') as f:
            self.token = json.load(f)
        if not isinstance(self.token, dict):
            raise DriveError('OAuth token JSON must be an object')
        self.access_token = ''
        self.refresh()

    def refresh(self):
        required = ('refresh_token', 'client_id', 'client_secret')
        if not all(self.token.get(k) for k in required):
            raise DriveError('Token missing refresh_token/client_id/client_secret; same OAuth token required')
        body = urllib.parse.urlencode({
            'grant_type': 'refresh_token',
            'refresh_token': self.token['refresh_token'],
            'client_id': self.token['client_id'],
            'client_secret': self.token['client_secret'],
        }).encode('utf-8')
        request = urllib.request.Request('https://oauth2.googleapis.com/token', body,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}, method='POST')
        try:
            with urllib.request.urlopen(request, timeout=40) as response:
                result = json.load(response)
        except urllib.error.HTTPError as err:
            raise DriveError('OAuth refresh HTTP ' + str(err.code) + '; token is unchanged') from None
        except Exception as err:
            raise DriveError('OAuth refresh network error: ' + str(err)) from err
        self.access_token = result.get('access_token') or ''
        if not self.access_token:
            raise DriveError('OAuth refresh returned no access_token')

    def request(self, url: str, method: str = 'GET', body: bytes | None = None,
                headers: dict | None = None, allow308: bool = False) -> tuple[int, bytes, Any]:
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or parsed.hostname not in ('www.googleapis.com', 'oauth2.googleapis.com'):
            raise DriveError('Unexpected upload host; refusing to send OAuth credentials')
        last_status = 0
        for attempt in range(6):
            request_headers = {
                'Authorization': 'Bearer ' + self.access_token,
                'Accept': 'application/json',
            }
            if headers:
                request_headers.update(headers)
            req = urllib.request.Request(url, body, headers=request_headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=120) as response:
                    return response.status, response.read(), response.headers
            except urllib.error.HTTPError as e:
                last_status = e.code
                payload = e.read(4096)
                if allow308 and e.code == 308:
                    return 308, payload, e.headers
                if e.code == 401 and attempt == 0:
                    self.refresh()
                    continue
                if e.code in RETRY_STATUSES and attempt < 5:
                    time.sleep(min(12, 2 ** attempt))
                    continue
                # Never expose headers or authentication material.
                reason = ''
                try:
                    raw = json.loads(payload)
                    err_obj = raw.get('error', {})
                    reason = str(err_obj.get('status', '')) if isinstance(err_obj, dict) else ''
                except Exception:
                    pass
                raise DriveError(f'Google API HTTP {e.code} {reason}; method={method}') from None
            except (OSError, TimeoutError) as e:
                if attempt < 5:
                    time.sleep(min(12, 2 ** attempt))
                    continue
                raise DriveError('Google API network failure: ' + str(e)) from e
        raise DriveError('Google API exhausted retries HTTP ' + str(last_status))

    def json_request(self, url: str, method='GET', payload: dict | None = None) -> dict:
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None
        headers = {'Content-Type': 'application/json; charset=UTF-8'} if data is not None else None
        code, body, _ = self.request(url, method, data, headers)
        if code < 200 or code >= 300:
            raise DriveError('Unexpected API HTTP ' + str(code))
        try:
            result = json.loads(body)
        except Exception as e:
            raise DriveError('Google API returned invalid JSON') from e
        return result

    def list_named(self, parent_id: str | None, name: str, folder: bool | None = None) -> list[dict]:
        safe_name = name.replace('\\', '\\\\').replace("'", "\\'")
        terms = [f"name = '{safe_name}'", 'trashed = false']
        if parent_id:
            terms.append(f"'{parent_id}' in parents")
        else:
            terms.append("'root' in parents")
        if folder is True:
            terms.append("mimeType = 'application/vnd.google-apps.folder'")
        elif folder is False:
            terms.append("mimeType != 'application/vnd.google-apps.folder'")
        items = []
        page_token = ''
        while True:
            query = {
                'q': ' and '.join(terms),
                'fields': 'nextPageToken,files(id,name,mimeType,size,md5Checksum,parents)',
                'pageSize': '100',
                'spaces': 'drive',
            }
            if page_token:
                query['pageToken'] = page_token
            result = self.json_request(GOOGLE_DRIVE + '?' + urllib.parse.urlencode(query))
            items += result.get('files', [])
            page_token = result.get('nextPageToken', '')
            if not page_token:
                break
        return items

    def ensure_folder(self, name: str, parent_id: str | None) -> str:
        matches = self.list_named(parent_id, name, folder=True)
        if len(matches) > 1:
            raise DriveError(f'Multiple visible folders named {name}; stop to avoid wrong selection')
        if matches:
            return matches[0]['id']
        # When parent_id=None, new folder is created in the OAuth account's My Drive.
        metadata: dict[str, Any] = {'name': name, 'mimeType': FOLDER_MIME}
        if parent_id:
            metadata['parents'] = [parent_id]
        result = self.json_request(GOOGLE_DRIVE + '?fields=id,name,mimeType', 'POST', metadata)
        folder_id = result.get('id')
        if not folder_id:
            raise DriveError('Drive folder creation returned no id')
        return folder_id

    def upload(self, parent_id: str, path: Path, filename: str, md5: str) -> tuple[str, str]:
        matches = self.list_named(parent_id, filename, folder=False)
        if len(matches) > 1:
            raise DriveError(f'Multiple Drive files named {filename} in same folder; refusing to overwrite')
        existing = matches[0] if matches else None
        if existing and existing.get('md5Checksum', '').lower() == md5.lower():
            return existing['id'], 'unchanged'

        mime = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        size = path.stat().st_size
        metadata: dict[str, Any] = {'name': filename, 'mimeType': mime}
        method = 'POST'
        if existing:
            url = GOOGLE_UPLOAD + '/' + urllib.parse.quote(existing['id'], safe='')
            method = 'PATCH'
        else:
            url = GOOGLE_UPLOAD
            metadata['parents'] = [parent_id]
        url += '?uploadType=resumable&fields=id,name,size,md5Checksum'
        payload = json.dumps(metadata, ensure_ascii=False).encode('utf-8')
        status, _, headers = self.request(url, method=method, body=payload, headers={
            'Content-Type': 'application/json; charset=utf-8',
            'X-Upload-Content-Type': mime,
            'X-Upload-Content-Length': str(size),
        })
        if status not in (200, 201):
            raise DriveError('Could not create resumable upload session HTTP ' + str(status))
        upload_url = headers.get('Location', '')
        if not upload_url:
            raise DriveError('Google upload session has no Location')

        def finish_verified(uploaded_bytes: bytes) -> tuple[str, str]:
            try:
                result = json.loads(uploaded_bytes)
            except (ValueError, UnicodeDecodeError) as exc:
                raise DriveError('Google upload result was not valid JSON') from exc
            file_id = result.get('id')
            if not file_id:
                raise DriveError('Google upload result did not include file ID')
            if not result.get('md5Checksum') or result.get('size') is None:
                metadata_url = (GOOGLE_DRIVE + '/' + urllib.parse.quote(file_id, safe='')
                                + '?fields=id,size,md5Checksum')
                result = self.json_request(metadata_url)
            remote_hash = str(result.get('md5Checksum', '')).lower()
            remote_size = str(result.get('size', ''))
            if remote_hash != md5.lower() or remote_size != str(size):
                raise DriveError('Integrity verification failed: Drive MD5 or size differs from local file')
            return file_id, 'updated' if existing else 'uploaded'

        offset = 0
        with path.open('rb') as reader:
            if size == 0:
                status, response, _ = self.request(upload_url, 'PUT', b'', {
                    'Content-Type': mime, 'Content-Length': '0', 'Content-Range': 'bytes */0'
                }, allow308=True)
                if status not in (200, 201):
                    raise DriveError('Empty file upload incomplete')
                return finish_verified(response)

            while offset < size:
                reader.seek(offset)
                chunk = reader.read(min(CHUNK_SIZE, size - offset))
                if not chunk:
                    raise DriveError('Unexpected EOF while uploading ' + filename)
                end = offset + len(chunk) - 1
                try:
                    status, response, response_headers = self.request(upload_url, 'PUT', chunk, {
                        'Content-Type': mime,
                        'Content-Length': str(len(chunk)),
                        'Content-Range': f'bytes {offset}-{end}/{size}',
                    }, allow308=True)
                except DriveError:
                    # A request may have reached Google even when connection died.
                    # Query accepted range and resume without duplicating bytes.
                    status, response, response_headers = self.request(upload_url, 'PUT', b'', {
                        'Content-Length': '0',
                        'Content-Range': f'bytes */{size}',
                    }, allow308=True)
                    if status in (200, 201):
                        return finish_verified(response)
                    if status != 308:
                        raise DriveError('Cannot determine resumable upload status')
                    accepted = response_headers.get('Range', '')
                    if accepted.startswith('bytes=') and '-' in accepted:
                        offset = int(accepted.rsplit('-', 1)[-1]) + 1
                    else:
                        offset = 0
                    continue

                if status in (200, 201):
                    return finish_verified(response)
                if status != 308:
                    raise DriveError('Unexpected resumable upload HTTP ' + str(status))
                accepted = response_headers.get('Range', '')
                if accepted.startswith('bytes=') and '-' in accepted:
                    accepted_end = int(accepted.rsplit('-', 1)[-1])
                    offset = accepted_end + 1
                else:
                    offset = 0
        raise DriveError('Upload ended without completion response')


