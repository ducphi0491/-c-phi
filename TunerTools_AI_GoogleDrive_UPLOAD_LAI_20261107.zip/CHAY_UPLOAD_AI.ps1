param(
    [string]$SourceDir = "C:\TunerTools\Audio\AI_Music",
    [string]$OutputDir = "C:\TunerTools\BackupPrep\Drive_AI_Music",
    [string]$TokenFile = "",
    [switch]$InventoryOnly
)
$ErrorActionPreference = "Stop"
Write-Host "===== TUNERTOOLS AI MUSIC -> GOOGLE DRIVE =====" -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) {
    throw "Chua tim thay SourceDir: $SourceDir. Hay chi dinh dung thu muc cache cua Python bang -SourceDir."
}
if ([string]::IsNullOrWhiteSpace($TokenFile)) {
    $candidates = @(
        'C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json',
        'C:\TunerTools\BackupScripts\Drive_Buoc2C\drive_token.json',
        'C:\TunerTools\BackupScripts\Drive_Documents\drive_token.json'
    )
    $TokenFile = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
}
if (-not $InventoryOnly -and [string]::IsNullOrWhiteSpace($TokenFile)) {
    throw 'Khong tim thay drive_token.json OAuth cu. Truyen -TokenFile voi duong dan PRIVATE. KHONG dua file token len web.'
}
if (-not $InventoryOnly -and -not (Test-Path -LiteralPath $TokenFile -PathType Leaf)) {
    throw "TokenFile khong ton tai: $TokenFile"
}
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
$pythonArgs = @('--source', $SourceDir, '--output', $OutputDir)
if ($InventoryOnly) {
    Write-Host 'Mode: INVENTORY ONLY - khong upload.' -ForegroundColor Yellow
} else {
    Write-Host 'Mode: UPLOAD THAT (chi file moi/da thay doi).' -ForegroundColor Green
    $pythonArgs += @('--token', $TokenFile, '--upload')
}
Write-Host "Source: $SourceDir"
Write-Host "Report: $OutputDir"
Write-Host 'Target: My Drive/TunerTools_AppBackup/AI_Music/{stream_cache,lyrics}'
$script = Join-Path $PSScriptRoot 'UPLOAD_AI_MUSIC.py'
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 $script @pythonArgs
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python $script @pythonArgs
} else {
    throw 'Python 3.10+ chua co san trong PATH.'
}
if ($LASTEXITCODE -ne 0) { throw "Upload AI ket thuc voi exit code: $LASTEXITCODE" }
Write-Host "Hoan thanh. Xem: $OutputDir\KET_QUA_UPLOAD_AI.txt" -ForegroundColor Green
