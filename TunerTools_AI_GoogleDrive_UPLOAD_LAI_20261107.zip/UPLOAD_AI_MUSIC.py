#!/usr/bin/env python3
"""Upload eligible AI cached audio/lyrics to Google Drive (incremental).
Python 3.10+ standard library. Reads existing OAuth token; NEVER copies/modifies it.
No upload without --upload. Files are processed one by one with MD5 verification.

Flat folders on Drive are deliberate: a filename returned by the existing
/api/stream_cache/{filename} must be resolvable without server-side mapping.
Duplicate basenames are refused to prevent wrong-song playback.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import re
import sys
from tt_drive_client import DriveClient, dump_json, file_hash, now

AUDIO_EXT = {'.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg', '.opus', '.webm'}
LYRIC_FOLDERS = {'lyrics', 'karaoke', 'captions', 'subtitles', 'timing', 'timestamps'}
NAME_REGEX = re.compile(r'^[^\W_][\w .()+\-]{0,180}\.(?:wav|mp3|m4a|aac|flac|ogg|opus|webm|json)$', re.I)


def inventory(source: Path):
    items = []
    skipped = []
    destinations = {}
    for root, folders, files in os.walk(source, topdown=True, followlinks=False):
        base = Path(root)
        folders[:] = sorted(f for f in folders if not f.startswith('.') and not (base / f).is_symlink())
        for filename in sorted(files):
            path = base / filename
            if path.is_symlink() or not path.is_file() or filename.startswith('.'):
                continue
            rel = path.relative_to(source)
            ext = path.suffix.lower()
            if ext in AUDIO_EXT:
                bucket = 'stream_cache'
            elif ext == '.json' and (any(p.lower() in LYRIC_FOLDERS for p in rel.parts[:-1])
                                          or re.fullmatch(r'[\w-]{11}\.json', filename)):
                bucket = 'lyrics'
            else:
                skipped.append(rel.as_posix())
                continue
            if not NAME_REGEX.fullmatch(filename) or len(filename.encode('utf-8')) > 220:
                skipped.append(rel.as_posix() + ' (unsupported filename for API)')
                continue
            target = (bucket, filename.casefold())
            if target in destinations:
                raise ValueError(f'Duplicate target name: {destinations[target]} and {rel}. '
                                 'Rename or separate source files before uploading.')
            destinations[target] = rel.as_posix()
            size = path.stat().st_size
            items.append({'relative_path': rel.as_posix(), 'bucket': bucket,
                          'drive_name': filename, 'size_bytes': size,
                          'mtime': int(path.stat().st_mtime), 'status': 'inventory_only',
                          'drive_file_id': None})
    items.sort(key=lambda x: (x['bucket'], x['drive_name'].casefold()))
    return items, skipped


def main():
    p = argparse.ArgumentParser(description='TunerTools AI Music --> Google Drive')
    p.add_argument('--source', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--token', default='')
    p.add_argument('--upload', action='store_true')
    args = p.parse_args()
    source = Path(args.source).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    if not source.is_dir():
        raise ValueError('Source folder does not exist: ' + str(source))
    if output == source or source in output.parents:
        raise ValueError('Output must be outside SourceDir')
    output.mkdir(parents=True, exist_ok=True)
    print('Inventory (quick scan):', source, flush=True)
    files, skipped = inventory(source)
    report = output / 'ai_drive_manifest.json'
    manifest = {'schema_version': 1, 'created_utc': now(),
                'status': 'uploading' if args.upload else 'inventory_only',
                'source_dir': str(source), 'destination': 'My Drive/TunerTools_AppBackup/AI_Music',
                'total_files': len(files), 'total_bytes': sum(x['size_bytes'] for x in files),
                'audio_files': sum(x['bucket'] == 'stream_cache' for x in files),
                'lyrics_json_files': sum(x['bucket'] == 'lyrics' for x in files),
                'skipped_count': len(skipped), 'skipped_files': skipped[:100], 'files': files}
    dump_json(report, manifest)
    print(f"Found {len(files)} files (audio={manifest['audio_files']}, lyrics_json={manifest['lyrics_json_files']}), "
          f"size={manifest['total_bytes']/1048576:.1f} MB, skipped={len(skipped)}", flush=True)
    if not files:
        raise ValueError('No supported AI audio or timed-lyrics JSON in source. Check actual Python cache location.')
    if not args.upload:
        print('INVENTORY ONLY -- no Google Drive operation; report:', report, flush=True)
        for item in files[:12]:
            print('  ', item['bucket'] + '/', item['drive_name'], flush=True)
        return
    token = Path(args.token).expanduser().resolve() if args.token else None
    if token is None or not token.is_file():
        raise ValueError('OAuth token not found. Use private -TokenFile path; NEVER upload token to Alwaysdata web root.')
    print('Connecting Google Drive via existing OAuth...', flush=True)
    drive = DriveClient(token)
    main_id = drive.ensure_folder('TunerTools_AppBackup', None)
    ai_id = drive.ensure_folder('AI_Music', main_id)
    dirs = {name: drive.ensure_folder(name, ai_id) for name in ('stream_cache', 'lyrics')}
    manifest['root_drive_id'] = ai_id
    dump_json(report, manifest)
    failures = 0
    for i, info in enumerate(files, 1):
        path = source / info['relative_path']
        print(f"[{i}/{len(files)}] {info['bucket']}/{info['drive_name']} - "
              f"{info['size_bytes']/1048576:.1f} MB", flush=True)
        try:
            stat = path.stat()
            if stat.st_size != info['size_bytes'] or int(stat.st_mtime) != info['mtime']:
                raise ValueError('Local file changed during this sync; retry after processing is complete')
            info['md5'] = file_hash(path, 'md5')
            stat = path.stat()
            if stat.st_size != info['size_bytes'] or int(stat.st_mtime) != info['mtime']:
                raise ValueError('File changed during hashing; retry')
            fid, status = drive.upload(dirs[info['bucket']], path, info['drive_name'], info['md5'])
            info.update(status=status, drive_file_id=fid)
            print(f'[{i}/{len(files)}] {status}', flush=True)
        except Exception as ex:
            info.update(status='error', error=str(ex))
            failures += 1
            print(f'[{i}/{len(files)}] ERROR: {ex}', file=sys.stderr, flush=True)
        finally:
            dump_json(report, manifest)
    manifest['status'] = 'complete' if failures == 0 else 'partial_failure'
    manifest['failed_files'] = failures
    manifest['completed_utc'] = now()
    dump_json(report, manifest)
    summary = [f"Status: {manifest['status']}",
               f"Source: {source}", f"Destination: {manifest['destination']}",
               f"Audio: {manifest['audio_files']}",
               f"Lyrics JSON: {manifest['lyrics_json_files']}",
               f"Files: {sum(x['status'] in ('uploaded','updated','unchanged') for x in files)} / {len(files)}",
               f'Failed: {failures}', f'Manifest: {report}']
    (output / 'KET_QUA_UPLOAD_AI.txt').write_text('\n'.join(summary) + '\n', encoding='utf-8')
    print('\n'.join(summary), flush=True)
    if failures:
        sys.exit(2)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('ERROR:', exc, file=sys.stderr, flush=True)
        sys.exit(1)
