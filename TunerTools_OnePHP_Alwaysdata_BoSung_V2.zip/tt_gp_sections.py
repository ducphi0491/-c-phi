#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TunerTools: audit and publish small Vietnamese/rhythm GP collections.

Does NOT change the large SQLite, move/delete any file, or share public Drive links.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

EXTS = {'.gp', '.gp3', '.gp4', '.gp5', '.gpx', '.gp6', '.gp7', '.gp8'}
FOLDER_MIME = 'application/vnd.google-apps.folder'
SHORTCUT_MIME = 'application/vnd.google-apps.shortcut'
CANDIDATES = {
    'nhac_viet': ('vietnam', 'trinhcongson'),
    'dieu_nhac': ('dieu_dem_nhac', 'dieu_nhac'),
}


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def relative_key(section, path):
    return hashlib.sha256((section + '|' + path.casefold()).encode('utf-8')).hexdigest()[:32]


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, path)


def read_json(path, default):
    if path.is_file():
        return json.loads(path.read_text(encoding='utf-8'))
    return default


def make_catalog(source, db):
    if not source.is_dir():
        raise SystemExit(f'SOURCE NOT FOUND: {source}')
    if not db.is_file():
        raise SystemExit(f'DATABASE NOT FOUND: {db}')
    con = sqlite3.connect(f'file:{db.as_posix()}?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    roots = {p.name.casefold(): p for p in source.iterdir() if p.is_dir() and not p.is_symlink()}
    entries = []
    try:
        for section, candidates in CANDIDATES.items():
            for root_name in candidates:
                folder = roots.get(root_name.casefold())
                if folder is None:
                    continue
                for cur, dirs, files in os.walk(folder, followlinks=False):
                    dirs[:] = [d for d in dirs if not (Path(cur) / d).is_symlink()]
                    for name in files:
                        path = Path(cur) / name
                        if path.suffix.lower() not in EXTS or path.is_symlink():
                            continue
                        rel = path.relative_to(source).as_posix()
                        local_rel = path.relative_to(folder).as_posix()
                        if section == 'nhac_viet':
                            if root_name.casefold() == 'trinhcongson':
                                logical = 'Trinh Cong Son/' + local_rel
                            else:
                                logical = local_rel
                        else:
                            logical = local_rel
                        key = relative_key(section, rel)
                        # These files may have been uploaded by the 1.64M GP batch already.
                        names = ('tab/' + rel, rel, 'tab/' + rel.replace('\\', '/'))
                        row = None
                        for n in dict.fromkeys(names):
                            row = con.execute('SELECT id,title,artist,format,drive_file_id FROM songs WHERE file_path=?', (n,)).fetchone()
                            if row is not None:
                                break
                        fid = str(row['drive_file_id'] or '').strip() if row else ''
                        entries.append({
                            'key': key,
                            'section': section,
                            'local_relative_path': rel,
                            'logical_path': logical,
                            'file_name': name,
                            'title': str(row['title'] or path.stem) if row else path.stem,
                            'artist': str(row['artist'] or '') if row else '',
                            'format': path.suffix.lower().lstrip('.'),
                            'file_size': path.stat().st_size,
                            'song_id': str(row['id']) if row else '',
                            'drive_file_id': fid,
                            'origin': 'bulk' if fid else 'missing',
                        })
        # Resolve NTFS case aliases in one sequential DB pass, not one 1.6M-row
        # scan per missing file. Avoid slow audits when several new files exist.
        unresolved = {}
        for e in entries:
            if e['origin'] == 'missing':
                rel = e['local_relative_path']
                for candidate in ('tab/' + rel, rel):
                    unresolved.setdefault(candidate.casefold(), []).append(e)
        if unresolved:
            for r in con.execute('SELECT id,file_path,title,artist,format,drive_file_id FROM songs'):
                matches = unresolved.get((r['file_path'] or '').casefold())
                if not matches:
                    continue
                for e in matches:
                    e['song_id'] = str(r['id'])
                    e['title'] = str(r['title'] or e['title'])
                    e['artist'] = str(r['artist'] or e['artist'])
                    e['drive_file_id'] = str(r['drive_file_id'] or '')
                    if e['drive_file_id']:
                        e['origin'] = 'bulk'
    finally:
        con.close()
    return sorted(entries, key=lambda e: (e['section'], e['logical_path'].casefold()))


def status(entries):
    for section in CANDIDATES:
        group = [e for e in entries if e['section'] == section]
        ready = sum(bool(e['drive_file_id']) for e in group)
        print(f'{section}: total {len(group):,} | already on Drive {ready:,} | not yet indexed {len(group)-ready:,}')
        for e in group:
            if not e['drive_file_id']:
                print('  MISSING:', e['local_relative_path'])
    print(f'TOTAL: {len(entries):,}; ready: {sum(bool(e["drive_file_id"]) for e in entries):,}')
    if not entries:
        print('WARNING: No GP files found in the configured category folders.')


def get_drive(token_path):
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    if not token_path.is_file():
        raise SystemExit(f'TOKEN NOT FOUND: {token_path}')
    creds = Credentials.from_authorized_user_file(str(token_path))
    if not creds.valid:
        if not creds.refresh_token:
            raise SystemExit('Token cannot refresh. Run tt_gp_bulk.py auth first.')
        creds.refresh(Request())
        save_json(token_path, json.loads(creds.to_json()))
    return build('drive', 'v3', credentials=creds, cache_discovery=False)


def drive_retry(fn, attempts=6):
    from googleapiclient.errors import HttpError
    for i in range(attempts):
        try:
            return fn()
        except HttpError as exc:
            code = getattr(exc.resp, 'status', 0)
            if code not in (403, 429, 500, 502, 503, 504) or i == attempts - 1:
                raise
            time.sleep(min(20, (2 ** i) + 0.5))


def drive_search_children(service, folder_id, name):
    escaped = name.replace('\\', '\\\\').replace("'", "\\'")
    q = f"'{folder_id}' in parents and name = '{escaped}' and trashed = false"
    result = drive_retry(lambda: service.files().list(
        q=q, fields='nextPageToken,files(id,name,mimeType,shortcutDetails,appProperties)',
        pageSize=1000).execute())
    return result.get('files', [])


def get_or_make_folder(service, parent, name):
    for f in drive_search_children(service, parent, name):
        if f.get('mimeType') == FOLDER_MIME:
            return f['id']
    return drive_retry(lambda: service.files().create(
        body={'name': name, 'mimeType': FOLDER_MIME, 'parents': [parent]},
        fields='id').execute())['id']


def publish(entries, source, db, token, manifest, state_path, yes):
    if not yes:
        raise SystemExit('To publish on Drive, add --yes. This command creates shortcuts/uploads.')
    state = read_json(state_path, {'version': 1, 'files': {}, 'folders': {}})
    if not isinstance(state, dict) or not isinstance(state.get('files'), dict):
        raise SystemExit('Invalid state JSON; do not overwrite it.')
    con = sqlite3.connect(f'file:{db.as_posix()}?mode=ro', uri=True)
    try:
        row = con.execute("SELECT value FROM bulk_meta WHERE key='drive_root_id'").fetchone()
    finally:
        con.close()
    if row is None or not row[0]:
        raise SystemExit('No bulk Drive root ID in SQLite. Check gp_fresh_1600000.db.')
    bulk_root = row[0]
    service = get_drive(token)
    folders = state.setdefault('folders', {})
    files = state.setdefault('files', {})
    category_root = folders.get('category_root')
    if not category_root:
        category_root = get_or_make_folder(service, bulk_root, 'TunerTools_GP_Sections')
        folders['category_root'] = category_root
        save_json(state_path, state)
    print('Drive sections root:', category_root)
    created_shortcuts = new_uploads = reused = 0
    from googleapiclient.http import MediaFileUpload
    for i, e in enumerate(entries, 1):
        key = e['key']
        saved_id = files.get(key, '')
        section_folder = 'Nhac_Viet' if e['section'] == 'nhac_viet' else 'Dieu_Nhac'
        logical = Path(e['logical_path'])
        folder_segments = (section_folder,) + tuple(logical.parts[:-1])
        parent = category_root
        chain = ''
        for segment in folder_segments:
            chain += '/' + segment
            if chain not in folders:
                folders[chain] = get_or_make_folder(service, parent, segment)
                save_json(state_path, state)
            parent = folders[chain]
        if saved_id:
            e['drive_file_id'] = saved_id
            e['origin'] = 'section_state'
            reused += 1
            continue
        target_id = e['drive_file_id']
        matching = drive_search_children(service, parent, e['file_name'])
        if target_id:
            shortcut = next((x for x in matching if x.get('mimeType') == SHORTCUT_MIME and
                             x.get('shortcutDetails', {}).get('targetId') == target_id), None)
            if shortcut is None:
                drive_retry(lambda: service.files().create(
                    body={'name': e['file_name'], 'mimeType': SHORTCUT_MIME,
                          'parents': [parent], 'shortcutDetails': {'targetId': target_id}},
                    fields='id').execute())
                created_shortcuts += 1
            files[key] = target_id
            e['origin'] = 'bulk_shortcut'
            reused += 1
        else:
            existing = next((x for x in matching if x.get('mimeType') not in (FOLDER_MIME, SHORTCUT_MIME)
                             and x.get('appProperties', {}).get('ttgp_section_key') == key), None)
            if existing:
                new_id = existing['id']
            else:
                local_path = source / Path(*Path(e['local_relative_path']).parts)
                if not local_path.is_file():
                    raise SystemExit(f'File missing during upload: {local_path}')
                media = MediaFileUpload(str(local_path), mimetype='application/octet-stream', resumable=True)
                new_id = drive_retry(lambda: service.files().create(
                    body={'name': e['file_name'], 'parents': [parent],
                          'appProperties': {'ttgp_section_key': key}},
                    media_body=media, fields='id').execute())['id']
                new_uploads += 1
            files[key] = new_id
            e['drive_file_id'] = new_id
            e['origin'] = 'new_upload'
        save_json(state_path, state)
        if i % 20 == 0 or i == len(entries):
            print(f'Processed {i:,}/{len(entries):,} | shortcuts {created_shortcuts:,} | '
                  f'new uploads {new_uploads:,} | reused {reused:,}', flush=True)
    write_manifest(manifest, entries)
    print('DONE. JSON manifest:', manifest)
    print(f'New physical uploads: {new_uploads}; Drive shortcuts: {created_shortcuts}')


def write_manifest(path, entries):
    unresolved = [e['local_relative_path'] for e in entries if not e['drive_file_id']]
    if unresolved:
        raise SystemExit(f'Cannot create complete manifest. Missing Drive IDs: {len(unresolved)}. Use publish --yes.')
    # Store no OAuth credentials. This JSON should still stay outside public webroot.
    data = {'api_version': 1, 'generated_utc': utc_now(), 'total': len(entries),
            'entries': [{k: e[k] for k in ('key', 'section', 'local_relative_path',
              'logical_path', 'title', 'artist', 'format', 'song_id', 'drive_file_id')}
             for e in entries]}
    save_json(path, data)
    print('Manifest created:', path, '| entries:', len(entries))


def main():
    parser = argparse.ArgumentParser(description='TunerTools mini-category Drive index / uploader')
    parser.add_argument('command', choices=['audit', 'publish', 'manifest'])
    parser.add_argument('--source', default=r'C:\inetpub\wwwroot\tab')
    parser.add_argument('--db', default=r'C:\TunerToolsGP_Fresh\gp_fresh_1600000.db')
    parser.add_argument('--token', default=r'C:\TunerToolsGP_Fresh\drive_token.json')
    parser.add_argument('--manifest', default=r'C:\TunerToolsGP_Fresh\gp_sections.json')
    parser.add_argument('--state', default=r'C:\TunerToolsGP_Fresh\gp_sections_state.json')
    parser.add_argument('--yes', action='store_true')
    args = parser.parse_args()
    source, db = Path(args.source), Path(args.db)
    entries = make_catalog(source, db)
    status(entries)
    if args.command == 'audit':
        return
    if args.command == 'publish':
        publish(entries, source, db, Path(args.token), Path(args.manifest), Path(args.state), args.yes)
        return
    state = read_json(Path(args.state), {'files': {}})
    for e in entries:
        saved_id = (state.get('files') or {}).get(e['key'], '')
        if saved_id:
            e['drive_file_id'] = saved_id
    write_manifest(Path(args.manifest), entries)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Interrupted. Progress stored; no source files were changed.')
        sys.exit(130)
