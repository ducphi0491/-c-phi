# Third-party notices

AudioSheet Studio is an independent implementation and does not include or copy code from ledutu.com.

Major installed or loaded components include:

- Spotify Basic Pitch 0.4.0 - Apache License 2.0
- TensorFlow 2.15.x - Apache License 2.0
- Demucs 4.1.0 - MIT License
- PyTorch / TorchAudio - BSD-style license
- music21 10.5.2 - BSD 3-Clause License
- ReportLab - BSD License
- OpenSheetMusicDisplay 2.1.3 - BSD 3-Clause License
- Chrome, Edge, Chromium or Brave - used locally only for browser PDF printing; distributed separately
- FastAPI - MIT License
- yt-dlp - The Unlicense; optional components may use other licenses
- FFmpeg - license depends on the selected build and enabled codecs

## Salamander Grand Piano V3 samples

Alexander Holm - Creative Commons Attribution 3.0 Unported.
Source: https://github.com/sfzinstruments/SalamanderGrandPiano
MP3 distribution used by the downloader: https://tonejs.github.io/audio/salamander/
See `LICENSE_PIANO_SAMPLES.txt`.


## Beat This!
- Project: CPJKU/beat_this
- Purpose: beat and downbeat tracking
- License: MIT
- Default checkpoint: small0


## Optional v1.4 research engines (not bundled)
- SheetSage2 checkpoint `m-a-p/SheetSage2`: CC BY-NC 4.0, non-commercial only. Code loaded via `trust_remote_code=True` after the user enables it; model is not redistributed in this ZIP.
- Pop2Piano checkpoint `sweetcocoa/pop2piano`: evaluate repository/checkpoint license before any commercial deployment.
- Essentia Python library used by Pop2Piano: AGPL-3.0-only; Linux/WSL Python wheel, not included.
- Hugging Face Transformers, PyTorch: installed optionally by the user in separate venvs.

## Windows native research adapter v1.4.1
- SheetSage2 dependencies use the upstream version-pinned Python libraries in a separate Windows CPU environment; no model weights or external project code are bundled in AudioSheet's ZIP.
- `AutoModel.from_pretrained(..., trust_remote_code=True)` executes third-party repository code after explicit opt-in. Confirm terms for both SheetSage2 and its parent MERT-v2-FullSong before use.
- The separate PyTorch CPU 2.8.0 wheel is downloaded directly from the official CPU index at installation.
