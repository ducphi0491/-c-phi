# AudioSheet Studio v1.4.1 - SheetSage2 Native Windows (stage 1)

AudioSheet Studio converts permitted audio into piano sheet/MIDI/MusicXML/PDF on a local FastAPI website. Version 1.4.1 updates **only the optional SheetSage2 integration for Windows Server 2019** and keeps the entire existing A/B/C pipeline.

## Windows Server 2019, Xeon, 32GB, GTX 1060

1. Stop the website with Ctrl+C, unpack the FULL ZIP **on top of** `C:\audio-sheet-studio` (do not delete the old directory).
2. Keep `.venv`, `.demucs-venv`, `data` and `web\piano_samples` untouched.
3. Double-click `CAI_AI_NANG_CAO.bat` and choose **2**, or open `CAI_SHEETSAGE2_WINDOWS.bat` directly. A 64-bit Python 3.10/3.11 and FFmpeg must already be installed. No WSL/Ubuntu required for SheetSage2.
4. The installer creates only `.sheetsage2-venv` and installs CPU PyTorch/SheetSage2 Python dependencies. Models are **not** downloaded until your first analysis.
5. Restart `CHAY_WEBSITE.bat`, refresh your browser with Ctrl+F5, choose A = SheetSage2, confirm **non-commercial research**, and submit audio you are allowed to process.
6. Look at `Engine THUC TE` in the result. A successful run should show `A = sheetsage2`; otherwise read the clearly flagged fallback and `data\jobs\<id>\advanced_ai\sheetsage2\model.log`.

Quick dependency check: `KIEM_TRA_SHEETSAGE2_WINDOWS.bat`.
The advanced installer logs to `logs\sheetsage2-install.log`.

**Important limitations:** Checkpoint weights are CC BY-NC 4.0 and the parent MERT-v2 model has its own terms. This is a research-only feature, not a licensed production/commercial endpoint. The upstream Python code is executed with `trust_remote_code=True`. Model download/loading on Windows Server 2019 and the real quality advantage over Basic Pitch/ledutu are **not verified on the user's machine**. Actual inference may require significant RAM and time. No AI checkpoint, FFmpeg binary or licensed model weights are bundled in this project ZIP.

## Unchanged pipelines

- A default: Basic Pitch vocal melody. A optional: SheetSage2 melody and chord analysis (with A MIDI and dynamic PDF).
- B default: heuristic arrangement Easy/Standard/Full. B optional: Pop2Piano requires Linux/WSL2, **not available on Windows Server 2019** through this installer.
- C: Basic Pitch stem transcription, unchanged.
- Rhythm: Beat This! with fallback; Demucs separation; Salamander piano samples; OSMD and Chrome/Edge PDF.
- Existing data and stored jobs are preserved.

See `HUONG_DAN_V1.4.1_WINDOWS.txt` for troubleshooting and notes.
