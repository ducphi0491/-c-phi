from __future__ import annotations

import json
import shutil
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


class JobNotFoundError(KeyError):
    pass


class JobStore:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def job_dir(self, job_id: str) -> Path:
        if not job_id or any(ch not in "0123456789abcdef" for ch in job_id):
            raise JobNotFoundError(job_id)
        return self.root / job_id

    def _job_file(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "job.json"

    def create(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            job_id = uuid.uuid4().hex
            directory = self.job_dir(job_id)
            directory.mkdir(parents=True, exist_ok=False)
            now = self._now()
            job = {
                "id": job_id,
                "status": "queued",
                "progress": 0,
                "message": "Waiting for the processor",
                "created_at": now,
                "updated_at": now,
                "artifacts": [],
                "error": None,
                **payload,
            }
            self._write(job)
            return job

    def _write(self, job: dict[str, Any]) -> None:
        path = self._job_file(job["id"])
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(job, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def get(self, job_id: str) -> dict[str, Any]:
        with self._lock:
            path = self._job_file(job_id)
            if not path.exists():
                raise JobNotFoundError(job_id)
            return json.loads(path.read_text(encoding="utf-8"))

    def update(self, job_id: str, **changes: Any) -> dict[str, Any]:
        with self._lock:
            job = self.get(job_id)
            job.update(changes)
            job["updated_at"] = self._now()
            self._write(job)
            return job

    def list_recent(self, limit: int = 20) -> list[dict[str, Any]]:
        jobs: list[dict[str, Any]] = []
        for path in self.root.glob("*/job.json"):
            try:
                jobs.append(json.loads(path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                continue
        jobs.sort(key=lambda item: item.get("created_at", ""), reverse=True)
        return jobs[: max(1, min(limit, 100))]

    def delete(self, job_id: str) -> None:
        with self._lock:
            directory = self.job_dir(job_id)
            if not directory.exists():
                raise JobNotFoundError(job_id)
            shutil.rmtree(directory)

    @staticmethod
    def public(job: dict[str, Any]) -> dict[str, Any]:
        allowed = {
            "id",
            "status",
            "progress",
            "message",
            "created_at",
            "updated_at",
            "source_type",
            "source_name",
            "title",
            "mode",
            "bpm_requested",
            "bpm_used",
            "time_signature",
            "quantization",
            "split_pitch",
            "separate_stems",
            "melody_engine",
            "piano_engine",
            "ai_engines",
            "ai_warnings",
            "duration_seconds",
            "pipeline",
            "detected_key",
            "pdf_ready",
            "artifacts",
            "error",
        }
        return {key: value for key, value in job.items() if key in allowed}


job_store = JobStore(settings.data_dir / "jobs")
