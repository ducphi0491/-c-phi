from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parent.parent
APP_VERSION = "1.4.1"


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"\"", "'"}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


_load_env_file(ROOT_DIR / ".env")


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _default_demucs_python() -> str:
    candidates = [
        ROOT_DIR / ".demucs-venv" / "Scripts" / "python.exe",
        ROOT_DIR / ".demucs-venv" / "bin" / "python",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return ""


@dataclass(frozen=True)
class Settings:
    root_dir: Path = ROOT_DIR
    data_dir: Path = Path(os.getenv("DATA_DIR", str(ROOT_DIR / "data"))).resolve()
    web_dir: Path = Path(os.getenv("WEB_DIR", str(ROOT_DIR / "web"))).resolve()
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "120"))
    max_audio_seconds: int = int(os.getenv("MAX_AUDIO_SECONDS", "720"))
    worker_count: int = max(1, int(os.getenv("WORKER_COUNT", "1")))
    allow_youtube: bool = _env_bool("ALLOW_YOUTUBE", True)
    keep_source_audio: bool = _env_bool("KEEP_SOURCE_AUDIO", True)

    # PDF: Chrome/Edge prints the same OSMD sheet as the web. MuseScore and
    # ReportLab remain optional fallbacks for background artifacts.
    musescore_bin: str = os.getenv("MUSESCORE_BIN", "").strip()
    # Chrome/Edge/Chromium is used to print the exact OSMD sheet shown on the web.
    browser_bin: str = os.getenv("BROWSER_BIN", "").strip()

    # Demucs is isolated in its own venv so PyTorch does not interfere with the
    # TensorFlow version required by Basic Pitch.
    demucs_python: str = os.getenv("DEMUCS_PYTHON", _default_demucs_python()).strip()
    demucs_model: str = os.getenv("DEMUCS_MODEL", "htdemucs").strip() or "htdemucs"
    demucs_device: str = os.getenv("DEMUCS_DEVICE", "cpu").strip() or "cpu"
    demucs_timeout_seconds: int = max(600, int(os.getenv("DEMUCS_TIMEOUT_SECONDS", "7200")))
    demucs_shifts: int = max(0, min(5, int(os.getenv("DEMUCS_SHIFTS", "1"))))
    auto_separate_stems: bool = _env_bool("AUTO_SEPARATE_STEMS", True)

    # Beat This! runs in the same isolated PyTorch environment as Demucs.
    # small0 is fast enough for CPU-only Windows machines and still predicts
    # both beat and downbeat positions.
    rhythm_model: str = os.getenv("RHYTHM_MODEL", "small0").strip() or "small0"
    rhythm_device: str = os.getenv("RHYTHM_DEVICE", demucs_device).strip() or "cpu"
    rhythm_timeout_seconds: int = max(300, int(os.getenv("RHYTHM_TIMEOUT_SECONDS", "3600")))

    # PDF is produced for A/B/C at job completion. It can also be regenerated
    # on demand from the selected MusicXML.
    export_pdf: bool = _env_bool("EXPORT_PDF", True)
    ai_engine_timeout_seconds: int = max(300, int(os.getenv("AI_ENGINE_TIMEOUT_SECONDS", "7200")))


settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
settings.web_dir.mkdir(parents=True, exist_ok=True)
