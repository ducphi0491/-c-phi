package com.docflowoffline

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.StringReader
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

/**
 * Conservative OOXML reader + basic editor. This is NOT LibreOffice/Collabora.
 * The original ZIP's non-edited entries are copied byte-for-byte after inflation.
 * Saving is restricted to plain DOCX paragraphs and selected XLSX cells.
 * This class has no Android dependencies so its document logic can be unit-tested on a JVM.
 */
object OfficeOoxml {
    private const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val P = "http://schemas.openxmlformats.org/presentationml/2006/main"
    private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG_R = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val CT = "http://schemas.openxmlformats.org/package/2006/content-types"
    private const val XML = "http://www.w3.org/XML/1998/namespace"
    private const val MAX_ENTRY = 24 * 1024 * 1024
    private const val MAX_TOTAL = 96 * 1024 * 1024
    private const val MAX_ENTRIES = 2500

    data class Word(val paragraphs: List<String>, val editable: Boolean, val reason: String?)
    data class Sheet(val name: String, val partPath: String, val cells: Map<String, String>)
    data class Workbook(val sheets: List<Sheet>)
    data class Slide(val number: Int, val partPath: String, val paragraphs: List<String>)
    data class SlideChange(val partPath: String, val index: Int, val text: String)
    data class CellChange(val sheetPath: String, val address: String, val value: String)

    fun readWord(data: ByteArray): Word {
        val parts = unzip(data)
        val document = parse(parts["word/document.xml"] ?: error("Không tìm thấy nội dung Word."))
        val body = document.getElementsByTagNameNS(W, "body").item(0) as? Element
            ?: error("Cấu trúc Word không hợp lệ.")
        val paragraphs = body.getElementsByTagNameNS(W, "p")
        val texts = (0 until paragraphs.length).map { index ->
            val node = paragraphs.item(index) as Element
            node.getElementsByTagNameNS(W, "t").asSequence().joinToString("") { it.textContent ?: "" }
        }
        val unsupported = listOf("tbl", "drawing", "pict", "object", "sdt", "hyperlink", "fldChar", "instrText", "ins", "del", "br", "tab", "altChunk")
        val complexPart = unsupported.firstOrNull { document.getElementsByTagNameNS(W, it).length > 0 }
        val editable = complexPart == null && paragraphs.length <= 400
        val reason = when {
            complexPart != null -> "Có thành phần $complexPart. Chỉ cho xem trước để tránh làm hỏng bố cục; cần bộ máy Collabora để chỉnh sửa đầy đủ."
            !editable -> "Tệp có quá nhiều đoạn cho bộ chỉnh sửa đơn giản."
            else -> null
        }
        return Word(texts, editable, reason)
    }

    fun writeWord(original: ByteArray, newParagraphs: List<String>): ByteArray {
        require(newParagraphs.size <= 400) { "Tối đa 400 đoạn ở chế độ chỉnh sửa cơ bản." }
        val previous = readWord(original)
        require(previous.editable) { previous.reason ?: "Tài liệu này chỉ hỗ trợ xem trước." }
        val zip = unzip(original).toMutableMap()
        val xml = parse(zip.getValue("word/document.xml"))
        val body = xml.getElementsByTagNameNS(W, "body").item(0) as Element
        val paragraphs = body.getElementsByTagNameNS(W, "p").asSequence().map { it as Element }.toList()
        for (index in paragraphs.indices) {
            if (index >= newParagraphs.size) {
                body.removeChild(paragraphs[index])
            } else {
                writeParagraph(xml, paragraphs[index], newParagraphs[index])
            }
        }
        for (index in paragraphs.size until newParagraphs.size) {
            val paragraph = xml.createElementNS(W, "w:p")
            writeParagraph(xml, paragraph, newParagraphs[index])
            val sectPr = body.getElementsByTagNameNS(W, "sectPr").item(0)
            if (sectPr != null && sectPr.parentNode == body) body.insertBefore(paragraph, sectPr)
            else body.appendChild(paragraph)
        }
        zip["word/document.xml"] = serialize(xml)
        return zipEntries(zip)
    }

    private fun writeParagraph(doc: Document, paragraph: Element, value: String) {
        val textNodes = paragraph.getElementsByTagNameNS(W, "t")
        if (textNodes.length == 0) {
            val run = doc.createElementNS(W, "w:r")
            val text = doc.createElementNS(W, "w:t")
            text.setAttributeNS(XML, "xml:space", "preserve")
            text.textContent = value
            run.appendChild(text)
            paragraph.appendChild(run)
        } else {
            for (i in 0 until textNodes.length) {
                val text = textNodes.item(i) as Element
                text.textContent = if (i == 0) value else ""
                if (i == 0) text.setAttributeNS(XML, "xml:space", "preserve")
            }
        }
    }

    fun readWorkbook(data: ByteArray): Workbook {
        val zip = unzip(data)
        val wb = parse(zip["xl/workbook.xml"] ?: error("Không phải file XLSX hợp lệ."))
        val rels = zip["xl/_rels/workbook.xml.rels"]?.let(::parse)
        val relation = mutableMapOf<String, String>()
        rels?.getElementsByTagNameNS(PKG_R, "Relationship")?.asSequence()?.forEach {
            val e = it as Element
            val target = e.getAttribute("Target")
            if (!target.startsWith("http://") && !target.startsWith("https://")) {
                relation[e.getAttribute("Id")] = normalizePartPath("xl", target)
            }
        }
        val strings = zip["xl/sharedStrings.xml"]?.let { sheetStrings(parse(it)) } ?: emptyList()
        val sheets = wb.getElementsByTagNameNS(S, "sheet").asSequence().mapIndexedNotNull { i, node ->
            val element = node as Element
            val path = relation[element.getAttributeNS(R, "id")] ?: "xl/worksheets/sheet${i + 1}.xml"
            val sheetBytes = zip[path] ?: return@mapIndexedNotNull null
            Sheet(element.getAttribute("name").ifBlank { "Sheet ${i + 1}" }, path, loadCells(parse(sheetBytes), strings))
        }.toList()
        require(sheets.isNotEmpty()) { "Không tìm thấy worksheet để hiển thị." }
        return Workbook(sheets)
    }

    private fun sheetStrings(document: Document): List<String> {
        return document.getElementsByTagNameNS(S, "si").asSequence().map { node ->
            (node as Element).getElementsByTagNameNS(S, "t").asSequence().joinToString("") { it.textContent ?: "" }
        }.toList()
    }

    private fun loadCells(document: Document, strings: List<String>): Map<String, String> {
        val cells = linkedMapOf<String, String>()
        val nodes = document.getElementsByTagNameNS(S, "c")
        for (i in 0 until nodes.length) {
            val c = nodes.item(i) as Element
            val ref = c.getAttribute("r").uppercase(Locale.ROOT)
            val row = ref.filter(Char::isDigit).toIntOrNull() ?: continue
            val col = colNumber(ref.filter(Char::isLetter))
            if (row !in 1..400 || col !in 1..40) continue
            val value = cellValue(c, strings)
            if (value.isNotEmpty()) cells[ref] = value
        }
        return cells
    }

    private fun cellValue(cell: Element, strings: List<String>): String {
        val formula = cell.getElementsByTagNameNS(S, "f").item(0)?.textContent
        if (!formula.isNullOrBlank()) return "=$formula"
        val rawValue = cell.getElementsByTagNameNS(S, "v").item(0)?.textContent.orEmpty()
        return when (cell.getAttribute("t")) {
            "s" -> rawValue.toIntOrNull()?.let(strings::getOrNull) ?: rawValue
            "inlineStr" -> cell.getElementsByTagNameNS(S, "t").asSequence().joinToString("") { it.textContent.orEmpty() }
            "b" -> if (rawValue == "1") "TRUE" else "FALSE"
            else -> rawValue
        }
    }

    fun writeWorkbook(original: ByteArray, edits: List<CellChange>): ByteArray {
        require(edits.size <= 3000) { "Tối đa 3000 ô cho mỗi lần lưu ở phiên bản thử nghiệm." }
        if (edits.isEmpty()) return original.copyOf()
        val validPaths = readWorkbook(original).sheets.map { it.partPath }.toSet()
        val zip = unzip(original).toMutableMap()
        val grouped = edits.groupBy { it.sheetPath }
        grouped.forEach { (path, changes) ->
            require(path in validPaths) { "Worksheet không thuộc tài liệu: $path" }
            val doc = parse(zip.getValue(path))
            changes.forEach { change -> updateCell(doc, change.address, change.value) }
            zip[path] = serialize(doc)
        }
        // A different calculation result might be required when opening with Excel/LibreOffice.
        zip["xl/workbook.xml"]?.let { old ->
            val doc = parse(old)
            val root = doc.documentElement
            val calcPr = doc.getElementsByTagNameNS(S, "calcPr").item(0) as? Element
                ?: doc.createElementNS(S, "calcPr").also(root::appendChild)
            calcPr.setAttribute("fullCalcOnLoad", "1")
            calcPr.setAttribute("forceFullCalc", "1")
            zip["xl/workbook.xml"] = serialize(doc)
        }
        // When formulas are edited, the old calcChain is no longer trustworthy.
        if (edits.any { it.value.trim().startsWith("=") } && zip.remove("xl/calcChain.xml") != null) {
            zip["xl/_rels/workbook.xml.rels"]?.let { old ->
                val rels = parse(old)
                removeWhere(rels.documentElement, "Relationship", PKG_R) {
                    (it as Element).getAttribute("Type").endsWith("/calcChain")
                }
                zip["xl/_rels/workbook.xml.rels"] = serialize(rels)
            }
            zip["[Content_Types].xml"]?.let { old ->
                val ct = parse(old)
                removeWhere(ct.documentElement, "Override", CT) {
                    (it as Element).getAttribute("PartName") == "/xl/calcChain.xml"
                }
                zip["[Content_Types].xml"] = serialize(ct)
            }
        }
        return zipEntries(zip)
    }

    private fun removeWhere(root: Element, name: String, namespace: String, condition: (Node) -> Boolean) {
        val nodes = root.getElementsByTagNameNS(namespace, name).asSequence().toList()
        nodes.filter(condition).forEach { it.parentNode.removeChild(it) }
    }

    private fun updateCell(document: Document, address: String, text: String) {
        val normalized = address.trim().uppercase(Locale.ROOT)
        require(normalized.matches(Regex("[A-Z]{1,2}[1-9][0-9]{0,5}"))) { "Địa chỉ ô không hợp lệ: $address" }
        val rowNo = normalized.dropWhile(Char::isLetter).toInt()
        val column = colNumber(normalized.takeWhile(Char::isLetter))
        require(rowNo in 1..100000 && column in 1..40) { "Địa chỉ ô nằm ngoài phạm vi chỉnh sửa cơ bản." }
        val root = document.documentElement
        val sheetData = root.getElementsByTagNameNS(S, "sheetData").item(0) as? Element
            ?: document.createElementNS(S, "sheetData").also(root::appendChild)
        val row = sheetData.childElements(S, "row").firstOrNull { it.getAttribute("r").toIntOrNull() == rowNo }
            ?: document.createElementNS(S, "row").also { newRow ->
                newRow.setAttribute("r", rowNo.toString())
                val next = sheetData.childElements(S, "row").firstOrNull {
                    (it.getAttribute("r").toIntOrNull() ?: Int.MAX_VALUE) > rowNo
                }
                sheetData.insertBefore(newRow, next)
            }
        val cell = row.childElements(S, "c").firstOrNull { it.getAttribute("r").equals(normalized, true) }
            ?: document.createElementNS(S, "c").also { newCell ->
                newCell.setAttribute("r", normalized)
                val next = row.childElements(S, "c").firstOrNull {
                    colNumber(it.getAttribute("r").takeWhile(Char::isLetter)) > column
                }
                row.insertBefore(newCell, next)
            }
        // Keep attributes such as style 's'; remove only old value/formula contents.
        val children = (0 until cell.childNodes.length).map { cell.childNodes.item(it) }
        children.filter { it.localName in setOf("f", "v", "is") && it.namespaceURI == S }
            .forEach(cell::removeChild)
        val cleaned = text.trim()
        when {
            cleaned.startsWith("=") && cleaned.length > 1 -> {
                cell.removeAttribute("t")
                cell.appendChild(document.createElementNS(S, "f").also { it.textContent = cleaned.substring(1) })
                cell.appendChild(document.createElementNS(S, "v").also { it.textContent = "0" })
            }
            cleaned.matches(Regex("[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[Ee][+-]?[0-9]+)?")) -> {
                cell.removeAttribute("t")
                cell.appendChild(document.createElementNS(S, "v").also { it.textContent = cleaned })
            }
            else -> {
                cell.setAttribute("t", "inlineStr")
                val inline = document.createElementNS(S, "is")
                val t = document.createElementNS(S, "t")
                t.setAttributeNS(XML, "xml:space", "preserve")
                t.textContent = text
                inline.appendChild(t)
                cell.appendChild(inline)
            }
        }
    }

    fun readPresentation(original: ByteArray): List<Slide> {
        val zip = unzip(original)
        val paths = zip.keys.filter { it.matches(Regex("ppt/slides/slide[0-9]+\\.xml")) }
            .sortedBy { it.substringAfterLast("/slide").substringBefore(".xml").toInt() }
        return paths.mapIndexed { index, path ->
            val doc = parse(zip.getValue(path))
            val paragraphs = doc.getElementsByTagNameNS(A, "p").asSequence().map { item ->
                val element = item as Element
                element.getElementsByTagNameNS(A, "t").asSequence().joinToString("") { it.textContent.orEmpty() }
            }.toList()
            Slide(index + 1, path, paragraphs)
        }
    }

    /** Edits existing slide text in-place; it cannot create shapes, alter geometry or add slides. */
    fun writePresentation(original: ByteArray, edits: List<SlideChange>): ByteArray {
        if (edits.isEmpty()) return original.copyOf()
        val parts = unzip(original).toMutableMap()
        val valid = readPresentation(original).map { it.partPath }.toSet()
        edits.groupBy { it.partPath }.forEach { (path, changes) ->
            require(path in valid) { "Slide không nằm trong tệp PPTX." }
            val xml = parse(parts.getValue(path))
            val paragraphs = xml.getElementsByTagNameNS(A, "p").asSequence().map { it as Element }.toList()
            changes.forEach { change ->
                require(change.index in paragraphs.indices) { "Không tìm thấy đoạn chữ trên slide." }
                val paragraph = paragraphs[change.index]
                val tNodes = paragraph.getElementsByTagNameNS(A, "t")
                require(tNodes.length > 0) { "Chỉ chỉnh sửa đoạn đã có văn bản." }
                for (i in 0 until tNodes.length) {
                    tNodes.item(i).textContent = if (i == 0) change.text else ""
                }
            }
            parts[path] = serialize(xml)
        }
        return zipEntries(parts)
    }

    /** A strict document size guard prevents huge or malicious ZIP inflation. */
    private fun unzip(source: ByteArray): LinkedHashMap<String, ByteArray> {
        require(source.size <= MAX_TOTAL) { "Tệp vượt quá 96 MB." }
        val parts = linkedMapOf<String, ByteArray>()
        var totalSize = 0L
        ZipInputStream(ByteArrayInputStream(source)).use { stream ->
            while (true) {
                val entry = stream.nextEntry ?: break
                if (!entry.isDirectory) {
                    require(totalEntries(parts) <= MAX_ENTRIES) { "Tệp chứa quá nhiều thành phần." }
                    val bytes = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    while (true) {
                        val read = stream.read(buffer)
                        if (read < 0) break
                        bytes.write(buffer, 0, read)
                        totalSize += read
                        require(bytes.size() <= MAX_ENTRY && totalSize <= MAX_TOTAL) {
                            "Tệp Office quá lớn hoặc có dấu hiệu ZIP bomb."
                        }
                    }
                    val name = entry.name
                    require(!name.startsWith('/') && !name.contains("..")) { "Đường dẫn không an toàn trong tệp Office." }
                    parts[name] = bytes.toByteArray()
                }
                stream.closeEntry()
            }
        }
        return LinkedHashMap(parts)
    }

    private fun totalEntries(entries: Map<String, ByteArray>): Int = entries.size + 1

    private fun zipEntries(entries: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            entries.forEach { (name, bytes) ->
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun parse(bytes: ByteArray): Document {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = true
        runCatching { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { f.setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        f.isExpandEntityReferences = false
        val builder = f.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> org.xml.sax.InputSource(StringReader("")) }
        return builder.parse(ByteArrayInputStream(bytes))
    }

    private fun serialize(document: Document): ByteArray {
        val factory = TransformerFactory.newInstance()
        try { factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) } catch (_: Exception) { }
        val transformer = factory.newTransformer()
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
        transformer.setOutputProperty(OutputKeys.INDENT, "no")
        val out = ByteArrayOutputStream()
        transformer.transform(DOMSource(document), StreamResult(out))
        return out.toByteArray()
    }

    private fun normalizePartPath(base: String, target: String): String {
        val sections = mutableListOf<String>()
        val raw = if (target.startsWith('/')) target.removePrefix("/") else "$base/$target"
        raw.replace('\\', '/').split('/').forEach {
            when (it) {
                "", "." -> Unit
                ".." -> if (sections.isNotEmpty()) sections.removeAt(sections.lastIndex) else error("Đường dẫn ngoài gói OOXML")
                else -> sections += it
            }
        }
        return sections.joinToString("/")
    }

    private fun org.w3c.dom.NodeList.asSequence(): Sequence<Node> = sequence {
        for (i in 0 until length) yield(item(i))
    }
    private fun Element.childElements(ns: String, local: String): List<Element> =
        (0 until childNodes.length).mapNotNull { childNodes.item(it) as? Element }
            .filter { it.namespaceURI == ns && it.localName == local }

    private fun colNumber(letters: String): Int {
        if (letters.isEmpty()) return -1
        var number = 0
        for (char in letters.uppercase(Locale.ROOT)) {
            if (char !in 'A'..'Z') return -1
            number = number * 26 + (char - 'A') + 1
        }
        return number
    }

    fun cellAddress(row: Int, column: Int): String {
        require(row >= 1 && column in 1..16384)
        var c = column
        val label = StringBuilder()
        while (c > 0) {
            c--
            label.append(('A'.code + c % 26).toChar())
            c /= 26
        }
        return label.reverse().toString() + row
    }
}
