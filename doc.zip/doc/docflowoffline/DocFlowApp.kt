package com.docflowoffline

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

/** Job is executed only after the user approves destination from Android SAF picker. */
internal data class SaveJob(
    val filename: String,
    val mime: String,
    val openAfter: Boolean = true,
    val writer: (Context, OutputStream) -> Unit
)

enum class HomeTab { HOME, TOOLS, ABOUT }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocFlowApp(incomingUri: Uri?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var document by remember { mutableStateOf<DocumentStore.OpenFile?>(null) }
    var busy by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(HomeTab.HOME) }
    var recent by remember { mutableStateOf(DocumentStore.recent(context)) }
    var pendingJob by remember { mutableStateOf<SaveJob?>(null) }

    fun notify(text: String) { scope.launch { snack.showSnackbar(text) } }

    fun openUri(uri: Uri) {
        scope.launch {
            busy = true
            try {
                val opened = withContext(Dispatchers.IO) { DocumentStore.open(context, uri) }
                document = opened
                DocumentStore.persistReadPermission(context, uri)
                DocumentStore.remember(context, uri, opened.name)
                recent = DocumentStore.recent(context)
            } catch (e: Exception) {
                notify("Không mở được tài liệu: ${e.message ?: e.javaClass.simpleName}")
            } finally { busy = false }
        }
    }

    LaunchedEffect(incomingUri) { if (incomingUri != null) openUri(incomingUri) }

    val openPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openUri(uri)
    }

    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val job = pendingJob
        pendingJob = null
        val outputUri = result.data?.data
        if (result.resultCode == android.app.Activity.RESULT_OK && outputUri != null && job != null) {
            scope.launch {
                busy = true
                try {
                    withContext(Dispatchers.IO) {
                        val stream = context.contentResolver.openOutputStream(outputUri, "wt")
                            ?: error("Không tạo được tệp đích.")
                        stream.use { job.writer(context, it) }
                    }
                    notify("Đã lưu ${job.filename}")
                    if (job.openAfter && job.mime in listOf(DocumentStore.DOCX, DocumentStore.XLSX, DocumentStore.PPTX, DocumentStore.PDF, DocumentStore.TXT, DocumentStore.CSV)) {
                        openUri(outputUri)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.IO) {
                        // Avoid leaving a zero-byte or partial output after a failed conversion.
                        runCatching { DocumentsContract.deleteDocument(context.contentResolver, outputUri) }
                    }
                    notify("Lưu thất bại: ${e.message ?: e.javaClass.simpleName}")
                } finally { busy = false }
            }
        }
    }

    fun requestSave(filename: String, mime: String, openAfter: Boolean = true, writer: (Context, OutputStream) -> Unit) {
        pendingJob = SaveJob(filename, mime, openAfter, writer)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, filename)
        }
        savePicker.launch(intent)
    }

    val mergePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.size < 2) notify("Hãy chọn ít nhất 2 tệp PDF.")
        else requestSave("PDF_da_ghep.pdf", DocumentStore.PDF) { ctx, out -> PdfTools.merge(ctx, uris, out) }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        requestSave("Hinh_anh_thanh_PDF.pdf", DocumentStore.PDF) { ctx, out -> PdfTools.imagesToPdf(ctx, uris, out) }
    }

    fun createNew(asset: String, name: String, mime: String) {
        requestSave(name, mime) { ctx, out -> ctx.assets.open(asset).use { it.copyTo(out) } }
    }

    BackHandler(enabled = document != null) { document = null }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(document?.name ?: "DocFlow Offline", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(if (document == null) "Tài liệu ở trên điện thoại" else "Làm việc offline • Lưu thành bản sao",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    if (document != null) IconButton(onClick = { document = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Trở lại")
                    } else {
                        Icon(Icons.Default.Description, contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 16.dp))
                    }
                },
                actions = {
                    if (document == null) Icon(Icons.Default.CloudOff, contentDescription = "100% offline",
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 16.dp))
                }
            )
        },
        bottomBar = {
            if (document == null) NavigationBar {
                listOf(
                    Triple(HomeTab.HOME, "Tài liệu", Icons.Default.Folder),
                    Triple(HomeTab.TOOLS, "Công cụ", Icons.Default.Build),
                    Triple(HomeTab.ABOUT, "Thông tin", Icons.Default.Info)
                ).forEach { (tab, name, icon) ->
                    NavigationBarItem(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        icon = { Icon(icon, contentDescription = name) }, label = { Text(name) })
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            val doc = document
            if (doc != null) {
                DocumentScreen(
                    document = doc,
                    requestSave = { file, mime, openAfter, write -> requestSave(file, mime, openAfter, write) },
                    notify = ::notify
                )
            } else when (activeTab) {
                HomeTab.HOME -> HomeContent(
                    recent = recent,
                    open = { openPicker.launch(arrayOf("*/*")) },
                    newWord = { createNew("blank.docx", "Tai_lieu_moi.docx", DocumentStore.DOCX) },
                    newExcel = { createNew("blank.xlsx", "Bang_tinh_moi.xlsx", DocumentStore.XLSX) },
                    newSlides = { createNew("blank.pptx", "Trinh_chieu_moi.pptx", DocumentStore.PPTX) },
                    newText = { requestSave("Ghi_chu_moi.txt", DocumentStore.TXT) { _, out -> out.write(ByteArray(0)) } },
                    openRecent = { openUri(Uri.parse(it.uri)) }
                )
                HomeTab.TOOLS -> ToolsContent(
                    merge = { mergePicker.launch(arrayOf(DocumentStore.PDF)) },
                    imagesPdf = { imagePicker.launch(arrayOf("image/*")) },
                    openPdf = { openPicker.launch(arrayOf(DocumentStore.PDF)) }
                )
                HomeTab.ABOUT -> AboutContent()
            }
            if (busy) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

@Composable
private fun HomeContent(
    recent: List<DocumentStore.Recent>,
    open: () -> Unit,
    newWord: () -> Unit,
    newExcel: () -> Unit,
    newSlides: () -> Unit,
    newText: () -> Unit,
    openRecent: (DocumentStore.Recent) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Surface(color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Security, contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("Không mạng. Không máy chủ.", style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Text("Mở và xử lý tệp trực tiếp trên điện thoại. Mọi thay đổi được lưu thành bản sao để bảo vệ bản gốc.",
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Button(onClick = open, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp)); Text("Mở tài liệu")
                    }
                }
            }
        }
        item { Text("Tạo tài liệu", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Word", "DOCX", Color(0xFF1766B0), Icons.Default.Description, newWord, Modifier.weight(1f))
                HomeAction("Excel", "XLSX", Color(0xFF167C4A), Icons.Default.TableChart, newExcel, Modifier.weight(1f))
                HomeAction("Slide", "PPTX", Color(0xFFD96832), Icons.Default.Slideshow, newSlides, Modifier.weight(1f))
                HomeAction("Ghi chú", "TXT", Color(0xFF97712A), Icons.Default.EditNote, newText, Modifier.weight(1f))
            }
        }
        item {
            Text("Tệp đã mở gần đây", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        if (recent.isEmpty()) item {
            Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()) {
                Text("Chưa có tài liệu. Hãy nhấn ‘Mở tài liệu’ để bắt đầu.",
                    modifier = Modifier.padding(22.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(recent, key = { it.uri }) { file ->
            Surface(onClick = { openRecent(file) }, shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(iconFor(file.name), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(14.dp))
                    Text(file.name, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Icon(Icons.Default.ChevronRight, contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun HomeAction(
    title: String, ext: String, tint: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit, modifier: Modifier = Modifier
) {
    Surface(onClick = onClick, modifier = modifier, color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(vertical = 20.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(32.dp))
            Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(ext, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun iconFor(name: String): androidx.compose.ui.graphics.vector.ImageVector = when {
    name.endsWith(".xlsx", true) || name.endsWith(".csv", true) -> Icons.Default.TableChart
    name.endsWith(".pdf", true) -> Icons.Default.PictureAsPdf
    name.endsWith(".pptx", true) -> Icons.Default.Slideshow
    else -> Icons.Default.Description
}

@Composable
private fun ToolsContent(merge: () -> Unit, imagesPdf: () -> Unit, openPdf: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Công cụ tài liệu", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Tất cả thao tác bên dưới đều thực hiện trên thiết bị, không upload file.",
            color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { ToolAction(Icons.Default.JoinFull, "Ghép nhiều PDF", "Chọn ít nhất hai file PDF và lưu thành một file.", merge) }
        item { ToolAction(Icons.Default.Image, "Ảnh → PDF", "Tạo PDF từ một hoặc nhiều ảnh JPG/PNG.", imagesPdf) }
        item { ToolAction(Icons.Default.ContentCut, "Tách trang PDF", "Mở PDF rồi nhập phạm vi trang cần trích xuất.", openPdf) }
        item { ToolAction(Icons.Default.Collections, "PDF → PNG", "Mở PDF rồi chọn xuất trang đang xem thành ảnh.", openPdf) }
        item {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp)) {
                Text("Word/Excel → PDF dạng văn bản: mở tệp, chọn ‘Xuất PDF’. Công cụ này chưa giữ nguyên bố cục Office.",
                    Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun ToolAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String,
                       subtitle: String, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
private fun AboutContent() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("DocFlow Offline 0.1.0", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Dự án Android mã nguồn để phát triển ứng dụng Office offline, không cần đăng nhập và không có quyền INTERNET.")
        HorizontalDivider()
        Text("Đã hỗ trợ", fontWeight = FontWeight.Bold)
        Text("• DOCX: xem đoạn văn, chỉnh sửa tài liệu đơn giản, lưu bản sao.\n" +
            "• XLSX: xem sheet/ô, thay giá trị, thêm ô, công thức đơn giản.\n" +
            "• PPTX: xem và thay chữ có sẵn trên slide (chưa hỗ trợ tạo thêm slide hoặc sửa bố cục).\n" +
            "• TXT/CSV: đọc và chỉnh sửa.\n" +
            "• PDF: xem trang, xuất PNG, ghép, tách trang, tạo PDF từ ảnh.\n" +
            "• Xuất nội dung văn bản sang PDF dạng đơn giản.")
        HorizontalDivider()
        Text("Chưa hỗ trợ", fontWeight = FontWeight.Bold)
        Text("Hiển thị Office chuẩn WYSIWYG, chỉnh sửa PowerPoint, PivotTable/macro, PDF chỉnh sửa chữ gốc, OCR và PDF ↔ Office giữ bố cục.")
        Text("Để đạt đầy đủ tính năng Office offline cần tự biên dịch và tích hợp Collabora/LibreOffice Native Engine; mã nguồn này chưa chứa bộ máy đó.",
            color = MaterialTheme.colorScheme.primary)
    }
}
