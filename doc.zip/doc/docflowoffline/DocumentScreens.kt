package com.docflowoffline

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream

internal typealias Save = (String, String, Boolean, (Context, OutputStream) -> Unit) -> Unit

@Composable
internal fun DocumentScreen(document: DocumentStore.OpenFile, requestSave: Save, notify: (String) -> Unit) {
    when (document) {
        is DocumentStore.OpenFile.Word -> WordEditor(document, requestSave, notify)
        is DocumentStore.OpenFile.Excel -> ExcelEditor(document, requestSave, notify)
        is DocumentStore.OpenFile.Slides -> PowerPointEditor(document, requestSave, notify)
        is DocumentStore.OpenFile.Pdf -> PdfScreen(document, requestSave, notify)
        is DocumentStore.OpenFile.Text -> TextEditor(document, requestSave, notify)
    }
}

@Composable
private fun EditorInfo(text: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(12.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WordEditor(document: DocumentStore.OpenFile.Word, save: Save, notify: (String) -> Unit) {
    val editable = document.data.editable
    val paragraphs = remember(document.uri) {
        mutableStateListOf<String>().apply { addAll(document.data.paragraphs.ifEmpty { listOf("") }) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Trình chỉnh sửa Word cơ bản", fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
        EditorInfo(document.data.reason ?: "Chỉnh sửa từng đoạn chữ. Tệp gốc được giữ nguyên. Định dạng phức tạp cần tích hợp Collabora.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val values = paragraphs.toList()
                save(DocumentStore.suggestedCopyName(document.name, "docx"), DocumentStore.DOCX, true) { _, out ->
                    out.write(OfficeOoxml.writeWord(document.bytes, values))
                }
            }, enabled = editable, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Save, null); Spacer(Modifier.width(4.dp)); Text("Lưu bản sao")
            }
            OutlinedButton(onClick = {
                val content = paragraphs.joinToString("\n")
                save(document.name.substringBeforeLast('.') + ".pdf", DocumentStore.PDF, true) { _, out ->
                    TextPdfExporter.create(content, out, document.name)
                }
            }, modifier = Modifier.weight(1f)) { Text("Xuất PDF (chữ)") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 20.dp)) {
            itemsIndexed(paragraphs) { index, value ->
                Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Đoạn ${index + 1}", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                            if (editable && paragraphs.size > 1) IconButton(onClick = { paragraphs.removeAt(index) },
                                modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Xóa đoạn")
                            }
                        }
                        if (editable) OutlinedTextField(value = value, onValueChange = { paragraphs[index] = it },
                            modifier = Modifier.fillMaxWidth(), minLines = 2)
                        else Text(value.ifBlank { "(đoạn trống)" }, modifier = Modifier.padding(8.dp))
                    }
                }
            }
            if (editable) item {
                OutlinedButton(onClick = { paragraphs.add("") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Thêm đoạn mới")
                }
            }
        }
    }
}

@Composable
private fun ExcelEditor(document: DocumentStore.OpenFile.Excel, save: Save, notify: (String) -> Unit) {
    var sheetIndex by remember(document.uri) { mutableIntStateOf(0) }
    val edits = remember(document.uri) { mutableStateMapOf<String, String>() }
    val sheet = document.data.sheets.getOrNull(sheetIndex) ?: return
    var rowStart by remember(document.uri, sheetIndex) { mutableIntStateOf(1) }
    var colStart by remember(document.uri, sheetIndex) { mutableIntStateOf(1) }
    var selected by remember(document.uri, sheetIndex) { mutableStateOf("A1") }
    val selectionKey = "${sheet.partPath}::$selected"
    var input by remember(document.uri, selectionKey) {
        mutableStateOf(edits[selectionKey] ?: sheet.cells[selected].orEmpty())
    }

    fun currentValue(ref: String): String = edits["${sheet.partPath}::$ref"] ?: sheet.cells[ref].orEmpty()
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Bảng tính Excel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        EditorInfo("Chỉnh sửa giá trị/công thức từng ô. Không hỗ trợ PivotTable, VBA và hiển thị định dạng phức tạp.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                val changes = edits.map { (key, value) ->
                    val div = key.lastIndexOf("::")
                    OfficeOoxml.CellChange(key.substring(0, div), key.substring(div + 2), value)
                }
                save(DocumentStore.suggestedCopyName(document.name, "xlsx"), DocumentStore.XLSX, true) { _, out ->
                    out.write(OfficeOoxml.writeWorkbook(document.bytes, changes))
                }
            }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Save, null); Spacer(Modifier.width(5.dp)); Text("Lưu XLSX")
            }
            OutlinedButton(onClick = {
                val simpleText = buildString {
                    document.data.sheets.forEach { s ->
                        append("\n### ").append(s.name).append('\n')
                        for (r in 1..60) {
                            val line = (1..8).joinToString("  |  ") { c ->
                                val cell = OfficeOoxml.cellAddress(r, c)
                                edits["${s.partPath}::$cell"] ?: s.cells[cell].orEmpty()
                            }
                            if (line.isNotBlank()) append(line).append('\n')
                        }
                    }
                }
                save(document.name.substringBeforeLast('.') + ".pdf", DocumentStore.PDF, true) { _, out ->
                    TextPdfExporter.create(simpleText, out, document.name)
                }
            }, modifier = Modifier.weight(1f)) { Text("PDF (chữ)") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            document.data.sheets.forEachIndexed { index, item ->
                FilterChip(selected = sheetIndex == index, onClick = { sheetIndex = index }, label = { Text(item.name) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = input, onValueChange = { input = it },
                label = { Text("Ô $selected") }, singleLine = true, modifier = Modifier.weight(1f))
            Button(onClick = {
                edits[selectionKey] = input
                notify("Đã cập nhật $selected (chưa lưu vào file)")
            }) { Text("Áp dụng") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { rowStart = (rowStart - 20).coerceAtLeast(1) }) { Text("↑ 20 hàng") }
            Text("$rowStart–${rowStart + 19}", style = MaterialTheme.typography.labelMedium)
            TextButton(onClick = { rowStart = (rowStart + 20).coerceAtMost(381) }) { Text("↓ 20 hàng") }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { colStart = (colStart - 6).coerceAtLeast(1) }) {
                Icon(Icons.Default.ChevronLeft, "Dịch cột trái")
            }
            IconButton(onClick = { colStart = (colStart + 6).coerceAtMost(35) }) {
                Icon(Icons.Default.ChevronRight, "Dịch cột phải")
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(MaterialTheme.colorScheme.surface,
            RoundedCornerShape(10.dp))) {
            val columns = (colStart until (colStart + 6).coerceAtMost(41)).toList()
            Column(Modifier.horizontalScroll(rememberScrollState())) {
                Row {
                    SheetCell("#", true, false, Modifier.width(52.dp)) { }
                    columns.forEach { c ->
                        SheetCell(OfficeOoxml.cellAddress(1, c).dropLast(1), true, false,
                            Modifier.width(108.dp)) { }
                    }
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(20) { i ->
                        val r = rowStart + i
                        Row {
                            SheetCell("$r", true, false, Modifier.width(52.dp)) { }
                            columns.forEach { c ->
                                val ref = OfficeOoxml.cellAddress(r, c)
                                SheetCell(currentValue(ref), false, selected == ref,
                                    Modifier.width(108.dp)) { selected = ref }
                            }
                        }
                    }
                }
            }
        }
        Text("Đã sửa ${edits.size} ô • Chọn ô, nhập giá trị rồi nhấn Áp dụng → Lưu XLSX.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SheetCell(value: String, header: Boolean, selected: Boolean,
                      modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = when {
        selected -> MaterialTheme.colorScheme.primaryContainer
        header -> MaterialTheme.colorScheme.surfaceVariant
        else -> MaterialTheme.colorScheme.surface
    }
    Surface(onClick = onClick, color = bg, modifier = modifier.height(44.dp)
        .border(0.4.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Box(Modifier.padding(6.dp), contentAlignment = if (header) Alignment.Center else Alignment.CenterStart) {
            Text(value, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = if (header) MaterialTheme.typography.labelMedium else MaterialTheme.typography.bodySmall,
                fontWeight = if (header) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
private fun PowerPointEditor(document: DocumentStore.OpenFile.Slides, save: Save, notify: (String) -> Unit) {
    // Basic editing existing text runs, without modifying slide shapes or positions.
    val changes = remember(document.uri) { mutableStateMapOf<String, String>() }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PowerPoint — chỉnh sửa chữ", fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
        EditorInfo("Chỉ sửa đoạn chữ có sẵn trong slide. Không xem đúng bố cục hoặc sửa hiệu ứng, hình ảnh, hình khối.")
        Button(onClick = {
            val edits = changes.map { (key, value) ->
                val split = key.lastIndexOf("::")
                OfficeOoxml.SlideChange(key.substring(0, split), key.substring(split + 2).toInt(), value)
            }
            // DocumentStore.Slides keeps no entire byte[]: it is re-read from the file picker URI when saving.
            save(DocumentStore.suggestedCopyName(document.name, "pptx"), DocumentStore.PPTX, true) { ctx, out ->
                val data = DocumentStore.readUpTo(ctx, document.uri)
                out.write(OfficeOoxml.writePresentation(data, edits))
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Lưu bản sao PPTX")
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(document.slides) { _, slide ->
                Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Slide ${slide.number}", fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary)
                        slide.paragraphs.forEachIndexed { index, item ->
                            if (item.isNotBlank()) {
                                val key = "${slide.partPath}::$index"
                                OutlinedTextField(
                                    value = changes[key] ?: item,
                                    onValueChange = { changes[key] = it },
                                    modifier = Modifier.fillMaxWidth(), label = { Text("Văn bản ${index + 1}") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TextEditor(document: DocumentStore.OpenFile.Text, save: Save, notify: (String) -> Unit) {
    var text by remember(document.uri) { mutableStateOf(document.value) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (document.csv) "Chỉnh sửa CSV/TSV" else "Chỉnh sửa văn bản", fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
        EditorInfo("Chỉnh sửa UTF-8. Lưu thành bản sao; với CSV, hãy giữ đúng quy tắc dấu phẩy và dấu nháy.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val body = text
                save(DocumentStore.suggestedCopyName(document.name, if (document.csv) "csv" else "txt"),
                    if (document.csv) DocumentStore.CSV else DocumentStore.TXT, true) { _, out ->
                    out.write(body.toByteArray(Charsets.UTF_8))
                }
            }, modifier = Modifier.weight(1f)) { Text("Lưu bản sao") }
            OutlinedButton(onClick = {
                val body = text
                save(document.name.substringBeforeLast('.') + ".pdf", DocumentStore.PDF, true) { _, out ->
                    TextPdfExporter.create(body, out, document.name)
                }
            }, modifier = Modifier.weight(1f)) { Text("Xuất PDF") }
        }
        OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().weight(1f),
            label = { Text("Nội dung") })
    }
}

@Composable
private fun PdfScreen(document: DocumentStore.OpenFile.Pdf, save: Save, notify: (String) -> Unit) {
    val context = LocalContext.current
    var page by remember(document.uri) { mutableIntStateOf(0) }
    var total by remember(document.uri) { mutableIntStateOf(0) }
    var rendered by remember(document.uri) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(document.uri) { mutableStateOf(false) }
    var error by remember(document.uri) { mutableStateOf<String?>(null) }
    var selection by remember(document.uri) { mutableStateOf("1") }

    LaunchedEffect(document.uri, page) {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) { PdfTools.renderPage(context, document.uri, page) }
            rendered = result.first
            total = result.second
            error = null
        } catch (e: Exception) {
            error = e.message ?: "Không thể hiển thị PDF."
        } finally { loading = false }
    }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { page = (page - 1).coerceAtLeast(0) }, enabled = page > 0) {
                Icon(Icons.Default.ChevronLeft, "Trang trước")
            }
            Text("Trang ${page + 1} / ${total.coerceAtLeast(1)}", modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            IconButton(onClick = { page = (page + 1).coerceAtMost(total - 1) }, enabled = page < total - 1) {
                Icon(Icons.Default.ChevronRight, "Trang sau")
            }
            OutlinedButton(onClick = {
                val current = page
                save(document.name.substringBeforeLast('.') + "_page_${page + 1}.png", "image/png", false) { ctx, out ->
                    PdfTools.pagePng(ctx, document.uri, current, out)
                }
            }) { Text("PNG") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = selection, onValueChange = { selection = it }, singleLine = true,
                label = { Text("Trang: 1-3,5") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                val pages = selection
                try {
                    if (total > 0) PdfTools.parsePageRange(pages, total)
                    save(document.name.substringBeforeLast('.') + "_tach.pdf", DocumentStore.PDF, true) { ctx, out ->
                        PdfTools.extract(ctx, document.uri, pages, out)
                    }
                } catch (e: Exception) { notify(e.message ?: "Khoảng trang không hợp lệ.") }
            }, enabled = total > 0) { Text("Tách PDF") }
        }
        Box(Modifier.fillMaxWidth().weight(1f).background(MaterialTheme.colorScheme.surfaceVariant,
            RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
            when {
                loading -> CircularProgressIndicator()
                error != null -> Text("Lỗi: $error", Modifier.padding(16.dp))
                rendered != null -> Image(rendered!!.asImageBitmap(), null,
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(10.dp))
                else -> Text("Đang mở PDF...")
            }
        }
        Text("PDF được đọc tại chỗ. Chức năng sửa chữ gốc/ghi chú cần bộ máy PDF nâng cao.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
