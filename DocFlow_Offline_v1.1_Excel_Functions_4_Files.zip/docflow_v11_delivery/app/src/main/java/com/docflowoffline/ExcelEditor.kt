package com.docflowoffline

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt
import android.graphics.Paint
import android.content.Intent
import android.content.ClipData
import android.net.Uri
import android.provider.DocumentsContract
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.PageRange
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.ScrollState
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min

// ================ ExcelEditor v1.1 ================
/** DocFlow v1.1: offline spreadsheet tools built on a conservative OOXML editor. */
private val ExcelGreen = Color(0xFF167346)
private val ExcelPale = Color(0xFFE7F4ED)
private enum class ExcelTab(val label: String) {
    HOME("Trang chủ"), INSERT("Chèn"), FORMULAS("Công thức"),
    DATA("Dữ liệu"), REVIEW("Đánh giá"), VIEW("Xem")
}
private data class ExcelUndo(
    val values: Map<String, String>,
    val styles: Map<String, OfficeOoxml.StyleChange>,
    val merges: Map<String, Boolean>
)
private enum class ExcelColorTarget { FONT, FILL }
private data class ExcelRibbonItem(val title: String, val icon: ImageVector, val id: String, val active: Boolean = false)

private fun colFromAddress(address: String): Int {
    var n = 0
    for (letter in address.takeWhile { it in 'A'..'Z' }) n = n * 26 + (letter - 'A' + 1)
    return n
}
private fun formatExcelNumber(number: Double): String {
    if (!number.isFinite()) return "#NUM!"
    return if (number == number.toLong().toDouble()) number.toLong().toString()
    else "%.8f".format(Locale.US, number).trimEnd('0').trimEnd('.')
}

/**
 * Basic local preview for SUM/AVERAGE/COUNT/MIN/MAX over a single rectangular range.
 * Unsupported formulas are kept unchanged and delegated to Excel/LibreOffice on the next open.
 */
internal fun previewFormula(expression: String, lookup: (String) -> String): String? {
    val match = Regex("^=(SUM|AVERAGE|COUNT|MIN|MAX)\\(([A-Z]{1,3}[1-9]\\d{0,5}):([A-Z]{1,3}[1-9]\\d{0,5})\\)$", RegexOption.IGNORE_CASE)
        .matchEntire(expression.trim()) ?: return null
    val fn = match.groupValues[1].uppercase(Locale.ROOT)
    val start = match.groupValues[2].uppercase(Locale.ROOT)
    val end = match.groupValues[3].uppercase(Locale.ROOT)
    val r1 = start.dropWhile(Char::isLetter).toIntOrNull() ?: return null
    val r2 = end.dropWhile(Char::isLetter).toIntOrNull() ?: return null
    val c1 = colFromAddress(start)
    val c2 = colFromAddress(end)
    if (r1 > r2 || c1 > c2 || r2.toLong().minus(r1).plus(1) * (c2 - c1 + 1) > 30000) return null
    val numbers = mutableListOf<Double>()
    for (r in r1..r2) for (c in c1..c2) {
        val ref = OfficeOoxml.cellAddress(r, c)
        val value = lookup(ref).trim().toDoubleOrNull()
        if (value != null) numbers.add(value)
    }
    val result = when (fn) {
        "SUM" -> numbers.sum()
        "COUNT" -> numbers.size.toDouble()
        "AVERAGE" -> if (numbers.isEmpty()) return "#DIV/0!" else numbers.average()
        "MIN" -> numbers.minOrNull() ?: 0.0
        "MAX" -> numbers.maxOrNull() ?: 0.0
        else -> return null
    }
    return formatExcelNumber(result)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ExcelEditor(
    document: DocumentStore.OpenFile.Excel,
    save: Save,
    notify: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val density = LocalDensity.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val formulaFocusRequester = remember { FocusRequester() }
    var activeUri by remember(document.uri) { mutableStateOf(document.uri) }
    var displayName by remember(document.uri) { mutableStateOf(document.name) }
    var sheetIndex by remember(document.uri) { mutableIntStateOf(0) }
    val sheet = document.data.sheets.getOrNull(sheetIndex) ?: return
    var activeTab by remember(document.uri) { mutableStateOf(ExcelTab.HOME) }
    var ribbonVisible by remember(document.uri) { mutableStateOf(true) }
    var zoom by remember(document.uri) { mutableFloatStateOf(1f) }
    var previousZoom by remember(document.uri) { mutableFloatStateOf(1f) }
    var selected by remember(document.uri, sheet.partPath) { mutableStateOf("A1") }
    var addressInput by remember(document.uri, sheet.partPath) { mutableStateOf("A1") }
    val values = remember(document.uri) { mutableStateMapOf<String, String>() }
    val styleChanges = remember(document.uri) { mutableStateMapOf<String, OfficeOoxml.StyleChange>() }
    val mergeChanges = remember(document.uri) { mutableStateMapOf<String, Boolean>() }
    val undo = remember(document.uri) { mutableStateListOf<ExcelUndo>() }
    val redo = remember(document.uri) { mutableStateListOf<ExcelUndo>() }
    var clipboard by remember(document.uri) { mutableStateOf<String?>(null) }
    var searchVisible by remember(document.uri) { mutableStateOf(false) }
    var query by remember(document.uri) { mutableStateOf("") }
    var results by remember(document.uri, sheet.partPath) { mutableStateOf(emptyList<String>()) }
    var resultIndex by remember(document.uri, sheet.partPath) { mutableIntStateOf(0) }
    var filterVisible by remember(document.uri) { mutableStateOf(false) }
    var filterText by remember(document.uri, sheet.partPath) { mutableStateOf("") }
    var filterColumn by remember(document.uri, sheet.partPath) { mutableIntStateOf(1) }
    var sortOrder by remember(document.uri, sheet.partPath) { mutableIntStateOf(0) }
    var showGridLines by remember(document.uri) { mutableStateOf(true) }
    var showFormulaBar by remember(document.uri) { mutableStateOf(true) }
    var infoVisible by remember(document.uri) { mutableStateOf(false) }
    var fileMenuVisible by remember(document.uri) { mutableStateOf(false) }
    var fileInfoVisible by remember(document.uri) { mutableStateOf(false) }
    var findReplaceVisible by remember(document.uri) { mutableStateOf(false) }
    var findNeedle by remember(document.uri) { mutableStateOf("") }
    var replacement by remember(document.uri) { mutableStateOf("") }
    var colorTarget by remember(document.uri) { mutableStateOf<ExcelColorTarget?>(null) }
    var mergeDialogVisible by remember(document.uri) { mutableStateOf(false) }
    var mergeStart by remember(document.uri) { mutableStateOf("A1") }
    var mergeEnd by remember(document.uri) { mutableStateOf("B1") }
    var renameVisible by remember(document.uri) { mutableStateOf(false) }
    var renameInput by remember(document.uri) { mutableStateOf(document.name) }
    var conversionVisible by remember(document.uri) { mutableStateOf(false) }
    var backupVisible by remember(document.uri) { mutableStateOf(false) }
    var securityVisible by remember(document.uri) { mutableStateOf(false) }
    var encryptPasswordVisible by remember(document.uri) { mutableStateOf(false) }
    var encryptPassword by remember(document.uri) { mutableStateOf("") }
    var encryptConfirm by remember(document.uri) { mutableStateOf("") }
    var pendingEncryptedUri by remember(document.uri) { mutableStateOf<Uri?>(null) }
    var decryptPasswordVisible by remember(document.uri) { mutableStateOf(false) }
    var decryptPassword by remember(document.uri) { mutableStateOf("") }
    var servicesVisible by remember(document.uri) { mutableStateOf(false) }
    val xScroll = rememberScrollState()
    val yScroll = rememberLazyListState()
    val maxRows = maxOf(100, sheet.maxRow + 25).coerceAtMost(100_000)
    val maxCols = maxOf(12, sheet.maxCol + 5).coerceAtMost(256)
    val selectedKey = "${sheet.partPath}::$selected"
    val decryptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingEncryptedUri = uri
            decryptPassword = ""
            decryptPasswordVisible = true
        }
    }

    fun rawValueFor(target: OfficeOoxml.Sheet, ref: String): String =
        values["${target.partPath}::$ref"] ?: target.cells[ref].orEmpty()
    fun styleFor(target: OfficeOoxml.Sheet, ref: String): OfficeOoxml.CellAppearance {
        val base = target.appearances[ref] ?: OfficeOoxml.CellAppearance()
        val change = styleChanges["${target.partPath}::$ref"] ?: return base
        return base.copy(
            bold = change.bold ?: base.bold,
            italic = change.italic ?: base.italic,
            underline = change.underline ?: base.underline,
            alignment = change.alignment ?: base.alignment,
            fillRgb = when (change.fillRgb) {
                null -> base.fillRgb
                "" -> null
                else -> change.fillRgb
            },
            fontRgb = when (change.fontRgb) {
                null -> base.fontRgb
                "" -> null
                else -> change.fontRgb
            },
            percent = change.numFmtId?.let { it == 9 || it == 10 } ?: base.percent
        )
    }
    fun displayValueFor(target: OfficeOoxml.Sheet, ref: String): String {
        val raw = rawValueFor(target, ref)
        val shown = if (raw.startsWith("=")) {
            previewFormula(raw) { candidate -> rawValueFor(target, candidate) }
                ?: if (values.containsKey("${target.partPath}::$ref")) raw else target.displayCells[ref] ?: raw
        } else raw
        if (styleFor(target, ref).percent) {
            return shown.toDoubleOrNull()?.let { formatExcelNumber(it * 100.0) + "%" } ?: shown
        }
        return shown
    }
    fun rawValue(ref: String): String = rawValueFor(sheet, ref)
    fun activeStyle(ref: String): OfficeOoxml.CellAppearance = styleFor(sheet, ref)
    fun cellDisplay(ref: String): String = displayValueFor(sheet, ref)
    var formula by remember(document.uri, selectedKey) { mutableStateOf(rawValue(selected)) }
    LaunchedEffect(selectedKey, values[selectedKey]) {
        formula = rawValue(selected)
        addressInput = selected
    }

    fun checkpoint() {
        undo.add(ExcelUndo(values.toMap(), styleChanges.toMap(), mergeChanges.toMap()))
        if (undo.size > 30) undo.removeAt(0)
        redo.clear()
    }
    fun setValue(text: String) {
        if (rawValue(selected) == text) return
        checkpoint()
        if (text == sheet.cells[selected].orEmpty()) values.remove(selectedKey) else values[selectedKey] = text
        formula = text
    }
    fun setAppearance(change: (OfficeOoxml.StyleChange, OfficeOoxml.CellAppearance) -> OfficeOoxml.StyleChange) {
        val original = styleChanges[selectedKey] ?: OfficeOoxml.StyleChange(sheet.partPath, selected)
        val next = change(original, activeStyle(selected))
        if (next == original) return
        checkpoint()
        styleChanges[selectedKey] = next
    }
    fun effectiveMerges(target: OfficeOoxml.Sheet = sheet): List<OfficeOoxml.MergeRange> {
        val result = LinkedHashMap<String, OfficeOoxml.MergeRange>()
        target.merges.forEach { result[it.ref] = it }
        val prefix = "${target.partPath}::"
        mergeChanges.forEach { (key, merged) ->
            if (key.startsWith(prefix)) {
                OfficeOoxml.parseMergeRange(key.removePrefix(prefix))?.let { range ->
                    if (merged) result[range.ref] = range else result.remove(range.ref)
                }
            }
        }
        return result.values.sortedWith(compareBy<OfficeOoxml.MergeRange> { it.startRow }.thenBy { it.startCol })
    }
    fun mergeChangeList(snapshot: Map<String, Boolean>): List<OfficeOoxml.MergeChange> =
        snapshot.mapNotNull { (key, merged) ->
            val split = key.lastIndexOf("::")
            if (split <= 0) null else OfficeOoxml.parseMergeRange(key.substring(split + 2))?.let {
                OfficeOoxml.MergeChange(key.substring(0, split), it, merged)
            }
        }
    fun workbookBytes(
        valueSnapshot: Map<String, String> = values.toMap(),
        styleSnapshot: Map<String, OfficeOoxml.StyleChange> = styleChanges.toMap(),
        mergeSnapshot: Map<String, Boolean> = mergeChanges.toMap()
    ): ByteArray {
        val changes = valueSnapshot.map { (key, value) ->
            val separator = key.lastIndexOf("::")
            val path = key.substring(0, separator)
            val cell = key.substring(separator + 2)
            val source = document.data.sheets.firstOrNull { it.partPath == path }
            val preview = if (value.startsWith("=")) previewFormula(value) { ref ->
                valueSnapshot["$path::$ref"] ?: source?.cells?.get(ref).orEmpty()
            }?.toDoubleOrNull()?.toString() else null
            OfficeOoxml.CellChange(path, cell, value, preview)
        }
        return OfficeOoxml.writeWorkbook(
            document.bytes, changes, styleSnapshot.values.toList(), mergeChangeList(mergeSnapshot)
        )
    }
    fun sheetSnapshot(target: OfficeOoxml.Sheet = sheet): SpreadsheetExporter.SheetSnapshot {
        val prefix = "${target.partPath}::"
        val editedRefs = values.keys.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix) }
        val styledRefs = styleChanges.keys.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix) }
        val refs = (target.cells.keys + editedRefs + styledRefs).distinct()
        val usedRow = refs.maxOfOrNull { OfficeOoxml.addressParts(it)?.first ?: 1 } ?: 1
        val usedCol = refs.maxOfOrNull { OfficeOoxml.addressParts(it)?.second ?: 1 } ?: 1
        val rows = maxOf(1, target.maxRow, usedRow).coerceAtMost(2000)
        val columns = maxOf(1, target.maxCol, usedCol).coerceAtMost(100)
        val text = LinkedHashMap<String, String>()
        refs.forEach { ref ->
            val parts = OfficeOoxml.addressParts(ref)
            if (parts != null && parts.first <= rows && parts.second <= columns) {
                val value = displayValueFor(target, ref)
                if (value.isNotEmpty()) text[ref] = value
            }
        }
        val appearanceRefs = (target.appearances.keys + styledRefs).distinct()
        val appearances = LinkedHashMap<String, OfficeOoxml.CellAppearance>()
        appearanceRefs.forEach { ref ->
            val parts = OfficeOoxml.addressParts(ref)
            if (parts != null && parts.first <= rows && parts.second <= columns) {
                val style = styleFor(target, ref)
                if (style != OfficeOoxml.CellAppearance()) appearances[ref] = style
            }
        }
        return SpreadsheetExporter.SheetSnapshot(
            documentName = displayName, sheetName = target.name, rows = rows, columns = columns,
            values = text, appearances = appearances, merges = effectiveMerges(target)
        )
    }
    fun applyMerge(first: String, last: String) {
        val range = OfficeOoxml.normalizedMergeRange(first, last)
        if (range == null) { notify("Vùng gộp không hợp lệ. Ví dụ A1:C1."); return }
        if (range.startRow != range.endRow) {
            notify("Bản hiện tại hỗ trợ gộp ngang trong cùng một hàng để hiển thị chính xác trên điện thoại.")
            return
        }
        if (range.startCol == range.endCol) { notify("Hãy chọn ít nhất hai ô để gộp."); return }
        if (range.endCol - range.startCol + 1 > 24) { notify("Mỗi lần chỉ gộp tối đa 24 ô ngang."); return }
        val overlap = effectiveMerges().firstOrNull { it.ref != range.ref && it.overlaps(range) }
        if (overlap != null) { notify("Vùng ${range.ref} đang chồng lên ô gộp ${overlap.ref}."); return }
        val occupied = (range.startCol + 1..range.endCol).map { OfficeOoxml.cellAddress(range.startRow, it) }
            .firstOrNull { rawValue(it).isNotBlank() }
        if (occupied != null) {
            notify("Ô $occupied đang có dữ liệu. Hãy xóa nội dung các ô phụ trước khi gộp để tránh mất dữ liệu.")
            return
        }
        checkpoint()
        mergeChanges["${sheet.partPath}::${range.ref}"] = true
        selected = OfficeOoxml.cellAddress(range.startRow, range.startCol)
        notify("Đã gộp ${range.ref}. Chọn Lưu dưới dạng để ghi vào XLSX.")
    }
    fun unmergeSelected() {
        val range = effectiveMerges().firstOrNull { it.contains(selected) }
        if (range == null) { notify("Ô $selected không nằm trong vùng gộp."); return }
        checkpoint()
        mergeChanges["${sheet.partPath}::${range.ref}"] = false
        notify("Đã bỏ gộp ${range.ref}.")
    }
    fun exportSheetPdf() {
        val snapshot = sheetSnapshot()
        save("${displayName.substringBeforeLast('.')}_${sheet.name.take(24)}.pdf", DocumentStore.PDF, true) { _, output ->
            SpreadsheetExporter.writePdf(snapshot, output)
        }
    }
    fun exportSheetPng() {
        val snapshot = sheetSnapshot()
        if (snapshot.rows > 190 || snapshot.columns > 58) {
            notify("Ảnh PNG sẽ giới hạn khoảng 190 hàng và 58 cột đầu để tránh vượt bộ nhớ.")
        }
        save("${displayName.substringBeforeLast('.')}_${sheet.name.take(24)}.png", "image/png", false) { _, output ->
            SpreadsheetExporter.writePng(snapshot, output)
        }
    }
    fun exportSheetDelimited(separator: Char, extension: String, mime: String) {
        val snapshot = sheetSnapshot()
        save("${displayName.substringBeforeLast('.')}_${sheet.name.take(24)}.$extension", mime, false) { _, output ->
            output.write(SpreadsheetExporter.csv(snapshot, separator).toByteArray(Charsets.UTF_8))
        }
    }
    fun mergeWorksheets() {
        val snapshots = document.data.sheets.map { sheetSnapshot(it) }
        save("${displayName.substringBeforeLast('.')}_hop_nhat.xlsx", DocumentStore.XLSX, true) { _, output ->
            SpreadsheetExporter.writeCombinedWorkbook(snapshots, output)
        }
    }
    fun shareCurrentWorkbook(openOnly: Boolean = false) {
        val valueSnapshot = values.toMap(); val styleSnapshot = styleChanges.toMap(); val mergeSnapshot = mergeChanges.toMap()
        scope.launch {
            try {
                val shareUri = withContext(Dispatchers.IO) {
                    val bytes = workbookBytes(valueSnapshot, styleSnapshot, mergeSnapshot)
                    val folder = File(context.cacheDir, "shared").apply { mkdirs() }
                    val safe = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(90).ifBlank { "DocFlow.xlsx" }
                    val file = File(folder, if (safe.endsWith(".xlsx", true)) safe else "$safe.xlsx")
                    file.writeBytes(bytes)
                    FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                }
                val intent = Intent(if (openOnly) Intent.ACTION_VIEW else Intent.ACTION_SEND).apply {
                    type = DocumentStore.XLSX
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = ClipData.newUri(context.contentResolver, displayName, shareUri)
                    if (openOnly) setDataAndType(shareUri, DocumentStore.XLSX)
                    else putExtra(Intent.EXTRA_STREAM, shareUri)
                }
                context.startActivity(Intent.createChooser(intent, if (openOnly) "Mở bằng ứng dụng khác" else "Chia sẻ bảng tính"))
            } catch (e: Exception) {
                notify("Không thể ${if (openOnly) "mở" else "chia sẻ"}: ${e.message ?: "lỗi hệ thống"}")
            }
        }
    }
    fun printCurrentSheet() {
        val snapshot = sheetSnapshot()
        scope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    ByteArrayOutputStream().also { SpreadsheetExporter.writePdf(snapshot, it) }.toByteArray()
                }
                printPdfBytes(context, "${displayName.substringBeforeLast('.')}_${sheet.name}.pdf", bytes)
            } catch (e: Exception) {
                notify("Không thể tạo bản in: ${e.message ?: "lỗi hệ thống"}")
            }
        }
    }
    fun renameCurrentDocument() {
        val base = renameInput.trim().replace(Regex("[\\/:*?\"<>|]"), "_")
        if (base.isBlank()) { notify("Tên tệp không được để trống."); return }
        val finalName = if (base.endsWith(".xlsx", true)) base else "$base.xlsx"
        scope.launch {
            try {
                val renamed = withContext(Dispatchers.IO) {
                    DocumentsContract.renameDocument(context.contentResolver, activeUri, finalName)
                }
                if (renamed != null) activeUri = renamed
                displayName = finalName
                renameVisible = false
                DocumentStore.remember(context, activeUri, displayName)
                notify("Đã đổi tên thành $displayName")
            } catch (e: Exception) {
                notify("Không đổi tên được. Nhà cung cấp tệp có thể không cho phép: ${e.message ?: "lỗi hệ thống"}")
            }
        }
    }
    fun addToRecent() {
        DocumentStore.remember(context, activeUri, displayName)
        notify("Đã đưa tài liệu lên đầu danh sách gần đây.")
    }
    fun createLocalBackup() {
        val valueSnapshot = values.toMap(); val styleSnapshot = styleChanges.toMap(); val mergeSnapshot = mergeChanges.toMap()
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val folder = File(context.filesDir, "docflow_backups").apply { mkdirs() }
                    val stamp = java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
                    val safe = displayName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)
                    File(folder, "${safe}_${stamp}.xlsx").also {
                        it.writeBytes(workbookBytes(valueSnapshot, styleSnapshot, mergeSnapshot))
                    }
                }
                notify("Đã sao lưu cục bộ: ${file.name}")
                backupVisible = false
            } catch (e: Exception) { notify("Sao lưu thất bại: ${e.message ?: "lỗi hệ thống"}") }
        }
    }
    fun restoreLatestBackup() {
        val file = File(context.filesDir, "docflow_backups").listFiles()
            ?.filter { it.extension.equals("xlsx", true) }?.maxByOrNull { it.lastModified() }
        if (file == null) { notify("Chưa có bản sao cục bộ nào."); return }
        val bytesResult = runCatching { file.readBytes() }
        if (bytesResult.isFailure) {
            notify("Không đọc được bản sao: ${bytesResult.exceptionOrNull()?.message ?: "lỗi hệ thống"}")
            return
        }
        val bytes = bytesResult.getOrThrow()
        save("${displayName.substringBeforeLast('.')}_khoi_phuc.xlsx", DocumentStore.XLSX, true) { _, output -> output.write(bytes) }
        backupVisible = false
    }

    fun undoAction() {
        if (undo.isEmpty()) return
        redo.add(ExcelUndo(values.toMap(), styleChanges.toMap(), mergeChanges.toMap()))
        val state = undo.removeAt(undo.lastIndex)
        values.clear(); values.putAll(state.values)
        styleChanges.clear(); styleChanges.putAll(state.styles)
        mergeChanges.clear(); mergeChanges.putAll(state.merges)
        formula = rawValue(selected)
    }
    fun redoAction() {
        if (redo.isEmpty()) return
        undo.add(ExcelUndo(values.toMap(), styleChanges.toMap(), mergeChanges.toMap()))
        val state = redo.removeAt(redo.lastIndex)
        values.clear(); values.putAll(state.values)
        styleChanges.clear(); styleChanges.putAll(state.styles)
        mergeChanges.clear(); mergeChanges.putAll(state.merges)
        formula = rawValue(selected)
    }
    fun navigate(input: String) {
        val normalized = input.trim().uppercase(Locale.ROOT).replace("$", "")
        if (!normalized.matches(Regex("[A-Z]{1,3}[1-9][0-9]{0,5}"))) {
            notify("Địa chỉ ô không hợp lệ. Ví dụ: A12 hoặc AZ500.")
            return
        }
        val row = normalized.dropWhile(Char::isLetter).toIntOrNull() ?: return
        val col = colFromAddress(normalized)
        if (row !in 1..maxRows || col !in 1..maxCols) {
            notify("Ô nằm ngoài vùng xem A1:${OfficeOoxml.cellAddress(maxRows,maxCols)}")
            return
        }
        if (filterText.isNotBlank() || sortOrder != 0) { filterText = ""; sortOrder = 0 }
        selected = normalized
        scope.launch {
            yScroll.scrollToItem(row - 1)
            val cellPixels = with(density) { (GRID_COLUMN_DP.dp * zoom).roundToPx() }
            xScroll.scrollTo(((col - 1) * cellPixels).coerceAtMost(xScroll.maxValue))
        }
    }
    fun applyRibbonAction(id: String) {
        when (id) {
            "undo" -> undoAction()
            "redo" -> redoAction()
            "copy" -> { clipboard = rawValue(selected); notify("Đã sao chép nội dung $selected") }
            "cut" -> { clipboard = rawValue(selected); setValue("") }
            "paste" -> { val clip = clipboard; if (clip != null) setValue(clip) else notify("Chưa có nội dung sao chép") }
            "clear" -> setValue("")
            "bold" -> setAppearance { old, appearance -> old.copy(bold = !appearance.bold) }
            "italic" -> setAppearance { old, appearance -> old.copy(italic = !appearance.italic) }
            "underline" -> setAppearance { old, appearance -> old.copy(underline = !appearance.underline) }
            "left", "center", "right" -> setAppearance { old, _ -> old.copy(alignment = id) }
            "highlight" -> setAppearance { old, appearance -> old.copy(fillRgb = if (appearance.fillRgb == "FFF2CC") "" else "FFF2CC") }
            "percent" -> setAppearance { old, appearance -> old.copy(numFmtId = if (appearance.percent) 0 else 10) }
            "insertDate" -> setValue(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE))
            "insertTime" -> setValue(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")))
            "insertCheck" -> setValue("✓")
            "numberList" -> {
                val row = selected.dropWhile(Char::isLetter).toIntOrNull() ?: 1
                setValue(row.toString())
            }
            "sum", "average", "count", "min", "max" -> {
                val row = selected.dropWhile(Char::isLetter).toIntOrNull() ?: 1
                if (row < 2) notify("Hãy chọn ô ở hàng 2 trở xuống để tạo công thức từ các hàng phía trên.")
                else {
                    val col = selected.takeWhile(Char::isLetter)
                    setValue("=${id.uppercase(Locale.ROOT)}(${col}1:${col}${row - 1})")
                }
            }
            "find" -> { searchVisible = !searchVisible; if (!searchVisible) results = emptyList() }
            "replace" -> { findReplaceVisible = true }
            "filter" -> { filterVisible = !filterVisible; if (!filterVisible) filterText = ""; filterColumn = colFromAddress(selected) }
            "sortAsc" -> { sortOrder = if (sortOrder == 1) 0 else 1; filterColumn = colFromAddress(selected) }
            "sortDesc" -> { sortOrder = if (sortOrder == -1) 0 else -1; filterColumn = colFromAddress(selected) }
            "resetDataView" -> { sortOrder = 0; filterText = ""; filterVisible = false }
            "formulaBar" -> showFormulaBar = !showFormulaBar
            "gridlines" -> showGridLines = !showGridLines
            "ribbon" -> ribbonVisible = !ribbonVisible
            "zoomIn" -> zoom = (zoom + .15f).coerceAtMost(2.5f)
            "zoomOut" -> zoom = (zoom - .15f).coerceAtLeast(.65f)
            "zoom100" -> zoom = 1f
            "info" -> infoVisible = !infoVisible
        }
    }
    /** One undo checkpoint for multi-cell replace; formulas are excluded to protect references. */
    fun findTextCells(): List<String> {
        if (findNeedle.isBlank()) return emptyList()
        val all = (sheet.cells.keys + values.keys.filter { it.startsWith(sheet.partPath + "::") }
            .map { it.substringAfter("::") }).distinct()
        return all.filter { ref ->
            val body = rawValue(ref)
            !body.startsWith("=") && body.contains(findNeedle, ignoreCase = true)
        }.sortedWith(compareBy<String> { it.dropWhile(Char::isLetter).toIntOrNull() ?: Int.MAX_VALUE }
            .thenBy { colFromAddress(it) })
    }
    fun replaceAllTextCells() {
        val refs = findTextCells()
        if (refs.isEmpty()) { notify("Không tìm thấy ô văn bản phù hợp."); return }
        checkpoint()
        refs.forEach { ref ->
            val changed = rawValue(ref).replace(findNeedle, replacement, ignoreCase = true)
            val key = "${sheet.partPath}::$ref"
            if (changed == sheet.cells[ref].orEmpty()) values.remove(key)
            else values[key] = changed
        }
        formula = rawValue(selected)
        notify("Đã thay nội dung trong ${refs.size} ô. Chọn Lưu bản sao để xuất XLSX.")
    }
    fun saveWorkbookCopy() {
        val valueSnapshot = values.toMap()
        val styleSnapshot = styleChanges.toMap()
        val mergeSnapshot = mergeChanges.toMap()
        save(DocumentStore.suggestedCopyName(displayName, "xlsx"), DocumentStore.XLSX, true) { _, output ->
            output.write(workbookBytes(valueSnapshot, styleSnapshot, mergeSnapshot))
        }
    }
    LaunchedEffect(sheet.partPath) { xScroll.scrollTo(0); yScroll.scrollToItem(0) }
    LaunchedEffect(zoom) {
        if (previousZoom != zoom && previousZoom > 0) {
            xScroll.scrollTo((xScroll.value * zoom / previousZoom).roundToInt().coerceAtLeast(0).coerceAtMost(xScroll.maxValue))
            previousZoom = zoom
        }
    }
    val rowMap: List<Int>? = remember(sheet.partPath, filterText, filterColumn, sortOrder, values.toMap()) {
        if (filterText.isBlank() && sortOrder == 0) null
        else {
            // Data operations are deliberately view-only, preserving formulas/styles in the actual workbook.
            val matches = (2..maxOf(2, sheet.maxRow)).filter { row ->
                filterText.isBlank() || rawValue(OfficeOoxml.cellAddress(row, filterColumn))
                    .contains(filterText.trim(), ignoreCase = true)
            }
            val sorted = if (sortOrder == 0) matches else matches.sortedWith(Comparator<Int> { a, b ->
                val av = rawValue(OfficeOoxml.cellAddress(a, filterColumn))
                val bv = rawValue(OfficeOoxml.cellAddress(b, filterColumn))
                val comparison = when {
                    av.toDoubleOrNull() != null && bv.toDoubleOrNull() != null ->
                        av.toDouble().compareTo(bv.toDouble())
                    else -> av.compareTo(bv, ignoreCase = true)
                }
                comparison * sortOrder
            })
            listOf(1) + sorted
        }
    }
    LaunchedEffect(rowMap) { if (rowMap != null) yScroll.scrollToItem(0) }
    val currentMerges = remember(sheet.partPath, mergeChanges.toMap()) { effectiveMerges(sheet) }
    val selectedMerge = currentMerges.firstOrNull { it.contains(selected) }
    val hasChanges = values.isNotEmpty() || styleChanges.isNotEmpty() || mergeChanges.isNotEmpty()
    val selectedAppearance = activeStyle(selected)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).imePadding()) {
        Row(Modifier.fillMaxWidth().height(51.dp).background(ExcelGreen).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
                Icon(Icons.Default.ArrowBack, "Quay lại", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(displayName, color = Color.White, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${document.data.sheets.size} trang tính · Offline", fontSize = 10.sp,
                    color = Color.White.copy(alpha = .85f))
            }
            IconButton(onClick = { applyRibbonAction("undo") }, enabled = undo.isNotEmpty(), modifier = Modifier.size(37.dp)) {
                Icon(Icons.Default.Undo, "Hoàn tác", tint = Color.White.copy(alpha = if (undo.isNotEmpty()) 1f else .4f))
            }
            IconButton(onClick = { applyRibbonAction("redo") }, enabled = redo.isNotEmpty(), modifier = Modifier.size(37.dp)) {
                Icon(Icons.Default.Redo, "Làm lại", tint = Color.White.copy(alpha = if (redo.isNotEmpty()) 1f else .4f))
            }
            IconButton(onClick = { findReplaceVisible = true }, modifier = Modifier.size(35.dp)) {
                Icon(Icons.Default.Search, "Tìm và thay thế", tint = Color.White)
            }
            IconButton(onClick = { saveWorkbookCopy() }, modifier = Modifier.size(39.dp)) {
                Icon(Icons.Default.Save, "Lưu dưới dạng XLSX", tint = Color.White)
            }
            IconButton(onClick = { fileMenuVisible = true }, modifier = Modifier.size(35.dp)) {
                Icon(Icons.Default.MoreVert, "Thêm tùy chọn tài liệu", tint = Color.White)
            }
        }
        ScrollableTabRow(
            selectedTabIndex = activeTab.ordinal,
            modifier = Modifier.fillMaxWidth().height(44.dp),
            edgePadding = 4.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = ExcelGreen,
            divider = { HorizontalDivider(thickness = .5.dp) }
        ) {
            ExcelTab.entries.forEach { tab ->
                Tab(selected = activeTab == tab, onClick = { activeTab = tab; ribbonVisible = true },
                    modifier = Modifier.height(42.dp),
                    text = { Text(tab.label, fontSize = 12.sp, fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Normal) })
            }
        }
        if (ribbonVisible) {
            val actions = remember(activeTab, selectedAppearance, showGridLines, showFormulaBar,
                searchVisible, filterVisible, sortOrder) {
                when (activeTab) {
                    ExcelTab.HOME -> listOf(
                        ExcelRibbonItem("Dán", Icons.Default.ContentPaste, "paste"),
                        ExcelRibbonItem("Sao chép", Icons.Default.ContentCopy, "copy"),
                        ExcelRibbonItem("Cắt", Icons.Default.ContentCut, "cut"),
                        ExcelRibbonItem("Xóa", Icons.Default.Backspace, "clear"),
                        ExcelRibbonItem("Đậm", Icons.Default.FormatBold, "bold", selectedAppearance.bold),
                        ExcelRibbonItem("Nghiêng", Icons.Default.FormatItalic, "italic", selectedAppearance.italic),
                        ExcelRibbonItem("Gạch chân", Icons.Default.FormatUnderlined, "underline", selectedAppearance.underline),
                        ExcelRibbonItem("Trái", Icons.Default.FormatAlignLeft, "left", selectedAppearance.alignment == "left"),
                        ExcelRibbonItem("Giữa", Icons.Default.FormatAlignCenter, "center", selectedAppearance.alignment == "center"),
                        ExcelRibbonItem("Phải", Icons.Default.FormatAlignRight, "right", selectedAppearance.alignment == "right"),
                        ExcelRibbonItem("Tô vàng", Icons.Default.FormatColorFill, "highlight", selectedAppearance.fillRgb == "FFF2CC"),
                        ExcelRibbonItem("Phần trăm", Icons.Default.Percent, "percent", selectedAppearance.percent)
                    )
                    ExcelTab.INSERT -> listOf(
                        ExcelRibbonItem("Ngày", Icons.Default.Event, "insertDate"),
                        ExcelRibbonItem("Giờ", Icons.Default.Schedule, "insertTime"),
                        ExcelRibbonItem("Dấu tích", Icons.Default.CheckCircle, "insertCheck"),
                        ExcelRibbonItem("Số hàng", Icons.Default.Tag, "numberList"),
                        ExcelRibbonItem("Dán", Icons.Default.ContentPaste, "paste")
                    )
                    ExcelTab.FORMULAS -> listOf(
                        ExcelRibbonItem("AutoSum", Icons.Default.Functions, "sum"),
                        ExcelRibbonItem("AVERAGE", Icons.Default.Calculate, "average"),
                        ExcelRibbonItem("COUNT", Icons.Default.Numbers, "count"),
                        ExcelRibbonItem("MIN", Icons.Default.ArrowDownward, "min"),
                        ExcelRibbonItem("MAX", Icons.Default.ArrowUpward, "max")
                    )
                    ExcelTab.DATA -> listOf(
                        ExcelRibbonItem("Lọc", Icons.Default.FilterAlt, "filter", filterVisible),
                        ExcelRibbonItem("A→Z", Icons.Default.SortByAlpha, "sortAsc", sortOrder == 1),
                        ExcelRibbonItem("Z→A", Icons.Default.SwapVert, "sortDesc", sortOrder == -1),
                        ExcelRibbonItem("Bỏ lọc", Icons.Default.FilterAltOff, "resetDataView")
                    )
                    ExcelTab.REVIEW -> listOf(
                        ExcelRibbonItem("Tìm kiếm", Icons.Default.Search, "find", searchVisible),
                        ExcelRibbonItem("Thay thế", Icons.Default.FindReplace, "replace"),
                        ExcelRibbonItem("Hoàn tác", Icons.Default.Undo, "undo"),
                        ExcelRibbonItem("Làm lại", Icons.Default.Redo, "redo"),
                        ExcelRibbonItem("Chi tiết", Icons.Default.Info, "info")
                    )
                    ExcelTab.VIEW -> listOf(
                        ExcelRibbonItem("Thu nhỏ", Icons.Default.ZoomOut, "zoomOut"),
                        ExcelRibbonItem("Phóng to", Icons.Default.ZoomIn, "zoomIn"),
                        ExcelRibbonItem("100%", Icons.Default.CenterFocusStrong, "zoom100"),
                        ExcelRibbonItem("Đường lưới", Icons.Default.GridOn, "gridlines", showGridLines),
                        ExcelRibbonItem("Thanh fx", Icons.Default.Functions, "formulaBar", showFormulaBar),
                        ExcelRibbonItem("Ẩn dải", Icons.Default.ExpandLess, "ribbon")
                    )
                }
            }
            Row(Modifier.fillMaxWidth().height(77.dp).horizontalScroll(rememberScrollState())
                .padding(horizontal = 5.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                actions.forEach { action ->
                    RibbonTool(action, onClick = { applyRibbonAction(action.id) })
                }
            }
        }
        if (searchVisible) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.weight(1f)
                    .height(50.dp), singleLine = true, placeholder = { Text("Tìm trong trang tính") },
                    textStyle = TextStyle(fontSize = 13.sp))
                TextButton(onClick = {
                    results = (sheet.cells.keys + values.keys.filter { it.startsWith(sheet.partPath + "::") }
                        .map { it.substringAfterLast("::") }).distinct().filter { ref ->
                        rawValue(ref).contains(query, ignoreCase = true) ||
                            cellDisplay(ref).contains(query, ignoreCase = true)
                    }.take(200)
                    resultIndex = 0
                    if (results.isNotEmpty()) navigate(results[0]) else notify("Không tìm thấy dữ liệu phù hợp")
                }, enabled = query.isNotBlank()) { Text("Tìm") }
                TextButton(onClick = {
                    if (results.isNotEmpty()) {
                        resultIndex = (resultIndex + 1) % results.size
                        navigate(results[resultIndex])
                    }
                }, enabled = results.isNotEmpty()) { Text("${if (results.isEmpty()) 0 else resultIndex + 1}/${results.size} ▶") }
            }
        }
        if (filterVisible) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Cột ${OfficeOoxml.cellAddress(1, filterColumn).dropLast(1)}", fontSize = 11.sp, color = ExcelGreen)
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(value = filterText, onValueChange = { filterText = it },
                    modifier = Modifier.weight(1f).height(49.dp), singleLine = true,
                    placeholder = { Text("Lọc chứa nội dung...") }, textStyle = TextStyle(fontSize = 13.sp))
                IconButton(onClick = { filterText = "" }) { Icon(Icons.Default.Clear, "Xóa bộ lọc") }
            }
        }
        if (showFormulaBar) {
            Row(Modifier.fillMaxWidth().height(51.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .4f))
                .padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = addressInput, onValueChange = { addressInput = it },
                    singleLine = true, textStyle = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.width(56.dp).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(5.dp))
                        .padding(7.dp))
                IconButton(onClick = { navigate(addressInput) }, modifier = Modifier.size(29.dp)) {
                    Icon(Icons.Default.ArrowForward, "Đến ô", Modifier.size(17.dp))
                }
                Text("fx", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ExcelGreen)
                Spacer(Modifier.width(6.dp))
                BasicTextField(value = formula, onValueChange = { formula = it },
                    modifier = Modifier.weight(1f).focusRequester(formulaFocusRequester)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(5.dp))
                        .padding(horizontal = 7.dp, vertical = 8.dp),
                    singleLine = true, textStyle = TextStyle(fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface),
                    decorationBox = { field ->
                        Box {
                            if (formula.isEmpty()) Text("Nhập giá trị hoặc công thức (=SUM...)",
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            field()
                        }
                    })
                IconButton(onClick = { setValue(formula) }, modifier = Modifier.size(35.dp)) {
                    Icon(Icons.Default.Check, "Nhập vào ô", tint = ExcelGreen)
                }
            }
        }
        if (sheet.truncated) {
            Text("Tệp rất lớn: chỉ nạp tối đa 120.000 ô / 100.000 hàng / 256 cột. Tệp gốc được giữ nguyên.",
                modifier = Modifier.fillMaxWidth().background(Color(0xFFFFF4D6)).padding(5.dp),
                color = Color(0xFF734F0B), fontSize = 10.sp, maxLines = 2)
        }
        ExcelGrid(
            rows = rowMap?.size ?: maxRows, columns = maxCols, selected = selected,
            cellValue = ::cellDisplay, cellAppearance = ::activeStyle, merges = currentMerges,
            rowNumbers = rowMap, showGridLines = showGridLines,
            onCellClick = { selected = it }, onCellDoubleClick = {
                selected = it
                if (!showFormulaBar) showFormulaBar = true
                formulaFocusRequester.requestFocus(); keyboardController?.show()
            }, horizontal = xScroll, vertical = yScroll,
            zoom = zoom, onPinchZoom = { zoom = (zoom * it).coerceIn(.65f, 2.5f) },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            shadowElevation = 3.dp
        ) {
            Row(
                Modifier.fillMaxWidth().height(67.dp).horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ExcelEditTool("In đậm", Icons.Default.FormatBold, selectedAppearance.bold) {
                    applyRibbonAction("bold")
                }
                ExcelEditTool(
                    "Màu chữ", Icons.Default.FormatColorText, selectedAppearance.fontRgb != null,
                    accent = selectedAppearance.fontRgb?.let(::excelComposeColor) ?: ExcelGreen
                ) { colorTarget = ExcelColorTarget.FONT }
                ExcelEditTool(
                    "Màu nền", Icons.Default.FormatColorFill, selectedAppearance.fillRgb != null,
                    accent = selectedAppearance.fillRgb?.let(::excelComposeColor) ?: ExcelGreen
                ) { colorTarget = ExcelColorTarget.FILL }
                ExcelEditTool(
                    if (selectedMerge != null) "Bỏ gộp" else "Gộp ô",
                    Icons.Default.MergeType, selectedMerge != null
                ) {
                    if (selectedMerge != null) unmergeSelected() else {
                        val parts = OfficeOoxml.addressParts(selected)
                        mergeStart = selected
                        mergeEnd = parts?.let { OfficeOoxml.cellAddress(it.first, (it.second + 1).coerceAtMost(maxCols)) } ?: selected
                        mergeDialogVisible = true
                    }
                }
                ExcelEditTool("Công cụ", Icons.Default.Apps, ribbonVisible) { ribbonVisible = !ribbonVisible }
                ExcelEditTool("Bàn phím", Icons.Default.Keyboard, false) {
                    if (!showFormulaBar) showFormulaBar = true
                    formulaFocusRequester.requestFocus(); keyboardController?.show()
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(44.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .48f))
            .horizontalScroll(rememberScrollState()).padding(horizontal = 5.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            document.data.sheets.forEachIndexed { index, data ->
                Surface(onClick = { sheetIndex = index },
                    color = if (index == sheetIndex) MaterialTheme.colorScheme.surface else Color.Transparent,
                    shape = RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp)) {
                    Column(Modifier.padding(horizontal = 13.dp, vertical = 10.dp)) {
                        Text(data.name, maxLines = 1, fontSize = 12.sp,
                            fontWeight = if (index == sheetIndex) FontWeight.Bold else FontWeight.Normal,
                            color = if (index == sheetIndex) ExcelGreen else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(26.dp).padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (hasChanges) "${values.size + styleChanges.size + mergeChanges.size} thay đổi chưa lưu" else "Sẵn sàng",
                fontSize = 10.sp, color = if (hasChanges) ExcelGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f))
            if (rowMap != null) Text("Đang lọc/sắp xếp hiển thị · ", fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${(zoom * 100).roundToInt()}%", fontSize = 11.sp, color = ExcelGreen,
                modifier = Modifier.clickable { activeTab = ExcelTab.VIEW; ribbonVisible = true })
        }
    }
    if (fileMenuVisible) {
        ModalBottomSheet(onDismissRequest = { fileMenuVisible = false }) {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    .padding(start = 14.dp, end = 14.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(12.dp), color = ExcelGreen) {
                        Text("S", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(displayName, style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${"%.1f".format(document.bytes.size / 1024.0)} KB · ${document.data.sheets.size} worksheet",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { fileMenuVisible = false }) { Icon(Icons.Default.Close, "Đóng") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FileQuickAction("Lưu dưới\ndạng", Icons.Default.SaveAs, Modifier.weight(1f)) {
                        fileMenuVisible = false; saveWorkbookCopy()
                    }
                    FileQuickAction("Tìm &\nthay thế", Icons.Default.FindReplace, Modifier.weight(1f)) {
                        fileMenuVisible = false; findReplaceVisible = true
                    }
                    FileQuickAction("Chia sẻ", Icons.Default.Share, Modifier.weight(1f)) {
                        fileMenuVisible = false; shareCurrentWorkbook()
                    }
                    FileQuickAction("In", Icons.Default.Print, Modifier.weight(1f)) {
                        fileMenuVisible = false; printCurrentSheet()
                    }
                }
                ExcelMenuCard {
                    FileActionRow("Đổi tên", "Đổi tên tệp tại vị trí hiện tại.", Icons.Default.Edit) {
                        renameInput = displayName; fileMenuVisible = false; renameVisible = true
                    }
                    FileActionRow("Thêm vào", "Đưa tài liệu lên đầu danh sách Tệp gần đây.", Icons.Default.Add) {
                        fileMenuVisible = false; addToRecent()
                    }
                }
                ExcelMenuCard {
                    FileActionRow("Xuất dưới dạng PDF", "Tạo PDF có bảng, màu nền và chữ cơ bản.", Icons.Default.PictureAsPdf) {
                        fileMenuVisible = false; exportSheetPdf()
                    }
                    FileActionRow("Xuất dưới dạng hình ảnh", "Xuất worksheet hiện tại thành ảnh PNG.", Icons.Default.Image) {
                        fileMenuVisible = false; exportSheetPng()
                    }
                    FileActionRow("Tùy chọn chuyển đổi khác", "CSV, TSV và các định dạng dữ liệu cơ bản.", Icons.Default.SwapHoriz) {
                        fileMenuVisible = false; conversionVisible = true
                    }
                }
                ExcelMenuCard {
                    FileActionRow("Hợp nhất worksheet", "Ghép dữ liệu các sheet thành một worksheet mới.", Icons.Default.TableRows) {
                        fileMenuVisible = false; mergeWorksheets()
                    }
                    FileActionRow("Tất cả dịch vụ", "Xem nhanh mọi thao tác offline đang hỗ trợ.", Icons.Default.Apps) {
                        fileMenuVisible = false; servicesVisible = true
                    }
                }
                ExcelMenuCard {
                    FileActionRow("Sao lưu và khôi phục", "Sao lưu cục bộ hoặc xuất bản khôi phục gần nhất.", Icons.Default.History) {
                        fileMenuVisible = false; backupVisible = true
                    }
                    FileActionRow("Mã hóa tài liệu", "Tạo hoặc giải mã bản sao DocFlow .dfx bằng mật khẩu.", Icons.Default.Lock) {
                        fileMenuVisible = false; securityVisible = true
                    }
                    FileActionRow("Thông tin tài liệu", "Tên, dung lượng, worksheet và trạng thái chỉnh sửa.", Icons.Default.Info) {
                        fileMenuVisible = false; fileInfoVisible = true
                    }
                    FileActionRow("Mở bằng ứng dụng khác", "Mở bản có cả các chỉnh sửa hiện tại.", Icons.Default.OpenInNew) {
                        fileMenuVisible = false; shareCurrentWorkbook(openOnly = true)
                    }
                }
            }
        }
    }
    if (findReplaceVisible) {
        AlertDialog(
            onDismissRequest = { findReplaceVisible = false },
            title = { Text("Tìm kiếm & thay thế") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Trong sheet: ${sheet.name}", color = ExcelGreen,
                        style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(
                        value = findNeedle, onValueChange = { findNeedle = it },
                        label = { Text("Nội dung cần tìm") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = replacement, onValueChange = { replacement = it },
                        label = { Text("Thay bằng") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Chỉ thay chữ và số trong các ô đã nạp; bỏ qua ô công thức để tránh hỏng tham chiếu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            val matches = findTextCells()
                            if (matches.isEmpty()) notify("Không tìm thấy: $findNeedle")
                            else {
                                val index = matches.indexOf(selected)
                                navigate(matches[(index + 1) % matches.size])
                            }
                        }, enabled = findNeedle.isNotBlank()) { Text("Tìm tiếp") }
                        TextButton(onClick = {
                            val body = rawValue(selected)
                            if (findNeedle.isBlank() || body.startsWith("=") ||
                                !body.contains(findNeedle, ignoreCase = true)) {
                                notify("Ô đang chọn không chứa nội dung cần tìm.")
                            } else {
                                setValue(body.replace(findNeedle, replacement, ignoreCase = true))
                                notify("Đã thay nội dung ô $selected")
                            }
                        }, enabled = findNeedle.isNotBlank()) { Text("Thay ô") }
                    }
                    Button(
                        onClick = { replaceAllTextCells(); findReplaceVisible = false },
                        enabled = findNeedle.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Thay tất cả trong sheet") }
                }
            },
            confirmButton = { TextButton(onClick = { findReplaceVisible = false }) { Text("Đóng") } }
        )
    }
    colorTarget?.let { target ->
        val colors = listOf(
            "000000", "FFFFFF", "C00000", "FF0000", "ED7D31", "FFC000",
            "70AD47", "00B050", "00B0F0", "0070C0", "4472C4", "7030A0",
            "F4CCCC", "FCE5CD", "FFF2CC", "D9EAD3", "D0E0E3", "CFE2F3",
            "D9D2E9", "EAD1DC"
        )
        AlertDialog(
            onDismissRequest = { colorTarget = null },
            title = { Text(if (target == ExcelColorTarget.FONT) "Màu phông chữ" else "Màu nền ô") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    colors.chunked(5).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            row.forEach { rgb ->
                                val color = excelComposeColor(rgb)
                                Surface(
                                    onClick = {
                                        if (target == ExcelColorTarget.FONT) {
                                            setAppearance { old, _ -> old.copy(fontRgb = rgb) }
                                        } else {
                                            setAppearance { old, _ -> old.copy(fillRgb = rgb) }
                                        }
                                        colorTarget = null
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    color = color,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp, MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier.size(44.dp)
                                ) {}
                            }
                            repeat(5 - row.size) { Spacer(Modifier.size(44.dp)) }
                        }
                    }
                    TextButton(onClick = {
                        if (target == ExcelColorTarget.FONT) setAppearance { old, _ -> old.copy(fontRgb = "") }
                        else setAppearance { old, _ -> old.copy(fillRgb = "") }
                        colorTarget = null
                    }) { Text("Bỏ màu tùy chỉnh") }
                }
            },
            confirmButton = { TextButton(onClick = { colorTarget = null }) { Text("Đóng") } }
        )
    }
    if (mergeDialogVisible) {
        AlertDialog(
            onDismissRequest = { mergeDialogVisible = false },
            title = { Text("Gộp ô ngang") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Nhập ô đầu và ô cuối trong cùng một hàng. Dữ liệu chỉ được giữ ở ô đầu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(mergeStart, { mergeStart = it.uppercase(Locale.ROOT) },
                            label = { Text("Ô đầu") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(mergeEnd, { mergeEnd = it.uppercase(Locale.ROOT) },
                            label = { Text("Ô cuối") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = { Button(onClick = {
                mergeDialogVisible = false; applyMerge(mergeStart, mergeEnd)
            }) { Text("Gộp") } },
            dismissButton = { TextButton(onClick = { mergeDialogVisible = false }) { Text("Hủy") } }
        )
    }
    if (renameVisible) {
        AlertDialog(
            onDismissRequest = { renameVisible = false },
            title = { Text("Đổi tên tài liệu") },
            text = { OutlinedTextField(renameInput, { renameInput = it }, label = { Text("Tên tệp") },
                singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { renameCurrentDocument() }) { Text("Đổi tên") } },
            dismissButton = { TextButton(onClick = { renameVisible = false }) { Text("Hủy") } }
        )
    }
    if (conversionVisible) {
        AlertDialog(
            onDismissRequest = { conversionVisible = false },
            title = { Text("Chuyển đổi worksheet") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chọn định dạng xuất cho worksheet ${sheet.name}.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { conversionVisible = false; exportSheetDelimited(',', "csv", DocumentStore.CSV) },
                        modifier = Modifier.fillMaxWidth()) { Text("Xuất CSV") }
                    OutlinedButton(onClick = { conversionVisible = false; exportSheetDelimited('\t', "tsv", "text/tab-separated-values") },
                        modifier = Modifier.fillMaxWidth()) { Text("Xuất TSV / văn bản tab") }
                    OutlinedButton(onClick = { conversionVisible = false; exportSheetPdf() },
                        modifier = Modifier.fillMaxWidth()) { Text("Xuất PDF") }
                    OutlinedButton(onClick = { conversionVisible = false; exportSheetPng() },
                        modifier = Modifier.fillMaxWidth()) { Text("Xuất PNG") }
                }
            },
            confirmButton = { TextButton(onClick = { conversionVisible = false }) { Text("Đóng") } }
        )
    }
    if (backupVisible) {
        AlertDialog(
            onDismissRequest = { backupVisible = false },
            title = { Text("Sao lưu và khôi phục") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Bản sao cục bộ nằm trong vùng riêng của ứng dụng và không tải lên mạng.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { createLocalBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Tạo bản sao cục bộ")
                    }
                    OutlinedButton(onClick = { restoreLatestBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.History, null); Spacer(Modifier.width(8.dp)); Text("Khôi phục bản gần nhất")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { backupVisible = false }) { Text("Đóng") } }
        )
    }
    if (securityVisible) {
        AlertDialog(
            onDismissRequest = { securityVisible = false },
            title = { Text("Bảo vệ tài liệu") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("DocFlow dùng AES-GCM để tạo bản sao .dfx. Đây không phải mật khẩu XLSX chuẩn của Microsoft Excel.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = {
                        securityVisible = false; encryptPassword = ""; encryptConfirm = ""; encryptPasswordVisible = true
                    }, modifier = Modifier.fillMaxWidth()) { Text("Mã hóa tài liệu hiện tại") }
                    OutlinedButton(onClick = {
                        securityVisible = false; decryptPicker.launch(arrayOf("application/octet-stream", "*/*"))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Giải mã bản sao .dfx") }
                }
            },
            confirmButton = { TextButton(onClick = { securityVisible = false }) { Text("Đóng") } }
        )
    }
    if (encryptPasswordVisible) {
        AlertDialog(
            onDismissRequest = { encryptPasswordVisible = false },
            title = { Text("Tạo bản sao mã hóa") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(encryptPassword, { encryptPassword = it }, label = { Text("Mật khẩu") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(encryptConfirm, { encryptConfirm = it }, label = { Text("Nhập lại mật khẩu") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Hãy lưu mật khẩu ở nơi an toàn. DocFlow không thể khôi phục mật khẩu đã quên.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { Button(onClick = {
                when {
                    encryptPassword.length < 6 -> notify("Mật khẩu cần ít nhất 6 ký tự.")
                    encryptPassword != encryptConfirm -> notify("Hai mật khẩu không trùng nhau.")
                    else -> {
                        val valueSnapshot = values.toMap(); val styleSnapshot = styleChanges.toMap();
                        val mergeSnapshot = mergeChanges.toMap(); val password = encryptPassword
                        encryptPasswordVisible = false
                        save("${displayName.substringBeforeLast('.')}.dfx", "application/octet-stream", false) { _, output ->
                            output.write(DocFlowCrypto.encrypt(
                                workbookBytes(valueSnapshot, styleSnapshot, mergeSnapshot), password, displayName
                            ))
                        }
                    }
                }
            }) { Text("Mã hóa") } },
            dismissButton = { TextButton(onClick = { encryptPasswordVisible = false }) { Text("Hủy") } }
        )
    }
    if (decryptPasswordVisible) {
        AlertDialog(
            onDismissRequest = { decryptPasswordVisible = false; pendingEncryptedUri = null },
            title = { Text("Giải mã bản sao DocFlow") },
            text = { OutlinedTextField(decryptPassword, { decryptPassword = it }, label = { Text("Mật khẩu") },
                singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = {
                val uri = pendingEncryptedUri ?: return@Button
                val password = decryptPassword
                scope.launch {
                    try {
                        val decoded = withContext(Dispatchers.IO) {
                            DocFlowCrypto.decrypt(DocumentStore.readUpTo(context, uri, 100 * 1024 * 1024), password)
                        }
                        decryptPasswordVisible = false; pendingEncryptedUri = null
                        val name = decoded.filename.substringBeforeLast('.', decoded.filename) + "_giai_ma.xlsx"
                        save(name, DocumentStore.XLSX, true) { _, output -> output.write(decoded.bytes) }
                    } catch (e: Exception) {
                        notify("Giải mã thất bại: ${e.message ?: "sai mật khẩu"}")
                    }
                }
            }) { Text("Giải mã") } },
            dismissButton = { TextButton(onClick = { decryptPasswordVisible = false; pendingEncryptedUri = null }) { Text("Hủy") } }
        )
    }
    if (servicesVisible) {
        AlertDialog(
            onDismissRequest = { servicesVisible = false },
            title = { Text("Dịch vụ Excel offline") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("• Chỉnh sửa ô, công thức cơ bản, màu chữ/nền và gộp ô ngang")
                    Text("• Tìm & thay thế, lọc/sắp xếp hiển thị, zoom")
                    Text("• Lưu XLSX, chia sẻ, in, đổi tên và mở bằng ứng dụng khác")
                    Text("• Xuất PDF, PNG, CSV, TSV và hợp nhất worksheet")
                    Text("• Sao lưu cục bộ và mã hóa bản sao .dfx")
                }
            },
            confirmButton = { TextButton(onClick = { servicesVisible = false }) { Text("Đóng") } }
        )
    }
    if (fileInfoVisible) {
        AlertDialog(
            onDismissRequest = { fileInfoVisible = false },
            title = { Text("Thông tin Excel") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Tên: $displayName")
                    Text("Dung lượng gốc: ${"%.1f".format(document.bytes.size / 1024.0)} KB")
                    Text("Số worksheet: ${document.data.sheets.size}")
                    Text("Worksheet hiện tại: ${sheet.name}")
                    Text("Ô sửa nội dung: ${values.size}")
                    Text("Ô đổi định dạng: ${styleChanges.size}")
                    Text("Thao tác gộp/bỏ gộp: ${mergeChanges.size}")
                    Text("Tệp gốc vẫn được giữ nguyên cho đến khi bạn chọn Lưu dưới dạng.")
                }
            },
            confirmButton = { TextButton(onClick = { fileInfoVisible = false }) { Text("Đóng") } }
        )
    }
    if (infoVisible) AlertDialog(onDismissRequest = { infoVisible = false },
        title = { Text("Giới hạn trình Excel offline") },
        text = { Text("Lưu thành bản sao. Các nút định dạng cơ bản được ghi vào XLSX; công thức SUM/AVERAGE/COUNT/MIN/MAX tính thử trên dữ liệu số. Sắp xếp và lọc chỉ thay đổi cách xem, không ghi lại thứ tự hàng. PivotTable, macro, biểu đồ và định dạng phức tạp cần bộ máy LibreOffice native.") },
        confirmButton = { TextButton(onClick = { infoVisible = false }) { Text("Đóng") } })
}

@Composable
private fun RibbonTool(item: ExcelRibbonItem, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(7.dp),
        color = if (item.active) ExcelPale else Color.Transparent,
        modifier = Modifier.widthIn(min = 56.dp).fillMaxHeight()) {
        Column(Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(item.icon, contentDescription = item.title, tint = ExcelGreen, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(5.dp))
            Text(item.title, fontSize = 10.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}


@Composable
private fun ExcelEditTool(
    label: String,
    icon: ImageVector,
    active: Boolean,
    accent: Color = ExcelGreen,
    action: () -> Unit
) {
    Surface(
        onClick = action,
        shape = RoundedCornerShape(10.dp),
        color = if (active) ExcelPale else Color.Transparent,
        modifier = Modifier.widthIn(min = 68.dp).fillMaxHeight()
    ) {
        Column(
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, label, tint = accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 10.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
private fun FileQuickAction(label: String, icon: ImageVector, modifier: Modifier, action: () -> Unit) {
    Surface(
        onClick = action,
        modifier = modifier.height(112.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)
    ) {
        Column(
            Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, label, tint = ExcelGreen, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(8.dp))
            Text(label, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontSize = 11.sp, lineHeight = 15.sp, maxLines = 2)
        }
    }
}

@Composable
private fun ExcelMenuCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .38f),
        modifier = Modifier.fillMaxWidth()
    ) { Column(Modifier.fillMaxWidth(), content = content) }
}

@Composable
private fun FileActionRow(title: String, subtitle: String, icon: ImageVector, action: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = action).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, title, tint = ExcelGreen, modifier = Modifier.size(26.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp, lineHeight = 15.sp, maxLines = 2)
        }
        Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun excelComposeColor(rgb: String): Color = runCatching {
    Color(android.graphics.Color.parseColor("#${rgb.takeLast(6)}"))
}.getOrDefault(ExcelGreen)

private fun printPdfBytes(context: android.content.Context, name: String, bytes: ByteArray) {
    val manager = context.getSystemService(android.content.Context.PRINT_SERVICE) as PrintManager
    manager.print(name, object : PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?, callback: PrintDocumentAdapter.LayoutResultCallback, extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) callback.onLayoutCancelled()
            else callback.onLayoutFinished(
                PrintDocumentInfo.Builder(name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true
            )
        }

        override fun onWrite(
            pages: Array<out PageRange>, destination: ParcelFileDescriptor,
            cancellationSignal: CancellationSignal, callback: PrintDocumentAdapter.WriteResultCallback
        ) {
            Thread {
                try {
                    if (cancellationSignal.isCanceled) { callback.onWriteCancelled(); return@Thread }
                    FileOutputStream(destination.fileDescriptor).use { it.write(bytes); it.flush() }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message ?: "Không thể ghi bản in")
                }
            }.start()
        }
    }, null)
}


// ================ ExcelGrid.kt ================
// One canvas per visible row. No 100,000 x 256 Compose TextFields or cell Views.
internal const val GRID_COLUMN_DP = 124
private const val GRID_ROW_DP = 43
private const val GRID_INDEX_DP = 50

@Composable
internal fun ExcelGrid(
    rows: Int,
    columns: Int,
    selected: String,
    cellValue: (String) -> String,
    cellAppearance: (String) -> OfficeOoxml.CellAppearance,
    merges: List<OfficeOoxml.MergeRange> = emptyList(),
    rowNumbers: List<Int>? = null,
    showGridLines: Boolean = true,
    onCellClick: (String) -> Unit,
    onCellDoubleClick: (String) -> Unit = onCellClick,
    horizontal: ScrollState,
    vertical: LazyListState,
    zoom: Float,
    onPinchZoom: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val bg = scheme.surface
    val header = scheme.surfaceVariant
    val foreground = scheme.onSurface
    val selectedBg = androidx.compose.ui.graphics.Color(0xFFDAF0E4)
    val selectedFg = androidx.compose.ui.graphics.Color(0xFF155B38)
    val outline = scheme.outlineVariant
    val density = LocalDensity.current
    val scale = zoom.coerceIn(0.65f, 2.5f)
    val columnWidth = GRID_COLUMN_DP.dp * scale
    val rowHeight = GRID_ROW_DP.dp * scale
    val indexWidth = GRID_INDEX_DP.dp * scale
    val columnWidthPx = with(density) { columnWidth.toPx() }
    val rowHeightPx = with(density) { rowHeight.toPx() }
    val contentWidth = (columns * GRID_COLUMN_DP).dp * scale
    val currentClick = rememberUpdatedState(onCellClick)
    val currentDoubleClick = rememberUpdatedState(onCellDoubleClick)
    val currentPinch = rememberUpdatedState(onPinchZoom)
    val mergeList = remember(merges) { merges.sortedWith(compareBy<OfficeOoxml.MergeRange> { it.startRow }.thenBy { it.startCol }) }
    val labelSize = with(density) { (13f * scale).sp.toPx() }
    val regularPaint = remember(foreground, labelSize) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = foreground.toArgb(); textSize = labelSize }
    }
    val highlightedPaint = remember(selectedFg, labelSize) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = selectedFg.toArgb(); textSize = labelSize; isFakeBoldText = true }
    }

    Column(
        modifier.background(bg, RoundedCornerShape(10.dp)).clipToBounds()
            .pointerInput(Unit) {
                // React only when at least two fingers are touching. Single-finger scrolling
                // remains owned by the horizontal ScrollState / vertical LazyColumn.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.size >= 2) {
                            val oldDistance = (pressed[0].previousPosition - pressed[1].previousPosition).getDistance()
                            val newDistance = (pressed[0].position - pressed[1].position).getDistance()
                            if (oldDistance > 2f && newDistance > 2f) {
                                val factor = (newDistance / oldDistance).coerceIn(0.8f, 1.25f)
                                if (kotlin.math.abs(factor - 1f) > 0.005f) currentPinch.value(factor)
                            }
                            pressed.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        Row(Modifier.fillMaxWidth().height(38.dp * scale)) {
            GridIndex("", true, Modifier.width(indexWidth), scale)
            BoxWithConstraints(Modifier.weight(1f).clipToBounds()) {
                val viewportWidthPx = constraints.maxWidth.toFloat()
                Row(Modifier.horizontalScroll(horizontal)) {
                    Canvas(Modifier.width(contentWidth).fillMaxHeight()) {
                        val start = (horizontal.value / columnWidthPx).toInt().coerceIn(0, columns - 1)
                        val end = min(columns - 1, start + ceil(viewportWidthPx / columnWidthPx).toInt() + 2)
                        val canvas = drawContext.canvas.nativeCanvas
                        for (c in start..end) {
                            val x = c * columnWidthPx
                            drawRect(header, topLeft = Offset(x, 0f), size = androidx.compose.ui.geometry.Size(columnWidthPx, size.height))
                            drawLine(outline, Offset(x + columnWidthPx, 0f), Offset(x + columnWidthPx, size.height), 0.7.dp.toPx())
                            val label = OfficeOoxml.cellAddress(1, c + 1).dropLast(1)
                            val paint = regularPaint
                            paint.color = foreground.toArgb(); paint.isFakeBoldText = false
                            paint.isUnderlineText = false; paint.textSkewX = 0f
                            val textWidth = paint.measureText(label)
                            canvas.drawText(label, x + (columnWidthPx - textWidth) / 2, size.height / 2 + labelSize / 3, paint)
                        }
                        drawLine(outline, Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), 0.7.dp.toPx())
                    }
                }
            }
        }
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), state = vertical) {
            items(count = rows, key = { it }) { zeroBased ->
                val rowNumber = rowNumbers?.getOrNull(zeroBased) ?: (zeroBased + 1)
                Row(Modifier.fillMaxWidth().height(rowHeight), verticalAlignment = Alignment.CenterVertically) {
                    val selectedRow = selected.dropWhile(Char::isLetter).toIntOrNull() == rowNumber
                    GridIndex(rowNumber.toString(), selectedRow, Modifier.width(indexWidth), scale)
                    BoxWithConstraints(Modifier.weight(1f).fillMaxHeight().clipToBounds()) {
                        val viewportWidthPx = constraints.maxWidth.toFloat()
                        Row(Modifier.horizontalScroll(horizontal)) {
                            Canvas(
                                Modifier.width(contentWidth).fillMaxHeight()
                                    .pointerInput(rowNumber, columns, columnWidthPx, mergeList) {
                                        fun addressAt(point: Offset): String {
                                            val c = (floor(point.x / columnWidthPx).toInt() + 1).coerceIn(1, columns)
                                            val merge = mergeList.firstOrNull { it.contains(rowNumber, c) }
                                            return if (merge != null) OfficeOoxml.cellAddress(merge.startRow, merge.startCol)
                                            else OfficeOoxml.cellAddress(rowNumber, c)
                                        }
                                        detectTapGestures(
                                            onTap = { currentClick.value(addressAt(it)) },
                                            onDoubleTap = { currentDoubleClick.value(addressAt(it)) }
                                        )
                                    }
                            ) {
                                val start = (horizontal.value / columnWidthPx).toInt().coerceIn(0, columns - 1)
                                // draw only visible columns even though the canvas spans all columns
                                val end = min(columns - 1, start + ceil(viewportWidthPx / columnWidthPx).toInt() + 2)
                                val canvas = drawContext.canvas.nativeCanvas
                                var column = start
                                while (column <= end) {
                                    val colOne = column + 1
                                    val merge = mergeList.firstOrNull { it.contains(rowNumber, colOne) }
                                    val visibleStartOne = if (merge != null) maxOf(merge.startCol, start + 1) else colOne
                                    if (merge != null && colOne != visibleStartOne) { column++; continue }
                                    val spanEndOne = if (merge != null) minOf(merge.endCol, end + 1, columns) else colOne
                                    val span = spanEndOne - visibleStartOne + 1
                                    val x = (visibleStartOne - 1) * columnWidthPx
                                    val width = span * columnWidthPx
                                    val address = if (merge != null) OfficeOoxml.cellAddress(merge.startRow, merge.startCol)
                                        else OfficeOoxml.cellAddress(rowNumber, colOne)
                                    val isSelected = if (merge != null) merge.contains(selected) else address == selected
                                    val style = cellAppearance(address)
                                    if (!style.fillRgb.isNullOrBlank() && style.fillRgb.matches(Regex("[0-9A-Fa-f]{6}"))) {
                                        drawRect(androidx.compose.ui.graphics.Color(
                                            android.graphics.Color.parseColor("#${style.fillRgb}")),
                                            topLeft = Offset(x, 0f),
                                            size = androidx.compose.ui.geometry.Size(width, size.height))
                                    }
                                    if (isSelected) {
                                        drawRect(selectedBg.copy(alpha = 0.55f), topLeft = Offset(x, 0f),
                                            size = androidx.compose.ui.geometry.Size(width, size.height))
                                    }
                                    val value = if (merge == null || rowNumber == merge.startRow) cellValue(address) else ""
                                    if (value.isNotEmpty()) {
                                        val paint = if (isSelected) highlightedPaint else regularPaint
                                        paint.color = style.fontRgb?.takeIf { it.matches(Regex("[0-9A-Fa-f]{6}")) }
                                            ?.let { android.graphics.Color.parseColor("#$it") }
                                            ?: if (isSelected) selectedFg.toArgb() else foreground.toArgb()
                                        paint.isFakeBoldText = isSelected || style.bold
                                        paint.isUnderlineText = style.underline
                                        paint.textSkewX = if (style.italic) -0.18f else 0f
                                        val display = value.replace('\n', ' ')
                                        val textWidth = paint.measureText(display)
                                        val margin = 8.dp.toPx()
                                        val textX = when (style.alignment) {
                                            "right" -> x + width - textWidth - margin
                                            "center" -> x + (width - textWidth) / 2f
                                            else -> x + margin
                                        }
                                        canvas.save()
                                        canvas.clipRect(x + margin / 2, 0f, x + width - margin / 2, size.height)
                                        canvas.drawText(display, textX, rowHeightPx / 2 + labelSize / 3, paint)
                                        canvas.restore()
                                    }
                                    if (showGridLines) {
                                        drawLine(outline, Offset(x, 0f), Offset(x, size.height), 0.65.dp.toPx())
                                        drawLine(outline, Offset(x + width, 0f), Offset(x + width, size.height), 0.65.dp.toPx())
                                    }
                                    if (isSelected) {
                                        val green = androidx.compose.ui.graphics.Color(0xFF167346)
                                        drawLine(green, Offset(x, 1f), Offset(x + width, 1f), 2.dp.toPx())
                                        drawLine(green, Offset(x, size.height - 1f), Offset(x + width, size.height - 1f), 2.dp.toPx())
                                        drawLine(green, Offset(x + 1f, 0f), Offset(x + 1f, size.height), 2.dp.toPx())
                                        drawLine(green, Offset(x + width - 1f, 0f), Offset(x + width - 1f, size.height), 2.dp.toPx())
                                    }
                                    column = spanEndOne
                                }
                                drawLine(outline, Offset(0f, size.height - 0.5f),
                                    Offset(size.width, size.height - 0.5f), 0.65.dp.toPx())
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridIndex(label: String, active: Boolean, modifier: Modifier, scale: Float) {
    val scheme = MaterialTheme.colorScheme
    Box(
        modifier.fillMaxHeight()
            .background(if (active) androidx.compose.ui.graphics.Color(0xFFDAF0E4) else scheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = (12f * scale).sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = if (active) androidx.compose.ui.graphics.Color(0xFF155B38) else scheme.onSurfaceVariant)
    }
}
