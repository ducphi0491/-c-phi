# Fix Unicode NFC/NFD local path lookup and upload only the two staged PDFs.
# Does not upload/recheck the other 230 files, nor change Google OAuth credentials.
$ErrorActionPreference = 'Stop'

$toolDir = 'C:\TunerTools\BackupScripts\Drive_Documents'
$pythonTarget = Join-Path $toolDir '03_upload_documents.py'
$pythonFixed = Join-Path $PSScriptRoot '03_upload_documents.py'
$driveLib = Join-Path $toolDir 'tt_drive_client.py'
$runner = Join-Path $toolDir 'CHAY_UPLOAD_DOCUMENTS.ps1'
$stageParent = 'C:\TunerTools\BackupPrep'
$report = 'C:\TunerTools\BackupPrep\Drive_Documents_Only2'

foreach ($required in @($pythonTarget, $pythonFixed, $driveLib, $runner)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
        throw "Missing required program file: $required"
    }
}

# Find an existing staged copy of exactly the two PDFs (created previously).
$stages = @(Get-ChildItem -LiteralPath $stageParent -Directory -Filter 'Documents_Only2_*' |
    Sort-Object LastWriteTime -Descending)
$stage = $null
foreach ($item in $stages) {
    $contents = @(Get-ChildItem -LiteralPath $item.FullName -Recurse -File)
    if ($contents.Count -ne 2) { continue }
    $valid = $true
    foreach ($file in $contents) {
        if ($file.Extension -ne '.pdf' -or $file.BaseName -notmatch '\s[12]$') {
            $valid = $false
            break
        }
    }
    if ($valid) { $stage = $item; break }
}
if ($null -eq $stage) {
    throw 'No Documents_Only2_* staging folder with exactly two PDFs was found. No upload attempted.'
}

Write-Host ''
Write-Host '=== TUNERTOOLS DOCUMENTS - UNICODE FIX ===' -ForegroundColor Cyan
Write-Host "Staging: $($stage.FullName)"
Write-Host 'Only these 2 local PDFs will be inspected and uploaded:' -ForegroundColor Yellow
Get-ChildItem -LiteralPath $stage.FullName -Recurse -File | ForEach-Object {
    Write-Host (' - ' + $_.FullName)
}

# Keep rollback copy of the original uploader; replace ONLY this Python file.
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = "$pythonTarget.before_unicode_fix_$stamp.bak"
Copy-Item -LiteralPath $pythonTarget -Destination $backup -Force
Copy-Item -LiteralPath $pythonFixed -Destination $pythonTarget -Force
Write-Host "Uploader patched; original backed up to: $backup" -ForegroundColor Green

# Run current existing PowerShell wrapper against the 2-file stage only.
& powershell.exe -NoProfile -ExecutionPolicy Bypass `
    -File $runner -SourceDir $stage.FullName -OutputDir $report
$exitCode = $LASTEXITCODE
if ($exitCode -ne 0) {
    throw "Two-file upload failed with code $exitCode. Check report: $report"
}
Write-Host 'TWO PDF FILES COMPLETED; previously uploaded 230 files untouched.' -ForegroundColor Green
$summary = Join-Path $report 'KET_QUA_UPLOAD_DOCUMENTS.txt'
if (Test-Path -LiteralPath $summary) { Get-Content -LiteralPath $summary }
