<?php
/**
 * TunerTools - Drive-first tutorials API (alwaysdata), PHP 7.4+.
 * Existing Android api_guides.php V2-compatible catalog.
 * Google Drive holds MP4/VTT/thumbnail/guide.json; alwaysdata is an authenticated
 * streaming proxy for the public tutorial content. No OAuth tokens reach clients.
 *
 * Routes:
 *   ?action=health
 *   ?action=catalog&category=all&lang=vi   (default action)
 *   ?action=video&id=songs/search
 *   ?action=subtitle&id=songs/search&lang=vi
 *   ?action=thumbnail&id=songs/search
 *   ?action=refresh&key=...  (ONLY if TUNERTOOLS_GUIDES_REFRESH_KEY env is set)
 *
 * IMPORTANT: Put this alongside existing api_gp_drive.php and reuse its token
 * via TUNERTOOLS_GP_TOKEN_PATH or local drive_token.json. Do not modify GP API.
 * Media bytes pass through alwaysdata, consuming bandwidth there (not on tunertools.top).
 */
declare(strict_types=1);

const TTG_API_PUBLIC = 'https://tuner.alwaysdata.net/api_guides_drive.php';
const TTG_ROOT_ID = '1AWw1lY-gKkoNBGk3b6v0JdRvafBeFsU6';
const TTG_FOLDER_MIME = 'application/vnd.google-apps.folder';
const TTG_CATEGORIES = ['songs', 'chords', 'tuner', 'metronome', 'training', 'documents', 'settings'];
const TTG_REQUIRED_CATEGORIES = ['songs', 'chords', 'tuner', 'metronome', 'training', 'settings'];
const TTG_LANGUAGES = ['vi', 'en', 'es', 'fr', 'de', 'ru', 'ja', 'zh', 'th', 'lo', 'km', 'ko', 'pt', 'sw', 'ar'];
const TTG_EXPECTED_LESSONS = 10;
const TTG_EXPECTED_FILES = 180;
const TTG_MAX_METADATA_BYTES = 65536;

header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex, nofollow');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
header('Access-Control-Allow-Headers: Range, Content-Type');
header('Access-Control-Expose-Headers: Accept-Ranges, Content-Range, Content-Length');

function ttgJson(int $status, array $data): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function ttgError(string $error, int $status = 503, array $more = []): void {
    ttgJson($status, array_merge(['ok' => false, 'error' => $error], $more));
}
function ttgLog(string $s): void { error_log('[TunerTools AppGuides] ' . $s); }
function ttgEnvPath(string $env, string $fallback): string {
    $v = getenv($env);
    return is_string($v) && trim($v) !== '' ? trim($v) : $fallback;
}
function ttgTokenPath(): string {
    return ttgEnvPath('TUNERTOOLS_GP_TOKEN_PATH', __DIR__ . '/drive_token.json');
}
function ttgCachePath(): string {
    return ttgEnvPath('TUNERTOOLS_GUIDES_CACHE_PATH', sys_get_temp_dir() . '/tt_guides_' . substr(hash('sha256', __FILE__), 0, 16) . '.json');
}
function ttgNormalizeLang(string $input): string {
    $root = preg_split('/[-_]/', strtolower(trim($input)))[0] ?? '';
    return in_array($root, TTG_LANGUAGES, true) ? $root : 'en';
}
function ttgSlug(string $str): bool {
    return preg_match('/^[a-z0-9][a-z0-9_-]{0,63}$/D', $str) === 1;
}
function ttgValidateLessonId(string $id): array {
    $parts = explode('/', $id);
    if (count($parts) !== 2 || !in_array($parts[0], TTG_CATEGORIES, true) || !ttgSlug($parts[1])) {
        ttgError('invalid_lesson_id', 400);
    }
    return $parts;
}
function ttgValidDriveId(string $id): bool {
    return preg_match('/^[A-Za-z0-9_-]{8,200}$/D', $id) === 1;
}

/** Same token JSON format as api_gp_drive.php. Refresh with a shared lock. */
function ttgReadToken(string $path): array {
    if (!is_file($path) || !is_readable($path)) ttgError('drive_token_not_found');
    $token = json_decode((string)@file_get_contents($path), true);
    if (!is_array($token)) ttgError('drive_token_invalid_json');
    return $token;
}
function ttgNeedsRefresh(array $t): bool {
    if (empty($t['token'])) return true;
    $expiry = trim((string)($t['expiry'] ?? ''));
    if ($expiry === '') return true;
    if (!preg_match('/(?:Z|[+-][0-9]{2}:[0-9]{2})$/i', $expiry)) $expiry .= 'Z';
    $time = strtotime($expiry);
    return $time === false || $time <= time() + 120;
}
function ttgRefreshToken(array $t): array {
    foreach (['refresh_token', 'client_id', 'client_secret'] as $field) {
        if (empty($t[$field])) ttgError('oauth_refresh_configuration_missing');
    }
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'client_id' => $t['client_id'],
            'client_secret' => $t['client_secret'],
            'refresh_token' => $t['refresh_token'],
            'grant_type' => 'refresh_token',
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $response = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno = curl_errno($ch);
    curl_close($ch);
    $data = is_string($response) ? json_decode($response, true) : null;
    if ($errno !== 0 || $status !== 200 || !is_array($data) || empty($data['access_token'])) {
        ttgLog('OAuth refresh failed: HTTP ' . $status . ', errno ' . $errno);
        ttgError('oauth_refresh_failed');
    }
    $t['token'] = (string)$data['access_token'];
    $t['expiry'] = gmdate('Y-m-d\TH:i:s\Z', time() + (int)($data['expires_in'] ?? 3600));
    return $t;
}
function ttgAccessToken(bool $force = false, string $rejected = ''): string {
    $path = ttgTokenPath();
    if (!$force) {
        $now = ttgReadToken($path);
        if (!ttgNeedsRefresh($now)) return (string)$now['token'];
    }
    // Reuse exact lock naming of GP API to prevent simultaneous refresh writes.
    $lockPath = sys_get_temp_dir() . '/tt_gp_token_' . hash('sha256', $path) . '.lock';
    $lock = @fopen($lockPath, 'c');
    if ($lock === false || !flock($lock, LOCK_EX)) ttgError('token_lock_failed');
    try {
        $t = ttgReadToken($path);
        $changed = $force && $rejected !== '' && (string)($t['token'] ?? '') !== $rejected;
        if (!$changed && ($force || ttgNeedsRefresh($t))) {
            $t = ttgRefreshToken($t);
            $tmp = $path . '.tmp.' . bin2hex(random_bytes(5));
            $json = json_encode($t, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
            if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) ttgError('token_write_failed');
            @chmod($tmp, 0600);
            if (!@rename($tmp, $path)) { @unlink($tmp); ttgError('token_write_failed'); }
        }
        $access = trim((string)($t['token'] ?? ''));
        if ($access === '') ttgError('token_empty');
        return $access;
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function ttgDriveJsonGet(string $url): array {
    if (!function_exists('curl_init')) ttgError('php_curl_missing');
    $token = ttgAccessToken();
    for ($attempt = 0; $attempt < 2; $attempt++) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'],
            CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 25,
            CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $raw = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno = curl_errno($ch);
        curl_close($ch);
        if ($status === 401 && $attempt === 0) {
            $token = ttgAccessToken(true, $token); continue;
        }
        if ($errno !== 0 || $status < 200 || $status >= 300) {
            ttgLog('Drive metadata failed: HTTP ' . $status . ', errno ' . $errno);
            ttgError('drive_metadata_failed', 502, ['google_http' => $status]);
        }
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($decoded)) ttgError('drive_invalid_json', 502);
        return $decoded;
    }
    ttgError('drive_authentication_failed');
}
function ttgDriveChildren(string $folderId): array {
    if (!ttgValidDriveId($folderId)) ttgError('invalid_drive_folder', 500);
    $result = []; $pageToken = ''; $pages = 0;
    do {
        $params = [
            'q' => "'" . $folderId . "' in parents and trashed = false",
            'fields' => 'nextPageToken,files(id,name,mimeType,size,modifiedTime,trashed)',
            'pageSize' => 1000,
            'spaces' => 'drive',
        ];
        if ($pageToken !== '') $params['pageToken'] = $pageToken;
        $data = ttgDriveJsonGet('https://www.googleapis.com/drive/v3/files?' .
            http_build_query($params, '', '&', PHP_QUERY_RFC3986));
        foreach ($data['files'] ?? [] as $f) {
            if (is_array($f) && isset($f['id'], $f['name'], $f['mimeType']) &&
                ttgValidDriveId((string)$f['id'])) $result[] = $f;
        }
        $pageToken = (string)($data['nextPageToken'] ?? '');
        if (++$pages > 5 || count($result) > 5000) ttgError('drive_folder_too_large');
    } while ($pageToken !== '');
    return $result;
}
function ttgOneNamed(array $items, string $name, bool $folder): ?array {
    $match = [];
    foreach ($items as $item) {
        if ((string)$item['name'] === $name &&
            (((string)$item['mimeType'] === TTG_FOLDER_MIME) === $folder)) $match[] = $item;
    }
    if (count($match) > 1) ttgError('ambiguous_drive_item', 503, ['name' => $name]);
    return $match[0] ?? null;
}
function ttgDriveText(string $fileId, int $maxBytes = TTG_MAX_METADATA_BYTES): string {
    if (!ttgValidDriveId($fileId)) ttgError('invalid_drive_file');
    $token = ttgAccessToken();
    $url = 'https://www.googleapis.com/drive/v3/files/' . rawurlencode($fileId) . '?alt=media';
    for ($attempt = 0; $attempt < 2; $attempt++) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
            CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        ]);
        $raw = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno = curl_errno($ch);
        curl_close($ch);
        if ($status === 401 && $attempt === 0) { $token = ttgAccessToken(true, $token); continue; }
        if ($errno || $status !== 200 || !is_string($raw) || strlen($raw) > $maxBytes) {
            ttgError('drive_guide_json_read_failed', 502, ['google_http' => $status]);
        }
        return $raw;
    }
    ttgError('drive_guide_json_read_failed', 502);
}
function ttgFileRef(array $item): array {
    return [
        'id' => (string)$item['id'],
        'size' => (int)($item['size'] ?? 0),
        'modified' => (string)($item['modifiedTime'] ?? ''),
    ];
}

/** Enumerate Drive once on cold cache, then reuse IDs until authorized refresh. */
function ttgBuildManifest(): array {
    $info = ttgDriveJsonGet('https://www.googleapis.com/drive/v3/files/' . rawurlencode(TTG_ROOT_ID) . '?' .
        http_build_query(['fields' => 'id,name,mimeType,trashed', 'supportsAllDrives' => 'true'], '', '&', PHP_QUERY_RFC3986));
    if (($info['name'] ?? '') !== 'app-guides' || ($info['mimeType'] ?? '') !== TTG_FOLDER_MIME ||
        !empty($info['trashed'])) ttgError('unexpected_drive_root', 503);
    $root = ttgDriveChildren(TTG_ROOT_ID);
    $lessons = []; $fileCount = 0; $warnings = [];
    foreach (TTG_CATEGORIES as $category) {
        $cat = ttgOneNamed($root, $category, true);
        if ($cat === null) {
            if (in_array($category, TTG_REQUIRED_CATEGORIES, true)) $warnings[] = 'missing_category:' . $category;
            continue;
        }
        foreach (ttgDriveChildren((string)$cat['id']) as $lessonFolder) {
            if ((string)$lessonFolder['mimeType'] !== TTG_FOLDER_MIME || !ttgSlug((string)$lessonFolder['name'])) continue;
            $slug = (string)$lessonFolder['name'];
            $id = $category . '/' . $slug;
            $files = ttgDriveChildren((string)$lessonFolder['id']);
            $videoFolder = ttgOneNamed($files, 'videos', true);
            $subtitleFolder = ttgOneNamed($files, 'subtitles', true);
            $video = $videoFolder === null ? null : ttgOneNamed(ttgDriveChildren((string)$videoFolder['id']), 'video.mp4', false);
            $subtitleFiles = $subtitleFolder === null ? [] : ttgDriveChildren((string)$subtitleFolder['id']);
            $subs = [];
            foreach (TTG_LANGUAGES as $lang) {
                $subFile = ttgOneNamed($subtitleFiles, $lang . '.vtt', false);
                if ($subFile !== null && (int)($subFile['size'] ?? 0) > 0) $subs[$lang] = ttgFileRef($subFile);
            }
            $jsonFile = ttgOneNamed($files, 'guide.json', false);
            $thumb = null; $thumbExt = '';
            foreach (['jpg', 'png', 'webp'] as $ext) {
                $f = ttgOneNamed($files, 'thumbnail.' . $ext, false);
                if ($f !== null) { $thumb = ttgFileRef($f); $thumbExt = $ext; break; }
            }
            $meta = [];
            if ($jsonFile !== null) {
                $raw = ttgDriveText((string)$jsonFile['id']);
                $parsed = json_decode($raw, true);
                if (is_array($parsed)) $meta = $parsed;
            }
            if ($video === null || (int)($video['size'] ?? 0) < 1 || count($subs) !== 15 ||
                $jsonFile === null || $thumb === null) {
                $warnings[] = 'incomplete_lesson:' . $id;
                continue;
            }
            $fileCount += 1 + count($subs) + 1 + 1;
            $lessons[$id] = [
                'id' => $id,
                'category' => $category,
                'slug' => $slug,
                'order' => is_numeric($meta['order'] ?? null) ? (int)$meta['order'] : 1000,
                'audio_language' => ttgNormalizeLang((string)($meta['audio_language'] ?? 'vi')),
                'titles' => is_array($meta['titles'] ?? null) ? $meta['titles'] : [],
                'descriptions' => is_array($meta['descriptions'] ?? null) ? $meta['descriptions'] : [],
                'video' => ttgFileRef($video),
                'subtitles' => $subs,
                'thumbnail' => $thumb,
                'thumbnail_ext' => $thumbExt,
            ];
        }
    }
    $complete = count($lessons) === TTG_EXPECTED_LESSONS && $fileCount === TTG_EXPECTED_FILES && empty($warnings);
    if (!$complete) ttgError('backup_incomplete', 503, [
        'lessons_complete' => count($lessons), 'files_complete' => $fileCount,
        'expected_lessons' => TTG_EXPECTED_LESSONS, 'expected_files' => TTG_EXPECTED_FILES,
        'warnings' => $warnings,
    ]);
    return ['version' => 1, 'built_at' => time(), 'complete' => true,
        'root_id' => TTG_ROOT_ID, 'files' => $fileCount, 'lessons' => $lessons];
}
function ttgReadCache(string $path): ?array {
    if (!is_file($path) || !is_readable($path)) return null;
    $raw = @file_get_contents($path);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($decoded) || ($decoded['version'] ?? 0) !== 1 ||
        empty($decoded['complete']) || ($decoded['root_id'] ?? '') !== TTG_ROOT_ID ||
        !is_array($decoded['lessons'] ?? null)) return null;
    return $decoded;
}
function ttgManifest(bool $force = false): array {
    $path = ttgCachePath();
    $cached = ttgReadCache($path);
    if (!$force && $cached !== null) return $cached;
    $lock = @fopen($path . '.lock', 'c');
    if ($lock === false || !flock($lock, LOCK_EX)) {
        if ($cached !== null) return $cached;
        ttgError('manifest_lock_failed');
    }
    try {
        $newCached = ttgReadCache($path);
        if (!$force && $newCached !== null) return $newCached;
        // Cold cache needs a complete Drive enumeration. Subsequent requests use
        // cached IDs; refresh is manual to avoid intermittent Drive scans.
        $built = ttgBuildManifest();
        $json = json_encode($built, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($json)) ttgError('manifest_encode_failed');
        $tmp = $path . '.tmp.' . bin2hex(random_bytes(5));
        if (@file_put_contents($tmp, $json, LOCK_EX) === false || !@rename($tmp, $path)) {
            @unlink($tmp);
            if ($newCached !== null) return $newCached;
            ttgError('manifest_write_failed');
        }
        @chmod($path, 0600);
        return $built;
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}
function ttgLocalizedText(array $translations, string $lang, string $fallback): string {
    foreach (array_unique([$lang, 'en', 'vi']) as $code) {
        if (isset($translations[$code]) && is_string($translations[$code]) && trim($translations[$code]) !== '') {
            return substr(trim($translations[$code]), 0, 400);
        }
    }
    return $fallback;
}
function ttgAssetUrl(string $type, string $id, string $lang, array $file): string {
    $params = ['action' => $type, 'id' => $id];
    if ($type === 'subtitle') $params['lang'] = $lang;
    $params['v'] = substr(hash('sha256', $file['id'] . ':' . $file['modified'] . ':' . $file['size']), 0, 12);
    return TTG_API_PUBLIC . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
}
function ttgLesson(array $manifest, string $id): array {
    ttgValidateLessonId($id);
    if (!isset($manifest['lessons'][$id]) || !is_array($manifest['lessons'][$id])) ttgError('lesson_not_found', 404);
    return $manifest['lessons'][$id];
}
function ttgMediaHeaders(int $status, string $mime, array $headers, string $fileName): void {
    http_response_code($status);
    header('Content-Type: ' . $mime);
    header('Cache-Control: private, max-age=86400');
    header('Accept-Ranges: bytes');
    header('X-Accel-Buffering: no');
    // ASCII-only filename prevents response splitting.
    $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName) ?: 'asset';
    header('Content-Disposition: inline; filename="' . $safe . '"');
    if (isset($headers['content-length']) && ctype_digit((string)$headers['content-length'])) {
        header('Content-Length: ' . $headers['content-length']);
    }
    if (isset($headers['content-range']) &&
        preg_match('/^bytes [0-9]+-[0-9]+\/[0-9*]+$/i', (string)$headers['content-range'])) {
        header('Content-Range: ' . $headers['content-range']);
    }
}
function ttgMediaAttempt(string $fileId, string $token, string $mime, string $fileName, ?string $range): array {
    $code = 0; $headers = []; $error = ''; $sent = false; $bytes = 0;
    $h = ['Authorization: Bearer ' . $token, 'Accept: ' . $mime];
    if ($range !== null) $h[] = 'Range: ' . $range;
    $ch = curl_init('https://www.googleapis.com/drive/v3/files/' . rawurlencode($fileId) . '?alt=media');
    curl_setopt_array($ch, [
        CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 4,
        CURLOPT_HTTPHEADER => $h, CURLOPT_CONNECTTIMEOUT => 9, CURLOPT_TIMEOUT => 180,
        CURLOPT_RETURNTRANSFER => false, CURLOPT_BUFFERSIZE => 65536,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HEADERFUNCTION => static function ($handle, string $line) use (&$code, &$headers): int {
            $len = strlen($line);
            if (preg_match('/^HTTP\/[0-9.]+\s+([0-9]{3})/i', trim($line), $m)) {
                $code = (int)$m[1]; $headers = [];
            } elseif (strpos($line, ':') !== false) {
                [$k, $v] = explode(':', $line, 2);
                $k = strtolower(trim($k));
                if (in_array($k, ['content-length', 'content-range', 'retry-after'], true)) $headers[$k] = trim($v);
            }
            return $len;
        },
        CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use (&$code, &$headers, &$error, &$sent, &$bytes, $mime, $fileName, $range): int {
            $size = strlen($chunk);
            $rangeNotHonored = $range !== null && $code === 200 && $range !== 'bytes=0-';
            // Stop immediately if Google ignores a seek. Do not waste bandwidth
            // downloading a whole video only to return a Range error.
            if ($rangeNotHonored) return 0;
            if ($code === 200 || $code === 206) {
                if (!$sent) { ttgMediaHeaders($code, $mime, $headers, $fileName); $sent = true; }
                echo $chunk;
                $bytes += $size;
                if ($bytes % 262144 < $size) @flush();
                return connection_aborted() ? 0 : $size;
            }
            if (strlen($error) < 32768) $error .= substr($chunk, 0, 32768 - strlen($error));
            return $size;
        },
    ]);
    $ok = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno = curl_errno($ch);
    curl_close($ch);
    return ['status' => $status, 'errno' => $errno, 'ok' => $ok !== false,
        'sent' => $sent, 'bytes' => $bytes, 'headers' => $headers,
        'range_ignored' => $range !== null && $status === 200 && $range !== 'bytes=0-'];
}
function ttgStream(array $file, string $mime, string $filename): void {
    if (empty($file['id']) || !ttgValidDriveId((string)$file['id'])) ttgError('asset_not_found', 404);
    $range = null;
    if (isset($_SERVER['HTTP_RANGE'])) {
        $range = trim((string)$_SERVER['HTTP_RANGE']);
        if (!preg_match('/^bytes=([0-9]*)-([0-9]*)$/D', $range, $m) || ($m[1] === '' && $m[2] === '')) {
            ttgError('invalid_range', 416);
        }
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') {
        http_response_code(200);
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (int)($file['size'] ?? 0));
        header('Accept-Ranges: bytes');
        header('Cache-Control: private, max-age=86400');
        exit;
    }
    @ini_set('zlib.output_compression', '0');
    @set_time_limit(0);
    while (ob_get_level() > 0) @ob_end_clean();
    $token = ttgAccessToken(); $refreshed = false;
    for ($attempt = 0; $attempt < 3; $attempt++) {
        $result = ttgMediaAttempt((string)$file['id'], $token, $mime, $filename, $range);
        if ($result['sent']) {
            if (!$result['ok']) ttgLog('Media interrupted: HTTP ' . $result['status']);
            exit; // Never retry after sending media bytes.
        }
        if ($result['ok'] && in_array($result['status'], [200, 206], true) && !$result['range_ignored']) {
            ttgMediaHeaders($result['status'], $mime, $result['headers'], $filename);
            exit;
        }
        if ($result['status'] === 401 && !$refreshed) {
            $token = ttgAccessToken(true, $token); $refreshed = true; continue;
        }
        if (in_array($result['status'], [429, 500, 502, 503, 504], true) && $attempt < 2) {
            usleep(300000 * ($attempt + 1)); continue;
        }
        ttgLog('Media failed: HTTP ' . $result['status'] . ', errno ' . $result['errno']);
        if ($result['range_ignored']) ttgError('upstream_did_not_honor_range', 502);
        ttgError('drive_media_failed', 502, ['google_http' => $result['status']]);
    }
    ttgError('drive_media_failed', 502);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }
if (!in_array($method, ['GET', 'HEAD'], true)) ttgError('method_not_allowed', 405);
$action = strtolower(trim((string)($_GET['action'] ?? 'catalog')));
if ($action === 'health') {
    $cache = ttgReadCache(ttgCachePath());
    ttgJson(200, ['ok' => true, 'service' => 'tunertools_guides_drive_primary',
        'drive_root_id' => TTG_ROOT_ID, 'manifest_ready' => $cache !== null,
        'manifest_age_seconds' => $cache === null ? null : time() - (int)$cache['built_at'],
        'cached_lessons' => $cache === null ? 0 : count($cache['lessons'])]);
}
if ($action === 'refresh') {
    $key = (string)(getenv('TUNERTOOLS_GUIDES_REFRESH_KEY') ?: '');
    $provided = (string)($_GET['key'] ?? '');
    if ($key === '' || $provided === '' || !hash_equals($key, $provided)) ttgError('refresh_not_available', 403);
    $built = ttgManifest(true);
    ttgJson(200, ['ok' => true, 'complete' => true, 'files' => $built['files'], 'lessons' => count($built['lessons'])]);
}
if (!in_array($action, ['catalog', 'video', 'subtitle', 'thumbnail'], true)) ttgError('unknown_action', 400);
$manifest = ttgManifest();
if ($action === 'catalog') {
    $lang = ttgNormalizeLang((string)($_GET['lang'] ?? 'en'));
    $category = strtolower(trim((string)($_GET['category'] ?? 'all')));
    if ($category !== 'all' && !in_array($category, TTG_CATEGORIES, true)) ttgError('unknown_category', 400);
    $output = [];
    foreach ($manifest['lessons'] as $item) {
        if ($category !== 'all' && $item['category'] !== $category) continue;
        $subLang = null;
        foreach (array_unique([$lang, $item['audio_language'], 'en', 'vi']) as $candidate) {
            if (isset($item['subtitles'][$candidate])) { $subLang = $candidate; break; }
        }
        $output[] = [
            'id' => $item['id'], 'category' => $item['category'], 'order' => $item['order'],
            'title' => ttgLocalizedText($item['titles'], $lang, ucwords(str_replace(['_', '-'], ' ', $item['slug']))),
            'description' => ttgLocalizedText($item['descriptions'], $lang, ''),
            'audio_language' => $item['audio_language'],
            'video_url' => ttgAssetUrl('video', $item['id'], '', $item['video']),
            'subtitle_language' => $subLang,
            'subtitle_url' => $subLang === null ? null : ttgAssetUrl('subtitle', $item['id'], $subLang, $item['subtitles'][$subLang]),
            'subtitle_fallback' => $subLang !== null && $subLang !== $lang,
            'available_subtitle_languages' => array_keys($item['subtitles']),
            'thumbnail_url' => ttgAssetUrl('thumbnail', $item['id'], '', $item['thumbnail']),
        ];
    }
    $rank = array_flip(TTG_CATEGORIES);
    usort($output, static function (array $a, array $b) use ($rank): int {
        return ($rank[$a['category']] <=> $rank[$b['category']]) ?:
            ($a['order'] <=> $b['order']) ?: strcmp($a['id'], $b['id']);
    });
    header('Cache-Control: public, max-age=180');
    http_response_code(200);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['api_version' => 2, 'language' => $lang, 'category' => $category,
        'total' => count($output), 'guides' => $output],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
$id = (string)($_GET['id'] ?? '');
$item = ttgLesson($manifest, $id);
if ($action === 'video') ttgStream($item['video'], 'video/mp4', 'video.mp4');
if ($action === 'subtitle') {
    $lang = ttgNormalizeLang((string)($_GET['lang'] ?? 'en'));
    if (!isset($item['subtitles'][$lang])) ttgError('subtitle_not_found', 404);
    ttgStream($item['subtitles'][$lang], 'text/vtt; charset=utf-8', $lang . '.vtt');
}
if ($action === 'thumbnail') {
    $ext = $item['thumbnail_ext'];
    $mime = $ext === 'png' ? 'image/png' : ($ext === 'webp' ? 'image/webp' : 'image/jpeg');
    ttgStream($item['thumbnail'], $mime, 'thumbnail.' . $ext);
}
