# Generate local random secrets. Never send output to ChatGPT or share Drive.
$ErrorActionPreference = 'Stop'
function New-Secret {
    $bytes = New-Object byte[] 48
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return [Convert]::ToBase64String($bytes)
}
Write-Host 'Store these values only in your private server environment settings.'
Write-Host 'DO NOT send them in a message or upload them to Drive.'
Write-Host ''
Write-Host ('TUNERTOOLS_DOCUMENT_SESSION_SECRET=' + (New-Secret))
Write-Host ('TUNERTOOLS_DOCUMENT_SYNC_SHARED_SECRET=' + (New-Secret))
