TUNERTOOLS - DOCUMENTS DRIVE LA NGUON CHINH - 2026-11-08
====================================================

PHAM VI
- Nguon doc mac dinh: Android -> Alwaysdata api_documents_drive.php -> Google Drive.
- Quyen doc: Alwaysdata xac minh Google ID token, tao phien rieng; sau do doc
  JSON quyen RIENG TU tai Drive. Doc thu muc, PDF, anh, video KHONG can IIS.
- Admin: danh sach quyen mac dinh lay tu JSON tren Drive. Khi IIS offline,
  UI chi doc, khong cho cap/sua/xoa.
- Admin cap/sua/xoa khi IIS online: Android -> IIS -> MySQL -> HTTPS/HMAC
  day snapshot moi sang Alwaysdata -> CAP NHAT CHINH FILE JSON CU.
- SongTab 30 ngay: neu Gmail moi chua co tren Drive, IIS giu trach nhiem
  cap trial; KHONG tu cap trial o Alwaysdata.
- Khong can chay V3/V4 cu, khong tao file JSON moi.

FILE JSON DA CO, KHONG TAO LAI:
  My Drive/TunerTools_AppBackup/config/document_permissions.json
  File ID: 1DiaYfIb880t_K_iAilPh5aKbJYi69Uvf

FILE TRONG GOI
- PHP_Alwaysdata/api_documents_drive.php: full PHP thay cho Alwaysdata.
- Android/Gamefolder.kt: Google Sign-In ID token, Drive login mac dinh,
  IIS fallback, Drive API cho thu muc/media, ghi quyen Admin qua IIS.
- Android/admin.kt: doc danh sach tu Drive, online/offline va nut dong bo.
- IIS_Patch/PATCH_API_DOCUMENTS.py: va TRUC TIEP vao file PHP dang chay.
- IIS_Patch/iis_helpers.php.fragment: ham PHP cho patch. KHONG upload
  fragment nay ra public web server.
- 01_TAO_KHOA_BAO_MAT.ps1: chay local de tao 2 khoa bi mat.
- 02_KIEM_TRA_ALWAYS_DATA.ps1: kiem tra Drive root + quyen + OAuth.

CO 3 CAU HINH BAT BUOC (KHONG GHI TRONG ANDROID)
1) TUNERTOOLS_DOCUMENTS_WEB_CLIENT_ID
   Gia tri: Google OAuth 2.0 Web application client ID (ket thuc bang
   .apps.googleusercontent.com). GIA TRI GIUNG NHAU o IIS va Alwaysdata.
   Lay tu google-services.json (oauth_client.client_type = 3) cua app,
   hoac default_web_client_id tu Google Services Gradle plugin. KHONG lay
   Android OAuth client ID. Khong tu tao/bia client ID trong PHP.
2) TUNERTOOLS_DOCUMENT_SESSION_SECRET
   Chi can o Alwaysdata. Chuoi ngau nhien >=48 ky tu.
3) TUNERTOOLS_DOCUMENT_SYNC_SHARED_SECRET
   CUNG MOT CHUOI ngau nhien >=48 ky tu o IIS va Alwaysdata.
   Chi IIS duoc goi endpoint permissions_sync va phai ky HMAC.
Google Drive OAuth token co san tren Alwaysdata: dung TUNERTOOLS_GP_TOKEN_PATH
hoac drive_token.json giong API GP cu. KHONG day token vao Android.
TUNERTOOLS_DOCUMENT_PERMISSIONS_FILE_ID (tuy chon): neu bo qua thi dung
FILE ID cu phia tren, tuyet doi khong tao moi.

THU TU TRIỂN KHAI AN TOAN
A. SAO LUU api_documents_drive.php dang chay tren Alwaysdata (vao vi tri rieng
   tu ngoai webroot); sao luu 2 Kotlin hien tai.
B. Xac dinh OAuth Web client ID. Kiem tra app co res/values
   default_web_client_id (Google Services auto-generated). Neu KHONG co,
   tao res/values/tt_documents_oauth.xml trong du an Android:

   <?xml version="1.0" encoding="utf-8"?>
   <resources>
      <string name="tt_documents_web_client_id">YOUR_ACTUAL_WEB_CLIENT_ID.apps.googleusercontent.com</string>
   </resources>

   Thay bang Web client ID THUC TE, khong de gia tri mau.
C. Chay 01_TAO_KHOA_BAO_MAT.ps1 tren Windows, KHONG GUI KHOA LEN CHAT.
   Thiet lap 3 environment variables o Alwaysdata; 2 bien WEB_CLIENT_ID va
   SYNC_SHARED_SECRET o IIS. Phai cau hinh trong moi truong PHP/FastCGI,
   KHONG chi set trong mot PowerShell window; restart PHP pool/IIS App Pool
   de bien moi co hieu luc.
D. Upload PHP_Alwaysdata/api_documents_drive.php len Alwaysdata, cung thu
   muc voi api_gp_drive.php. File Drive token phai giu private.
E. KIEM TRA https://tuner.alwaysdata.net/api_documents_drive.php?action=health:
   drive_root_ready=true, permissions_ready=true, oauth_ready=true.
   permission_users=93 (truoc khi co thay doi quyen).
F. XU LY IIS: tren Windows Server, copy thu muc IIS_Patch ra
   C:\TunerTools\Tools\Documents_DrivePrimary\. Trong PowerShell Admin:

   cd C:\TunerTools\Tools\Documents_DrivePrimary
   python .\PATCH_API_DOCUMENTS.py --source "C:\TunerTools\Web\API\api_documents.php" --install

   Cong cu backup PHP goc ra C:\TunerTools\Backups\Documents\ (KHONG
   backup trong webroot), giam quyen Windows chi Administrators+SYSTEM,
   kiem tra php -l truoc khi thay file. Neu PHP CLI khong co trong PATH,
   them PHP vao PATH truoc khi chay.
G. Android Studio: thay DUNG 2 file goc bang Android/Gamefolder.kt va
   Android/admin.kt. Giu package/import/Gradle project hien co. Build va
   thu dung tai khoan Google da cap quyen.
H. Lan dau tien tai Admin > Quyen tai lieu, nhan 'Dong bo quyen len Drive'
   MOT LAN de bo sung access_type=trial/permanent, note, created_by vao
   CHINH JSON CU. Day la cap nhat noi dung file cu, KHONG tao file khac.
   Vi snapshot ban dau chua co access_type, Alwaysdata se tam thoi xem
   tai khoan co ngay het han (nhung khong can_manage) la trial, tranh
   lo cap nham Documents. Hien tuong nay het sau khi bo sung du lieu.
I. Them quyen moi tu Admin. Phan hoi can co drive_sync_status='synced',
   sau do reload danh sach Drive. Neu 'drive_sync_pending': MySQL DA LUU,
   Drive CHUA XAC NHAN. Admin nhan 'Dong bo quyen len Drive' de thu lai.
J. Dung IIS thu nghiem (van giu Alwaysdata+Google Drive hoat dong). Dang
   nhap lai bang Google, mo Guitar/Ukulele/Piano, thu xem/tai tai lieu;
   Admin van xem duoc danh sach Drive, khong the cap/xoa khi IIS offline.

QUAN TRONG
- Alwaysdata khong doc MySQL truc tiep; JSON duoc kiem tra lai toi da
  sau 20 giay. Quyền thu hoi co the tre den 20 giay do cache.
- File JSON KHONG duoc share/public. Khong gui Gmail roster, oauth token
  va cac khoa bi mat len chat/email.
- IIS la nguon ghi duy nhat cua cap quyen; IIS offline thi khong cap/xoa.
- Thao tac ghi tai lieu cong khai truc tiep (upload, rename, delete file)
  tiep tuc khoa de tranh ghi 1 phia khong duoc dong bo len Drive.
- Ban Android cu dang dung IIS session van chay nhu truoc neu IIS online.
  Cong doan legacy co nguy co do dang nhap email-only cua IIS cu; sau khi
  phat han app moi cho nguoi dung, can chuyen sang token bat buoc de loai bo.
  Ban API IIS sua da BAT BUOC ID token cho Admin cap/xoa/xem danh sach quyen.
- Phien IIS cu/Android cu KHONG duoc cam ket truy cap khi IIS chet. Chi
  Android moi co phien Drive TTDS1 + Google OAuth hop le moi doc doc lap IIS.
- Neu Google Drive hoac Alwaysdata offline, co the fallback IIS neu server con.
- Khi dong bo Drive hong, PHP KHONG khai bao thanh cong Drive; Admin xem
  thong bao pending va thu dong bo lai. Chua co hang doi retry tu dong.
- Ha tang thuc te va Gradle SDK cua app khong co trong moi truong kiem tra,
  nen can build/test tren Android Studio va kiem tra endpoint tren server.

ROLLBACK
1) IIS: dung App Pool, copy file backup moi nhat tu
   C:\TunerTools\Backups\Documents\api_documents.php.backup_DrivePrimary_*.bak
   de C:\TunerTools\Web\API\api_documents.php; start App Pool.
2) Alwaysdata: copy lai api_documents_drive.php backup cua ban.
3) Android: thay lai 2 Kotlin goc, build lai neu can.
4) KHONG xoa, khong cong khai document_permissions.json; rollback code
   khong doi ID Drive da co.

TESTS THUC HIEN
- php -l Alwaysdata PHP: OK.
- php -l IIS PHP da patch: OK.
- Local mock: manager, folder-scope, download denied, SongTab trial,
  expired, Google sub mismatch: OK.
- Kotlin compiler khong co Android/Compose/Google Play Services classpath;
  kiem tra parse khong phat hien loi cu phap; CHUA XAC NHAN build Android.
- Chua the kiem tra API/IIS/MySQL/Drive tren moi truong production.
