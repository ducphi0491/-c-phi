$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$u='https://tuner.alwaysdata.net/api_documents_drive.php?action=health'
try {
    $h=Invoke-RestMethod -Uri $u -TimeoutSec 25 -Method Get
    Write-Host ('DRIVE_ROOT_READY=' + $h.drive_root_ready)
    Write-Host ('PERMISSIONS_READY=' + $h.permissions_ready)
    Write-Host ('OAUTH_READY=' + $h.oauth_ready)
    Write-Host ('PERMISSION_ACCOUNTS=' + $h.permission_users)
    if ($h.drive_root_ready -and $h.permissions_ready -and $h.oauth_ready) {
        Write-Host 'DRIVE_PRIMARY_READY'
    } else { Write-Host 'NOT_READY: check PHP version and server environment variables'; exit 2 }
} catch {
    Write-Host 'HEALTH_FAILED (check Alwaysdata log / OAuth / Drive token).'
    exit 1
}
