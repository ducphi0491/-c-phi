# TunerTools - IIS HTTP 50x diagnostics (read-only)
# Run on the Windows/IIS server in Windows PowerShell 5.1+.
# Does not update MySQL, change PHP, or contact GitHub.
param(
    [int]$Hours = 48,
    [string]$IISLogRoot = "$env:SystemDrive\inetpub\logs\LogFiles",
    [string]$OutputFolder = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
$minimumUtc = (Get-Date).ToUniversalTime().AddHours(-1 * [Math]::Abs($Hours))
if (-not (Test-Path -LiteralPath $IISLogRoot)) {
    Write-Host "IIS log directory not found: $IISLogRoot" -ForegroundColor Yellow
    Write-Host 'Specify -IISLogRoot with the actual IIS log directory.'
    exit 2
}
if (-not $OutputFolder) { $OutputFolder = (Get-Location).Path }
if (-not (Test-Path -LiteralPath $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$records = New-Object System.Collections.Generic.List[object]
$files = @(Get-ChildItem -LiteralPath $IISLogRoot -Recurse -File -Filter '*.log' -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTimeUtc -ge $minimumUtc.AddHours(-6) } |
    Sort-Object LastWriteTimeUtc -Descending |
    Select-Object -First 60)

foreach ($file in $files) {
    try {
        $headers = @(Get-Content -LiteralPath $file.FullName -TotalCount 40 -ErrorAction Stop |
            Where-Object { $_ -like '#Fields:*' })
        if ($headers.Count -eq 0) { continue }
        $fields = @($headers[$headers.Count - 1].Substring(8).Trim() -split '\s+')
        $lookup = @{}
        for ($i = 0; $i -lt $fields.Count; $i++) { $lookup[$fields[$i]] = $i }
        if (-not $lookup.ContainsKey('cs-uri-stem')) { continue }
        if (-not $lookup.ContainsKey('cs-uri-query')) { continue }
        if (-not $lookup.ContainsKey('date') -or -not $lookup.ContainsKey('time')) { continue }

        $maxTail = 30000
        foreach ($line in (Get-Content -LiteralPath $file.FullName -Tail $maxTail -ErrorAction Stop)) {
            if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) { continue }
            if ($line -notmatch 'api_songs\.php') { continue }
            if ($line -notmatch 'action=update(?:&|\s|$)') { continue }
            $columns = @($line -split '\s+')
            if ($columns.Count -lt $fields.Count) { continue }
            $stampText = $columns[$lookup['date']] + ' ' + $columns[$lookup['time']]
            $stampUtc = [datetime]::MinValue
            if (-not [datetime]::TryParse($stampText, [ref]$stampUtc)) { continue }
            # IIS W3C log dates are UTC.
            $stampUtc = [datetime]::SpecifyKind($stampUtc, [DateTimeKind]::Utc)
            if ($stampUtc -lt $minimumUtc) { continue }

            $status = if ($lookup.ContainsKey('sc-status')) { $columns[$lookup['sc-status']] } else { 'n/a' }
            $subStatus = if ($lookup.ContainsKey('sc-substatus')) { $columns[$lookup['sc-substatus']] } else { 'n/a' }
            $win32 = if ($lookup.ContainsKey('sc-win32-status')) { $columns[$lookup['sc-win32-status']] } else { 'n/a' }
            $elapsed = if ($lookup.ContainsKey('time-taken')) { $columns[$lookup['time-taken']] } else { 'n/a' }
            $method = if ($lookup.ContainsKey('cs-method')) { $columns[$lookup['cs-method']] } else { 'n/a' }
            $records.Add([pscustomobject]@{
                TimeLocal = $stampUtc.ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss')
                Method = $method
                HttpStatus = $status
                SubStatus = $subStatus
                Win32Status = $win32
                TimeTakenMs = $elapsed
                LogFile = $file.FullName
            }) | Out-Null
        }
    } catch {
        Write-Warning ('Cannot read ' + $file.FullName + ': ' + $_.Exception.Message)
    }
}

$selected = @($records | Sort-Object TimeLocal -Descending | Select-Object -First 30)
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$output = Join-Path $OutputFolder "TunerTools_HTTP50x_IIS_$stamp.txt"
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add('TunerTools sheet update - IIS request diagnostics')
$lines.Add('Generated local time: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
$lines.Add('Time window: last ' + $Hours + ' hours')
$lines.Add('IIS logs scanned: ' + $files.Count)
$lines.Add('Matching action=update requests: ' + $records.Count)
$lines.Add('')
if ($selected.Count -eq 0) {
    $lines.Add('NO MATCH: Check whether IIS logs are enabled and whether this is the correct IIS site/log path.')
} else {
    $lines.Add('TimeLocal | Method | HTTP | Substatus | Win32 | TimeTakenMs | File')
    foreach ($record in $selected) {
        $lines.Add(('{0} | {1} | {2} | {3} | {4} | {5} | {6}' -f
            $record.TimeLocal, $record.Method, $record.HttpStatus, $record.SubStatus,
            $record.Win32Status, $record.TimeTakenMs, $record.LogFile))
    }
}
$lines.Add('')
$lines.Add('No PHP/MySQL password, GitHub token, query parameters, or image data is collected.')
$lines | Set-Content -LiteralPath $output -Encoding UTF8
$lines | ForEach-Object { Write-Host $_ }
Write-Host "`nSaved to: $output" -ForegroundColor Green
