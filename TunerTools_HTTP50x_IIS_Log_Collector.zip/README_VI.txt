TUNERTOOLS - CHAN DOAN HTTP 50x KHI LUU SHEET

1) Chay file Check_TunerTools_IIS_Update_HTTP50x.ps1 tren MAY CHU WINDOWS co IIS, khong chay tren may Android Studio neu khong co IIS.
2) Mo Windows PowerShell (Run as administrator neu can quyen doc IIS log).
3) Di chuyen den thu muc chua script, chay:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Check_TunerTools_IIS_Update_HTTP50x.ps1
4) Script chi doc log IIS, loc cac request api_songs.php?action=update trong 48 gio gan nhat.
5) Gui lai file TunerTools_HTTP50x_IIS_*.txt ma script tao trong cung thu muc.

Neu log IIS nam o duong dan khac, chay:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Check_TunerTools_IIS_Update_HTTP50x.ps1 -IISLogRoot "D:\IISLogs" -Hours 72

DONG THOI tren Android Studio -> Logcat, tim tag:SongScraper,
copy dong "Song update is not JSON: HTTP=...".

Khi phan tich:
- HTTP 500.0 + TimeTakenMs lon => nghi FastCGI/process timeout; can xem log PHP/IIS.
- HTTP 502.x => nghi gateway/upstream/timeout; can xem IIS URL Rewrite/ARR/FastCGI.
- 50x + TimeTakenMs nho => nghi loi PHP/runtime hay proxy tu choi truoc khi xu ly.
- Logcat php=responsefix-20261104 => request da den ban PHP co header chan doan.
- Logcat php=unknown => PHP khong chay den action=update hoac header bi IIS/proxy loc.

LUU Y: Chi mot dong "HTTP 50..." tren Toast bi cat khong du de xac dinh 500 hay 502.
Khong sua SQL tiep khi chua co log.
Script khong thay doi MySQL, PHP, app, GitHub va khong doc token.
