# Tunertools — V4: Tu dong hien anh bia bai hat

## Tinh nang
- Tu dong tim anh bia bai hat theo ten bai hat va nghe si cho nhac Google Drive cong khai, Google Drive ca nhan (SAF), va nhac trong may.
- Xu ly ten file co STT dau dong va du hai kieu dat ten: ARTIST - SONG hay SONG - ARTIST.
- Uu tien anh album nhung san trong file audio neu file dang co trong cache. Neu chua co, tra cuu Apple/iTunes Search API, du phong Deezer, chi nhan anh khi diem khop dat nguong.
- Anh bia hien ca tai khung dang phat va thumbnail trong danh sach nhac. Tu dong tim khi bai hien tren man hinh (lazy), toi da 2 luot tim song song, khong quet anh cho ca folder hang nghin file.
- Ghi nho anh theo ID + ten bai + nghe si; su dung lai khi vao playlist cu. Neu nguoi dung sua ten bai, anh se duoc tim lai theo ten moi.
- Khi khong tim duoc anh, hien logo not nhac mac dinh. Mang cham/khong co album art khong anh huong den phat nhac Google Drive.

## Ba file can copy
1. `app/src/main/java/duc_phi/music/MainActivity.kt` — DA SUA tinh nang album art.
2. `app/src/main/java/duc_phi/music/PublicDriveBrowser.kt` — GIU NGUYEN nhu V3, dam bao phat Drive cong khai dang hoat dong.
3. `app/src/main/res/values/public_drive_api_key.xml` — GIU NGUYEN API key trong bo V3 da duoc cau hinh.

Ban co the chi thay file **MainActivity.kt** neu 2 file con lai cua V3 dang phat nhac tot. Vi tri package la `duc_phi.music`, theo source V3.

## Cach kiem tra
1. Backup ban V3 dang chay tot.
2. Copy `MainActivity.kt` V4 vao du an. Neu chua co 2 file khac, copy ca 3 file theo thu muc.
3. Sync Gradle, Rebuild Project.
4. Mo Google Drive cong khai, chon bai `05. Kate Bush - Babooshka.flac`; giao dien se tu tim anh bia.
5. Chuyen sang bai khac, cuon danh sach: chi nhung hang dang hien thi moi tra cuu anh.
6. Tat mo lai ung dung de xac nhan anh bia da duoc ghi nho.

**Luu y**:
- V4 KHONG doi Google Drive API, cach xin quyen, cache am thanh hoac logic ExoPlayer da hoat dong.
- Apple/iTunes va Deezer co the khong tra anh cho moi bai. Truong hop khong khop, ung dung su dung logo mac dinh, khong gan anh ngau nhien.
- Anh album truc tuyen la noi dung cua ben cung cap; neu xuat ban thuong mai, can xem quy dinh su dung/attribution tu dich vu tuong ung.
- Bo code da qua kiem tra cu phap Kotlin PSI; chua du thong tin module Android va may that de kiem tra build / run-time.
- XML trong bo ZIP giu API Key theo bo V3 cu. Do key da tung duoc chia se tren anh/chat, nen thay key moi, han che quyen va khong commit public tren GitHub truoc khi phat hanh.
