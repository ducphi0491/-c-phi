# AudioSheet Studio

AudioSheet Studio is a local-first open-source MVP that converts an uploaded audio file or an authorized YouTube source into:

- MIDI transcription using Spotify Basic Pitch
- MusicXML notation using music21
- In-browser sheet rendering using OpenSheetMusicDisplay
- Piano two-hand, lead-sheet, and raw-transcription arrangements
- Optional PDF export through MuseScore CLI, plus browser Print / Save as PDF

The app does not call a third-party transcription API. Audio processing runs on the machine that hosts the FastAPI server.

## Quick start on Windows

1. Install Python 3.11, FFmpeg, and Node.js LTS.
2. Run `install_windows.bat` once.
3. Run `run_windows.bat` whenever you want to start the site.
4. Open `http://127.0.0.1:8000`.

Detailed Vietnamese instructions are in `HUONG_DAN_VAN_HANH.md`.

## Docker

```bash
docker compose up --build
```

Then open `http://127.0.0.1:8000`.

## Notes

- Basic Pitch works best with one clearly audible instrument at a time.
- Full mixed songs can produce noisy or incomplete notation.
- YouTube input is provided only for content the user is authorized to process.
- The current job queue is local and file-based. Use a database and a proper worker queue before multi-user public deployment.
