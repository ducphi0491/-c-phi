# AudioSheet Studio 1.0.0

Release date: 2026-11-02

## Included

- FastAPI local web server and responsive Vietnamese user interface.
- Audio upload: MP3, WAV, FLAC, OGG, M4A, AAC, and WEBM.
- Authorized YouTube input through yt-dlp.
- FFmpeg normalization to mono 22.05 kHz WAV.
- Spotify Basic Pitch audio-to-MIDI transcription.
- music21 MusicXML generation in piano, lead-sheet, and raw modes.
- Browser sheet rendering with OpenSheetMusicDisplay.
- MIDI, MusicXML, CSV, JSON, WAV, and optional PDF outputs.
- File-backed local job history and one-worker processing queue.
- Windows scripts, Linux scripts, and Docker setup.

## Verification performed in the build environment

- Python source compilation: passed.
- JavaScript syntax check: passed.
- FastAPI health and root endpoint tests: passed.
- Filename and YouTube host validation tests: passed.
- Live local HTTP health response: passed.

The build environment used Python 3.13 and did not contain TensorFlow, Basic Pitch,
or music21. Therefore, a full real-audio AI inference was not executed there. The
release intentionally targets Python 3.11. After installation, run:

    .venv\Scripts\python.exe scripts\check_install.py

A fully ready machine should report OK for FFmpeg, FastAPI, music21, basic_pitch,
and yt_dlp.

## Known limitations

- Best results come from a clear solo instrument recording.
- Lead-sheet chord names are heuristic suggestions.
- Piano hand separation is pitch-based, not pianist fingering analysis.
- No stem separation, guitar tablature, user accounts, or distributed worker queue yet.
- Public Internet deployment needs authentication, HTTPS, rate limits, cleanup jobs,
  a database, and a dedicated processing queue.
