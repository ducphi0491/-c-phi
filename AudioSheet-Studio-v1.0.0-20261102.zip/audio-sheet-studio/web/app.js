(() => {
  "use strict";

  const form = document.getElementById("transcriptionForm");
  const audioFile = document.getElementById("audioFile");
  const youtubeUrl = document.getElementById("youtubeUrl");
  const dropZone = document.getElementById("dropZone");
  const fileLabel = document.getElementById("fileLabel");
  const submitButton = document.getElementById("submitButton");
  const demoButton = document.getElementById("demoButton");
  const jobSection = document.getElementById("jobSection");
  const resultSection = document.getElementById("resultSection");
  const toast = document.getElementById("toast");

  let activeSource = "upload";
  let currentJobId = null;
  let pollToken = 0;
  let osmd = null;
  let osmdPromise = null;
  let zoom = 1.0;

  const statusRank = {
    queued: 0,
    fetching: 0,
    normalizing: 1,
    transcribing: 2,
    arranging: 3,
    done: 4,
    failed: -1,
  };

  const statusText = {
    queued: "Dang cho bo xu ly",
    fetching: "Dang lay nguon am thanh",
    normalizing: "Dang chuan hoa am thanh",
    transcribing: "AI dang nhan dang not",
    arranging: "Dang tao khuong nhac",
    done: "Da hoan tat",
    failed: "Xu ly that bai",
  };

  function showToast(message, isError = false) {
    toast.textContent = message;
    toast.classList.toggle("error", isError);
    toast.classList.add("show");
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3600);
  }

  async function requestJson(url, options = {}) {
    const response = await fetch(url, options);
    let payload = null;
    try {
      payload = await response.json();
    } catch (_) {
      payload = null;
    }
    if (!response.ok) {
      const message = payload && payload.detail ? payload.detail : `HTTP ${response.status}`;
      throw new Error(message);
    }
    return payload;
  }

  function switchSource(source) {
    activeSource = source;
    document.querySelectorAll(".source-tab").forEach((button) => {
      const active = button.dataset.source === source;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
    });
    document.getElementById("uploadSource").classList.toggle("active", source === "upload");
    document.getElementById("youtubeSource").classList.toggle("active", source === "youtube");
  }

  document.querySelectorAll(".source-tab").forEach((button) => {
    button.addEventListener("click", () => switchSource(button.dataset.source));
  });

  function updateFileLabel(file) {
    if (!file) {
      fileLabel.innerHTML = "K&#233;o th&#7843; file v&#224;o &#273;&#226;y ho&#7863;c b&#7845;m &#273;&#7875; ch&#7885;n";
      return;
    }
    const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
    fileLabel.textContent = `${file.name} (${sizeMb} MB)`;
  }

  audioFile.addEventListener("change", () => updateFileLabel(audioFile.files[0]));
  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.add("dragging");
    });
  });
  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.remove("dragging");
    });
  });
  dropZone.addEventListener("drop", (event) => {
    const files = event.dataTransfer.files;
    if (!files || !files.length) return;
    const transfer = new DataTransfer();
    transfer.items.add(files[0]);
    audioFile.files = transfer.files;
    updateFileLabel(files[0]);
  });

  function validateClientInput() {
    if (activeSource === "upload" && !audioFile.files.length) {
      throw new Error("Hay chon mot file am thanh.");
    }
    if (activeSource === "youtube" && !youtubeUrl.value.trim()) {
      throw new Error("Hay dan link YouTube.");
    }
    if (!document.getElementById("acceptedRights").checked) {
      throw new Error("Ban can xac nhan quyen su dung noi dung am thanh.");
    }
  }

  function makeFormData() {
    const data = new FormData(form);
    if (activeSource === "upload") {
      data.delete("youtube_url");
    } else {
      data.delete("audio_file");
    }
    if (!document.getElementById("acceptedRights").checked) {
      data.set("accepted_rights", "false");
    }
    return data;
  }

  function resetJobUi() {
    resultSection.classList.add("hidden");
    document.getElementById("jobError").classList.add("hidden");
    document.getElementById("jobError").textContent = "";
    jobSection.classList.remove("hidden");
  }

  function renderJob(job) {
    const progress = Number(job.progress || 0);
    document.getElementById("jobTitle").textContent = job.title || job.source_name || "Tao ban nhac";
    document.getElementById("jobPercent").textContent = `${Math.round(progress)}%`;
    document.getElementById("progressBar").style.width = `${Math.max(0, Math.min(100, progress))}%`;
    document.getElementById("jobMessage").textContent = job.message || statusText[job.status] || job.status;
    const rank = statusRank[job.status] ?? 0;
    document.querySelectorAll("#processSteps span").forEach((node, index) => {
      node.classList.toggle("complete", rank > index || job.status === "done");
      node.classList.toggle("active", rank === index && job.status !== "done");
    });
    const errorBox = document.getElementById("jobError");
    if (job.status === "failed") {
      errorBox.textContent = job.error || "Khong the xu ly tep am thanh nay.";
      errorBox.classList.remove("hidden");
    }
  }

  async function pollJob(jobId) {
    const token = ++pollToken;
    currentJobId = jobId;
    while (token === pollToken) {
      const job = await requestJson(`/api/jobs/${jobId}`);
      renderJob(job);
      if (job.status === "done") {
        await showResult(job);
        await loadRecentJobs();
        return;
      }
      if (job.status === "failed") {
        submitButton.disabled = false;
        await loadRecentJobs();
        return;
      }
      await new Promise((resolve) => window.setTimeout(resolve, 1300));
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      validateClientInput();
      submitButton.disabled = true;
      resetJobUi();
      jobSection.scrollIntoView({ behavior: "smooth", block: "center" });
      const job = await requestJson("/api/jobs", { method: "POST", body: makeFormData() });
      renderJob(job);
      await pollJob(job.id);
    } catch (error) {
      submitButton.disabled = false;
      showToast(error.message || String(error), true);
    }
  });

  demoButton.addEventListener("click", async () => {
    try {
      demoButton.disabled = true;
      resetJobUi();
      const mode = document.getElementById("mode").value;
      const job = await requestJson(`/api/demo?mode=${encodeURIComponent(mode)}`, { method: "POST" });
      renderJob(job);
      await showResult(job);
      await loadRecentJobs();
      jobSection.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (error) {
      showToast(error.message || String(error), true);
    } finally {
      demoButton.disabled = false;
    }
  });

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`Cannot load ${src}`));
      document.head.appendChild(script);
    });
  }

  async function ensureOsmd() {
    if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
    if (osmdPromise) return osmdPromise;
    osmdPromise = (async () => {
      const sources = [
        "/static/vendor/opensheetmusicdisplay.min.js",
        "https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.1.3/build/opensheetmusicdisplay.min.js",
      ];
      let lastError = null;
      for (const source of sources) {
        try {
          await loadScript(source);
          if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
        } catch (error) {
          lastError = error;
        }
      }
      throw lastError || new Error("OpenSheetMusicDisplay is unavailable");
    })();
    return osmdPromise;
  }

  async function renderMusicXml(url) {
    const loading = document.getElementById("scoreLoading");
    const container = document.getElementById("scoreContainer");
    loading.classList.remove("hidden");
    container.innerHTML = "";
    try {
      const library = await ensureOsmd();
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const xml = await response.text();
      osmd = new library.OpenSheetMusicDisplay(container, {
        autoResize: true,
        backend: "svg",
        drawTitle: true,
        drawComposer: true,
        drawingParameters: "compacttight",
      });
      osmd.Zoom = zoom;
      await osmd.load(xml);
      osmd.render();
      loading.classList.add("hidden");
      updateZoomLabel();
    } catch (error) {
      loading.textContent = "Khong the hien thi MusicXML: " + (error.message || error);
      showToast("Khong the tai bo hien thi sheet nhac.", true);
    }
  }

  function artifactLabel(artifact) {
    const labels = {
      musicxml: "Tai MusicXML",
      midi: "Tai MIDI",
      pdf: "Tai PDF",
      csv: "Tai CSV",
      json: "Tai JSON",
      audio: "Tai WAV",
    };
    return labels[artifact.kind] || artifact.label || artifact.filename;
  }

  async function showResult(job) {
    currentJobId = job.id;
    submitButton.disabled = false;
    resultSection.classList.remove("hidden");
    document.getElementById("resultTitle").textContent = job.title || job.source_name || "Sheet nhac da san sang";
    const meta = [];
    if (job.mode) meta.push(job.mode === "piano" ? "Piano hai tay" : job.mode === "lead" ? "Lead sheet" : "Ban chep tho");
    if (job.bpm_used) meta.push(`${job.bpm_used} BPM`);
    if (job.time_signature) meta.push(`Nhip ${job.time_signature}`);
    if (job.duration_seconds) meta.push(`${job.duration_seconds}s audio`);
    document.getElementById("resultMeta").textContent = meta.join("  /  ");

    const buttons = document.getElementById("downloadButtons");
    buttons.innerHTML = "";
    const artifacts = Array.isArray(job.artifacts) ? job.artifacts : [];
    artifacts.filter((item) => item.kind !== "audio").forEach((artifact, index) => {
      const link = document.createElement("a");
      link.href = artifact.url;
      link.download = artifact.filename;
      link.textContent = artifactLabel(artifact);
      if (artifact.kind === "musicxml" || (!index && artifact.kind !== "pdf")) {
        link.classList.add("primary-download");
      }
      buttons.appendChild(link);
    });

    const audioArtifact = artifacts.find((item) => item.kind === "audio");
    const audioPreview = document.getElementById("audioPreview");
    if (audioArtifact) {
      document.getElementById("audioPlayer").src = audioArtifact.url;
      audioPreview.classList.remove("hidden");
    } else {
      document.getElementById("audioPlayer").removeAttribute("src");
      audioPreview.classList.add("hidden");
    }

    const xmlArtifact = artifacts.find((item) => item.kind === "musicxml");
    if (xmlArtifact) {
      await renderMusicXml(xmlArtifact.url);
    }
    resultSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function updateZoomLabel() {
    document.getElementById("zoomValue").textContent = `${Math.round(zoom * 100)}%`;
  }

  function applyZoom(nextZoom) {
    zoom = Math.max(0.4, Math.min(2.0, nextZoom));
    updateZoomLabel();
    if (osmd) {
      osmd.Zoom = zoom;
      osmd.render();
    }
  }

  document.getElementById("zoomIn").addEventListener("click", () => applyZoom(zoom + 0.1));
  document.getElementById("zoomOut").addEventListener("click", () => applyZoom(zoom - 0.1));
  document.getElementById("fitScore").addEventListener("click", () => {
    const width = document.getElementById("scoreContainer").clientWidth;
    applyZoom(width < 720 ? 0.62 : width < 1000 ? 0.82 : 1.0);
  });
  document.getElementById("printScore").addEventListener("click", () => {
    document.body.classList.add("print-score");
    window.print();
    window.setTimeout(() => document.body.classList.remove("print-score"), 400);
  });

  async function loadRecentJobs() {
    const container = document.getElementById("recentJobs");
    try {
      const jobs = await requestJson("/api/jobs?limit=8");
      container.innerHTML = "";
      if (!jobs.length) {
        container.innerHTML = '<span class="muted">Chua co du lieu.</span>';
        return;
      }
      jobs.forEach((job) => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "recent-job";
        item.innerHTML = `
          <strong></strong>
          <span class="job-state ${job.status === "failed" ? "failed" : ""}"></span>
          <small></small>
        `;
        item.querySelector("strong").textContent = job.title || job.source_name || job.id.slice(0, 8);
        item.querySelector(".job-state").textContent = job.status === "done" ? "Hoan tat" : job.status === "failed" ? "Loi" : `${job.progress || 0}%`;
        item.querySelector("small").textContent = new Date(job.created_at).toLocaleString("vi-VN");
        item.addEventListener("click", async () => {
          try {
            resetJobUi();
            renderJob(job);
            if (job.status === "done") await showResult(job);
            else if (job.status !== "failed") await pollJob(job.id);
            else jobSection.scrollIntoView({ behavior: "smooth" });
          } catch (error) {
            showToast(error.message || String(error), true);
          }
        });
        container.appendChild(item);
      });
    } catch (error) {
      container.innerHTML = '<span class="muted">Khong the tai lich su.</span>';
    }
  }

  async function loadHealth(showMessage = false) {
    const list = document.getElementById("healthList");
    const text = document.getElementById("healthText");
    try {
      const health = await requestJson("/api/health");
      const checks = [
        ["FFmpeg", health.ffmpeg],
        ["Basic Pitch AI", health.basic_pitch],
        ["music21", health.music21],
        ["yt-dlp", health.yt_dlp],
        ["OSMD local", health.local_osmd],
      ];
      list.innerHTML = "";
      checks.forEach(([label, ok]) => {
        const row = document.createElement("div");
        row.className = "health-row";
        row.innerHTML = `<span>${label}</span><i class="health-dot ${ok ? "ok" : ""}"></i>`;
        list.appendChild(row);
      });
      const coreOk = health.ffmpeg && health.basic_pitch && health.music21;
      text.textContent = coreOk
        ? `San sang. Gioi han ${health.limits.max_upload_mb} MB / ${Math.round(health.limits.max_audio_seconds / 60)} phut.`
        : "Thieu cong cu xu ly cot loi. Hay chay lai script cai dat.";
      if (showMessage) showToast(coreOk ? "He thong da san sang." : "He thong dang thieu thanh phan.", !coreOk);
    } catch (error) {
      text.textContent = "Khong ket noi duoc API.";
      list.innerHTML = "";
      if (showMessage) showToast(error.message || String(error), true);
    }
  }

  document.getElementById("healthButton").addEventListener("click", () => {
    loadHealth(true);
    document.querySelector(".info-panel").scrollIntoView({ behavior: "smooth", block: "center" });
  });
  document.getElementById("refreshJobs").addEventListener("click", loadRecentJobs);

  loadHealth();
  loadRecentJobs();
})();
