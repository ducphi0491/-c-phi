from __future__ import annotations

import json
import logging
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from .audio_tools import download_youtube, estimate_bpm, normalize_audio, run_command
from .config import settings
from .job_store import job_store
from .score_builder import write_musicxml
from .transcriber import transcribe


logger = logging.getLogger("audio_sheet.processor")
_executor = ThreadPoolExecutor(max_workers=settings.worker_count, thread_name_prefix="audio-sheet")


def _artifact(job_id: str, filename: str, label: str, kind: str) -> dict[str, str]:
    return {
        "filename": filename,
        "label": label,
        "kind": kind,
        "url": f"/api/jobs/{job_id}/files/{filename}",
    }


def _find_musescore() -> str | None:
    candidates = [
        settings.musescore_bin,
        "MuseScore4",
        "musescore4",
        "mscore4",
        "MuseScore3",
        "musescore3",
        "mscore",
    ]
    for candidate in candidates:
        if not candidate:
            continue
        explicit = Path(candidate)
        if explicit.exists():
            return str(explicit)
        located = shutil.which(candidate)
        if located:
            return located
    return None


def _try_export_pdf(musicxml_path: Path, pdf_path: Path) -> bool:
    executable = _find_musescore()
    if not executable:
        return False
    try:
        run_command([executable, "-o", str(pdf_path), str(musicxml_path)], timeout=180)
        return pdf_path.exists() and pdf_path.stat().st_size > 0
    except Exception:
        logger.exception("MuseScore PDF export failed")
        return False


def _friendly_error(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    lowered = text.lower()
    if "no notes were detected" in lowered:
        return "No stable notes were detected. Try a cleaner solo instrument recording or lower the thresholds."
    if "tensorflow" in lowered or "basic pitch" in lowered:
        return "The AI engine is not ready. Re-run the installer with Python 3.11 and check the health panel."
    if "ffmpeg" in lowered or "ffprobe" in lowered:
        return "FFmpeg is missing or could not decode this audio file."
    if "youtube" in lowered or "yt-dlp" in lowered:
        return text[:600]
    return text[:600]


def submit_job(job_id: str) -> None:
    _executor.submit(_process_job, job_id)


def _process_job(job_id: str) -> None:
    directory = job_store.job_dir(job_id)
    log_path = directory / "processor.log"
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(file_handler)
    try:
        job = job_store.get(job_id)
        source_type = job["source_type"]
        source_path: Path

        if source_type == "youtube":
            job_store.update(job_id, status="fetching", progress=8, message="Reading the YouTube source")
            source_path, metadata = download_youtube(
                job["youtube_url"],
                output_dir=directory,
                max_seconds=settings.max_audio_seconds,
                max_bytes=settings.max_upload_mb * 1024 * 1024,
            )
            source_name = str(metadata.get("title") or "YouTube audio")[:200]
            title = job.get("title") or source_name
            job_store.update(job_id, source_name=source_name, title=title)
        else:
            source_path = directory / job["source_filename"]

        job_store.update(job_id, status="normalizing", progress=22, message="Normalizing audio with FFmpeg")
        normalized_path = directory / "normalized.wav"
        duration = normalize_audio(source_path, normalized_path, settings.max_audio_seconds)

        requested_bpm = float(job.get("bpm_requested") or 0)
        bpm = requested_bpm if requested_bpm > 0 else estimate_bpm(normalized_path)
        bpm = max(40.0, min(240.0, float(bpm)))
        job_store.update(
            job_id,
            duration_seconds=round(duration, 2),
            bpm_used=round(bpm, 1),
            progress=34,
            message=f"Preparing AI transcription at {bpm:.1f} BPM",
        )

        midi_path = directory / "transcription.mid"
        csv_path = directory / "note_events.csv"
        job_store.update(job_id, status="transcribing", progress=42, message="Detecting notes with Basic Pitch")
        note_events = transcribe(
            audio_path=normalized_path,
            midi_path=midi_path,
            csv_path=csv_path,
            bpm=bpm,
            minimum_midi=int(job["minimum_midi"]),
            maximum_midi=int(job["maximum_midi"]),
            onset_threshold=float(job["onset_threshold"]),
            frame_threshold=float(job["frame_threshold"]),
            minimum_note_length_ms=float(job["minimum_note_length_ms"]),
        )

        notes_json = directory / "note_events.json"
        serializable_notes = [
            {
                "start": float(start),
                "end": float(end),
                "pitch": int(pitch),
                "velocity": int(round(float(amplitude) * 127)),
                "pitch_bends": [int(value) for value in bends] if bends else None,
            }
            for start, end, pitch, amplitude, bends in note_events
        ]
        notes_json.write_text(json.dumps(serializable_notes, indent=2), encoding="utf-8")

        job_store.update(job_id, status="arranging", progress=76, message="Building readable MusicXML notation")
        musicxml_path = directory / "sheet.musicxml"
        write_musicxml(
            note_events=note_events,
            output_path=musicxml_path,
            mode=job["mode"],
            title=job.get("title") or job.get("source_name") or "Untitled transcription",
            bpm=bpm,
            time_signature=job["time_signature"],
            quantization=int(job["quantization"]),
            split_pitch=int(job["split_pitch"]),
        )

        artifacts = [
            _artifact(job_id, musicxml_path.name, "MusicXML sheet", "musicxml"),
            _artifact(job_id, midi_path.name, "MIDI transcription", "midi"),
            _artifact(job_id, csv_path.name, "Detected notes CSV", "csv"),
            _artifact(job_id, notes_json.name, "Detected notes JSON", "json"),
            _artifact(job_id, normalized_path.name, "Normalized preview audio", "audio"),
        ]

        job_store.update(job_id, progress=90, message="Finalizing downloadable files")
        pdf_path = directory / "sheet.pdf"
        if _try_export_pdf(musicxml_path, pdf_path):
            artifacts.insert(1, _artifact(job_id, pdf_path.name, "PDF sheet", "pdf"))

        if not settings.keep_source_audio and source_path != normalized_path:
            try:
                source_path.unlink(missing_ok=True)
            except OSError:
                pass

        job_store.update(
            job_id,
            status="done",
            progress=100,
            message="Transcription completed",
            artifacts=artifacts,
            error=None,
        )
    except Exception as exc:
        logger.exception("Job %s failed", job_id)
        try:
            job_store.update(
                job_id,
                status="failed",
                progress=100,
                message="Processing failed",
                error=_friendly_error(exc),
            )
        except Exception:
            logger.exception("Could not record failure for job %s", job_id)
    finally:
        logger.removeHandler(file_handler)
        file_handler.close()
