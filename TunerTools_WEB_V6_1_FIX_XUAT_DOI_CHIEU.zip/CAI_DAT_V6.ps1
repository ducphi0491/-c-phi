param([string]$Destination = 'C:\TunerTools\Tools\PDF_TAB_GP_WEB')
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host 'TunerTools WEB V6 - Cai dat ban thu nghiem' -ForegroundColor Cyan
Write-Host ('ZIP extracted at: ' + $Root)
Write-Host ('Destination: ' + $Destination)

# If the old server is active, stop before overwriting any code.
try {
    $reply = Invoke-WebRequest -Uri 'http://127.0.0.1:8021/api/health' -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop
    if ($reply.StatusCode -eq 200) {
        Write-Host 'ERROR: A web server is still using port 8021. Close the old web terminal first.' -ForegroundColor Red
        exit 2
    }
} catch { }

$HashFile = Join-Path $Root 'MANIFEST_SHA256_V6.csv'
if (-not (Test-Path -LiteralPath $HashFile -PathType Leaf)) { throw 'Missing manifest. Please extract the full ZIP.' }
$Rows = @(Import-Csv -LiteralPath $HashFile)
if ($Rows.Count -lt 15) { throw 'Manifest is incomplete.' }
foreach ($Row in $Rows) {
    $Path = Join-Path $Root $Row.Path
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ('Missing file: ' + $Row.Path) }
    $Hash = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if ($Hash -ne $Row.SHA256) { throw ('SHA256 mismatch: ' + $Row.Path) }
}
Write-Host ('[OK] Verified SHA256 for ' + $Rows.Count + ' files.') -ForegroundColor Green

if (-not (Test-Path -LiteralPath $Destination)) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
}
$FullSource = [IO.Path]::GetFullPath($Root).TrimEnd('\')
$FullDest = [IO.Path]::GetFullPath($Destination).TrimEnd('\')
if (-not [String]::Equals($FullSource, $FullDest, [StringComparison]::OrdinalIgnoreCase)) {
    $Backup = Join-Path $FullDest ('BACKUP_TRUOC_V6_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $OldFiles = @('app.py', 'vector_draft.py', 'source_inspector.py', 'review_bundle.py', 'static\index.html', 'static\app.js', 'CHAY_WEB.ps1')
    foreach ($Name in $OldFiles) {
        $Old = Join-Path $FullDest $Name
        if (Test-Path -LiteralPath $Old -PathType Leaf) {
            $New = Join-Path $Backup $Name
            New-Item -ItemType Directory -Path (Split-Path -Parent $New) -Force | Out-Null
            Copy-Item -LiteralPath $Old -Destination $New -Force
        }
    }
    if (Test-Path -LiteralPath $Backup) { Write-Host ('Backup: ' + $Backup) }
    foreach ($Row in $Rows) {
        $From = Join-Path $Root $Row.Path
        $To = Join-Path $FullDest $Row.Path
        $Parent = Split-Path -Parent $To
        if (-not (Test-Path -LiteralPath $Parent)) {
            New-Item -ItemType Directory -Path $Parent -Force | Out-Null
        }
        Copy-Item -LiteralPath $From -Destination $To -Force
    }
}
$Actual = Get-Content -LiteralPath (Join-Path $FullDest 'app.py') -Raw
if (-not $Actual.Contains('version="0.6.1"')) { throw 'The destination does not have V6 app.py.' }
Write-Host '[OK] V6 installed; existing .venv and SoundFont were preserved.' -ForegroundColor Green
Write-Host ('Launch: ' + (Join-Path $FullDest 'CHAY_WEB.bat')) -ForegroundColor Cyan
exit 0
