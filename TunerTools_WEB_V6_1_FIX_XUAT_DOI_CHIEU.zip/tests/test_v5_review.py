"""V5 source/audit ZIP smoke tests; synthetic content, no private PDFs."""
import io
import json
import zipfile
from pathlib import Path

import fitz
from fastapi.testclient import TestClient

import app
from measure_anchors import resolve_boundaries, audit_summary
from review_bundle import _midi_file, generate_review_zip


def make_source_pdf():
    doc=fitz.open()
    page=doc.new_page(width=420,height=360)
    page.insert_text((30,34),'Demo source PDF', fontsize=12)
    page.insert_text((30,95),'First staff / tab placeholder',fontsize=11)
    for k in range(6):
        page.draw_line((42,135+k*8),(390,135+k*8))
    page.insert_text((88,141),'3',fontsize=9)
    page.insert_text((167,149),'5',fontsize=9)
    data=doc.tobytes();doc.close()
    return data


def make_fake_job(source=None):
    source=source or make_source_pdf()
    beat={'voice':0,'beat':0,'position':0.0,'length':.5,'duration':8,'dotted':False,
          'notes':[{'note':0,'string':1,'fret':3,'pitch':67,'velocity':90}]}
    score={'tempo':80,'title':'Test','total_notes':1,'total_measures':1,
        'tracks':[{'index':0,'measures':[{'number':1,'start':0,'beats':[beat]}]}]}
    draft={'mode':'vector_draft','time_signature':'6/8','bars':[
        {'number':1,'page':1,'system':1,'x_range':[30,190],
         'source_printed_measure':1,'measure_number_lanes':[[1]],
         'notes_count':1,'columns_count':1,'boundary_method':'labels_fallback',
         'risks':['rhythm_estimated_not_omr'],
         'beats':[{'duration':8,'dotted':False,'notes':[{'x':88,'y':135,'string':1,'fret':3}]}]}],
        'systems_audit':[{'page':1,'system':1,'tab_y':[135,175],
                          'lanes':[{'numbers':[1]}], 'selected_labels':[1],
                          'unresolved_labels':[]}],
        'warnings':['All rhythm estimated']}
    draft['label_audit']=audit_summary(draft)
    return {'source_file':source, 'source_filename':'sample.pdf','selected_pages':[1],
            'report':{'mode':'vector_draft','warnings':draft['warnings']},
            'audit_draft':draft,'score':score,'files':{'gp5':b'TEST-ONLY'},
            'export_warnings':{},'edit_history':[],'name':'sample', 'created':0}


def test_zip_with_source_and_midi():
    payload=generate_review_zip(make_fake_job())
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        assert z.testzip() is None
        assert 'source/original.pdf' in z.namelist()
        assert 'images/page_01_overlay.png' in z.namelist()
        assert 'GP_output/result.mid' in z.namelist()
        assert z.read('GP_output/result.mid').startswith(b'MThd')
        assert len(z.read('output_notes.csv').splitlines())==2
        assert len(z.read('measures.csv').splitlines())==2
        assert b'PDF label' in z.read('OPEN_REVIEW.html')
        assert json.loads(z.read('manifest.json'))['source']['included']


def test_zip_without_source_excludes_page_images():
    payload=generate_review_zip(make_fake_job(), include_source=False)
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        assert 'source/original.pdf' not in z.namelist()
        assert not any(x.startswith('images/') for x in z.namelist())
        assert not json.loads(z.read('manifest.json'))['source']['included']


def test_route_download_includes_review_data(monkeypatch):
    job=make_fake_job()
    def convert(*args, **kwargs):
        return {k:v for k,v in job.items() if k not in ('source_file','source_filename','created','name','edit_history')}
    monkeypatch.setattr(app,'conversion_pipeline',convert)
    client=TestClient(app.app)
    reply=client.post('/api/convert',files={'file':('song.pdf',job['source_file'],'application/pdf')},data={'mode':'vector'})
    assert reply.status_code==200,reply.text
    ref=reply.json()['id']
    assert reply.json()['review_ready'] is True
    zdata=client.get(f'/api/review-package/{ref}?include_source=1')
    assert zdata.status_code==200,zdata.text[:100]
    assert 'song_DOI_CHIEU_V6.zip' in zdata.headers['content-disposition']
    assert 'DOI_CHIEU_V5' not in zdata.headers['content-disposition']
    with zipfile.ZipFile(io.BytesIO(zdata.content)) as z:
        assert z.testzip() is None
        assert 'recognition_diagnostics.json' in z.namelist()
        assert 'alignment_audit.csv' in z.namelist()
        assert json.loads(z.read('manifest.json'))['format']=='tunertools_v6_review_bundle'
        assert 'source/original.pdf' in z.namelist()
    without=client.get(f'/api/review-package/{ref}?include_source=0')
    with zipfile.ZipFile(io.BytesIO(without.content)) as z:
        assert 'source/original.pdf' not in z.namelist()
    assert client.get(f'/api/review-package/{ref}?include_source=9').status_code==422


def test_boundary_recovery_when_missing_barlines():
    notes=[{'x':50,'string':1,'fret':2},{'x':82,'string':2,'fret':3},
           {'x':152,'string':1,'fret':5},{'x':183,'string':2,'fret':7}]
    lanes=[{'y':5,'labels':[{'x':40,'number':21},{'x':140,'number':22}],
            'numbers':[21,22],'count':2}]
    result=resolve_boundaries(notes,[],lanes,{'spacing':8})
    assert result['method']=='labels_fallback'
    assert len(result['edges'])==3
    assert not result['missing_labels']


def test_overprinted_lanes_flagged():
    notes=[{'x':50,'string':1,'fret':2},{'x':155,'string':1,'fret':5}]
    lanes=[{'y':5,'labels':[{'x':40,'number':21},{'x':140,'number':22}],
            'numbers':[21,22],'count':2},
           {'y':15,'labels':[{'x':40,'number':23},{'x':140,'number':24}],
            'numbers':[23,24],'count':2}]
    result=resolve_boundaries(notes,[140,235],lanes,{'spacing':8})
    assert result['missing_labels']==[23,24]
    assert 'overprinted_measure_number_lanes' in result['problems']
