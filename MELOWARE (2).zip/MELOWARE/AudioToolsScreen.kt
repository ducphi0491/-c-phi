package duc_phi.music

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.sourceforge.lame.mp3.Lame
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

internal enum class AudioToolMode { CONVERT, EXTRACT }
private enum class AudioTarget(val extension: String, val mime: String) {
    MP3("mp3", "audio/mpeg"),
    M4A("m4a", "audio/mp4"),
    WAV("wav", "audio/x-wav")
}

/** Full-screen overlay opened from the Home page. The source is never modified. */
@Composable
internal fun MeloWaveAudioToolDialog(mode: AudioToolMode, onDismiss: () -> Unit) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val savedLabel = mwString("audio_tools.saved", "Đã lưu file thành công")
    var inputUri by remember(mode) { mutableStateOf<Uri?>(null) }
    var inputName by remember(mode) { mutableStateOf("") }
    var target by remember(mode) { mutableStateOf(if (mode == AudioToolMode.EXTRACT) AudioTarget.M4A else AudioTarget.MP3) }
    var bitrate by remember(mode) { mutableStateOf(192) }
    var progress by remember(mode) { mutableFloatStateOf(0f) }
    var busy by remember(mode) { mutableStateOf(false) }
    var saving by remember(mode) { mutableStateOf(false) }
    var message by remember(mode) { mutableStateOf("") }
    var resultFile by remember(mode) { mutableStateOf<File?>(null) }
    var savedUri by remember(mode) { mutableStateOf<Uri?>(null) }
    var task by remember(mode) { mutableStateOf<Job?>(null) }

    DisposableEffect(mode) {
        onDispose {
            task?.cancel()
            resultFile?.delete()
        }
    }

    fun clearResult() {
        resultFile?.delete()
        resultFile = null
        savedUri = null
        progress = 0f
        message = ""
    }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            clearResult()
            inputUri = uri
            inputName = displayNameFor(context, uri)
        }
    }

    fun writeToDocument(destination: Uri?) {
        saving = false
        if (destination == null) return
        val source = resultFile ?: return
        saving = true
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val output = context.contentResolver.openOutputStream(destination, "w")
                        ?: error("Cannot open output document")
                    output.use { stream -> source.inputStream().use { it.copyTo(stream, 128 * 1024) } }
                }
                savedUri = destination
                message = ""
                Toast.makeText(context, savedLabel, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                message = e.localizedMessage ?: "Không lưu được file"
            } finally {
                saving = false
            }
        }
    }
    val createMp3 = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { writeToDocument(it) }
    val createM4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { writeToDocument(it) }
    val createWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { writeToDocument(it) }

    val chooseDocument = {
        val name = inputName.substringBeforeLast('.', inputName).ifBlank { "MeloWave" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_").take(90)
        val outputName = "${name}.${target.extension}"
        when (target) {
            AudioTarget.MP3 -> createMp3.launch(outputName)
            AudioTarget.M4A -> createM4a.launch(outputName)
            AudioTarget.WAV -> createWav.launch(outputName)
        }
    }

    val startConversion = {
        val uri = inputUri
        if (uri != null && !busy && !saving) {
            clearResult()
            busy = true
            message = ""
            val outputFormat = target
            val kbps = bitrate
            task = scope.launch {
                var temp: File? = null
                try {
                    val folder = File(context.cacheDir, "mw_audio_exports").apply { mkdirs() }
                    val outputFile = File.createTempFile("mw_export_", ".${outputFormat.extension}", folder)
                    temp = outputFile
                    withContext(Dispatchers.IO) {
                        AudioExportEngine.export(
                            context = context,
                            uri = uri,
                            format = outputFormat.extension,
                            bitrateKbps = kbps,
                            output = outputFile,
                            check = {
                                if (!isActive) throw CancellationException()
                            },
                            onProgress = { fraction -> progress = fraction.coerceIn(0f, 1f) }
                        )
                    }
                    resultFile = temp
                    progress = 1f
                    temp = null
                } catch (_: CancellationException) {
                    message = "Đã hủy chuyển đổi"
                } catch (e: Exception) {
                    message = e.localizedMessage ?: "Không thể xử lý file này"
                } finally {
                    temp?.delete()
                    busy = false
                    task = null
                }
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy && !saving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = colors.background) {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = mwString("common.close", "Đóng"),
                        modifier = Modifier.size(27.dp).clickable(enabled = !busy && !saving) { onDismiss() },
                        tint = colors.textPrimary
                    )
                    Spacer(Modifier.size(15.dp))
                    Text(
                        if (mode == AudioToolMode.CONVERT) mwString("audio_tools.convert", "Chuyển đổi nhạc")
                        else mwString("audio_tools.extract", "Tách âm thanh"),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
                Column(
                    modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text(
                        if (mode == AudioToolMode.CONVERT)
                            mwString("audio_tools.convert_hint", "Chọn một bài nhạc trong điện thoại để chuyển sang định dạng khác.")
                        else mwString("audio_tools.extract_hint", "Chọn một video để lấy riêng âm thanh; video gốc được giữ nguyên."),
                        fontSize = 13.sp, color = colors.textSecondary
                    )
                    AudioExportSection(colors.card, colors.border) {
                        Text(mwString("audio_tools.source", "Tệp nguồn"), fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Spacer(Modifier.height(9.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (mode == AudioToolMode.CONVERT) Icons.Rounded.MusicNote else Icons.Rounded.VideoFile,
                                contentDescription = null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(30.dp)
                            )
                            Spacer(Modifier.size(12.dp))
                            Text(
                                inputName.ifBlank { mwString("audio_tools.not_selected", "Chưa chọn tệp") },
                                color = colors.textPrimary, fontSize = 13.sp,
                                modifier = Modifier.weight(1f),
                                maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                pickFile.launch(
                                    if (mode == AudioToolMode.CONVERT) arrayOf("audio/*") else arrayOf("video/*")
                                )
                            },
                            enabled = !busy && !saving,
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, colors.purpleBright)
                        ) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = colors.purpleBright)
                            Spacer(Modifier.size(8.dp))
                            Text(mwString("audio_tools.pick", "Chọn file từ điện thoại"), color = colors.purpleBright)
                        }
                    }
                    AudioExportSection(colors.card, colors.border) {
                        Text(mwString("audio_tools.output", "Định dạng đầu ra"), color = colors.textPrimary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AudioTarget.entries.forEach { entry ->
                                val selected = target == entry
                                Surface(
                                    modifier = Modifier.weight(1f).clickable(enabled = !busy && !saving) {
                                        if (target != entry) { target = entry; clearResult() }
                                    },
                                    color = if (selected) colors.purple.copy(alpha = 0.20f) else colors.cardRaised,
                                    shape = RoundedCornerShape(13.dp),
                                    border = BorderStroke(1.dp, if (selected) colors.purpleBright else colors.border)
                                ) {
                                    Box(modifier = Modifier.padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                                        Text(entry.extension.uppercase(), color = if (selected) colors.purpleBright else colors.textPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(9.dp))
                        Text(
                            if (target == AudioTarget.WAV) mwString("audio_tools.wav_note", "WAV không nén: chất lượng PCM gốc, file có thể lớn.")
                            else if (target == AudioTarget.M4A) mwString("audio_tools.m4a_note", "M4A (AAC): ưu tiên chép luồng AAC gốc khi có thể.")
                            else mwString("audio_tools.mp3_note", "MP3: chuyển đổi bằng mã hóa Java, có thể lâu hơn M4A."),
                            fontSize = 12.sp, color = colors.textSecondary
                        )
                        if (target != AudioTarget.WAV) {
                            Spacer(Modifier.height(14.dp))
                            Text(mwString("audio_tools.bitrate", "Chất lượng (kbps)"), color = colors.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(128, 192, 256).forEach { rate ->
                                    Surface(
                                        modifier = Modifier.weight(1f).clickable(enabled = !busy && !saving) {
                                            if (bitrate != rate) { bitrate = rate; clearResult() }
                                        },
                                        color = if (rate == bitrate) colors.purple.copy(alpha = 0.20f) else colors.cardRaised,
                                        shape = RoundedCornerShape(11.dp),
                                        border = BorderStroke(1.dp, if (rate == bitrate) colors.purpleBright else colors.border)
                                    ) {
                                        Text(
                                            "$rate", modifier = Modifier.padding(vertical = 10.dp),
                                            color = if (rate == bitrate) colors.purpleBright else colors.textPrimary,
                                            fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                    if (busy || resultFile != null) {
                        AudioExportSection(colors.card, colors.border) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = colors.purpleBright)
                                else Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = colors.green)
                                Spacer(Modifier.size(10.dp))
                                Text(
                                    if (busy) mwString("audio_tools.processing", "Đang xử lý...")
                                    else mwString("audio_tools.ready", "Đã xử lý xong — chọn nơi lưu file"),
                                    color = colors.textPrimary, fontWeight = FontWeight.Medium
                                )
                            }
                            Spacer(Modifier.height(13.dp))
                            LinearProgressIndicator(
                                progress = progress,
                                modifier = Modifier.fillMaxWidth(),
                                color = colors.purpleBright,
                                trackColor = colors.border
                            )
                            Spacer(Modifier.height(6.dp))
                            Text("${(progress * 100).toInt()}%", color = colors.textSecondary, fontSize = 12.sp)
                        }
                    }
                    if (message.isNotBlank()) {
                        Text(message, color = colors.red, fontSize = 13.sp)
                    }
                    if (savedUri != null) {
                        OutlinedButton(onClick = {
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(savedUri, target.mime)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                )
                            } catch (_: ActivityNotFoundException) {
                                Toast.makeText(context, "Không tìm thấy ứng dụng mở tệp", Toast.LENGTH_SHORT).show()
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(mwString("audio_tools.open_saved", "Mở file vừa lưu"), color = colors.purpleBright)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 15.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (busy) {
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth().height(53.dp),
                            onClick = { task?.cancel() }, border = BorderStroke(1.dp, colors.red)
                        ) { Text(mwString("audio_tools.cancel", "Hủy chuyển đổi"), color = colors.red) }
                    } else if (resultFile != null) {
                        Button(
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            enabled = !saving,
                            onClick = chooseDocument,
                            colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                        ) {
                            Icon(Icons.Rounded.SaveAlt, contentDescription = null, tint = Color.White)
                            Spacer(Modifier.size(9.dp))
                            Text(mwString("audio_tools.save", "Lưu file vào điện thoại"), color = Color.White)
                        }
                    } else {
                        Button(
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            enabled = inputUri != null && !saving,
                            onClick = startConversion,
                            colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                        ) {
                            Text(
                                if (mode == AudioToolMode.CONVERT) mwString("audio_tools.start", "Bắt đầu chuyển đổi")
                                else mwString("audio_tools.extract", "Tách âm thanh"),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        mwString("audio_tools.original", "MeloWave không thay đổi hoặc xóa tệp gốc."),
                        fontSize = 11.sp, color = colors.textMuted,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        }
    }
}

@Composable
private fun AudioExportSection(bg: Color, border: Color, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = bg, shape = RoundedCornerShape(19.dp),
        border = BorderStroke(1.dp, border)
    ) { Column(modifier = Modifier.padding(16.dp), content = content) }
}

private fun displayNameFor(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    } ?: uri.lastPathSegment ?: "MeloWave"
}.getOrDefault(uri.lastPathSegment ?: "MeloWave")

/** Uses Android's platform codecs for AAC/WAV, plus pure Java LAME for MP3. */
private object AudioExportEngine {
    fun export(
        context: Context, uri: Uri, format: String, bitrateKbps: Int, output: File,
        check: () -> Unit, onProgress: (Float) -> Unit
    ) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("Tệp không có luồng âm thanh có thể đọc")
            val inputFormat = extractor.getTrackFormat(trackIndex)
            extractor.selectTrack(trackIndex)
            val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION))
                inputFormat.getLong(MediaFormat.KEY_DURATION) else 0L
            val mime = inputFormat.getString(MediaFormat.KEY_MIME).orEmpty()
            if (format == "m4a" && mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                copyAac(extractor, inputFormat, output, durationUs, check, onProgress)
            } else {
                decodeAudio(extractor, inputFormat, format, bitrateKbps, output, durationUs, check, onProgress)
            }
            require(output.length() > 44) { "Không có dữ liệu âm thanh để lưu" }
        } finally {
            extractor.release()
        }
    }

    private fun copyAac(
        extractor: MediaExtractor, input: MediaFormat, target: File, duration: Long,
        check: () -> Unit, progress: (Float) -> Unit
    ) {
        var muxer: MediaMuxer? = null
        var started = false
        try {
            muxer = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val track = muxer.addTrack(input)
            muxer.start()
            started = true
            val capacity = if (input.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                max(1024 * 1024, input.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)) else 1024 * 1024
            val buffer = ByteBuffer.allocateDirect(min(capacity, 16 * 1024 * 1024))
            val info = MediaCodec.BufferInfo()
            while (true) {
                check()
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                val codecFlags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else {
                    0
                }
                info.set(0, size, max(0L, extractor.sampleTime), codecFlags)
                buffer.position(0)
                buffer.limit(size)
                muxer.writeSampleData(track, buffer, info)
                if (duration > 0) progress((info.presentationTimeUs.toFloat() / duration).coerceIn(0f, 0.99f))
                extractor.advance()
            }
            progress(1f)
        } finally {
            if (started) runCatching { muxer?.stop() }
            muxer?.release()
        }
    }

    private fun decodeAudio(
        extractor: MediaExtractor, source: MediaFormat, format: String, bitrate: Int,
        target: File, duration: Long, check: () -> Unit, progress: (Float) -> Unit
    ) {
        val mime = source.getString(MediaFormat.KEY_MIME) ?: error("Không nhận dạng được âm thanh")
        val decoder = MediaCodec.createDecoderByType(mime)
        var sink: PcmWriter? = null
        try {
            decoder.configure(source, null, null, 0)
            decoder.start()
            var inputEnded = false
            var outputEnded = false
            val info = MediaCodec.BufferInfo()
            while (!outputEnded) {
                check()
                if (!inputEnded) {
                    val index = decoder.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val buffer = decoder.getInputBuffer(index) ?: error("Decoder input buffer unavailable")
                        buffer.clear()
                        val read = extractor.readSampleData(buffer, 0)
                        if (read < 0) {
                            decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEnded = true
                        } else {
                            decoder.queueInputBuffer(index, 0, read, max(0L, extractor.sampleTime), 0)
                            extractor.advance()
                        }
                    }
                }
                val index = decoder.dequeueOutputBuffer(info, 10_000)
                when (index) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (sink != null) error("Âm thanh thay đổi định dạng trong khi xử lý")
                        sink = buildWriter(decoder.outputFormat, format, bitrate, target)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER, MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                    else -> if (index >= 0) {
                        if (sink == null) sink = buildWriter(decoder.outputFormat, format, bitrate, target)
                        if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            val data = decoder.getOutputBuffer(index) ?: error("Decoder output buffer unavailable")
                            data.position(info.offset)
                            data.limit(info.offset + info.size)
                            val raw = ByteArray(info.size)
                            data.get(raw)
                            sink!!.write(raw)
                            if (duration > 0) progress((info.presentationTimeUs.toFloat() / duration).coerceIn(0f, 0.99f))
                        }
                        outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(index, false)
                    }
                }
            }
            check()
            val writer = sink ?: error("Không tìm được dữ liệu âm thanh")
            writer.finish()
            progress(1f)
        } finally {
            runCatching { sink?.close() }
            runCatching { decoder.stop() }
            decoder.release()
        }
    }

    private fun buildWriter(outputFormat: MediaFormat, ext: String, bitrate: Int, file: File): PcmWriter {
        val sampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        require(channels in 1..2) { "Hiện chỉ hỗ trợ âm thanh mono hoặc stereo" }
        val pcmEncoding = if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING))
            outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
        require(pcmEncoding == 2) { "Thiết bị xuất PCM không phải 16-bit; chưa hỗ trợ codec này" }
        return when (ext) {
            "wav" -> WavWriter(file, sampleRate, channels)
            "mp3" -> Mp3Writer(file, sampleRate, channels, bitrate)
            "m4a" -> AacWriter(file, sampleRate, channels, bitrate)
            else -> error("Định dạng xuất không được hỗ trợ")
        }
    }

    private interface PcmWriter : Closeable {
        fun write(pcm: ByteArray)
        fun finish()
    }

    private class WavWriter(file: File, private val rate: Int, private val channels: Int) : PcmWriter {
        private val target = RandomAccessFile(file, "rw")
        private var bytes = 0L
        init { target.setLength(0); target.write(ByteArray(44)) }
        override fun write(pcm: ByteArray) {
            require(bytes + pcm.size <= 0xFFFFFFFFL - 36L) { "File WAV vượt giới hạn 4 GB" }
            target.write(pcm)
            bytes += pcm.size
        }
        override fun finish() {
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray(Charsets.US_ASCII))
            h.putInt((36L + bytes).toInt())
            h.put("WAVEfmt ".toByteArray(Charsets.US_ASCII))
            h.putInt(16)
            h.putShort(1)
            h.putShort(channels.toShort())
            h.putInt(rate)
            h.putInt(rate * channels * 2)
            h.putShort((channels * 2).toShort())
            h.putShort(16)
            h.put("data".toByteArray(Charsets.US_ASCII))
            h.putInt(bytes.toInt())
            target.seek(0)
            target.write(h.array())
        }
        override fun close() { target.close() }
    }

    private class Mp3Writer(file: File, rate: Int, private val channels: Int, bitrate: Int) : PcmWriter {
        private val stream = FileOutputStream(file)
        private val encoder = Lame()
        private var remainder = ByteArray(0)
        init {
            val flags = encoder.getFlags()
            flags.setInNumChannels(channels)
            flags.setInSampleRate(rate)
            flags.setBitRate(if (rate < 32_000) min(bitrate, 160) else bitrate)
            flags.setQuality(5)
            encoder.getId3().init(flags)
            flags.setWriteId3tagAutomatic(false)
            val state = encoder.initParams()
            require(state >= 0) { "Không khởi tạo được bộ mã hóa MP3 ($state)" }
        }
        override fun write(pcm: ByteArray) {
            val alignedSize = ((remainder.size + pcm.size) / (2 * channels)) * (2 * channels)
            val joined = if (remainder.isEmpty()) pcm else remainder + pcm
            if (alignedSize == 0) { remainder = joined; return }
            val frameBytes = channels * 2
            val maxFrames = 8192
            var offset = 0
            while (offset < alignedSize) {
                val frames = min(maxFrames, (alignedSize - offset) / frameBytes)
                val left = FloatArray(frames)
                val right = FloatArray(frames)
                for (i in 0 until frames) {
                    val p = offset + i * frameBytes
                    val l = (joined[p].toInt() and 0xff) or (joined[p + 1].toInt() shl 8)
                    left[i] = (l.toShort().toInt() shl 16).toFloat()
                    if (channels == 2) {
                        val r = (joined[p + 2].toInt() and 0xff) or (joined[p + 3].toInt() shl 8)
                        right[i] = (r.toShort().toInt() shl 16).toFloat()
                    } else {
                        right[i] = left[i]
                    }
                }
                val buffer = ByteArray((1.25 * frames).toInt() + 8192)
                val count = encoder.encodeBuffer(left, right, frames, buffer)
                require(count >= 0) { "Lỗi mã hóa MP3 ($count)" }
                if (count > 0) stream.write(buffer, 0, count)
                offset += frames * frameBytes
            }
            remainder = if (alignedSize == joined.size) ByteArray(0) else joined.copyOfRange(alignedSize, joined.size)
        }
        override fun finish() {
            require(remainder.isEmpty()) { "Âm thanh PCM thiếu dữ liệu mẫu" }
            val buffer = ByteArray(16384)
            val count = encoder.encodeFlush(buffer)
            require(count >= 0) { "Lỗi hoàn tất MP3 ($count)" }
            if (count > 0) stream.write(buffer, 0, count)
            stream.flush()
        }
        override fun close() {
            runCatching { encoder.close() }
            stream.close()
        }
    }

    private class AacWriter(file: File, rate: Int, private val channels: Int, bitrate: Int) : PcmWriter {
        private val encoder: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        private val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        private var muxStarted = false
        private var track = -1
        private var queuedFrames = 0L
        private var encoderEos = false
        private val sampleRate = rate
        private val info = MediaCodec.BufferInfo()
        init {
            val codecFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, channels).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate * 1000)
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32 * 1024)
            }
            encoder.configure(codecFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
        }
        override fun write(pcm: ByteArray) {
            var offset = 0
            val frameSize = channels * 2
            require(pcm.size % frameSize == 0) { "PCM không đồng bộ frame" }
            var emptyPolls = 0
            while (offset < pcm.size) {
                var index = encoder.dequeueInputBuffer(10_000)
                if (index < 0) { drain(false); index = encoder.dequeueInputBuffer(10_000) }
                if (index < 0) {
                    check(++emptyPolls < 500) { "AAC encoder input timed out" }
                    continue
                }
                emptyPolls = 0
                val buffer = encoder.getInputBuffer(index) ?: error("AAC input buffer unavailable")
                buffer.clear()
                val len = min(pcm.size - offset, buffer.remaining()) / frameSize * frameSize
                require(len > 0) { "AAC input buffer quá nhỏ" }
                buffer.put(pcm, offset, len)
                encoder.queueInputBuffer(index, 0, len, queuedFrames * 1_000_000L / sampleRate, 0)
                queuedFrames += len / frameSize
                offset += len
                drain(false)
            }
        }
        override fun finish() {
            var polls = 0
            while (true) {
                check(++polls < 500) { "AAC encoder EOS timed out" }
                val index = encoder.dequeueInputBuffer(10_000)
                if (index >= 0) {
                    encoder.queueInputBuffer(index, 0, 0, queuedFrames * 1_000_000L / sampleRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(false)
            }
            var attempts = 0
            while (!encoderEos && attempts++ < 400) drain(true)
            check(encoderEos) { "AAC encoder did not finish" }
        }
        private fun drain(wait: Boolean) {
            while (true) {
                val index = encoder.dequeueOutputBuffer(info, if (wait) 10_000 else 0)
                when (index) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> return
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(!muxStarted) { "AAC encoder changed output format twice" }
                        track = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxStarted = true
                    }
                    MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                    else -> if (index >= 0) {
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0) {
                            check(muxStarted) { "AAC muxer has not started" }
                            val buffer = encoder.getOutputBuffer(index) ?: error("AAC output buffer unavailable")
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            muxer.writeSampleData(track, buffer, info)
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) encoderEos = true
                        encoder.releaseOutputBuffer(index, false)
                    }
                }
            }
        }
        override fun close() {
            runCatching { encoder.stop() }
            encoder.release()
            if (muxStarted) runCatching { muxer.stop() }
            muxer.release()
        }
    }
}
