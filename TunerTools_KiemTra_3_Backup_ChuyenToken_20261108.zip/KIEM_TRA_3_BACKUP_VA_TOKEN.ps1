#Requires -Version 5.1
<#
TunerTools: safe audit of BackupPrep, Backups, BackupScripts.
DEFAULT = READ ONLY. No files/tasks are removed.
-ApplyToken: copy the existing working Drive OAuth JSON into AI_Drive_AutoSync,
             protect it, and point SYNC_AI_DRIVE.py at it first.
-RemoveLegacyAITask: remove ONLY TunerTools_AI_Drive_Sync_15Min when the
                     replacement TunerTools_AI_Drive_AutoSync task is verified.
Never prints OAuth token values or client secrets.
#>
[CmdletBinding()]
param(
    [switch]$ApplyToken,
    [switch]$RemoveLegacyAITask
)

$ErrorActionPreference = 'Stop'
$Root = 'C:\TunerTools'
$Targets = @('BackupPrep','Backups','BackupScripts')
$SyncDir = Join-Path $Root 'Tools\AI_Drive_AutoSync'
$SyncPy = Join-Path $SyncDir 'SYNC_AI_DRIVE.py'
$TargetToken = Join-Path $SyncDir 'drive_token.json'
$ReportDir = Join-Path $Root 'Logs\Backup_Audit'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$ReportFile = Join-Path $ReportDir ("Backup_Audit_$stamp.txt")
$InventoryFile = Join-Path $ReportDir ("Backup_Files_$stamp.csv")
$Log = New-Object 'System.Collections.Generic.List[string]'
$FileRows = New-Object 'System.Collections.Generic.List[object]'
$TokenList = New-Object 'System.Collections.Generic.List[object]'
$AllFileRefs = New-Object 'System.Collections.Generic.List[object]'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal -ArgumentList $identity
$IsWindowsAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Keep a partial report even when optional credential migration fails.
trap {
    $msg = 'ERROR: ' + $_.Exception.Message
    Write-Host $msg -ForegroundColor Red
    try {
        $Log.Add($msg)
        [IO.File]::WriteAllLines($ReportFile, [string[]]$Log.ToArray(), ([System.Text.UTF8Encoding]::new($true)))
    } catch { }
    break
}

function Note([string]$message) {
    $Log.Add($message)
    Write-Host $message
}
function Validate-DriveOAuth([string]$path) {
    try {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $false }
        $f = Get-Item -LiteralPath $path
        if ($f.Length -lt 64 -or $f.Length -gt 1048576) { return $false }
        $obj = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -eq $obj) { return $false }
        $keys = @($obj.PSObject.Properties.Name)
        return (('refresh_token' -in $keys) -and ('client_id' -in $keys) -and ('client_secret' -in $keys))
    } catch { return $false }
}
function Describe-Size([long]$v) {
    if ($v -ge 1GB) { return ('{0:N2} GB' -f ($v / 1GB)) }
    if ($v -ge 1MB) { return ('{0:N2} MB' -f ($v / 1MB)) }
    if ($v -ge 1KB) { return ('{0:N2} KB' -f ($v / 1KB)) }
    return "$v bytes"
}
function Python-SyntaxCheck([string]$path) {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($null -ne $launcher) {
        & $launcher.Source -3 -c 'import ast,sys;ast.parse(open(sys.argv[1],encoding="utf-8").read())' $path
    } else {
        $interpreter = Get-Command python.exe -ErrorAction SilentlyContinue
        if ($null -eq $interpreter) { Note 'NOTE: Python not found in PATH; syntax check skipped.'; return }
        & $interpreter.Source -c 'import ast,sys;ast.parse(open(sys.argv[1],encoding="utf-8").read())' $path
    }
    if ($LASTEXITCODE -ne 0) { throw 'Python syntax check failed after update; inspect backup and do not delete old token.' }
    Note 'PYTHON SYNTAX: OK (AST parse; no __pycache__ created).'
}
function Protect-Credential([string]$path) {
    if (-not $IsWindowsAdmin) { throw 'Run PowerShell as Administrator for token migration and ACL protection.' }
    $identitySys = New-Object System.Security.Principal.SecurityIdentifier -ArgumentList 'S-1-5-18'
    $identityAdmin = New-Object System.Security.Principal.SecurityIdentifier -ArgumentList 'S-1-5-32-544'
    $acl = Get-Acl -LiteralPath $path
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($rule in @($acl.Access)) { [void]$acl.RemoveAccessRuleAll($rule) }
    foreach ($sid in @($identitySys, $identityAdmin)) {
        $access = New-Object System.Security.AccessControl.FileSystemAccessRule -ArgumentList @($sid, [System.Security.AccessControl.FileSystemRights]::FullControl, [System.Security.AccessControl.AccessControlType]::Allow)
        $acl.AddAccessRule($access)
    }
    Set-Acl -LiteralPath $path -AclObject $acl
}

New-Item -Path $ReportDir -ItemType Directory -Force | Out-Null
Note '==============================================================='
Note 'TUNERTOOLS BACKUP AUDIT: READ-ONLY UNTIL OPTIONAL ACTION FLAGS'
Note ('SERVER PATH: ' + $Root)
Note ('MODE: ApplyToken=' + $ApplyToken + ' / RemoveLegacyAITask=' + $RemoveLegacyAITask)
Note ('TIME: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Note '==============================================================='

foreach ($name in $Targets) {
    $folder = Join-Path $Root $name
    Note ''
    Note ('=== ' + $folder + ' ===')
    if (-not (Test-Path -LiteralPath $folder -PathType Container)) { Note 'NOT FOUND'; continue }
    $files = @(Get-ChildItem -LiteralPath $folder -Recurse -File -Force -ErrorAction SilentlyContinue)
    $dirs = @(Get-ChildItem -LiteralPath $folder -Recurse -Directory -Force -ErrorAction SilentlyContinue)
    $bytes = [long]0
    foreach ($f in $files) {
        $bytes += [long]$f.Length
        $FileRows.Add([pscustomobject]@{
            Root=$name; Path=$f.FullName; Bytes=$f.Length; Modified=$f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
        })
        if ($f.Extension -ieq '.json' -and $f.Length -gt 64 -and $f.Length -le 1048576) {
            if (Validate-DriveOAuth $f.FullName) {
                $TokenList.Add([pscustomobject]@{Path=$f.FullName; Bytes=$f.Length; Modified=$f.LastWriteTime})
            }
        }
    }
    Note ('FILE COUNT: ' + $files.Count + ' / DIR COUNT: ' + $dirs.Count + ' / TOTAL: ' + (Describe-Size $bytes))
    $top = @(Get-ChildItem -LiteralPath $folder -Force -ErrorAction SilentlyContinue | Sort-Object Name)
    Note ('ROOT ENTRIES: ' + $top.Count)
    foreach ($entry in @($top | Select-Object -First 60)) {
        $kind = if ($entry.PSIsContainer) { '[DIR] ' } else { '[FILE]' }
        Note ("  $kind " + $entry.Name + ' | ' + $entry.LastWriteTime.ToString('yyyy-MM-dd'))
    }
    if ($top.Count -gt 60) { Note ('  ... remaining root entries: ' + ($top.Count-60)) }
}

Note ''
Note '=== SCHEDULED TASKS REFERENCING BACKUP FOLDERS ==='
$tasks = @()
try { $tasks = @(Get-ScheduledTask -ErrorAction Stop) }
catch { Note ('WARNING: Cannot enumerate scheduled tasks: ' + $_.Exception.Message) }
$relevantTasks = @()
foreach ($task in $tasks) {
    foreach ($act in $task.Actions) {
        $actionText = [string]$act.Execute + ' ' + [string]$act.Arguments + ' ' + [string]$act.WorkingDirectory
        $refs = @($Targets | Where-Object { $actionText.IndexOf(('\' + $_), [StringComparison]::OrdinalIgnoreCase) -ge 0 })
        if ($refs.Count -gt 0) {
            $relevantTasks += $task
            Note ("TASK: $($task.TaskName) | DIRS: $($refs -join ',') | STATE: $($task.State)")
        }
    }
}
if ($relevantTasks.Count -eq 0) { Note 'NONE (does not rule out references in manual scripts or services).' }

Note ''
Note '=== WINDOWS SERVICES REFERENCING BACKUP FOLDERS ==='
try {
    $services = @(Get-CimInstance Win32_Service -ErrorAction Stop)
    $serviceCount = 0
    foreach ($service in $services) {
        $refs = @($Targets | Where-Object { ([string]$service.PathName).IndexOf(('\' + $_), [StringComparison]::OrdinalIgnoreCase) -ge 0 })
        if ($refs.Count -gt 0) {
            $serviceCount++
            Note ("SERVICE: $($service.Name) | DIRS: $($refs -join ',') | STATE: $($service.State)")
        }
    }
    if ($serviceCount -eq 0) { Note 'NONE' }
} catch { Note ('WARNING: Cannot enumerate Windows services: ' + $_.Exception.Message) }

Note ''
Note '=== SCRIPT REFERENCES TO BACKUP FOLDERS ==='
$scanRoots = @((Join-Path $Root 'Tools'), (Join-Path $Root 'BackupScripts'), (Join-Path $Root 'BackupPrep'), (Join-Path $Root 'Web'))
$scanFiles = New-Object 'System.Collections.Generic.List[object]'
foreach ($p in $scanRoots) {
    if (-not (Test-Path -LiteralPath $p -PathType Container)) { continue }
    Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue |
      Where-Object { $_.Extension -in @('.ps1','.psm1','.py','.php','.cmd','.bat','.vbs','.js','.config') -and $_.Length -le 2MB } |
      ForEach-Object { $scanFiles.Add($_) }
}
$appPy = Join-Path $Root 'Audio\AI_Music\app.py'
if (Test-Path -LiteralPath $appPy -PathType Leaf) { $scanFiles.Add((Get-Item -LiteralPath $appPy)) }
$printed = 0
foreach ($f in $scanFiles) {
    try {
        $body = [IO.File]::ReadAllText($f.FullName)
        $refs = @($Targets | Where-Object { $body.IndexOf(($_ + '\'), [StringComparison]::OrdinalIgnoreCase) -ge 0 -or $body.IndexOf(($_ + '/'), [StringComparison]::OrdinalIgnoreCase) -ge 0 })
        if ($refs.Count -gt 0) {
            $AllFileRefs.Add([pscustomobject]@{File=$f.FullName; Roots=($refs -join ',')})
            if ($printed -lt 100) { Note ("REF: $($f.FullName) -> $($refs -join ',')"); $printed++ }
        }
    } catch { }
}
if ($AllFileRefs.Count -eq 0) { Note 'No textual references found in scanned scripts.' }
if ($AllFileRefs.Count -gt 100) { Note ('  ... additional scripts with refs: ' + ($AllFileRefs.Count-100)) }
Note ('SCANNED SCRIPTS: ' + $scanFiles.Count)
Note 'NOTE: A script can still be used manually even without scheduled-task references.'

Note ''
Note '=== GOOGLE DRIVE OAUTH JSON CANDIDATES (VALUES HIDDEN) ==='
foreach ($t in $TokenList) { Note ('TOKEN: ' + $t.Path + ' | size=' + $t.Bytes + ' | has refresh/client fields=YES') }
if ($TokenList.Count -eq 0) { Note 'NO refresh-capable OAuth JSON discovered in the three backup folders.' }
if (Validate-DriveOAuth $TargetToken) { Note ('TOKEN ALREADY IN TOOLS: ' + $TargetToken) }

if ($ApplyToken) {
    Note ''
    Note '=== APPLY: STAGED TOKEN MIGRATION ==='
    if (-not $IsWindowsAdmin) { throw 'Administrator permission required for -ApplyToken.' }
    if (-not (Test-Path -LiteralPath $SyncPy -PathType Leaf)) { throw ('Sync Python not found: ' + $SyncPy) }
    $preferred = @(
        (Join-Path $Root 'BackupScripts\Drive_Buoc2D\drive_token.json'),
        (Join-Path $Root 'BackupScripts\Drive_Buoc2C\drive_token.json'),
        (Join-Path $Root 'BackupScripts\Drive_Documents\drive_token.json')
    )
    $sourceToken = $null
    foreach ($candidate in $preferred) {
        if (Validate-DriveOAuth $candidate) { $sourceToken = $candidate; break }
    }
    if ($null -eq $sourceToken -and $TokenList.Count -eq 1) { $sourceToken = $TokenList[0].Path }
    if ($null -eq $sourceToken -and -not (Validate-DriveOAuth $TargetToken)) {
        throw 'No unambiguous working OAuth token found; no changes applied. Check report.'
    }
    if ($null -ne $sourceToken) { Note ('SOURCE TOKEN: ' + $sourceToken) }
    New-Item -ItemType Directory -Path $SyncDir -Force | Out-Null
    if (Test-Path -LiteralPath $TargetToken -PathType Leaf) {
        if (-not (Validate-DriveOAuth $TargetToken)) { throw 'Target token file exists but is not valid OAuth JSON; refusing to overwrite.' }
        if ($null -ne $sourceToken) {
            $srcHash = (Get-FileHash -LiteralPath $sourceToken -Algorithm SHA256).Hash
            $dstHash = (Get-FileHash -LiteralPath $TargetToken -Algorithm SHA256).Hash
            if ($srcHash -ne $dstHash) {
                throw 'Token already exists in Tools but differs from old token. Refusing overwrite; choose token manually.'
            }
        }
        Note 'TOKEN COPY: already exists and is valid; no overwrite.'
    } elseif ($null -ne $sourceToken) {
        $tempToken = $TargetToken + '.copying_' + [guid]::NewGuid().ToString('N')
        try {
            Copy-Item -LiteralPath $sourceToken -Destination $tempToken -ErrorAction Stop
            if (-not (Validate-DriveOAuth $tempToken)) { throw 'Copied token JSON fails schema validation.' }
            $srcHash = (Get-FileHash -LiteralPath $sourceToken -Algorithm SHA256).Hash
            $tmpHash = (Get-FileHash -LiteralPath $tempToken -Algorithm SHA256).Hash
            if ($srcHash -ne $tmpHash) { throw 'Token SHA256 mismatch after copy.' }
            Protect-Credential $tempToken
            Move-Item -LiteralPath $tempToken -Destination $TargetToken -ErrorAction Stop
            Note ('TOKEN COPY: OK; SHA256 match; SYSTEM + Administrators access only.')
        } finally {
            if (Test-Path -LiteralPath $tempToken -PathType Leaf) { Remove-Item -LiteralPath $tempToken -Force }
        }
    }
    if (-not (Validate-DriveOAuth $TargetToken)) { throw 'Target token not valid after migration.' }
    Protect-Credential $TargetToken
    $src = [IO.File]::ReadAllText($SyncPy)
    $newLine = '    r"C:\TunerTools\Tools\AI_Drive_AutoSync\drive_token.json",'
    if ($src.IndexOf('C:\TunerTools\Tools\AI_Drive_AutoSync\drive_token.json', [StringComparison]::OrdinalIgnoreCase) -ge 0) {
        Note 'PYTHON CONFIG: already contains Tools token path.'
    } else {
        $pattern = '(?m)^TOKEN_DEFAULTS\s*=\s*\('
        $tokenMatches = [regex]::Matches($src, $pattern)
        if ($tokenMatches.Count -ne 1) { throw 'TOKEN_DEFAULTS marker missing/ambiguous; not editing Python script.' }
        $scriptBackupDir = Join-Path $Root 'Backups\AI_Drive_Script_PreMigration'
        New-Item -Path $scriptBackupDir -ItemType Directory -Force | Out-Null
        $backup = Join-Path $scriptBackupDir ('SYNC_AI_DRIVE_' + $stamp + '.py')
        Copy-Item -LiteralPath $SyncPy -Destination $backup -ErrorAction Stop
        $replacement = "TOKEN_DEFAULTS = (" + "`r`n" + $newLine
        $patched = $src.Substring(0, $tokenMatches[0].Index) + $replacement + $src.Substring($tokenMatches[0].Index + $tokenMatches[0].Length)
        $tmpScript = $SyncPy + '.new_' + [guid]::NewGuid().ToString('N')
        try {
            $utf8 = [System.Text.UTF8Encoding]::new($false)
            [IO.File]::WriteAllText($tmpScript, $patched, $utf8)
            Move-Item -LiteralPath $tmpScript -Destination $SyncPy -Force
        } finally {
            if (Test-Path -LiteralPath $tmpScript -PathType Leaf) { Remove-Item -LiteralPath $tmpScript -Force }
        }
        Note ('PYTHON CONFIG: Tools token path added as FIRST candidate. Backup: ' + $backup)
    }
    Python-SyntaxCheck $SyncPy
    Note 'MIGRATION STAGED: original token NOT removed from BackupScripts.'
    Note 'Check manual sync AND scheduled sync before deleting old backup folders.'
}

if ($RemoveLegacyAITask) {
    Note ''
    Note '=== REMOVE: LEGACY AI TASK ONLY ==='
    if (-not $IsWindowsAdmin) { throw 'Administrator permission required for -RemoveLegacyAITask.' }
    $newTask = Get-ScheduledTask -TaskName 'TunerTools_AI_Drive_AutoSync' -ErrorAction SilentlyContinue
    $oldTask = Get-ScheduledTask -TaskName 'TunerTools_AI_Drive_Sync_15Min' -ErrorAction SilentlyContinue
    if ($null -eq $newTask) { Note 'SKIPPED: new AI Drive task not found; leaving old task unchanged.' }
    elseif ($null -eq $oldTask) { Note 'OK: old 15-minute task already absent.' }
    else {
        $newText = (($newTask.Actions | ForEach-Object { [string]$_.Execute + ' ' + [string]$_.Arguments }) -join ' ')
        if ($newText.IndexOf('SYNC_AI_DRIVE.py',[StringComparison]::OrdinalIgnoreCase) -lt 0) {
            Note 'SKIPPED: new task does not reference SYNC_AI_DRIVE.py.'
        } else {
            Unregister-ScheduledTask -TaskName 'TunerTools_AI_Drive_Sync_15Min' -Confirm:$false -ErrorAction Stop
            Note 'REMOVED: TunerTools_AI_Drive_Sync_15Min (new task confirmed).'
        }
    }
}

$FileRows | Export-Csv -LiteralPath $InventoryFile -NoTypeInformation -Encoding UTF8
Note ''
Note ('INVENTORY CSV: ' + $InventoryFile)
Note ('AUDIT REPORT: ' + $ReportFile)
Note 'NO BackupPrep/Backups/BackupScripts directories or files were deleted.'
Note 'DO NOT share drive_token.json or OAuth token values.'
[IO.File]::WriteAllLines($ReportFile, [string[]]$Log.ToArray(), ([System.Text.UTF8Encoding]::new($true)))
