# Ledutu Auto Monitor v2.0.0

Công cụ mở Ledutu bằng một profile trình duyệt riêng và ghi lại **lưu lượng mà chính trình duyệt của người dùng nhận được** trong quá trình tạo sheet.

## Chạy

Nhấp đúp `CHAY_VA_THEO_DOI_LEDUTU.bat`.

Công cụ tự động:

1. Cài Playwright trong `.venv` ở lần đầu.
2. Mở trang Scriptor.
3. Chờ người dùng đăng nhập.
4. Tự bật ghi trước khi người dùng nhập link.
5. Nhận diện yêu cầu tạo sheet, mã generation và EventSource `/api/generations/{id}/events/`.
6. Theo dõi `queued`, `fetching`, `generating`, `uploading`, rồi tự dừng ở `completed`, `failed`, `cancelled` hoặc `expired`.
7. Tạo `CHIA_SE_VOI_CHATGPT.zip` đã che cookie, Authorization, token, email và khóa bí mật.

## Giới hạn

Công cụ không nhìn thấy lưu lượng nội bộ server-to-server. Nếu Ledutu không trả tên model hoặc phiên bản pipeline về trình duyệt, báo cáo chỉ xác nhận được kiến trúc và trạng thái xử lý, không thể chứng minh tuyệt đối model backend.

## Quyền riêng tư

Không chia sẻ `data/PRIVATE_CHROME_PROFILE_KHONG_CHIA_SE`.
