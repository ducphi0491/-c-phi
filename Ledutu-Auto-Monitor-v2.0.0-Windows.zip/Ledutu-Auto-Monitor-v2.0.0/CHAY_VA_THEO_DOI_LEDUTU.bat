@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title Ledutu Auto Monitor - Cai dat va theo doi
set "PIP_DISABLE_PIP_VERSION_CHECK=1"

color 0A
echo ============================================================================
echo  LEDUTU AUTO MONITOR v2.0.0 - CHI CAN CHAY FILE NAY
echo ============================================================================
echo  Lan dau se cai Playwright. Cac lan sau se mo thang Ledutu va theo doi.
echo.

set "PYBASE="
where py >nul 2>nul
if not errorlevel 1 (
  py -3.11 --version >nul 2>nul
  if not errorlevel 1 set "PYBASE=py -3.11"
)

if not defined PYBASE (
  where python >nul 2>nul
  if not errorlevel 1 (
    for /f "tokens=2" %%V in ('python --version 2^>^&1') do set "PYVER=%%V"
    echo !PYVER! | findstr /b "3.11" >nul 2>nul
    if not errorlevel 1 set "PYBASE=python"
  )
)

if not defined PYBASE (
  color 0C
  echo [LOI] Khong tim thay Python 3.11.
  echo May ban truoc do da cai Python 3.11; hay kiem tra lai PATH hoac Python Launcher.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/4] Tao moi truong Python rieng...
  %PYBASE% -m venv .venv
  if errorlevel 1 goto :fail
)

if not exist ".setup_complete" (
  echo [2/4] Cai Playwright...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  if errorlevel 1 goto :fail
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto :fail

  echo [3/4] Cai Chromium du phong. Neu may da co Chrome, buoc nay van giup on dinh...
  ".venv\Scripts\python.exe" -m playwright install chromium
  if errorlevel 1 (
    echo [CANH BAO] Khong tai duoc Chromium du phong. Chuong trinh van thu Google Chrome/Edge.
  )

  echo [4/4] Kiem tra noi bo...
  ".venv\Scripts\python.exe" ledutu_auto_monitor.py --self-test
  if errorlevel 1 goto :fail
  > ".setup_complete" echo setup_ok_v2.0.0
  echo [OK] Cai dat hoan tat.
  echo.
)

".venv\Scripts\python.exe" ledutu_auto_monitor.py
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  color 0C
  echo Chuong trinh ket thuc voi ma loi %RC%.
) else (
  color 0A
  echo Da tao file CHIA_SE_VOI_CHATGPT.zip trong thu muc ket_qua.
)
pause
exit /b %RC%

:fail
color 0C
echo.
echo [LOI] Cai dat chua hoan tat. Hay chup toan bo cua so nay gui lai.
pause
exit /b 1
