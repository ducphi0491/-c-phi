@echo off
setlocal
cd /d "%~dp0"
echo File nay se xoa profile Chrome rieng va phien dang nhap Ledutu da luu.
choice /c YN /m "Ban co chac muon xoa"
if errorlevel 2 exit /b 0
if exist "data\PRIVATE_CHROME_PROFILE_KHONG_CHIA_SE" (
  rmdir /s /q "data\PRIVATE_CHROME_PROFILE_KHONG_CHIA_SE"
  echo Da xoa.
) else (
  echo Khong tim thay profile rieng.
)
pause
