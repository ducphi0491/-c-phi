from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

APP_NAME = "Ledutu Auto Monitor"
APP_VERSION = "2.0.0"
DEFAULT_URL = "https://ledutu.com/account/scriptor"

KNOWN_STATUSES = {
    "queued",
    "fetching",
    "generating",
    "uploading",
    "completed",
    "failed",
    "cancelled",
    "expired",
}
RUNNING_STATUSES = {"queued", "fetching", "generating", "uploading"}
TERMINAL_STATUSES = {"completed", "failed", "cancelled", "expired"}
FEATURE_TERMS = {
    "piano_transcription",
    "piano_arrangement",
    "lead_sheet",
    "guitar_transcription",
    "guitar_lick",
    "bass_transcription",
    "drum_transcription",
    "bandsheet",
}

SENSITIVE_KEY_RE = re.compile(
    r"(?:password|passwd|passcode|secret|token|access[_-]?token|refresh[_-]?token|"
    r"authorization|cookie|set-cookie|csrf|xsrf|session|credential|api[_-]?key|"
    r"email|phone|otp|verification[_-]?code|signature|signed[_-]?url)",
    re.IGNORECASE,
)
SENSITIVE_HEADERS = {
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "x-csrf-token",
    "x-xsrf-token",
    "cf-clearance",
}
JWT_RE = re.compile(r"\beyJ[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9_-]{8,}\b")
BEARER_RE = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}")
EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
LONG_SECRET_RE = re.compile(r"(?<![A-Za-z0-9])[A-Za-z0-9_-]{40,}(?![A-Za-z0-9])")
INLINE_QUERY_SECRET_RE = re.compile(
    r"(?i)([?&](?:token|access_token|refresh_token|signature|x-amz-signature|"
    r"x-amz-credential|x-amz-security-token|key|api_key|apikey)=)[^&\s\"'<>]+"
)

NOISE_HOST_PARTS = (
    "google-analytics.com",
    "googletagmanager.com",
    "doubleclick.net",
    "googlesyndication.com",
    "cloudflareinsights.com",
    "ahrefs.com",
    "facebook.net",
    "clarity.ms",
)

MODEL_TERMS = (
    "basic-pitch",
    "basic_pitch",
    "demucs",
    "htdemucs",
    "htdemucs_ft",
    "mdx",
    "mdx-net",
    "spleeter",
    "open-unmix",
    "openunmix",
    "mt3",
    "magenta",
    "omnizart",
    "music21",
    "tensorflow",
    "tensorflow-lite",
    "tflite",
    "pytorch",
    "torchscript",
    "onnxruntime",
    "onnx",
    "transformer",
    "transkun",
    "replicate",
    "runpod",
    "modal.com",
    "huggingface",
    "fal.ai",
    "vertex ai",
    "sagemaker",
    "azure ml",
)

METADATA_KEY_RE = re.compile(
    r"(?:^|_)(?:model|model_name|model_id|model_version|engine|engine_version|provider|"
    r"pipeline|pipeline_version|runtime|framework|worker|worker_type|backend|"
    r"failed_stage|stage|stem|separator|transcriber|inference)(?:$|_)",
    re.IGNORECASE,
)

TEXT_CONTENT_TYPES = (
    "application/json",
    "application/problem+json",
    "text/plain",
    "text/event-stream",
    "application/xml",
    "text/xml",
    "text/x-component",
    "application/x-ndjson",
    "application/graphql-response+json",
)

GENERATION_URL_RE = re.compile(r"/api/(?:admin/)?generations/([^/?#]+)/", re.IGNORECASE)
GENERATION_PAGE_RE = re.compile(r"/(?:account/)?generations?/([^/?#]+)", re.IGNORECASE)
STATUS_RE = re.compile(
    r"[\\\"]?status[\\\"]?\s*[:=]\s*[\\\"]?(queued|fetching|generating|uploading|completed|failed|cancelled|expired)",
    re.IGNORECASE,
)
ID_RE = re.compile(
    r"[\\\"]?(?:id|job_id|generation_id)[\\\"]?\s*[:=]\s*[\\\"]([A-Za-z0-9_-]{4,80})[\\\"]",
    re.IGNORECASE,
)


def configure_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def safe_text(value: str, max_len: int = 200_000) -> str:
    value = JWT_RE.sub("[REDACTED_JWT]", value)
    value = BEARER_RE.sub("Bearer [REDACTED]", value)
    value = EMAIL_RE.sub("[REDACTED_EMAIL]", value)
    value = INLINE_QUERY_SECRET_RE.sub(r"\1[REDACTED]", value)
    value = LONG_SECRET_RE.sub("[REDACTED_SECRET]", value)
    if len(value) > max_len:
        value = value[:max_len] + f"\n...[TRUNCATED {len(value) - max_len} chars]"
    return value


def sanitize_url(url: str) -> str:
    try:
        parts = urlsplit(url)
        items: list[tuple[str, str]] = []
        for key, value in parse_qsl(parts.query, keep_blank_values=True):
            clean = "[REDACTED]" if SENSITIVE_KEY_RE.search(key) else safe_text(value, 1000)
            items.append((key, clean))
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(items, doseq=True), ""))
    except Exception:
        return safe_text(url, 4000)


def sanitize_headers(headers: dict[str, Any] | None) -> dict[str, str]:
    result: dict[str, str] = {}
    for key, value in (headers or {}).items():
        key_text = str(key)
        lower = key_text.lower()
        if lower in SENSITIVE_HEADERS or SENSITIVE_KEY_RE.search(lower):
            result[key_text] = "[REDACTED]"
        else:
            result[key_text] = safe_text(str(value), 4000)
    return result


def sanitize_obj(value: Any, key_hint: str = "") -> Any:
    if SENSITIVE_KEY_RE.search(key_hint):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): sanitize_obj(v, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitize_obj(v, key_hint) for v in value[:5000]]
    if isinstance(value, tuple):
        return [sanitize_obj(v, key_hint) for v in value[:5000]]
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith(("http://", "https://")):
            return sanitize_url(value)
        return safe_text(value)
    return value


def parse_and_sanitize_body(text: str) -> Any:
    text = safe_text(text)
    stripped = text.strip()
    if not stripped:
        return ""
    if stripped[0] in "[{":
        try:
            return sanitize_obj(json.loads(stripped))
        except Exception:
            pass
    return text


def host_of(url: str) -> str:
    try:
        return (urlsplit(url).hostname or "").lower()
    except Exception:
        return ""


def path_of(url: str) -> str:
    try:
        return urlsplit(url).path.lower()
    except Exception:
        return ""


def is_ledutu_host(host: str) -> bool:
    return host == "ledutu.com" or host.endswith(".ledutu.com")


def is_noise_host(host: str) -> bool:
    return any(part in host for part in NOISE_HOST_PARTS)


def is_interesting(url: str, resource_type: str = "", method: str = "GET") -> bool:
    host = host_of(url)
    path = path_of(url)
    rtype = (resource_type or "").lower()
    method = method.upper()
    if not host or is_noise_host(host):
        return False
    if is_ledutu_host(host):
        if method != "GET" and rtype in {"xhr", "fetch", "document", "eventsource"}:
            return True
        if any(x in path for x in ("/api/", "generation", "scriptor", "event", "download", "upload")):
            return True
        return rtype in {"xhr", "fetch", "eventsource", "websocket"}
    return rtype in {"xhr", "fetch", "eventsource", "websocket"}


def flatten_for_scan(value: Any, prefix: str = "") -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    if isinstance(value, dict):
        for key, item in value.items():
            child = f"{prefix}.{key}" if prefix else str(key)
            out.extend(flatten_for_scan(item, child))
    elif isinstance(value, list):
        for idx, item in enumerate(value[:1000]):
            out.extend(flatten_for_scan(item, f"{prefix}[{idx}]"))
    elif value is not None:
        out.append((prefix, str(value)))
    return out


def iter_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from iter_dicts(item)
    elif isinstance(value, list):
        for item in value:
            yield from iter_dicts(item)


def extract_snapshots(value: Any) -> list[dict[str, Any]]:
    snapshots: list[dict[str, Any]] = []
    for item in iter_dicts(value):
        status = str(item.get("status", "")).lower()
        raw_id = item.get("id", item.get("job_id", item.get("generation_id")))
        if status in KNOWN_STATUSES and raw_id is not None:
            snapshots.append(sanitize_obj(item))
    if isinstance(value, str):
        normalized = value.replace('\\"', '"')
        statuses = list(STATUS_RE.finditer(normalized))
        ids = list(ID_RE.finditer(normalized))
        for sm in statuses:
            nearest_id = None
            nearest_distance = 10**9
            for im in ids:
                distance = abs(im.start() - sm.start())
                if distance < nearest_distance and distance <= 2500:
                    nearest_distance = distance
                    nearest_id = im.group(1)
            if nearest_id:
                snapshots.append({"id": nearest_id, "status": sm.group(1).lower(), "raw_text_match": True})
    return snapshots


def job_id_from_url(url: str) -> str | None:
    path = path_of(url)
    match = GENERATION_URL_RE.search(path)
    if match:
        return match.group(1)
    match = GENERATION_PAGE_RE.search(path)
    if match:
        candidate = match.group(1)
        if candidate not in {"new", "create", "scriptor"}:
            return candidate
    return None


def body_has_feature(body: Any) -> bool:
    text = body if isinstance(body, str) else json.dumps(body, ensure_ascii=False, default=str)
    lower = text.lower()
    return any(term in lower for term in FEATURE_TERMS)


def windows_enter_pressed() -> bool:
    if os.name != "nt":
        return False
    try:
        import msvcrt

        pressed = False
        while msvcrt.kbhit():
            char = msvcrt.getwch()
            if char in {"\r", "\n"}:
                pressed = True
        return pressed
    except Exception:
        return False


class Monitor:
    def __init__(self, root: Path, output_root: Path) -> None:
        self.root = root
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        self.session_dir = output_root / f"ledutu-monitor-{stamp}"
        self.responses_dir = self.session_dir / "responses"
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.responses_dir.mkdir(parents=True, exist_ok=True)
        self.events_path = self.session_dir / "events_sanitized.jsonl"
        self.evidence_path = self.session_dir / "evidence.json"
        self.summary_path = self.session_dir / "BAO_CAO_CHIA_SE.txt"
        self.final_snapshot_path = self.session_dir / "final_job_snapshot.json"

        self.capture_enabled = False
        self.capture_started_monotonic: float | None = None
        self.events_count: Counter[str] = Counter()
        self.status_count: Counter[str] = Counter()
        self.host_count: Counter[str] = Counter()
        self.endpoint_count: Counter[str] = Counter()
        self.evidence: list[dict[str, Any]] = []
        self._evidence_seen: set[str] = set()
        self._response_seq = 0
        self._pending_tasks: set[asyncio.Task[Any]] = set()
        self._cdp_request_map: dict[str, tuple[str, str, str]] = {}
        self._attached_pages: set[int] = set()
        self.errors: list[str] = []

        self.baseline_job_ids: set[str] = set()
        self.job_ids_seen: set[str] = set()
        self.creation_request_seen = False
        self.creation_request_time: float | None = None
        self.creation_request_url: str | None = None
        self.active_job_id: str | None = None
        self.active_job_status: str | None = None
        self.final_snapshot: dict[str, Any] | None = None
        self.status_timeline: list[dict[str, Any]] = []
        self.terminal_event = asyncio.Event()
        self.job_detected_event = asyncio.Event()
        self.last_activity_monotonic = time.monotonic()

    def begin_capture(self, page_url: str) -> None:
        self.capture_enabled = True
        self.capture_started_monotonic = time.monotonic()
        self.write_event("capture_started", {"url": sanitize_url(page_url), "app_version": APP_VERSION})

    def spawn(self, coro: Any) -> None:
        task = asyncio.create_task(coro)
        self._pending_tasks.add(task)
        task.add_done_callback(self._pending_tasks.discard)

    def write_event(self, kind: str, data: dict[str, Any]) -> None:
        if not self.capture_enabled:
            return
        record = {"time_utc": utc_now_iso(), "kind": kind, **sanitize_obj(data)}
        self.events_count[kind] += 1
        self.last_activity_monotonic = time.monotonic()
        url = str(record.get("url", ""))
        if url:
            host = host_of(url)
            path = path_of(url)
            if host:
                self.host_count[host] += 1
            if path:
                self.endpoint_count[f"{host}{path}"] += 1
        if "http_status" in record:
            self.status_count[str(record["http_status"])] += 1
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
        self.scan_evidence(kind, record)

    def scan_evidence(self, source: str, value: Any) -> None:
        for key, text in flatten_for_scan(value):
            lower = text.lower()
            hits = sorted({term for term in MODEL_TERMS if term in lower})
            explicit = bool(key and METADATA_KEY_RE.search(key))
            if not hits and not explicit:
                continue
            snippet = safe_text(text, 700)
            fingerprint = hashlib.sha256(f"{source}|{key}|{snippet}".encode("utf-8", "ignore")).hexdigest()
            if fingerprint in self._evidence_seen:
                continue
            self._evidence_seen.add(fingerprint)
            self.evidence.append(
                {
                    "time_utc": utc_now_iso(),
                    "source": source,
                    "field": key,
                    "matched_terms": hits,
                    "value": snippet,
                    "explicit_metadata_field": explicit,
                }
            )

    def mark_creation_request(self, url: str, method: str, body: Any, headers: dict[str, Any]) -> None:
        if self.active_job_id or method.upper() != "POST":
            return
        path = path_of(url)
        clean_headers = {str(k).lower(): str(v) for k, v in headers.items()}
        exact_generation_post = path.rstrip("/") == "/api/generations"
        server_action_on_scriptor = "scriptor" in path and "next-action" in clean_headers
        feature_present = body_has_feature(body)
        if exact_generation_post or (server_action_on_scriptor and feature_present) or feature_present:
            if not self.creation_request_seen:
                self.creation_request_seen = True
                self.creation_request_time = time.monotonic()
                self.creation_request_url = sanitize_url(url)
                self.write_event(
                    "generation_creation_request_detected",
                    {
                        "url": sanitize_url(url),
                        "method": method,
                        "feature_term_found": feature_present,
                        "next_action": clean_headers.get("next-action", ""),
                    },
                )
                print("[PHAT HIEN] Ban da gui yeu cau tao sheet. Dang tim ma tac vu...")

    def observe_payload(
        self,
        source: str,
        value: Any,
        *,
        url: str = "",
        response_to_post: bool = False,
    ) -> None:
        self.scan_evidence(source, value)
        url_job_id = job_id_from_url(url) if url else None
        snapshots = extract_snapshots(value)

        if url_job_id and not snapshots:
            status_match = STATUS_RE.search(str(value).replace('\\"', '"')) if isinstance(value, str) else None
            if status_match:
                snapshots.append({"id": url_job_id, "status": status_match.group(1).lower()})

        for snapshot in snapshots:
            raw_id = snapshot.get("id", snapshot.get("job_id", snapshot.get("generation_id")))
            status = str(snapshot.get("status", "")).lower()
            if raw_id is None or status not in KNOWN_STATUSES:
                continue
            job_id = str(raw_id)
            self.job_ids_seen.add(job_id)

            if not self.creation_request_seen and not self.active_job_id:
                self.baseline_job_ids.add(job_id)
                continue

            if not self.active_job_id:
                new_job = job_id not in self.baseline_job_ids
                running_status = status in RUNNING_STATUSES
                url_matches = url_job_id == job_id if url_job_id else False
                if new_job and (running_status or url_matches):
                    self.active_job_id = job_id
                    self.job_detected_event.set()
                    self.write_event(
                        "active_generation_detected",
                        {
                            "job_id": job_id,
                            "status": status,
                            "source": source,
                            "url": sanitize_url(url) if url else "",
                        },
                    )
                    print(f"[DA NHAN DIEN] Ma tac vu: {job_id}")

            if self.active_job_id != job_id:
                continue

            if self.active_job_status != status:
                self.active_job_status = status
                entry = {
                    "time_utc": utc_now_iso(),
                    "job_id": job_id,
                    "status": status,
                    "source": source,
                    "url": sanitize_url(url) if url else "",
                }
                self.status_timeline.append(entry)
                self.write_event("generation_status_changed", entry)
                print(f"[TRANG THAI] {status}")

            self.final_snapshot = sanitize_obj(snapshot)
            if status in TERMINAL_STATUSES:
                self.terminal_event.set()

    async def handle_request(self, request: Any) -> None:
        if not self.capture_enabled or not is_interesting(request.url, request.resource_type, request.method):
            return
        post_data: Any = None
        try:
            if request.post_data:
                post_data = parse_and_sanitize_body(request.post_data)
        except Exception as exc:
            post_data = f"[UNAVAILABLE: {exc}]"
        headers = dict(request.headers)
        self.mark_creation_request(request.url, request.method, post_data, headers)
        self.write_event(
            "request",
            {
                "method": request.method,
                "url": sanitize_url(request.url),
                "resource_type": request.resource_type,
                "headers": sanitize_headers(headers),
                "post_data": post_data,
            },
        )
        job_id = job_id_from_url(request.url)
        if job_id and self.creation_request_seen and not self.active_job_id and job_id not in self.baseline_job_ids:
            if "/events/" in path_of(request.url):
                self.active_job_id = job_id
                self.job_detected_event.set()
                self.write_event("active_generation_detected_from_events_url", {"job_id": job_id, "url": sanitize_url(request.url)})
                print(f"[DA NHAN DIEN] Ma tac vu: {job_id}")

    async def handle_response(self, response: Any) -> None:
        request = response.request
        if not self.capture_enabled or not is_interesting(response.url, request.resource_type, request.method):
            return
        try:
            raw_headers = await response.all_headers()
        except Exception:
            raw_headers = dict(response.headers)
        headers = sanitize_headers(raw_headers)
        content_type = headers.get("content-type", headers.get("Content-Type", "")).lower()
        self.write_event(
            "response",
            {
                "http_status": response.status,
                "status_text": response.status_text,
                "url": sanitize_url(response.url),
                "resource_type": request.resource_type,
                "request_method": request.method,
                "headers": headers,
            },
        )
        self.observe_payload("response_headers", headers, url=response.url, response_to_post=request.method.upper() == "POST")
        if request.resource_type == "eventsource":
            return
        if not any(ct in content_type for ct in TEXT_CONTENT_TYPES):
            return
        try:
            raw = await response.body()
            if len(raw) > 4_000_000:
                self.write_event(
                    "response_body_skipped",
                    {"url": sanitize_url(response.url), "reason": "body > 4 MB", "size": len(raw)},
                )
                return
            charset = "utf-8"
            match = re.search(r"charset=([^;\s]+)", content_type)
            if match:
                charset = match.group(1).strip('"\'')
            text = raw.decode(charset, errors="replace")
            sanitized = parse_and_sanitize_body(text)
            self.observe_payload(
                "response_body",
                sanitized,
                url=response.url,
                response_to_post=request.method.upper() == "POST",
            )
            self._response_seq += 1
            digest = hashlib.sha1(response.url.encode("utf-8", "ignore")).hexdigest()[:10]
            suffix = ".json" if isinstance(sanitized, (dict, list)) else ".txt"
            name = f"{self._response_seq:04d}_{response.status}_{digest}{suffix}"
            target = self.responses_dir / name
            if isinstance(sanitized, (dict, list)):
                target.write_text(json.dumps(sanitized, ensure_ascii=False, indent=2), encoding="utf-8")
            else:
                target.write_text(str(sanitized), encoding="utf-8")
            self.write_event(
                "response_body",
                {
                    "url": sanitize_url(response.url),
                    "http_status": response.status,
                    "saved_file": f"responses/{name}",
                    "preview": sanitize_obj(sanitized),
                },
            )
        except Exception as exc:
            self.write_event(
                "response_body_error",
                {"url": sanitize_url(response.url), "error": safe_text(str(exc), 2000)},
            )

    async def handle_request_failed(self, request: Any) -> None:
        if not self.capture_enabled or not is_interesting(request.url, request.resource_type, request.method):
            return
        self.write_event(
            "request_failed",
            {
                "method": request.method,
                "url": sanitize_url(request.url),
                "resource_type": request.resource_type,
                "failure": request.failure,
            },
        )

    async def attach_page(self, page: Any) -> None:
        identity = id(page)
        if identity in self._attached_pages:
            return
        self._attached_pages.add(identity)
        page.on(
            "console",
            lambda msg: self.write_event(
                "console",
                {"type": msg.type, "text": safe_text(msg.text, 5000), "page_url": sanitize_url(page.url)},
            )
            if self.capture_enabled and msg.type in {"error", "warning", "warn"}
            else None,
        )
        page.on(
            "pageerror",
            lambda exc: self.write_event(
                "page_error", {"error": safe_text(str(exc), 5000), "page_url": sanitize_url(page.url)}
            ),
        )
        page.on("websocket", lambda ws: self.attach_websocket(ws))
        page.on("framenavigated", lambda frame: self.observe_navigation(frame.url) if frame == page.main_frame else None)
        try:
            cdp = await page.context.new_cdp_session(page)
            await cdp.send("Network.enable", {"maxTotalBufferSize": 50_000_000, "maxResourceBufferSize": 5_000_000})

            def on_cdp_request(params: dict[str, Any]) -> None:
                req = params.get("request", {})
                url = str(req.get("url", ""))
                rtype = str(params.get("type", ""))
                method = str(req.get("method", "GET"))
                self._cdp_request_map[str(params.get("requestId", ""))] = (url, rtype, method)

            def on_sse(params: dict[str, Any]) -> None:
                if not self.capture_enabled:
                    return
                request_id = str(params.get("requestId", ""))
                url, rtype, method = self._cdp_request_map.get(request_id, ("", "EventSource", "GET"))
                if url and not is_interesting(url, rtype, method):
                    return
                payload = parse_and_sanitize_body(str(params.get("data", "")))
                self.write_event(
                    "eventsource_message",
                    {
                        "url": sanitize_url(url),
                        "event_name": params.get("eventName", ""),
                        "event_id": params.get("eventId", ""),
                        "data": payload,
                    },
                )
                self.observe_payload("eventsource_message", payload, url=url)

            cdp.on("Network.requestWillBeSent", on_cdp_request)
            cdp.on("Network.eventSourceMessageReceived", on_sse)
        except Exception as exc:
            self.errors.append(f"CDP unavailable for {page.url}: {exc}")

    def observe_navigation(self, url: str) -> None:
        if not self.capture_enabled:
            return
        self.write_event("navigation", {"url": sanitize_url(url)})
        candidate = job_id_from_url(url)
        if candidate and self.creation_request_seen and not self.active_job_id and candidate not in self.baseline_job_ids:
            self.active_job_id = candidate
            self.job_detected_event.set()
            self.write_event("active_generation_detected_from_navigation", {"job_id": candidate, "url": sanitize_url(url)})
            print(f"[DA NHAN DIEN] Ma tac vu: {candidate}")

    def attach_websocket(self, ws: Any) -> None:
        if not self.capture_enabled or not is_interesting(ws.url, "websocket", "GET"):
            return
        self.write_event("websocket_open", {"url": sanitize_url(ws.url)})
        ws.on(
            "framesent",
            lambda payload: self.write_event(
                "websocket_sent", {"url": sanitize_url(ws.url), "payload": parse_and_sanitize_body(str(payload))}
            ),
        )

        def on_received(payload: Any) -> None:
            clean = parse_and_sanitize_body(str(payload))
            self.write_event("websocket_received", {"url": sanitize_url(ws.url), "payload": clean})
            self.observe_payload("websocket_received", clean, url=ws.url)

        ws.on("framereceived", on_received)
        ws.on("close", lambda: self.write_event("websocket_close", {"url": sanitize_url(ws.url)}))

    async def drain_tasks(self, timeout: float = 20.0) -> None:
        if not self._pending_tasks:
            return
        done, pending = await asyncio.wait(self._pending_tasks, timeout=timeout)
        for task in pending:
            task.cancel()
        for task in done:
            try:
                task.result()
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                self.errors.append(f"Task error: {exc}")

    def build_summary(self, start_time: float, final_page_url: str, stop_reason: str) -> None:
        exact = [e for e in self.evidence if e.get("explicit_metadata_field")]
        terms = Counter(term for e in self.evidence for term in e.get("matched_terms", []))
        external_hosts = [
            (h, c) for h, c in self.host_count.most_common() if not is_ledutu_host(h)
        ]
        lines = [
            f"{APP_NAME} v{APP_VERSION}",
            "=" * 76,
            f"Thoi diem ket thuc UTC: {utc_now_iso()}",
            f"Thoi gian theo doi: {time.time() - start_time:.1f} giay",
            f"Ly do dung: {stop_reason}",
            f"Trang cuoi: {sanitize_url(final_page_url)}",
            f"Ma tac vu: {self.active_job_id or 'KHONG NHAN DIEN DUOC'}",
            f"Trang thai cuoi: {self.active_job_status or 'KHONG RO'}",
            "",
            "PHAM VI VA BAO MAT",
            "- Theo doi luu luong ma trinh duyet cua phien dang nhap nhan duoc.",
            "- Cookie, Authorization, token, email va khoa bi mat da duoc che.",
            "- Khong the nhin thay luu luong server-to-server neu Ledutu khong tra metadata ve trinh duyet.",
            "- Khong tu dong dang nhap, khong tu dong bam tao, khong truy cap endpoint quan tri.",
            "",
            "TIEN TRINH TAC VU",
        ]
        if self.status_timeline:
            for item in self.status_timeline:
                lines.append(f"- {item['time_utc']} | {item['status']} | {item['source']}")
        else:
            lines.append("- Khong trich xuat duoc timeline trang thai.")

        lines += ["", "THONG KE SU KIEN"]
        if self.events_count:
            lines.extend(f"- {k}: {v}" for k, v in self.events_count.most_common())
        else:
            lines.append("- Khong ghi nhan duoc su kien phu hop.")

        lines += ["", "MA HTTP"]
        if self.status_count:
            lines.extend(f"- {k}: {v}" for k, v in self.status_count.most_common())
        else:
            lines.append("- Khong co")

        lines += ["", "HOST NGOAI LEDUTU DUOC GOI TRUC TIEP"]
        if external_hosts:
            lines.extend(f"- {h}: {c}" for h, c in external_hosts)
        else:
            lines.append("- Khong thay host API ngoai mien trong phien nay.")

        lines += ["", "ENDPOINT NOI BAT"]
        if self.endpoint_count:
            for endpoint, count in self.endpoint_count.most_common(40):
                lines.append(f"- {count:4d}  {endpoint}")
        else:
            lines.append("- Khong co")

        lines += ["", "DAU VET MODEL / PIPELINE"]
        if terms:
            lines.extend(f"- {term}: {count} lan" for term, count in terms.most_common())
        else:
            lines.append("- Chua thay ten model hoac thu vien cu the trong du lieu trinh duyet nhan duoc.")

        lines += ["", "TRUONG METADATA DANG CHU Y"]
        if exact:
            for item in exact[:150]:
                lines.append(f"- {item['source']} | {item['field']} = {item['value']}")
        else:
            lines.append("- Khong thay model_name/model_version/engine/provider/pipeline ro rang.")

        if self.errors:
            lines += ["", "CANH BAO KY THUAT"]
            lines.extend(f"- {safe_text(err, 2000)}" for err in self.errors)

        lines += [
            "",
            "CACH DOC KET QUA",
            "- Co model_name/model_version/engine/provider cu the: bang chung manh.",
            "- Chi co stem/stage/error_code: xac nhan kien truc pipeline, chua xac nhan ten model.",
            "- Khong co metadata: backend da che; can so sanh dau van tay dau ra hoac hoi nha phat trien.",
        ]
        self.summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        self.evidence_path.write_text(json.dumps(self.evidence, ensure_ascii=False, indent=2), encoding="utf-8")
        if self.final_snapshot is not None:
            self.final_snapshot_path.write_text(
                json.dumps(self.final_snapshot, ensure_ascii=False, indent=2), encoding="utf-8"
            )

    def build_share_zip(self) -> Path:
        target = self.session_dir / "CHIA_SE_VOI_CHATGPT.zip"
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path in [self.summary_path, self.evidence_path, self.events_path, self.final_snapshot_path]:
                if path.exists():
                    zf.write(path, path.relative_to(self.session_dir))
            if self.responses_dir.exists():
                for path in sorted(self.responses_dir.rglob("*")):
                    if path.is_file():
                        zf.write(path, path.relative_to(self.session_dir))
        return target


def self_test() -> int:
    sample = {
        "email": "test@example.com",
        "model_name": "htdemucs_ft",
        "headers": {"Authorization": "Bearer abcdefghijklmnopqrstuvwxyz", "Server": "cloudflare"},
        "access_token": "eyJ1234567890.abcdefghijklmno.abcdefghijklmno",
        "signed_url": "https://x.test/file?token=verysecretvalue&x=1",
    }
    clean = sanitize_obj(sample)
    assert clean["email"] == "[REDACTED]"
    assert clean["access_token"] == "[REDACTED]"
    assert clean["signed_url"] == "[REDACTED]"
    assert sanitize_headers(sample["headers"])["Authorization"] == "[REDACTED]"
    assert "token=%5BREDACTED%5D" in sanitize_url("https://ledutu.com/api/x?token=abc&job=1")
    assert is_interesting("https://ledutu.com/api/generations/1/events/", "eventsource", "GET")
    assert not is_interesting("https://www.google-analytics.com/g/collect", "fetch", "POST")
    snaps = extract_snapshots({"data": {"id": "abc123", "status": "queued", "model_name": "x"}})
    assert snaps and snaps[0]["id"] == "abc123"
    text_snaps = extract_snapshots(r'{\"id\":\"job789\",\"status\":\"completed\"}')
    assert text_snaps and text_snaps[0]["status"] == "completed"
    assert job_id_from_url("https://ledutu.com/api/generations/abc-123/events/") == "abc-123"
    assert body_has_feature({"feature": "lead_sheet"})
    print("SELF-TEST PASS")
    return 0


async def wait_for_scriptor(context: Any, timeout_seconds: int) -> Any:
    started = time.monotonic()
    last_notice = 0.0
    while time.monotonic() - started < timeout_seconds:
        for page in reversed(context.pages):
            if page.is_closed():
                continue
            url = page.url
            if is_ledutu_host(host_of(url)) and "scriptor" in path_of(url):
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=15_000)
                except Exception:
                    pass
                await asyncio.sleep(2.0)
                return page
        if time.monotonic() - last_notice > 15:
            print("[CHO] Hay dang nhap Ledutu va mo trang Scriptor trong cua so Chrome...")
            last_notice = time.monotonic()
        await asyncio.sleep(1.0)
    raise TimeoutError("Khong thay trang Scriptor trong thoi gian cho.")


async def launch_context(pw: Any, private_profile: Path) -> tuple[Any, str]:
    options = dict(
        user_data_dir=str(private_profile),
        headless=False,
        accept_downloads=True,
        viewport=None,
        args=["--start-maximized"],
    )
    errors: list[str] = []
    for channel, label in (("chrome", "Google Chrome"), ("msedge", "Microsoft Edge"), (None, "Playwright Chromium")):
        try:
            if channel:
                context = await pw.chromium.launch_persistent_context(channel=channel, **options)
            else:
                context = await pw.chromium.launch_persistent_context(**options)
            return context, label
        except Exception as exc:
            errors.append(f"{label}: {exc}")
    raise RuntimeError("Khong mo duoc trinh duyet. " + " | ".join(errors))


def open_folder(path: Path) -> None:
    try:
        if os.name == "nt":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


async def run_monitor(args: argparse.Namespace) -> int:
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        print("[LOI] Chua cai Playwright. Hay chay file BAT chinh de tu cai dat.")
        return 2

    root = Path(__file__).resolve().parent
    output_root = root / "ket_qua"
    private_profile = root / "data" / "PRIVATE_CHROME_PROFILE_KHONG_CHIA_SE"
    private_profile.mkdir(parents=True, exist_ok=True)
    monitor = Monitor(root, output_root)
    start_time = time.time()
    stop_reason = "unknown"
    final_url = args.url

    print("=" * 76)
    print(f" {APP_NAME} v{APP_VERSION}")
    print("=" * 76)
    print("1. Chrome se mo trang Ledutu Scriptor.")
    print("2. Neu chua dang nhap, ban dang nhap thu cong.")
    print("3. Khi Scriptor san sang, cong cu tu BAT DAU ghi truoc khi ban dan link.")
    print("4. Cong cu tu dung khi tac vu completed/failed/cancelled/expired.")
    print("5. Neu Ledutu thay doi API va khong tu dung, nhan ENTER trong cua so nay.")
    print()
    print("KHONG chia se thu muc data/PRIVATE_CHROME_PROFILE_KHONG_CHIA_SE.")

    async with async_playwright() as pw:
        try:
            context, browser_label = await launch_context(pw, private_profile)
        except Exception as exc:
            print(f"[LOI] {exc}")
            print("Hay ket noi Internet va chay lai file BAT de cai Chromium du phong.")
            return 3

        print(f"[OK] Da mo {browser_label} bang profile rieng.")
        context.on("request", lambda req: monitor.spawn(monitor.handle_request(req)))
        context.on("response", lambda res: monitor.spawn(monitor.handle_response(res)))
        context.on("requestfailed", lambda req: monitor.spawn(monitor.handle_request_failed(req)))
        context.on("page", lambda p: monitor.spawn(monitor.attach_page(p)))

        pages = context.pages
        page = pages[0] if pages else await context.new_page()
        for current_page in context.pages:
            await monitor.attach_page(current_page)

        try:
            await page.goto(args.url, wait_until="domcontentloaded", timeout=120_000)
        except Exception as exc:
            print(f"[CANH BAO] Khong mo duoc URL tu dong: {exc}")
            print("Ban co the tu nhap ledutu.com trong cua so trinh duyet vua mo.")

        try:
            page = await wait_for_scriptor(context, args.login_timeout_minutes * 60)
        except TimeoutError as exc:
            print(f"[LOI] {exc}")
            await context.close()
            return 4

        await monitor.attach_page(page)
        monitor.begin_capture(page.url)
        print()
        print("[SAN SANG] Da bat theo doi. BAY GIO ban hay dan link va bam tao sheet.")
        print("[LUU Y] Giu cua so Chrome va cua so den nay mo cho den khi co ket qua.")
        print()

        deadline = time.monotonic() + args.max_hours * 3600
        while True:
            if monitor.terminal_event.is_set():
                stop_reason = f"terminal_status:{monitor.active_job_status}"
                print(f"[HOAN TAT] Tac vu da o trang thai {monitor.active_job_status}.")
                print(f"Dang ghi them {args.grace_seconds} giay de lay cac response ket qua...")
                await asyncio.sleep(args.grace_seconds)
                break
            if windows_enter_pressed():
                stop_reason = "manual_enter"
                print("[DUNG THU CONG] Da nhan ENTER.")
                await asyncio.sleep(2.0)
                break
            if not any(not current_page.is_closed() for current_page in context.pages):
                stop_reason = "browser_closed"
                print("[DUNG] Cua so trinh duyet da dong.")
                break
            if time.monotonic() >= deadline:
                stop_reason = "max_timeout"
                print("[HET THOI GIAN] Da dat gioi han theo doi.")
                break
            await asyncio.sleep(0.5)

        live_pages = [current_page for current_page in context.pages if not current_page.is_closed()]
        if live_pages:
            final_url = live_pages[-1].url
        monitor.write_event(
            "capture_stopping",
            {
                "url": sanitize_url(final_url),
                "reason": stop_reason,
                "job_id": monitor.active_job_id or "",
                "job_status": monitor.active_job_status or "",
            },
        )
        await monitor.drain_tasks()
        monitor.capture_enabled = False
        await context.close()

    monitor.build_summary(start_time, final_url, stop_reason)
    share_zip = monitor.build_share_zip()
    print()
    print("=" * 76)
    print(" HOAN THANH")
    print("=" * 76)
    print(f"Thu muc ket qua: {monitor.session_dir}")
    print(f"File gui lai: {share_zip}")
    print("Chi gui CHIA_SE_VOI_CHATGPT.zip. KHONG gui thu muc data.")
    open_folder(monitor.session_dir)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--url", default=DEFAULT_URL, help="Trang Ledutu mo khi khoi dong")
    parser.add_argument("--self-test", action="store_true", help="Chay kiem tra noi bo")
    parser.add_argument("--login-timeout-minutes", type=int, default=60)
    parser.add_argument("--max-hours", type=float, default=6.0)
    parser.add_argument("--grace-seconds", type=int, default=20)
    return parser


def main() -> int:
    configure_console()
    args = build_parser().parse_args()
    if args.self_test:
        return self_test()
    try:
        return asyncio.run(run_monitor(args))
    except KeyboardInterrupt:
        print("\nDa dung boi nguoi dung.")
        return 130
    except Exception:
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
