@echo off
setlocal
cd /d "%~dp0"
if not exist "ket_qua" (
  echo Chua co thu muc ket_qua.
  pause
  exit /b 1
)
for /f "delims=" %%D in ('dir /b /ad /o-d "ket_qua\ledutu-monitor-*" 2^>nul') do (
  explorer "ket_qua\%%D"
  exit /b 0
)
echo Chua co ket qua theo doi.
pause
