#!/usr/bin/env python3
"""Create-only AI_Music synchronization: local valid missing names -> Google Drive.

Read-only by default. Do not write files with a conflicting name, overwrite,
update or delete remote files. Never log OAuth credentials.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import http.client
import json
import mimetypes
from pathlib import Path
import ssl
import sys
import time
from urllib import error, parse, request
import uuid

from DOI_CHIEU_AI_DRIVE import (
    GoogleReader, SOURCE_DEFAULT, TOKEN_DEFAULTS, FOLDER_MIME,
    find_local_files, compare,
)

UPLOAD_API = "https://www.googleapis.com/upload/drive/v3/files"
AUDIO_MIMES = {".ogg": "audio/ogg", ".mp3": "audio/mpeg", ".wav": "audio/wav",
               ".m4a": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac",
               ".opus": "audio/opus", ".webm": "audio/webm"}


def err_message(exc: Exception) -> str:
    if isinstance(exc, error.HTTPError):
        return f"HTTP {exc.code}"
    return f"{type(exc).__name__}: {str(exc)[:180]}"


def find_exact(drive: GoogleReader, folder_id: str, name: str) -> list[dict]:
    return [x for x in drive.list_files(folder_id, name)
            if x.get("name") == name and x.get("mimeType") != FOLDER_MIME]


def check_existing(drive: GoogleReader, folder_id: str, path: Path,
                   retries: int = 1) -> str:
    """Returns missing, present, conflict, or unknown. Unknown never allows POST."""
    for attempt in range(retries):
        try:
            exact = find_exact(drive, folder_id, path.name)
            if not exact:
                return "missing"
            if len(exact) != 1:
                return f"conflict_duplicate_{len(exact)}"
            try:
                size = int(exact[0]["size"])
            except (KeyError, ValueError, TypeError):
                return "conflict_unknown_size"
            return "present" if size == path.stat().st_size else f"conflict_size_remote_{size}"
        except Exception:
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    return "unknown_network"


def upload_once(drive: GoogleReader, parent_id: str, path: Path, kind: str) -> dict:
    """Sends exactly one create request. Error is ambiguous; caller must re-list."""
    boundary = "TTAiFile" + uuid.uuid4().hex
    mime = "application/json" if kind == "lyrics" else AUDIO_MIMES[path.suffix.lower()]
    metadata = json.dumps({"name": path.name, "mimeType": mime, "parents": [parent_id]},
                          ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    data = path.read_bytes()
    body = (b"--" + boundary.encode("ascii") + b"\r\n"
            b"Content-Type: application/json; charset=UTF-8\r\n\r\n" + metadata + b"\r\n"
            b"--" + boundary.encode("ascii") + b"\r\n"
            b"Content-Type: " + mime.encode("ascii") + b"\r\n\r\n" + data + b"\r\n"
            b"--" + boundary.encode("ascii") + b"--\r\n")
    qs = parse.urlencode({"uploadType": "multipart", "fields": "id,name,size"})
    req = request.Request(UPLOAD_API + "?" + qs, data=body, method="POST", headers={
        "Authorization": "Bearer " + drive.token,
        "Accept": "application/json",
        "Content-Type": "multipart/related; boundary=" + boundary,
    })
    with request.urlopen(req, timeout=95) as response:
        obj = json.load(response)
    if not isinstance(obj, dict) or not obj.get("id"):
        raise RuntimeError("Drive create response did not contain a file ID")
    if obj.get("name") != path.name:
        raise RuntimeError("Drive create response filename mismatch")
    return obj


def main() -> int:
    ap = argparse.ArgumentParser(description="Create only locally-present AI files missing on Google Drive")
    ap.add_argument("--source", default=SOURCE_DEFAULT)
    ap.add_argument("--token", default="", help="Private OAuth token path; never printed")
    ap.add_argument("--report", default="")
    ap.add_argument("--upload", action="store_true", help="Explicitly create missing files on Drive")
    ap.add_argument("--pause", type=float, default=2.5, help="Wait seconds after each attempt")
    args = ap.parse_args()
    if not 0.0 <= args.pause <= 30:
        ap.error("pause must be 0..30")
    root = Path(args.source)
    if not root.is_dir():
        ap.error("Source root does not exist: " + str(root))
    local, details = find_local_files(root)
    if details["folders_missing"]:
        print("STOP: Local source folders missing (rename them back first):")
        for item in details["folders_missing"]:
            print(" -", item)
        return 2
    dupes = [(k, n) for k in ("audio", "lyrics") for n, v in local[k].items() if len(v) != 1]
    if dupes:
        print("STOP: Duplicate names on local source require manual review:", dupes[:8])
        return 2
    report = (Path(args.report) if args.report else root / "Reports" / "Drive_Audit")
    report.mkdir(parents=True, exist_ok=True)
    selected = Path(args.token) if args.token else next((Path(p) for p in TOKEN_DEFAULTS if Path(p).is_file()), None)
    if not selected or not selected.is_file():
        print("STOP: No private OAuth drive_token.json. Pass -TokenFile to wrapper.")
        return 2
    print("==== TUNERTOOLS AI MISSING-FILE SYNC ====")
    print("MODE:", "UPLOAD ONLY MISSING" if args.upload else "PREVIEW ONLY, NO CHANGES")
    print("LOCAL:", root)
    print("TOKEN: present, contents not printed")
    if details["unrecognized_audio"]:
        print("NOTICE: Audio files with unrecognized names (not auto-uploaded):", len(details["unrecognized_audio"]))
    if details["invalid_json"]:
        print("NOTICE: Invalid JSON files (not auto-uploaded):", len(details["invalid_json"]))
    drive = GoogleReader(selected)
    backup = drive.folder("root", "TunerTools_AppBackup")
    ai = drive.folder(backup, "AI_Music")
    folders = {"audio": drive.folder(ai, "stream_cache"), "lyrics": drive.folder(ai, "lyrics")}
    remote = {k: drive.list_files(v) for k, v in folders.items()}
    plans: dict[str, list[Path]] = {}
    for kind in ("audio", "lyrics"):
        remote_names = {str(x.get("name")) for x in remote[kind] if x.get("mimeType") != FOLDER_MIME}
        plans[kind] = [Path(paths[0][0]) for name, paths in local[kind].items() if name not in remote_names]
        plans[kind].sort(key=lambda p: p.name.casefold())
        print(f"{kind.upper()}: LOCAL={len(local[kind])} DRIVE={len(remote_names)} MISSING={len(plans[kind])}")
        for p in plans[kind][:5]:
            print("  MISSING:", p.name)
    total = sum(map(len, plans.values()))
    print("TOTAL MISSING VALID FILES:", total)
    if not args.upload:
        print("PREVIEW FINISHED. Use -Upload to create only the missing files.")
        return 0

    results = {"uploaded": [], "confirmed_after_disconnect": [], "skipped_existing": [], "failed": []}
    count = 0
    for kind in ("audio", "lyrics"):
        for p in plans[kind]:
            count += 1
            key = {"kind": kind, "filename": p.name}
            try:
                # Protect from source mutation or newly-uploaded duplicates.
                if not p.is_file() or p.stat().st_size == 0:
                    raise RuntimeError("Source file disappeared or is empty")
                before = check_existing(drive, folders[kind], p, retries=3)
                if before == "present":
                    results["skipped_existing"].append(key)
                    print(f"[{count}/{total}] SKIP PRESENT {p.name}")
                    continue
                if before != "missing":
                    raise RuntimeError("Unsafe to create: " + before)
                sent = False
                post_error = None
                try:
                    sent = True
                    obj = upload_once(drive, folders[kind], p, kind)
                    if obj.get("size") is not None and int(obj["size"]) != p.stat().st_size:
                        raise RuntimeError("Drive returned wrong file size")
                except Exception as exc:
                    post_error = exc
                # On network disconnection the POST may already have succeeded.
                # NEVER blindly retry the POST; check Drive after a short delay.
                confirmed = "unknown_network"
                for ix in range(4):
                    time.sleep(1.5 * (ix + 1))
                    confirmed = check_existing(drive, folders[kind], p, retries=2)
                    if confirmed == "present" or confirmed.startswith("conflict"):
                        break
                if confirmed == "present":
                    results["confirmed_after_disconnect" if post_error else "uploaded"].append(key)
                    print(f"[{count}/{total}] OK {p.name}")
                else:
                    message = (err_message(post_error) + "; " if post_error else "") + "post_status=" + confirmed
                    results["failed"].append(dict(key, error=message))
                    print(f"[{count}/{total}] FAILED {p.name}: {message}")
            except KeyboardInterrupt:
                print("Stopped by user. Successfully uploaded files remain; rerun is safe.")
                raise
            except Exception as exc:
                results["failed"].append(dict(key, error=err_message(exc)))
                print(f"[{count}/{total}] FAILED {p.name}: {err_message(exc)}")
            finally:
                if args.pause:
                    time.sleep(args.pause)

    # Confirm reconciliation against a fresh live listing, not PHP 600-s cache.
    print("\n==== FINAL LIVE DRIVE AUDIT ====")
    final = {}
    final_errors = []
    for kind in ("audio", "lyrics"):
        try:
            final[kind] = compare(kind, local[kind], drive.list_files(folders[kind]), report)
            x = final[kind]
            print(f"{kind.upper()}: MISSING_ON_DRIVE={x['missing_on_drive']} ONLY_ON_DRIVE={x['only_on_drive']} SIZE_DIFFERENT={x['size_different']}")
        except Exception as exc:
            final_errors.append(kind + ": " + err_message(exc))
            print("WARNING: final Drive audit could not complete for", kind)
    payload = {
        "date_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "upload_mode": True,
        "source": str(root),
        "attempted_total": count,
        "uploaded": results["uploaded"],
        "confirmed_after_disconnect": results["confirmed_after_disconnect"],
        "skipped_existing": results["skipped_existing"],
        "failed": results["failed"],
        "final": final,
        "final_errors": final_errors,
    }
    result_path = report / "UPLOAD_MISSING_RESULT.json"
    result_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("REPORT:", result_path)
    print(f"CREATED={len(results['uploaded']) + len(results['confirmed_after_disconnect'])} SKIPPED={len(results['skipped_existing'])} FAILED={len(results['failed'])}")
    print("No Drive files were deleted or overwritten.")
    return 1 if results["failed"] or final_errors or any(x.get("missing_on_drive", -1) for x in final.values()) else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as exc:
        print("ERROR:", err_message(exc), file=sys.stderr)
        raise SystemExit(1)
