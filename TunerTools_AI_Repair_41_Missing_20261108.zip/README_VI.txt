TUNERTOOLS - DONG BO NHUNG FILE AI CON THIEU TU WINDOWS LEN GOOGLE DRIVE
===========================================================================
Nguon: C:\TunerTools\Audio\AI_Music\ZING_AUDIO, YOUTUBE_CACHE, ZING_JSON.
Dich: My Drive/TunerTools_AppBackup/AI_Music/stream_cache va lyrics.

1. Giai nen ZIP vao C:\TunerTools\Tools\AI_Repair_Missing
2. Xem truoc, KHONG UPLOAD:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Repair_Missing\CHAY_DONG_BO_FILE_THIEU.ps1"
3. Neu tong so file thieu du kien dung (o lan audit 2026-11-08 la 1 audio + 40 lyrics):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Repair_Missing\CHAY_DONG_BO_FILE_THIEU.ps1" -Upload -PauseSeconds 2.5

MUC TIEU:
   AUDIO: MISSING_ON_DRIVE=0
   LYRICS: MISSING_ON_DRIVE=0

Chuong trinh:
- Mac dinh chi xem truoc, phai co -Upload moi tao file moi.
- Tu dung neu thieu thu muc nguon; khong upload du lieu khong duoc scan.
- Chi tao file CHUA CO TEN tren Drive, khong xoa/ghi de.
- Gap mat ket noi: KHONG gui lai lenh POST ma khong kiem tra, de tranh trung file.
- Co the chay lai nhieu lan; file da co duoc bo qua.
- Cuoi cung doi chieu lai truc tiep bang Google Drive API va in tong hop trong PowerShell.
- 59 audio chi co tren Drive duoc giu nguyen.
- File audio co ten khong dung quy uoc (8 file cua lan kiem tra truoc) can xem xet rieng,
  khong duoc tu dong upload vi chua biet chuc nang cua chung.
- Hien tai chua so sanh SHA256, chi so ten va dung luong.
- Bao cao: C:\TunerTools\Audio\AI_Music\Reports\Drive_Audit\UPLOAD_MISSING_RESULT.json

BAO MAT: khong cong khai private drive_token.json; khong chay hai ban upload song song.
Khong doi ten thu muc Windows trong luc chay.
