param(
    [string]$SourceDir = "C:\TunerTools\Audio\AI_Music",
    [string]$TokenFile = "",
    [string]$ReportDir = "C:\TunerTools\Audio\AI_Music\Reports\Drive_Audit",
    [switch]$Upload,
    [double]$PauseSeconds = 2.5
)
$ErrorActionPreference = 'Stop'
$script = Join-Path $PSScriptRoot 'DONG_BO_FILE_AI_THIEU.py'
$helper = Join-Path $PSScriptRoot 'DOI_CHIEU_AI_DRIVE.py'
if (-not (Test-Path -LiteralPath $script) -or -not (Test-Path -LiteralPath $helper)) {
    throw 'Thieu script Python. Hay giai nen lai ZIP vao cung mot thu muc.'
}
$pyArgs = @($script, '--source', $SourceDir, '--report', $ReportDir, '--pause', [string]::Format([cultureinfo]::InvariantCulture, '{0}', $PauseSeconds))
if ($TokenFile.Trim() -ne '') { $pyArgs += @('--token', $TokenFile) }
if ($Upload) { $pyArgs += '--upload' }
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 @pyArgs
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python @pyArgs
} else {
    throw 'Chua tim thay Python 3.10+ trong PATH.'
}
if ($LASTEXITCODE -ne 0) { throw "AI reconcile finished with exit code $LASTEXITCODE" }
