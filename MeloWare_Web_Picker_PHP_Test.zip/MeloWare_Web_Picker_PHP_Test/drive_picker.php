<?php
/**
 * MeloWare Google Picker (web) - safe standalone integration test.
 * Host as https://tunertools.top/meloware/drive_picker.php
 * IMPORTANT: This page does NOT yet send selections to Android.
 * It keeps the Google OAuth access token in browser memory only.
 */
declare(strict_types=1);

const MELOWARE_WEB_CLIENT_ID = 'PASTE_WEB_OAUTH_CLIENT_ID_HERE';
const MELOWARE_PICKER_API_KEY = 'PASTE_PICKER_BROWSER_API_KEY_HERE';
const MELOWARE_PROJECT_NUMBER = '886650248212'; // MeloWave project number

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Content-Type-Options: nosniff');

$config = [
    'clientId' => MELOWARE_WEB_CLIENT_ID,
    'apiKey' => MELOWARE_PICKER_API_KEY,
    'appId' => MELOWARE_PROJECT_NUMBER,
];
$configured = (
    substr(MELOWARE_WEB_CLIENT_ID, -strlen('.apps.googleusercontent.com')) === '.apps.googleusercontent.com' &&
    substr(MELOWARE_PICKER_API_KEY, 0, 4) === 'AIza' &&
    preg_match('/^\d+$/', MELOWARE_PROJECT_NUMBER) === 1
);
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>MeloWare - Chon nhac Google Drive</title>
<style>
:root{color-scheme:dark; font-family:system-ui,-apple-system,Roboto,sans-serif}
*{box-sizing:border-box}
body{margin:0;background:linear-gradient(145deg,#070b1b,#0d1830 65%,#10091e);color:#f5f1ff;min-height:100vh}
.wrap{max-width:740px;margin:auto;padding:24px 18px 60px}
.brand{font-size:13px;font-weight:800;letter-spacing:.08em;color:#c983ff;margin:6px 0 4px}
h1{font-size:26px;margin:10px 0 6px} p{color:#b3bad1;line-height:1.55;font-size:14px}
.panel{border:1px solid #384568;border-radius:22px;background:rgba(18,26,47,.92);padding:20px;margin-top:20px;box-shadow:0 12px 40px #0003}
.buttons{display:flex;flex-wrap:wrap;gap:10px;margin-top:18px}
button{border:0;border-radius:14px;padding:13px 18px;cursor:pointer;font-weight:800;color:white;background:linear-gradient(110deg,#9639ff,#d02aeb)}
button.secondary{background:#1b2c48;color:#d5ddf1;border:1px solid #3a4d69}
button:disabled{opacity:.45;cursor:not-allowed}
#status{margin-top:18px;font-size:13px;color:#a7dec7;white-space:pre-wrap}
#status.error{color:#ffb8b8}
#results{list-style:none;margin:14px 0 0;padding:0}
#results li{background:#0c1426;border:1px solid #24354f;border-radius:12px;padding:11px 13px;margin:7px 0;word-break:break-word}
#results small{display:block;color:#9ba9c4;margin-top:4px}
.note{font-size:12px;color:#9eabbe}
code{color:#d6b5ff}
</style>
<script>
'use strict';
const config = <?php echo json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES); ?>;
const configured = <?php echo $configured ? 'true' : 'false'; ?>;
const SCOPE = 'https://www.googleapis.com/auth/drive.file';
let pickerApiReady = false;
let gisReady = false;
let tokenClient = null;
let accessToken = null;
let expiresAt = 0;
let selectedDocuments = [];

function setStatus(message, isError = false) {
  const elem = document.getElementById('status');
  if (!elem) return;
  elem.textContent = message;
  elem.classList.toggle('error', isError);
}
function updateButtons() {
  const ready = configured && pickerApiReady && gisReady;
  document.getElementById('pickButton').disabled = !ready;
  document.getElementById('accountButton').disabled = !ready;
  document.getElementById('copyButton').disabled = selectedDocuments.length === 0;
}
function onApiLoad() {
  gapi.load('picker', () => { pickerApiReady = true; updateButtons(); if (gisReady) setStatus('Sẵn sàng chọn nhạc Google Drive.'); });
}
function onGisLoad() {
  if (configured) {
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: config.clientId,
      scope: SCOPE,
      callback: (response) => {
        if (!response || response.error || !response.access_token) {
          setStatus('Không thể lấy quyền Google: ' + (response?.error_description || response?.error || 'Không rõ lỗi'), true);
          return;
        }
        accessToken = response.access_token;
        // Buffer by 60 seconds so that an almost-expired token is not reused.
        expiresAt = Date.now() + (Math.max(60, Number(response.expires_in) || 3600) - 60) * 1000;
        showPicker();
      },
      error_callback: (error) => setStatus('Đăng nhập Google bị hủy hoặc chặn popup: ' + (error?.type || 'unknown'), true)
    });
  }
  gisReady = true;
  updateButtons();
  if (pickerApiReady && configured) setStatus('Sẵn sàng chọn nhạc Google Drive.');
}
function openDrive(changeAccount = false) {
  if (!configured) { setStatus('Cần điền Web Client ID và API Key vào drive_picker.php.', true); return; }
  if (!pickerApiReady || !gisReady || !tokenClient) { setStatus('Đang tải thư viện Google, thử lại sau vài giây.', true); return; }
  if (!changeAccount && accessToken && Date.now() < expiresAt) { showPicker(); return; }
  // Empty prompt reuses a prior consent when Google can; first visit may still ask.
  // Explicit account change requests the account chooser, not forced re-consent.
  tokenClient.requestAccessToken({prompt: changeAccount ? 'select_account' : ''});
}
function showPicker() {
  if (!accessToken || !pickerApiReady) return;
  const view = new google.picker.DocsView(google.picker.ViewId.DOCS)
    .setIncludeFolders(true)
    .setSelectFolderEnabled(true)
    .setMode(google.picker.DocsViewMode.LIST);
  try {
    const picker = new google.picker.PickerBuilder()
      .addView(view)
      .enableFeature(google.picker.Feature.MULTISELECT_ENABLED)
      .setOAuthToken(accessToken)
      .setDeveloperKey(config.apiKey)
      .setAppId(config.appId)
      .setOrigin(window.location.origin)
      .setLocale('vi')
      .setTitle('MeloWare - Chọn nhạc từ Google Drive')
      .setCallback(onPicked)
      .build();
    picker.setVisible(true);
    setStatus('Đã mở Google Picker. Hãy chọn bài hát hoặc thư mục.');
  } catch (error) {
    setStatus('Không thể mở Picker: ' + (error?.message || String(error)), true);
  }
}
function isMusic(doc) {
  if ((doc.mimeType || '').toLowerCase().startsWith('audio/')) return true;
  return /\.(mp3|m4a|m4b|flac|wav|wave|aac|ogg|oga|opus|wma|amr)$/i.test(doc.name || '');
}
function onPicked(data) {
  if (data?.[google.picker.Response.ACTION] !== google.picker.Action.PICKED) return;
  const raw = data[google.picker.Response.DOCUMENTS] || [];
  selectedDocuments = raw.map(doc => ({
    id: doc[google.picker.Document.ID] || '',
    name: doc[google.picker.Document.NAME] || '',
    mimeType: doc[google.picker.Document.MIME_TYPE] || ''
  })).filter(doc => doc.id && (isMusic(doc) || doc.mimeType === 'application/vnd.google-apps.folder'));
  const list = document.getElementById('results');
  list.replaceChildren();
  for (const doc of selectedDocuments) {
    const li = document.createElement('li');
    li.append(document.createTextNode(doc.name));
    const small = document.createElement('small');
    small.textContent = doc.mimeType + ' · ID: ' + doc.id;
    li.append(small);
    list.append(li);
  }
  setStatus(`Google Picker trả ${raw.length} mục; ${selectedDocuments.length} mục là file nhạc hoặc thư mục.\nĐây mới là trang thử nghiệm, chưa gửi danh sách về Android.`);
  updateButtons();
}
async function copyList() {
  const data = JSON.stringify(selectedDocuments, null, 2);
  try { await navigator.clipboard.writeText(data); setStatus('Đã sao chép danh sách ID, KHÔNG chứa access token.'); }
  catch { setStatus('Không sao chép được. Hãy mở trên HTTPS và cho phép Clipboard.', true); }
}
window.onApiLoad = onApiLoad;
window.onGisLoad = onGisLoad;
window.openDrive = openDrive;
window.copyList = copyList;
window.addEventListener('DOMContentLoaded', () => {
  updateButtons();
  if (!configured) setStatus('Chưa cấu hình Web Client ID và API Key trong file PHP.', true);
});
</script>
<script async defer src="https://apis.google.com/js/api.js" onload="onApiLoad()"></script>
<script async defer src="https://accounts.google.com/gsi/client" onload="onGisLoad()"></script>
</head>
<body>
<main class="wrap">
  <div class="brand">MELOWARE · GOOGLE DRIVE</div>
  <h1>Chọn nhạc từ Google Drive</h1>
  <p>Chọn các bài hát MP3, FLAC hoặc thư mục Drive mà bạn muốn dùng với MeloWare. Website không gửi access token tới máy chủ PHP.</p>
  <section class="panel">
    <strong>Google Picker · thử nghiệm web</strong>
    <p>Ấn “Mở Google Drive”. Nếu tài khoản đã cấp quyền cho Web OAuth Client này, Google thường sẽ không hiển thị lại màn đồng ý trong phiên hợp lệ.</p>
    <div class="buttons">
      <button id="pickButton" onclick="openDrive(false)" disabled>Mở Google Drive</button>
      <button id="accountButton" class="secondary" onclick="openDrive(true)" disabled>Đổi tài khoản</button>
    </div>
    <div id="status" aria-live="polite">Đang tải Google API…</div>
  </section>
  <section class="panel">
    <strong>Danh sách đã chọn</strong>
    <p class="note">Trang này mới kiểm tra việc đăng nhập và chọn file. Kết nối kết quả về Android sẽ được làm ở bước sau. Chọn thư mục không bảo đảm có quyền đọc toàn bộ file con.</p>
    <ul id="results"></ul>
    <div class="buttons"><button id="copyButton" class="secondary" onclick="copyList()" disabled>Sao chép danh sách ID</button></div>
  </section>
  <p class="note">Chỉ dùng Google Cloud Project MeloWave. Không dùng quyền drive.readonly. Không sao chép OAuth client secret hoặc refresh token vào file này.</p>
</main>
</body>
</html>
