@file:OptIn(
    ExperimentalUnsignedTypes::class,
    kotlin.contracts.ExperimentalContracts::class
)

package ducphi.tunnerinstrument

import com.google.android.gms.common.api.ApiException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import androidx.core.graphics.PathParser
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Lock
import androidx.compose.foundation.Canvas
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.roundToInt
import androidx.compose.ui.draw.alpha
import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Palette
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
private val SUPPORTED_GP_EXTENSIONS = setOf("gp3", "gp4", "gp5", "gpx", "gp")

// Android Storage Access Framework lọc theo MIME, không lọc trực tiếp theo đuôi file.
// Danh sách này loại ảnh, video, PDF, tài liệu... khỏi màn hình chọn file.
// application/octet-stream được giữ lại vì nhiều trình quản lý file khai báo GP3/4/5/GPX/GP
// là dữ liệu nhị phân chung; sau khi chọn vẫn kiểm tra chính xác phần mở rộng ở readLocalScoreFile().
private val SUPPORTED_GP_MIME_TYPES = arrayOf(
    "application/x-guitar-pro",
    "application/x-guitar-pro3",
    "application/x-guitar-pro4",
    "application/x-guitar-pro5",
    "application/x-guitar-pro6",
    "application/x-guitar-pro7",
    "application/vnd.guitarpro",
    "application/vnd.guitar-pro",
    "application/x-gpx",
    "application/gpx+xml",
    "audio/x-guitar-pro",
    "application/octet-stream"
)
private const val LOCAL_SCORE_MAX_BYTES = 50L * 1024L * 1024L
private const val LOCAL_SCORE_URL_PREFIX = "https://tunertools.top/__local_score__/"

internal const val STANDARD_SOUNDFONT_URL =
    "https://cdn.jsdelivr.net/npm/@coderline/alphatab@1.8.4/dist/soundfont/sonivox.sf2"
private const val FLUIDR3_SOUNDFONT_FILE_NAME = "FluidR3_GM.sf2"
private const val MUSESCORE_SOUNDFONT_FILE_NAME = "MuseScore_General.sf3"
private const val LOCAL_FLUIDR3_SOUNDFONT_URL =
    "https://tunertools.top/__local_soundfont__/FluidR3_GM.sf2"
private const val LOCAL_MUSESCORE_SOUNDFONT_URL =
    "https://tunertools.top/__local_soundfont__/MuseScore_General.sf3"
private const val SOUNDFONT_PREFS_NAME = "SongTabSoundFontPrefs"
private const val SOUNDFONT_PREF_MODE = "selected_mode"
// Piano uses its own compatible preset. Keep the Guitar SF2 preference unchanged.
private const val SOUNDFONT_PREF_PIANO_MODE = "piano_selected_mode"
private const val SOUNDFONT_PREF_SIZE = "downloaded_size"
private const val SOUNDFONT_PREF_VERSION = "downloaded_version"
private const val SOUNDFONT_PREF_PART_VERSION = "partial_version"
private const val TAB_DISPLAY_PREFS_NAME = "SongTabDisplayPrefs"
private const val TAB_DISPLAY_PREF_NOTE_NAMES = "show_note_names"
private const val TAB_DISPLAY_PREF_MODE = "display_mode_combination"
// Thu/phong CHI khuong nhac + TAB; khong thay doi kich thuoc can dan.
// -1 = mac dinh cua che do (S+T+F: 82%, S+T / TAB / Score: 100%).
private const val TAB_DISPLAY_PREF_SCORE_ZOOM = "score_notation_zoom_percent"
private const val TAB_SCORE_ZOOM_MIN = 50
private const val TAB_SCORE_ZOOM_MAX = 150
private const val TAB_APPEARANCE_PREF_THEME_MODE = "appearance_theme_mode"
private const val TAB_APPEARANCE_PREF_CURSOR_COLOR = "appearance_cursor_color"
private const val TAB_APPEARANCE_PREF_ACTIVE_REGION_COLOR = "appearance_active_region_color"
private const val TAB_APPEARANCE_PREF_TAB_COLOR = "appearance_tab_color"
private const val TAB_APPEARANCE_PREF_NOTE_COLOR = "appearance_note_color"
private const val TAB_APPEARANCE_PREF_FRETBOARD_COLOR = "appearance_fretboard_color"
private const val TAB_APPEARANCE_PREF_PANEL_COLOR = "appearance_fretboard_panel_color"
private const val TAB_APPEARANCE_PREF_CURSOR_WIDTH = "appearance_cursor_width"
private const val TAB_APPEARANCE_PREF_REGION_OPACITY = "appearance_region_opacity"
private const val TAB_METRONOME_PREFS_NAME = "SongTabMetronomePrefs"
private const val TAB_METRONOME_PREF_ENABLED = "metronome_enabled"

private enum class TabAppearanceThemeMode(val storedValue: String) {
    FOLLOW_APP("follow_app"),
    LIGHT("light"),
    DARK("dark");

    fun resolve(appIsDark: Boolean): Boolean = when (this) {
        FOLLOW_APP -> appIsDark
        LIGHT -> false
        DARK -> true
    }

    fun title(currentLang: String): String {
        val isVietnamese = currentLang
            .lowercase(Locale.ROOT)
            .substringBefore('-')
            .substringBefore('_') == "vi"
        return when (this) {
            FOLLOW_APP -> if (isVietnamese) "Theo ứng dụng" else "Follow app"
            LIGHT -> if (isVietnamese) "Sáng" else "Light"
            DARK -> if (isVietnamese) "Tối" else "Dark"
        }
    }

    companion object {
        fun fromStoredValue(value: String?): TabAppearanceThemeMode =
            values().firstOrNull { it.storedValue == value } ?: FOLLOW_APP
    }
}

private data class TabAppearanceColorOption(
    val id: String,
    val vietnameseName: String,
    val englishName: String,
    val lightHex: String,
    val darkHex: String
) {
    fun resolve(isDark: Boolean): String = if (isDark) darkHex else lightHex

    fun title(currentLang: String): String {
        val isVietnamese = currentLang
            .lowercase(Locale.ROOT)
            .substringBefore('-')
            .substringBefore('_') == "vi"
        return if (isVietnamese) vietnameseName else englishName
    }
}

private val TAB_EXTRA_COLORS = listOf(
    TabAppearanceColorOption("white", "Tr\u1eafng", "White", "#FFFFFF", "#FFFFFF"),
    TabAppearanceColorOption("black", "\u0110en", "Black", "#000000", "#000000"),
    TabAppearanceColorOption("cream", "Kem", "Cream", "#FFF9E6", "#FFF9E6"),
    TabAppearanceColorOption("pearl", "Ng\u1ecdc trai", "Pearl", "#E9EDF3", "#E9EDF3"),
    TabAppearanceColorOption("charcoal", "Than", "Charcoal", "#202733", "#202733"),
    TabAppearanceColorOption("gray", "X\u00e1m", "Gray", "#9CA3AF", "#9CA3AF"),
    TabAppearanceColorOption("brown", "N\u00e2u", "Brown", "#8B5E3C", "#8B5E3C"),
    TabAppearanceColorOption("gold", "V\u00e0ng kim", "Gold", "#EAB308", "#FACC15"),
    TabAppearanceColorOption("yellow", "V\u00e0ng", "Yellow", "#FBBF24", "#FFD43B"),
    TabAppearanceColorOption("lime", "Xanh chanh", "Lime", "#84CC16", "#A3E635"),
    TabAppearanceColorOption("teal", "Xanh l\u1ee5c", "Teal", "#0D9488", "#2DD4BF"),
    TabAppearanceColorOption("indigo", "Ch\u00e0m", "Indigo", "#4F46E5", "#818CF8"),
    TabAppearanceColorOption("magenta", "T\u00edm h\u1ed3ng", "Magenta", "#C026D3", "#E879F9"),
    TabAppearanceColorOption("pink", "H\u1ed3ng", "Pink", "#EC4899", "#F472B6"),
    TabAppearanceColorOption("coral", "San h\u00f4", "Coral", "#FB7185", "#FDA4AF"),
    TabAppearanceColorOption("mintlight", "B\u1ea1c h\u00e0 nh\u1ea1t", "Pale mint", "#D1FAE5", "#D1FAE5"),
    TabAppearanceColorOption("skyblue", "Xanh tr\u1eddi nh\u1ea1t", "Pale blue", "#DBEAFE", "#DBEAFE")
)

private fun tabAppearanceExpandedPalette(
    base: List<TabAppearanceColorOption>
): List<TabAppearanceColorOption> = base + TAB_EXTRA_COLORS.filter { extra ->
    base.none { it.id == extra.id }
}

private val TAB_CURSOR_COLOR_OPTIONS = tabAppearanceExpandedPalette(listOf(
    TabAppearanceColorOption("purple", "T\u00edm", "Purple", "#7C3AED", "#C084FC"),
    TabAppearanceColorOption("blue", "Xanh d\u01b0\u01a1ng", "Blue", "#2563EB", "#60A5FA"),
    TabAppearanceColorOption("cyan", "Xanh ng\u1ecdc", "Cyan", "#0891B2", "#22D3EE"),
    TabAppearanceColorOption("green", "Xanh l\u00e1", "Green", "#059669", "#34D399"),
    TabAppearanceColorOption("orange", "Cam", "Orange", "#EA580C", "#FB923C"),
    TabAppearanceColorOption("red", "\u0110\u1ecf", "Red", "#DC2626", "#F87171")
))

private val TAB_ACTIVE_REGION_COLOR_OPTIONS = tabAppearanceExpandedPalette(listOf(
    TabAppearanceColorOption("lavender", "T\u00edm nh\u1ea1t", "Lavender", "#8B5CF6", "#7C3AED"),
    TabAppearanceColorOption("sky", "Xanh tr\u1eddi", "Sky", "#0EA5E9", "#0284C7"),
    TabAppearanceColorOption("mint", "B\u1ea1c h\u00e0", "Mint", "#10B981", "#059669"),
    TabAppearanceColorOption("amber", "H\u1ed5 ph\u00e1ch", "Amber", "#F59E0B", "#D97706"),
    TabAppearanceColorOption("rose", "H\u1ed3ng", "Rose", "#F43F5E", "#E11D48"),
    TabAppearanceColorOption("slate", "X\u00e1m xanh", "Slate", "#64748B", "#475569")
))

private val TAB_GLYPH_COLOR_OPTIONS = tabAppearanceExpandedPalette(listOf(
    TabAppearanceColorOption("auto", "T\u1ef1 \u0111\u1ed9ng", "Automatic", "#111827", "#F8FAFC"),
    TabAppearanceColorOption("purple", "T\u00edm", "Purple", "#5B21B6", "#E9D5FF"),
    TabAppearanceColorOption("blue", "Xanh d\u01b0\u01a1ng", "Blue", "#1D4ED8", "#BFDBFE"),
    TabAppearanceColorOption("green", "Xanh l\u00e1", "Green", "#047857", "#A7F3D0"),
    TabAppearanceColorOption("amber", "H\u1ed5 ph\u00e1ch", "Amber", "#92400E", "#FDE68A"),
    TabAppearanceColorOption("rose", "H\u1ed3ng", "Rose", "#9F1239", "#FECDD3")
))

private val TAB_NOTE_COLOR_OPTIONS = tabAppearanceExpandedPalette(listOf(
    TabAppearanceColorOption("yellow", "V\u00e0ng", "Yellow", "#FBBF24", "#FFD43B"),
    TabAppearanceColorOption("orange", "Cam", "Orange", "#F97316", "#FB923C"),
    TabAppearanceColorOption("cyan", "Xanh ng\u1ecdc", "Cyan", "#06B6D4", "#22D3EE"),
    TabAppearanceColorOption("green", "Xanh l\u00e1", "Green", "#10B981", "#34D399"),
    TabAppearanceColorOption("pink", "H\u1ed3ng", "Pink", "#EC4899", "#F472B6"),
    TabAppearanceColorOption("purple", "T\u00edm", "Purple", "#8B5CF6", "#C084FC")
))

private val TAB_FRETBOARD_COLOR_OPTIONS = tabAppearanceExpandedPalette(listOf(
    TabAppearanceColorOption("auto", "T\u1ef1 \u0111\u1ed9ng", "Automatic", "#F8FAFC", "#171B24"),
    TabAppearanceColorOption("slate", "X\u00e1m \u0111\u00e1", "Slate", "#E2E8F0", "#0F172A"),
    TabAppearanceColorOption("navy", "Xanh navy", "Navy", "#DBEAFE", "#0B1F3A"),
    TabAppearanceColorOption("forest", "Xanh r\u1eebng", "Forest", "#DCFCE7", "#10251B"),
    TabAppearanceColorOption("wood", "M\u00e0u g\u1ed7", "Wood", "#F3E2C7", "#3A2418"),
    TabAppearanceColorOption("graphite", "Than ch\u00ec", "Graphite", "#E5E7EB", "#111827")
))

private val TAB_FRETBOARD_PANEL_OPTIONS = tabAppearanceExpandedPalette(listOf(
    TabAppearanceColorOption("auto", "T\u1ef1 \u0111\u1ed9ng", "Automatic", "#F4F6FB", "#0F131C"),
    TabAppearanceColorOption("panelblue", "Xanh nh\u1ea1t", "Pale blue", "#E8F3FF", "#142237"),
    TabAppearanceColorOption("panelgray", "X\u00e1m s\u00e1ng", "Soft gray", "#F3F4F6", "#292E3A"),
    TabAppearanceColorOption("panelgreen", "Xanh l\u00e1 nh\u1ea1t", "Soft green", "#E8FAF2", "#153228"),
    TabAppearanceColorOption("panelwood", "M\u00e0u kem", "Cream", "#FFF4DF", "#32251F")
))

private fun tabAppearanceCustomHex(id: String?): String? =
    id?.takeIf { it.length == 7 && it[0] == '#' &&
            it.substring(1).all { c -> c in '0'..'9' || c in 'a'..'f' || c in 'A'..'F' }
    }?.uppercase(Locale.ROOT)

private fun tabAppearanceStoredSelection(
    options: List<TabAppearanceColorOption>, id: String?, fallback: String
): String = when {
    options.any { it.id == id } -> id!!
    tabAppearanceCustomHex(id) != null -> tabAppearanceCustomHex(id)!!
    else -> fallback
}

private fun tabAppearanceResolvedHex(
    options: List<TabAppearanceColorOption>, id: String?, fallback: String, isDark: Boolean
): String = tabAppearanceCustomHex(id)
    ?: tabAppearanceOption(options, id, fallback).resolve(isDark)

private fun tabAppearanceHexFromHsv(hue: Float, saturation: Float, brightness: Float): String {
    val rgb = android.graphics.Color.HSVToColor(
        floatArrayOf(hue.coerceIn(0f, 360f), saturation.coerceIn(0f, 100f) / 100f,
            brightness.coerceIn(0f, 100f) / 100f)
    )
    return String.format(Locale.ROOT, "#%06X", rgb and 0xFFFFFF)
}


private fun tabAppearanceOption(
    options: List<TabAppearanceColorOption>,
    id: String?,
    fallbackId: String
): TabAppearanceColorOption = options.firstOrNull { it.id == id }
    ?: options.first { it.id == fallbackId }

private fun tabAppearanceComposeColor(hex: String): Color = runCatching {
    Color(android.graphics.Color.parseColor(hex))
}.getOrDefault(Color(0xFF7C3AED))

private fun tabAppearanceUsesDarkText(hex: String): Boolean {
    val color = android.graphics.Color.parseColor(hex)
    val red = android.graphics.Color.red(color) / 255.0
    val green = android.graphics.Color.green(color) / 255.0
    val blue = android.graphics.Color.blue(color) / 255.0
    fun channel(value: Double): Double =
        if (value <= 0.03928) value / 12.92 else Math.pow((value + 0.055) / 1.055, 2.4)
    val luminance = 0.2126 * channel(red) + 0.7152 * channel(green) + 0.0722 * channel(blue)
    // WCAG black/white crossover: prefer the text with stronger contrast.
    return luminance > 0.179
}

// Chuc nang Ban nhac duoc su dung mien phi khong gioi han thoi gian.
// Van giu buoc dang nhap Google de su dung tai khoan hien co.

internal fun soundFontText(
    key: String,
    currentLang: String,
    vietnameseFallback: String,
    englishFallback: String
): String {
    val translated = runCatching {
        CoreTranslator.getString(key, currentLang)
    }.getOrDefault("")

    if (
        translated.isNotBlank() &&
        translated != key &&
        !translated.contains("missing translation", ignoreCase = true)
    ) {
        return translated
    }

    val languageCode = currentLang
        .lowercase(Locale.ROOT)
        .substringBefore('-')
        .substringBefore('_')
    return if (languageCode == "vi") vietnameseFallback else englishFallback
}

private fun soundFontFormat(
    key: String,
    currentLang: String,
    vietnameseFallback: String,
    englishFallback: String,
    vararg args: Any
): String {
    val template = soundFontText(
        key = key,
        currentLang = currentLang,
        vietnameseFallback = vietnameseFallback,
        englishFallback = englishFallback
    )
    return runCatching {
        String.format(Locale.getDefault(), template, *args)
    }.getOrElse {
        val fallback = if (
            currentLang.lowercase(Locale.ROOT).substringBefore('-').substringBefore('_') == "vi"
        ) vietnameseFallback else englishFallback
        runCatching { String.format(Locale.getDefault(), fallback, *args) }
            .getOrDefault(fallback)
    }
}

private enum class TabDisplayInstrument { NONE, GUITAR, PIANO }

// A display mode is the applied combination of two independent notation layers
// and one optional instrument. Exactly one of score/TAB must be enabled.
private enum class TabDisplayMode(
    val jsValue: String,
    val buttonLabel: String,
    val showScore: Boolean,
    val showTab: Boolean,
    val instrument: TabDisplayInstrument
) {
    SCORE_TAB("scoretab", "S+T", true, true, TabDisplayInstrument.NONE),
    SCORE_TAB_FRETBOARD("scoretab_fretboard", "S+T+G", true, true, TabDisplayInstrument.GUITAR),
    PIANO("piano", "S+P", true, false, TabDisplayInstrument.PIANO),
    TAB_ONLY("tab", "TAB", false, true, TabDisplayInstrument.NONE),
    PARTITION_ONLY("score", "S", true, false, TabDisplayInstrument.NONE),
    SCORE_FRETBOARD("score_fretboard", "S+G", true, false, TabDisplayInstrument.GUITAR),
    TAB_FRETBOARD("tab_fretboard", "T+G", false, true, TabDisplayInstrument.GUITAR),
    PIANO_TAB("piano_tab", "S+T+P", true, true, TabDisplayInstrument.PIANO),
    TAB_PIANO("tab_piano", "T+P", false, true, TabDisplayInstrument.PIANO);

    val hasInstrumentPanel: Boolean get() = instrument != TabDisplayInstrument.NONE

    fun menuTitle(currentLang: String): String {
        val vi = currentLang.lowercase(Locale.ROOT).startsWith("vi")
        val notation = when {
            showScore && showTab -> if (vi) "Khuông nhạc + TAB" else "Notation + TAB"
            showScore -> if (vi) "Khuông nhạc" else "Notation"
            else -> "TAB"
        }
        val tail = when (instrument) {
            TabDisplayInstrument.NONE -> ""
            TabDisplayInstrument.GUITAR -> if (vi) " + Guitar" else " + Guitar fretboard"
            TabDisplayInstrument.PIANO -> if (vi) " + Piano" else " + Piano keyboard"
        }
        return notation + tail
    }

    companion object {
        fun fromSelection(score: Boolean, tab: Boolean, instrument: TabDisplayInstrument): TabDisplayMode {
            require(score || tab) { "Select notation or TAB" }
            return when (instrument) {
                TabDisplayInstrument.NONE -> when {
                    score && tab -> SCORE_TAB
                    score -> PARTITION_ONLY
                    else -> TAB_ONLY
                }
                TabDisplayInstrument.GUITAR -> when {
                    score && tab -> SCORE_TAB_FRETBOARD
                    score -> SCORE_FRETBOARD
                    else -> TAB_FRETBOARD
                }
                TabDisplayInstrument.PIANO -> when {
                    score && tab -> PIANO_TAB
                    score -> PIANO
                    else -> TAB_PIANO
                }
            }
        }
        fun fromStored(value: String?): TabDisplayMode =
            values().firstOrNull { it.jsValue == value } ?: SCORE_TAB
    }
}

private enum class TabSoundFontMode(
    val storedValue: String,
    val jsValue: String,
    val serverProfile: String?,
    val defaultDisplayName: String,
    val localFileName: String?,
    val localUrl: String?,
    val preferenceSuffix: String
) {
    STANDARD(
        storedValue = "standard",
        jsValue = "standard",
        serverProfile = null,
        defaultDisplayName = "Sonivox",
        localFileName = null,
        localUrl = null,
        preferenceSuffix = ""
    ),
    // Giữ storedValue/jsValue cũ để người đã tải FluidR3 ở phiên bản trước không bị mất lựa chọn.
    FLUIDR3(
        storedValue = "high_quality",
        jsValue = "high_quality",
        serverProfile = "fluidr3",
        defaultDisplayName = "FluidR3 GM",
        localFileName = FLUIDR3_SOUNDFONT_FILE_NAME,
        localUrl = LOCAL_FLUIDR3_SOUNDFONT_URL,
        preferenceSuffix = ""
    ),
    MUSESCORE(
        storedValue = "musescore_sf3",
        jsValue = "musescore_sf3",
        serverProfile = "musescore",
        defaultDisplayName = "MuseScore General",
        localFileName = MUSESCORE_SOUNDFONT_FILE_NAME,
        localUrl = LOCAL_MUSESCORE_SOUNDFONT_URL,
        preferenceSuffix = "_musescore_sf3"
    );

    val isDownloadable: Boolean
        get() = this != STANDARD

    val playbackUrl: String
        get() = when (this) {
            STANDARD -> STANDARD_SOUNDFONT_URL
            FLUIDR3 -> LOCAL_FLUIDR3_SOUNDFONT_URL
            MUSESCORE -> LOCAL_MUSESCORE_SOUNDFONT_URL
        }

    fun menuTitle(currentLang: String): String = when (this) {
        STANDARD -> soundFontText(
            "tab_sound_quality_low", currentLang,
            "Chất lượng thấp", "Low quality"
        )
        MUSESCORE -> soundFontText(
            "tab_sound_quality_medium", currentLang,
            "Chất lượng trung bình", "Medium quality"
        )
        FLUIDR3 -> soundFontText(
            "tab_sound_quality_high", currentLang,
            "Chất lượng cao", "High quality"
        )
    }

    fun menuDescription(currentLang: String): String = when (this) {
        STANDARD -> soundFontText(
            "tab_sound_no_extra_storage", currentLang,
            "Không tăng dung lượng app", "Does not increase app storage"
        )
        MUSESCORE -> ""
        FLUIDR3 -> ""
    }

    val estimatedAppIncreaseText: String
        get() = when (this) {
            STANDARD -> "0 MB"
            MUSESCORE -> "38 MB"
            FLUIDR3 -> "145 MB"
        }

    companion object {
        fun fromStoredValue(value: String?): TabSoundFontMode =
            values().firstOrNull { it.storedValue == value } ?: STANDARD

        fun fromJsValue(value: String?): TabSoundFontMode =
            values().firstOrNull { it.jsValue == value } ?: STANDARD
    }
}

private fun soundFontSizePreferenceKey(mode: TabSoundFontMode): String =
    SOUNDFONT_PREF_SIZE + mode.preferenceSuffix

private fun soundFontVersionPreferenceKey(mode: TabSoundFontMode): String =
    SOUNDFONT_PREF_VERSION + mode.preferenceSuffix

private fun soundFontPartVersionPreferenceKey(mode: TabSoundFontMode): String =
    SOUNDFONT_PREF_PART_VERSION + mode.preferenceSuffix

private data class TabSoundFontInfo(
    val mode: TabSoundFontMode,
    val displayName: String,
    val fileName: String,
    val sizeBytes: Long,
    val version: String,
    val downloadUrl: String
)

private fun formatStorageSize(bytes: Long): String {
    if (bytes <= 0L) return "--"
    val megabytes = bytes.toDouble() / (1024.0 * 1024.0)
    return if (megabytes >= 1024.0) {
        String.format(Locale.getDefault(), "%.2f GB", megabytes / 1024.0)
    } else {
        String.format(Locale.getDefault(), "%.1f MB", megabytes)
    }
}

private fun resolveSongTabApiEndpoint(apiBaseUrl: String, searchPath: String): String =
    when {
        searchPath.startsWith("http", ignoreCase = true) -> searchPath
        apiBaseUrl.trimEnd('/').endsWith(".php", ignoreCase = true) ->
            apiBaseUrl.trimEnd('/')
        else -> apiBaseUrl.trimEnd('/') + "/" + searchPath.trimStart('/')
    }

private fun appendUrlParameter(url: String, parameter: String): String =
    url + if (url.contains('?')) "&$parameter" else "?$parameter"

private fun loadTabSoundFontInfo(
    apiBaseUrl: String,
    searchPath: String,
    apiToken: String?,
    mode: TabSoundFontMode,
    currentLang: String
): TabSoundFontInfo {
    require(mode.isDownloadable) { "Chế độ tiêu chuẩn không cần tải SoundFont cục bộ." }

    val endpoint = resolveSongTabApiEndpoint(apiBaseUrl, searchPath)
    val profile = mode.serverProfile
        ?: throw IllegalStateException(
            soundFontText(
                "tab_sound_info_failed", currentLang,
                "Không thể đọc thông tin SoundFont.",
                "Could not read SoundFont information."
            )
        )
    val infoUrl = appendUrlParameter(
        appendUrlParameter(endpoint, "action=soundfont_info"),
        "profile=" + URLEncoder.encode(profile, StandardCharsets.UTF_8.name())
    )
    val connection = URL(infoUrl).openConnection() as HttpURLConnection

    try {
        connection.requestMethod = "GET"
        connection.connectTimeout = 15_000
        connection.readTimeout = 30_000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "TunerInstrument-Android")
        if (!apiToken.isNullOrBlank()) {
            connection.setRequestProperty("Authorization", "Bearer $apiToken")
        }

        val responseCode = connection.responseCode
        val responseText = (if (responseCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        })?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()

        if (responseCode !in 200..299) {
            val serverMessage = runCatching {
                JSONObject(responseText).optString("error")
            }.getOrNull().orEmpty()
            throw IllegalStateException(
                serverMessage.ifBlank {
                    soundFontFormat(
                        "tab_sound_server_http", currentLang,
                        "Máy chủ phản hồi HTTP %1\$d",
                        "Server returned HTTP %1\$d",
                        responseCode
                    )
                }
            )
        }

        val root = JSONObject(responseText)
        if (!root.optBoolean("success", false)) {
            throw IllegalStateException(
                root.optString("error").ifBlank {
                    soundFontText(
                        "tab_sound_info_failed", currentLang,
                        "Không thể đọc thông tin SoundFont.",
                        "Could not read SoundFont information."
                    )
                }
            )
        }

        val data = root.optJSONObject("data")
            ?: throw IllegalStateException(
                soundFontText(
                    "tab_sound_info_missing", currentLang,
                    "Máy chủ chưa trả về thông tin SoundFont.",
                    "The server did not return SoundFont information."
                )
            )
        val expectedFileName = mode.localFileName
            ?: throw IllegalStateException(
                soundFontText(
                    "tab_sound_info_failed", currentLang,
                    "Không thể đọc thông tin SoundFont.",
                    "Could not read SoundFont information."
                )
            )
        val fileName = data.optString("file_name").ifBlank { expectedFileName }
        if (!fileName.equals(expectedFileName, ignoreCase = true)) {
            throw IllegalStateException(
                soundFontFormat(
                    "tab_sound_wrong_file", currentLang,
                    "Máy chủ trả sai file SoundFont: %1\$s (mong đợi %2\$s).",
                    "The server returned the wrong SoundFont file: %1\$s (expected %2\$s).",
                    fileName,
                    expectedFileName
                )
            )
        }
        val downloadUrl = data.optString("download_url").ifBlank {
            appendUrlParameter(
                appendUrlParameter(endpoint, "action=download_soundfont"),
                "profile=" + URLEncoder.encode(profile, StandardCharsets.UTF_8.name())
            )
        }
        val sizeBytes = data.optLong("size_bytes", 0L)
        if (sizeBytes <= 0L) {
            throw IllegalStateException(
                soundFontText(
                    "tab_sound_invalid_size", currentLang,
                    "Kích thước SoundFont trên máy chủ không hợp lệ.",
                    "The server returned an invalid SoundFont size."
                )
            )
        }

        return TabSoundFontInfo(
            mode = mode,
            displayName = data.optString("display_name").ifBlank { mode.defaultDisplayName },
            fileName = fileName,
            sizeBytes = sizeBytes,
            version = data.optString("version"),
            downloadUrl = downloadUrl
        )
    } finally {
        connection.disconnect()
    }
}

private fun soundFontDirectory(context: Context): File =
    File(context.filesDir, "soundfonts")

private fun soundFontFile(context: Context, mode: TabSoundFontMode): File {
    require(mode.isDownloadable) { "Chế độ tiêu chuẩn không có file SoundFont cục bộ." }
    return File(
        soundFontDirectory(context),
        mode.localFileName ?: throw IllegalStateException("Thiếu tên file SoundFont.")
    )
}

private fun soundFontPartFile(context: Context, mode: TabSoundFontMode): File {
    require(mode.isDownloadable) { "Chế độ tiêu chuẩn không có file SoundFont tải dở." }
    val fileName = mode.localFileName
        ?: throw IllegalStateException("Thiếu tên file SoundFont.")
    return File(soundFontDirectory(context), "$fileName.part")
}

private data class LocalScorePayload(
    val requestUrl: String,
    val bytes: ByteArray
)

private data class LocalScoreSelection(
    val displayName: String,
    val extension: String,
    val bytes: ByteArray
)

private fun readLocalScoreFile(
    context: android.content.Context,
    uri: Uri
): LocalScoreSelection {
    val resolver = context.contentResolver
    var displayName: String? = null
    var declaredSize = -1L

    resolver.query(
        uri,
        arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
        null,
        null,
        null
    )?.use { cursor ->
        if (cursor.moveToFirst()) {
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && !cursor.isNull(nameIndex)) {
                displayName = cursor.getString(nameIndex)
            }

            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                declaredSize = cursor.getLong(sizeIndex)
            }
        }
    }

    val resolvedName = displayName
        ?.trim()
        ?.takeIf { it.isNotEmpty() }
        ?: uri.lastPathSegment
            ?.substringAfterLast('/')
            ?.substringAfterLast(':')
            ?.takeIf { it.isNotBlank() }
        ?: "ban_nhac.gp"

    val extension = resolvedName
        .substringAfterLast('.', missingDelimiterValue = "")
        .lowercase(Locale.ROOT)

    if (extension !in SUPPORTED_GP_EXTENSIONS) {
        throw IllegalArgumentException(
            "File không được hỗ trợ. Hãy chọn file GP3, GP4, GP5, GPX hoặc GP."
        )
    }

    if (declaredSize > LOCAL_SCORE_MAX_BYTES) {
        throw IllegalArgumentException("File quá lớn. Kích thước tối đa là 50 MB.")
    }

    val bytes = resolver.openInputStream(uri)?.use { input ->
        ByteArrayOutputStream().use { output ->
            val buffer = ByteArray(8 * 1024)
            var totalBytes = 0L

            while (true) {
                val readCount = input.read(buffer)
                if (readCount < 0) break
                if (readCount == 0) continue

                totalBytes += readCount
                if (totalBytes > LOCAL_SCORE_MAX_BYTES) {
                    throw IllegalArgumentException("File quá lớn. Kích thước tối đa là 50 MB.")
                }
                output.write(buffer, 0, readCount)
            }

            output.toByteArray()
        }
    } ?: throw IllegalStateException("Không thể đọc file đã chọn.")

    if (bytes.isEmpty()) {
        throw IllegalArgumentException("File đã chọn không có dữ liệu.")
    }

    return LocalScoreSelection(
        displayName = resolvedName,
        extension = extension,
        bytes = bytes
    )
}

private fun buildA4PdfJobName(rawTitle: String?): String {
    val safeTitle = rawTitle
        .orEmpty()
        .replace(Regex("""[\\/:*?"<>|]"""), "_")
        .replace(Regex("\\s+"), " ")
        .trim()
        .trim('.')
        .take(80)
        .ifBlank { "Ban_nhac" }

    return "${safeTitle}_A4.pdf"
}

private enum class TuneToolsItemType {
    FILE,
    FOLDER
}

private data class TuneToolsSong(
    val id: String,
    val title: String,
    val artist: String,
    val fileUrl: String,
    val format: String,
    val itemType: TuneToolsItemType = TuneToolsItemType.FILE,
    val rhythm: String = "",
    val subfolder: String = "",
    val relativePath: String = "",
    val folderPath: String = "",
    val parentPath: String = "",
    val librarySection: String = ""
) {
    val isFolder: Boolean
        get() = itemType == TuneToolsItemType.FOLDER
}

// -----------------------------------------------------------------------------
// GP server failover: alwaysdata (Google Drive) -> IIS (Windows local GP archive).
// Keep this in SongTabPlay.kt: no extra PHP is required on alwaysdata.
// Only a *verified* tab-relative path can be used to request a matching IIS file.
// Never infer a backup file from a similar song title or arbitrary URL.
// -----------------------------------------------------------------------------
private data class GpFailoverRoute(
    val primaryUrl: String,
    val backupUrl: String
)

private data class GpFailoverPayload(val bytes: ByteArray, val usedIis: Boolean)

private class GpDownloadHttpFailure(
    val statusCode: Int,
    val endpointMissing: Boolean = false
) : java.io.IOException("GP HTTP $statusCode")

private class GpDownloadInvalidContent(message: String) : java.io.IOException(message)

private object TuneToolsGpFailover {
    private const val PRIMARY_HOST = "tuner.alwaysdata.net"
    private const val BACKUP_DOWNLOAD_ENDPOINT =
        "https://tunertools.top/api_gp_search.php?action=download_gp&file="

    private const val PRIMARY_CONNECT_TIMEOUT_MS = 3500
    private const val PRIMARY_READ_TIMEOUT_MS = 12000
    private const val BACKUP_CONNECT_TIMEOUT_MS = 3500
    private const val BACKUP_READ_TIMEOUT_MS = 12000

    // Accept ONLY the known, public GP download endpoint on alwaysdata.
    // This prevents intercepting other application requests or following a
    // malformed/third-party download URL from an untrusted API response.
    private fun isTrustedDriveGpUrl(value: String): Boolean = try {
        val uri = java.net.URI(value)
        uri.scheme.equals("https", true) &&
                uri.host.equals(PRIMARY_HOST, true) &&
                (uri.port == -1 || uri.port == 443) &&
                uri.rawUserInfo == null &&
                uri.rawFragment == null &&
                uri.rawPath == "/api_gp_drive.php" &&
                uri.rawQuery.orEmpty().split('&').any { part ->
                    part.equals("action=file", true) ||
                            part.equals("action=section_file", true)
                }
    } catch (_: Exception) {
        false
    }

    // PHP on IIS resolves file relative to C:\\inetpub\\wwwroot\\tab.
    // A bulk DB sometimes stores a leading "tab/"; the manifest does not.
    // Reject absolute paths, traversal, and non-GP extensions before generating
    // a backup URL. The IIS PHP independently checks the resolved file path.
    private fun buildIisBackupUrl(relativePath: String): String? {
        val normalized = relativePath.trim().replace('\\', '/')
        if (normalized.isBlank() || normalized.startsWith('/') ||
            normalized.indexOf('\u0000') >= 0 ||
            Regex("^[A-Za-z]:").containsMatchIn(normalized)
        ) return null
        val segments = normalized.split('/')
        if (segments.any { it.isBlank() || it == "." || it == ".." || ':' in it }) return null
        val adjusted = if (segments.first().equals("tab", true)) segments.drop(1) else segments
        if (adjusted.isEmpty()) return null
        val suffix = adjusted.last().substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (suffix !in SUPPORTED_GP_EXTENSIONS) return null
        return BACKUP_DOWNLOAD_ENDPOINT + URLEncoder.encode(
            adjusted.joinToString("/"), StandardCharsets.UTF_8.name()
        )
    }

    fun routeFor(song: TuneToolsSong): GpFailoverRoute? {
        if (song.isFolder || !isTrustedDriveGpUrl(song.fileUrl)) return null
        val backup = buildIisBackupUrl(song.relativePath) ?: return null
        return GpFailoverRoute(primaryUrl = song.fileUrl, backupUrl = backup)
    }

    // A missing PRIMARY PHP script returns HTTP 404 with an HTML/plain-text page.
    // It is a server availability problem, so use IIS. A JSON 404 (missing GP)
    // is NOT automatically bypassed. Never bypass primary 401 or 403.
    private fun canFailOver(error: Exception): Boolean = when (error) {
        is GpDownloadHttpFailure ->
            (error.statusCode == 404 && error.endpointMissing) ||
                    error.statusCode == 408 || error.statusCode == 429 ||
                    error.statusCode in 500..599
        is javax.net.ssl.SSLException -> false
        is java.io.IOException -> true  // DNS, timeout, reset, truncated/invalid upstream file
        else -> false
    }

    fun fetch(route: GpFailoverRoute): GpFailoverPayload {
        try {
            return GpFailoverPayload(downloadBytes(route.primaryUrl, true), usedIis = false)
        } catch (primaryError: Exception) {
            if (!canFailOver(primaryError)) throw primaryError
            android.util.Log.w(
                "TuneToolsGpFailover", "Primary GP download failed; using IIS", primaryError
            )
            try {
                return GpFailoverPayload(downloadBytes(route.backupUrl, false), usedIis = true)
            } catch (backupError: Exception) {
                val bothFailed = java.io.IOException(
                    "Cả alwaysdata và máy chủ IIS đều không tải được file Guitar Pro.",
                    backupError
                )
                bothFailed.addSuppressed(primaryError)
                throw bothFailed
            }
        }
    }

    private fun downloadBytes(url: String, primary: Boolean): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.instanceFollowRedirects = false
            conn.requestMethod = "GET"
            conn.connectTimeout = if (primary) PRIMARY_CONNECT_TIMEOUT_MS else BACKUP_CONNECT_TIMEOUT_MS
            conn.readTimeout = if (primary) PRIMARY_READ_TIMEOUT_MS else BACKUP_READ_TIMEOUT_MS
            conn.useCaches = false
            conn.setRequestProperty("Accept", "application/octet-stream")
            conn.setRequestProperty("Accept-Encoding", "identity")
            conn.setRequestProperty("User-Agent", "TunerTools-Android-GP-Failover")
            val status = conn.responseCode
            // This request does not send a Range header: partial data must not be
            // passed to alphaTab, even if the upstream reports HTTP 206.
            if (status != 200) {
                // When api_gp_drive.php is deleted or its route is not deployed,
                // the hosting layer normally returns HTML, not an API JSON error.
                // A trusted GP route with an exact relative_path can then use IIS.
                val responseType = conn.contentType.orEmpty().lowercase(Locale.ROOT)
                val phpEndpointMissing = status == 404 && (
                    responseType.isBlank() ||
                        responseType.startsWith("text/html") ||
                        responseType.startsWith("text/plain") ||
                        responseType.startsWith("application/xhtml+xml")
                )
                throw GpDownloadHttpFailure(status, endpointMissing = phpEndpointMissing)
            }
            val size = conn.contentLengthLong
            if (size > LOCAL_SCORE_MAX_BYTES) {
                throw IllegalArgumentException("File GP vượt giới hạn 50 MB")
            }
            val mime = conn.contentType.orEmpty().lowercase(Locale.ROOT)
            if (mime.startsWith("text/html") || mime.startsWith("application/json")) {
                throw GpDownloadInvalidContent("Máy chủ trả HTML/JSON thay vì file GP")
            }
            val output = ByteArrayOutputStream()
            conn.inputStream.use { stream ->
                val buffer = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val n = stream.read(buffer)
                    if (n == -1) break
                    total += n
                    if (total > LOCAL_SCORE_MAX_BYTES) {
                        throw IllegalArgumentException("File GP vượt giới hạn 50 MB")
                    }
                    output.write(buffer, 0, n)
                }
            }
            val bytes = output.toByteArray()
            if (bytes.isEmpty() || (size >= 0 && bytes.size.toLong() != size)) {
                throw GpDownloadInvalidContent("Dữ liệu GP trống hoặc tải chưa đủ")
            }
            val prefix = bytes.take(64).toByteArray()
                .toString(StandardCharsets.UTF_8).trimStart().lowercase(Locale.ROOT)
            if (prefix.startsWith("<!doctype") || prefix.startsWith("<html") ||
                prefix.startsWith("{") || prefix.startsWith("[")) {
                throw GpDownloadInvalidContent("Nội dung trả về không phải file GP")
            }
            return bytes
        } finally {
            conn.disconnect()
        }
    }
}

data class AlphaTrack(
    val index: Int,
    val name: String
)


// The legend only shows items actually found in the selected Guitar Pro track.
private data class SongTechniqueDefinition(
    val symbol: String,
    val nameVi: String,
    val nameEn: String,
    val descriptionVi: String,
    val descriptionEn: String,
    val notation: Boolean = false
)

private val SONG_TECHNIQUE_LEGEND = linkedMapOf(
    "hammer" to SongTechniqueDefinition("H", "Hammer-on", "Hammer-on", "Gõ ngón lên ngăn cao hơn mà không gảy dây lần nữa.", "Hammer on a higher fret without picking again."),
    "pull" to SongTechniqueDefinition("P", "Pull-off", "Pull-off", "Nhấc ngón để phát nốt thấp hơn trên cùng dây.", "Release a fretting finger to sound a lower note."),
    "legato" to SongTechniqueDefinition("⌒", "Legato / Slur", "Legato / slur", "Nối các nốt liền mạch; hạn chế gảy lại khi phù hợp.", "Connect notes smoothly, often with fewer pick attacks."),
    "tie" to SongTechniqueDefinition("⌒", "Nối trường độ", "Tie", "Kéo dài cùng một cao độ qua nhiều nốt, không đánh lại nốt nối.", "Sustain the same pitch across tied notes without a new attack."),
    "slide" to SongTechniqueDefinition("/ \\", "Slide", "Slide", "Trượt ngón từ ngăn này đến ngăn khác trên cùng dây.", "Move a fretting finger between frets on the same string."),
    "pick_slide" to SongTechniqueDefinition("P.S.", "Pick slide", "Pick slide", "Vuốt miếng gảy dọc theo dây để tạo tiếng cào.", "Scrape the pick along the string."),
    "bend" to SongTechniqueDefinition("↗", "Bend / Release", "Bend / release", "Đẩy dây để thay đổi cao độ; release là trả dây về.", "Push a string to raise pitch and release it back."),
    "vibrato" to SongTechniqueDefinition("~~~~", "Vibrato", "Vibrato", "Rung cao độ nhẹ và liên tục ở nốt đang giữ.", "Gently oscillate the pitch of a held note."),
    "wide_vibrato" to SongTechniqueDefinition("~~~~", "Wide vibrato", "Wide vibrato", "Rung dây với biên độ rộng hơn vibrato thông thường.", "Oscillate the pitch with wider movement."),
    "trill" to SongTechniqueDefinition("tr", "Trill", "Trill", "Luân phiên nhanh hai cao độ liền kề.", "Rapid alternation between two pitches."),
    "tremolo" to SongTechniqueDefinition("TR ///", "Tremolo picking", "Tremolo picking", "Gảy lặp một nốt rất nhanh; số vạch thể hiện độ chia nhịp.", "Rapid repeated picking; slashes indicate rhythmic subdivision."),
    "buzz" to SongTechniqueDefinition("Buzz", "Buzz roll", "Buzz roll", "Đánh lặp/nhấn tạo âm rung liên tục theo ký hiệu file nhạc.", "A sustained buzzing roll indicated by the score."),
    "whammy" to SongTechniqueDefinition("↘↗", "Tremolo bar / Whammy", "Tremolo / whammy bar", "Dùng cần rung để hạ, nâng hoặc trả cao độ.", "Use the whammy bar to dip or restore pitch."),
    "harmonic" to SongTechniqueDefinition("◇", "Harmonic", "Harmonic", "Âm bồi tự nhiên, nhân tạo, pinch hoặc các dạng harmonic khác.", "Natural, artificial, pinch, tap and other harmonics."),
    "palm_mute" to SongTechniqueDefinition("P.M.", "Palm mute", "Palm mute", "Đặt nhẹ cạnh bàn tay lên dây gần ngựa đàn để làm tiếng ngắn/đục.", "Lightly mute near the bridge with the picking hand."),
    "let_ring" to SongTechniqueDefinition("Let ring", "Let ring", "Let ring", "Để dây ngân tự nhiên, không chặn ngay sau khi gảy.", "Allow the note to ring instead of damping it."),
    "dead" to SongTechniqueDefinition("×", "Dead note", "Dead note", "Chặn dây để tạo âm gõ không có cao độ rõ ràng.", "Muted percussive note without a clear pitch."),
    "ghost" to SongTechniqueDefinition("( )", "Ghost note", "Ghost note", "Nốt nhẹ, thường nằm trong ngoặc.", "A softer, parenthesized note."),
    "staccato" to SongTechniqueDefinition("·", "Staccato", "Staccato", "Ngắt nốt ngắn hơn trường độ ghi trên khuông.", "Play the note shorter than its written value."),
    "accent" to SongTechniqueDefinition(">", "Accent", "Accent", "Nhấn mạnh nốt hơn các nốt xung quanh.", "Stress a note more strongly than surrounding notes."),
    "heavy_accent" to SongTechniqueDefinition(">>", "Heavy accent", "Heavy accent", "Nhấn nốt rất mạnh.", "Give the note a strong accent."),
    "tenuto" to SongTechniqueDefinition("—", "Tenuto", "Tenuto", "Giữ nốt đầy đủ trường độ và nhấn nhẹ.", "Hold the note to its full value with slight emphasis."),
    "tapping" to SongTechniqueDefinition("T", "Tapping", "Tapping", "Gõ lên cần đàn bằng tay phải hoặc tay trái.", "Sound a note by tapping the fretboard."),
    "grace" to SongTechniqueDefinition("♪", "Grace note", "Grace note", "Nốt trang trí ngắn trước hoặc đúng vào phách.", "A short ornamental note before or on the beat."),
    "turn" to SongTechniqueDefinition("↷", "Turn / Inverted turn", "Turn / inverted turn", "Luyến nhanh quanh nốt chính bằng các nốt kề.", "An ornament circling the main note."),
    "mordent" to SongTechniqueDefinition("M", "Mordent", "Mordent", "Chèn một nốt kề rất nhanh rồi về nốt chính.", "Quickly alternate with a neighboring pitch."),
    "strum" to SongTechniqueDefinition("↑ ↓", "Strum", "Strum", "Quạt qua nhiều dây theo hướng lên hoặc xuống.", "Brush multiple strings upward or downward."),
    "arpeggio" to SongTechniqueDefinition("Arp.", "Arpeggio", "Arpeggio", "Rải các nốt của hợp âm theo thứ tự thay vì cùng một lúc.", "Play chord notes in sequence instead of simultaneously."),
    "pick_stroke" to SongTechniqueDefinition("↑ ↓", "Hướng gảy pick", "Pick stroke", "Ký hiệu hướng gảy lên hoặc xuống của miếng gảy.", "Pick upstroke or downstroke indication."),
    "barre" to SongTechniqueDefinition("B / ½B", "Barre / Half barre", "Barre / half barre", "Dùng một ngón chặn nhiều dây cùng một ngăn.", "Use one finger to fret multiple strings at the same fret."),
    "slap" to SongTechniqueDefinition("S", "Slap", "Slap", "Đập ngón cái vào dây, thường gặp ở bass.", "Strike the string with the thumb, often on bass."),
    "pop" to SongTechniqueDefinition("P", "Pop", "Pop", "Móc rồi bật dây tạo âm sắc mạnh, thường trên bass.", "Pull and release a string for a snappy bass tone."),
    "dead_slap" to SongTechniqueDefinition("×S", "Dead slap", "Dead slap", "Đập dây đã chặn để tạo âm gõ.", "Percussive slap on a muted string."),
    "rasgueado" to SongTechniqueDefinition("Rasg.", "Rasgueado", "Rasgueado", "Quạt nhiều ngón liên tiếp theo phong cách guitar cổ điển/flamenco.", "Rapid multi-finger strumming, often flamenco."),
    "golpe" to SongTechniqueDefinition("G", "Golpe", "Golpe", "Gõ vào mặt đàn bằng ngón tay hoặc ngón cái.", "Tap the guitar top with a finger or thumb."),
    "wah" to SongTechniqueDefinition("Wah", "Wah pedal", "Wah pedal", "Ký hiệu pedal wah ở vị trí mở hoặc đóng.", "Wah pedal open/closed indication."),
    "fade" to SongTechniqueDefinition("Fade", "Fade / Swell", "Fade / swell", "Hiệu ứng tăng, giảm hoặc phồng âm lượng.", "Fade in, fade out or swell the volume."),
    "crescendo" to SongTechniqueDefinition("< >", "Crescendo / Diminuendo", "Crescendo / diminuendo", "Tăng hoặc giảm âm lượng dần theo đoạn.", "Gradually increase or decrease volume."),
    "fermata" to SongTechniqueDefinition("𝄐", "Fermata", "Fermata", "Ngân nốt hoặc dấu nghỉ lâu hơn trường độ viết.", "Hold a note or rest beyond its written duration."),
    "fingering" to SongTechniqueDefinition("1–4", "Số ngón bấm/gảy", "Fingering", "Số ngón tay trái hoặc ký hiệu ngón gảy tay phải.", "Left-hand finger numbers or right-hand finger marks."),
    "key_signature" to SongTechniqueDefinition("♯ ♭", "Hóa biểu", "Key signature", "Dấu thăng/giáng ở đầu khuông quy định các nốt thay đổi cao độ.", "Sharps/flats at the start of the staff define the key.", true),
    "time_signature" to SongTechniqueDefinition("4/4", "Số chỉ nhịp", "Time signature", "Số trên là phách mỗi ô nhịp, số dưới là loại nốt tính một phách.", "Top number counts beats per bar; bottom defines the beat note.", true),
    "tempo" to SongTechniqueDefinition("♩=", "Tốc độ (BPM)", "Tempo (BPM)", "Chỉ tốc độ bài nhạc, có thể thay đổi giữa các ô nhịp.", "Tempo indication; may change during the score.", true),
    "dynamics" to SongTechniqueDefinition("p mf f", "Cường độ", "Dynamics", "p: nhẹ; mf: vừa mạnh; f/ff: mạnh/rất mạnh.", "p is soft, mf moderately loud, f/ff loud/very loud.", true),
    "tuplet" to SongTechniqueDefinition("3", "Liên ba / Tuplet", "Tuplet", "Chia nhóm nốt theo tỷ lệ khác cách chia nhịp thông thường.", "A rhythmic subdivision such as triplets.", true),
    "repeat" to SongTechniqueDefinition("𝄆 𝄇", "Lặp đoạn", "Repeat signs", "Quay lại và chơi lặp đoạn nhạc theo dấu lặp.", "Repeat the marked score section.", true),
    "chord_symbol" to SongTechniqueDefinition("Am7", "Tên hợp âm", "Chord symbol", "Tên hợp âm được khai báo trong bản Guitar Pro.", "Chord name supplied by the Guitar Pro score.", true),
    "rest" to SongTechniqueDefinition("𝄽", "Dấu nghỉ", "Rest", "Khoảng im lặng theo giá trị trường độ tương ứng.", "Silence for the notated duration.", true)
)


/**
 * Ba nhóm nội dung ở màn hình Bản nhạc.
 *
 * Nhạc Việt đọc trực tiếp cây thư mục /tab/Vietnam qua section=nhac_viet.
 * Quốc tế giữ nguyên luồng tìm kiếm SQLite/JSON cũ. Điệu nhạc dùng
 * section=dieu_nhac và rhythm=<tên điệu> để lấy các file GP bên trong.
 */
private enum class MusicLibrarySection {
    NHAC_VIET,
    QUOC_TE,
    DIEU_NHAC;

    fun tabTitle(currentLang: String): String = when (this) {
        NHAC_VIET -> soundFontText(
            "tab_library_vietnamese_title", currentLang,
            "Nhạc Việt", "Vietnamese"
        )
        QUOC_TE -> soundFontText(
            "tab_library_international_title", currentLang,
            "Quốc tế", "International"
        )
        DIEU_NHAC -> soundFontText(
            "tab_library_rhythms_title", currentLang,
            "Điệu nhạc", "Rhythms"
        )
    }

    fun searchHint(currentLang: String): String = when (this) {
        NHAC_VIET -> soundFontText(
            "tab_library_search_vietnamese", currentLang,
            "Tìm bài hát Việt Nam...", "Search Vietnamese songs..."
        )
        QUOC_TE -> soundFontText(
            "tab_library_search_international", currentLang,
            "Tìm bài hát quốc tế...", "Search international songs..."
        )
        DIEU_NHAC -> soundFontText(
            "tab_library_search_rhythms", currentLang,
            "Tìm Bolero, Ballad, Disco...", "Search Bolero, Ballad, Disco..."
        )
    }

    fun emptyTitle(currentLang: String): String = when (this) {
        NHAC_VIET -> soundFontText(
            "tab_library_empty_vietnamese_title", currentLang,
            "Chưa có dữ liệu Nhạc Việt", "No Vietnamese music yet"
        )
        QUOC_TE -> soundFontText(
            "tab_library_empty_international_title", currentLang,
            "Chưa có nhạc quốc tế", "No international music yet"
        )
        DIEU_NHAC -> soundFontText(
            "tab_library_empty_rhythms_title", currentLang,
            "Chưa có điệu nhạc", "No rhythms yet"
        )
    }

    fun emptyMessage(currentLang: String): String = when (this) {
        NHAC_VIET -> soundFontText(
            "tab_library_empty_vietnamese_desc", currentLang,
            "Các thư mục và file GP trong tab/Vietnam sẽ hiển thị tại đây.",
            "Folders and Guitar Pro files from tab/Vietnam will appear here."
        )
        QUOC_TE -> soundFontText(
            "tab_library_empty_international_desc", currentLang,
            "Danh sách bài hát quốc tế sẽ hiển thị tại đây.",
            "International songs will appear here."
        )
        DIEU_NHAC -> soundFontText(
            "tab_library_empty_rhythms_desc", currentLang,
            "Các điệu Bolero, Ballad, Rumba, Disco... sẽ hiển thị tại đây.",
            "Bolero, Ballad, Rumba, Disco and other rhythms will appear here."
        )
    }
}

@Composable
private fun SongTechniqueGuideRow(
    detail: SongTechniqueDefinition,
    vietnamese: Boolean,
    dark: Boolean,
    textColor: Color,
    mutedColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .background(if (dark) Color(0xFF222838) else Color(0xFFF5F6FB))
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .width(59.dp)
                .heightIn(min = 34.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(if (dark) Color(0xFF3C285A) else Color(0xFFEDE9FE)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = detail.symbol,
                color = if (dark) Color(0xFFE9D5FF) else Color(0xFF6D28D9),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (vietnamese) detail.nameVi else detail.nameEn,
                color = textColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (vietnamese) detail.descriptionVi else detail.descriptionEn,
                color = mutedColor,
                fontSize = 11.5.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun MusicLibraryTabs(
    selectedSection: MusicLibrarySection,
    currentLang: String,
    isDark: Boolean,
    accentColor: Color,
    onSectionSelected: (MusicLibrarySection) -> Unit
) {
    val outerShape = RoundedCornerShape(13.dp)
    val itemShape = RoundedCornerShape(10.dp)
    val outerColor = if (isDark) Color(0xFF111111) else Color.White
    val outerBorder = if (isDark) {
        Color.White.copy(alpha = 0.14f)
    } else {
        Color.Black.copy(alpha = 0.10f)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .height(44.dp)
            .clip(outerShape)
            .background(outerColor)
            .border(1.dp, outerBorder, outerShape)
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MusicLibrarySection.values().forEach { section ->
            val selected = section == selectedSection
            val itemBackground = when {
                selected && isDark -> accentColor.copy(alpha = 0.24f)
                selected -> accentColor
                else -> Color.Transparent
            }
            val itemTextColor = when {
                selected -> Color.White
                isDark -> Color.White.copy(alpha = 0.68f)
                else -> Color(0xFF616161)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(itemShape)
                    .background(itemBackground)
                    .then(
                        if (selected && isDark) {
                            Modifier.border(
                                1.dp,
                                accentColor.copy(alpha = 0.75f),
                                itemShape
                            )
                        } else {
                            Modifier
                        }
                    )
                    .clickable { onSectionSelected(section) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = section.tabTitle(currentLang),
                    color = itemTextColor,
                    fontSize = 12.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun SongTabGoogleGIcon(modifier: Modifier = Modifier) {
    // Google multicolour G drawn directly from vector path data.
    // No PNG/drawable resource is required.
    val bluePath = remember {
        PathParser.createPathFromPathData(
            "M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47a5.55 5.55 0 0 1-2.4 3.54v2.95h3.88c2.27-2.09 3.54-5.17 3.54-8.73z"
        )!!.asComposePath()
    }
    val greenPath = remember {
        PathParser.createPathFromPathData(
            "M12 24c3.24 0 5.95-1.07 7.94-2.9l-3.88-2.95c-1.08.72-2.46 1.15-4.06 1.15-3.13 0-5.78-2.11-6.73-4.95H1.27v3.04A12 12 0 0 0 12 24z"
        )!!.asComposePath()
    }
    val yellowPath = remember {
        PathParser.createPathFromPathData(
            "M5.27 14.35A7.2 7.2 0 0 1 4.9 12c0-.82.14-1.61.37-2.35V6.61H1.27A12 12 0 0 0 0 12c0 1.93.46 3.76 1.27 5.39l4-3.04z"
        )!!.asComposePath()
    }
    val redPath = remember {
        PathParser.createPathFromPathData(
            "M12 4.7c1.77 0 3.35.61 4.6 1.8l3.44-3.44A11.54 11.54 0 0 0 12 0 12 12 0 0 0 1.27 6.61l4 3.04C6.22 6.81 8.87 4.7 12 4.7z"
        )!!.asComposePath()
    }

    Canvas(modifier = modifier) {
        val targetSize = size.minDimension
        val scaleFactor = targetSize / 24f
        val offsetX = (size.width - targetSize) / 2f
        val offsetY = (size.height - targetSize) / 2f

        withTransform({
            translate(left = offsetX, top = offsetY)
            scale(scaleX = scaleFactor, scaleY = scaleFactor, pivot = Offset.Zero)
        }) {
            drawPath(redPath, Color(0xFFEA4335))
            drawPath(yellowPath, Color(0xFFFBBC05))
            drawPath(greenPath, Color(0xFF34A853))
            drawPath(bluePath, Color(0xFF4285F4))
        }
    }
}

/**
 * C-major open chord diagram (x32010), drawn directly by Compose.
 * Order, left to right: E6(x), A5(3), D4(2), G3(0), B2(1), E1(0).
 * No PNG, drawable resource, network request or external icon library.
 */
@Composable
private fun SongTabCChordIcon(
    modifier: Modifier = Modifier,
    isDark: Boolean = false,
    selected: Boolean = false,
    accentColor: Color = Color(0xFF6D28D9)
) {
    Canvas(modifier = modifier) {
        val side = size.minDimension
        if (side <= 0f) return@Canvas
        val scaleFactor = side / 100f
        val left = (size.width - side) / 2f
        val top = (size.height - side) / 2f
        val lineColor = if (isDark) Color(0xFFE0E7F0) else Color(0xFF475569)
        val fingerColor = if (selected) accentColor
        else if (isDark) Color(0xFFA78BFA) else Color(0xFF6D28D9)

        withTransform({
            translate(left = left, top = top)
            scale(scaleX = scaleFactor, scaleY = scaleFactor, pivot = Offset.Zero)
        }) {
            // Strings are vertical (low E on the left, high E on the right).
            val x0 = 19f
            val stepX = 14.4f
            val nutY = 29f
            val fretStep = 16f
            for (stringIndex in 0..5) {
                val x = x0 + stringIndex * stepX
                drawLine(lineColor.copy(alpha = 0.86f), Offset(x, nutY), Offset(x, nutY + 4 * fretStep), 1.7f)
            }
            for (fretLine in 0..4) {
                val y = nutY + fretLine * fretStep
                drawLine(lineColor, Offset(x0, y), Offset(x0 + 5 * stepX, y),
                    if (fretLine == 0) 4.4f else 1.7f)
            }

            // Muted low E (x); open G and high E (o).
            val markerY = 19f
            val mutedX = x0
            drawLine(lineColor, Offset(mutedX - 3.8f, markerY - 3.8f),
                Offset(mutedX + 3.8f, markerY + 3.8f), 2.4f, StrokeCap.Round)
            drawLine(lineColor, Offset(mutedX - 3.8f, markerY + 3.8f),
                Offset(mutedX + 3.8f, markerY - 3.8f), 2.4f, StrokeCap.Round)
            listOf(3, 5).forEach { openString ->
                drawCircle(color = fingerColor, radius = 4.8f,
                    center = Offset(x0 + openString * stepX, markerY),
                    style = Stroke(width = 2.5f))
            }

            fun finger(stringIndex: Int, fret: Int) {
                val center = Offset(
                    x0 + stringIndex * stepX,
                    nutY + (fret - 0.5f) * fretStep
                )
                drawCircle(color = fingerColor, radius = 6.5f, center = center)
                drawCircle(color = if (isDark) Color(0xFF151827) else Color.White,
                    radius = 1.6f, center = center)
            }
            finger(stringIndex = 1, fret = 3) // A string, C3
            finger(stringIndex = 2, fret = 2) // D string, E3
            finger(stringIndex = 4, fret = 1) // B string, C4

            // Chord name within the icon, without another image or font resource.
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = fingerColor.toArgb()
                textSize = 16f
                isFakeBoldText = true
                textAlign = android.graphics.Paint.Align.CENTER
            }
            drawContext.canvas.nativeCanvas.drawText("C", 43f, 15f, paint)
        }
    }
}

@Composable
private fun SongTabGmailBrandIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val diameter = size.minDimension
        val originX = (size.width - diameter) / 2f
        val originY = (size.height - diameter) / 2f

        drawRoundRect(
            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                colors = listOf(
                    Color(0xFF8CB8F8),
                    Color(0xFF4C82D8),
                    Color(0xFF655FD3)
                ),
                start = Offset(originX, originY),
                end = Offset(originX + diameter, originY + diameter)
            ),
            topLeft = Offset(originX, originY),
            size = Size(diameter, diameter),
            cornerRadius = CornerRadius(diameter * 0.25f, diameter * 0.25f)
        )

        val tileInset = diameter * 0.13f
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(originX + tileInset, originY + tileInset),
            size = Size(diameter - tileInset * 2f, diameter - tileInset * 2f),
            cornerRadius = CornerRadius(diameter * 0.18f, diameter * 0.18f)
        )

        val leftX = originX + diameter * 0.31f
        val centerX = originX + diameter * 0.50f
        val rightX = originX + diameter * 0.69f
        val topY = originY + diameter * 0.36f
        val valleyY = originY + diameter * 0.55f
        val bottomY = originY + diameter * 0.70f
        val markWidth = diameter * 0.105f

        drawLine(Color(0xFFEA4335), Offset(leftX, bottomY), Offset(leftX, topY), markWidth, StrokeCap.Round)
        drawLine(Color(0xFFEA4335), Offset(leftX, topY), Offset(centerX, valleyY), markWidth, StrokeCap.Round)

        val diagonalOrange = Offset(
            centerX + (rightX - centerX) * 0.58f,
            valleyY + (topY - valleyY) * 0.58f
        )
        drawLine(Color(0xFFFF4B3E), Offset(centerX, valleyY), diagonalOrange, markWidth, StrokeCap.Round)
        drawLine(Color(0xFFFFB300), diagonalOrange, Offset(rightX, topY), markWidth, StrokeCap.Round)

        val greenStartY = topY + (bottomY - topY) * 0.23f
        val blueStartY = topY + (bottomY - topY) * 0.60f
        drawLine(Color(0xFFFFC107), Offset(rightX, topY), Offset(rightX, greenStartY), markWidth, StrokeCap.Round)
        drawLine(Color(0xFF20B86A), Offset(rightX, greenStartY), Offset(rightX, blueStartY), markWidth, StrokeCap.Round)
        drawLine(Color(0xFF4285F4), Offset(rightX, blueStartY), Offset(rightX, bottomY), markWidth, StrokeCap.Round)
    }
}

@Composable
private fun SongTabZaloBrandIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val diameter = size.minDimension
        val originX = (size.width - diameter) / 2f
        val originY = (size.height - diameter) / 2f

        drawRoundRect(
            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                colors = listOf(
                    Color(0xFF2497FF),
                    Color(0xFF1469EE),
                    Color(0xFF6753D8)
                ),
                start = Offset(originX, originY),
                end = Offset(originX + diameter, originY + diameter)
            ),
            topLeft = Offset(originX, originY),
            size = Size(diameter, diameter),
            cornerRadius = CornerRadius(diameter * 0.25f, diameter * 0.25f)
        )

        val bubbleLeft = originX + diameter * 0.16f
        val bubbleTop = originY + diameter * 0.17f
        val bubbleWidth = diameter * 0.68f
        val bubbleHeight = diameter * 0.60f
        val bubbleCorner = CornerRadius(diameter * 0.18f, diameter * 0.18f)

        drawRoundRect(
            color = Color.White,
            topLeft = Offset(bubbleLeft, bubbleTop),
            size = Size(bubbleWidth, bubbleHeight),
            cornerRadius = bubbleCorner
        )
        val bubbleTail = androidx.compose.ui.graphics.Path().apply {
            moveTo(bubbleLeft + diameter * 0.17f, bubbleTop + bubbleHeight - diameter * 0.02f)
            lineTo(bubbleLeft + diameter * 0.11f, bubbleTop + bubbleHeight + diameter * 0.13f)
            lineTo(bubbleLeft + diameter * 0.31f, bubbleTop + bubbleHeight - diameter * 0.015f)
            close()
        }
        drawPath(path = bubbleTail, color = Color.White)

        val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFF0868F2).toArgb()
            textAlign = android.graphics.Paint.Align.CENTER
            textSize = diameter * 0.245f
            typeface = android.graphics.Typeface.create(
                android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD
            )
        }
        val metrics = textPaint.fontMetrics
        val textCenterY = bubbleTop + bubbleHeight * 0.50f
        val baseline = textCenterY - (metrics.ascent + metrics.descent) / 2f
        drawContext.canvas.nativeCanvas.drawText(
            "Zalo",
            originX + diameter * 0.50f,
            baseline,
            textPaint
        )
    }
}

@Composable
private fun SongTabContactActionRow(
    textColor: Color,
    label: String,
    value: String,
    onClick: () -> Unit,
    iconContent: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .clickable(onClick = onClick),
        color = textColor.copy(alpha = 0.045f),
        shape = RoundedCornerShape(11.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, textColor.copy(alpha = 0.13f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(textColor.copy(alpha = 0.07f)),
                contentAlignment = Alignment.Center
            ) {
                iconContent()
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    color = textColor.copy(alpha = 0.56f),
                    fontSize = 10.sp,
                    lineHeight = 12.sp
                )
                Text(
                    text = value,
                    color = textColor,
                    fontSize = 12.sp,
                    lineHeight = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = textColor.copy(alpha = 0.42f),
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

@Composable
private fun SongTabMetronomeIcon(
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val lineWidth = size.minDimension * 0.085f
        val frame = Path().apply {
            moveTo(w * 0.28f, h * 0.80f)
            lineTo(w * 0.44f, h * 0.25f)
            lineTo(w * 0.56f, h * 0.25f)
            lineTo(w * 0.72f, h * 0.80f)
            close()
        }
        drawPath(frame, color, style = Stroke(width = lineWidth))
        drawLine(
            color = color,
            start = Offset(w * 0.50f, h * 0.66f),
            end = Offset(w * 0.76f, h * 0.13f),
            strokeWidth = lineWidth,
            cap = StrokeCap.Round
        )
        drawCircle(color, radius = lineWidth * 1.05f, center = Offset(w * 0.76f, h * 0.13f))
        drawLine(
            color = color,
            start = Offset(w * 0.21f, h * 0.86f),
            end = Offset(w * 0.79f, h * 0.86f),
            strokeWidth = lineWidth,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun SongTabLoadingWave(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFF15B27D)
) {
    val transition = rememberInfiniteTransition(label = "song_tab_loading_wave")
    val maxHeights = listOf(0.46f, 0.72f, 1.0f, 0.72f, 0.46f)

    Row(
        modifier = modifier.height(46.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        maxHeights.forEachIndexed { index, maxHeight ->
            val heightFactor by transition.animateFloat(
                initialValue = 0.18f,
                targetValue = maxHeight,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 430,
                        delayMillis = index * 85,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "song_tab_loading_wave_$index"
            )

            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height((46f * heightFactor).dp)
                    .clip(RoundedCornerShape(50))
                    .background(color)
            )
        }
    }
}

@Composable
private fun SongTabAccessLoadingScreen(
    isDark: Boolean
) {
    val bgColor = if (isDark) Color.Black else Color(0xFFF5F6FA)
    val accentColor = Color(0xFF15B27D)

    // Một loader duy nhất dùng xuyên suốt cả giai đoạn kiểm tra quyền và tải
    // danh sách ban đầu. Không hiển thị tiêu đề hoặc nút Back khi đang tải.
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = bgColor
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            SongTabLoadingWave(color = accentColor)
        }
    }
}

@Composable
private fun SongTabAccessGateScreen(
    isDark: Boolean,
    state: DocumentAccessState,
    currentLang: String,
    onClose: () -> Unit,
    onLogin: () -> Unit,
    onRetry: () -> Unit
) {
    val bgColor = if (isDark) Color.Black else Color(0xFFF5F6FA)
    val surfaceColor = if (isDark) Color(0xFF121212) else Color.White
    val textColor = if (isDark) Color.White else Color(0xFF202124)
    val accentColor = Color(0xFF15B27D)
    val context = LocalContext.current
    val supportEmail = "tunertools.top@gmail.com"
    val supportZaloPhone = "0971832146"

    fun accessText(
        key: String,
        vietnameseFallback: String,
        englishFallback: String
    ): String = soundFontText(
        key = key,
        currentLang = currentLang,
        vietnameseFallback = vietnameseFallback,
        englishFallback = englishFallback
    )

    fun launchContactIntent(primary: Intent, fallback: Intent) {
        val opened = runCatching {
            context.startActivity(primary)
            true
        }.getOrDefault(false)

        if (!opened) {
            runCatching { context.startActivity(fallback) }
                .onFailure {
                    Toast.makeText(
                        context,
                        accessText(
                            "tab_access_contact_open_error",
                            "Không tìm thấy ứng dụng phù hợp để mở liên hệ.",
                            "No suitable app was found to open this contact."
                        ),
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }
    }

    fun requestingEmail(): String = when (state) {
        is DocumentAccessState.Denied -> state.email
        is DocumentAccessState.Granted -> state.info.email
        else -> GoogleSignIn.getLastSignedInAccount(context)?.email.orEmpty()
    }

    fun openSupportEmail() {
        val accountEmail = requestingEmail()
        val subject = accessText(
            "tab_access_contact_subject",
            "Liên hệ hỗ trợ chức năng Bản nhạc TunerTools",
            "Contact TunerTools Sheet Music support"
        )
        val body = buildString {
            append(
                accessText(
                    "tab_access_contact_body",
                    "Xin chào TunerTools, vui lòng hỗ trợ tôi sử dụng chức năng Bản nhạc miễn phí",
                    "Hello TunerTools, please help me use the free Sheet Music feature"
                )
            )
            if (accountEmail.isNotBlank()) {
                append(
                    accessText(
                        "tab_access_for_account",
                        " cho tài khoản: ",
                        " for account: "
                    )
                )
                append(accountEmail)
            }
            append(".")
        }
        val mailUri = Uri.parse(
            "mailto:$supportEmail?subject=${Uri.encode(subject)}&body=${Uri.encode(body)}"
        )
        val fallback = Intent(Intent.ACTION_SENDTO, mailUri)
        val gmail = Intent(fallback).apply { setPackage("com.google.android.gm") }
        launchContactIntent(gmail, fallback)
    }

    fun openSupportZalo() {
        val zaloUri = Uri.parse("https://zalo.me/$supportZaloPhone")
        val fallback = Intent(Intent.ACTION_VIEW, zaloUri)
        val zalo = Intent(fallback).apply { setPackage("com.zing.zalo") }
        launchContactIntent(zalo, fallback)
    }

    val title = when (state) {
        DocumentAccessState.Checking -> accessText(
            "tab_access_checking_title", "Đang kiểm tra tài khoản...", "Checking account..."
        )
        is DocumentAccessState.LoginRequired -> accessText(
            "tab_access_login_title", "Cần đăng nhập Google", "Google sign-in required"
        )
        is DocumentAccessState.Denied -> accessText(
            "tab_access_error_title", "Không thể truy cập", "Unable to access"
        )
        is DocumentAccessState.Error -> accessText(
            "tab_access_error_title", "Không thể tải dữ liệu", "Unable to load data"
        )
        is DocumentAccessState.Granted -> ""
    }

    val message = when (state) {
        DocumentAccessState.Checking -> accessText(
            "tab_access_checking_message", "Vui lòng chờ trong giây lát.", "Please wait a moment."
        )
        is DocumentAccessState.LoginRequired -> state.message.ifBlank {
            accessText(
                "tab_free_login_message",
                "Đăng nhập Google để sử dụng chức năng Bản nhạc miễn phí, không giới hạn thời gian.",
                "Sign in with Google to use Sheet Music for free, with no time limit."
            )
        }
        is DocumentAccessState.Denied -> state.message.ifBlank {
            accessText(
                "tab_access_error_message",
                "Không thể tải dữ liệu Bản nhạc. Hãy thử lại.",
                "Unable to load Sheet Music. Please retry."
            )
        }
        is DocumentAccessState.Error -> state.message.ifBlank {
            accessText(
                "tab_access_error_message",
                "Không thể kết nối máy chủ hoặc tải dữ liệu.",
                "Unable to connect to the server or load data."
            )
        }
        is DocumentAccessState.Granted -> ""
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = bgColor
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = accessText(
                            "tab_access_back",
                            "Quay lại",
                            "Back"
                        ),
                        tint = textColor
                    )
                }
                Text(
                    text = accessText(
                        "tab_access_screen_title",
                        "Bản nhạc",
                        "Sheet Music"
                    ),
                    color = textColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }

            Card(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .widthIn(max = 480.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = surfaceColor),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isDark) Color.White.copy(alpha = 0.12f) else Color.Black.copy(alpha = 0.10f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val icon = when {
                        state == DocumentAccessState.Checking -> Icons.Default.Refresh
                        state is DocumentAccessState.LoginRequired -> Icons.Default.Login
                        state is DocumentAccessState.Denied -> Icons.Default.Lock
                        state is DocumentAccessState.Error -> Icons.Default.Warning
                        else -> Icons.Default.Lock
                    }

                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (state is DocumentAccessState.Error) {
                            Color(0xFFEF5350)
                        } else {
                            textColor.copy(alpha = 0.82f)
                        },
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = title,
                        color = textColor,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(7.dp))
                    Text(
                        text = message,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )

                    if (state is DocumentAccessState.Denied) {
                        Spacer(modifier = Modifier.height(14.dp))
                        SongTabContactActionRow(
                            textColor = textColor,
                            label = "Gmail",
                            value = supportEmail,
                            onClick = { openSupportEmail() }
                        ) {
                            SongTabGmailBrandIcon(modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        SongTabContactActionRow(
                            textColor = textColor,
                            label = "Zalo",
                            value = supportZaloPhone,
                            onClick = { openSupportZalo() }
                        ) {
                            SongTabZaloBrandIcon(modifier = Modifier.size(24.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    when {
                        state == DocumentAccessState.Checking -> {
                            CircularProgressIndicator(
                                color = accentColor,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        state is DocumentAccessState.LoginRequired -> {
                            Button(
                                onClick = onLogin,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color(0xFF202124)
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDADCE0))
                            ) {
                                SongTabGoogleGIcon(modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(9.dp))
                                Text(
                                    text = accessText(
                                        "tab_access_login_button",
                                        "Đăng nhập bằng Google",
                                        "Sign in with Google"
                                    ),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        state is DocumentAccessState.Denied -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = onLogin,
                                    modifier = Modifier.weight(1f).height(44.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White,
                                        contentColor = Color(0xFF202124)
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        Color(0xFFDADCE0)
                                    )
                                ) {
                                    SongTabGoogleGIcon(modifier = Modifier.size(17.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        accessText(
                                            "tab_access_switch_account",
                                            "Đổi tài khoản",
                                            "Switch account"
                                        ),
                                        color = Color(0xFF202124),
                                        maxLines = 1,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Button(
                                    onClick = onRetry,
                                    modifier = Modifier.weight(1f).height(44.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                                ) {
                                    Text(
                                        accessText(
                                            "tab_access_retry",
                                            "Thử lại",
                                            "Retry"
                                        ),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        state is DocumentAccessState.Error -> {
                            Button(
                                onClick = onRetry,
                                modifier = Modifier.fillMaxWidth().height(46.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(7.dp))
                                Text(
                                    accessText(
                                        "tab_access_retry",
                                        "Thử lại",
                                        "Retry"
                                    ),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BangNhacScreen(
    apiBaseUrl: String,
    isDark: Boolean,
    modifier: Modifier = Modifier,
    searchPath: String = "api_gp_search.php",
    apiToken: String? = null,
    onClose: () -> Unit = {}
) {
    val context = LocalContext.current
    val currentLang = context
        .getSharedPreferences("TunerPrefs", Context.MODE_PRIVATE)
        .getString("appLang", "en")
        ?.takeIf { it.isNotBlank() }
        ?: "en"
    val scope = rememberCoroutineScope()
    val googleSignInClient = remember(context) {
        GoogleSignIn.getClient(context, buildTunerGoogleSignInOptions(context))
    }

    var accessState by remember {
        mutableStateOf<DocumentAccessState>(DocumentAccessState.Checking)
    }
    var accessRefresh by remember { mutableIntStateOf(0) }

    var signedInEmail by remember {
        mutableStateOf(
            GoogleSignIn.getLastSignedInAccount(context)
                ?.email
                .orEmpty()
                .trim()
                .lowercase(Locale.ROOT)
        )
    }
    // Danh sách Nhạc Việt ban đầu được tải tại lớp ngoài. Nhờ vậy cùng một
    // SongTabAccessLoadingScreen được giữ nguyên vị trí từ lúc kiểm tra quyền
    // cho tới khi dữ liệu đầu tiên thật sự sẵn sàng.
    var initialSongs by remember(apiBaseUrl, searchPath, apiToken) {
        mutableStateOf<List<TuneToolsSong>?>(null)
    }
    var initialLoadError by remember(apiBaseUrl, searchPath, apiToken) {
        mutableStateOf<String?>(null)
    }
    var initialSearchSource by remember(apiBaseUrl, searchPath, apiToken) {
        mutableStateOf(SheetMusicServerSource.PRIMARY)
    }
    var initialLoadRefresh by remember { mutableIntStateOf(0) }

    fun resetInitialLoad() {
        initialSongs = null
        initialLoadError = null
        initialSearchSource = SheetMusicServerSource.PRIMARY
    }

    val signInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                resetInitialLoad()
                accessState = DocumentAccessState.Checking
                val account = try {
                    GoogleSignIn.getSignedInAccountFromIntent(result.data)
                        .getResult(ApiException::class.java)
                } catch (_: Exception) {
                    null
                }

                val email = account?.email.orEmpty()
                if (account == null || email.isBlank()) {
                    signedInEmail = ""
                    accessState = DocumentAccessState.LoginRequired(
                        message = soundFontText(
                            "tab_free_login_message",
                            currentLang,
                            "Đăng nhập Google để sử dụng chức năng Bản nhạc miễn phí, không giới hạn thời gian.",
                            "Sign in with Google to use Sheet Music for free, with no time limit."
                        )
                    )
                } else {
                    // Mọi tài khoản Google đăng nhập thành công đều được sử dụng miễn phí lâu dài.
                    signedInEmail = email.trim().lowercase(Locale.ROOT)
                    accessState = try {
                        DocumentAccessApi.loginWithAccount(context, account, DocumentAccessScope.SONG_TAB)
                    } catch (error: Exception) {
                        // Lỗi kiểm tra phiên máy chủ không làm mất quyền dùng miễn phí.
                        DocumentAccessState.Error(
                            error.message ?: soundFontText(
                                "tab_access_error_message",
                                currentLang,
                                "Không thể kết nối máy chủ hoặc tải dữ liệu.",
                                "Unable to connect to the server or load data."
                            )
                        )
                    }
                }
            }
        } else {
            resetInitialLoad()
            signedInEmail = ""
            accessState = DocumentAccessState.LoginRequired(
                message = soundFontText(
                    "tab_free_login_message",
                    currentLang,
                    "Đăng nhập Google để sử dụng chức năng Bản nhạc miễn phí, không giới hạn thời gian.",
                    "Sign in with Google to use Sheet Music for free, with no time limit."
                )
            )
        }
    }

    fun switchGoogleAccount() {
        resetInitialLoad()
        accessState = DocumentAccessState.Checking
        DocumentAccessStore.clear(context)
        // Đăng xuất trước để người dùng chủ động chọn tài khoản Google khác.
        googleSignInClient.signOut().addOnCompleteListener {
            signedInEmail = ""
            signInLauncher.launch(googleSignInClient.signInIntent)
        }
    }

    LaunchedEffect(accessRefresh) {
        resetInitialLoad()
        accessState = DocumentAccessState.Checking

        val account = GoogleSignIn.getLastSignedInAccount(context)
        signedInEmail = account?.email.orEmpty().trim().lowercase(Locale.ROOT)

        accessState = try {
            DocumentAccessApi.ensureSession(context, DocumentAccessScope.SONG_TAB)
        } catch (error: Exception) {
            DocumentAccessState.Error(
                error.message ?: soundFontText(
                    "tab_access_error_message",
                    currentLang,
                    "Không thể kết nối máy chủ hoặc tải dữ liệu.",
                    "Unable to connect to the server or load data."
                )
            )
        }
    }

    val grantedState = accessState as? DocumentAccessState.Granted
    val effectiveEmail = grantedState?.info?.email
        ?.trim()
        ?.lowercase(Locale.ROOT)
        ?.takeIf { it.isNotBlank() }
        ?: signedInEmail
    val isSignedIn = effectiveEmail.isNotBlank()
    // Khong ap dung gioi han 30 ngay hoac quyen canView/canManage de mo Ban nhac.
    // Dang nhap Google la dieu kien duy nhat o phia giao dien; loi phien server
    // khong duoc phep khoa tinh nang mien phi.
    val canUseSheetMusic = isSignedIn

    LaunchedEffect(
        effectiveEmail,
        canUseSheetMusic,
        initialLoadRefresh,
        apiBaseUrl,
        searchPath,
        apiToken
    ) {
        if (!isSignedIn || !canUseSheetMusic) return@LaunchedEffect

        initialSongs = null
        initialLoadError = null
        try {
            val initialOutcome = withContext(Dispatchers.IO) {
                TuneToolsSheetMusicApi.search(
                    apiBaseUrl = apiBaseUrl,
                    searchPath = searchPath,
                    keyword = "",
                    apiToken = apiToken,
                    section = MusicLibrarySection.NHAC_VIET,
                    rhythm = null,
                    folder = null
                )
            }
            initialSongs = initialOutcome.songs
            initialSearchSource = initialOutcome.source
        } catch (cancelled: CancellationException) {
            // LaunchedEffect was cancelled when this screen left composition.
            // This is a normal lifecycle event, not a server or search error.
            throw cancelled
        } catch (error: Exception) {
            android.util.Log.e("TuneToolsSheetMusicApi", "Initial sheet list failed", error)
            // Show the meaningful HTTP/JSON failure instead of hiding every
            // server problem behind one generic error. Keep the full trace in Logcat.
            val details = mutableListOf<String>()
            error.suppressed.firstOrNull()?.message?.takeIf { it.isNotBlank() }
                ?.let { details += "Google Drive: $it" }
            error.cause?.message?.takeIf { it.isNotBlank() }
                ?.let { details += "Dự phòng: $it" }
            if (details.isEmpty()) {
                error.message?.takeIf { it.isNotBlank() }?.let { details += it }
            }
            val detailText = if (details.isEmpty()) {
                "Vui lòng thử lại."
            } else {
                "Chi tiết: " + details.joinToString(" | ").take(240)
            }
            initialLoadError = "Không thể tải danh sách bản nhạc. " + detailText
        }
    }

    val showUnifiedLoading =
        (isSignedIn && accessState is DocumentAccessState.Checking) ||
                (canUseSheetMusic && initialSongs == null && initialLoadError == null)

    when {
        // Cùng một nhánh Composable được giữ trong cả hai giai đoạn nên sóng âm
        // không đổi vị trí, không chớp tiêu đề và không xuất hiện loader thứ hai.
        showUnifiedLoading -> SongTabAccessLoadingScreen(isDark = isDark)

        canUseSheetMusic && initialLoadError != null -> SongTabAccessGateScreen(
            isDark = isDark,
            state = DocumentAccessState.Error(initialLoadError.orEmpty()),
            currentLang = currentLang,
            onClose = onClose,
            onLogin = { switchGoogleAccount() },
            onRetry = {
                initialLoadError = null
                initialSongs = null
                initialLoadRefresh++
            }
        )

        canUseSheetMusic && initialSongs != null -> BangNhacScreenContent(
            apiBaseUrl = apiBaseUrl,
            isDark = isDark,
            modifier = modifier,
            searchPath = searchPath,
            apiToken = apiToken,
            currentLang = currentLang,
            initialSongs = initialSongs.orEmpty(),
            initialSearchSource = initialSearchSource,
            onClose = onClose
        )

        !isSignedIn -> SongTabAccessGateScreen(
            isDark = isDark,
            state = DocumentAccessState.LoginRequired(
                message = soundFontText(
                    "tab_free_login_message",
                    currentLang,
                    "Đăng nhập Google để sử dụng chức năng Bản nhạc miễn phí, không giới hạn thời gian.",
                    "Sign in with Google to use Sheet Music for free, with no time limit."
                )
            ),
            currentLang = currentLang,
            onClose = onClose,
            onLogin = { switchGoogleAccount() },
            onRetry = { accessRefresh++ }
        )

        else -> SongTabAccessGateScreen(
            isDark = isDark,
            state = DocumentAccessState.Error(
                soundFontText(
                    "tab_access_error_message",
                    currentLang,
                    "Không thể tải Bản nhạc. Hãy thử lại.",
                    "Could not load Sheet Music. Please retry."
                )
            ),
            currentLang = currentLang,
            onClose = onClose,
            onLogin = { switchGoogleAccount() },
            onRetry = { accessRefresh++ }
        )
    }
}

@Composable
private fun TabAppearanceColorPicker(
    title: String,
    currentLang: String,
    options: List<TabAppearanceColorOption>,
    selectedId: String,
    isDarkPreview: Boolean,
    accentColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onSelected: (String) -> Unit
) {
    val isVietnamese = currentLang.lowercase(Locale.ROOT)
        .substringBefore('-').substringBefore('_') == "vi"
    val selectedOption = options.firstOrNull { it.id == selectedId }
    val selectedHex = tabAppearanceCustomHex(selectedId)
        ?: selectedOption?.resolve(isDarkPreview)
        ?: options.first().resolve(isDarkPreview)
    val selectedName = selectedOption?.title(currentLang)
        ?: if (isVietnamese) "T\u1ef1 ch\u1ecdn" else "Custom"
    var mixerExpanded by remember(title) { mutableStateOf(false) }
    var hue by remember(title) { mutableFloatStateOf(260f) }
    var saturation by remember(title) { mutableFloatStateOf(80f) }
    var brightness by remember(title) { mutableFloatStateOf(85f) }

    fun openMixer() {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(android.graphics.Color.parseColor(selectedHex), hsv)
        hue = hsv[0]
        saturation = hsv[1] * 100f
        brightness = hsv[2] * 100f
        mixerExpanded = !mixerExpanded
    }
    fun applyMixer(h: Float, sat: Float, value: Float) {
        onSelected(tabAppearanceHexFromHsv(h, sat, value))
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = title,
                color = textColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "$selectedName  $selectedHex",
                color = secondaryTextColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        // Many accessible presets without shrinking the color circles or the dialog.
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            options.forEach { option ->
                val selected = option.id == selectedId
                val resolvedHex = option.resolve(isDarkPreview)
                val outlineColor = if (selected) textColor
                else secondaryTextColor.copy(alpha = 0.35f)
                Box(
                    modifier = Modifier
                        .size(35.dp)
                        .clip(CircleShape)
                        .border(if (selected) 2.5.dp else 1.dp, outlineColor, CircleShape)
                        .clickable {
                            mixerExpanded = false
                            onSelected(option.id)
                        }
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(tabAppearanceComposeColor(resolvedHex)),
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) {
                        Box(
                            modifier = Modifier.size(8.dp)
                                .background(
                                    if (tabAppearanceUsesDarkText(resolvedHex))
                                        Color(0xFF111827) else Color.White,
                                    CircleShape
                                )
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(7.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (isVietnamese) "Vu\u1ed1t ngang \u0111\u1ec3 xem th\u00eam m\u00e0u" else "Swipe to see more colors",
                color = secondaryTextColor,
                fontSize = 10.sp
            )
            Text(
                text = if (isVietnamese) {
                    if (mixerExpanded) "\u1ea8n b\u1ed9 tr\u1ed9n m\u00e0u" else "T\u1ef1 pha m\u00e0u  HSV"
                } else if (mixerExpanded) "Hide color mixer" else "Mix color  HSV",
                color = accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(9.dp))
                    .clickable { openMixer() }
                    .padding(horizontal = 6.dp, vertical = 6.dp)
            )
        }
        if (mixerExpanded) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = tabAppearanceComposeColor(selectedHex).copy(alpha = 0.11f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp, secondaryTextColor.copy(alpha = 0.22f)
                )
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(22.dp).clip(CircleShape)
                            .background(tabAppearanceComposeColor(selectedHex))
                            .border(1.dp, secondaryTextColor.copy(alpha = .4f), CircleShape))
                        Spacer(modifier = Modifier.width(9.dp))
                        Text(
                            text = if (isVietnamese) "M\u00e0u t\u00f9y ch\u1ec9nh" else "Custom color",
                            color = textColor, fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = selectedHex, color = textColor, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth().height(9.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(
                                androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    listOf(
                                        Color.Red, Color.Yellow, Color.Green, Color.Cyan,
                                        Color.Blue, Color.Magenta, Color.Red
                                    )
                                )
                            )
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isVietnamese) "S\u1eafc" else "Hue",
                            color = textColor, fontSize = 11.sp,
                            modifier = Modifier.width(55.dp)
                        )
                        Slider(
                            value = hue, valueRange = 0f..360f,
                            onValueChange = {
                                hue = it
                                applyMixer(hue, saturation, brightness)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        Text("${hue.roundToInt()}\u00b0", color = secondaryTextColor,
                            fontSize = 10.sp, modifier = Modifier.width(37.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isVietnamese) "B\u00e3o h\u00f2a" else "Saturation",
                            color = textColor, fontSize = 11.sp,
                            modifier = Modifier.width(55.dp)
                        )
                        Slider(
                            value = saturation, valueRange = 0f..100f,
                            onValueChange = {
                                saturation = it
                                applyMixer(hue, saturation, brightness)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        Text("${saturation.roundToInt()}%", color = secondaryTextColor,
                            fontSize = 10.sp, modifier = Modifier.width(37.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isVietnamese) "\u0110\u1ed9 s\u00e1ng" else "Brightness",
                            color = textColor, fontSize = 11.sp,
                            modifier = Modifier.width(55.dp)
                        )
                        Slider(
                            value = brightness, valueRange = 0f..100f,
                            onValueChange = {
                                brightness = it
                                applyMixer(hue, saturation, brightness)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        Text("${brightness.roundToInt()}%", color = secondaryTextColor,
                            fontSize = 10.sp, modifier = Modifier.width(37.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TabAppearancePreview(
    isDarkPreview: Boolean,
    cursorHex: String,
    activeRegionHex: String,
    tabHex: String,
    noteHex: String,
    fretboardHex: String,
    panelHex: String,
    cursorWidth: Float,
    regionOpacity: Float
) {
    val previewSurface = if (isDarkPreview) Color(0xFF0B0F1A) else Color.White
    val cursorColor = tabAppearanceComposeColor(cursorHex)
    val regionColor = tabAppearanceComposeColor(activeRegionHex)
    val tabColor = tabAppearanceComposeColor(tabHex)
    val noteColor = tabAppearanceComposeColor(noteHex)
    val boardColor = tabAppearanceComposeColor(fretboardHex)
    val boardTextColor = if (tabAppearanceUsesDarkText(fretboardHex))
        Color(0xFF1F2937) else Color.White
    val panelColor = tabAppearanceComposeColor(panelHex)
    Surface(
        modifier = Modifier.fillMaxWidth().height(165.dp),
        shape = RoundedCornerShape(16.dp),
        color = previewSurface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp, if (isDarkPreview) Color.White.copy(alpha = .16f)
            else Color.Black.copy(alpha = .12f)
        )
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Box(
                modifier = Modifier.fillMaxWidth().height(73.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (isDarkPreview) Color(0xFF111827) else Color(0xFFF8FAFC))
            ) {
                Box(
                    modifier = Modifier.align(Alignment.CenterEnd)
                        .fillMaxWidth(.50f).fillMaxHeight()
                        .background(regionColor.copy(alpha = regionOpacity))
                        .then(
                            if (regionOpacity > 0f) Modifier.border(
                                1.dp,
                                if (isDarkPreview) Color.White.copy(alpha = .25f)
                                else Color.Black.copy(alpha = .15f)
                            ) else Modifier
                        )
                )
                repeat(5) { index ->
                    Box(
                        modifier = Modifier.fillMaxWidth().height(1.dp)
                            .align(Alignment.TopCenter)
                            .offset(y = (15 + index * 9).dp)
                            .background(tabColor.copy(alpha = if (index == 2) .9f else .48f))
                    )
                }
                listOf(.20f, .36f, .58f, .78f).forEachIndexed { index, fraction ->
                    Box(
                        modifier = Modifier.align(Alignment.TopStart)
                            .offset(x = (fraction * 290).dp, y = (25 + index % 2 * 12).dp)
                            .size(9.dp).background(tabColor, CircleShape)
                    )
                }
                // 0 px means the playhead is fully hidden, including the preview dot.
                if (cursorWidth >= 1f) {
                    Box(
                        modifier = Modifier.align(Alignment.Center)
                            .width(cursorWidth.coerceIn(1f, 24f).dp).fillMaxHeight()
                            .background(cursorColor)
                            .border(1.dp,
                                if (isDarkPreview) Color.White.copy(alpha = .6f)
                                else Color.Black.copy(alpha = .55f))
                    )
                    Box(
                        modifier = Modifier.align(Alignment.TopCenter)
                            .offset(y = 2.dp).size(9.dp)
                            .background(cursorColor, CircleShape)
                    )
                }
            }
            Spacer(modifier = Modifier.height(7.dp))
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(panelColor).padding(4.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize()
                        .clip(RoundedCornerShape(7.dp))
                        .background(boardColor)
                        .border(1.dp, boardTextColor.copy(alpha = .35f), RoundedCornerShape(7.dp))
                ) {
                    repeat(4) { index ->
                        Box(
                            modifier = Modifier.fillMaxWidth().height(1.dp)
                                .align(Alignment.TopCenter)
                                .offset(y = (9 + index * 12).dp)
                                .background(boardTextColor.copy(alpha = .58f))
                        )
                    }
                    Box(
                        modifier = Modifier.align(Alignment.Center)
                            .offset(x = 30.dp, y = (-5).dp)
                            .size(24.dp).background(noteColor, CircleShape)
                            .border(2.dp, boardTextColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "A",
                            color = if (tabAppearanceUsesDarkText(noteHex))
                                Color(0xFF111827) else Color.White,
                            fontSize = 10.sp, fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabAppearanceSettingsDialog(
    currentLang: String,
    appIsDark: Boolean,
    themeMode: TabAppearanceThemeMode,
    cursorColorId: String,
    activeRegionColorId: String,
    tabColorId: String,
    noteColorId: String,
    fretboardColorId: String,
    panelColorId: String,
    cursorWidth: Float,
    regionOpacity: Float,
    onThemeModeChange: (TabAppearanceThemeMode) -> Unit,
    onCursorColorChange: (String) -> Unit,
    onActiveRegionColorChange: (String) -> Unit,
    onTabColorChange: (String) -> Unit,
    onNoteColorChange: (String) -> Unit,
    onFretboardColorChange: (String) -> Unit,
    onPanelColorChange: (String) -> Unit,
    onCursorWidthChange: (Float) -> Unit,
    onRegionOpacityChange: (Float) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val isVietnamese = currentLang
        .lowercase(Locale.ROOT)
        .substringBefore('-')
        .substringBefore('_') == "vi"
    val previewIsDark = themeMode.resolve(appIsDark)
    val cursorHex = tabAppearanceResolvedHex(
        TAB_CURSOR_COLOR_OPTIONS, cursorColorId, "purple", previewIsDark)
    val regionHex = tabAppearanceResolvedHex(
        TAB_ACTIVE_REGION_COLOR_OPTIONS, activeRegionColorId, "lavender", previewIsDark)
    val tabHex = tabAppearanceResolvedHex(
        TAB_GLYPH_COLOR_OPTIONS, tabColorId, "auto", previewIsDark)
    val noteHex = tabAppearanceResolvedHex(
        TAB_NOTE_COLOR_OPTIONS, noteColorId, "yellow", previewIsDark)
    val boardHex = tabAppearanceResolvedHex(
        TAB_FRETBOARD_COLOR_OPTIONS, fretboardColorId, "auto", previewIsDark)
    val panelHex = tabAppearanceResolvedHex(
        TAB_FRETBOARD_PANEL_OPTIONS, panelColorId, "auto", previewIsDark)
    val dialogBackground = if (previewIsDark) Color(0xFF11151F) else Color(0xFFF8FAFC)
    val cardBackground = if (previewIsDark) Color(0xFF1A202C) else Color.White
    val textColor = if (previewIsDark) Color.White else Color(0xFF101828)
    val secondaryTextColor = if (previewIsDark) Color(0xFFB8C0CC) else Color(0xFF667085)
    val dividerColor = if (previewIsDark) Color.White.copy(alpha = 0.10f) else Color.Black.copy(alpha = 0.08f)
    // Controls still contrast when white/black are chosen for the actual cursor.
    val useChosenAccent = if (previewIsDark) tabAppearanceUsesDarkText(cursorHex)
    else !tabAppearanceUsesDarkText(cursorHex)
    val actionAccentHex = if (useChosenAccent) cursorHex
    else if (previewIsDark) "#A78BFA" else "#6D28D9"
    val accentColor = tabAppearanceComposeColor(actionAccentHex)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.94f)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            color = dialogBackground,
            shadowElevation = 12.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 8.dp, top = 10.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(25.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isVietnamese) "Tùy chỉnh hiển thị" else "Display customization",
                            color = textColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isVietnamese) {
                                "Thay đổi được áp dụng ngay và tự động lưu"
                            } else {
                                "Changes apply instantly and are saved automatically"
                            },
                            color = secondaryTextColor,
                            fontSize = 10.5.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = if (isVietnamese) "Đóng" else "Close",
                            tint = textColor
                        )
                    }
                }

                HorizontalDivider(color = dividerColor)

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    TabAppearancePreview(
                        isDarkPreview = previewIsDark,
                        cursorHex = cursorHex,
                        activeRegionHex = regionHex,
                        tabHex = tabHex,
                        noteHex = noteHex,
                        fretboardHex = boardHex,
                        panelHex = panelHex,
                        cursorWidth = cursorWidth,
                        regionOpacity = regionOpacity
                    )

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = cardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, dividerColor)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isVietnamese) "Chế độ hiển thị" else "Display mode",
                                color = textColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                TabAppearanceThemeMode.values().forEach { mode ->
                                    val selected = mode == themeMode
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(11.dp))
                                            .background(
                                                if (selected) accentColor else dialogBackground
                                            )
                                            .border(
                                                1.dp,
                                                if (selected) accentColor else dividerColor,
                                                RoundedCornerShape(11.dp)
                                            )
                                            .clickable { onThemeModeChange(mode) }
                                            .padding(horizontal = 4.dp, vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = mode.title(currentLang),
                                            color = if (selected) {
                                                if (tabAppearanceUsesDarkText(actionAccentHex)) {
                                                    Color(0xFF111827)
                                                } else {
                                                    Color.White
                                                }
                                            } else {
                                                textColor
                                            },
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = cardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, dividerColor)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            TabAppearanceColorPicker(
                                title = if (isVietnamese) "Màu con trỏ" else "Playhead color",
                                currentLang = currentLang,
                                options = TAB_CURSOR_COLOR_OPTIONS,
                                selectedId = cursorColorId,
                                isDarkPreview = previewIsDark,
                                accentColor = accentColor,
                                textColor = textColor,
                                secondaryTextColor = secondaryTextColor,
                                onSelected = onCursorColorChange
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isVietnamese) "Độ dày vạch chạy (0 = ẩn)" else "Playhead thickness (0 = hide)",
                                    color = textColor, fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text("${cursorWidth.roundToInt()} px", color = secondaryTextColor,
                                    fontSize = 11.sp)
                            }
                            Slider(
                                value = cursorWidth,
                                valueRange = 0f..24f,
                                steps = 23,
                                onValueChange = onCursorWidthChange
                            )
                            HorizontalDivider(color = dividerColor)
                            TabAppearanceColorPicker(
                                title = if (isVietnamese) "Nền vùng đang chạy" else "Active region background",
                                currentLang = currentLang,
                                options = TAB_ACTIVE_REGION_COLOR_OPTIONS,
                                selectedId = activeRegionColorId,
                                isDarkPreview = previewIsDark,
                                accentColor = accentColor,
                                textColor = textColor,
                                secondaryTextColor = secondaryTextColor,
                                onSelected = onActiveRegionColorChange
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isVietnamese) "\u0110\u1ed9 ph\u1ee7 n\u1ec1n ch\u1ea1y" else "Region opacity",
                                    color = textColor, fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text("${(regionOpacity * 100).roundToInt()}%",
                                    color = secondaryTextColor, fontSize = 11.sp)
                            }
                            Slider(
                                value = regionOpacity,
                                valueRange = 0f.. .85f,
                                onValueChange = onRegionOpacityChange
                            )
                            HorizontalDivider(color = dividerColor)
                            TabAppearanceColorPicker(
                                title = if (isVietnamese) "Khuông nhạc và TAB" else "Notation and TAB",
                                currentLang = currentLang,
                                options = TAB_GLYPH_COLOR_OPTIONS,
                                selectedId = tabColorId,
                                isDarkPreview = previewIsDark,
                                accentColor = accentColor,
                                textColor = textColor,
                                secondaryTextColor = secondaryTextColor,
                                onSelected = onTabColorChange
                            )
                            HorizontalDivider(color = dividerColor)
                            TabAppearanceColorPicker(
                                title = if (isVietnamese) "Nốt trên cần đàn" else "Fretboard notes",
                                currentLang = currentLang,
                                options = TAB_NOTE_COLOR_OPTIONS,
                                selectedId = noteColorId,
                                isDarkPreview = previewIsDark,
                                accentColor = accentColor,
                                textColor = textColor,
                                secondaryTextColor = secondaryTextColor,
                                onSelected = onNoteColorChange
                            )
                            HorizontalDivider(color = dividerColor)
                            TabAppearanceColorPicker(
                                title = if (isVietnamese) "Màu mặt cần đàn" else "Fretboard surface",
                                currentLang = currentLang,
                                options = TAB_FRETBOARD_COLOR_OPTIONS,
                                selectedId = fretboardColorId,
                                isDarkPreview = previewIsDark,
                                accentColor = accentColor,
                                textColor = textColor,
                                secondaryTextColor = secondaryTextColor,
                                onSelected = onFretboardColorChange
                            )
                            HorizontalDivider(color = dividerColor)
                            TabAppearanceColorPicker(
                                title = if (isVietnamese) "M\u00e0u n\u1ec1n ngo\u00e0i c\u1ea7n \u0111\u00e0n"
                                else "Fretboard panel background",
                                currentLang = currentLang,
                                options = TAB_FRETBOARD_PANEL_OPTIONS,
                                selectedId = panelColorId,
                                isDarkPreview = previewIsDark,
                                accentColor = accentColor,
                                textColor = textColor,
                                secondaryTextColor = secondaryTextColor,
                                onSelected = onPanelColorChange
                            )
                        }
                    }
                }

                HorizontalDivider(color = dividerColor)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onReset,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Text(
                            text = if (isVietnamese) "Mặc định" else "Reset",
                            color = textColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                    ) {
                        Text(
                            text = if (isVietnamese) "Hoàn tất" else "Done",
                            color = if (tabAppearanceUsesDarkText(actionAccentHex)) {
                                Color(0xFF111827)
                            } else {
                                Color.White
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BangNhacScreenContent(
    apiBaseUrl: String,
    isDark: Boolean,
    modifier: Modifier = Modifier,
    searchPath: String = "api_gp_search.php",
    apiToken: String? = null,
    currentLang: String,
    initialSongs: List<TuneToolsSong>,
    initialSearchSource: SheetMusicServerSource,
    onClose: () -> Unit = {}
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val focusManager = LocalFocusManager.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val scope = rememberCoroutineScope()
    val localScorePayload = remember {
        AtomicReference<LocalScorePayload?>(null)
    }
    // Visible to WebView's background network thread; updated on each song open.
    val activeGpFailoverRoute = remember {
        AtomicReference<GpFailoverRoute?>(null)
    }
    val pdfPrintStarted = remember { AtomicBoolean(false) }
    val pdfJobName = remember { AtomicReference("Ban_nhac_A4.pdf") }

    // Ba cấu hình âm thanh TAB theo thứ tự chất lượng người dùng đánh giá:
    // 1) Chất lượng thấp: Sonivox tải từ CDN, không chiếm thêm bộ nhớ lâu dài.
    // 2) Chất lượng trung bình: MuseScore_General.sf3 tải một lần và có thể xóa riêng.
    // 3) Chất lượng cao: FluidR3_GM.sf2 tải một lần và có thể xóa riêng.
    val soundFontPrefs = remember(context) {
        context.getSharedPreferences(SOUNDFONT_PREFS_NAME, Context.MODE_PRIVATE)
    }
    val tabDisplayPrefs = remember(context) {
        context.getSharedPreferences(TAB_DISPLAY_PREFS_NAME, Context.MODE_PRIVATE)
    }
    val metronomePrefs = remember(context) {
        context.getSharedPreferences(TAB_METRONOME_PREFS_NAME, Context.MODE_PRIVATE)
    }
    var metronomeEnabled by remember(context) {
        mutableStateOf(metronomePrefs.getBoolean(TAB_METRONOME_PREF_ENABLED, false))
    }
    val downloadableSoundFontModes = remember {
        // Thứ tự hiển thị: SF3 trung bình trước, SF2 cao nhất sau.
        listOf(TabSoundFontMode.MUSESCORE, TabSoundFontMode.FLUIDR3)
    }
    val soundFontFiles = remember(context) {
        downloadableSoundFontModes.associateWith { soundFontFile(context, it) }
    }
    val soundFontPartFiles = remember(context) {
        downloadableSoundFontModes.associateWith { soundFontPartFile(context, it) }
    }
    val startupReadySoundFonts = remember(context) {
        downloadableSoundFontModes.filterTo(mutableSetOf()) { mode ->
            val file = soundFontFiles.getValue(mode)
            val savedSize = soundFontPrefs.getLong(soundFontSizePreferenceKey(mode), 0L)
            file.isFile &&
                    file.length() > 1024L * 1024L &&
                    (savedSize <= 0L || file.length() == savedSize)
        }
    }
    // Preserve the Guitar choice independently from Piano. In particular, a stored
    // FluidR3 SF2 selection must never become the initial playback font for Piano.
    val startupDisplayIsPiano = remember(tabDisplayPrefs) {
        TabDisplayMode.fromStored(
            tabDisplayPrefs.getString(TAB_DISPLAY_PREF_MODE, null)
        ).instrument == TabDisplayInstrument.PIANO
    }
    val startupGuitarSoundFontMode = remember(context) {
        val savedMode = TabSoundFontMode.fromStoredValue(
            soundFontPrefs.getString(SOUNDFONT_PREF_MODE, TabSoundFontMode.STANDARD.storedValue)
        )
        if (!savedMode.isDownloadable || savedMode in startupReadySoundFonts) {
            savedMode
        } else {
            TabSoundFontMode.STANDARD
        }
    }
    val startupPianoSoundFontMode = remember(context) {
        val savedPianoMode = soundFontPrefs.getString(SOUNDFONT_PREF_PIANO_MODE, null)
        val preferred = if (savedPianoMode == null) {
            if (TabSoundFontMode.MUSESCORE in startupReadySoundFonts) {
                TabSoundFontMode.MUSESCORE
            } else {
                TabSoundFontMode.STANDARD
            }
        } else {
            TabSoundFontMode.fromStoredValue(savedPianoMode)
        }
        when {
            preferred == TabSoundFontMode.FLUIDR3 -> TabSoundFontMode.STANDARD
            preferred.isDownloadable && preferred !in startupReadySoundFonts -> TabSoundFontMode.STANDARD
            else -> preferred
        }
    }
    val startupSoundFontMode = if (startupDisplayIsPiano) {
        startupPianoSoundFontMode
    } else {
        startupGuitarSoundFontMode
    }
    val localSoundFontFileRefs = remember {
        downloadableSoundFontModes.associateWith { mode ->
            AtomicReference<File?>(
                soundFontFiles.getValue(mode).takeIf { mode in startupReadySoundFonts }
            )
        }
    }

    val soundFontInfos = remember { mutableStateMapOf<TabSoundFontMode, TabSoundFontInfo>() }
    val soundFontInfoErrors = remember { mutableStateMapOf<TabSoundFontMode, String>() }
    val downloadedSoundFontModes = remember {
        mutableStateMapOf<TabSoundFontMode, Boolean>().apply {
            downloadableSoundFontModes.forEach { put(it, it in startupReadySoundFonts) }
        }
    }
    val localSoundFontDataModes = remember {
        mutableStateMapOf<TabSoundFontMode, Boolean>().apply {
            downloadableSoundFontModes.forEach { mode ->
                put(
                    mode,
                    soundFontFiles.getValue(mode).exists() ||
                            soundFontPartFiles.getValue(mode).exists()
                )
            }
        }
    }
    val soundFontDownloadedBytesByMode = remember {
        mutableStateMapOf<TabSoundFontMode, Long>().apply {
            downloadableSoundFontModes.forEach { mode ->
                put(mode, soundFontPartFiles.getValue(mode).takeIf { it.isFile }?.length() ?: 0L)
            }
        }
    }
    val soundFontDownloadProgressByMode = remember {
        mutableStateMapOf<TabSoundFontMode, Float>().apply {
            downloadableSoundFontModes.forEach { put(it, 0f) }
        }
    }

    var selectedSoundFontMode by remember { mutableStateOf(startupGuitarSoundFontMode) }
    var selectedPianoSoundFontMode by remember { mutableStateOf(startupPianoSoundFontMode) }
    var activeSoundFontMode by remember { mutableStateOf(startupSoundFontMode) }
    var soundFontMenuExpanded by remember { mutableStateOf(false) }
    var downloadingSoundFontMode by remember { mutableStateOf<TabSoundFontMode?>(null) }
    var isSwitchingSoundFont by remember { mutableStateOf(false) }
    var isCheckingSoundFontCompatibility by remember { mutableStateOf(false) }
    var soundFontDecodeProgress by remember { mutableFloatStateOf(0f) }
    var soundFontFallbackRequest by remember { mutableIntStateOf(0) }
    var soundFontRestoreRequest by remember { mutableIntStateOf(0) }
    var temporarySoundFontFallbackFrom by remember {
        mutableStateOf<TabSoundFontMode?>(null)
    }

    val startupSoundFontUrl = startupSoundFontMode.playbackUrl

    // Tùy chỉnh giao diện TAB được lưu độc lập với cài đặt chung của ứng dụng.
    // Chế độ "Theo ứng dụng" vẫn tự đồng bộ khi người dùng đổi theme ở trang Cài đặt.
    val initialAppearanceThemeMode = remember(tabDisplayPrefs) {
        TabAppearanceThemeMode.fromStoredValue(
            tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_THEME_MODE, null)
        )
    }
    var appearanceThemeMode by remember { mutableStateOf(initialAppearanceThemeMode) }
    var appearanceCursorColorId by remember(tabDisplayPrefs) {
        mutableStateOf(
            tabAppearanceStoredSelection(
                TAB_CURSOR_COLOR_OPTIONS,
                tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_CURSOR_COLOR, null),
                "purple"
            )
        )
    }
    var appearanceActiveRegionColorId by remember(tabDisplayPrefs) {
        mutableStateOf(
            tabAppearanceStoredSelection(
                TAB_ACTIVE_REGION_COLOR_OPTIONS,
                tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_ACTIVE_REGION_COLOR, null),
                "lavender"
            )
        )
    }
    var appearanceTabColorId by remember(tabDisplayPrefs) {
        mutableStateOf(
            tabAppearanceStoredSelection(
                TAB_GLYPH_COLOR_OPTIONS,
                tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_TAB_COLOR, null),
                "auto"
            )
        )
    }
    var appearanceNoteColorId by remember(tabDisplayPrefs) {
        mutableStateOf(
            tabAppearanceStoredSelection(
                TAB_NOTE_COLOR_OPTIONS,
                tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_NOTE_COLOR, null),
                "yellow"
            )
        )
    }
    var appearanceFretboardColorId by remember(tabDisplayPrefs) {
        mutableStateOf(
            tabAppearanceStoredSelection(
                TAB_FRETBOARD_COLOR_OPTIONS,
                tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_FRETBOARD_COLOR, null),
                "auto"
            )
        )
    }
    var appearancePanelColorId by remember(tabDisplayPrefs) {
        mutableStateOf(tabAppearanceStoredSelection(
            TAB_FRETBOARD_PANEL_OPTIONS,
            tabDisplayPrefs.getString(TAB_APPEARANCE_PREF_PANEL_COLOR, null),
            "auto"
        ))
    }
    var appearanceCursorWidth by remember(tabDisplayPrefs) {
        mutableFloatStateOf(
            tabDisplayPrefs.getFloat(TAB_APPEARANCE_PREF_CURSOR_WIDTH, 6f).coerceIn(0f, 24f)
        )
    }
    var appearanceRegionOpacity by remember(tabDisplayPrefs) {
        mutableFloatStateOf(
            tabDisplayPrefs.getFloat(TAB_APPEARANCE_PREF_REGION_OPACITY, .28f)
                .coerceIn(0f, .85f)
        )
    }
    var showAppearanceSettings by remember { mutableStateOf(false) }
    var localIsDark by remember {
        mutableStateOf(initialAppearanceThemeMode.resolve(isDark))
    }

    val appearanceCursorHex = tabAppearanceResolvedHex(
        TAB_CURSOR_COLOR_OPTIONS, appearanceCursorColorId, "purple", localIsDark)
    val appearanceActiveRegionHex = tabAppearanceResolvedHex(
        TAB_ACTIVE_REGION_COLOR_OPTIONS, appearanceActiveRegionColorId, "lavender", localIsDark)
    val appearanceTabHex = tabAppearanceResolvedHex(
        TAB_GLYPH_COLOR_OPTIONS, appearanceTabColorId, "auto", localIsDark)
    val appearanceNoteHex = tabAppearanceResolvedHex(
        TAB_NOTE_COLOR_OPTIONS, appearanceNoteColorId, "yellow", localIsDark)
    val appearanceFretboardHex = tabAppearanceResolvedHex(
        TAB_FRETBOARD_COLOR_OPTIONS, appearanceFretboardColorId, "auto", localIsDark)
    val appearancePanelHex = tabAppearanceResolvedHex(
        TAB_FRETBOARD_PANEL_OPTIONS, appearancePanelColorId, "auto", localIsDark)

    // Quản lý trạng thái Xoay màn hình
    var isLandscape by remember {
        mutableStateOf(activity?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
    }

    val bgColor = if (localIsDark) Color.Black else Color(0xFFF5F6FA)
    val surfaceColor = if (localIsDark) Color.Black else Color.White
    val textColor = if (localIsDark) Color.White else Color(0xFF2D3436)
    val accentColor = if (localIsDark) Color(0xFF9FA8DA) else Color(0xFF5E35B1)

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    val isTabJsReady = remember { AtomicBoolean(false) }
    val pendingTabSongScript = remember { AtomicReference<String?>(null) }

    LaunchedEffect(isDark, appearanceThemeMode) {
        val resolvedDark = appearanceThemeMode.resolve(isDark)
        if (localIsDark != resolvedDark) localIsDark = resolvedDark
    }

    fun setAppearanceThemeMode(mode: TabAppearanceThemeMode) {
        appearanceThemeMode = mode
        localIsDark = mode.resolve(isDark)
        tabDisplayPrefs.edit()
            .putString(TAB_APPEARANCE_PREF_THEME_MODE, mode.storedValue)
            .apply()
    }

    fun setAppearanceColor(
        preferenceKey: String,
        value: String,
        onStateChanged: (String) -> Unit
    ) {
        onStateChanged(value)
        tabDisplayPrefs.edit().putString(preferenceKey, value).apply()
    }

    fun resetAppearanceSettings() {
        appearanceThemeMode = TabAppearanceThemeMode.FOLLOW_APP
        appearanceCursorColorId = "purple"
        appearanceActiveRegionColorId = "lavender"
        appearanceTabColorId = "auto"
        appearanceNoteColorId = "yellow"
        appearanceFretboardColorId = "auto"
        appearancePanelColorId = "auto"
        appearanceCursorWidth = 6f
        appearanceRegionOpacity = .28f
        localIsDark = isDark
        tabDisplayPrefs.edit()
            .putString(
                TAB_APPEARANCE_PREF_THEME_MODE,
                TabAppearanceThemeMode.FOLLOW_APP.storedValue
            )
            .putString(TAB_APPEARANCE_PREF_CURSOR_COLOR, "purple")
            .putString(TAB_APPEARANCE_PREF_ACTIVE_REGION_COLOR, "lavender")
            .putString(TAB_APPEARANCE_PREF_TAB_COLOR, "auto")
            .putString(TAB_APPEARANCE_PREF_NOTE_COLOR, "yellow")
            .putString(TAB_APPEARANCE_PREF_FRETBOARD_COLOR, "auto")
            .putString(TAB_APPEARANCE_PREF_PANEL_COLOR, "auto")
            .putFloat(TAB_APPEARANCE_PREF_CURSOR_WIDTH, 6f)
            .putFloat(TAB_APPEARANCE_PREF_REGION_OPACITY, .28f)
            .apply()
    }

    // Gõ nhịp dùng chính bộ phát alphaTab: không dùng Timer/MediaPlayer riêng
    // để nhịp không lệch khi Pause/Play hoặc thay BPM.
    fun setMetronomeEnabled(enabled: Boolean) {
        metronomeEnabled = enabled
        metronomePrefs.edit().putBoolean(TAB_METRONOME_PREF_ENABLED, enabled).apply()
        webViewInstance?.evaluateJavascript(
            "javascript:if (typeof setMetronomeEnabled === 'function') setMetronomeEnabled($enabled);",
            null
        )
    }

    fun dispatchPendingTabSong(target: WebView) {
        pendingTabSongScript.getAndSet(null)?.let { command ->
            target.evaluateJavascript(command, null)
        }
    }

    fun syncTabViewport(target: WebView) {
        target.post {
            val viewportWidth = target.width
            val viewportHeight = target.height
            if (viewportWidth > 0 && viewportHeight > 0) {
                target.evaluateJavascript(
                    "javascript:if(typeof onAndroidViewportChanged==='function'){" +
                            "onAndroidViewportChanged($viewportWidth,$viewportHeight);}",
                    null
                )
            }
        }
    }

    var selectedMusicSection by remember {
        mutableStateOf(MusicLibrarySection.NHAC_VIET)
    }
    val searchQueries = remember {
        mutableStateMapOf(
            MusicLibrarySection.NHAC_VIET to "",
            MusicLibrarySection.QUOC_TE to "",
            MusicLibrarySection.DIEU_NHAC to ""
        )
    }
    val songs = remember(initialSongs) {
        mutableStateListOf<TuneToolsSong>().also { it.addAll(initialSongs) }
    }
    var activeSearchSource by remember(initialSearchSource) {
        mutableStateOf(initialSearchSource)
    }
    var searchRequestId by remember { mutableIntStateOf(0) }

    // null: đang ở danh sách các điệu; khác null: đang xem file của một điệu.
    var selectedRhythm by remember { mutableStateOf<String?>(null) }

    // Duong dan tuong doi dang mo ben trong /tab/Vietnam. Chuoi rong la thu muc goc.
    var selectedVietnamFolder by remember { mutableStateOf("") }

    var currentSong by remember { mutableStateOf<TuneToolsSong?>(null) }
    var tracks by remember { mutableStateOf<List<AlphaTrack>>(emptyList()) }
    var selectedTrackIndex by remember { mutableIntStateOf(0) }

    var songTechniqueDialogOpen by remember { mutableStateOf(false) }
    var songTechniqueScanning by remember { mutableStateOf(false) }
    var songTechniqueIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var songTechniqueTrackIndex by remember { mutableIntStateOf(-1) }

    var isSearching by remember { mutableStateOf(false) }
    var isLoadingSong by remember { mutableStateOf(false) }
    var isPlayerReady by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var hasScore by remember { mutableStateOf(false) }
    // Banner TAB chi duoc hien thi khi nguoi dung cuon qua phan cuoi ban nhac.
    var showTabBottomBanner by remember { mutableStateOf(false) }

    // BPM đang hiển thị trong ô nhập và BPM đã áp dụng vào bản nhạc.
    var bpmText by remember { mutableStateOf("") }
    var currentBpm by remember { mutableIntStateOf(0) }

    // Mặc định giữ nguyên bố cục hiện tại: khuông nhạc + TAB.
    // Người dùng có thể chuyển nhanh sang TAB hoặc Partition (chỉ khuông nhạc).
    var selectedDisplayMode by remember(tabDisplayPrefs) {
        mutableStateOf(TabDisplayMode.fromStored(tabDisplayPrefs.getString(TAB_DISPLAY_PREF_MODE, null)))
    }
    var displayModeMenuExpanded by remember { mutableStateOf(false) }
    var draftShowScore by remember { mutableStateOf(selectedDisplayMode.showScore) }
    var draftShowTab by remember { mutableStateOf(selectedDisplayMode.showTab) }
    var draftInstrument by remember { mutableStateOf(selectedDisplayMode.instrument) }
    var draftShowNoteNames by remember { mutableStateOf(false) }
    var displayConfigurationApplying by remember { mutableStateOf(false) }
    // -1: dung kich thuoc goc cua tung che do. Co the thu khuong nhac de xem nhieu o nhip.
    var customScoreZoomPercent by remember(tabDisplayPrefs) {
        mutableIntStateOf(
            tabDisplayPrefs.getInt(TAB_DISPLAY_PREF_SCORE_ZOOM, -1).let { value ->
                if (value < 0) -1 else value.coerceIn(TAB_SCORE_ZOOM_MIN, TAB_SCORE_ZOOM_MAX)
            }
        )
    }
    var scoreZoomMenuExpanded by remember { mutableStateOf(false) }
    var scoreZoomSliderDraft by remember { mutableFloatStateOf(100f) }
    // Chi hien cac nut zoom khi moi mo TAB, cham nut zoom hoac pinch 2 ngon.
    var scoreZoomControlVisible by remember { mutableStateOf(false) }
    var scoreZoomPinchActive by remember { mutableStateOf(false) }
    var scoreZoomPinchPreviewPercent by remember { mutableIntStateOf(-1) }
    var scoreZoomActivityToken by remember { mutableIntStateOf(0) }

    var isExportingPdf by remember { mutableStateOf(false) }

    fun showScoreZoomControl() {
        scoreZoomControlVisible = true
        scoreZoomActivityToken += 1
    }

    fun setScoreZoomPercent(value: Int) {
        if (isExportingPdf || !hasScore) return
        showScoreZoomControl()
        val normalized = if (value < 0) -1
        else value.coerceIn(TAB_SCORE_ZOOM_MIN, TAB_SCORE_ZOOM_MAX)
        if (customScoreZoomPercent == normalized) return
        customScoreZoomPercent = normalized
        tabDisplayPrefs.edit().putInt(TAB_DISPLAY_PREF_SCORE_ZOOM, normalized).apply()
        // LaunchedEffect ben duoi dong bo voi WebView va khong tai lai bai hat.
    }
    var showNoteNames by remember(context) {
        mutableStateOf(
            tabDisplayPrefs.getBoolean(TAB_DISPLAY_PREF_NOTE_NAMES, false)
        )
    }

    var trackMenuExpanded by remember { mutableStateOf(false) }

    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    var hideExtraButtons by remember { mutableStateOf(false) }
    var isImportingLocalFile by remember { mutableStateOf(false) }

    fun finishPdfExport(message: String? = null, isError: Boolean = false) {
        webViewInstance?.evaluateJavascript(
            "javascript:if (typeof restoreAfterA4PdfExport === 'function') { restoreAfterA4PdfExport(); }",
            null
        )
        pdfPrintStarted.set(false)
        isExportingPdf = false

        if (!message.isNullOrBlank()) {
            Toast.makeText(
                context,
                message,
                if (isError) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun startA4PdfPrint() {
        if (!isExportingPdf || !pdfPrintStarted.compareAndSet(false, true)) return

        val targetWebView = webViewInstance
        val printManager = activity?.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (targetWebView == null || printManager == null) {
            finishPdfExport(
                message = "Thiết bị không hỗ trợ dịch vụ xuất PDF.",
                isError = true
            )
            return
        }

        try {
            val jobName = pdfJobName.get().ifBlank { "Ban_nhac_A4.pdf" }
            val printAdapter = targetWebView.createPrintDocumentAdapter(jobName)
            val printAttributes = PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asPortrait())
                .setResolution(
                    PrintAttributes.Resolution(
                        "tunertools_pdf_a4",
                        "TuneTools PDF A4",
                        600,
                        600
                    )
                )
                // Đơn vị margins là 1/1000 inch; 394 xấp xỉ 10 mm.
                .setMinMargins(PrintAttributes.Margins(394, 394, 394, 394))
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build()

            val printJob = printManager.print(jobName, printAdapter, printAttributes)
            Toast.makeText(
                context,
                "Chọn ‘Lưu dưới dạng PDF’ để lưu bản nhạc khổ A4.",
                Toast.LENGTH_LONG
            ).show()

            // Giữ WebView ở bố cục A4 cho tới khi hộp thoại in/lưu kết thúc.
            scope.launch {
                while (
                    !printJob.isCompleted &&
                    !printJob.isCancelled &&
                    !printJob.isFailed
                ) {
                    delay(400L)
                }

                when {
                    printJob.isFailed -> finishPdfExport(
                        message = "Xuất PDF không thành công.",
                        isError = true
                    )
                    printJob.isCompleted -> finishPdfExport(
                        message = "Đã hoàn tất xuất PDF A4."
                    )
                    else -> finishPdfExport()
                }
            }
        } catch (e: Exception) {
            finishPdfExport(
                message = "Không thể mở chức năng xuất PDF: ${e.message ?: "Lỗi không xác định"}",
                isError = true
            )
        }
    }

    // Khởi tạo WebView một lần duy nhất để không bị reload khi xoay màn hình (chuyển sang Dialog)
    val webView = remember(context) {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // Zoom chi qua AlphaTab display.scale; khong de WebView phong to ca can dan.
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.allowFileAccessFromFileURLs = true
            settings.allowUniversalAccessFromFileURLs = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setBackgroundColor(android.graphics.Color.TRANSPARENT)

            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.let(::syncTabViewport)
                }

                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val url = request?.url.toString()

                    // File người dùng chọn trong bộ nhớ máy được phục vụ qua một URL ảo
                    // cùng origin với WebView. Cách này đọc được cả content:// mà không
                    // yêu cầu quyền truy cập toàn bộ bộ nhớ.
                    val localPayload = localScorePayload.get()
                    if (localPayload != null && url == localPayload.requestUrl) {
                        return WebResourceResponse(
                            "application/octet-stream",
                            null,
                            200,
                            "OK",
                            mapOf(
                                "Access-Control-Allow-Origin" to "*",
                                "Cache-Control" to "no-store"
                            ),
                            ByteArrayInputStream(localPayload.bytes)
                        )
                    }

                    // Intercept ONLY a selected GP file from the trusted alwaysdata
                    // endpoint. Load it fully before returning so an interrupted
                    // Google Drive stream cannot corrupt alphaTab's input. If primary
                    // is temporarily down, request the exact relative file on IIS.
                    val gpRoute = activeGpFailoverRoute.get()
                    if (request?.method.equals("GET", true) &&
                        gpRoute != null && url == gpRoute.primaryUrl
                    ) {
                        return try {
                            val payload = TuneToolsGpFailover.fetch(gpRoute)
                            if (payload.usedIis) {
                                mainHandler.post {
                                    if (activeGpFailoverRoute.get() === gpRoute) {
                                        Toast.makeText(
                                            context,
                                            "Google Drive tạm gián đoạn, đã dùng máy chủ dự phòng.",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            }
                            WebResourceResponse(
                                "application/octet-stream",
                                null,
                                200,
                                "OK",
                                mapOf(
                                    "Access-Control-Allow-Origin" to "*",
                                    "Cache-Control" to "no-store",
                                    "Content-Length" to payload.bytes.size.toString()
                                ),
                                ByteArrayInputStream(payload.bytes)
                            )
                        } catch (e: Exception) {
                            android.util.Log.e(
                                "TuneToolsGpFailover", "Cannot download GP from available servers", e
                            )
                            // Preserve primary 401/403 and a JSON 404 for a missing GP.
                            // A missing primary PHP route (HTML 404) is tried on IIS.
                            val status = (e as? GpDownloadHttpFailure)?.statusCode
                                ?.takeIf { it in 400..599 && it != 407 }
                                ?: 503
                            WebResourceResponse(
                                "text/plain",
                                "UTF-8",
                                status,
                                if (status == 503) "Service Unavailable" else "GP Request Failed",
                                mapOf(
                                    "Access-Control-Allow-Origin" to "*",
                                    "Cache-Control" to "no-store"
                                ),
                                ByteArrayInputStream("Không thể tải GP từ máy chủ.".toByteArray(StandardCharsets.UTF_8))
                            )
                        }
                    }

                    // Hai SoundFont tải thêm được phục vụ qua URL ảo. Dữ liệu thật nằm
                    // trong filesDir/soundfonts nên không làm tăng kích thước APK/AAB.
                    val localSoundFontMode = when (url) {
                        LOCAL_FLUIDR3_SOUNDFONT_URL -> TabSoundFontMode.FLUIDR3
                        LOCAL_MUSESCORE_SOUNDFONT_URL -> TabSoundFontMode.MUSESCORE
                        else -> null
                    }
                    if (localSoundFontMode != null) {
                        val localSoundFont = localSoundFontFileRefs[localSoundFontMode]?.get()
                        if (localSoundFont != null && localSoundFont.isFile && localSoundFont.length() > 0L) {
                            return try {
                                WebResourceResponse(
                                    "application/octet-stream",
                                    null,
                                    200,
                                    "OK",
                                    mapOf(
                                        "Access-Control-Allow-Origin" to "*",
                                        "Cache-Control" to "no-store",
                                        "Content-Length" to localSoundFont.length().toString()
                                    ),
                                    localSoundFont.inputStream().buffered()
                                )
                            } catch (_: Exception) {
                                null
                            }
                        }
                    }

                    if (url.endsWith(".gp3") || url.endsWith(".gp4") || url.endsWith(".gp5") || url.endsWith(".gpx") || url.endsWith(".gp")) {
                        try {
                            val connection = URL(url).openConnection() as HttpURLConnection
                            connection.requestMethod = "GET"
                            val inputStream = connection.inputStream
                            val responseHeaders = mutableMapOf(
                                "Access-Control-Allow-Origin" to "*",
                                "Access-Control-Allow-Methods" to "GET, OPTIONS",
                                "Access-Control-Allow-Headers" to "*"
                            )
                            return WebResourceResponse("application/octet-stream", "UTF-8", 200, "OK", responseHeaders, inputStream)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    return super.shouldInterceptRequest(view, request)
                }
            }

            addOnLayoutChangeListener { view, left, top, right, bottom,
                                        oldLeft, oldTop, oldRight, oldBottom ->
                val changed = right - left != oldRight - oldLeft ||
                        bottom - top != oldBottom - oldTop
                if (changed) (view as? WebView)?.let(::syncTabViewport)
            }

            addJavascriptInterface(object {
                @JavascriptInterface
                fun onTabReady() {
                    mainHandler.post {
                        isTabJsReady.set(true)
                        webViewInstance?.let(::dispatchPendingTabSong)
                    }
                }

                @JavascriptInterface
                fun onPlayerReady() {
                    mainHandler.post {
                        isPlayerReady = true
                        isSwitchingSoundFont = false
                        isCheckingSoundFontCompatibility = false
                    }
                }

                @JavascriptInterface
                fun onSoundFontLoadProgress(loaded: Double, total: Double) {
                    mainHandler.post {
                        soundFontDecodeProgress = if (total > 0.0) {
                            (loaded / total).toFloat().coerceIn(0f, 1f)
                        } else {
                            0f
                        }
                    }
                }

                @JavascriptInterface
                fun onSoundFontLoaded(mode: String, temporaryFallback: Boolean) {
                    mainHandler.post {
                        val loadedMode = TabSoundFontMode.fromJsValue(mode)
                        activeSoundFontMode = loadedMode
                        isSwitchingSoundFont = false
                        soundFontDecodeProgress = 1f

                        if (!temporaryFallback) {
                            // Keep a separate user preference for Piano vs. Guitar.
                            // Auto switches deliberately use temporaryFallback=true.
                            if (selectedDisplayMode.instrument == TabDisplayInstrument.PIANO) {
                                if (loadedMode != TabSoundFontMode.FLUIDR3) {
                                    selectedPianoSoundFontMode = loadedMode
                                    soundFontPrefs.edit()
                                        .putString(SOUNDFONT_PREF_PIANO_MODE, loadedMode.storedValue)
                                        .apply()
                                }
                            } else {
                                selectedSoundFontMode = loadedMode
                                soundFontPrefs.edit()
                                    .putString(SOUNDFONT_PREF_MODE, loadedMode.storedValue)
                                    .apply()
                            }
                            temporarySoundFontFallbackFrom = null
                        }
                        // Temporary auto switching changes only the active SoundFont.
                        // Guitar/Piano preferences and stored files stay untouched.
                    }
                }

                @JavascriptInterface
                fun onSoundFontCompatibilityCheckChanged(checking: Boolean) {
                    mainHandler.post {
                        // Khong ha isPlayerReady khi chi dang kiem tra am thanh. Neu bai tuong thich,
                        // nut Play phai su dung lai duoc ngay sau khi phep kiem tra ket thuc.
                        isCheckingSoundFontCompatibility = checking
                    }
                }

                @JavascriptInterface
                fun onSoundFontAutoFallback(mode: String) {
                    mainHandler.post {
                        val incompatibleMode = TabSoundFontMode.fromJsValue(mode)
                        temporarySoundFontFallbackFrom = incompatibleMode
                        isCheckingSoundFontCompatibility = false
                        isSwitchingSoundFont = true
                        isPlayerReady = false
                        soundFontDecodeProgress = 0f

                        Toast.makeText(
                            context,
                            soundFontFormat(
                                "tab_sound_auto_fallback", currentLang,
                                "Bộ âm thanh %1\$s không tạo được âm thanh cho bản nhạc này. Ứng dụng sẽ tự chuyển sang %2\$s.",
                                "The %1\$s audio pack produced no sound for this score. The app will switch to %2\$s automatically.",
                                incompatibleMode.menuTitle(currentLang),
                                TabSoundFontMode.STANDARD.menuTitle(currentLang)
                            ),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                @JavascriptInterface
                fun onSoundFontLoadFailed(mode: String, message: String) {
                    mainHandler.post {
                        val failedMode = TabSoundFontMode.fromJsValue(mode)
                        isSwitchingSoundFont = false
                        isCheckingSoundFontCompatibility = false
                        isPlayerReady = false
                        soundFontDecodeProgress = 0f

                        if (failedMode.isDownloadable) {
                            if (selectedDisplayMode.instrument == TabDisplayInstrument.PIANO) {
                                selectedPianoSoundFontMode = TabSoundFontMode.STANDARD
                                soundFontPrefs.edit()
                                    .putString(SOUNDFONT_PREF_PIANO_MODE, TabSoundFontMode.STANDARD.storedValue)
                                    .apply()
                            } else {
                                selectedSoundFontMode = TabSoundFontMode.STANDARD
                                soundFontPrefs.edit()
                                    .putString(SOUNDFONT_PREF_MODE, TabSoundFontMode.STANDARD.storedValue)
                                    .apply()
                            }
                            activeSoundFontMode = TabSoundFontMode.STANDARD
                            soundFontFallbackRequest++
                        }

                        val displayedMessage = if (failedMode.isDownloadable) {
                            soundFontFormat(
                                "tab_sound_load_fallback", currentLang,
                                "Không thể sử dụng %1\$s cho bản nhạc này. Ứng dụng sẽ chuyển sang %2\$s.",
                                "Could not use %1\$s for this score. The app will switch to %2\$s.",
                                failedMode.menuTitle(currentLang),
                                TabSoundFontMode.STANDARD.menuTitle(currentLang)
                            )
                        } else {
                            message.ifBlank {
                                soundFontText(
                                    "tab_sound_load_failed", currentLang,
                                    "Không thể nạp bộ âm thanh đã chọn.",
                                    "Could not load the selected audio pack."
                                )
                            }
                        }

                        Toast.makeText(
                            context,
                            displayedMessage,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                @JavascriptInterface
                fun onPlayerStateChanged(state: Int) { mainHandler.post { isPlaying = (state == 1) } }

                @JavascriptInterface
                fun onTempoChanged(bpm: Int) {
                    mainHandler.post {
                        if (bpm > 0) {
                            currentBpm = bpm
                            bpmText = bpm.toString()
                        }
                    }
                }

                @JavascriptInterface
                fun onTempoChangeFailed(message: String) {
                    mainHandler.post {
                        Toast.makeText(
                            context,
                            if (message.isBlank()) "Không thể thay đổi BPM." else message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                @JavascriptInterface
                fun onPdfLayoutReady() {
                    mainHandler.post {
                        startA4PdfPrint()
                    }
                }

                @JavascriptInterface
                fun onPdfExportFailed(message: String) {
                    mainHandler.post {
                        finishPdfExport(
                            message = if (message.isBlank()) {
                                "Không thể chuẩn bị bản nhạc để xuất PDF."
                            } else {
                                message
                            },
                            isError = true
                        )
                    }
                }

                @JavascriptInterface
                fun onTabBottomBannerVisibilityChanged(visible: Boolean) {
                    // JavaScriptInterface co the duoc goi tren background thread.
                    mainHandler.post {
                        val shouldShow = visible && hasScore && !isLoadingSong && currentSong != null
                        if (showTabBottomBanner != shouldShow) {
                            showTabBottomBanner = shouldShow
                        }
                    }
                }

                @JavascriptInterface
                fun onSongTechniqueInfoRequested() {
                    mainHandler.post {
                        if (!hasScore) return@post
                        songTechniqueDialogOpen = true
                        songTechniqueScanning = songTechniqueTrackIndex != selectedTrackIndex
                        webViewInstance?.evaluateJavascript(
                            "javascript:if(typeof reportSongTechniqueCatalog==='function'){reportSongTechniqueCatalog();}",
                            null
                        )
                    }
                }

                @JavascriptInterface
                fun onSongTechniqueCatalog(trackIndex: Int, itemsJson: String) {
                    mainHandler.post {
                        // Ignore callbacks that belong to an older/another track.
                        if (!hasScore || trackIndex != selectedTrackIndex) return@post
                        val found = mutableListOf<String>()
                        try {
                            val arr = JSONArray(itemsJson)
                            for (i in 0 until arr.length()) {
                                val key = arr.optString(i)
                                if (SONG_TECHNIQUE_LEGEND.containsKey(key) && !found.contains(key)) {
                                    found.add(key)
                                }
                            }
                        } catch (_: Exception) { /* Show empty state for invalid score data. */ }
                        songTechniqueIds = found
                        songTechniqueTrackIndex = trackIndex
                        songTechniqueScanning = false
                    }
                }

                @JavascriptInterface
                fun onSongTechniqueCatalogFailed() {
                    mainHandler.post { songTechniqueScanning = false }
                }

                @JavascriptInterface
                fun onDisplayModeRestoreFailed() {
                    mainHandler.post {
                        selectedDisplayMode = TabDisplayMode.SCORE_TAB
                        tabDisplayPrefs.edit().putString(
                            TAB_DISPLAY_PREF_MODE, TabDisplayMode.SCORE_TAB.jsValue
                        ).apply()
                        Toast.makeText(context, soundFontText(
                            "tab_display_restore_failed", currentLang,
                            "Track này không hỗ trợ cấu hình đã lưu; đã chuyển về Khuông + TAB.",
                            "This track cannot use the saved layout. Switched to Notation + TAB."
                        ), Toast.LENGTH_SHORT).show()
                    }
                }

                @JavascriptInterface
                fun onFretboardClosed() {
                    mainHandler.post {
                        selectedDisplayMode = TabDisplayMode.SCORE_TAB
                        tabDisplayPrefs.edit().putString(TAB_DISPLAY_PREF_MODE, TabDisplayMode.SCORE_TAB.jsValue).apply()
                        displayModeMenuExpanded = false
                    }
                }

                // JS chuyen pinch tren khuong/TAB sang Compose. Khong cap nhat
                // render AlphaTab giua cac frame de tranh mat su kien touch.
                @JavascriptInterface
                fun onScoreZoomGesture(phase: String, percent: Int) {
                    mainHandler.post {
                        if (!hasScore || isExportingPdf) return@post
                        val bounded = percent.coerceIn(TAB_SCORE_ZOOM_MIN, TAB_SCORE_ZOOM_MAX)
                        when (phase) {
                            "begin" -> {
                                scoreZoomMenuExpanded = false
                                scoreZoomPinchActive = true
                                scoreZoomPinchPreviewPercent = bounded
                                showScoreZoomControl()
                            }
                            "change" -> {
                                if (scoreZoomPinchActive) {
                                    scoreZoomPinchPreviewPercent = bounded
                                }
                            }
                            "end" -> {
                                scoreZoomPinchActive = false
                                scoreZoomPinchPreviewPercent = -1
                                setScoreZoomPercent(bounded)
                            }
                        }
                    }
                }

                @JavascriptInterface
                fun onScoreLoaded(tracksJson: String, title: String) {
                    // AlphaTab đã đọc xong dữ liệu nên có thể giải phóng bản sao byte local.
                    localScorePayload.set(null)
                    mainHandler.post {
                        songTechniqueIds = emptyList()
                        songTechniqueTrackIndex = -1
                        songTechniqueScanning = false
                        if (title.startsWith("Lỗi")) {
                            isLoadingSong = false
                            hasScore = false
                            showTabBottomBanner = false
                            isPlayerReady = false
                            currentBpm = 0
                            bpmText = ""
                            Toast.makeText(context, title, Toast.LENGTH_SHORT).show()
                        } else {
                            hasScore = true
                            isLoadingSong = false
                            val parsedTracks = mutableListOf<AlphaTrack>()
                            try {
                                val arr = JSONArray(tracksJson)
                                for (i in 0 until arr.length()) {
                                    parsedTracks.add(
                                        AlphaTrack(
                                            arr.getJSONObject(i).getInt("index"),
                                            arr.getJSONObject(i).getString("name")
                                        )
                                    )
                                }
                                tracks = parsedTracks
                                selectedTrackIndex = 0

                                // Nếu bài trước phải tạm dùng Sonivox, bài mới sẽ thử lại đúng
                                // cấu hình SF2/SF3 mà người dùng đã chọn và đã tải.
                                val wantedForThisView = if (
                                    selectedDisplayMode.instrument == TabDisplayInstrument.PIANO
                                ) selectedPianoSoundFontMode else selectedSoundFontMode
                                if (
                                    temporarySoundFontFallbackFrom != null &&
                                    activeSoundFontMode != wantedForThisView &&
                                    wantedForThisView.isDownloadable &&
                                    downloadedSoundFontModes[wantedForThisView] == true
                                ) {
                                    soundFontRestoreRequest++
                                }
                            } catch (_: Exception) {
                                tracks = emptyList()
                            }
                        }
                    }
                }
            }, "AndroidInterface")

            // Trình duyệt khởi tạo với cờ DarkTheme hiện tại
            loadDataWithBaseURL("https://tunertools.top", getAlphaTabHtml(
                isDarkInitial = localIsDark,
                initialSoundFontMode = startupSoundFontMode.jsValue,
                initialSoundFontUrl = startupSoundFontUrl,
                currentLang = currentLang,
                initialShowNoteNames = showNoteNames,
                initialMetronomeEnabled = metronomeEnabled,
                initialCursorColor = appearanceCursorHex,
                initialActiveRegionColor = appearanceActiveRegionHex,
                initialTabColor = appearanceTabHex,
                initialNoteColor = appearanceNoteHex,
                initialFretboardColor = appearanceFretboardHex,
                initialPanelColor = appearancePanelHex,
                initialCursorWidth = appearanceCursorWidth,
                initialRegionOpacity = appearanceRegionOpacity,
                initialScoreZoomPercent = customScoreZoomPercent,
                initialDisplayMode = selectedDisplayMode.jsValue
            ), "text/html", "UTF-8", null)
        }
    }

    LaunchedEffect(webView) {
        webViewInstance = webView
        syncTabViewport(webView)
        if (isTabJsReady.get()) dispatchPendingTabSong(webView)
    }

    // Nhin thay nut zoom 2 giay khi mo bai / chuyen che do; an de nhin duoc nhieu not.
    LaunchedEffect(hasScore, selectedDisplayMode, isExportingPdf, songs.isEmpty()) {
        if (hasScore && songs.isEmpty() && !isExportingPdf) {
            showScoreZoomControl()
        } else {
            scoreZoomControlVisible = false
            scoreZoomPinchActive = false
            scoreZoomPinchPreviewPercent = -1
            scoreZoomMenuExpanded = false
        }
    }

    // Dem lai 2 giay sau lan Zoom cuoi; khong an khi dang pinch/mo popup.
    LaunchedEffect(
        scoreZoomControlVisible, scoreZoomActivityToken,
        scoreZoomPinchActive, scoreZoomMenuExpanded
    ) {
        if (scoreZoomControlVisible && !scoreZoomPinchActive && !scoreZoomMenuExpanded) {
            delay(2000L)
            scoreZoomControlVisible = false
        }
    }

    // Chi thay doi alphaTab.display.scale. SVG can dan khong dung scale nay.
    LaunchedEffect(webViewInstance, customScoreZoomPercent) {
        webViewInstance?.evaluateJavascript(
            "javascript:if(typeof setScoreZoomPercent === 'function') {" +
                    "setScoreZoomPercent($customScoreZoomPercent);}",
            null
        )
    }

    // Đồng bộ toàn bộ bảng màu ngay khi người dùng đổi lựa chọn, không tải lại bài.
    LaunchedEffect(
        webViewInstance,
        localIsDark,
        appearanceCursorColorId,
        appearanceActiveRegionColorId,
        appearanceTabColorId,
        appearanceNoteColorId,
        appearanceFretboardColorId,
        appearancePanelColorId,
        appearanceCursorWidth,
        appearanceRegionOpacity
    ) {
        val script = "javascript:if(typeof applyVisualPreferences === 'function'){" +
                "applyVisualPreferences(" +
                localIsDark + "," +
                JSONObject.quote(appearanceCursorHex) + "," +
                JSONObject.quote(appearanceActiveRegionHex) + "," +
                JSONObject.quote(appearanceTabHex) + "," +
                JSONObject.quote(appearanceNoteHex) + "," +
                JSONObject.quote(appearanceFretboardHex) + "," +
                JSONObject.quote(appearancePanelHex) + "," +
                appearanceCursorWidth + "," +
                appearanceRegionOpacity +
                ");}"
        webViewInstance?.evaluateJavascript(script, null)
    }

    fun switchSoundFontMode(mode: TabSoundFontMode, rememberChoice: Boolean = true) {
        val pianoView = selectedDisplayMode.instrument == TabDisplayInstrument.PIANO
        // This is a playback limitation of the current Piano path, not an SF2 download error.
        if (pianoView && mode == TabSoundFontMode.FLUIDR3) return
        if (mode.isDownloadable && downloadedSoundFontModes[mode] != true) {
            Toast.makeText(
                context,
                soundFontFormat(
                    "tab_sound_download_first", currentLang,
                    "Hãy tải %1\$s trước.",
                    "Download %1\$s first.",
                    mode.menuTitle(currentLang)
                ),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val targetWebView = webViewInstance
        if (targetWebView == null) {
            Toast.makeText(
                context,
                soundFontText(
                    "tab_sound_player_not_ready", currentLang,
                    "Trình phát chưa sẵn sàng.",
                    "The player is not ready."
                ),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        soundFontMenuExpanded = false
        if (rememberChoice) {
            if (pianoView) {
                selectedPianoSoundFontMode = mode
                soundFontPrefs.edit()
                    .putString(SOUNDFONT_PREF_PIANO_MODE, mode.storedValue)
                    .apply()
            } else {
                selectedSoundFontMode = mode
                soundFontPrefs.edit()
                    .putString(SOUNDFONT_PREF_MODE, mode.storedValue)
                    .apply()
            }
            temporarySoundFontFallbackFrom = null
        }
        isCheckingSoundFontCompatibility = false
        isSwitchingSoundFont = true
        isPlayerReady = false
        soundFontDecodeProgress = 0f

        val jsMode = JSONObject.quote(mode.jsValue)
        val jsUrl = JSONObject.quote(mode.playbackUrl)
        // Auto switches must not overwrite either saved preference in the JS callback.
        val isTemporary = !rememberChoice
        targetWebView.evaluateJavascript(
            "javascript:(function(){" +
                    "if(typeof switchSoundFontMode !== 'function') return false;" +
                    "return switchSoundFontMode($jsMode, $jsUrl, $isTemporary);" +
                    "})();"
        ) { result ->
            if (result != "true") {
                mainHandler.post {
                    isSwitchingSoundFont = false
                    isPlayerReady = false
                    Toast.makeText(
                        context,
                        soundFontText(
                            "tab_sound_switch_failed", currentLang,
                            "Không thể chuyển bộ âm thanh. Hãy mở lại Bản nhạc.",
                            "Could not switch the audio pack. Reopen Sheet Music."
                        ),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    LaunchedEffect(soundFontFallbackRequest, webViewInstance) {
        if (soundFontFallbackRequest > 0 && webViewInstance != null) {
            switchSoundFontMode(TabSoundFontMode.STANDARD)
        }
    }

    LaunchedEffect(soundFontRestoreRequest, webViewInstance) {
        val preferredMode = if (selectedDisplayMode.instrument == TabDisplayInstrument.PIANO) {
            selectedPianoSoundFontMode
        } else {
            selectedSoundFontMode
        }
        if (
            soundFontRestoreRequest > 0 &&
            webViewInstance != null &&
            preferredMode.isDownloadable &&
            downloadedSoundFontModes[preferredMode] == true &&
            activeSoundFontMode != preferredMode
        ) {
            temporarySoundFontFallbackFrom = null
            switchSoundFontMode(preferredMode, rememberChoice = false)
        }
    }

    // Layout changes dynamically swap to the compatible SoundFont for each instrument.
    // Never modify Guitar's saved SF2 preference while the Piano screen is open.
    LaunchedEffect(
        selectedDisplayMode.instrument,
        selectedSoundFontMode,
        selectedPianoSoundFontMode,
        activeSoundFontMode,
        downloadedSoundFontModes[TabSoundFontMode.MUSESCORE],
        isPlayerReady,
        isSwitchingSoundFont,
        hasScore
    ) {
        if (!hasScore || !isPlayerReady || isSwitchingSoundFont || webViewInstance == null) {
            return@LaunchedEffect
        }
        val pianoView = selectedDisplayMode.instrument == TabDisplayInstrument.PIANO
        val preferred = if (pianoView) selectedPianoSoundFontMode else selectedSoundFontMode
        val wanted = when {
            pianoView && preferred == TabSoundFontMode.FLUIDR3 -> TabSoundFontMode.STANDARD
            preferred.isDownloadable && downloadedSoundFontModes[preferred] != true -> TabSoundFontMode.STANDARD
            // A SoundFont that failed on this score must not be retried in a loop,
            // regardless of whether the current view is Guitar or Piano.
            temporarySoundFontFallbackFrom == preferred -> TabSoundFontMode.STANDARD
            else -> preferred
        }
        if (wanted != activeSoundFontMode && downloadingSoundFontMode == null) {
            switchSoundFontMode(wanted, rememberChoice = false)
        }
    }

    LaunchedEffect(apiBaseUrl, searchPath, apiToken) {
        downloadableSoundFontModes.forEach { mode ->
            soundFontInfoErrors.remove(mode)
            try {
                val info = withContext(Dispatchers.IO) {
                    loadTabSoundFontInfo(apiBaseUrl, searchPath, apiToken, mode, currentLang)
                }
                soundFontInfos[mode] = info

                val completeFile = soundFontFiles.getValue(mode)
                val partFile = soundFontPartFiles.getValue(mode)
                if (completeFile.isFile) {
                    val savedVersion = soundFontPrefs.getString(
                        soundFontVersionPreferenceKey(mode),
                        null
                    )
                    val sizeMatches = completeFile.length() == info.sizeBytes
                    val versionMatches = savedVersion.isNullOrBlank() ||
                            savedVersion == info.version

                    if (sizeMatches && versionMatches) {
                        downloadedSoundFontModes[mode] = true
                        localSoundFontDataModes[mode] = true
                        localSoundFontFileRefs[mode]?.set(completeFile)
                        soundFontPrefs.edit()
                            .putLong(soundFontSizePreferenceKey(mode), info.sizeBytes)
                            .putString(soundFontVersionPreferenceKey(mode), info.version)
                            .apply()
                    } else {
                        // File hoàn chỉnh sai kích thước hoặc máy chủ có phiên bản mới:
                        // giữ lại để người dùng chủ động xóa/tải lại nhưng không dùng để phát.
                        downloadedSoundFontModes[mode] = false
                        localSoundFontDataModes[mode] = true
                        localSoundFontFileRefs[mode]?.set(null)
                        if (
                            selectedSoundFontMode == mode ||
                            activeSoundFontMode == mode
                        ) {
                            selectedSoundFontMode = TabSoundFontMode.STANDARD
                            activeSoundFontMode = TabSoundFontMode.STANDARD
                            soundFontFallbackRequest++
                        }
                    }
                } else {
                    downloadedSoundFontModes[mode] = false
                    localSoundFontFileRefs[mode]?.set(null)
                    localSoundFontDataModes[mode] = partFile.exists()
                }

                if (partFile.isFile && info.sizeBytes > 0L) {
                    val downloadedBytes = partFile.length()
                    soundFontDownloadedBytesByMode[mode] = downloadedBytes
                    soundFontDownloadProgressByMode[mode] =
                        (downloadedBytes.toDouble() / info.sizeBytes.toDouble())
                            .toFloat()
                            .coerceIn(0f, 1f)
                    localSoundFontDataModes[mode] = true
                }
            } catch (error: Exception) {
                if (downloadedSoundFontModes[mode] != true) {
                    soundFontInfoErrors[mode] =
                        error.message ?: soundFontText(
                            "tab_sound_server_error", currentLang,
                            "Không thể kết nối máy chủ SoundFont.",
                            "Could not connect to the SoundFont server."
                        )
                }
            }
        }
    }

    fun startSoundFontDownload(mode: TabSoundFontMode) {
        if (!mode.isDownloadable || downloadingSoundFontMode != null) return

        downloadingSoundFontMode = mode
        soundFontInfoErrors.remove(mode)

        scope.launch {
            try {
                val info = soundFontInfos[mode] ?: withContext(Dispatchers.IO) {
                    loadTabSoundFontInfo(apiBaseUrl, searchPath, apiToken, mode, currentLang)
                }.also { soundFontInfos[mode] = it }

                val completeFile = soundFontFiles.getValue(mode)
                val partFile = soundFontPartFiles.getValue(mode)
                val downloadedFile = withContext(Dispatchers.IO) {
                    val directory = soundFontDirectory(context)
                    if (!directory.exists() && !directory.mkdirs()) {
                        throw IllegalStateException(
                            soundFontText(
                                "tab_sound_create_dir_failed", currentLang,
                                "Không thể tạo thư mục lưu SoundFont.",
                                "Could not create the SoundFont storage folder."
                            )
                        )
                    }

                    val savedCompleteVersion = soundFontPrefs.getString(
                        soundFontVersionPreferenceKey(mode),
                        null
                    )
                    if (
                        completeFile.isFile &&
                        completeFile.length() == info.sizeBytes &&
                        (savedCompleteVersion.isNullOrBlank() ||
                                savedCompleteVersion == info.version)
                    ) {
                        return@withContext completeFile
                    }

                    val savedPartVersion = soundFontPrefs.getString(
                        soundFontPartVersionPreferenceKey(mode),
                        null
                    )
                    if (partFile.exists() && savedPartVersion != info.version) {
                        partFile.delete()
                    }

                    soundFontPrefs.edit()
                        .putString(soundFontPartVersionPreferenceKey(mode), info.version)
                        .apply()

                    var existingBytes = partFile.takeIf { it.isFile }?.length() ?: 0L
                    if (existingBytes > info.sizeBytes) {
                        partFile.delete()
                        existingBytes = 0L
                    }

                    if (existingBytes == info.sizeBytes && existingBytes > 0L) {
                        if (completeFile.exists()) completeFile.delete()
                        if (!partFile.renameTo(completeFile)) {
                            partFile.copyTo(completeFile, overwrite = true)
                            partFile.delete()
                        }
                        return@withContext completeFile
                    }

                    val remainingBytes = info.sizeBytes - existingBytes
                    val safetyBytes = 20L * 1024L * 1024L
                    if (
                        directory.usableSpace > 0L &&
                        directory.usableSpace < remainingBytes + safetyBytes
                    ) {
                        throw IllegalStateException(
                            soundFontFormat(
                                "tab_sound_storage_not_enough", currentLang,
                                "Bộ nhớ trống không đủ. Cần thêm ít nhất %1\$s.",
                                "Not enough free storage. At least %1\$s more is required.",
                                formatStorageSize(remainingBytes + safetyBytes)
                            )
                        )
                    }

                    val connection = URL(info.downloadUrl).openConnection() as HttpURLConnection
                    try {
                        connection.requestMethod = "GET"
                        connection.connectTimeout = 20_000
                        connection.readTimeout = 120_000
                        connection.setRequestProperty("Accept", "application/octet-stream")
                        connection.setRequestProperty("Accept-Encoding", "identity")
                        connection.setRequestProperty("User-Agent", "TunerInstrument-Android")
                        if (!apiToken.isNullOrBlank()) {
                            connection.setRequestProperty("Authorization", "Bearer $apiToken")
                        }
                        if (existingBytes > 0L) {
                            connection.setRequestProperty("Range", "bytes=$existingBytes-")
                        }

                        val responseCode = connection.responseCode
                        var append =
                            responseCode == HttpURLConnection.HTTP_PARTIAL && existingBytes > 0L

                        if (responseCode == HttpURLConnection.HTTP_OK && existingBytes > 0L) {
                            partFile.delete()
                            existingBytes = 0L
                            append = false
                        }

                        if (
                            responseCode != HttpURLConnection.HTTP_OK &&
                            responseCode != HttpURLConnection.HTTP_PARTIAL
                        ) {
                            val serverMessage = connection.errorStream
                                ?.bufferedReader(StandardCharsets.UTF_8)
                                ?.use { it.readText() }
                                .orEmpty()
                            throw IllegalStateException(
                                runCatching {
                                    JSONObject(serverMessage).optString("error")
                                }.getOrNull().orEmpty().ifBlank {
                                    soundFontFormat(
                                        "tab_sound_http_failed", currentLang,
                                        "Tải SoundFont thất bại: HTTP %1\$d",
                                        "SoundFont download failed: HTTP %1\$d",
                                        responseCode
                                    )
                                }
                            )
                        }

                        var totalWritten = existingBytes
                        BufferedInputStream(connection.inputStream, 128 * 1024).use { input ->
                            BufferedOutputStream(
                                FileOutputStream(partFile, append),
                                128 * 1024
                            ).use { output ->
                                val buffer = ByteArray(128 * 1024)
                                var lastUiUpdate = 0L

                                while (true) {
                                    val readCount = input.read(buffer)
                                    if (readCount < 0) break
                                    if (readCount == 0) continue

                                    output.write(buffer, 0, readCount)
                                    totalWritten += readCount

                                    val now = System.currentTimeMillis()
                                    if (now - lastUiUpdate >= 120L) {
                                        lastUiUpdate = now
                                        val bytesForUi = totalWritten
                                        mainHandler.post {
                                            soundFontDownloadedBytesByMode[mode] = bytesForUi
                                            soundFontDownloadProgressByMode[mode] =
                                                (bytesForUi.toDouble() / info.sizeBytes.toDouble())
                                                    .toFloat()
                                                    .coerceIn(0f, 1f)
                                            localSoundFontDataModes[mode] = true
                                        }
                                    }
                                }
                                output.flush()
                            }
                        }
                    } finally {
                        connection.disconnect()
                    }

                    if (partFile.length() != info.sizeBytes) {
                        throw IllegalStateException(
                            soundFontFormat(
                                "tab_sound_file_incomplete", currentLang,
                                "File tải chưa hoàn tất: %1\$s / %2\$s",
                                "Download incomplete: %1\$s / %2\$s",
                                formatStorageSize(partFile.length()),
                                formatStorageSize(info.sizeBytes)
                            )
                        )
                    }

                    if (completeFile.exists() && !completeFile.delete()) {
                        throw IllegalStateException(
                            soundFontText(
                                "tab_sound_replace_failed", currentLang,
                                "Không thể thay thế SoundFont cũ.",
                                "Could not replace the previous SoundFont."
                            )
                        )
                    }

                    if (!partFile.renameTo(completeFile)) {
                        partFile.copyTo(completeFile, overwrite = true)
                        partFile.delete()
                    }

                    completeFile
                }

                localSoundFontFileRefs[mode]?.set(downloadedFile)
                downloadedSoundFontModes[mode] = true
                localSoundFontDataModes[mode] = true
                soundFontDownloadedBytesByMode[mode] = downloadedFile.length()
                soundFontDownloadProgressByMode[mode] = 1f
                soundFontPrefs.edit()
                    .putLong(soundFontSizePreferenceKey(mode), downloadedFile.length())
                    .putString(soundFontVersionPreferenceKey(mode), info.version)
                    .remove(soundFontPartVersionPreferenceKey(mode))
                    .apply()

                Toast.makeText(
                    context,
                    soundFontFormat(
                        "tab_sound_downloaded", currentLang,
                        "Đã tải %1\$s (%2\$s).",
                        "Downloaded %1\$s (%2\$s).",
                        info.displayName,
                        formatStorageSize(downloadedFile.length())
                    ),
                    Toast.LENGTH_LONG
                ).show()

                switchSoundFontMode(mode)
            } catch (error: Exception) {
                val completeFile = soundFontFiles.getValue(mode)
                val partFile = soundFontPartFiles.getValue(mode)
                localSoundFontDataModes[mode] = completeFile.exists() || partFile.exists()
                val errorMessage = error.message ?: soundFontText(
                    "tab_sound_download_failed", currentLang,
                    "Không thể tải SoundFont.",
                    "Could not download SoundFont."
                )
                soundFontInfoErrors[mode] = errorMessage
                Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
            } finally {
                downloadingSoundFontMode = null
            }
        }
    }

    fun deleteSoundFont(mode: TabSoundFontMode) {
        if (!mode.isDownloadable) return
        if (downloadingSoundFontMode == mode) {
            Toast.makeText(
                context,
                soundFontText(
                    "tab_sound_delete_wait", currentLang,
                    "SoundFont đang tải. Hãy đợi hoàn tất rồi xóa.",
                    "SoundFont is downloading. Wait until it finishes before deleting."
                ),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val wasActive =
            selectedSoundFontMode == mode || activeSoundFontMode == mode
        if (wasActive) {
            if (webViewInstance != null) {
                switchSoundFontMode(TabSoundFontMode.STANDARD)
            } else {
                selectedSoundFontMode = TabSoundFontMode.STANDARD
                activeSoundFontMode = TabSoundFontMode.STANDARD
                soundFontPrefs.edit()
                    .putString(
                        SOUNDFONT_PREF_MODE,
                        TabSoundFontMode.STANDARD.storedValue
                    )
                    .apply()
            }
        }

        localSoundFontFileRefs[mode]?.set(null)
        scope.launch {
            if (wasActive) delay(350L)

            val completeFile = soundFontFiles.getValue(mode)
            val partFile = soundFontPartFiles.getValue(mode)
            val deleted = withContext(Dispatchers.IO) {
                var success = true
                if (completeFile.exists()) {
                    success = completeFile.delete() && success
                }
                if (partFile.exists()) {
                    success = partFile.delete() && success
                }
                success
            }

            if (deleted) {
                downloadedSoundFontModes[mode] = false
                localSoundFontDataModes[mode] = false
                soundFontDownloadedBytesByMode[mode] = 0L
                soundFontDownloadProgressByMode[mode] = 0f
                soundFontInfoErrors.remove(mode)
                soundFontPrefs.edit()
                    .remove(soundFontSizePreferenceKey(mode))
                    .remove(soundFontVersionPreferenceKey(mode))
                    .remove(soundFontPartVersionPreferenceKey(mode))
                    .apply()
                Toast.makeText(
                    context,
                    soundFontFormat(
                        "tab_sound_deleted", currentLang,
                        "Đã xóa %1\$s khỏi thiết bị.",
                        "Removed %1\$s from this device.",
                        mode.menuTitle(currentLang)
                    ),
                    Toast.LENGTH_LONG
                ).show()
            } else {
                localSoundFontDataModes[mode] = completeFile.exists() || partFile.exists()
                Toast.makeText(
                    context,
                    soundFontText(
                        "tab_sound_delete_failed", currentLang,
                        "Không thể xóa hoàn toàn file SoundFont.",
                        "Could not completely delete the SoundFont file."
                    ),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    fun selectTrack(index: Int) {
        if (index !in tracks.indices) return
        selectedTrackIndex = index
        songTechniqueIds = emptyList()
        songTechniqueTrackIndex = -1
        songTechniqueScanning = songTechniqueDialogOpen
        isCheckingSoundFontCompatibility = false
        webViewInstance?.evaluateJavascript("javascript:selectTrackSolo($index);", null)
        if (songTechniqueDialogOpen) {
            webViewInstance?.evaluateJavascript(
                "javascript:if(typeof reportSongTechniqueCatalog==='function'){reportSongTechniqueCatalog();}", null
            )
        }
    }

    fun applyBpm() {
        if (!hasScore) return

        val targetBpm = bpmText.toIntOrNull()
        if (targetBpm == null) {
            Toast.makeText(context, "Vui lòng nhập BPM.", Toast.LENGTH_SHORT).show()
            return
        }
        if (targetBpm !in 20..400) {
            Toast.makeText(
                context,
                "BPM phải nằm trong khoảng 20 đến 400.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        focusManager.clearFocus()
        webViewInstance?.evaluateJavascript(
            "javascript:if (typeof setScoreBpm === 'function') { setScoreBpm($targetBpm); } else { AndroidInterface.onTempoChangeFailed('Bộ điều khiển BPM chưa sẵn sàng.'); }",
            null
        )
    }

    // One Apply action -> one native-to-WebView update -> one re-engrave.
    // Do not call setNoteNamesVisible separately: that would render the score twice.
    fun applyDisplaySelection() {
        if (displayConfigurationApplying || isExportingPdf) return
        val mode = TabDisplayMode.fromSelection(draftShowScore, draftShowTab, draftInstrument)
        val names = draftShowNoteNames
        if (mode == selectedDisplayMode && names == showNoteNames) {
            displayModeMenuExpanded = false
            return
        }
        val targetWebView = webViewInstance
        if (targetWebView == null || !hasScore) {
            Toast.makeText(context, soundFontText(
                "tab_display_not_ready", currentLang,
                "Bản nhạc chưa sẵn sàng để đổi chế độ hiển thị.",
                "The score is not ready for changing the display mode."
            ), Toast.LENGTH_SHORT).show()
            return
        }
        displayConfigurationApplying = true
        targetWebView.evaluateJavascript(
            "javascript:(function(){" +
                    "if(typeof setStaveDisplayMode!=='function')return false;" +
                    "return setStaveDisplayMode(${JSONObject.quote(mode.jsValue)}, $names);" +
                    "})();"
        ) { result ->
            mainHandler.post {
                displayConfigurationApplying = false
                if (result == "true") {
                    selectedDisplayMode = mode
                    showNoteNames = names
                    tabDisplayPrefs.edit()
                        .putString(TAB_DISPLAY_PREF_MODE, mode.jsValue)
                        .putBoolean(TAB_DISPLAY_PREF_NOTE_NAMES, names)
                        .apply()
                    if (mode.hasInstrumentPanel) {
                        offsetX = 0f
                        offsetY = 0f
                        showTabBottomBanner = false
                    }
                    displayModeMenuExpanded = false
                } else {
                    Toast.makeText(context, soundFontText(
                        "tab_display_switch_failed", currentLang,
                        "Không thể đổi chế độ hiển thị cho track này.",
                        "Could not apply this display combination to the selected track."
                    ), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    fun setNoteNamesEnabled(enabled: Boolean) {
        if (isExportingPdf || enabled == showNoteNames) return

        val previousValue = showNoteNames
        showNoteNames = enabled
        tabDisplayPrefs.edit()
            .putBoolean(TAB_DISPLAY_PREF_NOTE_NAMES, enabled)
            .apply()

        val targetWebView = webViewInstance
        if (targetWebView == null || !hasScore) return

        targetWebView.evaluateJavascript(
            "javascript:(function(){" +
                    "if(typeof setNoteNamesVisible !== 'function') return false;" +
                    "return setNoteNamesVisible($enabled);" +
                    "})();"
        ) { result ->
            if (result != "true") {
                mainHandler.post {
                    showNoteNames = previousValue
                    tabDisplayPrefs.edit()
                        .putBoolean(TAB_DISPLAY_PREF_NOTE_NAMES, previousValue)
                        .apply()
                    Toast.makeText(
                        context,
                        soundFontText(
                            "tab_note_names_switch_failed",
                            currentLang,
                            "Không thể thay đổi hiển thị tên nốt.",
                            "Could not change note-name display."
                        ),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    fun requestPdfExport() {
        if (!hasScore || isExportingPdf) return

        val targetWebView = webViewInstance
        if (targetWebView == null) {
            Toast.makeText(
                context,
                "Bản nhạc chưa sẵn sàng để xuất PDF.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        focusManager.clearFocus()
        pdfPrintStarted.set(false)
        pdfJobName.set(buildA4PdfJobName(currentSong?.title))
        isExportingPdf = true

        targetWebView.evaluateJavascript(
            "javascript:if (typeof prepareA4PdfExport === 'function') { prepareA4PdfExport(); } else { AndroidInterface.onPdfExportFailed('Bộ xuất PDF chưa sẵn sàng.'); }",
            null
        )
    }

    fun searchSongs(
        section: MusicLibrarySection = selectedMusicSection,
        queryOverride: String? = null,
        rhythmOverride: String? = null,
        folderOverride: String? = null,
        showNoResultsToast: Boolean = true
    ) {
        val q = (queryOverride ?: searchQueries[section].orEmpty()).trim()
        val requestedRhythm = if (section == MusicLibrarySection.DIEU_NHAC) {
            (rhythmOverride ?: selectedRhythm)
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
        } else {
            null
        }
        val requestedVietnamFolder = if (section == MusicLibrarySection.NHAC_VIET) {
            (folderOverride ?: selectedVietnamFolder)
                .trim()
                .trim('/')
        } else {
            ""
        }

        focusManager.clearFocus()

        // Cho phép phát sinh request mới ngay cả khi request cũ chưa xong.
        // searchRequestId sẽ loại bỏ kết quả cũ khi nó trả về muộn.
        searchRequestId += 1
        val requestId = searchRequestId
        isSearching = true
        songs.clear()

        scope.launch {
            try {
                val (outcome, usedInternationalSearch) = withContext(Dispatchers.IO) {
                    val first = TuneToolsSheetMusicApi.search(
                        apiBaseUrl = apiBaseUrl,
                        searchPath = searchPath,
                        keyword = q,
                        apiToken = apiToken,
                        section = section,
                        rhythm = requestedRhythm,
                        folder = requestedVietnamFolder.takeIf { it.isNotEmpty() }
                    )
                    // Only an explicit Vietnamese keyword search with zero results falls
                    // through to international. Empty folder/category listings are preserved.
                    if (section == MusicLibrarySection.NHAC_VIET && q.isNotBlank() && first.songs.isEmpty()) {
                        val international = runCatching {
                            TuneToolsSheetMusicApi.search(
                                apiBaseUrl = apiBaseUrl,
                                searchPath = searchPath,
                                keyword = q,
                                apiToken = apiToken,
                                section = MusicLibrarySection.QUOC_TE
                            )
                        }.getOrNull()
                        if (international != null) Pair(international, true)
                        else Pair(first, false) // Keep a valid VN response on network error.
                    } else Pair(first, false)
                }
                val result = outcome.songs

                val isStillSameRhythm =
                    section != MusicLibrarySection.DIEU_NHAC ||
                            selectedRhythm == requestedRhythm
                val isStillSameVietnamFolder =
                    section != MusicLibrarySection.NHAC_VIET ||
                            selectedVietnamFolder == requestedVietnamFolder

                // Chỉ nhận kết quả của lần tìm mới nhất, đúng tab và đúng thư mục.
                if (
                    requestId == searchRequestId &&
                    selectedMusicSection == section &&
                    isStillSameRhythm &&
                    isStillSameVietnamFolder
                ) {
                    activeSearchSource = outcome.source
                    if (usedInternationalSearch) {
                        // Display the actual source and preserve the user's query.
                        searchQueries[MusicLibrarySection.QUOC_TE] = q
                        selectedMusicSection = MusicLibrarySection.QUOC_TE
                        selectedVietnamFolder = ""
                        selectedRhythm = null
                        if (result.isNotEmpty()) {
                            Toast.makeText(
                                context,
                                "Không tìm thấy ở Nhạc Việt. Đang hiển thị kết quả Quốc tế.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    songs.addAll(result)
                    if (result.isEmpty() && showNoResultsToast) {
                        val message = when {
                            usedInternationalSearch ->
                                "Không tìm thấy bài phù hợp trong cả Nhạc Việt và Quốc tế."

                            section == MusicLibrarySection.DIEU_NHAC &&
                                    requestedRhythm != null ->
                                "Không tìm thấy bản Tab trong điệu $requestedRhythm."

                            section == MusicLibrarySection.DIEU_NHAC ->
                                "Không tìm thấy điệu nhạc phù hợp."

                            section == MusicLibrarySection.NHAC_VIET &&
                                    requestedVietnamFolder.isNotBlank() ->
                                "Không tìm thấy bản Tab trong thư mục ${requestedVietnamFolder.substringAfterLast('/')}."

                            section == MusicLibrarySection.NHAC_VIET ->
                                "Không tìm thấy Nhạc Việt phù hợp."

                            else -> "Không tìm thấy nội dung phù hợp."
                        }
                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (cancelled: CancellationException) {
                // "rememberCoroutineScope left the composition" means this UI
                // coroutine was cancelled. Do not display it as a network error.
                throw cancelled
            } catch (e: Exception) {
                android.util.Log.e(
                    "TuneToolsSheetMusicApi",
                    "Sheet search failed; section=$section",
                    e
                )
                val isStillSameRhythm =
                    section != MusicLibrarySection.DIEU_NHAC ||
                            selectedRhythm == requestedRhythm
                val isStillSameVietnamFolder =
                    section != MusicLibrarySection.NHAC_VIET ||
                            selectedVietnamFolder == requestedVietnamFolder

                if (
                    requestId == searchRequestId &&
                    selectedMusicSection == section &&
                    isStillSameRhythm &&
                    isStillSameVietnamFolder
                ) {
                    Toast.makeText(
                        context,
                        "Không thể tìm kiếm bản nhạc. Hãy kiểm tra kết nối rồi thử lại.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } finally {
                if (requestId == searchRequestId) {
                    isSearching = false
                }
            }
        }
    }

    // alwaysdata is the authoritative catalogue for ALL three tabs.
    // Do not poll or overwrite its list with the legacy IIS source after 20 seconds.
    // If alwaysdata is temporarily unreachable, search() falls back to IIS only
    // for that request; the next user search tries alwaysdata again.

    fun openRhythmFolder(item: TuneToolsSong) {
        if (!item.isFolder || isLoadingSong) return

        val rhythmName = item.rhythm
            .ifBlank { item.title }
            .trim()

        if (rhythmName.isEmpty()) return

        selectedRhythm = rhythmName
        searchQueries[MusicLibrarySection.DIEU_NHAC] = ""
        hideExtraButtons = false

        searchSongs(
            section = MusicLibrarySection.DIEU_NHAC,
            queryOverride = "",
            rhythmOverride = rhythmName,
            showNoResultsToast = false
        )
    }

    fun showRhythmFolders() {
        selectedRhythm = null
        searchQueries[MusicLibrarySection.DIEU_NHAC] = ""
        hideExtraButtons = false

        searchSongs(
            section = MusicLibrarySection.DIEU_NHAC,
            queryOverride = "",
            rhythmOverride = null,
            showNoResultsToast = false
        )
    }

    fun openVietnamFolder(item: TuneToolsSong) {
        if (!item.isFolder || isLoadingSong) return

        val folderPath = item.folderPath
            .ifBlank { item.relativePath }
            .trim()
            .trim('/')

        if (folderPath.isEmpty()) return

        selectedVietnamFolder = folderPath
        searchQueries[MusicLibrarySection.NHAC_VIET] = ""
        hideExtraButtons = false

        searchSongs(
            section = MusicLibrarySection.NHAC_VIET,
            queryOverride = "",
            folderOverride = folderPath,
            showNoResultsToast = false
        )
    }

    fun showParentVietnamFolder() {
        val currentFolder = selectedVietnamFolder.trim().trim('/')
        val parentFolder = if (currentFolder.contains('/')) {
            currentFolder.substringBeforeLast('/')
        } else {
            ""
        }

        selectedVietnamFolder = parentFolder
        searchQueries[MusicLibrarySection.NHAC_VIET] = ""
        hideExtraButtons = false

        searchSongs(
            section = MusicLibrarySection.NHAC_VIET,
            queryOverride = "",
            folderOverride = parentFolder,
            showNoResultsToast = false
        )
    }

    fun selectMusicSection(section: MusicLibrarySection) {
        if (section == selectedMusicSection) return

        // Hủy hiệu lực kết quả của request cũ nếu người dùng đổi tab khi đang tải.
        searchRequestId += 1
        isSearching = false
        selectedMusicSection = section
        selectedRhythm = null
        selectedVietnamFolder = ""
        songs.clear()
        focusManager.clearFocus()
        hideExtraButtons = false

        searchSongs(
            section = section,
            rhythmOverride = null,
            showNoResultsToast = false
        )
    }

    // Một số file GP3/GP4/GP5 cũ chứa tên tiếng Việt ở bảng mã ANSI, khiến
    // API hoặc alphaTab giải mã thành "V?ng Tr?ng Kh�c". Không dùng tên đã lỗi
    // làm fallback cho khuông nhạc; ưu tiên tên sạch lấy từ danh sách/đường dẫn.
    fun isUsableSongTitle(raw: String): Boolean {
        val title = raw.replace(Regex("\\s+"), " ").trim()
        if (title.isBlank() || title.contains('\uFFFD')) return false
        if (title.all { it == '?' || it.isWhitespace() }) return false
        if (Regex("""[\p{L}\p{N}]\?[\p{L}\p{N}]""").containsMatchIn(title)) return false
        if (Regex("""(?:Ã[\u0080-\u00BF]|Â[\u0080-\u00BF]|á[º»])""").containsMatchIn(title)) return false
        if (title.lowercase(Locale.ROOT) in setOf("không tên", "bài nhạc", "bản nhạc", "untitled", "n/a")) return false
        return true
    }

    fun resolveScoreFallbackTitle(song: TuneToolsSong): String {
        val providedTitle = song.title.replace(Regex("\\s+"), " ").trim()
        if (isUsableSongTitle(providedTitle)) return providedTitle

        // Tên API bị lỗi thì thử relativePath trước; nếu thiếu, lấy tên file
        // từ URL (hỗ trợ cả tên có dấu đã percent-encode, không suy đoán dấu).
        fun titleFromPath(rawPath: String): String? {
            if (rawPath.isBlank()) return null
            val path = Uri.decode(rawPath.substringBefore('?').substringBefore('#'))
            val fileName = path.trim('/').substringAfterLast('/').trim()
            val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (extension !in SUPPORTED_GP_EXTENSIONS) return null

            val stem = fileName.substringBeforeLast('.')
                .replace('_', ' ')
                .replace(Regex("\\s+"), " ")
                .trim()
            val title = stem.substringAfter(" - ", stem).trim()
            return title.takeIf { isUsableSongTitle(it) && it.any(Char::isLetter) }
        }

        return titleFromPath(song.relativePath)
            ?: titleFromPath(song.fileUrl)
            ?: "Bản nhạc"
    }

    fun openSong(song: TuneToolsSong) {
        if (isLoadingSong) return

        // Activate a backup route only for a trusted Drive GP URL with an exact,
        // validated relative path on the IIS archive. Local GP remains unchanged.
        activeGpFailoverRoute.set(TuneToolsGpFailover.routeFor(song))

        // Không để kết quả tìm kiếm đang chạy quay về phủ lên bản nhạc vừa mở.
        searchRequestId += 1
        isSearching = false

        if (!song.fileUrl.startsWith(LOCAL_SCORE_URL_PREFIX)) {
            localScorePayload.set(null)
        }

        hideExtraButtons = false
        focusManager.clearFocus()

        currentSong = song
        showTabBottomBanner = false
        isLoadingSong = true
        isPlaying = false
        isPlayerReady = false
        isCheckingSoundFontCompatibility = false
        hasScore = false
        currentBpm = 0
        bpmText = ""
        tracks = emptyList()
        songs.clear()

        offsetX = 0f
        offsetY = 0f

        val quotedFileUrl = JSONObject.quote(song.fileUrl)
        val quotedSongTitle = JSONObject.quote(resolveScoreFallbackTitle(song))
        pendingTabSongScript.set(
            "javascript:if(typeof stopPlayer==='function')stopPlayer();" +
                    "loadScoreFromUrl($quotedFileUrl, $quotedSongTitle);"
        )
        if (isTabJsReady.get()) {
            webViewInstance?.let(::dispatchPendingTabSong)
        }
    }

    // Mở file GP trực tiếp từ bộ nhớ máy bằng Android Storage Access Framework.
    val localFileLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null && !isImportingLocalFile && !isLoadingSong) {
            isImportingLocalFile = true
            focusManager.clearFocus()

            scope.launch {
                try {
                    runCatching {
                        context.contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }

                    val selectedFile = withContext(Dispatchers.IO) {
                        readLocalScoreFile(context, uri)
                    }

                    val requestUrl = buildString {
                        append(LOCAL_SCORE_URL_PREFIX)
                        append(System.nanoTime())
                        append('.')
                        append(selectedFile.extension)
                    }

                    localScorePayload.set(
                        LocalScorePayload(
                            requestUrl = requestUrl,
                            bytes = selectedFile.bytes
                        )
                    )

                    val localTitle = selectedFile.displayName
                        .substringBeforeLast('.', missingDelimiterValue = selectedFile.displayName)
                        .ifBlank { "Bản nhạc trong máy" }

                    openSong(
                        TuneToolsSong(
                            id = "local:$uri",
                            title = localTitle,
                            artist = "Tệp trong máy",
                            fileUrl = requestUrl,
                            format = selectedFile.extension
                        )
                    )
                } catch (e: Exception) {
                    localScorePayload.set(null)
                    Toast.makeText(
                        context,
                        e.message ?: "Không thể mở file đã chọn.",
                        Toast.LENGTH_LONG
                    ).show()
                } finally {
                    isImportingLocalFile = false
                }
            }
        }
    }

    // Launcher nhận nội dung tìm kiếm bằng giọng nói cho tab đang chọn.
    val speechLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(
                android.speech.RecognizerIntent.EXTRA_RESULTS
            )
            if (!matches.isNullOrEmpty()) {
                val section = selectedMusicSection
                val spokenText = matches[0]
                searchQueries[section] = spokenText
                searchSongs(
                    section = section,
                    queryOverride = spokenText
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            localScorePayload.set(null)
            pdfPrintStarted.set(false)
            webViewInstance?.destroy()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    val screenContent = @Composable {
        val isViewingSong = currentSong != null || isLoadingSong || hasScore
        val isInsideRhythmFolder =
            selectedMusicSection == MusicLibrarySection.DIEU_NHAC &&
                    !selectedRhythm.isNullOrBlank() &&
                    !isViewingSong
        val isInsideVietnamFolder =
            selectedMusicSection == MusicLibrarySection.NHAC_VIET &&
                    selectedVietnamFolder.isNotBlank() &&
                    !isViewingSong
        val showBackButton = isViewingSong || isInsideRhythmFolder || isInsideVietnamFolder
        val currentSearchText = searchQueries[selectedMusicSection].orEmpty()
        val currentSearchHint = when {
            selectedMusicSection == MusicLibrarySection.DIEU_NHAC &&
                    !selectedRhythm.isNullOrBlank() ->
                soundFontFormat(
                    "tab_library_search_in_rhythm", currentLang,
                    "Tìm bản TAB trong %1\$s...", "Search TABs in %1\$s...",
                    selectedRhythm.orEmpty()
                )

            selectedMusicSection == MusicLibrarySection.NHAC_VIET &&
                    selectedVietnamFolder.isNotBlank() ->
                soundFontFormat(
                    "tab_library_search_in_folder", currentLang,
                    "Tìm trong %1\$s...", "Search in %1\$s...",
                    selectedVietnamFolder.substringAfterLast('/')
                )

            else -> selectedMusicSection.searchHint(currentLang)
        }
        val currentFolderRootTitle = when {
            isInsideRhythmFolder -> MusicLibrarySection.DIEU_NHAC.tabTitle(currentLang)
            isInsideVietnamFolder -> MusicLibrarySection.NHAC_VIET.tabTitle(currentLang)
            else -> ""
        }
        val currentFolderPathTitle = when {
            isInsideRhythmFolder -> selectedRhythm.orEmpty()
            isInsideVietnamFolder -> selectedVietnamFolder
                .split('/')
                .filter { it.isNotBlank() }
                .joinToString("  ›  ")
            else -> ""
        }
        val parsedBpm = bpmText.toIntOrNull()
        val canApplyBpm = hasScore &&
                parsedBpm != null &&
                parsedBpm in 20..400 &&
                parsedBpm != currentBpm

        Surface(
            modifier = modifier.fillMaxSize(),
            color = bgColor
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(
                        WindowInsets.safeDrawing.only(WindowInsetsSides.Top)
                    )
                    .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // --- HEADER & Ô TÌM KIẾM ---
                androidx.compose.animation.AnimatedVisibility(
                    visible = !(isLandscape && isPlaying), // Ẩn khi đang xoay ngang VÀ nhạc đang phát
                    enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(
                            if (isViewingSong) 6.dp else 8.dp
                        )
                    ) {
                        // NÚT HOME HOẶC BACK
                        IconButton(
                            onClick = {
                                when {
                                    isViewingSong -> {
                                        // Dọn bản nhạc rồi quay lại đúng danh sách trước đó.
                                        currentSong = null
                                        hasScore = false
                                        showTabBottomBanner = false
                                        isLoadingSong = false
                                        isPlaying = false
                                        isPlayerReady = false
                                        currentBpm = 0
                                        bpmText = ""
                                        tracks = emptyList()
                                        songTechniqueDialogOpen = false
                                        songTechniqueIds = emptyList()
                                        songTechniqueTrackIndex = -1
                                        songTechniqueScanning = false
                                        localScorePayload.set(null)
                                        activeGpFailoverRoute.set(null)
                                        pendingTabSongScript.set(null)
                                        webViewInstance?.evaluateJavascript("javascript:stopPlayer();", null)

                                        searchSongs(
                                            section = selectedMusicSection,
                                            rhythmOverride = selectedRhythm,
                                            folderOverride = selectedVietnamFolder,
                                            showNoResultsToast = false
                                        )
                                    }

                                    isInsideVietnamFolder -> {
                                        // Lui mot cap trong cay thu muc /tab/Vietnam.
                                        showParentVietnamFolder()
                                    }

                                    isInsideRhythmFolder -> {
                                        // Từ danh sách file của một điệu quay lại danh sách các điệu.
                                        showRhythmFolders()
                                    }

                                    else -> {
                                        // Đang ở danh sách gốc: thoát màn hình Bản nhạc.
                                        onClose()
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(46.dp)
                                .background(
                                    if (localIsDark) Color.Black else surfaceColor,
                                    RoundedCornerShape(12.dp)
                                )
                                .border(1.dp, Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        ) {
                            Icon(
                                imageVector = if (showBackButton) Icons.Default.ArrowBack else Icons.Default.Home,
                                contentDescription = if (showBackButton) "Quay lại" else "Trang chủ",
                                tint = if (localIsDark) Color.White else textColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        if (isViewingSong) {
                            // Khi đã chọn bài: ẩn ô tìm kiếm và thay bằng ô nhập BPM.
                            BasicTextField(
                                value = bpmText,
                                onValueChange = { rawValue ->
                                    bpmText = rawValue
                                        .filter { it.isDigit() }
                                        .take(3)
                                },
                                enabled = hasScore,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .background(
                                        if (localIsDark) Color.Black else surfaceColor,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (hasScore) {
                                            accentColor.copy(alpha = 0.65f)
                                        } else {
                                            Color.Gray.copy(alpha = 0.3f)
                                        },
                                        RoundedCornerShape(12.dp)
                                    )
                                    // Thu gọn phần đệm để ưu tiên không gian cho số BPM 3 chữ số.
                                    .padding(start = 4.dp, end = 2.dp),
                                textStyle = TextStyle(
                                    color = if (localIsDark) Color.White else textColor,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                ),
                                singleLine = true,
                                cursorBrush = SolidColor(
                                    if (localIsDark) Color.White else accentColor
                                ),
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { applyBpm() }
                                ),
                                decorationBox = { innerTextField ->
                                    Row(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.weight(1f),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (bpmText.isEmpty()) {
                                                Text(
                                                    text = if (isLoadingSong) "..." else "--",
                                                    color = Color.Gray.copy(alpha = 0.75f),
                                                    fontSize = 15.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            innerTextField()
                                        }

                                        Text(
                                            text = "BPM",
                                            color = if (hasScore) accentColor else Color.Gray,
                                            // Cỡ chữ vừa phải: dễ đọc hơn nhưng vẫn ưu tiên chỗ cho số BPM.
                                            fontSize = 7.sp,
                                            lineHeight = 7.sp,
                                            letterSpacing = (-0.25).sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            softWrap = false
                                        )

                                        IconButton(
                                            onClick = { applyBpm() },
                                            enabled = canApplyBpm,
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Áp dụng BPM",
                                                tint = if (canApplyBpm) {
                                                    accentColor
                                                } else {
                                                    Color.Gray.copy(alpha = 0.35f)
                                                },
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            )

                            // Chọn cách hiển thị: khuông + TAB, TAB hoặc Partition.
                            Box {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (localIsDark) Color.Black else surfaceColor
                                        )
                                        .border(
                                            1.dp,
                                            if (hasScore) {
                                                accentColor.copy(alpha = 0.55f)
                                            } else {
                                                Color.Gray.copy(alpha = 0.3f)
                                            },
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable(
                                            enabled = hasScore && !isExportingPdf
                                        ) {
                                            focusManager.clearFocus()
                                            draftShowScore = selectedDisplayMode.showScore
                                            draftShowTab = selectedDisplayMode.showTab
                                            draftInstrument = selectedDisplayMode.instrument
                                            draftShowNoteNames = showNoteNames
                                            displayModeMenuExpanded = true
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LibraryMusic,
                                            contentDescription = selectedDisplayMode.menuTitle(currentLang),
                                            tint = if (hasScore) {
                                                if (localIsDark) Color.White else accentColor
                                            } else {
                                                Color.Gray.copy(alpha = 0.4f)
                                            },
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = selectedDisplayMode.buttonLabel,
                                            color = if (hasScore) {
                                                if (localIsDark) Color.White else accentColor
                                            } else {
                                                Color.Gray.copy(alpha = 0.4f)
                                            },
                                            fontSize = 7.5.sp,
                                            lineHeight = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }

                                if (displayModeMenuExpanded) {
                                    val vi = currentLang.lowercase(Locale.ROOT).startsWith("vi")
                                    Dialog(
                                        onDismissRequest = {
                                            if (!displayConfigurationApplying) displayModeMenuExpanded = false
                                        },
                                        properties = DialogProperties(usePlatformDefaultWidth = false)
                                    ) {
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(0.92f)
                                                .widthIn(max = 420.dp)
                                                .heightIn(max = 600.dp),
                                            shape = RoundedCornerShape(22.dp),
                                            color = surfaceColor,
                                            shadowElevation = 14.dp
                                        ) {
                                            Column(
                                                modifier = Modifier.verticalScroll(rememberScrollState())
                                                    .padding(horizontal = 15.dp, vertical = 13.dp),
                                                verticalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier.size(34.dp)
                                                            .background(accentColor.copy(alpha = .12f), RoundedCornerShape(10.dp)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(Icons.Default.Tune, null,
                                                            tint = accentColor, modifier = Modifier.size(20.dp))
                                                    }
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            if (vi) "T\u00f9y ch\u1ec9nh hi\u1ec3n th\u1ecb" else "Display layout",
                                                            color = textColor, fontSize = 17.sp,
                                                            fontWeight = FontWeight.Bold, lineHeight = 21.sp
                                                        )
                                                        Text(
                                                            if (vi) "Ch\u1ea1m v\u00e0o th\u1ebb \u0111\u1ec3 ch\u1ecdn, sau \u0111\u00f3 nh\u1ea5n \u00c1p d\u1ee5ng" else "Tap an option, then press Apply",
                                                            color = textColor.copy(alpha = .65f), fontSize = 10.sp
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = { displayModeMenuExpanded = false },
                                                        enabled = !displayConfigurationApplying,
                                                        modifier = Modifier.size(32.dp)
                                                            .background(textColor.copy(alpha = .06f), CircleShape)
                                                    ) {
                                                        Icon(Icons.Default.Close,
                                                            if (vi) "\u0110\u00f3ng" else "Close",
                                                            tint = textColor, modifier = Modifier.size(19.dp))
                                                    }
                                                }
                                                HorizontalDivider(color = Color.Gray.copy(alpha = .18f))

                                                Text(
                                                    if (vi) "N\u1ed9i dung b\u1ea3n nh\u1ea1c" else "Score content",
                                                    color = textColor, fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    listOf(true, false).forEach { isScore ->
                                                        val checked = if (isScore) draftShowScore else draftShowTab
                                                        Surface(
                                                            modifier = Modifier.weight(1f).height(49.dp)
                                                                .clickable {
                                                                    if (isScore) {
                                                                        draftShowScore = !draftShowScore
                                                                        if (!draftShowScore && !draftShowTab) draftShowTab = true
                                                                    } else {
                                                                        draftShowTab = !draftShowTab
                                                                        if (!draftShowTab && !draftShowScore) draftShowScore = true
                                                                    }
                                                                },
                                                            shape = RoundedCornerShape(12.dp),
                                                            color = if (checked) accentColor.copy(alpha = .09f)
                                                            else textColor.copy(alpha = .035f),
                                                            border = androidx.compose.foundation.BorderStroke(
                                                                if (checked) 1.5.dp else 1.dp,
                                                                if (checked) accentColor else textColor.copy(alpha = .12f)
                                                            )
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.padding(horizontal = 7.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                                                            ) {
                                                                Checkbox(
                                                                    checked = checked,
                                                                    onCheckedChange = { value ->
                                                                        if (isScore) {
                                                                            draftShowScore = value
                                                                            if (!value && !draftShowTab) draftShowTab = true
                                                                        } else {
                                                                            draftShowTab = value
                                                                            if (!value && !draftShowScore) draftShowScore = true
                                                                        }
                                                                    },
                                                                    modifier = Modifier.size(34.dp)
                                                                )
                                                                Text(
                                                                    if (isScore) {
                                                                        if (vi) "Khu\u00f4ng nh\u1ea1c" else "Notation"
                                                                    } else "TAB",
                                                                    color = textColor, fontSize = 12.sp,
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                                                )
                                                            }
                                                        }
                                                    }
                                                }

                                                Text(
                                                    if (vi) "Nh\u1ea1c c\u1ee5 hi\u1ec3n th\u1ecb" else "Instrument panel",
                                                    color = textColor, fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    TabDisplayInstrument.values().forEach { instrument ->
                                                        val selected = draftInstrument == instrument
                                                        Surface(
                                                            modifier = Modifier.weight(1f).height(76.dp)
                                                                .clickable(
                                                                    role = androidx.compose.ui.semantics.Role.RadioButton,
                                                                    onClick = { draftInstrument = instrument }
                                                                ),
                                                            shape = RoundedCornerShape(13.dp),
                                                            color = if (selected) accentColor.copy(alpha = .11f)
                                                            else textColor.copy(alpha = .035f),
                                                            border = androidx.compose.foundation.BorderStroke(
                                                                if (selected) 1.7.dp else 1.dp,
                                                                if (selected) accentColor else textColor.copy(alpha = .12f)
                                                            )
                                                        ) {
                                                            Box(modifier = Modifier.fillMaxSize()) {
                                                                Column(
                                                                    modifier = Modifier.fillMaxSize().padding(5.dp),
                                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                                    verticalArrangement = Arrangement.Center
                                                                ) {
                                                                    if (instrument == TabDisplayInstrument.GUITAR) {
                                                                        SongTabCChordIcon(
                                                                            modifier = Modifier.size(40.dp),
                                                                            isDark = localIsDark,
                                                                            selected = selected,
                                                                            accentColor = accentColor
                                                                        )
                                                                    } else {
                                                                        Text(
                                                                            if (instrument == TabDisplayInstrument.PIANO) "\uD83C\uDFB9" else "\u2014",
                                                                            color = if (selected) accentColor else textColor,
                                                                            fontSize = 23.sp,
                                                                            lineHeight = 27.sp
                                                                        )
                                                                    }
                                                                    Text(
                                                                        when (instrument) {
                                                                            TabDisplayInstrument.NONE -> if (vi) "Kh\u00f4ng" else "None"
                                                                            TabDisplayInstrument.GUITAR -> "Guitar"
                                                                            TabDisplayInstrument.PIANO -> "Piano"
                                                                        },
                                                                        color = if (selected) accentColor else textColor,
                                                                        fontSize = 11.sp,
                                                                        fontWeight = FontWeight.Bold,
                                                                        maxLines = 1
                                                                    )
                                                                }
                                                                if (selected) {
                                                                    Box(
                                                                        modifier = Modifier.align(Alignment.TopEnd)
                                                                            .padding(top = 3.dp, end = 3.dp)
                                                                            .size(17.dp)
                                                                            .background(accentColor, CircleShape),
                                                                        contentAlignment = Alignment.Center
                                                                    ) {
                                                                        Icon(
                                                                            imageVector = Icons.Default.Check,
                                                                            contentDescription = null,
                                                                            tint = Color.White,
                                                                            modifier = Modifier.size(12.dp)
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                Row(
                                                    modifier = Modifier.fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(
                                                            if (draftShowNoteNames) accentColor.copy(alpha = .055f)
                                                            else textColor.copy(alpha = .025f)
                                                        )
                                                        .border(
                                                            1.dp,
                                                            if (draftShowNoteNames) accentColor.copy(alpha = .35f)
                                                            else textColor.copy(alpha = .13f),
                                                            RoundedCornerShape(12.dp)
                                                        )
                                                        .clickable { draftShowNoteNames = !draftShowNoteNames }
                                                        .padding(horizontal = 11.dp, vertical = 5.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            if (vi) "Hiện tên nốt" else "Show note names",
                                                            color = textColor, fontSize = 12.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                        Text(
                                                            if (vi) "Tên nốt trên khuông nhạc / TAB"
                                                            else "Note labels on notation / TAB",
                                                            color = textColor.copy(alpha = .60f), fontSize = 10.sp,
                                                            lineHeight = 13.sp
                                                        )
                                                    }
                                                    Switch(
                                                        checked = draftShowNoteNames,
                                                        onCheckedChange = { draftShowNoteNames = it },
                                                        modifier = Modifier.height(37.dp)
                                                    )
                                                }

                                                val previewMode = TabDisplayMode.fromSelection(
                                                    draftShowScore, draftShowTab, draftInstrument
                                                )
                                                Surface(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = accentColor.copy(alpha = .09f)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(11.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Icon(Icons.Default.Check, null, tint = accentColor,
                                                            modifier = Modifier.size(20.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                if (vi) "Xem tr\u01b0\u1edbc" else "Preview",
                                                                color = accentColor, fontSize = 10.sp,
                                                                fontWeight = FontWeight.Medium
                                                            )
                                                            Text(previewMode.menuTitle(currentLang),
                                                                color = textColor, fontSize = 12.sp,
                                                                fontWeight = FontWeight.Bold, maxLines = 2,
                                                                lineHeight = 16.sp)
                                                            if (draftInstrument == TabDisplayInstrument.PIANO && draftShowTab) {
                                                                Text(
                                                                    if (vi) "TAB GP g\u1ed1c \u2022 Piano chia tay g\u1ee3i \u00fd"
                                                                    else "Original GP TAB \u2022 suggested Piano hands",
                                                                    color = textColor.copy(alpha = .67f),
                                                                    fontSize = 10.sp, lineHeight = 13.sp
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                                    OutlinedButton(
                                                        onClick = { displayModeMenuExpanded = false },
                                                        enabled = !displayConfigurationApplying,
                                                        modifier = Modifier.weight(1f).height(43.dp)
                                                    ) { Text(if (vi) "H\u1ee7y" else "Cancel", fontSize = 13.sp) }
                                                    Button(
                                                        onClick = { applyDisplaySelection() },
                                                        enabled = !displayConfigurationApplying && hasScore && !isExportingPdf,
                                                        modifier = Modifier.weight(1f).height(43.dp)
                                                    ) {
                                                        Icon(Icons.Default.Check, null, modifier = Modifier.size(17.dp))
                                                        Spacer(Modifier.width(4.dp))
                                                        Text(if (vi) "\u00c1p d\u1ee5ng" else "Apply", fontSize = 13.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                            }

                            // Xuất track đang hiển thị thành PDF A4.
                            IconButton(
                                onClick = { requestPdfExport() },
                                enabled = hasScore && !isExportingPdf,
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(
                                        if (localIsDark) Color.Black else surfaceColor,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (hasScore) {
                                            accentColor.copy(alpha = 0.55f)
                                        } else {
                                            Color.Gray.copy(alpha = 0.3f)
                                        },
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                if (isExportingPdf) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(19.dp),
                                        color = if (localIsDark) Color.White else accentColor,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.PictureAsPdf,
                                        contentDescription = "Xuất PDF A4",
                                        tint = if (hasScore) {
                                            if (localIsDark) Color.White else accentColor
                                        } else {
                                            Color.Gray.copy(alpha = 0.4f)
                                        },
                                        modifier = Modifier.size(23.dp)
                                    )
                                }
                            }
                        } else {
                            // Khi đang ở danh sách: hiển thị ô tìm kiếm như cũ.
                            BasicTextField(
                                value = currentSearchText,
                                onValueChange = { searchQueries[selectedMusicSection] = it },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .background(
                                        if (localIsDark) Color.Black else surfaceColor,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(1.dp, Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                    .onFocusChanged { focusState ->
                                        if (focusState.isFocused) {
                                            hideExtraButtons = true
                                        }
                                    }
                                    .padding(horizontal = 12.dp),
                                textStyle = TextStyle(
                                    color = if (localIsDark) Color.White else textColor,
                                    fontSize = 15.sp
                                ),
                                singleLine = true,
                                cursorBrush = SolidColor(if (localIsDark) Color.White else accentColor),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(
                                    onSearch = { searchSongs(section = selectedMusicSection) }
                                ),
                                decorationBox = { innerTextField ->
                                    Row(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(modifier = Modifier.weight(1f)) {
                                            if (currentSearchText.isEmpty()) {
                                                Text(
                                                    currentSearchHint,
                                                    color = Color.Gray.copy(alpha = 0.8f),
                                                    fontSize = 14.sp
                                                )
                                            }
                                            innerTextField()
                                        }
                                        if (currentSearchText.isNotEmpty()) {
                                            IconButton(
                                                onClick = {
                                                    searchQueries[selectedMusicSection] = ""
                                                    searchSongs(
                                                        section = selectedMusicSection,
                                                        queryOverride = "",
                                                        showNoResultsToast = false
                                                    )
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Close,
                                                    contentDescription = "Xóa",
                                                    tint = Color.Gray,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        } else {
                                            IconButton(
                                                onClick = {
                                                    try {
                                                        val intent = android.content.Intent(
                                                            android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH
                                                        ).apply {
                                                            putExtra(
                                                                android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                                                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                                            )
                                                            putExtra(
                                                                android.speech.RecognizerIntent.EXTRA_LANGUAGE,
                                                                if (selectedMusicSection == MusicLibrarySection.QUOC_TE) {
                                                                    "en-US"
                                                                } else {
                                                                    "vi-VN"
                                                                }
                                                            )
                                                            putExtra(
                                                                android.speech.RecognizerIntent.EXTRA_PROMPT,
                                                                currentSearchHint
                                                            )
                                                        }
                                                        speechLauncher.launch(intent)
                                                    } catch (_: Exception) {
                                                        Toast.makeText(
                                                            context,
                                                            "Thiết bị không hỗ trợ giọng nói",
                                                            Toast.LENGTH_SHORT
                                                        ).show()
                                                    }
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Mic,
                                                    contentDescription = "Giọng nói",
                                                    tint = accentColor,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            )

                            // Không cần nút tìm riêng vì bàn phím đã có phím Search.
                            // Vị trí này dùng để mở file GP trong thư mục của điện thoại.
                            IconButton(
                                onClick = {
                                    focusManager.clearFocus()
                                    localFileLauncher.launch(SUPPORTED_GP_MIME_TYPES)
                                },
                                enabled = !isImportingLocalFile && !isLoadingSong,
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(
                                        if (localIsDark) Color.Black else surfaceColor,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        1.dp,
                                        Color.Gray.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                if (isImportingLocalFile) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(19.dp),
                                        color = if (localIsDark) Color.White else accentColor,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.FolderOpen,
                                        contentDescription = "Chọn file GP trong máy",
                                        tint = if (localIsDark) Color.White else accentColor,
                                        modifier = Modifier.size(23.dp)
                                    )
                                }
                            }
                        }

                        // CÁC NÚT BÊN PHẢI (Ẩn/Hiện khi Focus vào ô tìm kiếm và CẦN tab nhạc đã hiển thị)
                        if (!hideExtraButtons && hasScore) {
                            // Mở bảng chọn theme và màu hiển thị chi tiết.
                            IconButton(
                                onClick = { showAppearanceSettings = true },
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(
                                        if (localIsDark) Color.Black else surfaceColor,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        1.dp,
                                        Color.Gray.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Icon(
                                    imageVector = if (localIsDark) {
                                        Icons.Default.LightMode
                                    } else {
                                        Icons.Default.DarkMode
                                    },
                                    contentDescription = soundFontText(
                                        "tab_appearance_settings",
                                        currentLang,
                                        "Tùy chỉnh hiển thị",
                                        "Display customization"
                                    ),
                                    tint = tabAppearanceComposeColor(appearanceCursorHex),
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            // NÚT XOAY MÀN HÌNH
                            IconButton(
                                onClick = {
                                    isLandscape = !isLandscape
                                    activity?.requestedOrientation = if (isLandscape) {
                                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    }
                                },
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(
                                        if (localIsDark) Color.Black else surfaceColor,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        1.dp,
                                        Color.Gray.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ScreenRotation,
                                    contentDescription = "Xoay màn hình",
                                    tint = if (localIsDark) Color.White else textColor,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                } // <--- ĐÓNG THẺ AnimatedVisibility

                // --- 3 NHÓM NỘI DUNG: NHẠC VIỆT / QUỐC TẾ / ĐIỆU NHẠC ---
                androidx.compose.animation.AnimatedVisibility(
                    visible = !isViewingSong && !(isLandscape && isPlaying),
                    enter = androidx.compose.animation.expandVertically() +
                            androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.shrinkVertically() +
                            androidx.compose.animation.fadeOut()
                ) {
                    MusicLibraryTabs(
                        selectedSection = selectedMusicSection,
                        currentLang = currentLang,
                        isDark = localIsDark,
                        accentColor = accentColor,
                        onSectionSelected = { selectMusicSection(it) }
                    )
                }

                // Hien thi vi tri hien tai khi dang o trong thu muc Nhac Viet hoac Dieu nhac.
                androidx.compose.animation.AnimatedVisibility(
                    visible = !isViewingSong &&
                            (isInsideVietnamFolder || isInsideRhythmFolder),
                    enter = androidx.compose.animation.expandVertically() +
                            androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.shrinkVertically() +
                            androidx.compose.animation.fadeOut()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(accentColor.copy(alpha = 0.10f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = currentFolderRootTitle,
                            color = Color.Gray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "  ›  ",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                        Text(
                            text = currentFolderPathTitle,
                            color = textColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // --- KHUNG HIỂN THỊ CHÍNH ---
                // Measure the actual score viewport; do not depend on
                // BoxWithConstraintsScope (reported as unused by the IDE).
                var scoreViewportSize by remember { mutableStateOf(IntSize.Zero) }
                val scoreViewportDensity = LocalDensity.current
                val zoomScoreRightInset = with(scoreViewportDensity) {
                    val fretboardOnRight =
                        selectedDisplayMode.hasInstrumentPanel &&
                                scoreViewportSize.width > 0 && scoreViewportSize.height > 0 &&
                                scoreViewportSize.width >= scoreViewportSize.height * 1.28f
                    if (fretboardOnRight) {
                        scoreViewportSize.width.toDp() * 0.47f + 8.dp
                    } else {
                        8.dp
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .onSizeChanged { newSize ->
                            if (scoreViewportSize != newSize) scoreViewportSize = newSize
                        }
                ) {
                    // 1. LỚP DƯỚI CÙNG: WEBVIEW BẢN NHẠC
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = {
                            // Tháo WebView khỏi parent cũ (nếu có) trước khi gắn vào View mới của Dialog
                            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
                            webView
                        },
                        update = { target -> syncTabViewport(target) }
                    )

                    // Zoom khuong/TAB: mini control phia tren, khong thu nho SVG can dan.
                    // 82% la scale goc cua S+T+F; khi chon thu cong thi giu chung
                    // scale do giua cac che do. Ve score bang AlphaTab, khong CSS transform.
                    if (hasScore && songs.isEmpty() && !isExportingPdf &&
                        (scoreZoomControlVisible || scoreZoomMenuExpanded)) {
                        val effectiveZoom = if (scoreZoomPinchActive &&
                            scoreZoomPinchPreviewPercent >= 0) {
                            scoreZoomPinchPreviewPercent
                        } else if (customScoreZoomPercent >= 0) {
                            customScoreZoomPercent
                        } else if (selectedDisplayMode.hasInstrumentPanel) {
                            82
                        } else {
                            100
                        }
                        val zoomLabel = soundFontText(
                            "tab_zoom_label", currentLang, "Thu/phóng TAB", "Notation zoom"
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 4.dp, end = zoomScoreRightInset)
                                .zIndex(8f)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (localIsDark) Color(0xF2212530) else Color(0xF9FFFFFF),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp, accentColor.copy(alpha = 0.35f)
                                ),
                                shadowElevation = 3.dp
                            ) {
                                Row(
                                    modifier = Modifier.height(34.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(width = 30.dp, height = 34.dp)
                                            .clickable(enabled = effectiveZoom > TAB_SCORE_ZOOM_MIN) {
                                                setScoreZoomPercent(effectiveZoom - 10)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "−", fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (effectiveZoom > TAB_SCORE_ZOOM_MIN)
                                                textColor else Color.Gray
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .width(52.dp).height(34.dp)
                                            .clickable {
                                                scoreZoomSliderDraft = effectiveZoom.toFloat()
                                                scoreZoomMenuExpanded = true
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "$effectiveZoom%",
                                            color = accentColor,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(width = 30.dp, height = 34.dp)
                                            .clickable(enabled = effectiveZoom < TAB_SCORE_ZOOM_MAX) {
                                                setScoreZoomPercent(effectiveZoom + 10)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "+", fontSize = 19.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (effectiveZoom < TAB_SCORE_ZOOM_MAX)
                                                textColor else Color.Gray
                                        )
                                    }
                                }
                            }
                            DropdownMenu(
                                expanded = scoreZoomMenuExpanded,
                                onDismissRequest = { scoreZoomMenuExpanded = false },
                                modifier = Modifier
                                    .width(270.dp)
                                    .background(surfaceColor)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                    Text(
                                        text = zoomLabel,
                                        color = textColor,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "${scoreZoomSliderDraft.roundToInt()}%",
                                            color = accentColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text(
                                            text = "50–150%",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Slider(
                                        value = scoreZoomSliderDraft,
                                        onValueChange = { scoreZoomSliderDraft =
                                            (it / 5f).roundToInt().times(5).toFloat()
                                                .coerceIn(50f, 150f)
                                        },
                                        onValueChangeFinished = {
                                            setScoreZoomPercent(scoreZoomSliderDraft.roundToInt())
                                        },
                                        valueRange = 50f..150f,
                                        steps = 19,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        listOf(60, 80, 100, 120).forEach { preset ->
                                            Text(
                                                text = "$preset%",
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(7.dp))
                                                    .clickable {
                                                        scoreZoomSliderDraft = preset.toFloat()
                                                        setScoreZoomPercent(preset)
                                                    }
                                                    .padding(horizontal = 7.dp, vertical = 6.dp),
                                                color = if (effectiveZoom == preset) accentColor else textColor,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    HorizontalDivider(color = Color.Gray.copy(alpha = 0.15f))
                                    Text(
                                        text = soundFontText(
                                            "tab_zoom_reset", currentLang,
                                            "Khôi phục mức mặc định", "Reset to default size"
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                setScoreZoomPercent(-1)
                                                scoreZoomSliderDraft = if (
                                                    selectedDisplayMode.hasInstrumentPanel
                                                ) 82f else 100f
                                            }
                                            .padding(vertical = 10.dp),
                                        color = accentColor,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = soundFontText(
                                            "tab_zoom_board_unchanged", currentLang,
                                            "Chỉ thu/phóng khuông nhạc và TAB; cần đàn giữ nguyên.",
                                            "Only notation and TAB zoom; fretboard stays the same size."
                                        ),
                                        color = Color.Gray,
                                        fontSize = 10.sp,
                                        lineHeight = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    // LỚP TRUNG GIAN 1: TRẠNG THÁI ĐANG TẢI / CHƯA CÓ DỮ LIỆU
                    val showCurrentSongList = songs.isNotEmpty()

                    if (!hasScore && !isLoadingSong && !showCurrentSongList) {
                        val vietnamFolderName = selectedVietnamFolder
                            .substringAfterLast('/')
                            .ifBlank { "Vietnam" }
                        val emptyTitle = when {
                            isSearching ->
                                "Đang tải danh sách..."

                            selectedMusicSection == MusicLibrarySection.DIEU_NHAC &&
                                    selectedRhythm != null &&
                                    currentSearchText.isNotBlank() ->
                                "Không tìm thấy bản Tab"

                            selectedMusicSection == MusicLibrarySection.DIEU_NHAC &&
                                    selectedRhythm != null ->
                                "Chưa có bản Tab trong ${selectedRhythm.orEmpty()}"

                            selectedMusicSection == MusicLibrarySection.NHAC_VIET &&
                                    selectedVietnamFolder.isNotBlank() &&
                                    currentSearchText.isNotBlank() ->
                                "Không tìm thấy bản Tab"

                            selectedMusicSection == MusicLibrarySection.NHAC_VIET &&
                                    selectedVietnamFolder.isNotBlank() ->
                                "Thư mục $vietnamFolderName đang trống"

                            currentSearchText.isNotBlank() ->
                                "Không tìm thấy nội dung"

                            else -> selectedMusicSection.emptyTitle(currentLang)
                        }
                        val emptyMessage = when {
                            isSearching ->
                                "Vui lòng chờ trong giây lát."

                            selectedMusicSection == MusicLibrarySection.DIEU_NHAC &&
                                    selectedRhythm != null &&
                                    currentSearchText.isNotBlank() ->
                                "Hãy thử tên file khác trong điệu ${selectedRhythm.orEmpty()}."

                            selectedMusicSection == MusicLibrarySection.DIEU_NHAC &&
                                    selectedRhythm != null ->
                                "Thư mục này chưa có file GP3, GP4, GP5, GPX hoặc GP."

                            selectedMusicSection == MusicLibrarySection.NHAC_VIET &&
                                    selectedVietnamFolder.isNotBlank() &&
                                    currentSearchText.isNotBlank() ->
                                "Hãy thử tên file khác trong thư mục $vietnamFolderName."

                            selectedMusicSection == MusicLibrarySection.NHAC_VIET &&
                                    selectedVietnamFolder.isNotBlank() ->
                                "Thư mục này chưa có thư mục con hoặc file GP được hỗ trợ."

                            currentSearchText.isNotBlank() ->
                                "Hãy thử từ khóa khác hoặc kiểm tra lại nội dung tìm kiếm."

                            else -> selectedMusicSection.emptyMessage(currentLang)
                        }

                        Column(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(horizontal = 32.dp, vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (isSearching) {
                                // Giữ đúng một kiểu loading từ lúc kiểm tra quyền cho tới khi
                                // danh sách đầu tiên trả về. Không hiển thị thêm vòng tròn hay
                                // dòng "Đang tải danh sách..." để tránh cảm giác chạy 2 tiến trình.
                                SongTabLoadingWave(color = Color(0xFF15B27D))
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(accentColor.copy(alpha = 0.10f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (
                                            selectedMusicSection == MusicLibrarySection.DIEU_NHAC ||
                                            selectedMusicSection == MusicLibrarySection.NHAC_VIET
                                        ) {
                                            Icons.Default.FolderOpen
                                        } else {
                                            Icons.Default.LibraryMusic
                                        },
                                        contentDescription = null,
                                        tint = accentColor.copy(alpha = 0.82f),
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = emptyTitle,
                                    color = textColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = emptyMessage,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // LỚP TRUNG GIAN 2: THANH CÔNG CỤ KÉO THẢ
                    if (tracks.isNotEmpty() && hasScore && songs.isEmpty()) {
                        Card(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                                // Chế độ cần đàn chừa vùng dưới cùng cho bộ điều khiển,
                                // không để thanh Play che các vị trí nốt trên dây.
                                .padding(
                                    bottom = if (selectedDisplayMode.hasInstrumentPanel) {
                                        8.dp
                                    } else {
                                        40.dp
                                    }
                                )
                                .zIndex(10f)
                                // Giữ thanh điều khiển đủ rõ để bật/tắt metronome lúc Play.
                                .alpha(
                                    if (
                                        isPlaying &&
                                        !selectedDisplayMode.hasInstrumentPanel
                                    ) 0.75f else 1f
                                )
                                .pointerInput(selectedDisplayMode) {
                                    // Ở S+T+F, khóa thanh điều khiển tại đáy để bố cục
                                    // TAB → cần đàn → Play luôn ổn định, không bị kéo lệch.
                                    if (!selectedDisplayMode.hasInstrumentPanel) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            offsetX += dragAmount.x
                                            offsetY += dragAmount.y
                                        }
                                    }
                                },
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = if (localIsDark) Color.Black else surfaceColor),
                            border = if (localIsDark) androidx.compose.foundation.BorderStroke(
                                1.dp,
                                Color.Gray.copy(alpha = 0.3f)
                            ) else null,
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box {
                                    OutlinedButton(
                                        onClick = { trackMenuExpanded = true },
                                        modifier = Modifier.height(40.dp),
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (localIsDark) Color.Black else Color.Transparent,
                                            contentColor = if (localIsDark) Color.White else textColor
                                        ),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            Color.Gray.copy(alpha = 0.3f)
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.LibraryMusic,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = tracks.getOrNull(selectedTrackIndex)?.name
                                                ?: "N/A",
                                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.widthIn(max = 90.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = trackMenuExpanded,
                                        onDismissRequest = { trackMenuExpanded = false },
                                        modifier = Modifier.background(surfaceColor)
                                    ) {
                                        tracks.forEachIndexed { index, track ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = track.name,
                                                        color = textColor
                                                    )
                                                },
                                                onClick = {
                                                    trackMenuExpanded = false
                                                    selectTrack(index)
                                                }
                                            )
                                        }
                                    }
                                }

                                Box {
                                    IconButton(
                                        onClick = { soundFontMenuExpanded = true },
                                        enabled = !isPlaying,
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(
                                                if (localIsDark) Color.Black else Color.Transparent,
                                                CircleShape
                                            )
                                            .border(
                                                1.dp,
                                                Color.Gray.copy(alpha = 0.3f),
                                                CircleShape
                                            )
                                    ) {
                                        if (downloadingSoundFontMode != null || isSwitchingSoundFont) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(18.dp),
                                                color = if (localIsDark) Color.White else accentColor,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.VolumeUp,
                                                contentDescription = soundFontText(
                                                    "tab_sound_choose", currentLang,
                                                    "Chọn âm thanh TAB", "Choose TAB audio"
                                                ),
                                                tint = if (
                                                    activeSoundFontMode.isDownloadable
                                                ) {
                                                    accentColor
                                                } else {
                                                    if (localIsDark) Color.White else textColor
                                                },
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = soundFontMenuExpanded,
                                        onDismissRequest = { soundFontMenuExpanded = false },
                                        modifier = Modifier
                                            .widthIn(min = 300.dp, max = 350.dp)
                                            .background(surfaceColor)
                                    ) {
                                        Text(
                                            text = if (selectedDisplayMode.instrument == TabDisplayInstrument.PIANO) {
                                                soundFontText("tab_sound_piano_title", currentLang,
                                                    "Âm thanh Piano", "Piano sound")
                                            } else {
                                                soundFontText("tab_sound_menu_title", currentLang,
                                                    "Âm thanh TAB", "TAB audio")
                                            },
                                            color = textColor,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(
                                                start = 16.dp,
                                                end = 16.dp,
                                                top = 10.dp,
                                                bottom = 6.dp
                                            )
                                        )

                                        // Checkbox hoạt động như lựa chọn đơn: luôn chỉ có một cấu hình được chọn.
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable(
                                                    enabled = !isSwitchingSoundFont &&
                                                            downloadingSoundFontMode == null
                                                ) {
                                                    switchSoundFontMode(TabSoundFontMode.STANDARD)
                                                }
                                                .padding(horizontal = 10.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Checkbox(
                                                checked = activeSoundFontMode == TabSoundFontMode.STANDARD,
                                                onCheckedChange = { checked ->
                                                    if (checked) {
                                                        switchSoundFontMode(TabSoundFontMode.STANDARD)
                                                    }
                                                },
                                                enabled = !isSwitchingSoundFont &&
                                                        downloadingSoundFontMode == null,
                                                colors = CheckboxDefaults.colors(
                                                    checkedColor = accentColor,
                                                    checkmarkColor = Color.White,
                                                    uncheckedColor = textColor.copy(alpha = 0.48f)
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(5.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = TabSoundFontMode.STANDARD.menuTitle(currentLang),
                                                    color = textColor,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = TabSoundFontMode.STANDARD.menuDescription(currentLang),
                                                    color = Color.Gray,
                                                    fontSize = 11.sp,
                                                    lineHeight = 14.sp
                                                )
                                            }
                                        }

                                        HorizontalDivider(
                                            color = Color.Gray.copy(alpha = 0.18f),
                                            modifier = Modifier.padding(horizontal = 12.dp)
                                        )

                                        // FluidR3 SF2 remains available for Guitar, but not for Piano.
                                        val visibleSoundFontModes = if (
                                            selectedDisplayMode.instrument == TabDisplayInstrument.PIANO
                                        ) {
                                            listOf(TabSoundFontMode.MUSESCORE)
                                        } else {
                                            downloadableSoundFontModes
                                        }
                                        visibleSoundFontModes.forEachIndexed { index, mode ->
                                            val info = soundFontInfos[mode]
                                            val completeFile = soundFontFiles.getValue(mode)
                                            val isDownloaded = downloadedSoundFontModes[mode] == true
                                            val hasLocalData = localSoundFontDataModes[mode] == true
                                            val isDownloading = downloadingSoundFontMode == mode
                                            val sizeBytes = when {
                                                info?.sizeBytes ?: 0L > 0L -> info?.sizeBytes ?: 0L
                                                completeFile.isFile -> completeFile.length()
                                                else -> 0L
                                            }
                                            val subtitle = when {
                                                isDownloading -> {
                                                    val progress = soundFontDownloadProgressByMode[mode] ?: 0f
                                                    val percent = (progress * 100f)
                                                        .roundToInt()
                                                        .coerceIn(0, 100)
                                                    soundFontFormat(
                                                        "tab_sound_downloading_progress", currentLang,
                                                        "Đang tải %1\$d%% · %2\$s / %3\$s",
                                                        "Downloading %1\$d%% · %2\$s / %3\$s",
                                                        percent,
                                                        formatStorageSize(
                                                            soundFontDownloadedBytesByMode[mode] ?: 0L
                                                        ),
                                                        formatStorageSize(sizeBytes)
                                                    )
                                                }
                                                isDownloaded -> soundFontFormat(
                                                    "tab_sound_downloaded_storage", currentLang,
                                                    "Đã tải · dung lượng app tăng khoảng %1\$s",
                                                    "Downloaded · app storage increased by about %1\$s",
                                                    mode.estimatedAppIncreaseText
                                                )
                                                hasLocalData -> soundFontText(
                                                    "tab_sound_incomplete_continue", currentLang,
                                                    "Tải chưa hoàn tất · nhấn để tiếp tục",
                                                    "Download incomplete · tap to continue"
                                                )
                                                else -> soundFontFormat(
                                                    "tab_sound_increase_storage", currentLang,
                                                    "Tăng dung lượng app lên khoảng %1\$s",
                                                    "Increases app storage by about %1\$s",
                                                    mode.estimatedAppIncreaseText
                                                )
                                            }

                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(
                                                        start = 8.dp,
                                                        end = 6.dp,
                                                        top = 5.dp,
                                                        bottom = 5.dp
                                                    ),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .clickable(
                                                            enabled = !isSwitchingSoundFont &&
                                                                    downloadingSoundFontMode == null
                                                        ) {
                                                            if (isDownloaded) {
                                                                switchSoundFontMode(mode)
                                                            } else {
                                                                startSoundFontDownload(mode)
                                                            }
                                                        }
                                                        .padding(vertical = 3.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Checkbox(
                                                        checked = activeSoundFontMode == mode,
                                                        onCheckedChange = { checked ->
                                                            if (checked) {
                                                                if (isDownloaded) {
                                                                    switchSoundFontMode(mode)
                                                                } else {
                                                                    startSoundFontDownload(mode)
                                                                }
                                                            }
                                                        },
                                                        enabled = !isSwitchingSoundFont &&
                                                                downloadingSoundFontMode == null,
                                                        colors = CheckboxDefaults.colors(
                                                            checkedColor = accentColor,
                                                            checkmarkColor = Color.White,
                                                            uncheckedColor = textColor.copy(alpha = 0.48f)
                                                        )
                                                    )
                                                    Spacer(modifier = Modifier.width(5.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = mode.menuTitle(currentLang),
                                                            color = textColor,
                                                            fontSize = 14.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                        Text(
                                                            text = subtitle,
                                                            color = if (isDownloaded) {
                                                                accentColor.copy(alpha = 0.86f)
                                                            } else {
                                                                Color.Gray
                                                            },
                                                            fontSize = 10.sp,
                                                            lineHeight = 13.sp
                                                        )
                                                    }
                                                }

                                                when {
                                                    isDownloading -> {
                                                        CircularProgressIndicator(
                                                            modifier = Modifier.size(21.dp),
                                                            color = accentColor,
                                                            strokeWidth = 2.dp
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                    }
                                                    hasLocalData -> {
                                                        IconButton(
                                                            onClick = { deleteSoundFont(mode) },
                                                            enabled = downloadingSoundFontMode == null,
                                                            modifier = Modifier.size(36.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Delete,
                                                                contentDescription = soundFontFormat(
                                                                    "tab_sound_delete", currentLang,
                                                                    "Xóa %1\$s", "Delete %1\$s",
                                                                    mode.menuTitle(currentLang)
                                                                ),
                                                                tint = Color(0xFFEF5350),
                                                                modifier = Modifier.size(20.dp)
                                                            )
                                                        }
                                                    }
                                                    else -> {
                                                        Icon(
                                                            imageVector = Icons.Default.Download,
                                                            contentDescription = null,
                                                            tint = accentColor,
                                                            modifier = Modifier
                                                                .padding(end = 8.dp)
                                                                .size(19.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            soundFontInfoErrors[mode]
                                                ?.takeIf { it.isNotBlank() }
                                                ?.let { errorText ->
                                                    Text(
                                                        text = errorText,
                                                        color = Color(0xFFEF5350),
                                                        fontSize = 10.sp,
                                                        lineHeight = 13.sp,
                                                        modifier = Modifier.padding(
                                                            start = 52.dp,
                                                            end = 16.dp,
                                                            bottom = 6.dp
                                                        )
                                                    )
                                                }

                                            if (index < visibleSoundFontModes.lastIndex) {
                                                HorizontalDivider(
                                                    color = Color.Gray.copy(alpha = 0.13f),
                                                    modifier = Modifier.padding(horizontal = 12.dp)
                                                )
                                            }
                                        }

                                        if (
                                            isSwitchingSoundFont ||
                                            (soundFontDecodeProgress in 0.001f..0.999f)
                                        ) {
                                            Text(
                                                text = soundFontFormat(
                                                    "tab_sound_prepare_progress", currentLang,
                                                    "Đang chuẩn bị bộ âm thanh %1\$d%%",
                                                    "Preparing audio pack %1\$d%%",
                                                    (soundFontDecodeProgress * 100f)
                                                        .roundToInt()
                                                        .coerceIn(0, 100)
                                                ),
                                                color = Color.Gray,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(
                                                    horizontal = 16.dp,
                                                    vertical = 6.dp
                                                )
                                            )
                                        }
                                    }
                                }

                                // Metronome bật/tắt trong lúc phát; nhịp gõ lấy từ MIDI của
                                // alphaTab nên tự khớp với tempo và số chỉ nhịp của bản GP.
                                val metronomeAction = soundFontText(
                                    if (metronomeEnabled) "tab_metronome_turn_off" else "tab_metronome_turn_on",
                                    currentLang,
                                    if (metronomeEnabled) "Tắt máy đếm nhịp" else "Bật máy đếm nhịp",
                                    if (metronomeEnabled) "Turn off metronome" else "Turn on metronome"
                                )
                                IconButton(
                                    onClick = { setMetronomeEnabled(!metronomeEnabled) },
                                    enabled = hasScore && !isExportingPdf,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (metronomeEnabled) accentColor.copy(alpha = 0.22f)
                                            else if (localIsDark) Color.Black else Color.Transparent,
                                            CircleShape
                                        )
                                        .border(
                                            1.dp,
                                            if (metronomeEnabled) accentColor
                                            else Color.Gray.copy(alpha = 0.3f),
                                            CircleShape
                                        )
                                        .semantics { contentDescription = metronomeAction }
                                ) {
                                    SongTabMetronomeIcon(
                                        modifier = Modifier.size(21.dp),
                                        color = if (metronomeEnabled) accentColor
                                        else if (localIsDark) Color.White else textColor
                                    )
                                }

                                Button(
                                    onClick = {
                                        webViewInstance?.evaluateJavascript(
                                            "javascript:playPause();",
                                            null
                                        )
                                    },
                                    enabled = isPlayerReady &&
                                            !isCheckingSoundFontCompatibility &&
                                            !isSwitchingSoundFont,
                                    shape = RoundedCornerShape(20.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isPlaying) Color(0xFFE53935) else accentColor
                                    ),
                                    modifier = Modifier.height(40.dp).widthIn(min = 100.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    if (isCheckingSoundFontCompatibility) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(17.dp),
                                            color = Color.White,
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        when {
                                            isCheckingSoundFontCompatibility -> soundFontText(
                                                "tab_sound_checking_compatibility", currentLang,
                                                "Đang kiểm tra...", "Checking..."
                                            )
                                            isPlaying -> "Pause"
                                            else -> "Play"
                                        },
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // LỚP TRÊN CÙNG: DANH SÁCH THEO TAB ĐANG CHỌN
                    if (showCurrentSongList) {
                        Card(
                            modifier = Modifier.fillMaxSize(),
                            colors = CardDefaults.cardColors(containerColor = bgColor),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(
                                    items = songs,
                                    key = { "${it.itemType}|${it.id}|${it.fileUrl}|${it.rhythm}|${it.folderPath}" }
                                ) { song ->
                                    val isRhythmSection =
                                        selectedMusicSection == MusicLibrarySection.DIEU_NHAC
                                    val isVietnamSection =
                                        selectedMusicSection == MusicLibrarySection.NHAC_VIET
                                    val isFolder = song.isFolder

                                    // Chỉ tìm ảnh iTunes cho danh sách bài hát thông thường.
                                    // Thư mục/file Điệu nhạc dùng icon cục bộ để tránh gọi mạng thừa.
                                    var thumbnailUrl by remember(song.id) { mutableStateOf("") }
                                    LaunchedEffect(song.id, isRhythmSection, isFolder) {
                                        thumbnailUrl = if (!isRhythmSection && !isFolder) {
                                            getITunesThumbnail(song.title, song.artist)
                                        } else {
                                            ""
                                        }
                                    }

                                    val itemSubtitle = when {
                                        isFolder && isVietnamSection ->
                                            "Chọn để mở thư mục"

                                        isFolder ->
                                            "Chọn để xem các file Guitar Pro"

                                        isRhythmSection -> {
                                            val details = mutableListOf<String>()
                                            song.format
                                                .takeIf { it.isNotBlank() && it != "folder" }
                                                ?.uppercase(Locale.ROOT)
                                                ?.let(details::add)

                                            song.subfolder
                                                .takeIf { it.isNotBlank() }
                                                ?.let(details::add)

                                            if (details.size < 2) {
                                                song.artist
                                                    .takeIf { it.isNotBlank() }
                                                    ?.let(details::add)
                                            }

                                            details.distinct().joinToString(" • ")
                                                .ifBlank { "Bản Tab điệu ${selectedRhythm.orEmpty()}" }
                                        }

                                        isVietnamSection -> {
                                            val details = mutableListOf<String>()
                                            song.format
                                                .takeIf { it.isNotBlank() && it != "folder" }
                                                ?.uppercase(Locale.ROOT)
                                                ?.let(details::add)

                                            song.subfolder
                                                .takeIf { it.isNotBlank() }
                                                ?.split('/')
                                                ?.lastOrNull()
                                                ?.takeIf { it.isNotBlank() }
                                                ?.let(details::add)

                                            if (details.size < 2) {
                                                song.artist
                                                    .takeIf { it.isNotBlank() }
                                                    ?.let(details::add)
                                            }

                                            details.distinct().joinToString(" • ")
                                                .ifBlank { "Nhạc Việt" }
                                        }

                                        else -> song.artist
                                    }

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(surfaceColor)
                                            .clickable(enabled = !isLoadingSong && !isSearching) {
                                                if (isFolder) {
                                                    when (selectedMusicSection) {
                                                        MusicLibrarySection.NHAC_VIET ->
                                                            openVietnamFolder(song)
                                                        MusicLibrarySection.DIEU_NHAC ->
                                                            openRhythmFolder(song)
                                                        MusicLibrarySection.QUOC_TE -> Unit
                                                    }
                                                } else {
                                                    openSong(song)
                                                }
                                            }
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .background(
                                                    if (isFolder) {
                                                        accentColor.copy(alpha = 0.12f)
                                                    } else {
                                                        bgColor
                                                    },
                                                    RoundedCornerShape(10.dp)
                                                )
                                                .clip(RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            when {
                                                isFolder -> {
                                                    Icon(
                                                        imageVector = Icons.Default.FolderOpen,
                                                        contentDescription = null,
                                                        tint = accentColor,
                                                        modifier = Modifier.size(27.dp)
                                                    )
                                                }

                                                thumbnailUrl.isNotEmpty() -> {
                                                    coil.compose.AsyncImage(
                                                        model = thumbnailUrl,
                                                        contentDescription = null,
                                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }

                                                else -> {
                                                    Icon(
                                                        imageVector = Icons.Default.LibraryMusic,
                                                        contentDescription = null,
                                                        tint = accentColor.copy(alpha = 0.8f),
                                                        modifier = Modifier.size(25.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(14.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = song.title,
                                                color = textColor,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = itemSubtitle,
                                                color = Color.Gray,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        if (isFolder) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "›",
                                                color = accentColor,
                                                fontSize = 28.sp,
                                                fontWeight = FontWeight.Light
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Khong chiem chieu cao man hinh khi dang doc / choi TAB.
                // Chi hien banner khi JS xac nhan nguoi dung da cuon den SAU ban nhac.
                // Van giu banner ngoai WebView de khong can thiep AlphaTab va AdMob.
                if (hasScore && showTabBottomBanner) {
                    SongDetailBottomBannerAd(
                        currentLang = currentLang,
                        surfaceColor = if (localIsDark) Color.Black else surfaceColor,
                        textColor = if (localIsDark) Color.White else textColor,
                        modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 4.dp)
                    )
                }
            }
        }
    }
    // 1. Ẩn thanh trạng thái của Activity gốc (Áp dụng cho CẢ DỌC LẪN NGANG)
    val currentView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(Unit) {
        val window = activity?.window
        if (window != null) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, currentView)
            insetsController.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.statusBars())
        }
        onDispose {
            // Đã tắt chức năng khôi phục thanh pin/sóng để ẩn luôn ở trang chủ
        }
    }

    // HIỂN THỊ GIAO DIỆN TÙY THEO CHẾ ĐỘ
    if (isLandscape) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = {
                isLandscape = false
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false
            )
        ) {
            val dialogView = androidx.compose.ui.platform.LocalView.current

            // 2. Ẩn tiếp thanh trạng thái của chính Dialog đang nổi lên
            DisposableEffect(dialogView) {
                val dialogWindow = (dialogView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
                if (dialogWindow != null) {
                    val insetsController = androidx.core.view.WindowCompat.getInsetsController(dialogWindow, dialogView)
                    insetsController.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.statusBars())
                }
                onDispose {}
            }

            screenContent()
        }
    } else {
        screenContent()
    }

    if (songTechniqueDialogOpen && hasScore) {
        val vietnameseGuide = currentLang.lowercase(Locale.ROOT).startsWith("vi")
        val themeSurface = if (localIsDark) Color(0xFF171B24) else Color.White
        val themeText = if (localIsDark) Color.White else Color(0xFF101828)
        val themeMuted = if (localIsDark) Color(0xFFB7C0D0) else Color(0xFF667085)
        val availableTechniques = SONG_TECHNIQUE_LEGEND.entries.filter { it.key in songTechniqueIds }
        Dialog(onDismissRequest = { songTechniqueDialogOpen = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth().heightIn(max = 660.dp),
                shape = RoundedCornerShape(22.dp),
                color = themeSurface,
                tonalElevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (vietnameseGuide) "Kỹ thuật & ký hiệu trong bài" else "Techniques & symbols in this score",
                            color = themeText,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { songTechniqueDialogOpen = false },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = if (vietnameseGuide) "Đóng" else "Close", tint = themeText)
                        }
                    }
                    Text(
                        text = tracks.getOrNull(selectedTrackIndex)?.name.orEmpty().ifBlank { "Track ${selectedTrackIndex + 1}" },
                        color = themeMuted,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = themeMuted.copy(alpha = .25f))
                    Spacer(modifier = Modifier.height(4.dp))
                    when {
                        songTechniqueScanning -> Box(
                            modifier = Modifier.fillMaxWidth().height(120.dp),
                            contentAlignment = Alignment.Center
                        ) { CircularProgressIndicator(color = accentColor) }
                        availableTechniques.isEmpty() -> Text(
                            text = if (vietnameseGuide) "Không phát hiện ký hiệu đặc biệt ở track này." else "No special symbols detected in this track.",
                            color = themeMuted,
                            modifier = Modifier.padding(vertical = 24.dp)
                        )
                        else -> {
                            val technicalItems = availableTechniques.filter { !it.value.notation }
                            val notationItems = availableTechniques.filter { it.value.notation }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                if (technicalItems.isNotEmpty()) {
                                    item {
                                        Text(
                                            text = if (vietnameseGuide) "KỸ THUẬT CHƠI" else "PLAYING TECHNIQUES",
                                            color = accentColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                                        )
                                    }
                                    items(technicalItems) { technique ->
                                        SongTechniqueGuideRow(technique.value, vietnameseGuide, localIsDark, themeText, themeMuted)
                                    }
                                }
                                if (notationItems.isNotEmpty()) {
                                    item {
                                        Text(
                                            text = if (vietnameseGuide) "KÝ HIỆU NHẠC LÝ" else "MUSICAL NOTATION",
                                            color = accentColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                                        )
                                    }
                                    items(notationItems) { technique ->
                                        SongTechniqueGuideRow(technique.value, vietnameseGuide, localIsDark, themeText, themeMuted)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAppearanceSettings) {
        TabAppearanceSettingsDialog(
            currentLang = currentLang,
            appIsDark = isDark,
            themeMode = appearanceThemeMode,
            cursorColorId = appearanceCursorColorId,
            activeRegionColorId = appearanceActiveRegionColorId,
            tabColorId = appearanceTabColorId,
            noteColorId = appearanceNoteColorId,
            fretboardColorId = appearanceFretboardColorId,
            panelColorId = appearancePanelColorId,
            cursorWidth = appearanceCursorWidth,
            regionOpacity = appearanceRegionOpacity,
            onThemeModeChange = ::setAppearanceThemeMode,
            onCursorColorChange = { value ->
                setAppearanceColor(TAB_APPEARANCE_PREF_CURSOR_COLOR, value) {
                    appearanceCursorColorId = it
                }
            },
            onActiveRegionColorChange = { value ->
                setAppearanceColor(TAB_APPEARANCE_PREF_ACTIVE_REGION_COLOR, value) {
                    appearanceActiveRegionColorId = it
                }
            },
            onTabColorChange = { value ->
                setAppearanceColor(TAB_APPEARANCE_PREF_TAB_COLOR, value) {
                    appearanceTabColorId = it
                }
            },
            onNoteColorChange = { value ->
                setAppearanceColor(TAB_APPEARANCE_PREF_NOTE_COLOR, value) {
                    appearanceNoteColorId = it
                }
            },
            onFretboardColorChange = { value ->
                setAppearanceColor(TAB_APPEARANCE_PREF_FRETBOARD_COLOR, value) {
                    appearanceFretboardColorId = it
                }
            },
            onPanelColorChange = { value ->
                setAppearanceColor(TAB_APPEARANCE_PREF_PANEL_COLOR, value) {
                    appearancePanelColorId = it
                }
            },
            onCursorWidthChange = { value ->
                appearanceCursorWidth = value.coerceIn(0f, 24f)
                tabDisplayPrefs.edit().putFloat(
                    TAB_APPEARANCE_PREF_CURSOR_WIDTH, appearanceCursorWidth
                ).apply()
            },
            onRegionOpacityChange = { value ->
                appearanceRegionOpacity = value.coerceIn(0f, .85f)
                tabDisplayPrefs.edit().putFloat(
                    TAB_APPEARANCE_PREF_REGION_OPACITY, appearanceRegionOpacity
                ).apply()
            },
            onReset = ::resetAppearanceSettings,
            onDismiss = { showAppearanceSettings = false }
        )
    }
}

// ----------------- API BẢN NHẠC -----------------
private enum class SheetMusicServerSource {
    PRIMARY,
    FALLBACK
}

private data class SheetMusicSearchOutcome(
    val songs: List<TuneToolsSong>,
    val source: SheetMusicServerSource
)

private object TuneToolsSheetMusicApi {
    // One PHP on alwaysdata now serves Vietnamese folders, international songs,
    // rhythms and GP bytes using the same database and Drive token.
    private const val DRIVE_API_BASE_URL = "https://tuner.alwaysdata.net"
    private const val DRIVE_SECTIONS_ENDPOINT =
        "https://tuner.alwaysdata.net/api_gp_drive.php"

    private const val DRIVE_CONNECT_TIMEOUT_MS = 4_000
    private const val DRIVE_READ_TIMEOUT_MS = 9_000
    private const val LEGACY_CONNECT_TIMEOUT_MS = 4_000
    private const val LEGACY_READ_TIMEOUT_MS = 10_000

    private class SearchHttpException(
        val statusCode: Int,
        message: String
    ) : IllegalStateException(message)

    private class InvalidSearchResponseException(
        message: String,
        cause: Throwable? = null
    ) : IllegalStateException(message, cause)

    fun search(
        apiBaseUrl: String,
        searchPath: String,
        keyword: String,
        apiToken: String?,
        section: MusicLibrarySection,
        rhythm: String? = null,
        folder: String? = null
    ): SheetMusicSearchOutcome {
        // All three tabs now use exactly the API contract provided by
        // api_gp_drive.php (one PHP file on alwaysdata).
        val driveUrl = buildDriveSectionsUrl(keyword, section, rhythm, folder)
        try {
            val driveJson = httpGetText(
                urlString = driveUrl,
                apiToken = null, // Never forward the token from a different server.
                connectTimeoutMs = DRIVE_CONNECT_TIMEOUT_MS,
                readTimeoutMs = DRIVE_READ_TIMEOUT_MS
            )
            return SheetMusicSearchOutcome(
                songs = parseSearchResponse(driveJson, DRIVE_API_BASE_URL),
                source = SheetMusicServerSource.PRIMARY
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (driveError: Exception) {
            if (!shouldUseFallback(driveError)) throw driveError
            android.util.Log.w(
                "TuneToolsSheetMusicApi",
                "alwaysdata sections temporarily unavailable; trying legacy IIS",
                driveError
            )

            // Keep the existing IIS endpoint as an emergency fallback only.
            // Its result is NEVER substituted for a valid empty Drive catalogue.
            val legacyUrl = buildPrimarySearchUrl(
                apiBaseUrl = apiBaseUrl,
                searchPath = searchPath,
                keyword = keyword,
                section = section,
                rhythm = rhythm,
                folder = folder
            )
            try {
                val legacyJson = httpGetText(
                    urlString = legacyUrl,
                    apiToken = apiToken,
                    connectTimeoutMs = LEGACY_CONNECT_TIMEOUT_MS,
                    readTimeoutMs = LEGACY_READ_TIMEOUT_MS
                )
                return SheetMusicSearchOutcome(
                    songs = parseSearchResponse(legacyJson, apiBaseUrl),
                    source = SheetMusicServerSource.FALLBACK
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (legacyError: Exception) {
                val failure = IllegalStateException(
                    "Không thể tải danh mục từ Google Drive hoặc máy chủ dự phòng.",
                    legacyError
                )
                failure.addSuppressed(driveError)
                throw failure
            }
        }
    }

    private fun buildDriveSectionsUrl(
        keyword: String,
        section: MusicLibrarySection,
        rhythm: String?,
        folder: String?
    ): String {
        val sectionCode = when (section) {
            MusicLibrarySection.NHAC_VIET -> "nhac_viet"
            MusicLibrarySection.QUOC_TE -> "quoc_te"
            MusicLibrarySection.DIEU_NHAC -> "dieu_nhac"
        }
        val parameters = mutableListOf(
            "action=sections",
            "section=$sectionCode",
            "q=" + URLEncoder.encode(keyword, StandardCharsets.UTF_8.name())
        )
        when (section) {
            MusicLibrarySection.NHAC_VIET -> folder
                ?.trim()
                ?.trim('/')
                ?.takeIf { it.isNotEmpty() }
                ?.let { parameters += "folder=" + URLEncoder.encode(it, StandardCharsets.UTF_8.name()) }

            MusicLibrarySection.DIEU_NHAC -> rhythm
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.let { parameters += "rhythm=" + URLEncoder.encode(it, StandardCharsets.UTF_8.name()) }

            MusicLibrarySection.QUOC_TE -> Unit
        }
        return DRIVE_SECTIONS_ENDPOINT + "?" + parameters.joinToString("&")
    }

    private fun buildPrimarySearchUrl(
        apiBaseUrl: String,
        searchPath: String,
        keyword: String,
        section: MusicLibrarySection,
        rhythm: String?,
        folder: String?
    ): String {
        val primaryEndpoint = when {
            searchPath.startsWith("http", ignoreCase = true) -> searchPath
            apiBaseUrl.trimEnd('/').endsWith(".php", ignoreCase = true) ->
                apiBaseUrl.trimEnd('/')
            else -> joinUrl(apiBaseUrl, searchPath)
        }

        val parameters = mutableListOf(
            "q=" + URLEncoder.encode(keyword, StandardCharsets.UTF_8.name())
        )

        when (section) {
            MusicLibrarySection.NHAC_VIET -> {
                parameters += "section=nhac_viet"
                folder
                    ?.trim()
                    ?.trim('/')
                    ?.takeIf { it.isNotEmpty() }
                    ?.let {
                        parameters += "folder=" +
                                URLEncoder.encode(it, StandardCharsets.UTF_8.name())
                    }
            }

            MusicLibrarySection.DIEU_NHAC -> {
                parameters += "section=dieu_nhac"
                rhythm
                    ?.trim()
                    ?.takeIf { it.isNotEmpty() }
                    ?.let {
                        parameters += "rhythm=" +
                                URLEncoder.encode(it, StandardCharsets.UTF_8.name())
                    }
            }

            MusicLibrarySection.QUOC_TE -> {
                parameters += "section=quoc_te"
            }
        }

        val separator = if (primaryEndpoint.contains("?")) "&" else "?"
        return primaryEndpoint + separator + parameters.joinToString("&")
    }

    /**
     * Chỉ fallback khi server thật sự không dùng được:
     * - lỗi mạng/timeout/DNS/SSL;
     * - HTTP 404 khi API sections chính biến mất / bị đổi đường dẫn;
     * - HTTP 408, 429 hoặc 5xx;
     * - HTTP 200 nhưng JSON tìm kiếm bị hỏng/không đúng cấu trúc.
     *
     * Không fallback với 401/403 và không fallback với danh sách rỗng hợp lệ.
     */
    private fun shouldUseFallback(error: Throwable): Boolean {
        var current: Throwable? = error

        while (current != null) {
            when (current) {
                is SearchHttpException -> {
                    return current.statusCode == 404 ||
                            current.statusCode == 408 ||
                            current.statusCode == 429 ||
                            current.statusCode in 500..599
                }

                is InvalidSearchResponseException -> return true
                is java.io.IOException -> return true
            }

            current = current.cause
        }

        return false
    }

    private fun parseSearchResponse(
        jsonText: String,
        apiBaseUrl: String
    ): List<TuneToolsSong> {
        val trimmed = jsonText.trim()
        if (trimmed.isEmpty()) {
            throw InvalidSearchResponseException("Máy chủ trả về dữ liệu trống.")
        }

        val array = try {
            when {
                trimmed.startsWith("[") -> JSONArray(trimmed)

                trimmed.startsWith("{") -> {
                    val root = JSONObject(trimmed)
                    if ((root.has("ok") && !root.optBoolean("ok", true)) ||
                        (root.has("success") && !root.optBoolean("success", true))) {
                        throw InvalidSearchResponseException(
                            firstNonBlank(
                                root.optString("error"),
                                root.optString("message"),
                                "Máy chủ chưa sẵn sàng trả danh mục bản nhạc."
                            )
                        )
                    }
                    root.optJSONArray("data")
                        ?: root.optJSONArray("songs")
                        ?: root.optJSONArray("results")
                        ?: throw InvalidSearchResponseException(
                            firstNonBlank(
                                root.optString("error"),
                                root.optString("message"),
                                "Phản hồi tìm kiếm không có danh sách kết quả."
                            )
                        )
                }

                else -> throw InvalidSearchResponseException(
                    "Máy chủ trả về dữ liệu không phải JSON."
                )
            }
        } catch (error: InvalidSearchResponseException) {
            throw error
        } catch (error: Exception) {
            throw InvalidSearchResponseException(
                "Không thể đọc dữ liệu tìm kiếm từ máy chủ.",
                error
            )
        }

        val result = ArrayList<TuneToolsSong>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val rawItemType = item.optString("item_type")
                .trim()
                .lowercase(Locale.ROOT)
            val rawFormat = item.optString("format")
                .trim()
                .lowercase(Locale.ROOT)
                .removePrefix(".")
            val isFolder = rawItemType == "folder" || rawFormat == "folder"
            val itemType = if (isFolder) {
                TuneToolsItemType.FOLDER
            } else {
                TuneToolsItemType.FILE
            }

            val title = firstNonBlank(
                item.optString("title"),
                item.optString("name"),
                "Không tên"
            )
            val artist = firstNonBlank(
                item.optString("artist"),
                item.optString("singer")
            )
            val rhythm = firstNonBlank(
                item.optString("rhythm"),
                if (isFolder && item.optString("library_section") == "dieu_nhac") {
                    title
                } else {
                    ""
                }
            )
            val librarySection = item.optString("library_section").trim()
            val relativePath = firstNonBlank(
                item.optString("relative_path"),
                item.optString("file_path")
            ).trim()
            val folderPath = firstNonBlank(
                item.optString("folder_path"),
                if (isFolder) relativePath else ""
            ).trim().trim('/')
            val parentPath = item.optString("parent_path")
                .trim()
                .trim('/')

            val fileUrl = firstNonBlank(
                item.optString("file_url"),
                item.optString("download_url"),
                item.optString("url")
            )

            // Thư mục Điệu nhạc cố ý không có file_url; file thông thường thì bắt buộc có.
            if (!isFolder && fileUrl.isBlank()) continue

            val resolvedUrl = when {
                fileUrl.isBlank() -> ""
                fileUrl.startsWith("http", ignoreCase = true) -> fileUrl
                else -> joinUrl(apiBaseUrl, fileUrl)
            }
            val format = when {
                isFolder -> "folder"
                rawFormat.isNotBlank() -> rawFormat
                else -> "gp5"
            }
            val fallbackId = if (isFolder) {
                "folder:$librarySection:${folderPath.ifBlank { rhythm.ifBlank { title } }}"
            } else {
                resolvedUrl
            }

            result += TuneToolsSong(
                id = firstNonBlank(item.optString("id"), fallbackId),
                title = title,
                artist = artist,
                fileUrl = resolvedUrl,
                format = format,
                itemType = itemType,
                rhythm = rhythm,
                subfolder = item.optString("subfolder").trim(),
                relativePath = relativePath,
                folderPath = folderPath,
                parentPath = parentPath,
                librarySection = librarySection
            )
        }
        return result
    }

    private fun httpGetText(
        urlString: String,
        apiToken: String?,
        connectTimeoutMs: Int,
        readTimeoutMs: Int
    ): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = connectTimeoutMs
            connection.readTimeout = readTimeoutMs
            connection.useCaches = false
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Accept-Encoding", "identity")
            connection.setRequestProperty("User-Agent", "TunerInstrument-Android")
            if (!apiToken.isNullOrBlank()) {
                connection.setRequestProperty("Authorization", "Bearer $apiToken")
            }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }
            val responseText = stream?.use { input ->
                ByteArrayOutputStream().use { output ->
                    input.copyTo(output)
                    output.toByteArray()
                }
            }?.toString(StandardCharsets.UTF_8).orEmpty()

            if (responseCode !in 200..299) {
                val serverMessage = runCatching {
                    val root = JSONObject(responseText)
                    firstNonBlank(
                        root.optString("error"),
                        root.optString("message")
                    )
                }.getOrNull().orEmpty()

                throw SearchHttpException(
                    statusCode = responseCode,
                    message = serverMessage.ifBlank {
                        "Máy chủ phản hồi HTTP $responseCode"
                    }
                )
            }

            return responseText
        } finally {
            connection.disconnect()
        }
    }

    private fun joinUrl(base: String, path: String): String =
        base.trimEnd('/') + "/" + path.trimStart('/')

    private fun firstNonBlank(vararg values: String): String =
        values.firstOrNull { it.isNotBlank() } ?: ""
}

// --- HÀM LẤY ẢNH THUMBNAIL TỪ ITUNES API ---
suspend fun getITunesThumbnail(title: String, artist: String): String {
    return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            // Tẩy bớt dấu ngoặc đơn (nếu có) để tìm kiếm chính xác hơn
            val cleanTitle = title.replace(Regex("\\(.*?\\)"), "").trim()
            val query = java.net.URLEncoder.encode("$cleanTitle $artist", "UTF-8")
            val url = java.net.URL("https://itunes.apple.com/search?term=$query&entity=song&limit=1")

            val connection = url.openConnection() as java.net.HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 3000
            connection.readTimeout = 3000

            if (connection.responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = org.json.JSONObject(response)
                val results = json.optJSONArray("results")
                if (results != null && results.length() > 0) {
                    return@withContext results.getJSONObject(0).optString("artworkUrl100", "")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        ""
    }
}