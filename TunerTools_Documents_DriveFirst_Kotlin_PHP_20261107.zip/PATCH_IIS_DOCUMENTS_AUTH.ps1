param(
    [string]$IisPhp = 'C:\inetpub\wwwroot\api_documents.php',
    [string]$BackupDir = 'C:\TunerTools\Backups\DocumentsIIS'
)
$ErrorActionPreference = 'Stop'
$anchor = '    if ($action === ''auth_login'') {'
$marker = 'TT_DOCUMENTS_DRIVE_AUTH_V1_BEGIN'
if (!(Test-Path -LiteralPath $IisPhp -PathType Leaf)) { throw "File IIS khong ton tai: $IisPhp" }
$utf8 = [System.Text.UTF8Encoding]::new($false, $true)
$originalBytes = [System.IO.File]::ReadAllBytes($IisPhp)
$old = $utf8.GetString($originalBytes)
if ($old.Contains($marker)) {
    Write-Host 'DA CO action=drive_authorize. Khong sua tiep file.' -ForegroundColor Yellow
    exit 0
}
$required = @(
    'function authorizeDocumentAction(',
    'function createDocumentTicket(',
    'function permissionCanAccessDocumentPath(',
    '$db = documentDatabase();',
    $anchor
)
foreach ($needle in $required) {
    if (-not $old.Contains($needle)) {
        throw "PHP IIS khong khop phien ban mau: $needle. Khong sua de tranh mat chuc nang."
    }
}
$at = $old.IndexOf($anchor, [System.StringComparison]::Ordinal)
if ($at -lt 0) { throw 'Khong tim thay vi tri chen ma.' }
$snippet = @'
    // TT_DOCUMENTS_DRIVE_AUTH_V1_BEGIN
    // Authorization-only bridge for Alwaysdata. This MUST execute before the
    // filesystem resolver, and MUST reuse the existing signed sessions/tickets.
    // No local document file/directory is opened by this branch.
    if ($action === 'drive_authorize') {
        if ($method !== 'POST') {
            sendJson(['success'=>false, 'code'=>'method_not_allowed', 'message'=>'POST required'], 405);
        }
        $purpose = strtolower(trim(requestValue('purpose', 'list')));
        if (!in_array($purpose, ['list','view','download','folder_options'], true)) {
            sendJson(['success'=>false, 'code'=>'invalid_purpose', 'message'=>'Unsupported purpose'], 400);
        }
        $instrumentKey = strtolower(requestValue('instrument', 'guitar'));
        if (!isset($instrumentMap[$instrumentKey])) {
            sendJson(['success'=>false, 'code'=>'invalid_instrument', 'message'=>'Unsupported instrument'], 400);
        }
        $instrument = $instrumentMap[$instrumentKey];
        $relativePath = normalizeRelativePath(requestValue('path', ''));
        if (strlen($relativePath) > 1000 || count(explode('/', $relativePath)) > 32) {
            sendJson(['success'=>false, 'code'=>'invalid_path', 'message'=>'Invalid path'], 400);
        }
        if (in_array($purpose, ['view', 'download'], true) && $relativePath === '') {
            sendJson(['success'=>false, 'code'=>'missing_file', 'message'=>'Missing file path'], 400);
        }
        // Folder selection for Admin now comes from Drive rather than an IIS directory.
        if ($purpose === 'folder_options') {
            $manager = requireDocumentSession($db);
            requirePermissionFlag($manager, 'can_manage', 'Chỉ quản trị viên được xem thư mục phân quyền.');
            sendJson(['success'=>true, 'authorized'=>true, 'purpose'=>'folder_options']);
        }
        // Centralized policy checks (including trial, revoked account, expiry,
        // allowed folders and signed short-lived view/download tickets).
        $drivePermission = authorizeDocumentAction($db, $purpose, $instrument, $relativePath);
        if ($purpose !== 'list') {
            sendJson(['success'=>true, 'authorized'=>true, 'purpose'=>$purpose]);
        }

        $childrenRaw = requestValue('children_json', '[]');
        if (strlen($childrenRaw) > 72000) {
            sendJson(['success'=>false, 'code'=>'too_many_children', 'message'=>'Child list too large'], 413);
        }
        $children = json_decode($childrenRaw, true);
        if (!is_array($children) || count($children) > 100) {
            sendJson(['success'=>false, 'code'=>'invalid_children', 'message'=>'Invalid child list'], 400);
        }
        $isTrial = permissionIsSongTabTrial($drivePermission);
        $canDownload = !$isTrial && permissionAllows($drivePermission, 'can_download');
        $authorizedChildren = [];
        foreach ($children as $child) {
            if (!is_array($child)) continue;
            $childPath = (string)($child['path'] ?? '');
            $kind = (string)($child['type'] ?? '');
            if (!in_array($kind, ['file','folder'], true) || $childPath === '' || strlen($childPath) > 1000) continue;
            // Exact canonical path and direct child check: clients cannot request
            // tickets for unrelated paths in a bulk list response.
            try { $normalized = normalizeRelativePath($childPath); } catch (Throwable $ignored) { continue; }
            if ($normalized !== $childPath || parentRelativePath($childPath) !== $relativePath) continue;
            if ($isTrial && !isContributionPath($childPath)) continue;
            if (!$isTrial && !permissionCanAccessDocumentPath($drivePermission, $instrument, $childPath, false)) continue;
            $entry = ['path' => $childPath, 'type' => $kind];
            if ($kind === 'file') {
                $entry['view_ticket'] = createDocumentTicket($drivePermission, 'view', $instrument, $childPath);
                $entry['download_ticket'] = $canDownload
                    ? createDocumentTicket($drivePermission, 'download', $instrument, $childPath) : '';
            }
            $authorizedChildren[] = $entry;
        }
        sendJson([
            'success' => true,
            'authorized' => true,
            'purpose' => 'list',
            'instrument' => $instrument,
            'path' => $relativePath,
            'children' => $authorizedChildren,
            // Public writes and ownership metadata require a separate, safely
            // synchronized Drive-write migration. Do not imply it is ready.
            'can_public_upload_here' => false,
            'can_public_create_folder_here' => false,
        ]);
    }
    // TT_DOCUMENTS_DRIVE_AUTH_V1_END
'@
if ($snippet -notmatch 'TT_DOCUMENTS_DRIVE_AUTH_V1_END') { throw 'Snippet khong hoan chinh.' }
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $BackupDir "api_documents_before_drive_auth_$stamp.php.bak"
$temp = Join-Path $BackupDir "api_documents_with_drive_auth_$stamp.tmp"
$patched = $old.Substring(0,$at) + $snippet + "`r`n" + $old.Substring($at)
[System.IO.File]::WriteAllText($temp, $patched, $utf8)
$php = Get-Command php.exe -ErrorAction SilentlyContinue
if ($null -ne $php) {
    & $php.Source -l $temp
    if ($LASTEXITCODE -ne 0) {
        Remove-Item -LiteralPath $temp -Force
        throw 'PHP syntax error. File IIS van nguyen ban.'
    }
} else {
    Write-Host 'KHONG CO php.exe trong PATH: chua tu dong kiem tra php -l.' -ForegroundColor Yellow
}
# Atomic replacement on NTFS, saving a copy OUTSIDE the public web root.
[System.IO.File]::Replace($temp, $IisPhp, $backup, $true)
Write-Host 'DA THEM action=drive_authorize VAO FILE IIS HIEN TAI.' -ForegroundColor Green
Write-Host "BACKUP (khong nam trong wwwroot): $backup"
Write-Host 'Khong xoa backup truoc khi test xong. Khong dua file backup len website.'
