<?php
/**
 * TunerTools - one-time READ-ONLY export of live MySQL document_permissions.
 * CLI ONLY. No DB secret or user email is printed to console.
 * It reads connection scalar literals from the local api_documents.php without
 * executing that API, preserving all production API/session behavior.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit(1); }

function failExport(string $message): void {
    fwrite(STDERR, "EXPORT_ERROR: " . $message . PHP_EOL);
    exit(1);
}
function getArgument(string $name): ?string {
    global $argv;
    foreach ($argv as $i => $arg) {
        if ($arg === $name && isset($argv[$i + 1])) return (string)$argv[$i + 1];
    }
    return null;
}
function literalString(string $raw): ?string {
    $quote = substr($raw, 0, 1);
    if (strlen($raw) < 2 || !in_array($quote, ["'", '"'], true) || substr($raw, -1) !== $quote) return null;
    $inside = substr($raw, 1, -1);
    if ($quote === "'") {
        // PHP single-quoted strings only unescape two patterns: \\ and \\'.
        return preg_replace_callback('/\\\\([\\\\\'])/', static function ($m) { return $m[1]; }, $inside);
    }
    // Refuse interpolated double-quoted values: no guessing passwords.
    if (preg_match('/(?<!\\\\)\\$/', $inside)) return null;
    return stripcslashes($inside);
}
function readLocalDbConfig(string $apiFile): array {
    if (!is_file($apiFile) || !is_readable($apiFile)) failExport('Khong tim thay api_documents.php tai duong dan server.');
    $source = file_get_contents($apiFile);
    if (!is_string($source) || $source === '') failExport('Khong doc duoc file API.');
    $tokens = token_get_all($source);
    $wanted = ['servername', 'username', 'password', 'dbname', 'port'];
    $values = [];
    $total = count($tokens);
    for ($i = 0; $i < $total; $i++) {
        $token = $tokens[$i];
        if (!is_array($token) || $token[0] !== T_VARIABLE) continue;
        $name = substr($token[1], 1);
        if (!in_array($name, $wanted, true) || array_key_exists($name, $values)) continue;
        $j = $i + 1;
        while ($j < $total && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) $j++;
        if ($j >= $total || $tokens[$j] !== '=') continue;
        $j++;
        while ($j < $total && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) $j++;
        if ($j >= $total || !is_array($tokens[$j])) continue;
        if ($tokens[$j][0] === T_CONSTANT_ENCAPSED_STRING) {
            $v = literalString($tokens[$j][1]);
            if ($v !== null) $values[$name] = $v;
        } elseif ($tokens[$j][0] === T_LNUMBER && $name === 'port') {
            $values[$name] = (int)$tokens[$j][1];
        }
    }
    // Environment overrides are for installations that do not use literal scalars.
    $keyMap = [
        'servername' => 'TUNERTOOLS_DB_HOST',
        'username' => 'TUNERTOOLS_DB_USER',
        'password' => 'TUNERTOOLS_DB_PASSWORD',
        'dbname' => 'TUNERTOOLS_DB_NAME',
        'port' => 'TUNERTOOLS_DB_PORT'
    ];
    foreach ($keyMap as $key => $env) {
        $value = getenv($env);
        if ($value !== false && $value !== '') $values[$key] = $value;
    }
    foreach (['servername', 'username', 'password', 'dbname'] as $key) {
        if (!array_key_exists($key, $values) || trim((string)$values[$key]) === '') {
            failExport('Khong doc du cau hinh MySQL tu file API. Can config DB o moi truong server (khong gui thong tin nay qua chat).');
        }
    }
    $values['port'] = isset($values['port']) ? (int)$values['port'] : 3306;
    if ($values['port'] < 1 || $values['port'] > 65535) failExport('MySQL port khong hop le.');
    return $values;
}
function boolColumn(array $row, string $name, bool $default = false): bool {
    if (!array_key_exists($name, $row) || $row[$name] === null) return $default;
    return ((int)$row[$name]) !== 0;
}
function folderScopes($raw): array {
    if (is_array($raw)) $values = $raw;
    else {
        $text = trim((string)$raw);
        if ($text === '') return [];
        $decoded = json_decode($text, true);
        $values = is_array($decoded) ? $decoded : preg_split('/[\r\n,]+/', $text);
    }
    $result = [];
    foreach ((array)$values as $item) {
        if (!is_string($item)) continue;
        $parts = [];
        foreach (explode('/', str_replace('\\', '/', trim($item))) as $part) {
            $part = trim($part);
            if ($part === '' || $part === '.') continue;
            if ($part === '..') { $parts = []; break; }
            $parts[] = $part;
        }
        if ($parts !== []) $result[implode('/', $parts)] = true;
        if (count($result) >= 200) break;
    }
    return array_keys($result);
}

$api = getArgument('--api') ?: 'C:\\TunerTools\\Web\\API\\api_documents.php';
$out = getArgument('--out');
$selfTest = in_array('--self-test-config', $argv, true);
$config = readLocalDbConfig($api);
if ($selfTest) { echo "DB_CONFIG_PARSE_OK: scalar connection keys found; no values printed." . PHP_EOL; exit(0); }
if (!$out) failExport('Thieu --out <private-json-path>.');
if (!extension_loaded('mysqli')) failExport('PHP CLI chua bat mysqli; can su dung php.exe co mysqli.');
if (!is_dir(dirname($out)) || !is_writable(dirname($out))) failExport('Private output folder chua duoc tao hoac khong co quyen ghi.');

try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $db = new mysqli((string)$config['servername'], (string)$config['username'], (string)$config['password'], (string)$config['dbname'], (int)$config['port']);
    $db->set_charset('utf8mb4');
    $result = $db->query('SELECT * FROM document_permissions ORDER BY id ASC');
    $users = [];
    $emails = [];
    $active = 0;
    $disabled = 0;
    $expired = 0;
    $now = time();
    while ($row = $result->fetch_assoc()) {
        if (count($users) >= 100000) throw new RuntimeException('Vuot gioi han 100000 tai khoan.');
        $id = (int)($row['id'] ?? 0);
        $email = strtolower(trim((string)($row['email'] ?? '')));
        if ($id <= 0 || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Ban ghi MySQL khong hop le (id: ' . $id . ').');
        if (isset($emails[$email])) throw new RuntimeException('Trung email sau khi chuan hoa (id: ' . $id . ').');
        $emails[$email] = true;
        $status = strtolower(trim((string)($row['status'] ?? 'disabled')));
        $expires = trim((string)($row['expires_at'] ?? ''));
        $isExpired = $expires !== '' && (($expiry = strtotime($expires)) !== false) && $expiry <= $now;
        if ($status !== 'active') $disabled++;
        elseif ($isExpired) $expired++;
        else $active++;
        $canManage = boolColumn($row, 'can_manage');
        $users[] = [
            'id' => $id,
            'email' => $email,
            'google_sub' => trim((string)($row['google_sub'] ?? '')),
            'can_view' => boolColumn($row, 'can_view'),
            'can_download' => boolColumn($row, 'can_download'),
            'can_upload' => boolColumn($row, 'can_upload'),
            'can_create_folder' => boolColumn($row, 'can_create_folder'),
            'can_manage' => $canManage,
            'can_view_all_folders' => $canManage || boolColumn($row, 'can_view_all_folders', true),
            'allowed_folders' => folderScopes($row['allowed_folders'] ?? null),
            'status' => $status,
            'expires_at' => $expires === '' ? null : $expires,
            'updated_at' => (string)($row['updated_at'] ?? '')
        ];
    }
    $result->free();
    $db->close();
    if (!$users) throw new RuntimeException('Khong co tai khoan. Khong xuat snapshot rong.');
    $snapshot = [
        'schema' => 'tunertools.document_permissions.v1',
        'version' => 1,
        'generated_at_utc' => gmdate('Y-m-d\TH:i:s\Z'),
        'source' => 'mysql.document_permissions',
        'user_count' => count($users),
        'users' => $users
    ];
    $data = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR) . "\n";
    $temp = tempnam(dirname($out), '.document-permissions-');
    if (!is_string($temp)) throw new RuntimeException('Khong tao duoc file tam.');
    try {
        if (file_put_contents($temp, $data, LOCK_EX) !== strlen($data)) throw new RuntimeException('Ghi JSON khong hoan tat.');
        @chmod($temp, 0600);
        if (!rename($temp, $out)) throw new RuntimeException('Khong the thay the file JSON private.');
    } finally { if (is_file($temp)) @unlink($temp); }
    echo 'EXPORT_OK: live MySQL -> private JSON' . PHP_EOL;
    echo 'USERS_TOTAL: ' . count($users) . ' | ACTIVE: ' . $active . ' | DISABLED: ' . $disabled . ' | EXPIRED: ' . $expired . PHP_EOL;
    echo 'JSON_SHA256: ' . hash('sha256', $data) . PHP_EOL;
} catch (Throwable $error) {
    failExport('Khong the doc/xuat bang document_permissions: ' . $error->getMessage());
}
