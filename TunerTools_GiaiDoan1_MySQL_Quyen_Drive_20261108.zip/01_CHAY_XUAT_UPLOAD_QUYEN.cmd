@echo off
setlocal
cd /d "%~dp0"
echo =============================================================
echo  TUNERTOOLS - DOCUMENT PERMISSIONS (MYSQL -^> GOOGLE DRIVE)
echo =============================================================
echo Run as Administrator. Existing Android code will NOT be changed.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_DOCUMENT_PERMISSIONS.ps1" %*
set "rc=%ERRORLEVEL%"
echo.
if not "%rc%"=="0" echo ERROR: See message above. No changes to admin.kt.
if "%rc%"=="0" echo SUCCESS: Drive permission snapshot uploaded and checked.
pause
exit /b %rc%
