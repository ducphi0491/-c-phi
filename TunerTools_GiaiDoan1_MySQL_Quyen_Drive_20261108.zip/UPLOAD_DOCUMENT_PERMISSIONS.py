#!/usr/bin/env python3
"""TunerTools: upload a PRIVATE MySQL permissions snapshot to Google Drive.

Only this server-side script reads the OAuth refresh token. Never embed it in
Android, never make the permissions JSON public, and never send it to a browser.
Standard library only, Python 3.9+.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

DRIVE_API = "https://www.googleapis.com/drive/v3/files"
UPLOAD_API = "https://www.googleapis.com/upload/drive/v3/files"
ROOT_NAME = "TunerTools_AppBackup"
CONFIG_NAME = "config"
FILE_NAME = "document_permissions.json"
FOLDER_MIME = "application/vnd.google-apps.folder"


class SyncFailure(RuntimeError):
    pass


def sha256(blob):
    return hashlib.sha256(blob).hexdigest()


def md5(blob):
    return hashlib.md5(blob).hexdigest()


def call_http(url, method="GET", body=None, headers=None, timeout=75):
    request = Request(url, data=body, headers=headers or {}, method=method)
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.read()
    except HTTPError as exc:
        # OAuth tokens, email addresses and server response bodies are sensitive.
        raise SyncFailure("HTTP %s from Google API (%s)." % (exc.code, method)) from None
    except (URLError, TimeoutError, OSError) as exc:
        raise SyncFailure("Khong ket noi duoc Google API (%s): %s" % (method, type(exc).__name__)) from None


def json_api(url, token, method="GET", body=None, timeout=75):
    raw = None
    headers = {"Authorization": "Bearer " + token, "Accept": "application/json"}
    if body is not None:
        raw = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=UTF-8"
    raw_result = call_http(url, method, raw, headers, timeout)
    try:
        doc = json.loads(raw_result)
    except (TypeError, ValueError) as exc:
        raise SyncFailure("Google API response khong phai JSON.") from exc
    if not isinstance(doc, dict):
        raise SyncFailure("Google API JSON object khong hop le.")
    return doc


def access_token_from_file(path):
    if not path.is_file():
        raise SyncFailure("Khong tim thay drive_token.json trong Tools/AI_Drive_AutoSync.")
    try:
        obj = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise SyncFailure("Khong doc duoc Drive OAuth token JSON.") from exc
    if not isinstance(obj, dict):
        raise SyncFailure("Drive OAuth token file khong hop le.")
    for name in ("refresh_token", "client_id", "client_secret"):
        if not isinstance(obj.get(name), str) or not obj[name]:
            raise SyncFailure("Drive OAuth token thieu %s." % name)
    token_uri = obj.get("token_uri") or "https://oauth2.googleapis.com/token"
    if token_uri not in ("https://oauth2.googleapis.com/token", "https://accounts.google.com/o/oauth2/token"):
        raise SyncFailure("Unexpected Google OAuth token_uri; refusing to send credentials.")
    payload = urlencode({
        "client_id": obj["client_id"],
        "client_secret": obj["client_secret"],
        "refresh_token": obj["refresh_token"],
        "grant_type": "refresh_token",
    }).encode("utf-8")
    raw = call_http(token_uri, "POST", payload, {"Content-Type": "application/x-www-form-urlencoded"}, 30)
    try:
        response = json.loads(raw)
    except ValueError as exc:
        raise SyncFailure("Google OAuth tra ve JSON khong hop le.") from exc
    access_token = response.get("access_token") if isinstance(response, dict) else None
    if not access_token:
        raise SyncFailure("Google OAuth refresh khong cung cap access_token.")
    return access_token


def exact_files(parent_id, name, mime, token):
    query = (
        "name = '%s' and '%s' in parents and trashed = false and mimeType %s '%s'"
        % (name, parent_id, "=" if mime else "!=", mime or FOLDER_MIME)
    )
    result = []
    page = None
    while True:
        params = {
            "q": query, "fields": "nextPageToken,files(id,name,mimeType,md5Checksum,size,parents)",
            "pageSize": 1000, "spaces": "drive",
        }
        if page:
            params["pageToken"] = page
        obj = json_api(DRIVE_API + "?" + urlencode(params), token)
        files = obj.get("files", [])
        if not isinstance(files, list):
            raise SyncFailure("Drive files list invalid.")
        result.extend(x for x in files if isinstance(x, dict))
        page = obj.get("nextPageToken")
        if not page:
            break
        if len(result) > 2000:
            raise SyncFailure("Too many Drive files with exact name.")
    if len(result) > 1:
        raise SyncFailure("Trung ten Drive: %s (khong tu y chon file)." % name)
    return result[0] if result else None


def assert_private_file(file_id, token, label):
    """Fail closed if a Drive ancestor or snapshot is shared with anyone else."""
    url = DRIVE_API + "/" + quote(file_id, safe="") + "?" + urlencode({"fields": "id,name,shared,mimeType"})
    obj = json_api(url, token)
    if obj.get("shared") is not False:
        raise SyncFailure("Drive %s shared/unknown: refusing to place private Gmail snapshot in shared folder." % label)


def make_folder(parent_id, name, token):
    meta = {"name": name, "mimeType": FOLDER_MIME, "parents": [parent_id]}
    folder = json_api(DRIVE_API + "?" + urlencode({"fields": "id,name,mimeType,parents"}), token,
                      method="POST", body=meta)
    if not folder.get("id") or folder.get("name") != name:
        raise SyncFailure("Drive create config folder invalid response.")
    return folder


def upload_new(folder_id, payload, token):
    boundary = "tunertools-permissions-" + os.urandom(10).hex()
    metadata = {
        "name": FILE_NAME,
        "mimeType": "application/json",
        "parents": [folder_id],
        "description": "Private TunerTools document-permissions snapshot. Never share publicly."
    }
    meta_bytes = json.dumps(metadata, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    blob = (
        ("--%s\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" % boundary).encode("ascii")
        + meta_bytes + b"\r\n"
        + ("--%s\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" % boundary).encode("ascii")
        + payload + b"\r\n"
        + ("--%s--\r\n" % boundary).encode("ascii")
    )
    url = UPLOAD_API + "?" + urlencode({"uploadType": "multipart", "fields": "id,name,mimeType,size,md5Checksum"})
    raw = call_http(url, "POST", blob, {
        "Authorization": "Bearer " + token,
        "Content-Type": "multipart/related; boundary=" + boundary,
        "Accept": "application/json",
    }, 90)
    try:
        obj = json.loads(raw)
    except ValueError as exc:
        raise SyncFailure("Drive new-file upload response invalid.") from exc
    if not isinstance(obj, dict) or not obj.get("id"):
        raise SyncFailure("Drive did not return new file ID.")
    return obj


def upload_overwrite(file_id, payload, token):
    url = UPLOAD_API + "/" + quote(file_id, safe="") + "?" + urlencode({
        "uploadType": "media", "fields": "id,name,mimeType,size,md5Checksum"})
    raw = call_http(url, "PATCH", payload, {
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json; charset=UTF-8",
        "Accept": "application/json",
    }, 90)
    try:
        obj = json.loads(raw)
    except ValueError as exc:
        raise SyncFailure("Drive update response invalid.") from exc
    if not isinstance(obj, dict) or obj.get("id") != file_id:
        raise SyncFailure("Drive updated file identity unexpected.")
    return obj


def verify_download(file_id, payload, token):
    url = DRIVE_API + "/" + quote(file_id, safe="") + "?alt=media"
    remote = call_http(url, "GET", None, {"Authorization": "Bearer " + token}, 60)
    if sha256(remote) != sha256(payload):
        raise SyncFailure("VERIFY_FAILED: SHA256 file tai tu Drive khong khop local.")
    return True


def validate_snapshot(path):
    if not path.is_file():
        raise SyncFailure("Private document_permissions.json chua duoc xuat tu MySQL.")
    data = path.read_bytes()
    if not data or len(data) > 40_000_000:
        raise SyncFailure("JSON empty or too large.")
    try:
        obj = json.loads(data.decode("utf-8-sig"))
    except (ValueError, UnicodeError) as exc:
        raise SyncFailure("Private JSON khong hop le.") from exc
    if not isinstance(obj, dict) or obj.get("schema") != "tunertools.document_permissions.v1":
        raise SyncFailure("Unexpected permission snapshot schema.")
    rows = obj.get("users")
    if not isinstance(rows, list) or not rows or len(rows) != obj.get("user_count"):
        raise SyncFailure("Snapshot user count invalid/empty.")
    seen = set()
    for user in rows:
        if not isinstance(user, dict):
            raise SyncFailure("Snapshot has malformed user entry.")
        email = user.get("email")
        if not isinstance(email, str) or "@" not in email or email in seen:
            raise SyncFailure("Snapshot has invalid/duplicate email.")
        seen.add(email)
        if not all(k in user for k in ("can_view", "can_download", "can_upload", "can_manage", "status", "allowed_folders")):
            raise SyncFailure("Snapshot missing permission flags.")
    return data, len(rows)


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--json", required=True)
    p.add_argument("--token", required=True)
    p.add_argument("--preview", action="store_true")
    p.add_argument("--update-existing", action="store_true")
    args = p.parse_args(argv)
    payload, count = validate_snapshot(Path(args.json))
    local_md5 = md5(payload)
    print("SNAPSHOT_VALID: %d accounts" % count)
    print("LOCAL_SHA256: %s" % sha256(payload))
    token = access_token_from_file(Path(args.token))
    root = exact_files("root", ROOT_NAME, FOLDER_MIME, token)
    if not root:
        raise SyncFailure("Khong tim thay Drive: My Drive/%s. Khong tu tao root." % ROOT_NAME)
    assert_private_file(root["id"], token, ROOT_NAME)
    folder = exact_files(root["id"], CONFIG_NAME, FOLDER_MIME, token)
    if not folder:
        if args.preview:
            print("PREVIEW: se tao thu muc private %s/%s." % (ROOT_NAME, CONFIG_NAME))
            print("PREVIEW_OK: chua ghi Google Drive.")
            return 0
        folder = make_folder(root["id"], CONFIG_NAME, token)
        print("DRIVE_CONFIG_FOLDER_CREATED: OK")
    assert_private_file(folder["id"], token, "config folder")
    existing = exact_files(folder["id"], FILE_NAME, None, token)
    if existing:
        assert_private_file(existing["id"], token, "existing snapshot")
        if existing.get("md5Checksum") == local_md5:
            verify_download(existing["id"], payload, token)
            print("DRIVE_FILE_PRESENT: identical; no write")
            print("DRIVE_VERIFY_OK: SHA256 match; accounts=%d" % count)
            print("GOOGLE_DRIVE_FILE_ID: %s" % existing["id"])
            return 0
        if not args.update_existing:
            print("DRIVE_EXISTING_DIFFERS: use -UpdateExisting only after checking desired MySQL export.")
            raise SyncFailure("Khong ghi de snapshot Drive khi chua duoc cho phep.")
        if args.preview:
            print("PREVIEW: would update existing private file once.")
            return 0
        obj = upload_overwrite(existing["id"], payload, token)
        operation = "UPDATED"
    else:
        if args.preview:
            print("PREVIEW: will create private %s/%s/%s." % (ROOT_NAME, CONFIG_NAME, FILE_NAME))
            print("PREVIEW_OK: chua ghi Google Drive.")
            return 0
        obj = upload_new(folder["id"], payload, token)
        operation = "CREATED"
    file_id = obj["id"]
    assert_private_file(file_id, token, "uploaded snapshot")
    if obj.get("md5Checksum") and obj["md5Checksum"] != local_md5:
        raise SyncFailure("VERIFY_FAILED: Google Drive md5Checksum khong khop.")
    verify_download(file_id, payload, token)
    print("DRIVE_UPLOAD_%s: OK" % operation)
    print("DRIVE_VERIFY_OK: SHA256 match; accounts=%d" % count)
    print("GOOGLE_DRIVE_FILE_ID: %s" % file_id)
    print("PRIVATE_FILE: My Drive/%s/%s/%s" % (ROOT_NAME, CONFIG_NAME, FILE_NAME))
    print("DO_NOT_SHARE_JSON_OR_TOKEN")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SyncFailure as exc:
        print("DRIVE_UPLOAD_ERROR: %s" % exc)
        raise SystemExit(1)
    except Exception as exc:
        print("DRIVE_UPLOAD_ERROR: unexpected %s; no secret or account data printed." % type(exc).__name__)
        raise SystemExit(1)
