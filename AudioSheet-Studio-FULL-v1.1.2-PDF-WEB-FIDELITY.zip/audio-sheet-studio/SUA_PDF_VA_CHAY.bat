@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PROJECT_PYTHON=%CD%\.venv\Scripts\python.exe"

echo ==================================================
echo  AudioSheet Studio 1.1.2 - Sua PDF giong giao dien web
echo ==================================================
echo.

if not exist "%PROJECT_PYTHON%" (
  echo [CAI DAT] Chua co moi truong website. Dang cai...
  call "%~dp0install_windows.bat"
  if errorlevel 1 goto :failure
)

echo [1/3] Kiem tra Chrome/Edge va OSMD local...
if not exist "web\vendor\opensheetmusicdisplay.min.js" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\download_osmd.ps1"
)

echo [2/3] Tao file PDF bang chinh giao dien OSMD...
"%PROJECT_PYTHON%" scripts\check_pdf.py
if errorlevel 1 goto :failure

echo [3/3] Mo thu muc file PDF kiem tra...
start "" "%CD%\data\pdf_test"

echo.
echo [OK] Neu PDF hien khuong nhac binh thuong, bo xuat OSMD da hoat dong.
echo Dang khoi dong website...
call "%~dp0run_windows.bat"
exit /b %ERRORLEVEL%

:failure
echo.
echo [LOI] Sua PDF that bai. Gui anh cua so nay de kiem tra.
pause
exit /b 1
