# AudioSheet Studio 1.1.2 - 2026-11-03

## PDF web-fidelity fix

- Removed the Verovio -> svglib -> ReportLab conversion from the active PDF path because it could enlarge or corrupt SMuFL music glyphs on Windows.
- Added Chrome/Edge/Chromium discovery and headless printing of the same OpenSheetMusicDisplay SVG used by the web interface.
- Added OSMD A4 portrait page layout (`pageFormat: "A4_P"`) for PDF output.
- Added a clean browser print page as an automatic fallback. It uses the same MusicXML endpoint and OSMD settings as the selected A/B/C score.
- Added `X-AudioSheet-PDF-Engine` so the frontend rejects an approximate server fallback and opens the exact browser print view instead.
- Invalid or old cached PDFs are regenerated under the v1.1.2 score signature.
- Existing jobs do not need to be transcribed again.

## Retained

- Demucs stem separation.
- Basic Pitch transcription.
- A/B/C arrangements, synchronized piano playback and MusicXML.
- MIDI, MusicXML and PDF controls for every arrangement.
