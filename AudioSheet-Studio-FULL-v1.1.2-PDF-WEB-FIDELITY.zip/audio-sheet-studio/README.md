# AudioSheet Studio 1.1.2

Local-first audio-to-sheet workflow for Windows:

- upload audio or use an allowed YouTube source;
- optionally separate vocals, bass, drums and other instruments with Demucs;
- transcribe notes with Basic Pitch;
- build A/B/C arrangements;
- display MusicXML with OpenSheetMusicDisplay;
- play the selected arrangement with local piano samples;
- export MIDI, MusicXML and PDF.

## PDF in v1.1.2

PDF is printed from the same OSMD SVG used by the browser UI through local Chrome,
Edge, Chromium or Brave. The former Verovio-to-svglib conversion is no longer used,
because it could corrupt SMuFL glyph scaling on Windows.

If automatic headless printing is unavailable, the PDF button opens a clean OSMD
print page and triggers the browser print dialog. Choose **Save as PDF**.

## Windows

1. Install Python 3.11 and FFmpeg.
2. Run `install_windows.bat` once, or just run `CHAY_WEBSITE.bat` and allow it to install missing components.
3. Open `http://127.0.0.1:8000`.
4. Keep the console window open.

See `HUONG_DAN_V1.1.2.txt` for the update and PDF workflow.
