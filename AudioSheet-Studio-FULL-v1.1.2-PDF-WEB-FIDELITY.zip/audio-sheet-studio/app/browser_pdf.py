from __future__ import annotations

import base64
import html
import os
import shutil
import tempfile
from pathlib import Path
from typing import Iterable

from .audio_tools import ExternalToolError, run_command
from .config import settings


class BrowserPDFError(RuntimeError):
    pass


def _unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for raw in values:
        value = str(raw or "").strip().strip('"')
        if not value:
            continue
        key = os.path.normcase(os.path.abspath(value)) if os.path.sep in value or "/" in value else value.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def find_browser() -> str | None:
    """Locate a Chromium browser suitable for headless PDF printing."""
    candidates: list[str] = [settings.browser_bin]

    if os.name == "nt":
        local_app = os.getenv("LOCALAPPDATA", "")
        program_files = os.getenv("ProgramFiles", "")
        program_files_x86 = os.getenv("ProgramFiles(x86)", "")
        program_w6432 = os.getenv("ProgramW6432", "")
        for base in (local_app, program_files, program_files_x86, program_w6432):
            if not base:
                continue
            candidates.extend(
                [
                    str(Path(base) / "Google" / "Chrome" / "Application" / "chrome.exe"),
                    str(Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
                    str(Path(base) / "Chromium" / "Application" / "chrome.exe"),
                    str(Path(base) / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe"),
                ]
            )

    candidates.extend(
        [
            "chrome",
            "chrome.exe",
            "msedge",
            "msedge.exe",
            "google-chrome",
            "google-chrome-stable",
            "chromium",
            "chromium-browser",
            "brave",
            "brave-browser",
        ]
    )

    for candidate in _unique(candidates):
        explicit = Path(candidate)
        if explicit.is_file():
            return str(explicit)
        located = shutil.which(candidate)
        if located:
            return located
    return None


def osmd_bundle_path() -> Path | None:
    path = settings.web_dir / "vendor" / "opensheetmusicdisplay.min.js"
    return path if path.is_file() and path.stat().st_size > 50_000 else None


def browser_pdf_available() -> bool:
    return bool(find_browser() and osmd_bundle_path())


def _build_print_html(musicxml_path: Path, html_path: Path, osmd_path: Path) -> None:
    xml_bytes = musicxml_path.read_bytes()
    xml_b64 = base64.b64encode(xml_bytes).decode("ascii")
    safe_title = html.escape(musicxml_path.stem, quote=True)
    script_uri = osmd_path.resolve().as_uri()

    # This page intentionally uses the same OSMD options as the visible web app.
    # Chrome/Edge prints the browser-rendered SVG directly, preserving SMuFL glyphs.
    content = f"""<!doctype html>
<html lang=\"vi\">
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
<title>{safe_title}</title>
<style>
  @page {{ size: A4 portrait; margin: 8mm 7mm 9mm; }}
  html, body {{ margin: 0; padding: 0; background: #fff; color: #000; }}
  body {{ font-family: Arial, \"Segoe UI\", sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
  #loading {{ position: fixed; inset: 0; display: grid; place-items: center; font-size: 14px; background: white; z-index: 5; }}
  body.ready #loading {{ display: none; }}
  #score {{ width: 196mm; max-width: 196mm; margin: 0 auto; overflow: visible; }}
  #score svg {{ display: block; max-width: 100% !important; height: auto !important; overflow: visible !important; break-after: page; page-break-after: always; }}
  #score svg:last-child {{ break-after: auto; page-break-after: auto; }}
  .error {{ white-space: pre-wrap; color: #a00; padding: 20mm; font-size: 12pt; }}
  @media print {{
    #loading {{ display: none !important; }}
    #score {{ width: 100%; max-width: none; margin: 0; }}
    #score svg {{ break-inside: auto; page-break-inside: auto; }}
  }}
</style>
<script src=\"{script_uri}\"></script>
</head>
<body>
<div id=\"loading\">Đang dựng sheet nhạc...</div>
<div id=\"score\"></div>
<script>
(() => {{
  const xmlBase64 = {xml_b64!r};
  function decodeBase64Utf8(value) {{
    const bytes = Uint8Array.from(atob(value), c => c.charCodeAt(0));
    return new TextDecoder('utf-8').decode(bytes);
  }}
  async function render() {{
    try {{
      if (!window.opensheetmusicdisplay || !window.opensheetmusicdisplay.OpenSheetMusicDisplay) {{
        throw new Error('OpenSheetMusicDisplay local bundle is unavailable');
      }}
      const container = document.getElementById('score');
      const osmd = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(container, {{
        autoResize: false,
        backend: 'svg',
        drawTitle: true,
        drawComposer: true,
        drawingParameters: 'compacttight',
        pageFormat: 'A4_P',
      }});
      osmd.Zoom = 0.82;
      await osmd.load(decodeBase64Utf8(xmlBase64));
      osmd.render();
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      if (document.fonts && document.fonts.ready) await document.fonts.ready;
      const readyMarker = document.createElement('div');
      readyMarker.textContent = 'AUDIOSHEET_OSMD_READY';
      readyMarker.style.cssText = 'position:fixed;left:0;bottom:0;font-size:1px;color:white;z-index:-1';
      document.body.appendChild(readyMarker);
      document.body.classList.add('ready');
      window.__AUDIOSHEET_PDF_READY__ = true;
      document.title = {safe_title!r};
    }} catch (error) {{
      document.getElementById('loading').className = 'error';
      document.getElementById('loading').textContent = 'PDF render error: ' + (error && error.message ? error.message : String(error));
      window.__AUDIOSHEET_PDF_ERROR__ = String(error);
    }}
  }}
  render();
}})();
</script>
</body>
</html>
"""
    html_path.write_text(content, encoding="utf-8")


def _chrome_commands(browser: str, html_uri: str, output_pdf: Path, profile_dir: Path) -> list[list[str]]:
    common = [
        browser,
        "--disable-gpu",
        "--no-sandbox",
        "--disable-dev-shm-usage",
        "--allow-file-access-from-files",
        "--disable-web-security",
        "--hide-scrollbars",
        "--run-all-compositor-stages-before-draw",
        "--virtual-time-budget=30000",
        "--no-pdf-header-footer",
        f"--user-data-dir={profile_dir}",
        f"--print-to-pdf={output_pdf}",
        html_uri,
    ]
    # Newer Chromium prefers --headless=new; older Chrome/Edge accepts --headless.
    return [[browser, "--headless=new", *common[1:]], [browser, "--headless", *common[1:]]]


def _pdf_contains_ready_marker(path: Path) -> bool:
    try:
        from pypdf import PdfReader

        reader = PdfReader(str(path))
        if not reader.pages:
            return False
        # The marker is appended only after OSMD has finished rendering.
        candidates = [reader.pages[0]]
        if len(reader.pages) > 1:
            candidates.append(reader.pages[-1])
        text = "\n".join((page.extract_text() or "") for page in candidates)
        return "AUDIOSHEET_OSMD_READY" in text
    except Exception:
        return False


def export_with_browser_osmd(musicxml_path: Path, pdf_path: Path) -> bool:
    browser = find_browser()
    osmd_path = osmd_bundle_path()
    if not browser or not osmd_path:
        return False

    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_pdf = pdf_path.with_suffix(".browser.tmp.pdf")
    temporary_pdf.unlink(missing_ok=True)

    with tempfile.TemporaryDirectory(prefix="audiosheet-pdf-") as temp_dir_raw:
        temp_dir = Path(temp_dir_raw)
        html_path = temp_dir / "score.html"
        profile_dir = temp_dir / "chrome-profile"
        profile_dir.mkdir(parents=True, exist_ok=True)
        _build_print_html(musicxml_path, html_path, osmd_path)

        errors: list[str] = []
        for command in _chrome_commands(browser, html_path.resolve().as_uri(), temporary_pdf, profile_dir):
            temporary_pdf.unlink(missing_ok=True)
            try:
                run_command(command, timeout=45)
            except ExternalToolError as exc:
                # Some Chromium builds finish writing the PDF but keep a helper
                # process alive. Accept the completed file before trying again.
                if (
                    temporary_pdf.is_file()
                    and temporary_pdf.stat().st_size > 1000
                    and _pdf_contains_ready_marker(temporary_pdf)
                ):
                    temporary_pdf.replace(pdf_path)
                    return True
                errors.append(str(exc))
                continue
            if (
                temporary_pdf.is_file()
                and temporary_pdf.stat().st_size > 1000
                and _pdf_contains_ready_marker(temporary_pdf)
            ):
                temporary_pdf.replace(pdf_path)
                return True
        temporary_pdf.unlink(missing_ok=True)
        if errors:
            raise BrowserPDFError(errors[-1][-1200:])
    return False
