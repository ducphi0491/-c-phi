from __future__ import annotations

import importlib.metadata
import json
import logging
import shutil
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .audio_tools import (
    download_youtube,
    estimate_bpm,
    normalize_audio,
    prepare_separation_audio,
    prepare_stem_for_ai,
)
from .config import APP_VERSION, settings
from .job_store import job_store
from .live_score import create_arrangement_xml
from .pdf_export import PDFExportError, export_musicxml_to_pdf, pdf_engine_status
from .playback_modes import (
    clean_notes,
    prepare_stem_variants,
    prepare_variants,
    write_mode_midi,
)
from .stem_separator import DemucsUnavailableError, demucs_info, separate_stems
from .transcriber import transcribe_to_files


_executor = ThreadPoolExecutor(max_workers=settings.worker_count, thread_name_prefix="audio-sheet")
VARIANTS = ("melody", "light", "full")
VARIANT_LETTERS = {"melody": "A", "light": "B", "full": "C"}
VARIANT_TITLES = {
    "melody": "Giai điệu hát",
    "light": "Piano dễ chơi",
    "full": "Phiên âm đầy đủ",
}


def _artifact(job_id: str, filename: str, label: str, kind: str, variant: str | None = None) -> dict[str, str]:
    item = {
        "filename": filename,
        "label": label,
        "kind": kind,
        "url": f"/api/jobs/{job_id}/files/{filename}",
    }
    if variant:
        item["variant"] = variant
    return item


def _write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def _package_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _friendly_error(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    lowered = text.lower()
    if isinstance(exc, DemucsUnavailableError) or "demucs" in lowered:
        return (
            text[:460]
            + " Chạy CAI_DEMUCS_AI.bat một lần, sau đó mở lại CHAY_WEBSITE.bat. "
              "Bạn cũng có thể bỏ chọn 'Tự động tách giọng và nhạc cụ' để dùng chế độ dự phòng."
        )[:700]
    if "no notes" in lowered or "no stable notes" in lowered:
        return "Không phát hiện được nốt ổn định. Hãy thử bản thu rõ hơn hoặc giảm ngưỡng nhận dạng."
    if "tensorflow" in lowered or "basic pitch" in lowered or "saved model" in lowered:
        detail = " ".join(text.split())[:440]
        return (
            f"Lỗi mô hình nhận dạng ({type(exc).__name__}): {detail}. "
            "Mở processor.log hoặc chạy scripts/diagnose_ai.py để xem chi tiết."
        )
    if "ffmpeg" in lowered or "ffprobe" in lowered:
        return "FFmpeg bị thiếu hoặc không thể đọc file âm thanh này."
    if "youtube" in lowered or "yt-dlp" in lowered:
        return text[:650]
    return text[:650]


def submit_job(job_id: str) -> None:
    _executor.submit(_process_job, job_id)


def _transcribe_stem(
    *,
    audio_path: Path,
    output_dir: Path,
    prefix: str,
    source: str,
    bpm: float,
    minimum_midi: int,
    maximum_midi: int,
    onset_threshold: float,
    frame_threshold: float,
    minimum_note_length_ms: float,
) -> list[dict[str, Any]]:
    return transcribe_to_files(
        audio_path=audio_path,
        output_dir=output_dir,
        prefix=prefix,
        source=source,
        bpm=bpm,
        minimum_midi=minimum_midi,
        maximum_midi=maximum_midi,
        onset_threshold=onset_threshold,
        frame_threshold=frame_threshold,
        minimum_note_length_ms=minimum_note_length_ms,
    )


def _create_arrangement_files(
    job_id: str,
    directory: Path,
    job: dict[str, Any],
    payload: dict[str, Any],
    processor_log: logging.Logger,
) -> tuple[list[dict[str, str]], dict[str, Any]]:
    artifacts: list[dict[str, str]] = []
    analysis = payload.get("analysis") if isinstance(payload.get("analysis"), dict) else {}
    key_info = analysis.get("key") if isinstance(analysis.get("key"), dict) else {}
    chords = analysis.get("chords") if isinstance(analysis.get("chords"), list) else []
    pdf_results: dict[str, Any] = {}

    for variant in VARIANTS:
        mode = payload["modes"][variant]
        notes = mode.get("notes") if isinstance(mode, dict) else []
        if not notes:
            continue
        letter = VARIANT_LETTERS[variant]
        title = f"{job.get('title') or job.get('source_name') or 'AudioSheet Studio'} - {letter}. {VARIANT_TITLES[variant]}"
        midi_path = directory / f"sheet_{letter}_{variant}.mid"
        xml_path = directory / f"sheet_{letter}_{variant}.musicxml"
        pdf_path = directory / f"sheet_{letter}_{variant}.pdf"

        write_mode_midi(notes, str(midi_path), bpm=float(job.get("bpm_used") or 100))
        xml = create_arrangement_xml(
            notes,
            variant,
            title=title,
            bpm=float(job.get("bpm_used") or 100),
            time_signature=str(job.get("time_signature") or "4/4"),
            quantization=int(job.get("quantization") or 16),
            split_pitch=int(job.get("split_pitch") or 60),
            duration_seconds=float(payload.get("duration_seconds") or job.get("duration_seconds") or 0),
            key_fifths=int(key_info.get("fifths") or 0),
            chords=chords,
        )
        xml_path.write_bytes(xml)

        artifacts.extend(
            [
                _artifact(job_id, pdf_path.name, f"PDF {letter} · {VARIANT_TITLES[variant]}", "pdf", variant),
                _artifact(job_id, xml_path.name, f"MusicXML {letter} · {VARIANT_TITLES[variant]}", "musicxml", variant),
                _artifact(job_id, midi_path.name, f"MIDI {letter} · {VARIANT_TITLES[variant]}", "midi", variant),
            ]
        )
        if settings.export_pdf:
            try:
                engine = export_musicxml_to_pdf(xml_path, pdf_path)
                pdf_results[variant] = {"ok": True, "engine": engine, "filename": pdf_path.name}
            except PDFExportError as exc:
                # Remove the pre-declared PDF artifact if rendering failed.
                artifacts = [item for item in artifacts if item["filename"] != pdf_path.name]
                pdf_results[variant] = {"ok": False, "error": str(exc)[:300]}
                processor_log.warning("PDF export failed for %s: %s", variant, exc)
        else:
            artifacts = [item for item in artifacts if item["filename"] != pdf_path.name]
            pdf_results[variant] = {"ok": False, "error": "PDF export disabled"}

    # Compatibility aliases point to the arrangement matching the form choice.
    default_variant = "melody" if job.get("mode") == "lead" else "full" if job.get("mode") == "raw" else "light"
    default_letter = VARIANT_LETTERS[default_variant]
    default_xml = directory / f"sheet_{default_letter}_{default_variant}.musicxml"
    default_midi = directory / f"sheet_{default_letter}_{default_variant}.mid"
    default_pdf = directory / f"sheet_{default_letter}_{default_variant}.pdf"
    if default_xml.is_file():
        shutil.copy2(default_xml, directory / "sheet.musicxml")
        artifacts.append(_artifact(job_id, "sheet.musicxml", "Sheet mặc định", "musicxml", default_variant))
    if default_midi.is_file():
        shutil.copy2(default_midi, directory / "transcription.mid")
        artifacts.append(_artifact(job_id, "transcription.mid", "MIDI mặc định", "midi", default_variant))
    if default_pdf.is_file():
        shutil.copy2(default_pdf, directory / "sheet.pdf")
        artifacts.append(_artifact(job_id, "sheet.pdf", "PDF mặc định", "pdf", default_variant))
    return artifacts, pdf_results


def _process_job(job_id: str) -> None:
    directory = job_store.job_dir(job_id)
    log_path = directory / "processor.log"
    processor_log = logging.getLogger(f"audio_sheet.processor.{job_id}")
    processor_log.setLevel(logging.INFO)
    processor_log.propagate = False
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    processor_log.addHandler(file_handler)
    try:
        job = job_store.get(job_id)
        source_type = job["source_type"]
        source_path: Path

        if source_type == "youtube":
            job_store.update(job_id, status="fetching", progress=5, message="Đang lấy âm thanh từ nguồn YouTube")
            source_path, metadata = download_youtube(
                job["youtube_url"],
                output_dir=directory,
                max_seconds=settings.max_audio_seconds,
                max_bytes=settings.max_upload_mb * 1024 * 1024,
            )
            source_name = str(metadata.get("title") or "YouTube audio")[:200]
            title = job.get("title") or source_name
            job = job_store.update(job_id, source_name=source_name, title=title)
        else:
            source_path = directory / job["source_filename"]

        job_store.update(job_id, status="normalizing", progress=14, message="Đang chuẩn hóa âm thanh bằng FFmpeg")
        normalized_path = directory / "normalized.wav"
        duration = normalize_audio(source_path, normalized_path, settings.max_audio_seconds)
        requested_bpm = float(job.get("bpm_requested") or 0)
        bpm = requested_bpm if requested_bpm > 0 else estimate_bpm(normalized_path)
        bpm = max(40.0, min(240.0, float(bpm)))
        job = job_store.update(
            job_id,
            duration_seconds=round(duration, 2),
            bpm_used=round(bpm, 1),
            progress=20,
            message=f"Đã chuẩn bị âm thanh · {bpm:.1f} BPM",
        )

        use_stems = bool(job.get("separate_stems", settings.auto_separate_stems))
        if use_stems:
            job_store.update(job_id, status="separating", progress=24, message="Demucs đang tách vocal, bass, trống và nhạc đệm")
            separation_input = directory / "separation_input.wav"
            prepare_separation_audio(source_path, separation_input, settings.max_audio_seconds, duration=duration)
            stem_dir = directory / "stems"
            stems = separate_stems(separation_input, stem_dir, log_path=directory / "demucs.log")

            ai_stem_dir = directory / "stems_ai"
            ai_stem_dir.mkdir(parents=True, exist_ok=True)
            ai_stems: dict[str, Path] = {}
            for stem_name in ("vocals", "bass", "other"):
                target = ai_stem_dir / f"{stem_name}_22050_mono.wav"
                prepare_stem_for_ai(stems[stem_name], target, settings.max_audio_seconds, duration=duration)
                ai_stems[stem_name] = target

            job_store.update(job_id, status="transcribing", progress=49, message="Đang nhận dạng giai điệu từ stem giọng hát")
            vocal_notes = _transcribe_stem(
                audio_path=ai_stems["vocals"], output_dir=directory, prefix="notes_vocals_raw", source="vocals",
                bpm=bpm,
                minimum_midi=max(40, int(job["minimum_midi"])),
                maximum_midi=min(96, int(job["maximum_midi"])),
                onset_threshold=max(0.32, float(job["onset_threshold"]) - 0.07),
                frame_threshold=max(0.20, float(job["frame_threshold"]) - 0.05),
                minimum_note_length_ms=max(70.0, float(job["minimum_note_length_ms"]) * 0.72),
            )
            job_store.update(job_id, status="transcribing", progress=60, message="Đang nhận dạng đường bass")
            bass_notes = _transcribe_stem(
                audio_path=ai_stems["bass"], output_dir=directory, prefix="notes_bass_raw", source="bass",
                bpm=bpm,
                minimum_midi=max(24, min(40, int(job["minimum_midi"]))),
                maximum_midi=min(72, int(job["maximum_midi"])),
                onset_threshold=max(0.38, float(job["onset_threshold"]) - 0.03),
                frame_threshold=max(0.24, float(job["frame_threshold"])),
                minimum_note_length_ms=max(90.0, float(job["minimum_note_length_ms"])),
            )
            job_store.update(job_id, status="transcribing", progress=69, message="Đang nhận dạng hợp âm và nhạc cụ đệm")
            other_notes = _transcribe_stem(
                audio_path=ai_stems["other"], output_dir=directory, prefix="notes_other_raw", source="other",
                bpm=bpm,
                minimum_midi=int(job["minimum_midi"]),
                maximum_midi=int(job["maximum_midi"]),
                onset_threshold=float(job["onset_threshold"]),
                frame_threshold=float(job["frame_threshold"]),
                minimum_note_length_ms=float(job["minimum_note_length_ms"]),
            )
            payload = prepare_stem_variants(
                vocal_notes,
                bass_notes,
                other_notes,
                bpm=bpm,
                time_signature=str(job["time_signature"]),
                duration_seconds=duration,
                split_pitch=int(job["split_pitch"]),
            )
        else:
            job_store.update(job_id, status="transcribing", progress=43, message="Đang nhận dạng nốt trên bản phối đầy đủ (không tách stem)")
            raw_notes = _transcribe_stem(
                audio_path=normalized_path, output_dir=directory, prefix="notes_full_mix_raw", source="full_mix",
                bpm=bpm,
                minimum_midi=int(job["minimum_midi"]),
                maximum_midi=int(job["maximum_midi"]),
                onset_threshold=float(job["onset_threshold"]),
                frame_threshold=float(job["frame_threshold"]),
                minimum_note_length_ms=float(job["minimum_note_length_ms"]),
            )
            payload = prepare_variants(
                raw_notes,
                bpm=bpm,
                time_signature=str(job["time_signature"]),
                split_pitch=int(job["split_pitch"]),
            )

        if not any(payload["modes"][name]["notes"] for name in VARIANTS):
            raise ValueError("No notes were detected in the audio")

        job_store.update(job_id, status="arranging", progress=80, message="Đang làm sạch nốt, phân tích hợp âm và tạo ba bản A/B/C")
        arrangements_path = directory / "arrangements.json"
        _write_json(arrangements_path, payload)
        _write_json(directory / "analysis.json", payload.get("analysis", {}))
        full_notes = payload["modes"]["full"]["notes"]
        _write_json(directory / "note_events.json", full_notes)
        _write_json(directory / "note_events_clean.json", clean_notes(full_notes))

        # Refresh job data before generating files so BPM and metadata are current.
        job = job_store.get(job_id)
        job_store.update(job_id, status="exporting", progress=90, message="Đang xuất MusicXML, MIDI và PDF cho A/B/C")
        arrangement_artifacts, pdf_results = _create_arrangement_files(job_id, directory, job, payload, processor_log)

        manifest = {
            "app_version": APP_VERSION,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "pipeline": payload.get("pipeline"),
            "separator": demucs_info() if use_stems else {"available": False, "used": False},
            "transcriber": {"name": "basic-pitch", "version": _package_version("basic-pitch")},
            "notation": {"name": "AudioSheet MusicXML", "music21_version": _package_version("music21")},
            "pdf": {"engines": pdf_engine_status(), "results": pdf_results},
            "bpm": bpm,
            "time_signature": job.get("time_signature"),
            "quantization": job.get("quantization"),
            "duration_seconds": duration,
            "analysis": payload.get("analysis", {}),
            "counts": {
                name: payload["modes"][name]["count"] for name in VARIANTS
            },
        }
        _write_json(directory / "pipeline_manifest.json", manifest)

        artifacts: list[dict[str, str]] = arrangement_artifacts + [
            _artifact(job_id, arrangements_path.name, "Dữ liệu ba chế độ A/B/C", "json"),
            _artifact(job_id, "analysis.json", "Phân tích giọng và hợp âm", "json"),
            _artifact(job_id, "pipeline_manifest.json", "Thông tin model và pipeline", "json"),
            _artifact(job_id, "note_events.json", "Nốt đã dùng cho chế độ C", "json"),
            _artifact(job_id, normalized_path.name, "Âm thanh gốc đã chuẩn hóa", "audio"),
        ]
        if use_stems:
            for stem_name, label in (
                ("vocals", "Stem giọng hát"),
                ("bass", "Stem bass"),
                ("other", "Stem nhạc cụ khác"),
                ("drums", "Stem trống"),
            ):
                path = directory / "stems" / f"{stem_name}.wav"
                if path.is_file():
                    public_name = f"stem_{stem_name}.wav"
                    shutil.copy2(path, directory / public_name)
                    artifacts.append(_artifact(job_id, public_name, label, "stem_audio"))

        if not settings.keep_source_audio and source_path != normalized_path:
            try:
                source_path.unlink(missing_ok=True)
            except OSError:
                pass

        job_store.update(
            job_id,
            status="done",
            progress=100,
            message="Đã tạo xong sheet, MIDI và PDF cho ba chế độ A/B/C",
            artifacts=artifacts,
            pipeline=str(payload.get("pipeline") or "unknown"),
            detected_key=str(payload.get("analysis", {}).get("key", {}).get("name") or ""),
            pdf_ready=all(result.get("ok") for result in pdf_results.values()) if pdf_results else False,
            error=None,
        )
    except Exception as exc:
        processor_log.exception("Job %s failed", job_id)
        try:
            job_store.update(
                job_id,
                status="failed",
                progress=100,
                message="Xử lý thất bại",
                error=_friendly_error(exc),
            )
        except Exception:
            processor_log.exception("Could not record failure for job %s", job_id)
    finally:
        processor_log.removeHandler(file_handler)
        file_handler.close()
