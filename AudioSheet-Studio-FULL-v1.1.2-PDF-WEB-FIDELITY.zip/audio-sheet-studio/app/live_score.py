"""Generate per-arrangement MusicXML without re-running the AI models.

A/B/C sound, MIDI, MusicXML and PDF are all created from the exact same note
list. Piano modes use one Piano part with two staves rather than two unrelated
instruments, which improves editing and export in MuseScore and other notation
software.
"""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from xml.etree import ElementTree as ET

DIVISIONS = 480
MAX_PART_VOICES = 8
MAX_MEASURES = 1200
PITCH_NAMES = ("C", "C", "D", "D", "E", "F", "F", "G", "G", "A", "A", "B")
SHARP_PCS = {1, 3, 6, 8, 10}


@dataclass
class NoteGroup:
    start: int
    end: int
    pitches: tuple[int, ...]
    voice: int = 1


def _add(parent: ET.Element, tag: str, value: str | int | float | None = None, **attrs: str) -> ET.Element:
    child = ET.SubElement(parent, tag, attrs)
    if value is not None:
        child.text = str(value)
    return child


def _duration_chunks(ticks: int) -> list[tuple[int, str, bool]]:
    options: list[tuple[int, str, bool]] = []
    for length, kind in (
        (1920, "whole"),
        (960, "half"),
        (480, "quarter"),
        (240, "eighth"),
        (120, "16th"),
        (60, "32nd"),
        (30, "64th"),
    ):
        options.append((length * 3 // 2, kind, True))
        options.append((length, kind, False))
    options.sort(key=lambda item: item[0], reverse=True)
    chunks: list[tuple[int, str, bool]] = []
    remaining = max(1, ticks)
    while remaining > 0:
        duration, kind, dotted = next((item for item in options if item[0] <= remaining), (30, "64th", False))
        chunks.append((duration, kind, dotted))
        remaining -= duration
    return chunks


def _safely_round(value: float, step: int) -> int:
    return int(round(value / step)) * step


def _pitch_xml(parent: ET.Element, midi_pitch: int) -> None:
    pitch = _add(parent, "pitch")
    pitch_class = midi_pitch % 12
    _add(pitch, "step", PITCH_NAMES[pitch_class])
    if pitch_class in SHARP_PCS:
        _add(pitch, "alter", 1)
    _add(pitch, "octave", midi_pitch // 12 - 1)


def _emit_note(
    parent: ET.Element,
    pitches: tuple[int, ...] | None,
    duration: int,
    kind: str,
    dotted: bool,
    voice: int,
    staff: int,
    tie_stop: bool = False,
    tie_start: bool = False,
) -> None:
    for index, pitch in enumerate(pitches if pitches is not None else (None,)):
        note = _add(parent, "note")
        if index > 0:
            _add(note, "chord")
        if pitch is None:
            _add(note, "rest")
        else:
            _pitch_xml(note, pitch)
        _add(note, "duration", duration)
        if pitch is not None and tie_stop:
            _add(note, "tie", type="stop")
        if pitch is not None and tie_start:
            _add(note, "tie", type="start")
        _add(note, "voice", voice)
        _add(note, "type", kind)
        if dotted:
            _add(note, "dot")
        _add(note, "staff", staff)
        if pitch is not None and (tie_start or tie_stop):
            notations = _add(note, "notations")
            if tie_stop:
                _add(notations, "tied", type="stop")
            if tie_start:
                _add(notations, "tied", type="start")


def _write_duration(
    parent: ET.Element,
    pitches: tuple[int, ...] | None,
    ticks: int,
    voice: int,
    staff: int,
    continuation_before: bool = False,
    continuation_after: bool = False,
) -> None:
    chunks = _duration_chunks(ticks)
    for index, (duration, kind, dotted) in enumerate(chunks):
        _emit_note(
            parent,
            pitches,
            duration,
            kind,
            dotted,
            voice,
            staff,
            tie_stop=(index > 0 or continuation_before) if pitches else False,
            tie_start=(index < len(chunks) - 1 or continuation_after) if pitches else False,
        )


def _place_voices(notes: list[dict], bpm: float, quantum: int) -> list[NoteGroup]:
    groups: dict[tuple[int, int], set[int]] = defaultdict(set)
    scale = bpm / 60.0 * DIVISIONS
    for note in notes:
        try:
            start = float(note["start"])
            end = float(note["end"])
            pitch = int(note["pitch"])
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
            continue
        if not 0 <= pitch <= 127 or start > 1200:
            continue
        onset = max(0, _safely_round(start * scale, quantum))
        stop = max(onset + quantum, _safely_round(end * scale, quantum))
        groups[(onset, stop)].add(pitch)
    chunks = [NoteGroup(start, end, tuple(sorted(pitches))) for (start, end), pitches in groups.items()]
    chunks.sort(key=lambda item: (item.start, item.end, item.pitches))
    lanes: list[int] = []
    for group in chunks:
        for index, lane_end in enumerate(lanes):
            if lane_end <= group.start:
                lanes[index] = group.end
                group.voice = index + 1
                break
        else:
            if len(lanes) < MAX_PART_VOICES:
                lanes.append(group.end)
                group.voice = len(lanes)
            else:
                lane_index = min(range(len(lanes)), key=lanes.__getitem__)
                lanes[lane_index] = group.end
                group.voice = lane_index + 1
    return chunks


def _measure_segments(
    groups: list[NoteGroup],
    ticks_per_measure: int,
) -> dict[tuple[int, int], list[tuple[int, int, tuple[int, ...], bool, bool]]]:
    result: dict[tuple[int, int], list[tuple[int, int, tuple[int, ...], bool, bool]]] = defaultdict(list)
    for group in groups:
        cursor = group.start
        while cursor < group.end:
            bar = cursor // ticks_per_measure
            local = cursor % ticks_per_measure
            stop = min(group.end, (bar + 1) * ticks_per_measure)
            result[(bar, group.voice)].append(
                (local, stop - cursor, group.pitches, cursor > group.start, stop < group.end)
            )
            cursor = stop
    return result


def _render_voice(
    measure: ET.Element,
    entries: list[tuple[int, int, tuple[int, ...], bool, bool]],
    ticks_per_measure: int,
    voice: int,
    staff: int,
) -> None:
    offset = 0
    for local, span, pitches, tied_from, tied_to in sorted(entries):
        if local > offset:
            _write_duration(measure, None, local - offset, voice, staff)
        _write_duration(measure, pitches, span, voice, staff, tied_from, tied_to)
        offset = local + span
    if offset < ticks_per_measure:
        _write_duration(measure, None, ticks_per_measure - offset, voice, staff)


def _add_backup(measure: ET.Element, duration: int) -> None:
    backup = _add(measure, "backup")
    _add(backup, "duration", duration)


def _harmony_xml(measure: ET.Element, chord: dict, local_ticks: int) -> None:
    root_pc = int(chord.get("root", 0)) % 12
    quality = str(chord.get("quality", "major"))
    harmony = _add(measure, "harmony")
    root = _add(harmony, "root")
    _add(root, "root-step", PITCH_NAMES[root_pc])
    if root_pc in SHARP_PCS:
        _add(root, "root-alter", 1)
    kind_map = {
        "major": ("major", ""),
        "minor": ("minor", "m"),
        "dim": ("diminished", "dim"),
        "sus4": ("suspended-fourth", "sus4"),
    }
    value, text = kind_map.get(quality, ("major", ""))
    kind = _add(harmony, "kind", value)
    if text:
        kind.set("text", text)
    if local_ticks:
        _add(harmony, "offset", local_ticks)


def _write_attributes(
    measure: ET.Element,
    beats: int,
    beat_type: int,
    key_fifths: int,
    two_staves: bool,
) -> None:
    attrs = _add(measure, "attributes")
    _add(attrs, "divisions", DIVISIONS)
    key = _add(attrs, "key")
    _add(key, "fifths", max(-7, min(7, int(key_fifths))))
    time = _add(attrs, "time")
    _add(time, "beats", beats)
    _add(time, "beat-type", beat_type)
    if two_staves:
        _add(attrs, "staves", 2)
        treble = _add(attrs, "clef", number="1")
        _add(treble, "sign", "G")
        _add(treble, "line", 2)
        bass = _add(attrs, "clef", number="2")
        _add(bass, "sign", "F")
        _add(bass, "line", 4)
    else:
        clef = _add(attrs, "clef")
        _add(clef, "sign", "G")
        _add(clef, "line", 2)


def _write_tempo(measure: ET.Element, bpm: float) -> None:
    direction = _add(measure, "direction", placement="above")
    direction_type = _add(direction, "direction-type")
    metronome = _add(direction_type, "metronome")
    _add(metronome, "beat-unit", "quarter")
    _add(metronome, "per-minute", round(bpm, 2))
    _add(direction, "sound", tempo=str(round(bpm, 2)))


def _render_score_part(
    root: ET.Element,
    right_groups: list[NoteGroup],
    left_groups: list[NoteGroup],
    beats: int,
    beat_type: int,
    bar_count: int,
    ticks_per_measure: int,
    bpm: float,
    key_fifths: int,
    chords: list[dict],
    two_staves: bool,
) -> None:
    part = _add(root, "part", id="P1")
    right_segments = _measure_segments(right_groups, ticks_per_measure)
    left_segments = _measure_segments(left_groups, ticks_per_measure)
    ticks_per_second = bpm / 60.0 * DIVISIONS

    for bar in range(bar_count):
        measure = _add(part, "measure", number=str(bar + 1))
        if bar == 0:
            _write_attributes(measure, beats, beat_type, key_fifths, two_staves)
            _write_tempo(measure, bpm)

        measure_start = bar * ticks_per_measure
        measure_end = measure_start + ticks_per_measure
        for chord in chords:
            chord_tick = int(round(float(chord.get("start", 0)) * ticks_per_second))
            if measure_start <= chord_tick < measure_end:
                _harmony_xml(measure, chord, max(0, chord_tick - measure_start))

        right_voices = sorted(voice for (measure_index, voice) in right_segments if measure_index == bar)
        if not right_voices:
            _write_duration(measure, None, ticks_per_measure, 1, 1)
        else:
            for index, voice in enumerate(right_voices):
                if index:
                    _add_backup(measure, ticks_per_measure)
                _render_voice(measure, right_segments[(bar, voice)], ticks_per_measure, voice, 1)

        if two_staves:
            _add_backup(measure, ticks_per_measure)
            left_voices = sorted(voice for (measure_index, voice) in left_segments if measure_index == bar)
            if not left_voices:
                _write_duration(measure, None, ticks_per_measure, 5, 2)
            else:
                for index, voice in enumerate(left_voices):
                    if index:
                        _add_backup(measure, ticks_per_measure)
                    _render_voice(measure, left_segments[(bar, voice)], ticks_per_measure, voice + 4, 2)


def create_arrangement_xml(
    notes: list[dict],
    mode: str,
    title: str,
    bpm: float = 100,
    time_signature: str = "4/4",
    quantization: int = 16,
    split_pitch: int = 60,
    duration_seconds: float = 0,
    key_fifths: int = 0,
    chords: list[dict] | None = None,
) -> bytes:
    if mode not in {"melody", "light", "full"}:
        raise ValueError("Invalid sheet mode")
    if not 30 <= float(bpm) <= 250:
        bpm = 100.0
    if quantization not in {8, 16, 32}:
        quantization = 16
    if time_signature not in {"4/4", "3/4", "6/8"}:
        time_signature = "4/4"
    beats, beat_type = map(int, time_signature.split("/"))
    measure_ticks = DIVISIONS * 4 * beats // beat_type
    quantum = DIVISIONS * 4 // quantization
    valid = [note for note in notes if isinstance(note, dict)]
    if not valid:
        raise ValueError("No notes in this arrangement")

    if mode == "melody":
        right = valid
        left: list[dict] = []
    elif mode == "light":
        right = [note for note in valid if note.get("staff") != "lower"]
        left = [note for note in valid if note.get("staff") == "lower"]
    else:
        right = [
            note for note in valid
            if note.get("staff") == "upper" or (not note.get("staff") and int(note.get("pitch", 60)) >= split_pitch)
        ]
        left = [
            note for note in valid
            if note.get("staff") == "lower" or (not note.get("staff") and int(note.get("pitch", 60)) < split_pitch)
        ]

    right_groups = _place_voices(right, bpm, quantum)
    left_groups = _place_voices(left, bpm, quantum)
    final_tick = max(
        [int(max(0, duration_seconds) * bpm / 60 * DIVISIONS)]
        + [group.end for group in right_groups + left_groups]
    )
    bar_count = max(1, min(MAX_MEASURES, math.ceil(final_tick / measure_ticks)))
    two_staves = mode != "melody"

    root = ET.Element("score-partwise", version="4.0")
    work = _add(root, "work")
    _add(work, "work-title", title[:160] or "AudioSheet Studio")
    _add(root, "movement-title", title[:160] or "AudioSheet Studio")
    identification = _add(root, "identification")
    _add(identification, "creator", "Generated by AudioSheet Studio 1.1.2", type="composer")
    encoding = _add(identification, "encoding")
    _add(encoding, "software", "AudioSheet Studio 1.1.2")
    defaults = _add(root, "defaults")
    scaling = _add(defaults, "scaling")
    _add(scaling, "millimeters", 7)
    _add(scaling, "tenths", 40)
    part_list = _add(root, "part-list")
    part_def = _add(part_list, "score-part", id="P1")
    _add(part_def, "part-name", "Melody" if not two_staves else "Piano")
    _add(part_def, "part-abbreviation", "Mel." if not two_staves else "Pno.")
    score_instrument = _add(part_def, "score-instrument", id="P1-I1")
    _add(score_instrument, "instrument-name", "Voice" if not two_staves else "Piano")
    midi_instrument = _add(part_def, "midi-instrument", id="P1-I1")
    _add(midi_instrument, "midi-channel", 1)
    _add(midi_instrument, "midi-program", 1)

    _render_score_part(
        root,
        right_groups,
        left_groups,
        beats,
        beat_type,
        bar_count,
        measure_ticks,
        bpm,
        key_fifths,
        chords or [],
        two_staves,
    )
    xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    declaration_end = xml.find(b"?>") + 2
    doctype = b'<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">\n'
    return xml[:declaration_end] + b"\n" + doctype + xml[declaration_end:]
