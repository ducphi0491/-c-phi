"""Arrangement and playback pipelines for AudioSheet Studio.

Version 1.1 has two paths:

* New jobs: Demucs separates vocals, bass, drums and other. Basic Pitch then
  transcribes the pitched stems separately. Modes A/B/C are built from different
  source material instead of three filters over one mixed transcription.
* Old jobs: the original full-mix note_events.json is still supported through a
  conservative fallback arranger.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Iterable, Sequence

MAX_EVENTS = 60000
PITCH_CLASS_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
MAJOR_PROFILE = (6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
MINOR_PROFILE = (6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)


def _quantile(values: Sequence[int | float], portion: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * portion)))
    return ordered[index]


def clean_notes(
    raw: Iterable[dict[str, Any]],
    default_source: str | None = None,
) -> list[dict[str, Any]]:
    """Validate and time-sort note events while retaining useful metadata."""
    notes: list[dict[str, Any]] = []
    for index, item in enumerate(raw):
        if index >= MAX_EVENTS:
            break
        if not isinstance(item, dict):
            continue
        try:
            start = float(item["start"])
            end = float(item["end"])
            pitch = int(item["pitch"])
            velocity = int(round(float(item.get("velocity", 80))))
        except (TypeError, ValueError, KeyError, OverflowError):
            continue
        if not all(map(math.isfinite, (start, end))):
            continue
        if start < 0 or start > 3600 or end <= start + 0.025:
            continue
        if not 0 <= pitch <= 127:
            continue
        note: dict[str, Any] = {
            "start": round(start, 5),
            "end": round(min(end, start + 18), 5),
            "pitch": pitch,
            "velocity": max(1, min(127, velocity)),
        }
        for key in ("staff", "role", "source", "generated"):
            if key in item:
                note[key] = item[key]
        if default_source and not note.get("source"):
            note["source"] = default_source
        for key in ("confidence", "amplitude"):
            if key in item:
                try:
                    value = float(item[key])
                    if math.isfinite(value):
                        note[key] = max(0.0, min(1.0, value))
                except (TypeError, ValueError, OverflowError):
                    pass
        notes.append(note)
    notes.sort(key=lambda n: (float(n["start"]), -int(n["pitch"]), -int(n["velocity"])))
    return notes


def merge_fragments(notes: list[dict[str, Any]], max_gap: float = 0.055) -> list[dict[str, Any]]:
    """Join short, nearly attached fragments of the same note conservatively."""
    by_key: dict[tuple[int, str, str], list[dict[str, Any]]] = defaultdict(list)
    for note in notes:
        by_key[(int(note["pitch"]), str(note.get("source") or ""), str(note.get("staff") or ""))].append(note)
    result: list[dict[str, Any]] = []
    for _, group in by_key.items():
        group.sort(key=lambda n: float(n["start"]))
        previous: dict[str, Any] | None = None
        for note in group:
            if previous is None:
                previous = dict(note)
                continue
            gap = float(note["start"]) - float(previous["end"])
            part_length = float(note["end"]) - float(note["start"])
            previous_span = float(previous["end"]) - float(previous["start"])
            joined = (
                -0.025 <= gap <= max_gap
                and part_length <= 0.75
                and previous_span <= 3.5
                and abs(int(note["velocity"]) - int(previous["velocity"])) <= 24
            )
            if joined:
                previous["end"] = round(max(float(previous["end"]), float(note["end"])), 5)
                previous["velocity"] = max(int(previous["velocity"]), int(note["velocity"]))
                if "confidence" in previous or "confidence" in note:
                    previous["confidence"] = max(float(previous.get("confidence", 0)), float(note.get("confidence", 0)))
            else:
                result.append(previous)
                previous = dict(note)
        if previous is not None:
            result.append(previous)
    result.sort(key=lambda n: (float(n["start"]), -int(n["pitch"])))
    return result


def suppress_octave_harmonics(notes: list[dict[str, Any]], onset_window: float = 0.055) -> list[dict[str, Any]]:
    """Remove only very likely octave-harmonic duplicates.

    This deliberately keeps ambiguous octave doublings. A note is removed only
    when it attacks almost simultaneously, is much weaker/shorter, and lies one
    or two octaves from a stronger event.
    """
    if not notes:
        return []
    groups: list[list[dict[str, Any]]] = []
    for note in notes:
        if groups and float(note["start"]) - float(groups[-1][0]["start"]) <= onset_window:
            groups[-1].append(note)
        else:
            groups.append([note])
    kept: list[dict[str, Any]] = []
    for group in groups:
        remove: set[int] = set()
        for i, first in enumerate(group):
            for j, second in enumerate(group):
                if i == j or j in remove:
                    continue
                interval = int(second["pitch"]) - int(first["pitch"])
                if abs(interval) not in {12, 24}:
                    continue
                strong, weak = (first, second) if int(first["velocity"]) >= int(second["velocity"]) else (second, first)
                weak_index = j if weak is second else i
                strong_duration = float(strong["end"]) - float(strong["start"])
                weak_duration = float(weak["end"]) - float(weak["start"])
                vocal_guard = weak.get("source") == "vocals" and strong.get("source") != "vocals"
                if not vocal_guard and int(weak["velocity"]) <= int(strong["velocity"]) * 0.68 and weak_duration <= strong_duration * 0.85:
                    remove.add(weak_index)
        kept.extend(note for index, note in enumerate(group) if index not in remove)
    kept.sort(key=lambda n: (float(n["start"]), -int(n["pitch"])))
    return kept


def _local_melody_score(note: dict[str, Any], pitch_center: float) -> float:
    duration = float(note["end"]) - float(note["start"])
    pitch = int(note["pitch"])
    source_bonus = 20.0 if note.get("source") == "vocals" else 0.0
    range_bonus = 8.0 if 52 <= pitch <= 86 else -0.9 * min(abs(pitch - 69), 24)
    confidence = float(note.get("confidence", note.get("amplitude", int(note["velocity"]) / 127)))
    center_penalty = abs(pitch - pitch_center) * 0.18
    return (
        int(note["velocity"]) * 0.48
        + min(duration, 1.8) * 18.0
        + confidence * 13.0
        + source_bonus
        + range_bonus
        - center_penalty
    )


def extract_melody(notes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Find a smooth monophonic melody path with dynamic programming."""
    if not notes:
        return []
    pitches = [int(n["pitch"]) for n in notes]
    velocities = [int(n["velocity"]) for n in notes]
    vocal_source = any(n.get("source") == "vocals" for n in notes)
    pitch_floor = 42 if vocal_source else max(38, min(78, int(_quantile(pitches, 0.42))))
    pitch_ceiling = 94 if vocal_source else 98
    velocity_floor = max(25 if vocal_source else 34, int(_quantile(velocities, 0.18)))
    candidates = [
        n for n in notes
        if pitch_floor <= int(n["pitch"]) <= pitch_ceiling
        and int(n["velocity"]) >= velocity_floor
        and float(n["end"]) - float(n["start"]) >= 0.055
    ]
    if not candidates:
        candidates = notes

    groups: list[list[dict[str, Any]]] = []
    for note in candidates:
        if groups and float(note["start"]) - float(groups[-1][0]["start"]) <= 0.105:
            groups[-1].append(note)
        else:
            groups.append([note])
    # Large polyphonic attacks are reduced before Viterbi to keep complexity bounded.
    pitch_center = _quantile([int(n["pitch"]) for n in candidates], 0.62)
    groups = [
        sorted(group, key=lambda n: _local_melody_score(n, pitch_center), reverse=True)[:8]
        for group in groups
    ]
    if not groups:
        return []

    scores: list[list[float]] = []
    back: list[list[int]] = []
    scores.append([_local_melody_score(note, pitch_center) for note in groups[0]])
    back.append([-1] * len(groups[0]))
    for index in range(1, len(groups)):
        current_scores: list[float] = []
        current_back: list[int] = []
        for note in groups[index]:
            best_score = -1e18
            best_parent = 0
            for parent_index, parent in enumerate(groups[index - 1]):
                interval = abs(int(note["pitch"]) - int(parent["pitch"]))
                dt = max(0.001, float(note["start"]) - float(parent["start"]))
                transition = -interval * (1.28 if dt < 0.9 else 0.82)
                if interval > 12:
                    transition -= (interval - 12) * 2.1
                if interval <= 2:
                    transition += 5.5
                if int(note["pitch"]) == int(parent["pitch"]):
                    transition += 2.0
                gap = float(note["start"]) - float(parent["end"])
                if gap > 2.0:
                    transition -= min(10.0, gap * 1.2)
                candidate_score = scores[index - 1][parent_index] + transition
                if candidate_score > best_score:
                    best_score = candidate_score
                    best_parent = parent_index
            current_scores.append(best_score + _local_melody_score(note, pitch_center))
            current_back.append(best_parent)
        scores.append(current_scores)
        back.append(current_back)

    cursor = max(range(len(scores[-1])), key=scores[-1].__getitem__)
    path: list[dict[str, Any]] = []
    for group_index in range(len(groups) - 1, -1, -1):
        path.append(dict(groups[group_index][cursor]))
        cursor = back[group_index][cursor]
        if cursor < 0 and group_index:
            cursor = 0
    path.reverse()

    result: list[dict[str, Any]] = []
    for note in path:
        if result:
            previous = result[-1]
            if float(note["start"]) < float(previous["start"]) + 0.075:
                continue
            if int(note["pitch"]) == int(previous["pitch"]) and float(note["start"]) - float(previous["end"]) <= 0.075:
                previous["end"] = max(float(previous["end"]), float(note["end"]))
                previous["velocity"] = max(int(previous["velocity"]), int(note["velocity"]))
                continue
            previous["end"] = round(min(float(previous["end"]), float(note["start"])), 5)
            previous["end"] = max(float(previous["end"]), float(previous["start"]) + 0.07)
        selected = dict(note)
        selected["staff"] = "upper"
        selected["role"] = "melody"
        selected["velocity"] = max(48, min(108, round(int(selected["velocity"]) * 0.92)))
        selected["end"] = round(min(float(selected["end"]), float(selected["start"]) + 4.5), 5)
        result.append(selected)
    return result


def detect_key(notes: list[dict[str, Any]]) -> dict[str, Any]:
    weights = [0.0] * 12
    for note in notes:
        duration = max(0.04, min(8.0, float(note["end"]) - float(note["start"])))
        weights[int(note["pitch"]) % 12] += duration * (0.3 + int(note["velocity"]) / 127.0)
    total = sum(weights)
    if total <= 0:
        return {"tonic": 0, "name": "C major", "mode": "major", "fifths": 0, "confidence": 0.0}

    def correlation(profile: Sequence[float], tonic: int) -> float:
        rotated = [profile[(pc - tonic) % 12] for pc in range(12)]
        mean_w = sum(weights) / 12
        mean_p = sum(rotated) / 12
        numerator = sum((weights[i] - mean_w) * (rotated[i] - mean_p) for i in range(12))
        denominator = math.sqrt(
            sum((value - mean_w) ** 2 for value in weights)
            * sum((value - mean_p) ** 2 for value in rotated)
        )
        return numerator / denominator if denominator else 0.0

    options: list[tuple[float, int, str]] = []
    for tonic in range(12):
        options.append((correlation(MAJOR_PROFILE, tonic), tonic, "major"))
        options.append((correlation(MINOR_PROFILE, tonic), tonic, "minor"))
    score, tonic, mode = max(options)
    fifths_major = {0: 0, 7: 1, 2: 2, 9: 3, 4: 4, 11: 5, 6: 6, 1: 7, 5: -1, 10: -2, 3: -3, 8: -4}
    # Minor keys use the signature of their relative major.
    signature_tonic = tonic if mode == "major" else (tonic + 3) % 12
    fifths = fifths_major.get(signature_tonic, 0)
    return {
        "tonic": tonic,
        "name": f"{PITCH_CLASS_NAMES[tonic]} {mode}",
        "mode": mode,
        "fifths": fifths,
        "confidence": round(max(0.0, min(1.0, (score + 1.0) / 2.0)), 3),
    }


def _time_signature_values(time_signature: str) -> tuple[int, int]:
    try:
        beats, beat_type = (int(value) for value in time_signature.split("/", 1))
    except Exception:
        return 4, 4
    if beats <= 0 or beat_type not in {2, 4, 8, 16}:
        return 4, 4
    return beats, beat_type


def infer_chord_timeline(
    notes: list[dict[str, Any]],
    bass_notes: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    duration_seconds: float,
    key_info: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    if not math.isfinite(float(bpm)) or not 30 <= float(bpm) <= 250:
        bpm = 100.0
    beats, beat_type = _time_signature_values(time_signature)
    measure_quarters = beats * 4 / beat_type
    window = max(0.6, 60.0 / bpm * measure_quarters)
    duration = max(duration_seconds, max((float(n["end"]) for n in notes + bass_notes), default=0.0))
    if duration <= 0:
        return []
    qualities = {
        "major": (0, 4, 7),
        "minor": (0, 3, 7),
        "dim": (0, 3, 6),
        "sus4": (0, 5, 7),
    }
    tonic = int((key_info or {}).get("tonic", 0))
    mode = str((key_info or {}).get("mode", "major"))
    major_scale = {(tonic + value) % 12 for value in (0, 2, 4, 5, 7, 9, 11)}
    minor_scale = {(tonic + value) % 12 for value in (0, 2, 3, 5, 7, 8, 10)}
    scale = major_scale if mode == "major" else minor_scale
    timeline: list[dict[str, Any]] = []
    previous: dict[str, Any] | None = None
    for index in range(max(1, math.ceil(duration / window))):
        start = index * window
        end = min(duration, start + window)
        weights = [0.0] * 12
        bass_weights = [0.0] * 12
        for note in notes:
            overlap = max(0.0, min(end, float(note["end"])) - max(start, float(note["start"])))
            if overlap:
                weights[int(note["pitch"]) % 12] += overlap * (0.35 + int(note["velocity"]) / 127)
        for note in bass_notes:
            overlap = max(0.0, min(end, float(note["end"])) - max(start, float(note["start"])))
            if overlap:
                bass_weights[int(note["pitch"]) % 12] += overlap * (0.6 + int(note["velocity"]) / 100)
                weights[int(note["pitch"]) % 12] += overlap * 0.8
        total = sum(weights)
        if total < 0.05:
            if previous:
                copied = dict(previous)
                copied.update(start=round(start, 5), end=round(end, 5), inherited=True)
                timeline.append(copied)
            continue
        best: tuple[float, int, str] | None = None
        for root in range(12):
            for quality, intervals in qualities.items():
                pcs = {(root + interval) % 12 for interval in intervals}
                inside = sum(weights[pc] for pc in pcs)
                outside = total - inside
                score = inside - 0.28 * outside + 0.30 * bass_weights[root] + 0.12 * weights[root]
                if root in scale:
                    score += total * 0.04
                if previous and int(previous["root"]) == root:
                    score += total * 0.025
                candidate = (score, root, quality)
                if best is None or candidate > best:
                    best = candidate
        if best is None:
            continue
        score, root, quality = best
        suffix = {"major": "", "minor": "m", "dim": "dim", "sus4": "sus4"}[quality]
        chord = {
            "start": round(start, 5),
            "end": round(end, 5),
            "root": root,
            "quality": quality,
            "name": PITCH_CLASS_NAMES[root] + suffix,
            "score": round(score / max(total, 0.001), 3),
        }
        timeline.append(chord)
        previous = chord
    return timeline


def _root_midi(root: int, target: int, low: int = 35, high: int = 52) -> int:
    choices = [pitch for pitch in range(low, high + 1) if pitch % 12 == root]
    return min(choices, key=lambda pitch: abs(pitch - target)) if choices else max(low, min(high, target))


def build_light_arrangement(
    melody: list[dict[str, Any]],
    chords: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
) -> list[dict[str, Any]]:
    result = [dict(note, staff="upper", role="melody") for note in melody]
    beats, beat_type = _time_signature_values(time_signature)
    beat_seconds = 60.0 / max(30.0, min(250.0, float(bpm))) * 4 / beat_type
    previous_root_pitch = 43
    for chord in chords:
        start = float(chord["start"])
        end = float(chord["end"])
        if end <= start:
            continue
        root_pitch = _root_midi(int(chord["root"]), previous_root_pitch)
        previous_root_pitch = root_pitch
        fifth_pitch = _root_midi((int(chord["root"]) + 7) % 12, root_pitch + 5, low=38, high=57)
        pulse_duration = min(max(0.32, beat_seconds * 0.90), max(0.35, end - start))
        result.append({
            "start": round(start, 5),
            "end": round(min(end, start + pulse_duration), 5),
            "pitch": root_pitch,
            "velocity": 43,
            "source": "generated_chord",
            "generated": True,
            "staff": "lower",
            "role": "bass_root",
            "chord": chord["name"],
        })
        second_at = start + max(beat_seconds * 2, (end - start) / 2)
        if second_at < end - 0.12:
            result.append({
                "start": round(second_at, 5),
                "end": round(min(end, second_at + pulse_duration), 5),
                "pitch": fifth_pitch,
                "velocity": 36,
                "source": "generated_chord",
                "generated": True,
                "staff": "lower",
                "role": "bass_fifth",
                "chord": chord["name"],
            })
    result.sort(key=lambda n: (float(n["start"]), str(n.get("staff")), -int(n["pitch"])))
    return result


def _density_prune(notes: list[dict[str, Any]], max_at_once: int = 7) -> list[dict[str, Any]]:
    groups: list[list[dict[str, Any]]] = []
    for note in sorted(notes, key=lambda n: (float(n["start"]), -int(n["pitch"]))):
        if groups and float(note["start"]) - float(groups[-1][0]["start"]) <= 0.060:
            groups[-1].append(note)
        else:
            groups.append([note])
    result: list[dict[str, Any]] = []
    for group in groups:
        def score(note: dict[str, Any]) -> float:
            priority = {"melody": 100, "bass": 55, "bass_root": 50, "other": 0}.get(str(note.get("role")), 10)
            duration = float(note["end"]) - float(note["start"])
            return priority + int(note["velocity"]) * 0.5 + min(duration, 2.0) * 10
        selected: list[dict[str, Any]] = []
        used_pitch: set[int] = set()
        for note in sorted(group, key=score, reverse=True):
            pitch = int(note["pitch"])
            if pitch in used_pitch:
                continue
            selected.append(note)
            used_pitch.add(pitch)
            if len(selected) >= max_at_once:
                break
        result.extend(selected)
    result.sort(key=lambda n: (float(n["start"]), -int(n["pitch"])))
    return result


def build_full_arrangement(
    melody: list[dict[str, Any]],
    bass_notes: list[dict[str, Any]],
    other_notes: list[dict[str, Any]],
    split_pitch: int = 60,
) -> list[dict[str, Any]]:
    combined: list[dict[str, Any]] = []
    for note in melody:
        combined.append(dict(note, staff="upper", role="melody"))
    for note in bass_notes:
        if int(note["pitch"]) > 67 or int(note["velocity"]) < 24:
            continue
        combined.append(dict(note, staff="lower", role="bass", velocity=max(30, min(90, int(note["velocity"])))))
    for note in other_notes:
        duration = float(note["end"]) - float(note["start"])
        if duration < 0.07 or int(note["velocity"]) < 27:
            continue
        role = "other"
        staff = "lower" if int(note["pitch"]) < split_pitch else "upper"
        combined.append(dict(note, staff=staff, role=role, velocity=max(24, min(96, int(note["velocity"]) * 0.82))))
    combined = merge_fragments(clean_notes(combined), max_gap=0.045)
    combined = suppress_octave_harmonics(combined)
    return _density_prune(combined, max_at_once=7)


def _align_reference(reference_notes: list[dict[str, Any]], original: list[dict[str, Any]]) -> float:
    if not reference_notes or not original:
        return 0.0
    offset = round(float(original[0]["start"]) - float(reference_notes[0]["start"]), 4)
    if abs(offset) > 0.025:
        for note in reference_notes:
            note["start"] = round(max(0.0, float(note["start"]) + offset), 5)
            note["end"] = round(max(float(note["start"]) + 0.03, float(note["end"]) + offset), 5)
    return offset


def apply_reference_to_payload(payload: dict[str, Any], reference: Iterable[dict[str, Any]] | None) -> dict[str, Any]:
    if reference is None:
        payload["reference_active"] = False
        payload["reference_offset_seconds"] = 0.0
        return payload
    reference_notes = clean_notes(reference, default_source="reference")
    if not reference_notes:
        payload["reference_active"] = False
        payload["reference_offset_seconds"] = 0.0
        return payload
    original = payload.get("modes", {}).get("full", {}).get("notes", [])
    offset = _align_reference(reference_notes, original)
    payload = {**payload, "modes": {**payload.get("modes", {})}}
    payload["modes"]["full"] = {
        "label": "C · MIDI tham chiếu",
        "count": len(reference_notes),
        "notes": reference_notes,
    }
    payload["reference_active"] = True
    payload["reference_offset_seconds"] = offset
    return payload


def prepare_stem_variants(
    vocal_raw: Iterable[dict[str, Any]],
    bass_raw: Iterable[dict[str, Any]],
    other_raw: Iterable[dict[str, Any]],
    *,
    bpm: float,
    time_signature: str,
    duration_seconds: float,
    split_pitch: int = 60,
    reference: Iterable[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    vocal_original = clean_notes(vocal_raw, "vocals")
    bass_original = clean_notes(bass_raw, "bass")
    other_original = clean_notes(other_raw, "other")

    vocal = suppress_octave_harmonics(merge_fragments(vocal_original, max_gap=0.085))
    bass = suppress_octave_harmonics(merge_fragments(bass_original, max_gap=0.060))
    other = suppress_octave_harmonics(merge_fragments(other_original, max_gap=0.045))
    melody = extract_melody(vocal or other)
    key_info = detect_key(melody + bass + other)
    chords = infer_chord_timeline(other, bass, bpm, time_signature, duration_seconds, key_info)
    light = build_light_arrangement(melody, chords, bpm, time_signature)
    full = build_full_arrangement(melody, bass, other, split_pitch=split_pitch)
    duration = max(
        duration_seconds,
        max((float(n["end"]) for n in melody + light + full), default=0.0),
    )
    payload: dict[str, Any] = {
        "version": 2,
        "source": "Demucs stems + Basic Pitch + AudioSheet arranger",
        "pipeline": "stem_separated",
        "duration_seconds": round(duration, 2),
        "reference_active": False,
        "reference_offset_seconds": 0.0,
        "raw_count": len(vocal_original) + len(bass_original) + len(other_original),
        "merged_count": len(vocal) + len(bass) + len(other),
        "stem_counts": {
            "vocals_raw": len(vocal_original),
            "vocals_clean": len(vocal),
            "bass_raw": len(bass_original),
            "bass_clean": len(bass),
            "other_raw": len(other_original),
            "other_clean": len(other),
        },
        "analysis": {"key": key_info, "chords": chords},
        "modes": {
            "melody": {"label": "A · Giai điệu hát", "count": len(melody), "notes": melody},
            "light": {"label": "B · Piano dễ chơi", "count": len(light), "notes": light},
            "full": {"label": "C · Phiên âm đầy đủ", "count": len(full), "notes": full},
        },
    }
    return apply_reference_to_payload(payload, reference)


def extract_light_bass(notes: list[dict[str, Any]], melody: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Backward-compatible fallback used for old full-mix jobs."""
    if not notes:
        return []
    pitches = [int(n["pitch"]) for n in notes]
    floor = min(59, int(_quantile(pitches, 0.36)))
    candidates = [n for n in notes if int(n["pitch"]) <= floor and int(n["velocity"]) >= 35]
    bass: list[dict[str, Any]] = []
    last_at = -5.0
    for note in sorted(candidates, key=lambda n: (float(n["start"]), -int(n["velocity"]))):
        if float(note["start"]) < last_at + 1.05:
            continue
        bass.append({
            "start": note["start"],
            "end": round(min(float(note["end"]), float(note["start"]) + 1.2), 5),
            "pitch": note["pitch"],
            "velocity": 35,
            "source": "fallback_mix",
            "staff": "lower",
            "role": "bass",
        })
        last_at = float(note["start"])
    return bass


def prepare_variants(
    raw: Iterable[dict[str, Any]],
    reference: Iterable[dict[str, Any]] | None = None,
    *,
    bpm: float = 100.0,
    time_signature: str = "4/4",
    split_pitch: int = 60,
) -> dict[str, Any]:
    """Fallback for legacy jobs that only have one full-mix transcription."""
    original = clean_notes(raw, "full_mix")
    merged = suppress_octave_harmonics(merge_fragments(original))
    melody = extract_melody(merged)
    key_info = detect_key(merged)
    duration = max((float(n["end"]) for n in original), default=0.0)
    chords = infer_chord_timeline(merged, extract_light_bass(merged, melody), bpm, time_signature, duration, key_info)
    light = build_light_arrangement(melody, chords, bpm, time_signature)
    full = [dict(n, staff="lower" if int(n["pitch"]) < split_pitch else "upper") for n in original]
    payload: dict[str, Any] = {
        "version": 2,
        "source": "Basic Pitch full mix + fallback arranger",
        "pipeline": "legacy_full_mix",
        "raw_count": len(original),
        "merged_count": len(merged),
        "duration_seconds": round(duration, 2),
        "reference_active": False,
        "reference_offset_seconds": 0.0,
        "analysis": {"key": key_info, "chords": chords},
        "modes": {
            "melody": {"label": "A · Giai điệu ước lượng", "count": len(melody), "notes": melody},
            "light": {"label": "B · Piano dễ chơi", "count": len(light), "notes": light},
            "full": {"label": "C · Toàn bộ nốt AI", "count": len(full), "notes": full},
        },
    }
    return apply_reference_to_payload(payload, reference)


def midi_to_events(midi_path: str) -> list[dict[str, Any]]:
    import pretty_midi

    midi = pretty_midi.PrettyMIDI(midi_path)
    data: list[dict[str, Any]] = []
    for instrument in midi.instruments:
        if instrument.is_drum:
            continue
        for note in instrument.notes:
            data.append({
                "start": note.start,
                "end": note.end,
                "pitch": note.pitch,
                "velocity": note.velocity,
                "source": "reference",
            })
            if len(data) >= MAX_EVENTS:
                raise ValueError("Reference MIDI has too many notes (maximum 60000).")
    if not data:
        raise ValueError("The reference MIDI contains no playable pitched notes.")
    if max(float(n["end"]) for n in data) > 1200:
        raise ValueError("The reference MIDI is too long (over 20 minutes).")
    return clean_notes(data)


def write_mode_midi(notes: list[dict[str, Any]], out_path: str, bpm: float = 100) -> None:
    import pretty_midi

    midi = pretty_midi.PrettyMIDI(initial_tempo=float(bpm) if 30 <= float(bpm) <= 250 else 100)
    upper = pretty_midi.Instrument(program=0, name="AudioSheet Piano RH")
    lower = pretty_midi.Instrument(program=0, name="AudioSheet Piano LH")
    for note in clean_notes(notes):
        target = lower if note.get("staff") == "lower" else upper
        target.notes.append(pretty_midi.Note(
            velocity=int(note["velocity"]),
            pitch=int(note["pitch"]),
            start=float(note["start"]),
            end=float(note["end"]),
        ))
    if upper.notes:
        midi.instruments.append(upper)
    if lower.notes:
        midi.instruments.append(lower)
    if not midi.instruments:
        midi.instruments.append(upper)
    midi.write(out_path)
