# TUNERTOOLS DOCUMENTS - SỬA OAUTH_READY=False (ALWAYSDATA)

## Vì sao cần bản này?

Kết quả máy chủ của bạn đã xác nhận:
- DRIVE_ROOT_READY=True
- PERMISSIONS_READY=True
- PERMISSION_ACCOUNTS=93
- OAUTH_READY=False

Bản PHP cũ chỉ đọc Google Web Client ID và session secret qua getenv().
Nếu PHP trên Alwaysdata không nhận biến môi trường từ cấu hình bạn đã nhập,
health trả false dù Google Drive và file JSON hoàn toàn bình thường.

Bản FIX giữ nguyên đọc Google Drive và cấp quyền hiện có. Chỉ bổ sung cách
đọc cấu hình từ file PHP PRIVATE nằm NGOÀI webroot, cùng các trạng thái
True/False để chỉ ra chính xác thành phần còn thiếu (không lộ giá trị).

## CÀI TRÊN ALWAYSDATA

1. Sao lưu `api_documents_drive.php` đang chạy vào thư mục an toàn ngoài webroot.
2. Qua SFTP hoặc trình quản lý file, xác định account trong đường dẫn
   /home/<TEN_ACCOUNT>/www/... của bạn.
3. Tạo thư mục RIÊNG TƯ `/home/<TEN_ACCOUNT>/private/` nếu chưa có.
   KHÔNG tạo nó bên trong `www` hoặc document root của website.
4. Chép `PRIVATE_CONFIG_TEMPLATE/tt_documents_private.php.example`
   vào thư mục private, sau đó đổi tên thành `tt_documents_private.php`.
   Đường dẫn cuối cùng phải là:
      /home/<TEN_ACCOUNT>/private/tt_documents_private.php
5. Mở file PRIVATE trên Alwaysdata, thay chính xác 3 giá trị:
   * TUNERTOOLS_DOCUMENTS_WEB_CLIENT_ID: Web application OAuth client ID
     của TunerTools, kết thúc bằng .apps.googleusercontent.com
   * TUNERTOOLS_DOCUMENT_SESSION_SECRET: khóa MỚI ngẫu nhiên, >=48 ký tự
   * TUNERTOOLS_DOCUMENT_SYNC_SHARED_SECRET: khóa MỚI ngẫu nhiên, >=48
     ký tự; phải là cùng giá trị sử dụng ở PHP IIS.
   Không chép khóa vào Android. Không gửi khóa vào chat.
6. Giới hạn quyền thư mục/file nếu có SSH:
      chmod 700 /home/<TEN_ACCOUNT>/private
      chmod 600 /home/<TEN_ACCOUNT>/private/tt_documents_private.php
   Đảm bảo PHP website vẫn có quyền đọc file.
7. Upload `PHP_Alwaysdata/api_documents_drive.php` lên cùng chỗ với
   file `api_documents_drive.php` hiện tại trên Alwaysdata, ghi đè
   đúng file này. Không sửa api_gp_drive.php hay drive_token.json.
8. Xác nhận `tuner.alwaysdata.net` đang chạy PHP file bạn vừa cập nhật;
   nếu bật OPCache cần reload/clear opcode cache hoặc restart PHP site.

## KIỂM TRA (WINDOWS POWERSHELL)

   $u = "https://tuner.alwaysdata.net/api_documents_drive.php?action=health"
   $h = Invoke-RestMethod -Uri $u -TimeoutSec 30
   $h | Select-Object drive_root_ready,permissions_ready,permission_users,oauth_client_ready,oauth_session_ready,oauth_sync_ready,private_config_loaded,oauth_ready

Kết quả mong muốn:
   drive_root_ready = True
   permissions_ready = True
   permission_users = 93 (hoặc nhiều hơn khi Admin thay đổi)
   oauth_client_ready = True
   oauth_session_ready = True
   oauth_sync_ready = True
   private_config_loaded = True  (nếu sử dụng file PRIVATE)
   oauth_ready = True

Nếu `private_config_loaded=False`: kiểm tra vị trí /home/<TEN_ACCOUNT>/private,
tên file phải chính xác, quyền đọc cho website và bản PHP mới đã upload.
Nếu `oauth_client_ready=False`: kiểm tra đúng Web application Client ID.
Nếu `oauth_session_ready=False`: khóa session chưa đọc được/không đủ 48 ký tự.
Nếu `oauth_sync_ready=False`: khóa đồng bộ quyền chưa đọc được; việc xem tài liệu
có thể hoạt động nhưng cập nhật quyền từ Admin sẽ chưa đồng bộ.

## ANDROID & IIS

Chỉ khi OAuth đã TRUE, hãy thử Android: Đăng nhập Google rồi vào
Admin > Quyền tài liệu > Thử lại. Thử xem PDF/tài liệu từ Drive.
* Nếu Drive thành công, không cần IIS để ĐỌC tài liệu.
* Để Admin THÊM/SỬA/XÓA quyền, IIS đã vá vẫn cần 2 biến môi trường:
  TUNERTOOLS_DOCUMENTS_WEB_CLIENT_ID và
  TUNERTOOLS_DOCUMENT_SYNC_SHARED_SECRET, với giá trị tương ứng.
* Nếu app báo 'Thiếu OAuth Web Client ID cho TunerTools Documents'
  thì APK thiếu resource `default_web_client_id` hoặc
  `tt_documents_web_client_id` - đây là vấn đề riêng ở Android Studio.
* Nếu app báo 'Chưa cấu hình Google OAuth Web Client ID trên IIS' thì
  nhánh fallback IIS đang lỗi cấu hình; kiểm tra OAuth_READY trên Alwaysdata
  và Google ID token Android trước, chưa vội sửa hệ thống Drive.

## AN TOÀN

- Hai khóa từng bị lộ trong cuộc trò chuyện trước phải THAY MỚI.
- Không chia sẻ hoặc tải file cấu hình PRIVATE ra web; không đặt file
  ngoài webroot nếu account có website khác trỏ vào thư mục này.
- Không tạo lại file document_permissions.json đã có trên Drive.
- Không chạy lại IIS_Patch; nó đã PATCH_OK.
- Bản sửa này không được thử đăng nhập trực tiếp với hạ tầng Google,
  MySQL hoặc Alwaysdata thật. Cần kiểm tra thực tế trước khi phát hành.

## KHÔI PHỤC

- Sao lưu lại file Alwaysdata trước khi thay.
- Nếu lỗi, phục hồi `api_documents_drive.php` đã sao lưu.
- Giữ nguyên file PRIVATE ngoài webroot và JSON trên Drive.
