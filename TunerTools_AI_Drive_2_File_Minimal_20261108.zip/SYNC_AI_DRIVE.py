#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TunerTools AI -> Google Drive. Standalone incremental sync + Windows menu.

NO other Python/PowerShell script dependencies. The AI app.py is kept in
C:/TunerTools/Audio/AI_Music and writes AI_DRIVE_SYNC_QUEUE.jsonl.
This program only uses Google Drive stream_cache and lyrics folders.
Create-only uploads, exact-name checks, resumable upload, MD5 verification.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from functools import lru_cache
from pathlib import Path
import ctypes
import hashlib
import http.client
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET
from urllib import error, parse, request

GOOGLE_FILES = "https://www.googleapis.com/drive/v3/files"
FOLDER_MIME = "application/vnd.google-apps.folder"
SOURCE_DEFAULT = r"C:\TunerTools\Audio\AI_Music"
TOKEN_DEFAULTS = (
    r"C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json",
    r"C:\TunerTools\BackupScripts\Drive_Buoc2C\drive_token.json",
    r"C:\TunerTools\BackupScripts\Drive_Documents\drive_token.json",
)
AUDIO_EXTS = {".ogg", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".opus", ".webm"}
ZING_AUDIO_PATTERN = re.compile(r"^zing_acapella_[A-Za-z0-9]{6,64}\.(ogg|mp3|wav|m4a|aac|flac|opus|webm)$", re.I)
YT_AUDIO_PATTERN = re.compile(r"^(acapella|beat_karaoke)_[A-Za-z0-9_-]{11}\.(ogg|mp3|wav|m4a|aac|flac|opus|webm)$", re.I)
UPLOAD_URL = "https://www.googleapis.com/upload/drive/v3/files"
MIME_AUDIO = {".ogg": "audio/ogg", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac", ".opus": "audio/opus", ".webm": "audio/webm"}
ZING_JSON = re.compile(r"^[A-Za-z0-9]{6,64}(?:_.+)?\.json$", re.I)
YOUTUBE_JSON = re.compile(r"^(?:lyrics|meta)_[A-Za-z0-9_-]{11}\.json$", re.I)
LOCK_FILE = "AI_DRIVE_SYNC_RUNNING.lock"
ID_RE = re.compile(r"^[A-Za-z0-9]{6,64}$")
CHUNK = 1024 * 1024
RETRY_HTTP = {408, 429, 500, 502, 503, 504}
SESSION_DIR = ".upload_sessions"
INDEX_NAME = 'AI_DRIVE_SYNC_INDEX.json'
QUEUE_NAME = 'AI_DRIVE_SYNC_QUEUE.jsonl'
QUEUE_LOCK_NAME = 'AI_DRIVE_SYNC_QUEUE.lock'
SCHEMA = 2
DEFAULT_FULL_INTERVAL = 24 * 3600
SOURCE_DIRS = {'ZING_AUDIO', 'ZING_JSON', 'YOUTUBE_CACHE'}
DEST_BUCKETS = {'audio': 'stream_cache', 'lyrics': 'lyrics'}

# ---- GOOGLE READER AND LOCAL CATALOG ----

class GoogleReader:
    def __init__(self, path: Path):
        self.data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(self.data, dict):
            raise RuntimeError("Invalid OAuth token file format")
        self.token = str(self.data.get("token") or self.data.get("access_token") or "")
        expiry_raw = str(self.data.get("expiry") or "")
        if expiry_raw:
            try:
                exp = datetime.fromisoformat(expiry_raw.replace("Z", "+00:00"))
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp < datetime.now(timezone.utc) + timedelta(minutes=2):
                    self.token = ""
            except ValueError:
                self.token = ""
        if not self.token:
            self.refresh()

    def refresh(self) -> None:
        keys = ("refresh_token", "client_id", "client_secret")
        payload = {key: self.data.get(key) for key in keys}
        if not all(payload.values()):
            raise RuntimeError("OAuth refresh credentials missing; reauthorize private token")
        payload["grant_type"] = "refresh_token"
        req = request.Request(
            "https://oauth2.googleapis.com/token",
            data=parse.urlencode(payload).encode("utf-8"),
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with request.urlopen(req, timeout=35) as resp:
            item = json.load(resp)
        self.token = str(item.get("access_token") or "")
        if not self.token:
            raise RuntimeError("OAuth refresh did not return an access token")

    def get(self, url: str) -> dict:
        last = None
        for attempt in range(5):
            req = request.Request(
                url,
                headers={"Authorization": "Bearer " + self.token, "Accept": "application/json"},
                method="GET",
            )
            try:
                with request.urlopen(req, timeout=50) as resp:
                    obj = json.load(resp)
                if not isinstance(obj, dict):
                    raise RuntimeError("Google response was not a JSON object")
                return obj
            except error.HTTPError as exc:
                last = exc
                if exc.code == 401 and attempt < 4:
                    self.refresh()
                    continue
                if exc.code not in (408, 429, 500, 502, 503, 504) or attempt == 4:
                    raise RuntimeError("Google API HTTP " + str(exc.code)) from exc
            except (error.URLError, TimeoutError, ConnectionError, http.client.RemoteDisconnected, ssl.SSLError) as exc:
                last = exc
                if attempt == 4:
                    raise RuntimeError("Cannot read Google Drive after retries: " + type(exc).__name__) from exc
            time.sleep(min(12, 0.8 * (2 ** attempt)))
        raise RuntimeError("Google Drive request failed: " + type(last).__name__)

    def list_files(self, parent_id: str, name: str | None = None) -> list[dict]:
        quoted = parent_id.replace("\\", "\\\\").replace("'", "\\'")
        q = "'" + quoted + "' in parents and trashed = false"
        if name is not None:
            escaped = name.replace("\\", "\\\\").replace("'", "\\'")
            q += " and name = '" + escaped + "'"
        result = []
        page_token = None
        for page in range(100):
            params = {"q": q, "pageSize": 1000, "spaces": "drive", "fields": "nextPageToken,files(id,name,mimeType,size)"}
            if page_token:
                params["pageToken"] = page_token
            obj = self.get(GOOGLE_FILES + "?" + parse.urlencode(params))
            items = obj.get("files")
            if not isinstance(items, list):
                raise RuntimeError("Google Drive did not return files array")
            result.extend(x for x in items if isinstance(x, dict))
            token = obj.get("nextPageToken")
            if not token:
                return result
            if token == page_token:
                raise RuntimeError("Google Drive page token did not advance")
            page_token = token
        raise RuntimeError("Google Drive paging exceeded 100 pages")

    def folder(self, parent_id: str, name: str) -> str:
        found = [x for x in self.list_files(parent_id, name)
                 if x.get("mimeType") == FOLDER_MIME and x.get("name") == name]
        if len(found) != 1:
            raise RuntimeError("Folder '%s' ambiguous or missing under '%s' (count=%d)" % (name, parent_id, len(found)))
        return str(found[0]["id"])


def valid_json(path: Path) -> bool:
    try:
        size = path.stat().st_size
        if not 0 < size <= 2 * 1024 * 1024:
            return False
        obj = json.loads(path.read_text(encoding="utf-8-sig"))
        return isinstance(obj, (list, dict))
    except (OSError, ValueError, UnicodeError):
        return False


def find_local_files(root: Path) -> tuple[dict, dict]:
    """Returns bucket -> {name: [(path, bytes), ...]}, plus scan diagnostics."""
    items = {"audio": defaultdict(list), "lyrics": defaultdict(list)}
    details = {"folders_missing": [], "unrecognized_audio": [], "invalid_json": [],
               "all_audio_source_files": 0, "all_json_source_files": 0,
               "ignored_other_json": 0}
    zing_audio = root / "ZING_AUDIO"
    youtube = root / "YOUTUBE_CACHE"
    zing_json = root / "ZING_JSON"
    for folder in (zing_audio, youtube, zing_json):
        if not folder.is_dir():
            details["folders_missing"].append(str(folder))
    for folder in (zing_audio, youtube):
        if not folder.is_dir():
            continue
        for p in folder.iterdir():
            if not p.is_file() or p.suffix.lower() not in AUDIO_EXTS:
                continue
            details["all_audio_source_files"] += 1
            pattern = ZING_AUDIO_PATTERN if folder == zing_audio else YT_AUDIO_PATTERN
            if not pattern.fullmatch(p.name):
                details["unrecognized_audio"].append((str(p), p.stat().st_size))
                continue
            items["audio"][p.name].append((str(p), p.stat().st_size))
    for folder in (zing_json, youtube):
        if not folder.is_dir():
            continue
        for p in folder.iterdir():
            if not p.is_file() or p.suffix.lower() != ".json":
                continue
            if folder == youtube and not p.name.startswith(("lyrics_", "meta_")):
                details["ignored_other_json"] += 1
                continue
            details["all_json_source_files"] += 1
            if not valid_json(p):
                details["invalid_json"].append((str(p), p.stat().st_size))
                continue
            items["lyrics"][p.name].append((str(p), p.stat().st_size))
    return items, details


# ---- RESUMABLE GOOGLE UPLOADER ----

def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def short_error(exc: Exception) -> str:
    if isinstance(exc, error.HTTPError):
        return "Google HTTP " + str(exc.code)
    return type(exc).__name__ + ": " + str(exc)[:160]


def sha_md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as fp:
        for buf in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(buf)
    return h.hexdigest()


def remote_by_name(items: list[dict], allowed_exts: set[str]) -> dict[str, list[dict]]:
    grouped = defaultdict(list)
    for o in items:
        n = o.get("name")
        if isinstance(n, str) and o.get("mimeType") != FOLDER_MIME and Path(n).suffix.lower() in allowed_exts:
            grouped[n].append(o)
    return dict(grouped)


def check_stable(path: Path, min_age: int) -> tuple[int, int]:
    if not path.is_file():
        raise RuntimeError("Local file missing")
    s = path.stat()
    if s.st_size <= 0:
        raise RuntimeError("Source file empty")
    age = time.time() - s.st_mtime
    if age < min_age:
        raise RuntimeError("Source file still new/writing: age=%ds < %ds" % (age, min_age))
    return s.st_size, s.st_mtime_ns


def remote_detail(drive: GoogleReader, file_id: str) -> dict:
    u = GOOGLE_FILES + "/" + parse.quote(file_id, safe="") + "?" + parse.urlencode({
        "fields": "id,name,mimeType,size,md5Checksum,parents",
    })
    return drive.get(u)


def remote_content_equal(drive: GoogleReader, info: dict, local: Path, require_md5: bool) -> bool:
    if str(info.get("size", "")) != str(local.stat().st_size):
        return False
    if not require_md5:
        return True
    meta = remote_detail(drive, str(info["id"]))
    checksum = str(meta.get("md5Checksum") or "").lower()
    if not checksum:
        raise RuntimeError("Drive file has no MD5 checksum")
    if checksum != sha_md5(local):
        raise RuntimeError("Drive and Server MD5 differ (same filename)")
    return True


class UploadSessionExpired(RuntimeError):
    pass


def validate_session_location(location: str) -> str:
    u = parse.urlsplit(location)
    # The URI is an upload credential. Never print it to logs.
    if u.scheme != "https" or u.hostname != "www.googleapis.com" or not u.path.startswith("/upload/drive/v3/files"):
        raise RuntimeError("Invalid Google Drive resumable session URL")
    return location


@lru_cache(maxsize=16)
def session_dir(report: Path) -> Path:
    """Restrict saved Google upload sessions to SYSTEM and local Administrators."""
    d = report / SESSION_DIR
    d.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        command = ["icacls.exe", str(d), "/inheritance:r", "/grant:r",
                   "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F", "/Q"]
        proc = subprocess.run(command, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError("Unable to protect Drive upload session directory ACL; run as Administrator")
    else:
        d.chmod(0o700)
    return d


def state_path(report: Path, kind: str, path: Path, folder_id: str) -> Path:
    key = hashlib.sha256((kind + "\0" + str(path.resolve()) + "\0" + folder_id).encode('utf-8')).hexdigest()
    return session_dir(report) / (key + ".json")


def save_session(path: Path, info: dict) -> None:
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(info, ensure_ascii=False), encoding='utf-8')
    if os.name != "nt":
        tmp.chmod(0o600)
    os.replace(tmp, path)


def load_session(path: Path, source: Path, folder_id: str) -> str | None:
    if not path.exists():
        return None
    info = json.loads(path.read_text(encoding='utf-8'))
    stat = source.stat()
    if (info.get('file') != str(source.resolve()) or info.get('folder_id') != folder_id
            or info.get('size') != stat.st_size or info.get('mtime_ns') != stat.st_mtime_ns):
        raise RuntimeError("Source changed since unfinished upload; check session manually before retry")
    return validate_session_location(str(info['location']))


def create_session(drive: GoogleReader, folder_id: str, local: Path, mime: str) -> str:
    metadata = json.dumps({"name": local.name, "mimeType": mime, "parents": [folder_id]},
                          ensure_ascii=False, separators=(",", ":")).encode('utf-8')
    url = UPLOAD_URL + "?" + parse.urlencode({
        "uploadType": "resumable", "fields": "id,name,size,md5Checksum,parents"
    })
    for attempt in range(4):
        req = request.Request(url, data=metadata, method="POST", headers={
            "Authorization": "Bearer " + drive.token,
            "Content-Type": "application/json; charset=UTF-8",
            "X-Upload-Content-Type": mime,
            "X-Upload-Content-Length": str(local.stat().st_size),
        })
        try:
            with request.urlopen(req, timeout=60) as resp:
                if resp.status != 200:
                    raise RuntimeError("Drive session returned HTTP " + str(resp.status))
                return validate_session_location(resp.headers.get("Location", ""))
        except error.HTTPError as exc:
            if exc.code == 401 and attempt < 3:
                drive.refresh()
            elif exc.code not in RETRY_HTTP or attempt == 3:
                raise
        except (error.URLError, TimeoutError, ConnectionError, socket.timeout, http.client.RemoteDisconnected, ssl.SSLError):
            if attempt == 3:
                raise
        time.sleep(min(8, 1.5 * (2 ** attempt)))
    raise RuntimeError("Unable to initialize Drive upload")


def resumable_response(req: request.Request, timeout: int):
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.headers, resp.read()
    except error.HTTPError as exc:
        if exc.code == 308:
            return 308, exc.headers, b''
        if exc.code in (404, 410):
            raise UploadSessionExpired('Drive session expired') from exc
        raise


def received_offset(headers, total: int) -> int:
    raw = headers.get("Range", "").strip()
    if not raw:
        return 0
    match = re.fullmatch(r"bytes=0-(\d+)", raw)
    if not match:
        raise RuntimeError("Unexpected upload Range response")
    offset = int(match.group(1)) + 1
    if offset < 0 or offset > total:
        raise RuntimeError("Invalid Drive upload offset")
    return offset


def status_query(location: str, total: int, timeout: int):
    # For Google Drive's interrupted upload recovery:
    # PUT Content-Range: bytes */TOTAL, Content-Length: 0
    req = request.Request(location, data=b'', method='PUT', headers={
        'Content-Range': 'bytes */' + str(total), 'Content-Length': '0',
    })
    status, headers, body = resumable_response(req, timeout)
    if status == 308:
        return received_offset(headers, total), None
    if status in (200, 201):
        obj = json.loads(body.decode('utf-8'))
        if not isinstance(obj, dict) or not obj.get('id'):
            raise RuntimeError("Drive completed, but no file ID was returned")
        return total, obj
    raise RuntimeError('Unexpected Drive session status: HTTP ' + str(status))


def recover_status(location: str, total: int, timeout: int, retries: int = 5):
    for attempt in range(retries):
        try:
            return status_query(location, total, min(timeout, 90))
        except UploadSessionExpired:
            raise
        except error.HTTPError as exc:
            if exc.code not in RETRY_HTTP:
                raise
        except (error.URLError, TimeoutError, ConnectionError, socket.timeout, http.client.RemoteDisconnected, ssl.SSLError):
            pass
        if attempt < retries - 1:
            time.sleep(min(12, 2 * (2 ** attempt)))
    raise RuntimeError("Cannot determine Drive upload offset after retries; saved session for next run")


def upload_chunk(location: str, data: bytes, start: int, total: int, mime: str, timeout: int):
    end = start + len(data) - 1
    req = request.Request(location, data=data, method="PUT", headers={
        "Content-Type": mime,
        "Content-Range": f"bytes {start}-{end}/{total}",
        "Content-Length": str(len(data)),
    })
    status, headers, body = resumable_response(req, timeout)
    if status == 308:
        return received_offset(headers, total), None
    if status in (200, 201):
        if end + 1 != total:
            raise RuntimeError("Drive completed before last file chunk")
        obj = json.loads(body.decode('utf-8'))
        if not isinstance(obj, dict) or not obj.get('id'):
            raise RuntimeError("Drive completion did not return a file ID")
        return total, obj
    raise RuntimeError("Unexpected Drive chunk HTTP " + str(status))


def put_chunks(location: str, local: Path, mime: str, chunk: int, timeout: int,
               resume_existing: bool) -> dict:
    total = local.stat().st_size
    offset = 0
    if resume_existing:
        offset, completed = recover_status(location, total, timeout)
        if completed:
            return completed
        print('  RESUME: Google Drive acknowledged %d/%d bytes' % (offset, total))
    retries = 0
    active_chunk = chunk
    with local.open('rb') as fp:
        while offset < total:
            fp.seek(offset)
            data = fp.read(min(active_chunk, total - offset))
            if not data:
                raise RuntimeError("Source file truncated during upload")
            try:
                next_offset, completed = upload_chunk(location, data, offset, total, mime, timeout)
            except UploadSessionExpired:
                raise
            except Exception as exc:
                transient = isinstance(exc, (error.URLError, TimeoutError, ConnectionError,
                                            socket.timeout, http.client.RemoteDisconnected, ssl.SSLError))
                if isinstance(exc, error.HTTPError):
                    transient = exc.code in RETRY_HTTP
                if not transient:
                    raise
                retries += 1
                active_chunk = max(256 * 1024, active_chunk // 2)
                print("  NETWORK RETRY %d/8: querying received bytes; next chunk=%d KiB" %
                      (retries, active_chunk // 1024))
                # Never blindly repeat a timed-out chunk. Ask the existing session first.
                next_offset, completed = recover_status(location, total, timeout)
                if completed:
                    return completed
                if retries >= 8:
                    raise RuntimeError("Too many upload interruptions; saved session for next run") from exc
                time.sleep(min(12, 1.5 * (2 ** min(retries, 4))))
            if completed:
                return completed
            if next_offset < offset or next_offset > total:
                raise RuntimeError("Drive acknowledged invalid byte offset")
            if next_offset == offset:
                if retries == 0:
                    retries = 1
                if retries >= 8:
                    raise RuntimeError("No upload progress after retries; saved session")
                time.sleep(min(12, 1.5 * (2 ** min(retries, 4))))
            else:
                offset = next_offset
                retries = 0
                print("  PROGRESS: %d/%d bytes (%.1f%%)" % (offset, total, 100 * offset / total))
    # A 308 Range that reaches total is unexpected; query completion rather than re-POST.
    _, completed = recover_status(location, total, timeout)
    if completed:
        return completed
    raise RuntimeError("Drive has all bytes but has not finalized; saved session for next run")


def upload_one(drive: GoogleReader, folder_id: str, local: Path,
               kind: str, report: Path, chunk: int, timeout: int) -> tuple[dict, Path]:
    mime = 'application/json' if kind == 'lyrics' else MIME_AUDIO[local.suffix.lower()]
    sp = state_path(report, kind, local, folder_id)
    location = load_session(sp, local, folder_id)
    is_resume = location is not None
    if not location:
        location = create_session(drive, folder_id, local, mime)
        stat = local.stat()
        save_session(sp, {
            'file': str(local.resolve()), 'folder_id': folder_id,
            'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
            'location': location, 'utc': stamp(),
        })
    try:
        return put_chunks(location, local, mime, chunk, timeout, is_resume), sp
    except UploadSessionExpired:
        # An expired session might already have committed the last chunk.
        # Check exact destination name before starting any replacement session.
        exact = [o for o in drive.list_files(folder_id, local.name)
                 if o.get('name') == local.name and o.get('mimeType') != FOLDER_MIME]
        if len(exact) == 1 and remote_content_equal(drive, exact[0], local, require_md5=True):
            return exact[0], sp
        if exact:
            raise RuntimeError('Drive filename conflict after upload session expiry')
        sp.unlink(missing_ok=True)
        location = create_session(drive, folder_id, local, mime)
        stat = local.stat()
        save_session(sp, {
            'file': str(local.resolve()), 'folder_id': folder_id,
            'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
            'location': location, 'utc': stamp(),
        })
        return put_chunks(location, local, mime, chunk, timeout, False), sp


def choose_files(root: Path, single_id: str | None) -> tuple[dict[str, list[Path]], dict]:
    result: dict[str, list[Path]] = {"audio": [], "lyrics": []}
    if single_id:
        if not ID_RE.fullmatch(single_id):
            raise RuntimeError("Invalid Zing ID")
        source = root / "ZING_AUDIO" / ("zing_acapella_" + single_id + ".ogg")
        if not source.is_file():
            raise RuntimeError("Cannot find expected ZING_AUDIO file: " + str(source))
        return {"audio": [source], "lyrics": []}, {"invalid": [], "missing": []}

    found, diag = find_local_files(root)
    if diag["folders_missing"]:
        raise RuntimeError("Local source folder missing: " + ", ".join(diag["folders_missing"]))
    issues = []
    for kind in ("audio", "lyrics"):
        for name, places in found[kind].items():
            if len(places) != 1:
                issues.append("Duplicate local filename " + name)
                continue
            p = Path(places[0][0])
            if kind == "lyrics":
                permitted = ZING_JSON.fullmatch(name) if p.parent.name == "ZING_JSON" else YOUTUBE_JSON.fullmatch(name)
                if not permitted:
                    issues.append("Skipped unrecognized JSON filename " + name)
                    continue
            result[kind].append(p)
        result[kind].sort(key=lambda p: p.name.casefold())
    return result, {"invalid": diag["invalid_json"],
                    "unrecognized_audio": diag["unrecognized_audio"],
                    "issues": issues, "missing": diag["folders_missing"]}


def acquire_lock(report_dir: Path):
    """Exclusive OS-level Windows file lock (automatically released on process exit)."""
    p = report_dir / LOCK_FILE
    fp = p.open("a+b")
    if os.name == "nt":
        import msvcrt
        fp.seek(0)
        if fp.read(1) == b"":
            fp.write(b"0")
            fp.flush()
        fp.seek(0)
        try:
            msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            fp.close()
            raise RuntimeError("Another AI Drive sync is currently running")
    else:
        import fcntl
        try:
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fp.close()
            raise RuntimeError("Another AI Drive sync is currently running")
    return fp


# ---- INCREMENTAL STATE MACHINE ----

def ident(kind: str, filename: str) -> str:
    return kind + ':' + filename


def new_index() -> dict:
    return {'schema': SCHEMA, 'queue_offset': 0, 'last_full_scan_utc': '', 'files': {}}


def load_index(index_path: Path) -> dict:
    if not index_path.is_file():
        return new_index()
    obj = json.loads(index_path.read_text(encoding='utf-8-sig'))
    if not isinstance(obj, dict) or obj.get('schema') != SCHEMA or not isinstance(obj.get('files'), dict):
        raise RuntimeError('Sync index schema invalid; do NOT delete it. Use full reconciliation after backup')
    if not isinstance(obj.get('queue_offset'), int) or obj['queue_offset'] < 0:
        raise RuntimeError('Sync queue offset invalid')
    return obj


def write_index(path: Path, obj: dict) -> None:
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with tmp.open('w', encoding='utf-8', newline='\n') as stream:
            json.dump(obj, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


@contextmanager
def queue_lock(root: Path):
    """Matches the lock used by app.py (Windows msvcrt / Unix flock)."""
    with (root / QUEUE_LOCK_NAME).open('a+b') as fp:
        locked = False
        for _ in range(100):
            try:
                if os.name == 'nt':
                    import msvcrt
                    fp.seek(0)
                    if fp.read(1) == b'':
                        fp.seek(0)
                        fp.write(b'0')
                        fp.flush()
                    fp.seek(0)
                    msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
                break
            except (OSError, IOError):
                time.sleep(0.05)
        if not locked:
            raise RuntimeError('AI queue is busy; retry on next run')
        try:
            yield
        finally:
            if os.name == 'nt':
                fp.seek(0)
                msvcrt.locking(fp.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fp.fileno(), fcntl.LOCK_UN)


def candidate_path(root: Path, entry: dict) -> Path:
    """Never use arbitrary filesystem paths provided by queue events."""
    folder, filename, kind = entry.get('source'), entry.get('filename'), entry.get('kind')
    if folder not in SOURCE_DIRS or kind not in DEST_BUCKETS:
        raise RuntimeError('Invalid queue source/kind')
    if not isinstance(filename, str) or not filename or filename in ('.', '..') or Path(filename).name != filename:
        raise RuntimeError('Invalid queue filename')
    valid = ((folder == 'ZING_AUDIO' and kind == 'audio' and ZING_AUDIO_PATTERN.fullmatch(filename)) or
             (folder == 'YOUTUBE_CACHE' and kind == 'audio' and YT_AUDIO_PATTERN.fullmatch(filename)) or
             (folder == 'ZING_JSON' and kind == 'lyrics' and ZING_JSON.fullmatch(filename)) or
             (folder == 'YOUTUBE_CACHE' and kind == 'lyrics' and YOUTUBE_JSON.fullmatch(filename)))
    if not valid:
        raise RuntimeError('Invalid queue file type/name')
    return root / folder / filename


def apply_event(index: dict, entry: dict, root: Path) -> None:
    p = candidate_path(root, entry)
    # Never trust stored absolute paths; use known root and folders only.
    kind = entry['kind']
    key = ident(kind, p.name)
    previous = index['files'].get(key, {})
    # AI may enqueue the same file again after a harmless cache hit/rewrite.
    size, mtime = entry.get('size'), entry.get('mtime_ns')
    if not isinstance(size, int) or size <= 0 or not isinstance(mtime, int) or mtime <= 0:
        raise RuntimeError('Invalid queue file size/mtime')
    if (previous.get('status') == 'synced' and previous.get('size') == size
            and previous.get('mtime_ns') == mtime):
        return
    index['files'][key] = {
        'kind': kind, 'source': entry['source'], 'filename': p.name,
        'size': size, 'mtime_ns': mtime, 'status': 'pending',
        'queued_utc': entry.get('queued_utc', 0), 'updated_utc': stamp(),
    }


def fold_queue(root: Path, index: dict) -> int:
    """Consume only complete event lines; index+offset are saved atomically."""
    queue = root / QUEUE_NAME
    if not queue.exists():
        return 0
    consumed = 0
    with queue_lock(root):
        with queue.open('rb') as fp:
            total = queue.stat().st_size
            offset = index['queue_offset']
            if offset > total:
                # Queue was externally truncated/rotated: read what remains, no loss.
                offset = 0
            fp.seek(offset)
            while True:
                before = fp.tell()
                line = fp.readline()
                if not line or not line.endswith(b'\n'):
                    fp.seek(before)
                    break
                try:
                    record = json.loads(line.decode('utf-8-sig'))
                    if not isinstance(record, dict):
                        raise ValueError('Event must be JSON object')
                    apply_event(index, record, root)
                except Exception as exc:
                    raise RuntimeError('Invalid queue at byte %d (%s); fix queue before syncing' %
                                       (before, short_error(exc))) from exc
                consumed += 1
            index['queue_offset'] = fp.tell()
    return consumed


def full_scan_due(index: dict, hours: int) -> bool:
    last = index.get('last_full_scan_utc', '')
    if not last:
        return True
    try:
        last_time = datetime.fromisoformat(last.replace('Z', '+00:00'))
        return (datetime.now(timezone.utc) - last_time).total_seconds() >= hours * 3600
    except (TypeError, ValueError):
        return True


def collect_drive_folders(drive: GoogleReader) -> dict:
    root_id = drive.folder('root', 'TunerTools_AppBackup')
    ai_id = drive.folder(root_id, 'AI_Music')
    return {
        'audio': drive.folder(ai_id, 'stream_cache'),
        'lyrics': drive.folder(ai_id, 'lyrics'),
    }


def reconcile_full(root: Path, index: dict, drive: GoogleReader, ids: dict) -> dict:
    """Daily/cold-start inventory. No Drive writes, no remote audio downloads."""
    files, info = choose_files(root, None)
    remote = {
        'audio': remote_by_name(drive.list_files(ids['audio']), AUDIO_EXTS),
        'lyrics': remote_by_name(drive.list_files(ids['lyrics']), {'.json'}),
    }
    touched: set[str] = set()
    counts = {'audio_local': len(files['audio']), 'lyrics_local': len(files['lyrics']),
              'audio_drive': len(remote['audio']), 'lyrics_drive': len(remote['lyrics']),
              'pending': 0, 'synced_existing': 0, 'conflicts': 0}
    for kind in ('audio', 'lyrics'):
        for path in files[kind]:
            st = path.stat()
            key = ident(kind, path.name)
            touched.add(key)
            matches = remote[kind].get(path.name, [])
            old = index['files'].get(key) or {}
            rec = {
                'kind': kind, 'source': path.parent.name, 'filename': path.name,
                'size': st.st_size, 'mtime_ns': st.st_mtime_ns,
                'updated_utc': stamp(),
            }
            if len(matches) > 1:
                rec.update(status='conflict', error='Duplicate Drive filename')
                counts['conflicts'] += 1
            elif len(matches) == 1:
                other = matches[0]
                if str(other.get('size')) == str(st.st_size):
                    # New/replaced files must be checked by MD5, even if name
                    # and size match. Historical files are bootstrapped using
                    # size-only metadata to avoid thousands of API requests.
                    changed = bool(old) and (
                        old.get('status') != 'synced' or old.get('size') != st.st_size or
                        old.get('mtime_ns') != st.st_mtime_ns)
                    if changed:
                        rec.update(status='pending')
                        counts['pending'] += 1
                    else:
                        rec.update(status='synced', drive_id=str(other.get('id') or ''),
                                   verification=old.get('verification', 'size'),
                                   verified_utc=old.get('verified_utc', stamp()))
                        counts['synced_existing'] += 1
                else:
                    rec.update(status='conflict', error='Different Drive file size; no overwrite')
                    counts['conflicts'] += 1
            else:
                rec['status'] = 'pending'
                counts['pending'] += 1
            index['files'][key] = rec
    for key, entry in index['files'].items():
        if key not in touched and entry.get('status') != 'absent_local':
            entry['status'] = 'absent_local'
            entry['updated_utc'] = stamp()
    index['last_full_scan_utc'] = stamp()
    if info.get('issues'):
        print('FULL SCAN WARNINGS:', len(info['issues']))
        for warn in info['issues'][:4]: print('  -', warn)
    if info.get('invalid'):
        print('INVALID JSON SKIPPED:', len(info['invalid']))
    if info.get('unrecognized_audio'):
        print('UNRECOGNIZED AUDIO SKIPPED:', len(info['unrecognized_audio']))
    return counts


def process_one(root: Path, report: Path, index: dict, record: dict,
                drive: GoogleReader, ids: dict, args: argparse.Namespace) -> str:
    path = candidate_path(root, record)
    if not path.is_file():
        record.update(status='absent_local', error='Local file removed', updated_utc=stamp())
        return 'ABSENT'
    try:
        size, mtime = check_stable(path, args.min_age)
    except Exception as exc:
        record.update(status='not_ready', error=short_error(exc), updated_utc=stamp())
        return 'NOT_READY'
    if record.get('size') != size or record.get('mtime_ns') != mtime:
        # File was replaced after AI enqueued it; verify latest content.
        record.update(size=size, mtime_ns=mtime, status='pending')
    if record['kind'] == 'lyrics' and not valid_json(path):
        record.update(status='not_ready', error='Invalid or incomplete JSON', updated_utc=stamp())
        return 'NOT_READY'
    kind = record['kind']
    # Required even with a fresh local manifest: Drive may have received an
    # upload before a crash. Only this exact filename in the exact destination.
    exact = [x for x in drive.list_files(ids[kind], path.name)
             if x.get('name') == path.name and x.get('mimeType') != FOLDER_MIME]
    if len(exact) > 1:
        record.update(status='conflict', error='Duplicate Drive filename', updated_utc=stamp())
        return 'CONFLICT'
    if len(exact) == 1:
        try:
            if remote_content_equal(drive, exact[0], path, require_md5=True):
                record.update(status='synced', drive_id=str(exact[0].get('id') or ''),
                              verification='md5', verified_utc=stamp(), updated_utc=stamp())
                state_path(report, kind, path, ids[kind]).unlink(missing_ok=True)
                record.pop('error', None)
                return 'ALREADY_PRESENT'
        except Exception as exc:
            record.update(status='conflict', error=short_error(exc), updated_utc=stamp())
            return 'CONFLICT'
        record.update(status='conflict', error='Drive size mismatch', updated_utc=stamp())
        return 'CONFLICT'
    created_obj = None
    post_exception = None
    try:
        created_obj, sp = upload_one(drive, ids[kind], path, kind, report,
                                     args.chunk_kib * 1024, args.put_timeout)
    except Exception as exc:
        post_exception = exc
    confirmed = None
    for attempt in range(4):
        if attempt: time.sleep(1.0 + attempt * 1.2)
        exact = [x for x in drive.list_files(ids[kind], path.name)
                 if x.get('name') == path.name and x.get('mimeType') != FOLDER_MIME]
        if len(exact) == 1:
            confirmed = exact[0]
            break
        if len(exact) > 1:
            record.update(status='conflict', error='Duplicate filename after upload', updated_utc=stamp())
            return 'CONFLICT'
    if confirmed is None:
        record.update(status='failed', error='Upload unconfirmed: ' +
                      short_error(post_exception or RuntimeError('Not visible')),
                      updated_utc=stamp())
        return 'FAILED'
    newstat = path.stat()
    if newstat.st_size != size or newstat.st_mtime_ns != mtime:
        record.update(status='conflict', error='Source changed during upload', updated_utc=stamp())
        return 'CONFLICT'
    try:
        remote_content_equal(drive, confirmed, path, require_md5=True)
    except Exception as exc:
        record.update(status='conflict', error='MD5 verification failed: ' + short_error(exc), updated_utc=stamp())
        return 'CONFLICT'
    record.update(status='synced', drive_id=str(confirmed.get('id') or ''),
                  verification='md5', verified_utc=stamp(), updated_utc=stamp())
    record.pop('error', None)
    state_path(report, kind, path, ids[kind]).unlink(missing_ok=True)
    return 'UPLOADED'


def sync_locked(args: argparse.Namespace, root: Path, report: Path) -> int:
    index_path = root / INDEX_NAME
    index = load_index(index_path)
    events = fold_queue(root, index)
    due = args.full or full_scan_due(index, args.full_hours)
    print('===== TUNERTOOLS AI DRIVE INCREMENTAL SYNC =====')
    print('MODE:', 'APPLY / CREATE ONLY' if args.apply else 'PREVIEW ONLY')
    print('SOURCE:', root)
    print('DRIVE: AI_Music/{stream_cache,lyrics} ONLY')
    print('QUEUE EVENTS NEW:', events, 'INDEX ITEMS:', len(index['files']))
    print('RECONCILE:', 'YES (cold-start/daily/forced)' if due else 'NO (pending only)')
    print('UTC:', stamp())
    if args.apply:
        # Persist new pending entries and byte offset BEFORE touching Drive.
        # A crash will leave a resumable queue/index, not lose events.
        write_index(index_path, index)
    pending = [v for v in index['files'].values()
               if v.get('status') in ('pending', 'failed', 'not_ready')]
    if not due and not pending:
        print('FAST EXIT: no pending files. No Google Drive API calls needed.')
        return 0
    if not args.apply and not due:
        print('PREVIEW: %d pending, %d max per run' % (len(pending), args.max_files))
        for record in pending[:12]:
            print('  WOULD CHECK:', record['kind'].upper(), record['filename'])
        print('PREVIEW: no files uploaded and index unchanged')
        return 0

    token = Path(args.token) if args.token else next((Path(x) for x in TOKEN_DEFAULTS if Path(x).is_file()), None)
    if token is None or not token.is_file():
        raise RuntimeError('OAuth token not found; use existing drive_token.json')
    drive = GoogleReader(token)
    ids = collect_drive_folders(drive)
    if due:
        stats = reconcile_full(root, index, drive, ids)
        print('FULL RECONCILE:', stats)
        if args.apply:
            write_index(index_path, index)
    pending = [v for v in index['files'].values()
               if v.get('status') in ('pending', 'failed', 'not_ready')]
    pending.sort(key=lambda v: (v.get('queued_utc', 0), v['kind'], v['filename'].casefold()))
    print('PENDING:', len(pending), 'MAX THIS RUN:', args.max_files)
    if not args.apply:
        for record in pending[:12]: print('  WOULD CHECK:', record['kind'].upper(), record['filename'])
        return 0
    result = {'utc': stamp(), 'mode': 'incremental', 'full_reconcile': due, 'new_queue_events': events,
              'pending_before': len(pending), 'uploaded': [], 'present': [],
              'failed': [], 'conflict': [], 'not_ready': [], 'absent': [], 'remaining': 0}
    for number, record in enumerate(pending[:args.max_files], 1):
        filename, kind = record['filename'], record['kind']
        print('[%d/%d] %s %s' % (number, min(len(pending), args.max_files), kind.upper(), filename))
        try:
            outcome = process_one(root, report, index, record, drive, ids, args)
        except Exception as exc:
            record.update(status='failed', error=short_error(exc), updated_utc=stamp())
            outcome = 'FAILED'
        key = {'UPLOADED': 'uploaded', 'ALREADY_PRESENT': 'present', 'FAILED': 'failed',
               'CONFLICT': 'conflict', 'NOT_READY': 'not_ready', 'ABSENT': 'absent'}[outcome]
        result[key].append({'file': filename, 'kind': kind, 'error': record.get('error', '')})
        print('  ' + outcome + (': ' + record['error'] if record.get('error') else ''))
        write_index(index_path, index)
        if args.pause and outcome == 'UPLOADED': time.sleep(args.pause)
    result['remaining'] = sum(v.get('status') in ('pending','failed','not_ready') for v in index['files'].values())
    path = report / 'AI_DRIVE_SYNC_LAST_RUN.json'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('===== COMPLETE =====')
    print('UPLOADED:',len(result['uploaded']), 'PRESENT:',len(result['present']),
          'FAILED:',len(result['failed']), 'CONFLICT:',len(result['conflict']),
          'WAITING:',len(result['not_ready']), 'QUEUED:',result['remaining'])
    print('REPORT:', path)
    print('No Drive files were overwritten, renamed or deleted.')
    return 1 if result['failed'] or result['conflict'] else 0



# =====================================================================
# WINDOWS CONSOLE MENU + TASK SCHEDULER (NO AUXILIARY .ps1/.txt FILES)
# =====================================================================
TASK_NAME = 'TunerTools_AI_Drive_AutoSync'
LEGACY_TASK_NAME = 'TunerTools_AI_Drive_Sync_15Min'


def _task_xml(name: str):
    if os.name != 'nt':
        return None
    proc = subprocess.run(['schtasks.exe', '/Query', '/TN', name, '/XML'],
                          capture_output=True, check=False)
    if proc.returncode != 0:
        return None
    # Windows may emit UTF-16; XML parsers recognize its BOM automatically.
    try:
        return ET.fromstring(proc.stdout)
    except ET.ParseError:
        try:
            return ET.fromstring(proc.stdout.decode('mbcs', errors='replace'))
        except (ET.ParseError, UnicodeError):
            return True  # Task is present, but its details cannot be read.


def _xml_text(tree, tag: str) -> str:
    if not isinstance(tree, ET.Element):
        return ''
    for node in tree.iter():
        if node.tag.rsplit('}', 1)[-1] == tag:
            return (node.text or '').strip()
    return ''


def schedule_status() -> None:
    current = _task_xml(TASK_NAME)
    old = _task_xml(LEGACY_TASK_NAME)
    if current is None:
        print('LICH: DANG TAT')
    else:
        interval = _xml_text(current, 'Interval')
        hour = re.fullmatch(r'PT(\d+)H', interval)
        label = ('moi %s gio' % hour.group(1)) if hour else ('interval=' + interval if interval else 'da dang ky')
        print('LICH: DANG BAT (%s)' % label)
        script_name = Path(__file__).name.casefold()
        config = _xml_text(current, 'Arguments')
        if script_name not in config.casefold():
            print('CANH BAO: Lich hien tai van goi script CU. Hay chon 2 va cai lai lich!')
    if old is not None:
        print('CANH BAO: Lich cu 15 phut van ton tai; cai lai lich moi de xoa.')


def _is_admin() -> bool:
    if os.name != 'nt':
        return True
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _run_task_command(args: list[str], ignore_missing: bool = False) -> None:
    proc = subprocess.run(['schtasks.exe'] + args, capture_output=True, text=True,
                          errors='replace')
    if proc.returncode and not ignore_missing:
        raise RuntimeError('Task Scheduler exit %d: %s' %
                           (proc.returncode, (proc.stderr or proc.stdout).strip()[:500]))


def configure_schedule(hours: int) -> None:
    if os.name != 'nt':
        raise RuntimeError('Task Scheduler works on Windows only')
    if not _is_admin():
        raise RuntimeError('Please run as Administrator')
    if hours not in (1, 2, 6, 12):
        raise ValueError('Hours must be 1,2,6,12')
    root = Path(SOURCE_DEFAULT)
    if not root.is_dir():
        raise RuntimeError('AI_Music source directory missing: ' + str(root))
    python_exe = Path(sys.executable).resolve()
    if not python_exe.is_file():
        raise RuntimeError('Python executable missing: ' + str(python_exe))
    script = Path(__file__).resolve()
    if not script.is_file():
        raise RuntimeError('Sync Python file missing')
    # A single .py is the scheduled action; no per-task PowerShell dependency.
    target = ('"%s" "%s" --apply --scheduled --max-files 200' %
              (python_exe, script))
    first_run = (datetime.now() + timedelta(minutes=2)).strftime('%H:%M')
    args = ['/Create', '/F', '/SC', 'HOURLY', '/MO', str(hours),
            '/ST', first_run, '/TN', TASK_NAME, '/TR', target,
            '/RU', 'SYSTEM', '/RL', 'HIGHEST']
    _run_task_command(args)
    # Do not remove legacy until new task registration is successful.
    if _task_xml(LEGACY_TASK_NAME) is not None:
        _run_task_command(['/Delete', '/F', '/TN', LEGACY_TASK_NAME])
    print('DA DAT LICH: moi %d gio (tai khoan SYSTEM)' % hours)
    print('CHU Y: SYSTEM phai doc duoc token trong BackupScripts.')
    print('NHAT KY: ' + str(root / 'Reports' / 'Drive_AutoSync' / 'TaskLogs'))


def disable_schedule() -> None:
    if os.name != 'nt' or not _is_admin():
        raise RuntimeError('Please run as Administrator on Windows')
    for name in (TASK_NAME, LEGACY_TASK_NAME):
        if _task_xml(name) is not None:
            _run_task_command(['/Delete', '/F', '/TN', name])
    print('LICH DA TAT. Khong xoa du lieu Drive.')


def _pause() -> None:
    try:
        input('Nhan ENTER de tiep tuc...')
    except EOFError:
        pass


def _ensure_admin_for_menu() -> bool:
    if _is_admin():
        return True
    if os.name != 'nt':
        return True
    print('Can quyen Administrator de upload va cai lich. Dang yeu cau UAC...')
    script = str(Path(__file__).resolve())
    parameters = '"%s" --menu' % script
    result = ctypes.windll.shell32.ShellExecuteW(None, 'runas',
                                                   str(Path(sys.executable).resolve()),
                                                   parameters, str(Path(__file__).parent), 1)
    if result <= 32:
        raise RuntimeError('Cannot elevate to Administrator (UAC code %d)' % result)
    return False


def menu_main() -> int:
    if not _ensure_admin_for_menu():
        return 8  # Close the non-admin launcher; elevated menu is already open.
    try:
        sys.stdout.reconfigure(errors='replace')
    except (AttributeError, OSError):
        pass
    while True:
        print('\n' + '=' * 48)
        print(' TUNERTOOLS - AI MUSIC -> GOOGLE DRIVE')
        print('=' * 48)
        print('2 folders Drive: stream_cache + lyrics (khong xoa/ghi de)')
        print('Dong bo tang dan: QUEUE + INDEX; doi soat day du 24 gio')
        schedule_status()
        ai_app = Path(SOURCE_DEFAULT) / 'app.py'
        try:
            ready = '_ai_drive_enqueue_completed_file' in ai_app.read_text(encoding='utf-8-sig')
        except (OSError, UnicodeError):
            ready = False
        if not ready:
            print('CANH BAO: app.py chua co queue; can cai app.py da sua o ban truoc.')
        print('  1. CHAY DONG BO THU CONG NGAY')
        print('  2. CAI / THAY DOI / TAT LICH DONG BO')
        print('  0. THOAT')
        choice = input('Chon: ').strip()
        if choice == '0':
            return 0
        if choice == '1':
            print('DANG DONG BO, khong tat cua so cho den khi hoan tat.')
            status = sync_cli(['--apply', '--max-files', '1000'])
            print('KET QUA: ' + ('THANH CONG' if status == 0 else 'CO LOI, xem nhat ky'))
            _pause()
            continue
        if choice == '2':
            while True:
                print('\n===== LICH DONG BO =====')
                schedule_status()
                print('  1. Moi 1 gio')
                print('  2. Moi 2 gio')
                print('  3. Moi 6 gio')
                print('  4. Moi 12 gio')
                print('  5. TAT lich')
                print('  0. Quay lai')
                slot = input('Chon: ').strip()
                if slot == '0':
                    break
                try:
                    if slot in ('1', '2', '3', '4'):
                        configure_schedule({'1': 1, '2': 2, '3': 6, '4': 12}[slot])
                    elif slot == '5':
                        disable_schedule()
                    else:
                        print('Khong hop le.'); continue
                except Exception as exc:
                    print('LOI: ' + short_error(exc))
                _pause()
                break
            continue
        print('Lua chon khong hop le')
        _pause()


class TeeOutput:
    def __init__(self, terminal, logfile):
        self.terminal = terminal
        self.logfile = logfile
    def write(self, msg):
        self.terminal.write(msg)
        self.logfile.write(msg)
        self.logfile.flush()
    def flush(self):
        self.terminal.flush()
        self.logfile.flush()
    @property
    def encoding(self):
        return getattr(self.terminal, 'encoding', 'utf-8')


def sync_cli(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='TunerTools AI Drive - standalone incremental sync')
    parser.add_argument('--menu', action='store_true', help='Show interactive menu')
    parser.add_argument('--source', default=SOURCE_DEFAULT)
    parser.add_argument('--token', default='')
    parser.add_argument('--report', default='')
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--scheduled', action='store_true')
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--full-hours', type=int, default=24)
    parser.add_argument('--min-age', type=int, default=120)
    parser.add_argument('--max-files', type=int, default=200)
    parser.add_argument('--pause', type=float, default=1.5)
    parser.add_argument('--chunk-kib', type=int, default=1024)
    parser.add_argument('--put-timeout', type=int, default=300)
    args = parser.parse_args(argv)
    if args.menu:
        return menu_main()
    if not (1 <= args.full_hours <= 720): parser.error('--full-hours must be 1..720')
    if not (0 <= args.min_age <= 86400): parser.error('--min-age must be 0..86400')
    if not (1 <= args.max_files <= 1000): parser.error('--max-files must be 1..1000')
    if args.chunk_kib not in (256,512,1024,2048,4096): parser.error('--chunk-kib must be 256..4096')
    if not (30 <= args.put_timeout <= 1800): parser.error('--put-timeout must be 30..1800')
    if not (0 <= args.pause <= 30): parser.error('--pause must be 0..30')
    try: sys.stdout.reconfigure(errors='replace')
    except (AttributeError, OSError): pass
    root=Path(args.source)
    if not root.is_dir():
        print('ERROR: AI_Music source not found: ' + str(root), file=sys.stderr)
        return 2
    report=Path(args.report) if args.report else root/'Reports'/'Drive_AutoSync'
    report.mkdir(parents=True, exist_ok=True)
    logfile=None
    stdout_orig=sys.stdout
    stderr_orig=sys.stderr
    if args.scheduled:
        logs=report/'TaskLogs'
        logs.mkdir(parents=True, exist_ok=True)
        # Keep a small operational log history outside the Tools folder.
        for old_log in logs.glob('Sync_*.log'):
            try:
                if old_log.stat().st_mtime < time.time() - 30 * 86400:
                    old_log.unlink()
            except OSError:
                pass
        logfile=(logs/('Sync_%s_%d.log' % (datetime.now().strftime('%Y%m%d_%H%M%S'), os.getpid()))).open('w', encoding='utf-8')
        sys.stdout=TeeOutput(stdout_orig, logfile)
        sys.stderr=TeeOutput(stderr_orig, logfile)
    try:
        print('TUNERTOOLS sync start:', stamp())
        guard=acquire_lock(report)
        try:
            return sync_locked(args, root, report)
        finally:
            guard.close()
    except Exception as exc:
        print('ERROR:', short_error(exc), file=sys.stderr)
        return 2
    finally:
        if logfile is not None:
            sys.stdout=stdout_orig
            sys.stderr=stderr_orig
            logfile.close()


if __name__ == '__main__':
    raise SystemExit(sync_cli())
