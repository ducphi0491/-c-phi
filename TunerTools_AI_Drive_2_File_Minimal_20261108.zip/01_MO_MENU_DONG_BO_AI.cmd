@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
py -3 -c "import sys;sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 goto PYTHON_FALLBACK
py -3 "%~dp0SYNC_AI_DRIVE.py" --menu
goto FINISHED
:PYTHON_FALLBACK
python -c "import sys;sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3.10+ not found. Install or add Python to PATH.
    pause
    exit /b 1
)
python "%~dp0SYNC_AI_DRIVE.py" --menu
:FINISHED
if "%ERRORLEVEL%"=="8" exit /b 0
if errorlevel 1 echo MENU failed. Check Python and Administrator permissions.
pause
