package duc_phi.music

import android.content.Context
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs

internal enum class BuiltInSmartPlaylist {
    MOST_PLAYED,
    RECENTLY_PLAYED,
    NEWLY_ADDED,
    NEVER_PLAYED,
    LONG_NOT_HEARD
}

internal enum class SmartMatchMode { ALL, ANY }

internal enum class SmartSortType {
    MOST_PLAYED,
    RECENTLY_PLAYED,
    NEWEST_ADDED,
    TITLE,
    ARTIST,
    DURATION_ASC,
    DURATION_DESC,
    DAILY_RANDOM
}

internal enum class SmartRuleField {
    ARTIST,
    ALBUM,
    GENRE,
    FOLDER,
    SOURCE,
    DURATION_MINUTES,
    PLAY_COUNT,
    DATE_ADDED_DAYS,
    LAST_PLAYED_DAYS,
    FAVORITE
}

internal enum class SmartRuleOperator {
    EQUALS,
    NOT_EQUALS,
    CONTAINS,
    NOT_CONTAINS,
    GREATER_THAN,
    LESS_THAN,
    BETWEEN,
    WITHIN_DAYS,
    OLDER_THAN_DAYS,
    IS_TRUE,
    IS_FALSE
}

@Entity(tableName = "song_playback_stats")
internal data class SongPlaybackStatsEntity(
    @PrimaryKey val songId: String,
    val playCount: Int = 0,
    val totalListenMs: Long = 0L,
    val firstPlayedAtMs: Long = 0L,
    val lastPlayedAtMs: Long = 0L,
    val skipCount: Int = 0
)

@Entity(tableName = "smart_playlists")
internal data class SmartPlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val matchMode: String = SmartMatchMode.ALL.name,
    val sortType: String = SmartSortType.MOST_PLAYED.name,
    val maxItems: Int = 50,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "smart_playlist_rules",
    foreignKeys = [
        ForeignKey(
            entity = SmartPlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("playlistId")]
)
internal data class SmartPlaylistRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val playlistId: Long,
    val field: String,
    val operator: String,
    val value: String = "",
    val secondValue: String = ""
)

internal data class SmartPlaylistRuleDraft(
    val field: SmartRuleField = SmartRuleField.ARTIST,
    val operator: SmartRuleOperator = SmartRuleOperator.CONTAINS,
    val value: String = "",
    val secondValue: String = ""
)

internal data class SmartPlaylistDraft(
    val id: Long = 0L,
    val name: String = "",
    val matchMode: SmartMatchMode = SmartMatchMode.ALL,
    val sortType: SmartSortType = SmartSortType.MOST_PLAYED,
    val maxItems: Int = 50,
    val rules: List<SmartPlaylistRuleDraft> = listOf(SmartPlaylistRuleDraft())
)

internal data class SmartPlaylistDefinition(
    val playlist: SmartPlaylistEntity,
    val rules: List<SmartPlaylistRuleEntity>
) {
    fun toDraft(): SmartPlaylistDraft = SmartPlaylistDraft(
        id = playlist.id,
        name = playlist.name,
        matchMode = runCatching { SmartMatchMode.valueOf(playlist.matchMode) }
            .getOrDefault(SmartMatchMode.ALL),
        sortType = runCatching { SmartSortType.valueOf(playlist.sortType) }
            .getOrDefault(SmartSortType.MOST_PLAYED),
        maxItems = playlist.maxItems,
        rules = rules.map { rule ->
            SmartPlaylistRuleDraft(
                field = runCatching { SmartRuleField.valueOf(rule.field) }
                    .getOrDefault(SmartRuleField.ARTIST),
                operator = runCatching { SmartRuleOperator.valueOf(rule.operator) }
                    .getOrDefault(SmartRuleOperator.CONTAINS),
                value = rule.value,
                secondValue = rule.secondValue
            )
        }.ifEmpty { listOf(SmartPlaylistRuleDraft()) }
    )
}

internal data class SmartDuplicateGroup(
    val key: String,
    val title: String,
    val artist: String,
    val songs: List<SongItem>
)

@Dao
internal abstract class SmartPlaylistDao {
    @Query("SELECT * FROM song_playback_stats")
    abstract fun observeStats(): kotlinx.coroutines.flow.Flow<List<SongPlaybackStatsEntity>>

    @Query("SELECT * FROM song_playback_stats WHERE songId = :songId LIMIT 1")
    abstract suspend fun getStats(songId: String): SongPlaybackStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertStats(stats: SongPlaybackStatsEntity)

    @Query("DELETE FROM song_playback_stats WHERE songId = :songId")
    abstract suspend fun deleteStats(songId: String)

    @Query("SELECT * FROM smart_playlists ORDER BY updatedAtMs DESC, id DESC")
    abstract fun observePlaylists(): kotlinx.coroutines.flow.Flow<List<SmartPlaylistEntity>>

    @Query("SELECT * FROM smart_playlist_rules ORDER BY id ASC")
    abstract fun observeRules(): kotlinx.coroutines.flow.Flow<List<SmartPlaylistRuleEntity>>

    @Insert
    abstract suspend fun insertPlaylist(playlist: SmartPlaylistEntity): Long

    @Query("SELECT * FROM smart_playlists WHERE id = :playlistId LIMIT 1")
    abstract suspend fun getPlaylist(playlistId: Long): SmartPlaylistEntity?

    @Update
    abstract suspend fun updatePlaylist(playlist: SmartPlaylistEntity)

    @Query("DELETE FROM smart_playlist_rules WHERE playlistId = :playlistId")
    abstract suspend fun deleteRulesForPlaylist(playlistId: Long)

    @Insert
    abstract suspend fun insertRules(rules: List<SmartPlaylistRuleEntity>)

    @Query("DELETE FROM smart_playlists WHERE id = :playlistId")
    abstract suspend fun deletePlaylist(playlistId: Long)

    @Transaction
    open suspend fun replacePlaylist(draft: SmartPlaylistDraft): Long {
        val now = System.currentTimeMillis()
        val safeName = draft.name.trim().take(80).ifBlank { "Smart Playlist" }
        val playlistId = if (draft.id <= 0L) {
            insertPlaylist(
                SmartPlaylistEntity(
                    name = safeName,
                    matchMode = draft.matchMode.name,
                    sortType = draft.sortType.name,
                    maxItems = draft.maxItems.coerceIn(0, 500),
                    createdAtMs = now,
                    updatedAtMs = now
                )
            )
        } else {
            val current = getPlaylist(draft.id)
            updatePlaylist(
                SmartPlaylistEntity(
                    id = draft.id,
                    name = safeName,
                    matchMode = draft.matchMode.name,
                    sortType = draft.sortType.name,
                    maxItems = draft.maxItems.coerceIn(0, 500),
                    createdAtMs = current?.createdAtMs ?: now,
                    updatedAtMs = now
                )
            )
            draft.id
        }
        deleteRulesForPlaylist(playlistId)
        val entities = draft.rules
            .take(12)
            .map { rule ->
                SmartPlaylistRuleEntity(
                    playlistId = playlistId,
                    field = rule.field.name,
                    operator = rule.operator.name,
                    value = rule.value.trim().take(200),
                    secondValue = rule.secondValue.trim().take(200)
                )
            }
        if (entities.isNotEmpty()) insertRules(entities)
        return playlistId
    }
}

@Database(
    entities = [
        SongPlaybackStatsEntity::class,
        SmartPlaylistEntity::class,
        SmartPlaylistRuleEntity::class
    ],
    version = 1,
    exportSchema = false
)
internal abstract class MeloWaveSmartPlaylistDatabase : RoomDatabase() {
    abstract fun smartPlaylistDao(): SmartPlaylistDao

    companion object {
        @Volatile private var instance: MeloWaveSmartPlaylistDatabase? = null

        fun get(context: Context): MeloWaveSmartPlaylistDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                MeloWaveSmartPlaylistDatabase::class.java,
                "melowave_smart_playlist.db"
            ).build().also { instance = it }
        }
    }
}

@Stable
internal class SmartPlaylistRepository(
    context: Context,
    private val scope: CoroutineScope
) {
    private val dao = MeloWaveSmartPlaylistDatabase.get(context).smartPlaylistDao()
    private val writeMutex = Mutex()

    var statsBySongId by mutableStateOf<Map<String, SongPlaybackStatsEntity>>(emptyMap())
        private set
    var customPlaylists by mutableStateOf<List<SmartPlaylistDefinition>>(emptyList())
        private set
    var ready by mutableStateOf(false)
        private set
    private var statsLoaded = false
    private var playlistsLoaded = false
    var lastError by mutableStateOf<String?>(null)
        private set

    init {
        scope.launch {
            try {
                dao.observeStats().collect { items ->
                    statsBySongId = items.associateBy(SongPlaybackStatsEntity::songId)
                    statsLoaded = true
                    ready = statsLoaded && playlistsLoaded
                }
            } catch (error: Throwable) {
                lastError = error.localizedMessage ?: "Không thể đọc thống kê nghe nhạc"
            }
        }
        scope.launch {
            try {
                combine(dao.observePlaylists(), dao.observeRules()) { playlists, rules ->
                    playlists.map { playlist ->
                        SmartPlaylistDefinition(
                            playlist = playlist,
                            rules = rules.filter { it.playlistId == playlist.id }
                        )
                    }
                }.collect { definitions ->
                    customPlaylists = definitions
                    playlistsLoaded = true
                    ready = statsLoaded && playlistsLoaded
                }
            } catch (error: Throwable) {
                lastError = error.localizedMessage ?: "Không thể đọc Smart Playlist"
            }
        }
    }

    fun recordListening(
        songId: String,
        listenDeltaMs: Long,
        incrementPlayCount: Boolean,
        incrementSkipCount: Boolean,
        playedAtMs: Long = System.currentTimeMillis()
    ) {
        if (songId.isBlank()) return
        val safeDelta = listenDeltaMs.coerceAtLeast(0L)
        if (safeDelta <= 0L && !incrementPlayCount && !incrementSkipCount) return
        scope.launch(Dispatchers.IO) {
            val error = writeMutex.withLock {
                runCatching {
                    val previous = dao.getStats(songId) ?: SongPlaybackStatsEntity(songId = songId)
                    dao.upsertStats(
                        previous.copy(
                            playCount = previous.playCount + if (incrementPlayCount) 1 else 0,
                            totalListenMs = previous.totalListenMs + safeDelta,
                            firstPlayedAtMs = when {
                                previous.firstPlayedAtMs > 0L -> previous.firstPlayedAtMs
                                incrementPlayCount -> playedAtMs
                                else -> 0L
                            },
                            lastPlayedAtMs = if (incrementPlayCount) playedAtMs
                            else previous.lastPlayedAtMs,
                            skipCount = previous.skipCount + if (incrementSkipCount) 1 else 0
                        )
                    )
                }.exceptionOrNull()
            }
            if (error != null) {
                withContext(Dispatchers.Main.immediate) {
                    lastError = error.localizedMessage ?: "Không thể lưu thống kê nghe nhạc"
                }
            }
        }
    }

    fun savePlaylist(draft: SmartPlaylistDraft, onSaved: ((Long) -> Unit)? = null) {
        scope.launch(Dispatchers.IO) {
            val result = runCatching { dao.replacePlaylist(draft) }
            withContext(Dispatchers.Main.immediate) {
                result.fold(
                    onSuccess = { id ->
                        lastError = null
                        onSaved?.invoke(id)
                    },
                    onFailure = { error ->
                        lastError = error.localizedMessage ?: "Không thể lưu Smart Playlist"
                    }
                )
            }
        }
    }

    fun deletePlaylist(playlistId: Long) {
        if (playlistId <= 0L) return
        scope.launch(Dispatchers.IO) {
            val result = runCatching { dao.deletePlaylist(playlistId) }
            withContext(Dispatchers.Main.immediate) {
                result.fold(
                    onSuccess = { lastError = null },
                    onFailure = { error ->
                        lastError = error.localizedMessage ?: "Không thể xóa Smart Playlist"
                    }
                )
            }
        }
    }

    fun clearError() {
        lastError = null
    }
}

internal fun smartPlaylistCount(
    type: BuiltInSmartPlaylist,
    songs: List<SongItem>,
    stats: Map<String, SongPlaybackStatsEntity>
): Int {
    val now = System.currentTimeMillis()
    return songs.count { song ->
        when (type) {
            BuiltInSmartPlaylist.MOST_PLAYED -> (stats[song.id]?.playCount ?: 0) > 0
            BuiltInSmartPlaylist.RECENTLY_PLAYED -> (stats[song.id]?.lastPlayedAtMs ?: 0L) > 0L
            BuiltInSmartPlaylist.NEWLY_ADDED -> song.dateAddedMs > 0L
            BuiltInSmartPlaylist.NEVER_PLAYED -> (stats[song.id]?.playCount ?: 0) == 0
            BuiltInSmartPlaylist.LONG_NOT_HEARD -> {
                val last = stats[song.id]?.lastPlayedAtMs ?: 0L
                last > 0L && now - last >= 30L * DAY_MS
            }
        }
    }
}

internal fun smartPlaylistSongs(
    type: BuiltInSmartPlaylist,
    songs: List<SongItem>,
    stats: Map<String, SongPlaybackStatsEntity>,
    limit: Int = 0
): List<SongItem> {
    val now = System.currentTimeMillis()
    val result = when (type) {
        BuiltInSmartPlaylist.MOST_PLAYED -> songs
            .filter { (stats[it.id]?.playCount ?: 0) > 0 }
            .sortedWith(
                compareByDescending<SongItem> { stats[it.id]?.playCount ?: 0 }
                    .thenByDescending { stats[it.id]?.totalListenMs ?: 0L }
                    .thenBy { smartNormalize(it.title) }
            )

        BuiltInSmartPlaylist.RECENTLY_PLAYED -> songs
            .filter { (stats[it.id]?.lastPlayedAtMs ?: 0L) > 0L }
            .sortedByDescending { stats[it.id]?.lastPlayedAtMs ?: 0L }

        BuiltInSmartPlaylist.NEWLY_ADDED -> songs
            .filter { it.dateAddedMs > 0L }
            .sortedByDescending(SongItem::dateAddedMs)

        BuiltInSmartPlaylist.NEVER_PLAYED -> songs
            .filter { (stats[it.id]?.playCount ?: 0) == 0 }
            .sortedWith(
                compareByDescending<SongItem> { it.dateAddedMs }
                    .thenBy { smartNormalize(it.title) }
            )

        BuiltInSmartPlaylist.LONG_NOT_HEARD -> songs
            .filter {
                val last = stats[it.id]?.lastPlayedAtMs ?: 0L
                last > 0L && now - last >= 30L * DAY_MS
            }
            .sortedBy { stats[it.id]?.lastPlayedAtMs ?: Long.MAX_VALUE }
    }
    return if (limit <= 0) result else result.take(limit.coerceAtMost(5_000))
}

internal fun countCustomSmartPlaylistSongs(
    definition: SmartPlaylistDefinition,
    songs: List<SongItem>,
    stats: Map<String, SongPlaybackStatsEntity>,
    isFavorite: (SongItem) -> Boolean
): Int {
    val matchMode = runCatching { SmartMatchMode.valueOf(definition.playlist.matchMode) }
        .getOrDefault(SmartMatchMode.ALL)
    val rules = definition.rules
    if (rules.isEmpty()) return songs.size
    val now = System.currentTimeMillis()
    return songs.count { song ->
        val results = rules.map { rule ->
            matchesSmartRule(song, stats[song.id], isFavorite(song), rule, now)
        }
        if (matchMode == SmartMatchMode.ALL) results.all { it } else results.any { it }
    }
}

internal fun evaluateCustomSmartPlaylistSongs(
    definition: SmartPlaylistDefinition,
    songs: List<SongItem>,
    stats: Map<String, SongPlaybackStatsEntity>,
    isFavorite: (SongItem) -> Boolean
): List<SongItem> {
    val matchMode = runCatching { SmartMatchMode.valueOf(definition.playlist.matchMode) }
        .getOrDefault(SmartMatchMode.ALL)
    val sortType = runCatching { SmartSortType.valueOf(definition.playlist.sortType) }
        .getOrDefault(SmartSortType.MOST_PLAYED)
    val rules = definition.rules
    val now = System.currentTimeMillis()

    val matched = songs.filter { song ->
        if (rules.isEmpty()) true
        else {
            val results = rules.map { rule ->
                matchesSmartRule(song, stats[song.id], isFavorite(song), rule, now)
            }
            if (matchMode == SmartMatchMode.ALL) results.all { it } else results.any { it }
        }
    }

    val sorted = when (sortType) {
        SmartSortType.MOST_PLAYED -> matched.sortedWith(
            compareByDescending<SongItem> { stats[it.id]?.playCount ?: 0 }
                .thenByDescending { stats[it.id]?.lastPlayedAtMs ?: 0L }
        )
        SmartSortType.RECENTLY_PLAYED -> matched.sortedByDescending {
            stats[it.id]?.lastPlayedAtMs ?: 0L
        }
        SmartSortType.NEWEST_ADDED -> matched.sortedByDescending(SongItem::dateAddedMs)
        SmartSortType.TITLE -> matched.sortedBy { smartNormalize(it.title) }
        SmartSortType.ARTIST -> matched.sortedWith(
            compareBy<SongItem> { smartNormalize(it.artist) }.thenBy { smartNormalize(it.title) }
        )
        SmartSortType.DURATION_ASC -> matched.sortedBy { it.durationMs }
        SmartSortType.DURATION_DESC -> matched.sortedByDescending { it.durationMs }
        SmartSortType.DAILY_RANDOM -> {
            val dailySeed = System.currentTimeMillis() / DAY_MS
            matched.sortedBy { (it.id.hashCode().toLong() xor dailySeed) }
        }
    }

    val maxItems = definition.playlist.maxItems
    return if (maxItems <= 0) sorted else sorted.take(maxItems.coerceAtMost(500))
}

private fun matchesSmartRule(
    song: SongItem,
    stats: SongPlaybackStatsEntity?,
    favorite: Boolean,
    rule: SmartPlaylistRuleEntity,
    now: Long
): Boolean {
    val field = runCatching { SmartRuleField.valueOf(rule.field) }.getOrNull() ?: return true
    val operator = runCatching { SmartRuleOperator.valueOf(rule.operator) }.getOrNull() ?: return true
    val first = rule.value.trim()
    val second = rule.secondValue.trim()

    fun stringMatch(actual: String): Boolean {
        val normalizedActual = smartNormalize(actual)
        val normalizedExpected = smartNormalize(first)
        if (normalizedExpected.isBlank()) return false
        return when (operator) {
            SmartRuleOperator.EQUALS -> normalizedActual == normalizedExpected
            SmartRuleOperator.NOT_EQUALS -> normalizedActual != normalizedExpected
            SmartRuleOperator.CONTAINS -> normalizedActual.contains(normalizedExpected)
            SmartRuleOperator.NOT_CONTAINS -> !normalizedActual.contains(normalizedExpected)
            else -> true
        }
    }

    fun numberMatch(actual: Double): Boolean {
        val expected = first.replace(',', '.').toDoubleOrNull() ?: return false
        val expected2 = if (operator == SmartRuleOperator.BETWEEN) {
            second.replace(',', '.').toDoubleOrNull() ?: return false
        } else expected
        return when (operator) {
            SmartRuleOperator.EQUALS -> abs(actual - expected) < 0.0001
            SmartRuleOperator.NOT_EQUALS -> abs(actual - expected) >= 0.0001
            SmartRuleOperator.GREATER_THAN -> actual > expected
            SmartRuleOperator.LESS_THAN -> actual < expected
            SmartRuleOperator.BETWEEN -> actual in minOf(expected, expected2)..maxOf(expected, expected2)
            else -> true
        }
    }

    fun dateMatch(timestamp: Long): Boolean {
        if (timestamp <= 0L) return false
        val days = ((now - timestamp).coerceAtLeast(0L) / DAY_MS).toDouble()
        val expected = first.replace(',', '.').toDoubleOrNull() ?: return false
        return when (operator) {
            SmartRuleOperator.WITHIN_DAYS -> days <= expected
            SmartRuleOperator.OLDER_THAN_DAYS -> days > expected
            SmartRuleOperator.LESS_THAN -> days < expected
            SmartRuleOperator.GREATER_THAN -> days > expected
            else -> true
        }
    }

    return when (field) {
        SmartRuleField.ARTIST -> stringMatch(song.artist)
        SmartRuleField.ALBUM -> stringMatch(song.album)
        SmartRuleField.GENRE -> stringMatch(song.genre)
        SmartRuleField.FOLDER -> stringMatch(song.folderName)
        SmartRuleField.SOURCE -> stringMatch(song.source.name)
        SmartRuleField.DURATION_MINUTES -> numberMatch(song.durationMs / 60_000.0)
        SmartRuleField.PLAY_COUNT -> numberMatch((stats?.playCount ?: 0).toDouble())
        SmartRuleField.DATE_ADDED_DAYS -> dateMatch(song.dateAddedMs)
        SmartRuleField.LAST_PLAYED_DAYS -> dateMatch(stats?.lastPlayedAtMs ?: 0L)
        SmartRuleField.FAVORITE -> when (operator) {
            SmartRuleOperator.IS_TRUE -> favorite
            SmartRuleOperator.IS_FALSE -> !favorite
            SmartRuleOperator.EQUALS -> favorite == first.equals("true", ignoreCase = true)
            SmartRuleOperator.NOT_EQUALS -> favorite != first.equals("true", ignoreCase = true)
            else -> true
        }
    }
}

internal fun findSmartDuplicateGroups(songs: List<SongItem>): List<SmartDuplicateGroup> {
    val local = songs.filter {
        it.source == SongSource.LOCAL_MEDIASTORE || it.source == SongSource.DOWNLOADED
    }
    val baseGroups = local.groupBy { song ->
        val cleanTitle = smartNormalize(song.title)
            .replace(Regex("\\b(official|audio|video|lyrics|lyric|320kbps|128kbps|remaster(?:ed)?)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val cleanArtist = smartNormalize(song.artist)
            .replace(Regex("\\b(official|topic)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        "$cleanTitle|$cleanArtist"
    }.filterKeys { it.substringBefore('|').length >= 2 }

    val output = mutableListOf<SmartDuplicateGroup>()
    baseGroups.forEach { (baseKey, candidates) ->
        if (candidates.size < 2) return@forEach
        val remaining = candidates.sortedBy { it.durationMs }.toMutableList()
        var clusterIndex = 0
        while (remaining.isNotEmpty()) {
            val seed = remaining.removeAt(0)
            val cluster = mutableListOf(seed)
            val iterator = remaining.iterator()
            while (iterator.hasNext()) {
                val candidate = iterator.next()
                val closeDuration = seed.durationMs <= 0L || candidate.durationMs <= 0L ||
                    abs(seed.durationMs - candidate.durationMs) <= 3_000L
                if (closeDuration) {
                    cluster += candidate
                    iterator.remove()
                }
            }
            if (cluster.size > 1) {
                output += SmartDuplicateGroup(
                    key = "$baseKey|${clusterIndex++}",
                    title = cluster.first().title,
                    artist = cluster.first().artist,
                    songs = cluster.sortedWith(
                        compareByDescending<SongItem> { it.mimeType?.contains("flac", true) == true }
                            .thenByDescending { it.durationMs }
                    )
                )
            }
        }
    }
    return output.sortedByDescending { it.songs.size }
}

internal fun smartRuleDefaultOperator(field: SmartRuleField): SmartRuleOperator = when (field) {
    SmartRuleField.ARTIST,
    SmartRuleField.ALBUM,
    SmartRuleField.GENRE,
    SmartRuleField.FOLDER -> SmartRuleOperator.CONTAINS

    SmartRuleField.SOURCE -> SmartRuleOperator.EQUALS

    SmartRuleField.DURATION_MINUTES,
    SmartRuleField.PLAY_COUNT -> SmartRuleOperator.GREATER_THAN

    SmartRuleField.DATE_ADDED_DAYS,
    SmartRuleField.LAST_PLAYED_DAYS -> SmartRuleOperator.WITHIN_DAYS

    SmartRuleField.FAVORITE -> SmartRuleOperator.IS_TRUE
}

internal fun smartRuleOperators(field: SmartRuleField): List<SmartRuleOperator> = when (field) {
    SmartRuleField.ARTIST,
    SmartRuleField.ALBUM,
    SmartRuleField.GENRE,
    SmartRuleField.FOLDER -> listOf(
        SmartRuleOperator.CONTAINS,
        SmartRuleOperator.NOT_CONTAINS,
        SmartRuleOperator.EQUALS,
        SmartRuleOperator.NOT_EQUALS
    )

    SmartRuleField.SOURCE -> listOf(
        SmartRuleOperator.EQUALS,
        SmartRuleOperator.NOT_EQUALS
    )

    SmartRuleField.DURATION_MINUTES,
    SmartRuleField.PLAY_COUNT -> listOf(
        SmartRuleOperator.GREATER_THAN,
        SmartRuleOperator.LESS_THAN,
        SmartRuleOperator.EQUALS,
        SmartRuleOperator.BETWEEN
    )

    SmartRuleField.DATE_ADDED_DAYS,
    SmartRuleField.LAST_PLAYED_DAYS -> listOf(
        SmartRuleOperator.WITHIN_DAYS,
        SmartRuleOperator.OLDER_THAN_DAYS
    )

    SmartRuleField.FAVORITE -> listOf(
        SmartRuleOperator.IS_TRUE,
        SmartRuleOperator.IS_FALSE
    )
}

private fun smartNormalize(value: String): String = Normalizer.normalize(
    value.lowercase(Locale.ROOT),
    Normalizer.Form.NFD
).replace(Regex("\\p{Mn}+"), "")
    .replace('đ', 'd')
    .replace(Regex("[^a-z0-9]+"), " ")
    .trim()

private const val DAY_MS = 86_400_000L
