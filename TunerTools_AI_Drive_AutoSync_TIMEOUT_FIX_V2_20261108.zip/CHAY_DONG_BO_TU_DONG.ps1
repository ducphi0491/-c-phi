param(
    [switch]$Apply,
    [string]$SourceDir = 'C:\TunerTools\Audio\AI_Music',
    [string]$TokenFile = '',
    [int]$MinAgeSeconds = 120,
    [int]$MaxFiles = 50,
    [ValidateSet(256,512,1024,2048,4096)] [int]$ChunkKiB = 1024,
    [ValidateRange(30,1800)] [int]$PutTimeoutSeconds = 300
)
$ErrorActionPreference = 'Stop'
$sync = Join-Path $PSScriptRoot 'SYNC_AI_DRIVE.py'
if (-not (Test-Path -LiteralPath $sync -PathType Leaf)) { throw 'SYNC_AI_DRIVE.py not found' }
$pythonCfg = Join-Path $PSScriptRoot 'python_path.txt'
if (Test-Path -LiteralPath $pythonCfg) {
    $pythonExe = (Get-Content -LiteralPath $pythonCfg -TotalCount 1).Trim()
    if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) { throw 'Configured Python not found' }
    $cmd = $pythonExe
    $prefix = @()
} elseif (Get-Command py.exe -ErrorAction SilentlyContinue) {
    $cmd = (Get-Command py.exe).Source
    $prefix = @('-3')
} elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
    $cmd = (Get-Command python.exe).Source
    $prefix = @()
} else {
    throw 'Python 3.10+ not installed or not on PATH'
}
$logDir = Join-Path $SourceDir 'Reports\Drive_AutoSync\TaskLogs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$logFile = Join-Path $logDir ("Sync_{0}.log" -f (Get-Date -Format 'yyyyMMdd'))
$argsPython = @($prefix) + @($sync, '--source', $SourceDir, '--min-age', [string]$MinAgeSeconds,
    '--max-files', [string]$MaxFiles, '--chunk-kib', [string]$ChunkKiB, '--put-timeout', [string]$PutTimeoutSeconds, '--report', (Join-Path $SourceDir 'Reports\Drive_AutoSync'))
if ($TokenFile) { $argsPython += @('--token', $TokenFile) }
if ($Apply) { $argsPython += '--apply' }
$mode = if ($Apply) { 'APPLY' } else { 'PREVIEW' }
$banner = "[{0}] MODE={1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $mode
Write-Host $banner
Add-Content -LiteralPath $logFile -Value $banner -Encoding Unicode
& $cmd @argsPython 2>&1 | Tee-Object -FilePath $logFile -Append
$exitCode = $LASTEXITCODE
if ($exitCode -ne 0) { throw "AI Drive sync failed (exit=$exitCode); see $logFile" }
