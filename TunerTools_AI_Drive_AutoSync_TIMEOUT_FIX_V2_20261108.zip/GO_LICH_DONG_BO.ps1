$ErrorActionPreference = 'Stop'
$taskName = 'TunerTools_AI_Drive_Sync_15Min'
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
Write-Host 'Removed automatic sync scheduled task only; no Google Drive data touched.'
