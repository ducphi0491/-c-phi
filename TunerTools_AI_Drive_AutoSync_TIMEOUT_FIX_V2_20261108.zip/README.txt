TunerTools - AI Drive AutoSync v2 (Fix write operation timed out)
Date: 2026-11-08

MUC DICH
- Upload duy nhat audio zing_acapella_QGQK47AO9MIR.ogg len dung Drive folder stream_cache.
- Sau khi thanh cong, co the bat lich dong bo audio + lyrics moi tu Server len Drive.
- Khong quet cac thu muc Drive khac, khong ghi de, khong xoa file.

KHAC PHUC v2
- Giam kich thuoc moi khoi upload tu 8 MiB xuong 1 MiB (co the chinh 256-4096 KiB).
- Tang timeout moi PUT tu 180s len 300s (co the chinh den 1800s).
- Gap timeout, tu dong PUT Content-Range: bytes */TOTAL de lay vi tri byte Drive da nhan.
- Giam tiep kich thuoc chunk xuong toi 256 KiB neu tiep tuc loi mang.
- Luu session URI tam thoi trong Reports/Drive_AutoSync/.upload_sessions, co ACL Windows gioi han cho Administrators + SYSTEM. Khong chia se thu muc nay.
- Neu chua the kiem tra trang thai Drive, KHONG tu upload file moi de tranh trung; lan chay sau tiep tuc session cu.
- Luon doi chieu MD5 va kich thuoc tren Drive; da co file dung thi bo qua.
- Upload tu 2 nguon local: ZING_AUDIO va ZING_JSON (them cache Youtube theo quy tac cu).
- Folder Drive dich DUY NHAT: AI_Music/stream_cache va AI_Music/lyrics.

BUOC 1 - CAP NHAT
Giai nen ZIP vao C:\TunerTools\Tools\AI_Drive_AutoSync voi -Force de ghi de script cu.
Khong can sua PHP, Kotlin, token Google hoac thay doi duong dan.

BUOC 2 - UPLOAD BAI MOT DEM SAY
Chay PowerShell voi tai khoan Administrator:

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CHAY_UPLOAD_MOT_DEM_SAY.ps1"

Neu mang cham va van gap timeout, co the thu 256 KiB mot khoi va timeout 600s:

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CHAY_UPLOAD_MOT_DEM_SAY.ps1" -ChunkKiB 256 -PutTimeoutSeconds 600

Luc thanh cong se co:
  OK: Drive size and MD5 verified
  UPLOADED: 1 FAILED: 0
Hoac neu lan chay truoc Drive da nhan duoc:
  PRESENT: 1 MISSING NEW: 0
  UPLOADED: 0 FAILED: 0
Ca 2 truong hop tren la thanh cong.

BUOC 3 - KIEM TRA
Chay script CHAY_UPLOAD_MOT_DEM_SAY.ps1 -Preview de xac nhan file tren Drive.
Chay KIEM_TRA_MOT_DEM_SAY.ps1 neu can kiem tra API PHP (co the cache 600s).

BUOC 4 - KHI CHAC CHAN UPLOAD RIENG THANH CONG
Dung PowerShell Admin va chay CAI_LICH_DONG_BO_15_PHUT.ps1 de dang ky task.
Task chay 15 phut/lien, duoi SYSTEM. Khong bat neu van dang test upload.

BAO CAO
C:\TunerTools\Audio\AI_Music\Reports\Drive_AutoSync\AI_DRIVE_SYNC_LAST_RUN.json

AN TOAN
- Upload sessions la credential tam thoi; khong copy .upload_sessions ra ngoai.
- Neu file cung ten nhung size/MD5 khac, script dung khong ghi de.
- Lua chon -Preview: chi doc Drive, khong upload/khong doi file Drive.
- Khi upload bao status chua xac dinh, dung chay cong cu cu de tao session moi.
- Script can Python >= 3.10 va OAuth token da duoc xac thuc.
- Chua kiem thu upload truc tiep voi Google Drive cua ban; cac bai test offline mo phong thanh cong.
