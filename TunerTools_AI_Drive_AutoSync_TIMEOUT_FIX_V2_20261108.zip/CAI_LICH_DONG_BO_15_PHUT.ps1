$ErrorActionPreference = 'Stop'
$taskName = 'TunerTools_AI_Drive_Sync_15Min'
$runScript = Join-Path $PSScriptRoot 'CHAY_DONG_BO_TU_DONG.ps1'
$pythonCfg = Join-Path $PSScriptRoot 'python_path.txt'
$source = 'C:\TunerTools\Audio\AI_Music'
if (-not (Test-Path -LiteralPath $runScript -PathType Leaf)) { throw 'CHAY_DONG_BO_TU_DONG.ps1 missing' }
if (-not (Test-Path -LiteralPath $source -PathType Container)) { throw 'AI_Music source missing' }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run PowerShell as Administrator to register scheduled task.'
}
if (Get-Command py.exe -ErrorAction SilentlyContinue) {
    $pythonExe = (& py.exe -3 -c 'import sys;print(sys.executable)' | Select-Object -Last 1).Trim()
} elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
    $pythonExe = (& python.exe -c 'import sys;print(sys.executable)' | Select-Object -Last 1).Trim()
} else {
    throw 'Python is not available. Install Python 3.10+ first.'
}
if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) { throw 'Python executable path cannot be resolved' }
Set-Content -LiteralPath $pythonCfg -Value $pythonExe -Encoding UTF8
# schtasks /SC MINUTE /MO 15 repeats indefinitely without expiring after a day.
$taskArgs = 'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $runScript + '" -Apply'
& schtasks.exe /Create /F /SC MINUTE /MO 15 /TN $taskName /TR $taskArgs /RU SYSTEM /RL HIGHEST
if ($LASTEXITCODE -ne 0) { throw 'Cannot create the 15 minute scheduled task.' }
Write-Host 'SCHEDULED TASK INSTALLED:' $taskName -ForegroundColor Green
Write-Host 'EVERY: 15 minutes. RUN AS: SYSTEM. Can also run manually.'
Write-Host 'LOG: C:\TunerTools\Audio\AI_Music\Reports\Drive_AutoSync\TaskLogs'
Write-Host 'PYTHON:' $pythonExe
