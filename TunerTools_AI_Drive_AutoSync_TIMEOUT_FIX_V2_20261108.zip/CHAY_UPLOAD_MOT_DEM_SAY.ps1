param(
    [switch]$Preview,
    [string]$SourceDir = 'C:\TunerTools\Audio\AI_Music',
    [string]$TokenFile = '',
    [ValidateSet(256,512,1024,2048,4096)] [int]$ChunkKiB = 1024,
    [ValidateRange(30,1800)] [int]$PutTimeoutSeconds = 300
)
$ErrorActionPreference = 'Stop'
$sync = Join-Path $PSScriptRoot 'SYNC_AI_DRIVE.py'
if (-not (Test-Path -LiteralPath $sync -PathType Leaf)) { throw 'SYNC_AI_DRIVE.py not found' }
$pythonCfg = Join-Path $PSScriptRoot 'python_path.txt'
if (Test-Path -LiteralPath $pythonCfg) {
    $pythonExe = (Get-Content -LiteralPath $pythonCfg -TotalCount 1).Trim()
    if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) { throw 'Configured Python not found' }
    $cmd = $pythonExe
    $prefix = @()
} elseif (Get-Command py.exe -ErrorAction SilentlyContinue) {
    $cmd = (Get-Command py.exe).Source
    $prefix = @('-3')
} elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
    $cmd = (Get-Command python.exe).Source
    $prefix = @()
} else {
    throw 'Python 3.10+ not installed or not on PATH'
}
$argsPython = @($prefix) + @($sync, '--source', $SourceDir, '--single-id', 'QGQK47AO9MIR', '--min-age', '0', '--chunk-kib', [string]$ChunkKiB, '--put-timeout', [string]$PutTimeoutSeconds)
if ($TokenFile) { $argsPython += @('--token', $TokenFile) }
if (-not $Preview) { $argsPython += '--apply' }
Write-Host '====== TUNERTOOLS: QGQK47AO9MIR -> AI_Music/stream_cache ======' -ForegroundColor Cyan
Write-Host ('MODE: ' + $(if ($Preview) { 'PREVIEW - NO UPLOAD' } else { 'UPLOAD EXACT ONE AUDIO FILE' }))
& $cmd @argsPython
if ($LASTEXITCODE -ne 0) { throw "AI Drive upload failed (exit=$LASTEXITCODE)" }
