$ErrorActionPreference = 'Stop'
$id = 'QGQK47AO9MIR'
$url = 'https://tuner.alwaysdata.net/api_ai_media_drive.php?action=cached_songs'
Write-Host ('Reading PHP Drive catalog (cached up to 600s): ' + $url) -ForegroundColor Cyan
$d = Invoke-RestMethod -Uri $url -TimeoutSec 120
$hits = @($d.songs | Where-Object { $_.id -eq $id })
if ($hits.Count -eq 0) {
    Write-Host 'NOT FOUND IN PHP CATALOG. Check Drive upload and PHP cache.' -ForegroundColor Yellow
    exit 1
}
$hits | Select-Object id,title,singer,source,has_audio_cache,has_lyrics_cache | Format-List
if (@($hits | Where-Object { $_.has_audio_cache -eq $true -and $_.has_lyrics_cache -eq $true }).Count -gt 0) {
    Write-Host 'OK: One song has both audio and JSON flags in Drive PHP catalog.' -ForegroundColor Green
    exit 0
}
Write-Host 'NOT YET BOTH TRUE: Verify upload report or wait for PHP cache refresh.' -ForegroundColor Yellow
exit 2
