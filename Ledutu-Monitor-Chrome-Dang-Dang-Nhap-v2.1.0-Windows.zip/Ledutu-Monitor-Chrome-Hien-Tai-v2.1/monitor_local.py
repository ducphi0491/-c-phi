#!/usr/bin/env python3
"""Local, metadata-only monitor receiver for a user-authorized Ledutu browser tab."""
from __future__ import annotations

import collections
import datetime as dt
import html
import json
import re
import threading
import time
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

HOST = "127.0.0.1"
PORT = 8765
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "ket_qua"
VERSION = "2.1.0"
END_STATUSES = {"completed", "failed", "cancelled", "expired"}
SECRET_KEY = re.compile(r"(password|passwd|secret|token|authorization|cookie|session|csrf|xsrf|api.?key|email|phone|credential|signature|signed|user.?id|file.?name|file.?path|audio.?url|video.?url|source.?url|youtube.?url)", re.I)
SECRET_TEXT = re.compile(r"(?i)(?:bearer\s+)[a-z0-9._~+/-]{10,}|eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}|[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}")
INTERESTING_KEY = re.compile(r"(model|engine|pipeline|version|provider|worker|stem|status|stage|error|progress|job|generat|task|transcri|inference|framework|runtime|separator|source|device|software|queue|duration|id$)", re.I)
MODEL_TERMS = re.compile(r"basic.?pitch|demucs|htdemucs|mdx.?net|mt3|tensorflow|pytorch|torchscript|onnx|spleeter|open.?unmix|omnizart|music21|replicate|runpod|hugging.?face|modal|sagemaker|vertex.?ai|transkun", re.I)


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def sanitize_url(v: str) -> str:
    try:
        x = urlsplit(v)
        if x.scheme in {"http", "https"}:
            return urlunsplit((x.scheme, x.netloc, x.path[:320], "", ""))
    except Exception:
        pass
    return "[URL_REDACTED]"


def sanitize(value, key="", depth=0):
    if SECRET_KEY.search(key):
        return "[REDACTED]"
    if depth > 8:
        return "[DEPTH_LIMIT]"
    if isinstance(value, dict):
        return {str(k)[:100]: sanitize(v, str(k), depth + 1) for k, v in list(value.items())[:180]}
    if isinstance(value, list):
        return [sanitize(v, key, depth + 1) for v in value[:180]]
    if isinstance(value, str):
        if value.startswith(("https://", "http://")):
            return sanitize_url(value)
        value = SECRET_TEXT.sub("[REDACTED]", value)
        if len(value) > 300:
            value = value[:300] + "...[TRUNCATED]"
        return value
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return "[OTHER]"


class Recorder:
    def __init__(self):
        OUT.mkdir(exist_ok=True, parents=True)
        self.lock = threading.RLock()
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.path = OUT / ("ledutu-existing-chrome-" + stamp)
        self.path.mkdir(parents=True, exist_ok=True)
        self.event_file = self.path / "events_sanitized.jsonl"
        self.count = 0
        self.statuses = collections.Counter()
        self.signals = collections.Counter()
        self.urls = collections.Counter()
        self.field_examples = collections.defaultdict(list)
        self.job_ids = set()
        self.saw_submission = False
        self.first_terminal_at = None
        self.started = utcnow()
        self.finished = False
        self.finish_reason = ""
        self.finished_zip = None
        self.last_activity = time.monotonic()

    def append(self, event):
        with self.lock:
            if self.finished:
                return
            clean = sanitize(event)
            if not isinstance(clean, dict):
                return
            clean["recorded_at_utc"] = utcnow()
            # Limit accidental excessive payloads.
            data = json.dumps(clean, ensure_ascii=True, separators=(",", ":"))
            if len(data) > 64000:
                data = json.dumps({"type": "oversized", "source_type": clean.get("type", "unknown"), "recorded_at_utc": utcnow()})
            with self.event_file.open("a", encoding="utf-8") as file:
                file.write(data + "\n")
            self.count += 1
            self.last_activity = time.monotonic()
            url = str(clean.get("url", ""))
            if url:
                self.urls[sanitize_url(url)] += 1
            for term in clean.get("evidence", {}).get("terms", []) if isinstance(clean.get("evidence"), dict) else []:
                self.signals[str(term)[:100]] += 1
            fields = clean.get("evidence", {}).get("fields", {}) if isinstance(clean.get("evidence"), dict) else {}
            if isinstance(fields, dict):
                for k, val in fields.items():
                    k = str(k)[:150]
                    if INTERESTING_KEY.search(k) and not SECRET_KEY.search(k):
                        safeval = sanitize(val, k)
                        if safeval not in self.field_examples[k] and len(self.field_examples[k]) < 12:
                            self.field_examples[k].append(safeval)
                        if k.lower().endswith(("generation_id", "job_id")) and isinstance(safeval, str) and re.fullmatch(r"[A-Za-z0-9_-]{4,80}", safeval):
                            self.job_ids.add(safeval)
                        if k.lower().endswith("status") and isinstance(safeval, str):
                            state = safeval.lower()
                            if state in {"queued", "fetching", "generating", "uploading", *END_STATUSES}:
                                self.statuses[state] += 1
                                if (self.saw_submission and state in END_STATUSES and "/api/generations/" in url):
                                    self.first_terminal_at = self.first_terminal_at or time.monotonic()
            if clean.get("type") == "request" and str(clean.get("method", "")).upper() == "POST":
                if "/api/generations" in url or "/account/scriptor" in url:
                    self.saw_submission = True
            if self.count % 20 == 0:
                print(f"[LOG] {self.count} events, model signals={dict(self.signals)}", flush=True)

    def finish(self, reason="manual"):
        with self.lock:
            if self.finished:
                return self.finished_zip
            self.finished = True
            self.finish_reason = reason
            report = {
                "tool": "Ledutu Monitor - existing Chrome tab",
                "version": VERSION,
                "started_at_utc": self.started,
                "finished_at_utc": utcnow(),
                "finish_reason": reason,
                "events_recorded": self.count,
                "job_ids": sorted(self.job_ids),
                "job_status_counts": dict(self.statuses),
                "model_term_hits_not_proof": dict(self.signals),
                "metadata_fields_observed": dict(self.field_examples),
                "request_url_counts": dict(self.urls),
                "caveat": "Browser-visible metadata only, not server-side code or server-to-server traffic; model names may be absent. Sanitization should be reviewed before sharing.",
            }
            (self.path / "evidence.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
            lines = [
                "LEDUTU MONITOR - KET QUA DA LOC",
                "Version: " + VERSION,
                "Bat dau: " + self.started,
                "Ket thuc: " + report["finished_at_utc"],
                "So su kien: " + str(self.count),
                "Trang thai: " + str(dict(self.statuses)),
                "Dau vet model (CHUA PHAI BANG CHUNG): " + str(dict(self.signals)),
                "Metadata:",
            ]
            lines += [f"  {key}: {val}" for key, val in sorted(self.field_examples.items())]
            lines += [
                "",
                "Ghi chu: Chi ghi mang cua tab Ledutu ma ban cho phep. Khong ket luan model neu khong co metadata ro rang.",
                "Hay mo bao cao va kiem tra lai truoc khi gui cho nguoi khac.",
            ]
            (self.path / "BAO_CAO_CHIA_SE.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
            zip_file = self.path / "CHIA_SE_VOI_CHATGPT.zip"
            with zipfile.ZipFile(zip_file, "w", zipfile.ZIP_DEFLATED, compresslevel=8) as z:
                for f in [self.event_file, self.path / "evidence.json", self.path / "BAO_CAO_CHIA_SE.txt"]:
                    if f.exists():
                        z.write(f, arcname=f.name)
            self.finished_zip = str(zip_file)
            print("\n[KET QUA] " + str(zip_file), flush=True)
            return self.finished_zip

    def stats(self):
        with self.lock:
            return {
                "running": not self.finished,
                "events": self.count,
                "status_counts": dict(self.statuses),
                "model_signals": dict(self.signals),
                "finished": self.finished,
                "report_ready": bool(self.finished_zip),
                "auto_finish_pending": self.first_terminal_at is not None,
            }


RECORDER = None


class Handler(BaseHTTPRequestHandler):
    server_version = "LedutuLocal/2.1"

    def log_message(self, fmt, *args):
        if not self.path.startswith("/health"):
            print("[HTTP] " + (fmt % args), flush=True)

    def headers_common(self, mime, size=None):
        self.send_header("Content-Type", mime)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        origin = self.headers.get("Origin", "")
        if origin.startswith("chrome-extension://") and re.fullmatch(r"chrome-extension://[a-p]{32}", origin):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        if size is not None:
            self.send_header("Content-Length", str(size))

    def send_json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.headers_common("application/json; charset=utf-8", len(data))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.headers_common("text/plain", 0)
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            return self.send_json(200, {"ok": True, "tool": VERSION, **RECORDER.stats()})
        if self.path in ("/", "/report"):
            st = RECORDER.stats()
            css = "body{font-family:Segoe UI,Arial,sans-serif;background:#101725;color:#e6eaf0;max-width:830px;margin:35px auto;padding:20px;line-height:1.7}b{color:#b3f7dc}code{background:#26394b;padding:4px;border-radius:4px}a{color:#8ed2ff}section{border:1px solid #445064;border-radius:14px;padding:18px;margin:20px 0}strong{color:#9ff2c0}"
            done = ('<p><strong>BAO CAO DA SAN SANG:</strong> <a href="/download">Tai ZIP ket qua</a></p>' if st["finished"] else '<p>Dang theo doi. Hoan tat tren ledutu.com, sau do nhan <b>DUNG VA XUAT</b> trong tien ich Chrome.</p>')
            body = f'''<!doctype html><html lang="vi"><meta charset="utf-8"><meta http-equiv="refresh" content="8"><title>Ledutu Monitor</title><style>{css}</style><h2>Ledutu Monitor - Chrome da dang nhap</h2><section><p><b>Khong can dang nhap lai</b>, khong can dong Chrome.</p><p>1. Mo <code>chrome://extensions/</code> trong Chrome, bat <b>Developer mode</b>.</p><p>2. Chon <b>Load unpacked</b>, chon thu muc <code>EXTENSION_CHROME</code> nam ben canh file BAT.</p><p>3. Tro lai tab Ledutu da dang nhap, nhan icon tien ich, chon <b>BAT DAU</b>.</p><p>4. Dan link va tao sheet nhu binh thuong. Dung &amp; xuat sau khi nhan ket qua.</p></section><section><b>Trang thai thu thap</b><p>Su kien: <strong>{st['events']}</strong></p><p>Trang thai tac vu: <code>{html.escape(str(st['status_counts']))}</code></p><p>Dau vet model: <code>{html.escape(str(st['model_signals']))}</code></p>{done}</section><p>Luu y: Tien ich xin quyen Chrome Debugger. Chi bat tren tab ledutu.com; khong can chia se profile, cookies hay mat khau. File ket qua da loc thong tin nhay cam nhung ban van nen xem truoc khi gui.</p></html>'''.encode("utf-8")
            self.send_response(200)
            self.headers_common("text/html; charset=utf-8", len(body))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path == "/download":
            if not RECORDER.finished_zip:
                return self.send_json(404, {"error": "not_finished"})
            b = Path(RECORDER.finished_zip).read_bytes()
            self.send_response(200)
            self.headers_common("application/zip", len(b))
            self.send_header("Content-Disposition", 'attachment; filename="CHIA_SE_VOI_CHATGPT.zip"')
            self.end_headers()
            self.wfile.write(b)
            return
        return self.send_json(404, {"error": "not_found"})

    def do_POST(self):
        origin = self.headers.get("Origin", "")
        if origin and not re.fullmatch(r"chrome-extension://[a-p]{32}", origin):
            return self.send_json(403, {"error": "extension_only"})
        if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
            return self.send_json(415, {"error": "json_required"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 100000:
                return self.send_json(413, {"error": "payload_too_large"})
            obj = json.loads(self.rfile.read(length))
            if self.path == "/event":
                RECORDER.append(obj)
                return self.send_json(200, {"ok": True, **RECORDER.stats()})
            if self.path == "/stop":
                RECORDER.finish("user_click_stop")
                return self.send_json(200, {"ok": True, "download": "/download"})
            return self.send_json(404, {"error": "not_found"})
        except (ValueError, json.JSONDecodeError) as exc:
            return self.send_json(400, {"error": str(exc)[:120]})


def auto_finish():
    while True:
        time.sleep(2)
        with RECORDER.lock:
            if RECORDER.finished:
                return
            when = RECORDER.first_terminal_at
            if when and time.monotonic() - when > 25 and time.monotonic() - RECORDER.last_activity > 10:
                RECORDER.finish("terminal_status_detected")
                return


def main():
    global RECORDER
    RECORDER = Recorder()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    threading.Thread(target=auto_finish, daemon=True).start()
    print("=" * 65)
    print(" LEDUTU MONITOR v2.1 - CHROME HIEN TAI, KHONG DANG NHAP LAI")
    print("=" * 65)
    print(f"[OK] Local: http://{HOST}:{PORT}")
    print(f"[OK] Reports: {RECORDER.path}")
    print("[1] Mo chrome://extensions/ -> Developer mode -> Load unpacked")
    print("[2] Chon thu muc EXTENSION_CHROME")
    print("[3] Trong tab ledutu.com -> icon tien ich -> BAT DAU")
    print("[4] Tao sheet, doi ket qua -> DUNG VA XUAT")
    print("[NOTE] Khong dong cua so nay khi dang theo doi.")
    print("[NOTE] Bam Ctrl+C de dung server. Bao cao chua xuat se duoc xuat.")
    webbrowser.open(f"http://{HOST}:{PORT}")
    try:
        srv.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("[STOP] Ctrl+C")
    finally:
        RECORDER.finish("local_server_closed")
        srv.server_close()


if __name__ == "__main__":
    main()
