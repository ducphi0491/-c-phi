"use strict";
const state = document.getElementById("state");
const message = document.getElementById("message");
const start = document.getElementById("start");
const stop = document.getElementById("stop");
const report = document.getElementById("report");
async function call(action, data = {}) { return await chrome.runtime.sendMessage({ action, ...data }); }
function note(s) { message.textContent = s || ""; }
async function update() {
  try {
    const r = await call("STATUS");
    if (!r.ok) throw new Error(r.message);
    state.textContent = (r.running ? "DANG GHI TAB LEDUTU" : "CHUA BAT GHI") + " | " +
      "Su kien: " + (r.server?.events || 0) + (r.server?.finished ? " | DA XUAT" : "");
    start.disabled = r.running || !!r.server?.finished;
    stop.disabled = !!r.server?.finished;
    if (r.lastError) note(r.lastError);
  } catch (e) {
    state.textContent = "KHONG KET NOI PYTHON";
    note("Hay chay CHAY_THEO_DOI_CHROME.bat truoc. " + e.message);
    start.disabled = true;
    stop.disabled = true;
  }
}
start.addEventListener("click", async () => {
  start.disabled = true;
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab) throw new Error("Khong thay tab Chrome hien tai.");
    const r = await call("START", { tabId: tab.id });
    note(r.message); if (!r.ok) throw new Error(r.message);
  } catch (e) { note(e.message); }
  await update();
});
stop.addEventListener("click", async () => {
  stop.disabled = true;
  const r = await call("STOP");
  note(r.message);
  await update();
  if (r.ok) chrome.tabs.create({ url: "http://127.0.0.1:8765/report" });
});
report.addEventListener("click", () => chrome.tabs.create({ url: "http://127.0.0.1:8765/report" }));
update();
