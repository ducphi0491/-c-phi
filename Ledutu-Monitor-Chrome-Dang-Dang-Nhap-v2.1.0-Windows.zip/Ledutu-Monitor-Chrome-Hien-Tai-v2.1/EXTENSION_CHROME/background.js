"use strict";

// Read-only Chrome DevTools Protocol monitor for ONE user-selected Ledutu tab.
// Never captures request bodies, passwords, cookies, raw page content, or audio.
// Only derives bounded metadata from browser-visible API response text.
const SERVER = "http://127.0.0.1:8765";
const MODEL_RE = /basic[ _-]?pitch|demucs|htdemucs(?:_ft)?|mdx[ _-]?net|\bmt3\b|tensorflow|pytorch|torchscript|\bonnx\b|onnxruntime|spleeter|open[ _-]?unmix|omnizart|music21|replicate|runpod|hugging[ _-]?face|modal\.com|sagemaker|vertex[ _-]?ai|transkun/gi;
const ALLOWED_KEY = /model|engine|pipeline|version|provider|worker|stem|status|stage|error|progress|job|generat|task|transcri|inference|framework|runtime|separator|device|software|queue|duration|^id$|^type$|^state$|^step$|^message$/i;
const SECRET_KEY = /password|passwd|secret|token|auth|cookie|session|csrf|xsrf|api.?key|email|phone|credential|signature|signed|user.?id|file.?name|file.?path|audio.?url|video.?url|source.?url|youtube.?url|refresh|access/i;
const SECRET_TEXT = /bearer\s+|eyJ[A-Za-z0-9_-]{8,}\.|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|\b(?:https?:\/\/|www\.)/i;
const KNOWN_EXTERNAL = /(?:^|\.)(replicate\.com|runpod\.io|huggingface\.co|modal\.com|fal\.ai|api\.runpod\.ai)$/;
let currentTab = null;
let requestMap = new Map();
let websocketMap = new Map();
let eventQueue = [];
let flushPromise = null;
let pendingBodies = new Set();
let captured = 0;
let lastError = "";

function isLedutu(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && (u.hostname === "ledutu.com" || u.hostname.endsWith(".ledutu.com"));
  } catch (_) { return false; }
}
function cleanUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol + "//" + u.hostname + u.pathname.slice(0, 300);
  } catch (_) { return "[invalid URL]"; }
}
function interesting(url, method, type) {
  if (!isLedutu(url)) return false;
  const p = new URL(url).pathname.toLowerCase();
  return p.startsWith("/api/generations") || p.startsWith("/api/transcri") ||
    p.startsWith("/api/ml") || (p.startsWith("/account/scriptor") &&
      (method === "POST" || type === "EventSource" || type === "Fetch" || type === "XHR"));
}
function knownExternal(url) {
  try { const h = new URL(url).hostname.toLowerCase(); return KNOWN_EXTERNAL.test(h); }
  catch (_) { return false; }
}
function safeScalar(v, key) {
  if (SECRET_KEY.test(key)) return "[REDACTED]";
  if (typeof v === "number" || typeof v === "boolean" || v === null) return v;
  if (typeof v !== "string") return undefined;
  if (v.length > 220 || SECRET_TEXT.test(v) || /[?&](?:token|key|sig|auth)=/i.test(v)) return "[REDACTED]";
  return v.replace(/[\r\n\t]/g, " ");
}
function extractEvidence(raw, contentType) {
  const txt = String(raw || "").slice(0, 220000);
  const terms = Array.from(new Set((txt.match(MODEL_RE) || []).map(s => s.toLowerCase()))).slice(0, 25);
  const keys = [];
  const fields = Object.create(null);
  const state = { count: 0 };
  function scan(obj, path, depth) {
    if (depth > 9 || state.count >= 260) return;
    if (Array.isArray(obj)) {
      // Inspect bounded number of items so large result arrays cannot flood logs.
      for (let i = 0; i < Math.min(obj.length, 16); i++) scan(obj[i], path + "[]", depth + 1);
    } else if (obj && typeof obj === "object") {
      for (const [key, val] of Object.entries(obj).slice(0, 90)) {
        if (state.count >= 260) break;
        state.count++;
        if (SECRET_KEY.test(key)) continue;
        const label = (path ? path + "." : "") + key.slice(0, 65);
        if (keys.length < 110) keys.push(label);
        if (val && typeof val === "object") scan(val, label, depth + 1);
        else if (ALLOWED_KEY.test(key) && Object.keys(fields).length < 75) {
          const safe = safeScalar(val, key);
          if (safe !== undefined && safe !== "[REDACTED]") fields[label] = safe;
        }
      }
    }
  }
  let parsed = false;
  try { scan(JSON.parse(txt), "", 0); parsed = true; } catch (_) { /* SSE/Flight may be line-oriented. */ }
  if (!parsed) {
    for (const line of txt.split("\n").slice(0, 120)) {
      const part = line.trim().replace(/^(?:data:\s*|\d+:)/, "");
      if (part.startsWith("{") || part.startsWith("[")) {
        try { scan(JSON.parse(part), "stream", 0); parsed = true; } catch (_) { /* ignore */ }
      }
    }
    // Some Next.js flight/SSE states appear as text rather than complete JSON.
    const re = /["']?(status|stage|model_name|model_version|engine|pipeline_version|provider|worker|stem|error_code)["']?\s*[:=]\s*["']([a-zA-Z0-9 _.-]{1,60})["']/gi;
    for (const m of txt.matchAll(re)) {
      if (Object.keys(fields).length > 75) break;
      fields[m[1].toLowerCase()] = m[2];
    }
  }
  return { content_type: String(contentType || "").slice(0, 80), body_length: txt.length, terms, fields, field_names: keys, parsed_json: parsed };
}
function selectedHeaders(headers) {
  const keep = /^(server-timing|x-model(?:-version)?|x-pipeline(?:-version)?|x-worker|x-request-id|x-trace-id|x-upstream|via|server|content-type)$/i;
  const out = Object.create(null);
  for (const [k, v] of Object.entries(headers || {})) {
    if (keep.test(k)) {
      const val = safeScalar(String(v).slice(0, 150), k);
      if (val && val !== "[REDACTED]") out[k] = val;
    }
  }
  return out;
}
async function send(type, data = {}) {
  const evt = { type, ...data };
  eventQueue.push(evt);
  captured++;
  if (!flushPromise) flushPromise = drain();
  return flushPromise;
}
async function drain() {
  while (eventQueue.length) {
    const item = eventQueue[0];
    try {
      const reply = await fetch(SERVER + "/event", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item), cache: "no-store"
      });
      if (!reply.ok) throw new Error("HTTP " + reply.status);
      eventQueue.shift(); lastError = "";
    } catch (e) {
      lastError = "Khong gui duoc log ve Python: " + String(e).slice(0, 130);
      // Preserve the data for another attempt, but prevent unbounded buffering.
      if (eventQueue.length > 200) eventQueue = eventQueue.slice(-200);
      break;
    }
  }
  flushPromise = null;
}
async function sendAndWait(type, data = {}) {
  await send(type, data);
  if (eventQueue.length && !flushPromise) flushPromise = drain();
  if (flushPromise) await flushPromise;
}
async function start(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (!isLedutu(tab.url || "")) throw new Error("Hay chon tab https://ledutu.com dang dang nhap.");
  const health = await fetch(SERVER + "/health", { cache: "no-store" }).then(r => r.json());
  if (!health.ok || health.finished) throw new Error("Hay chay CHAY_THEO_DOI_CHROME.bat (server moi) truoc.");
  if (currentTab !== null) {
    if (currentTab === tabId) return { ok: true, message: "Dang theo doi tab nay." };
    throw new Error("Dang theo doi tab Ledutu khac. Hay dung truoc.");
  }
  await chrome.debugger.attach({ tabId }, "1.3");
  try {
    await chrome.debugger.sendCommand({ tabId }, "Network.enable", {maxTotalBufferSize: 20000000, maxResourceBufferSize: 1200000});
  } catch (err) {
    await chrome.debugger.detach({ tabId }); throw err;
  }
  currentTab = tabId;
  requestMap.clear(); websocketMap.clear(); eventQueue = []; captured = 0; lastError = "";
  await sendAndWait("session_start", { url: cleanUrl(tab.url), message: "Capture started after explicit user click; no login captured." });
  return { ok: true, message: "Da BAT dau theo doi tab Ledutu hien tai. Hay dan link va tao sheet." };
}
async function stop() {
  const prior = currentTab;
  currentTab = null;
  if (prior !== null) {
    try { await chrome.debugger.detach({ tabId: prior }); } catch (_) {}
  }
  if (pendingBodies.size) {
    await Promise.race([Promise.allSettled(Array.from(pendingBodies)), new Promise(r => setTimeout(r, 3500))]);
  }
  await sendAndWait("session_stop", { message: "User requested stop and export." });
  try {
    const reply = await fetch(SERVER + "/stop", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    if (!reply.ok) throw new Error("HTTP " + reply.status);
    return { ok: true, message: "Da xuat bao cao. Mo http://127.0.0.1:8765/report" };
  } catch (err) { throw new Error("Khong xuat duoc: " + err.message); }
}
chrome.debugger.onEvent.addListener((source, method, p) => {
  if (currentTab === null || source.tabId !== currentTab || !p) return;
  if (method === "Network.requestWillBeSent") {
    const r = p.request || {};
    const url = String(r.url || "");
    if (knownExternal(url)) {
      send("external_provider_domain", { domain: new URL(url).hostname });
      return;
    }
    if (!interesting(url, r.method, p.type)) return;
    requestMap.set(p.requestId, { url: cleanUrl(url), method: r.method || "GET", type: p.type || "", mime: "" });
    if (requestMap.size > 500) requestMap.delete(requestMap.keys().next().value);
    send("request", { url: cleanUrl(url), method: r.method || "GET", resource_type: p.type || "" });
  } else if (method === "Network.responseReceived") {
    const info = requestMap.get(p.requestId);
    if (!info) return;
    const r = p.response || {};
    info.mime = r.mimeType || "";
    info.status = r.status || 0;
    send("response", { url: info.url, method: info.method, http_status: info.status,
      mime_type: info.mime, headers: selectedHeaders(r.headers) });
  } else if (method === "Network.loadingFinished") {
    const info = requestMap.get(p.requestId);
    if (!info) return;
    requestMap.delete(p.requestId);
    const mime = String(info.mime).toLowerCase();
    if (!(/json|text|event-stream|x-component|xml|javascript/.test(mime))) return;
    const task = chrome.debugger.sendCommand({ tabId: currentTab }, "Network.getResponseBody", { requestId: p.requestId })
      .then(resp => {
        if (resp && !resp.base64Encoded) {
          return send("response_metadata", { url: info.url, method: info.method, http_status: info.status,
            evidence: extractEvidence(resp.body, mime) });
        }
      }).catch(() => {}).finally(() => pendingBodies.delete(task));
    pendingBodies.add(task);
  } else if (method === "Network.eventSourceMessageReceived") {
    const info = requestMap.get(p.requestId);
    if (!info) return;
    send("sse", { url: info.url, sse_event: String(p.eventName || "").slice(0, 55),
      evidence: extractEvidence(p.data || "", "text/event-stream") });
  } else if (method === "Network.webSocketCreated") {
    if (interesting(p.url || "", "GET", "WebSocket")) {
      websocketMap.set(p.requestId, cleanUrl(p.url));
      send("websocket_created", { url: cleanUrl(p.url) });
    }
  } else if (method === "Network.webSocketFrameReceived") {
    const url = websocketMap.get(p.requestId);
    if (url && p.response && p.response.opcode === 1)
      send("websocket_message", { url, evidence: extractEvidence(p.response.payloadData, "websocket") });
  }
});
chrome.debugger.onDetach.addListener((source, reason) => {
  if (currentTab !== null && source.tabId === currentTab) {
    currentTab = null;
    send("debugger_detached", { reason: String(reason || "unknown") });
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  (async () => {
    try {
      if (msg.action === "START") respond(await start(msg.tabId));
      else if (msg.action === "STOP") respond(await stop());
      else if (msg.action === "STATUS") {
        const health = await fetch(SERVER + "/health", { cache: "no-store" }).then(r => r.json());
        respond({ ok: true, running: currentTab !== null, tabId: currentTab, events: captured,
          lastError, server: health });
      } else respond({ ok: false, message: "Unknown action" });
    } catch (err) { respond({ ok: false, message: String(err.message || err) }); }
  })();
  return true;
});
