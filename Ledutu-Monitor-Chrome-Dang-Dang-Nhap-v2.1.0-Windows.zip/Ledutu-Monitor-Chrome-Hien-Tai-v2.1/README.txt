LEDUTU MONITOR v2.1: Theo doi Chrome/Edge dang mo
================================================
Mot lan: mo CHAY_THEO_DOI_CHROME.bat, vao chrome://extensions,
bat Developer mode -> Load unpacked -> chon EXTENSION_CHROME.
Trong tab Ledutu dang login, click extension -> BAT DAU.
Tao sheet -> xong -> click extension -> DUNG VA XUAT ZIP.
Xem ket qua tai ket_qua\\...\\CHIA_SE_VOI_CHATGPT.zip
Doc HUONG_DAN_DUNG_CHROME_DANG_MO.txt de xem day du.

Tool chi nghe local 127.0.0.1:8765, khong dua du lieu len internet.
Ma Python, JS cua extension la file text co the doc/kiem tra.
File ket qua da duoc loc, hay xem truoc khi chia se.
