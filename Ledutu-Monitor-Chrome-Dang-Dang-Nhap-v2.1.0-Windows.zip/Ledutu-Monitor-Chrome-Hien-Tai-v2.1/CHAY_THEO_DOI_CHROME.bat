@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
title Ledutu Monitor - Dung Chrome dang dang nhap
set "PYTHON_CMD="
where py >nul 2>&1
if not errorlevel 1 (
    py -3.11 --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3.11"
    if not defined PYTHON_CMD (
        py -3 --version >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -3"
    )
)
if not defined PYTHON_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
    echo [LOI] Khong tim thay Python. Ban can cai Python 3.11.
    pause
    exit /b 1
)
echo [OK] Python: %PYTHON_CMD%
echo [OK] Khong can pip, Node.js hay Chrome moi.
echo.
%PYTHON_CMD% "%~dp0monitor_local.py"
if errorlevel 1 (
    echo.
    echo [LOI] Khong mo duoc local monitor. Co the cong 8765 dang duoc su dung.
    echo Hay dong cua so BAT monitor cu va thu lai.
    pause
)
