@echo off
cd /d "%~dp0"
if not exist "ket_qua" mkdir "ket_qua"
start "" "%~dp0ket_qua"
