# Bao cao kiem tra - Telegram Music local-only

## Kiem tra da thuc hien

- AndroidManifest XML parse thanh cong.
- Khong con thu muc PHP/MySQL/server trong goi.
- Khong con `TELEGRAM_MUSIC_API_URL`.
- Khong con `TELEGRAM_OFFICIAL_BOT`.
- Khong con `linkWithCode` hoac deep link pairing tu may chu.
- Telegram Music chi goi domain chinh thuc `api.telegram.org` va `t.me`.
- Bot Token khong ghi vao log, queue JSON, thu vien nhac hoac BuildConfig.
- Bot Token va connection state duoc ma hoa bang Android Keystore AES/GCM.
- File tai xuong dung file `.part`, gioi han kich thuoc, sau do rename atomic.
- Chi chat private va dung Telegram user/chat da xac nhan moi duoc nhap nhac.
- Offset `getUpdates` duoc luu tren thiet bi de tranh xu ly lai.
- File chia se tu Telegram duoc sao chep ngay, khong giu quyen URI tam thoi.
- File ZIP duoc kiem tra danh sach va giai nen.

## Gioi han kiem tra

Goi nguon ban dau chi gom cac file Kotlin chinh, manifest va module `build.gradle.kts`; khong co Gradle Wrapper, `settings.gradle.kts`, thu muc `res`, keystore va `google-services.json`. Vi vay khong the tao APK day du trong moi truong nay.

Da chay Kotlin compiler de kiem tra parse; khong phat hien loi cu phap kieu `expecting`/`unexpected token`. Cac canh bao `unresolved reference` la do goi rut gon khong kem Android SDK va Compose classpath, khong phai ket qua build Android hoan chinh.

Can chen cac file vao du an Android Studio day du cua MeloWave va chay:

```text
./gradlew :app:assembleDebug
```

sau do thu nghiem tren thiet bi that voi mot bot moi tao rieng.
