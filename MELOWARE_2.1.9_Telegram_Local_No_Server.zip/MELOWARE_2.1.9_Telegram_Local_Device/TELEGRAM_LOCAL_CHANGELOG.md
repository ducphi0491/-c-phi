# MeloWave 2.1.9-local - Telegram Music local-only

## Phien ban

- `versionCode = 41`
- `versionName = 2.1.9-local`

## Da bo

- Toan bo thu muc `server/`.
- PHP va MySQL Telegram Music.
- Webhook MeloWave.
- API `telegram_music.php`.
- Session token do may chu cap.
- Signed streaming URL va stream proxy.
- Bot MeloWave chung va ma lien ket do may chu tao.
- BuildConfig `TELEGRAM_MUSIC_API_URL` va `TELEGRAM_OFFICIAL_BOT`.
- Deep link `melowave://telegram/link?code=...`.

## Da them/thay doi

- Nguoi dung nhap Bot Token cua bot rieng tao bang BotFather.
- Goi truc tiep `getMe`, `deleteWebhook`, `getUpdates`, `getFile`, `sendMessage`, `sendAudio` va `sendDocument` tu Android.
- Token duoc ma hoa AES/GCM bang Android Keystore.
- Tao ma Start cuc bo de xac nhan dung chu so huu Telegram.
- Chi nhan tin nhan private tu tai khoan da xac nhan.
- Long polling cuc bo khi MeloWave con dang chay.
- Dong bo thu cong khi mo lai ung dung.
- Tai audio ve bo nho rieng cua ung dung truoc khi phat.
- Thu vien Telegram hoat dong Offline sau khi tai.
- Ho tro `/library`, `/recent`, `/random`, `/status`, `/help`.
- Ho tro Telegram -> Chia se -> MeloWave khong can bot.
- Canh bao va chuyen sang Share Sheet khi file lon hon 20 MB.
- Ngat bot khong xoa file nhac da tai.
- Co nut xoa rieng toan bo nhac Telegram da tai.
