package duc_phi.music

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.random.Random

private class TelegramBotApiException(
    val httpStatus: Int,
    val telegramErrorCode: Int,
    message: String
) : IOException(message)

internal enum class TelegramConnectionStatus {
    DISCONNECTED,
    PENDING,
    ACTIVE
}

internal enum class TelegramConnectionMode {
    OFFICIAL,
    CUSTOM
}

/**
 * The complete Telegram connection state is stored only in the app-private area.
 * The BotFather token itself is encrypted separately with Android Keystore.
 */
internal data class TelegramConnectionState(
    val status: TelegramConnectionStatus = TelegramConnectionStatus.DISCONNECTED,
    val mode: TelegramConnectionMode = TelegramConnectionMode.CUSTOM,
    val connectionId: String = "",
    val telegramDisplayName: String = "",
    val telegramUsername: String = "",
    val telegramUserId: Long = 0L,
    val telegramChatId: Long = 0L,
    val botId: Long = 0L,
    val botUsername: String = "",
    val botDisplayName: String = "",
    val startParameter: String = "",
    val trackCount: Int = 0,
    val lastSyncMs: Long = 0L
) {
    val linked: Boolean get() = status == TelegramConnectionStatus.ACTIVE
    val pending: Boolean get() = status == TelegramConnectionStatus.PENDING

    fun toJson(): JSONObject = JSONObject().apply {
        put("status", status.name)
        put("mode", mode.name)
        put("connection_id", connectionId)
        put("telegram_display_name", telegramDisplayName)
        put("telegram_username", telegramUsername)
        put("telegram_user_id", telegramUserId)
        put("telegram_chat_id", telegramChatId)
        put("bot_id", botId)
        put("bot_username", botUsername)
        put("bot_display_name", botDisplayName)
        put("start_parameter", startParameter)
        put("track_count", trackCount)
        put("last_sync_ms", lastSyncMs)
    }

    companion object {
        fun fromJson(json: JSONObject?): TelegramConnectionState {
            if (json == null) return TelegramConnectionState()
            val status = runCatching {
                TelegramConnectionStatus.valueOf(
                    json.optString("status", "DISCONNECTED").uppercase(Locale.ROOT)
                )
            }.getOrDefault(TelegramConnectionStatus.DISCONNECTED)
            val mode = runCatching {
                TelegramConnectionMode.valueOf(
                    json.optString("mode", "CUSTOM").uppercase(Locale.ROOT)
                )
            }.getOrDefault(TelegramConnectionMode.CUSTOM)
            return TelegramConnectionState(
                status = status,
                mode = mode,
                connectionId = json.optString("connection_id"),
                telegramDisplayName = json.optString("telegram_display_name"),
                telegramUsername = json.optString("telegram_username").removePrefix("@"),
                telegramUserId = json.optLong("telegram_user_id", 0L),
                telegramChatId = json.optLong("telegram_chat_id", 0L),
                botId = json.optLong("bot_id", 0L),
                botUsername = json.optString("bot_username").removePrefix("@"),
                botDisplayName = json.optString("bot_display_name"),
                startParameter = json.optString("start_parameter"),
                trackCount = json.optInt("track_count", 0).coerceAtLeast(0),
                lastSyncMs = json.optLong("last_sync_ms", 0L)
            )
        }
    }
}

private data class TelegramLocalTrack(
    val id: String,
    val botId: Long,
    val fileId: String,
    val fileUniqueId: String,
    val mediaKind: String,
    val messageId: Long,
    val chatId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val fileName: String,
    val mimeType: String,
    val durationMs: Long,
    val fileSize: Long,
    val localPath: String,
    val dateAddedMs: Long
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("bot_id", botId)
        put("file_id", fileId)
        put("file_unique_id", fileUniqueId)
        put("media_kind", mediaKind)
        put("message_id", messageId)
        put("chat_id", chatId)
        put("title", title)
        put("artist", artist)
        put("album", album)
        put("file_name", fileName)
        put("mime_type", mimeType)
        put("duration_ms", durationMs)
        put("file_size", fileSize)
        put("local_path", localPath)
        put("date_added_ms", dateAddedMs)
    }

    companion object {
        fun fromJson(json: JSONObject): TelegramLocalTrack? {
            val id = json.optString("id").trim()
            val fileId = json.optString("file_id").trim()
            if (id.isBlank() || fileId.isBlank()) return null
            return TelegramLocalTrack(
                id = id,
                botId = json.optLong("bot_id", 0L),
                fileId = fileId,
                fileUniqueId = json.optString("file_unique_id"),
                mediaKind = json.optString("media_kind", "audio"),
                messageId = json.optLong("message_id", 0L),
                chatId = json.optLong("chat_id", 0L),
                title = json.optString("title").ifBlank { "Bài hát Telegram" },
                artist = json.optString("artist").ifBlank { "Nghệ sĩ chưa biết" },
                album = json.optString("album"),
                fileName = json.optString("file_name"),
                mimeType = json.optString("mime_type").ifBlank { "audio/mpeg" },
                durationMs = json.optLong("duration_ms", 0L).coerceAtLeast(0L),
                fileSize = json.optLong("file_size", 0L).coerceAtLeast(0L),
                localPath = json.optString("local_path"),
                dateAddedMs = json.optLong("date_added_ms", 0L)
            )
        }
    }
}

/**
 * Local-only Telegram integration.
 *
 * There is no MeloWave PHP endpoint, database, webhook, stream proxy, or cloud
 * session. The user's own bot talks directly to Telegram Bot API via getUpdates.
 * Audio is downloaded into this phone before it is added to the MeloWave library.
 */
internal class TelegramMusicManager(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val secureStore = TelegramBotSecretStore(appContext)
    private val api = TelegramBotApi()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val pollMutex = Mutex()
    private val localTracks = mutableListOf<TelegramLocalTrack>()

    private var operationJob: Job? = null
    private var pollingJob: Job? = null

    var connection by mutableStateOf(secureStore.loadConnection())
        private set
    var busy by mutableStateOf(false)
        private set
    var polling by mutableStateOf(false)
        private set
    var pollingEnabled by mutableStateOf(prefs.getBoolean(KEY_POLLING_ENABLED, true))
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var pollingMessage by mutableStateOf<String?>(null)
        private set

    val songs = mutableStateListOf<SongItem>()

    init {
        localTracks.addAll(loadCachedTracks())
        rebuildSongs()

        val token = secureStore.loadBotToken()
        if (token.isNullOrBlank()) {
            secureStore.clear()
            connection = TelegramConnectionState(trackCount = songs.size)
        } else {
            connection = connection.copy(trackCount = songs.size)
            secureStore.saveConnection(connection)
            if (pollingEnabled && connection.status != TelegramConnectionStatus.DISCONNECTED) {
                ensurePolling()
            }
        }
    }

    val botUsernameForOpen: String
        get() = connection.botUsername

    fun clearFeedback() {
        error = null
        message = null
    }

    /** The "code" entered by the user is the BotFather token of their own bot. */
    fun connectCustomBot(rawToken: String) {
        val token = rawToken.trim()
        if (!BOT_TOKEN_PATTERN.matches(token)) {
            error = "Mã Bot Token chưa đúng. Hãy sao chép lại token do BotFather cấp."
            return
        }
        launchExclusive {
            val bot = api.getMe(token)
            // A bot can use webhook or getUpdates, not both. This removes only the
            // webhook setting on Telegram; no MeloWave server is created or used.
            api.deleteWebhook(token)
            stopPolling()

            val botId = bot.optLong("id", 0L)
            val username = bot.optString("username").removePrefix("@").trim()
            if (botId <= 0L || username.isBlank()) {
                throw IOException("Telegram không trả về thông tin bot hợp lệ.")
            }
            val displayName = listOf(
                bot.optString("first_name"),
                bot.optString("last_name")
            ).filter { it.isNotBlank() }.joinToString(" ").ifBlank { username }
            val pairCode = createPairCode()
            val state = TelegramConnectionState(
                status = TelegramConnectionStatus.PENDING,
                mode = TelegramConnectionMode.CUSTOM,
                connectionId = "local_$botId",
                botId = botId,
                botUsername = username,
                botDisplayName = displayName,
                startParameter = pairCode,
                trackCount = songs.size,
                lastSyncMs = System.currentTimeMillis()
            )
            connection = state
            secureStore.save(token, state)
            prefs.edit()
                .putLong(KEY_UPDATE_OFFSET, 0L)
                .putBoolean(KEY_POLLING_ENABLED, true)
                .apply()
            pollingEnabled = true
            message = "Đã lưu bot trên điện thoại. Hãy mở @$username và bấm Start để xác nhận chủ sở hữu."
            ensurePolling()
        }
    }

    fun refresh() {
        if (secureStore.loadBotToken().isNullOrBlank()) {
            error = "Chưa có Bot Token trên thiết bị này."
            return
        }
        launchExclusive {
            val processed = pollUpdates(timeoutSeconds = 0, maxBatches = 8)
            connection = connection.copy(
                trackCount = songs.size,
                lastSyncMs = System.currentTimeMillis()
            )
            secureStore.saveConnection(connection)
            message = when {
                connection.pending -> "Chưa nhận được lệnh Start. Hãy mở bot từ MeloWave rồi bấm Start."
                processed > 0 -> "Đã xử lý $processed cập nhật và lưu ${songs.size} bài trên điện thoại."
                else -> "Đã kiểm tra bot. Hiện có ${songs.size} bài Telegram trên thiết bị."
            }
        }
    }

    fun setPollingEnabled(enabled: Boolean) {
        pollingEnabled = enabled
        prefs.edit().putBoolean(KEY_POLLING_ENABLED, enabled).apply()
        if (enabled) {
            if (secureStore.loadBotToken().isNullOrBlank()) {
                pollingEnabled = false
                prefs.edit().putBoolean(KEY_POLLING_ENABLED, false).apply()
                error = "Hãy kết nối bot cá nhân trước."
                return
            }
            ensurePolling()
            message = "Bot cục bộ sẽ nhận nhạc khi MeloWave còn đang chạy."
        } else {
            stopPolling()
            message = "Đã dừng nhận cập nhật tự động. Bạn vẫn có thể bấm Đồng bộ thủ công."
        }
    }

    fun disconnect() {
        stopPolling()
        secureStore.clear()
        prefs.edit()
            .remove(KEY_UPDATE_OFFSET)
            .putBoolean(KEY_POLLING_ENABLED, false)
            .apply()
        pollingEnabled = false
        connection = TelegramConnectionState(trackCount = songs.size)
        message = "Đã ngắt bot. Các bài đã tải vẫn nằm trên điện thoại và vẫn nghe được."
    }

    fun clearDownloadedMusic() {
        launchExclusive {
            val snapshot = localTracks.toList()
            val deleted = withContext(Dispatchers.IO) {
                var count = 0
                snapshot.forEach { track ->
                    val file = File(track.localPath)
                    if (file.isFile && file.delete()) count++
                }
                count
            }
            localTracks.clear()
            saveCachedTracks()
            rebuildSongs()
            connection = connection.copy(trackCount = 0)
            secureStore.saveConnection(connection)
            message = "Đã xóa $deleted file Telegram đã lưu trong MeloWave."
        }
    }

    fun openBot(context: Context = appContext) {
        val username = botUsernameForOpen.trim().removePrefix("@")
        if (username.isBlank()) {
            error = "Chưa kết nối bot Telegram cá nhân."
            return
        }
        val start = connection.startParameter.takeIf { connection.pending && it.isNotBlank() }
        val nativeUri = if (start == null) {
            Uri.parse("tg://resolve?domain=${Uri.encode(username)}")
        } else {
            Uri.parse("tg://resolve?domain=${Uri.encode(username)}&start=${Uri.encode(start)}")
        }
        val webUri = if (start == null) {
            Uri.parse("https://t.me/${Uri.encode(username)}")
        } else {
            Uri.parse("https://t.me/${Uri.encode(username)}?start=${Uri.encode(start)}")
        }
        openExternalUri(context, nativeUri, webUri)
    }

    fun openBotFather(context: Context = appContext) {
        openExternalUri(
            context,
            Uri.parse("tg://resolve?domain=BotFather"),
            Uri.parse("https://t.me/BotFather")
        )
    }

    fun openLibrary(controller: MusicController) {
        controller.libraryTab = LibraryTab.SONGS
        controller.libraryQuery = ""
        controller.openLibrary(LibrarySource.TELEGRAM)
        if (connection.status != TelegramConnectionStatus.DISCONNECTED) refresh()
    }

    fun resolveLocalWaveformUri(song: SongItem): Uri? {
        if (song.source != SongSource.TELEGRAM) return null
        val trackId = song.id.removePrefix("telegram_")
        val track = localTracks.firstOrNull { it.id == trackId } ?: return null
        val file = File(track.localPath)
        return if (file.isFile && file.length() > 0L) Uri.fromFile(file) else null
    }

    suspend fun resolveStreamUri(song: SongItem): Uri {
        if (song.source != SongSource.TELEGRAM) return song.uri
        val trackId = song.id.removePrefix("telegram_")
        val track = localTracks.firstOrNull { it.id == trackId }
            ?: throw IOException("Không tìm thấy dữ liệu bài hát Telegram trên thiết bị.")
        val existing = File(track.localPath)
        if (existing.isFile && existing.length() > 0L) return Uri.fromFile(existing)

        val token = secureStore.loadBotToken()
            ?: throw IOException("File đã bị xóa và bot đã ngắt. Hãy kết nối lại bot để tải lại.")
        val refreshed = downloadTrackFile(token, track)
        replaceTrack(refreshed)
        return Uri.fromFile(File(refreshed.localPath))
    }

    fun shareSourceLabel(): String = connection.botUsername
        .takeIf { it.isNotBlank() }
        ?.let { "Bot Telegram @$it · lưu trên thiết bị" }
        ?: "Telegram · lưu trên thiết bị"

    fun release() {
        operationJob?.cancel()
        pollingJob?.cancel()
        scope.cancel()
    }

    private fun launchExclusive(block: suspend () -> Unit) {
        operationJob?.cancel()
        operationJob = scope.launch {
            busy = true
            error = null
            message = null
            try {
                block()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (throwable: Throwable) {
                if (throwable is TelegramBotApiException && throwable.telegramErrorCode == 401) {
                    stopPolling()
                    secureStore.clear()
                    connection = TelegramConnectionState(trackCount = songs.size)
                }
                error = friendlyError(throwable)
            } finally {
                busy = false
            }
        }
    }

    private fun ensurePolling() {
        if (!pollingEnabled || pollingJob?.isActive == true) return
        if (secureStore.loadBotToken().isNullOrBlank()) return
        pollingJob = scope.launch {
            polling = true
            pollingMessage = null
            try {
                while (isActive && pollingEnabled) {
                    try {
                        pollUpdates(timeoutSeconds = 15, maxBatches = 1)
                        pollingMessage = null
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (throwable: Throwable) {
                        pollingMessage = friendlyError(throwable)
                        if (throwable is TelegramBotApiException &&
                            throwable.telegramErrorCode == 401
                        ) {
                            secureStore.clear()
                            connection = TelegramConnectionState(trackCount = songs.size)
                            pollingEnabled = false
                            prefs.edit().putBoolean(KEY_POLLING_ENABLED, false).apply()
                            break
                        }
                        delay(5_000L)
                    }
                }
            } finally {
                polling = false
            }
        }
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
        polling = false
    }

    private suspend fun pollUpdates(timeoutSeconds: Int, maxBatches: Int): Int =
        pollMutex.withLock {
            val token = secureStore.loadBotToken()
                ?: throw IOException("Bot Token không còn trên thiết bị.")
            var offset = prefs.getLong(KEY_UPDATE_OFFSET, 0L)
            var processed = 0
            var batch = 0
            while (batch < maxBatches.coerceAtLeast(1)) {
                val updates = api.getUpdates(token, offset, if (batch == 0) timeoutSeconds else 0)
                if (updates.length() == 0) break
                for (index in 0 until updates.length()) {
                    currentCoroutineContext().ensureActive()
                    val update = updates.optJSONObject(index) ?: continue
                    val updateId = update.optLong("update_id", -1L)
                    try {
                        processUpdate(token, update)
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (throwable: Throwable) {
                        pollingMessage = friendlyError(throwable)
                    } finally {
                        if (updateId >= 0L) {
                            offset = maxOf(offset, updateId + 1L)
                            prefs.edit().putLong(KEY_UPDATE_OFFSET, offset).apply()
                        }
                    }
                    processed++
                }
                batch++
                if (updates.length() < 100) break
            }
            if (processed > 0) {
                connection = connection.copy(
                    trackCount = songs.size,
                    lastSyncMs = System.currentTimeMillis()
                )
                secureStore.saveConnection(connection)
            }
            processed
        }

    private suspend fun processUpdate(token: String, update: JSONObject) {
        val incoming = update.optJSONObject("message") ?: return
        val chat = incoming.optJSONObject("chat") ?: return
        if (!chat.optString("type").equals("private", ignoreCase = true)) return
        val from = incoming.optJSONObject("from") ?: return
        if (from.optBoolean("is_bot", false)) return

        val chatId = chat.optLong("id", 0L)
        val userId = from.optLong("id", 0L)
        if (chatId == 0L || userId == 0L) return
        val text = incoming.optString("text").trim()

        if (connection.pending) {
            if (isMatchingStartCommand(text, connection.startParameter)) {
                val displayName = listOf(
                    from.optString("first_name"),
                    from.optString("last_name")
                ).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Người dùng Telegram" }
                val username = from.optString("username").removePrefix("@")
                connection = connection.copy(
                    status = TelegramConnectionStatus.ACTIVE,
                    telegramDisplayName = displayName,
                    telegramUsername = username,
                    telegramUserId = userId,
                    telegramChatId = chatId,
                    lastSyncMs = System.currentTimeMillis()
                )
                secureStore.saveConnection(connection)
                api.sendMessage(
                    token,
                    chatId,
                    "Đã liên kết với MeloWave trên điện thoại này.\n\n" +
                        "Gửi hoặc chuyển tiếp file nhạc vào đây. MeloWave sẽ tải về máy khi ứng dụng đang chạy.\n\n" +
                        "Lệnh: /library, /recent, /random, /status, /help"
                )
                message = "Đã xác nhận tài khoản Telegram ${username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: displayName}."
            }
            return
        }

        if (!connection.linked ||
            connection.telegramUserId != userId ||
            connection.telegramChatId != chatId
        ) return

        when {
            incoming.has("audio") -> importIncomingMedia(token, incoming, from, "audio")
            incoming.has("document") && isAudioDocument(incoming.optJSONObject("document")) ->
                importIncomingMedia(token, incoming, from, "document")
            text.startsWith("/") -> handleCommand(token, chatId, text)
        }
    }

    private suspend fun importIncomingMedia(
        token: String,
        incoming: JSONObject,
        from: JSONObject,
        mediaKind: String
    ) {
        val media = incoming.optJSONObject(mediaKind) ?: return
        val chatId = incoming.optJSONObject("chat")?.optLong("id", 0L) ?: 0L
        val fileId = media.optString("file_id").trim()
        if (fileId.isBlank()) return
        val uniqueId = media.optString("file_unique_id").trim().ifBlank { stableId(fileId) }
        val existing = localTracks.firstOrNull {
            it.fileUniqueId == uniqueId && it.botId == connection.botId
        }
        if (existing != null && File(existing.localPath).isFile) {
            api.sendMessage(token, chatId, "Bài này đã có trong MeloWave: ${existing.title}.")
            return
        }

        val fileName = media.optString("file_name").ifBlank {
            if (mediaKind == "audio") "telegram_audio_$uniqueId.mp3"
            else "telegram_file_$uniqueId.audio"
        }
        val mimeType = media.optString("mime_type").ifBlank {
            mimeFromFileName(fileName)
        }
        val declaredSize = media.optLong("file_size", 0L).coerceAtLeast(0L)
        if (declaredSize > MAX_BOT_DOWNLOAD_BYTES) {
            api.sendMessage(
                token,
                chatId,
                "File lớn hơn 20 MB nên Telegram Bot API không cho ứng dụng tải trực tiếp. " +
                    "Trong Telegram hãy chọn Chia sẻ → MeloWave để nhập file không qua bot."
            )
            return
        }

        val telegramTitle = media.optString("title").trim()
        val telegramArtist = media.optString("performer").trim()
        val parsedName = parseArtistTitle(fileName)
        val provisionalTitle = telegramTitle.ifBlank { parsedName.second }
            .ifBlank { fileName.substringBeforeLast('.', fileName).ifBlank { "Bài hát Telegram" } }
        val provisionalArtist = telegramArtist.ifBlank { parsedName.first }
            .ifBlank { "Nghệ sĩ chưa biết" }
        val durationMs = media.optLong("duration", 0L).coerceAtLeast(0L) * 1_000L

        val fileInfo: JSONObject
        val remotePath: String
        val destination: File
        val embedded: EmbeddedMetadata
        try {
            fileInfo = api.getFile(token, fileId)
            remotePath = fileInfo.optString("file_path").trim()
            if (remotePath.isBlank()) throw IOException("Telegram chưa cấp đường dẫn tải file.")
            destination = destinationFile(
                artist = provisionalArtist,
                title = provisionalTitle,
                uniqueId = uniqueId,
                fileName = fileName,
                mimeType = mimeType,
                remotePath = remotePath
            )
            api.downloadFile(token, remotePath, destination, MAX_BOT_DOWNLOAD_BYTES)
            embedded = readEmbeddedMetadata(
                destination,
                provisionalTitle,
                provisionalArtist,
                durationMs
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (throwable: Throwable) {
            runCatching {
                api.sendMessage(
                    token,
                    chatId,
                    friendlyError(throwable) +
                        "\nBạn có thể dùng Telegram → Chia sẻ → MeloWave để nhập trực tiếp."
                )
            }
            return
        }
        val track = TelegramLocalTrack(
            id = stableId("${connection.botId}:$uniqueId"),
            botId = connection.botId,
            fileId = fileId,
            fileUniqueId = uniqueId,
            mediaKind = mediaKind,
            messageId = incoming.optLong("message_id", 0L),
            chatId = chatId,
            title = embedded.title,
            artist = embedded.artist,
            album = embedded.album,
            fileName = fileName,
            mimeType = mimeType,
            durationMs = embedded.durationMs,
            fileSize = destination.length(),
            localPath = destination.absolutePath,
            dateAddedMs = System.currentTimeMillis()
        )
        replaceTrack(track)
        val sender = listOf(
            from.optString("first_name"),
            from.optString("last_name")
        ).filter { it.isNotBlank() }.joinToString(" ")
        api.sendMessage(
            token,
            chatId,
            "Đã lưu vào điện thoại: ${track.title} - ${track.artist}" +
                sender.takeIf { it.isNotBlank() }?.let { "\nNgười gửi: $it" }.orEmpty()
        )
    }

    private suspend fun handleCommand(token: String, chatId: Long, rawText: String) {
        val command = rawText.substringBefore(' ')
            .substringBefore('@')
            .lowercase(Locale.ROOT)
        val botTracks = localTracks
            .filter { it.botId == connection.botId }
            .sortedByDescending { it.dateAddedMs }
        when (command) {
            "/start", "/help" -> api.sendMessage(
                token,
                chatId,
                "MeloWave Bot đang chạy trực tiếp trên điện thoại của bạn.\n\n" +
                    "Gửi hoặc chuyển tiếp MP3, M4A, FLAC, WAV, OGG vào chat này.\n" +
                    "/library - danh sách nhạc\n" +
                    "/recent - 5 bài mới nhất\n" +
                    "/random - gửi lại một bài ngẫu nhiên\n" +
                    "/status - trạng thái thư viện\n\n" +
                    "Bot chỉ phản hồi khi MeloWave đang chạy hoặc khi bạn mở ứng dụng để đồng bộ."
            )

            "/library" -> api.sendMessage(token, chatId, libraryMessage(botTracks, 25))
            "/recent" -> api.sendMessage(token, chatId, libraryMessage(botTracks.take(5), 5))
            "/status" -> api.sendMessage(
                token,
                chatId,
                "MeloWave đang lưu ${botTracks.size} bài từ @$botUsernameForOpen trên điện thoại này."
            )

            "/random" -> {
                val track = botTracks.takeIf { it.isNotEmpty() }?.let { it[Random.nextInt(it.size)] }
                if (track == null) {
                    api.sendMessage(token, chatId, "Thư viện chưa có bài hát.")
                } else {
                    api.resendMedia(token, chatId, track)
                }
            }

            "/unlink" -> api.sendMessage(
                token,
                chatId,
                "Để bảo vệ dữ liệu trên máy, hãy mở MeloWave → Telegram Music → Ngắt bot."
            )

            else -> api.sendMessage(token, chatId, "Lệnh chưa hỗ trợ. Gõ /help để xem hướng dẫn.")
        }
    }

    private fun libraryMessage(items: List<TelegramLocalTrack>, limit: Int): String {
        if (items.isEmpty()) return "Thư viện MeloWave chưa có bài hát Telegram."
        val displayed = items.take(limit.coerceAtLeast(1))
        return buildString {
            append("Thư viện MeloWave trên điện thoại (${items.size} bài)\n\n")
            displayed.forEachIndexed { index, track ->
                append(index + 1)
                append(". ")
                append(track.title)
                if (track.artist.isNotBlank()) append(" - ${track.artist}")
                append('\n')
            }
            if (items.size > displayed.size) append("\nCòn ${items.size - displayed.size} bài khác trong ứng dụng MeloWave.")
        }.take(3_900)
    }

    private suspend fun downloadTrackFile(
        token: String,
        track: TelegramLocalTrack
    ): TelegramLocalTrack {
        val fileInfo = api.getFile(token, track.fileId)
        val remotePath = fileInfo.optString("file_path").trim()
        if (remotePath.isBlank()) throw IOException("Không lấy được đường dẫn file Telegram.")
        val destination = destinationFile(
            artist = track.artist,
            title = track.title,
            uniqueId = track.fileUniqueId.ifBlank { track.id },
            fileName = track.fileName,
            mimeType = track.mimeType,
            remotePath = remotePath
        )
        api.downloadFile(token, remotePath, destination, MAX_BOT_DOWNLOAD_BYTES)
        return track.copy(localPath = destination.absolutePath, fileSize = destination.length())
    }

    private fun replaceTrack(track: TelegramLocalTrack) {
        val index = localTracks.indexOfFirst { it.id == track.id }
        if (index >= 0) localTracks[index] = track else localTracks.add(0, track)
        saveCachedTracks()
        rebuildSongs()
        connection = connection.copy(
            trackCount = songs.size,
            lastSyncMs = System.currentTimeMillis()
        )
        secureStore.saveConnection(connection)
    }

    private fun rebuildSongs() {
        val rebuilt = localTracks
            .sortedByDescending { it.dateAddedMs }
            .map { track ->
                val file = File(track.localPath)
                val playableUri = if (file.isFile) Uri.fromFile(file)
                else Uri.parse("melowave://telegram/local/${track.id}")
                SongItem(
                    id = "telegram_${track.id}",
                    title = track.title,
                    artist = track.artist,
                    album = track.album,
                    folderName = "Telegram / Trên thiết bị",
                    uri = playableUri,
                    durationMs = track.durationMs,
                    source = SongSource.TELEGRAM,
                    mimeType = track.mimeType,
                    genre = "Telegram",
                    dateAddedMs = track.dateAddedMs
                )
            }
        songs.clear()
        songs.addAll(rebuilt)
    }

    private fun saveCachedTracks() {
        val array = JSONArray()
        localTracks.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_TRACKS_CACHE, array.toString()).apply()
    }

    private fun loadCachedTracks(): List<TelegramLocalTrack> {
        val raw = prefs.getString(KEY_TRACKS_CACHE, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    TelegramLocalTrack.fromJson(array.optJSONObject(index) ?: continue)?.let(::add)
                }
            }.distinctBy { it.id }
        }.getOrDefault(emptyList())
    }

    private fun destinationFile(
        artist: String,
        title: String,
        uniqueId: String,
        fileName: String,
        mimeType: String,
        remotePath: String
    ): File {
        val parent = File(
            appContext.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: appContext.filesDir,
            "MeloWaveTelegram"
        ).apply { mkdirs() }
        val extension = preferredExtension(fileName, mimeType, remotePath)
        val base = safeFileName("$artist - $title").take(92).ifBlank { "Telegram Audio" }
        val suffix = stableId(uniqueId).take(10)
        return File(parent, "${base}_$suffix.$extension")
    }

    private suspend fun readEmbeddedMetadata(
        file: File,
        fallbackTitle: String,
        fallbackArtist: String,
        fallbackDurationMs: Long
    ): EmbeddedMetadata = withContext(Dispatchers.IO) {
        val reader = MediaMetadataRetriever()
        try {
            reader.setDataSource(file.absolutePath)
            EmbeddedMetadata(
                title = reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?.trim()?.takeIf { it.isNotBlank() } ?: fallbackTitle,
                artist = reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?.trim()?.takeIf { it.isNotBlank() } ?: fallbackArtist,
                album = reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                    ?.trim().orEmpty(),
                durationMs = reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.coerceAtLeast(0L)
                    ?.takeIf { it > 0L } ?: fallbackDurationMs
            )
        } catch (_: Exception) {
            EmbeddedMetadata(fallbackTitle, fallbackArtist, "", fallbackDurationMs)
        } finally {
            runCatching { reader.release() }
        }
    }

    private fun isMatchingStartCommand(text: String, expected: String): Boolean {
        if (expected.isBlank()) return false
        val parts = text.trim().split(Regex("\\s+"), limit = 2)
        if (parts.isEmpty() || !parts[0].substringBefore('@').equals("/start", true)) return false
        return parts.getOrNull(1)?.trim()?.equals(expected, ignoreCase = true) == true
    }

    private fun isAudioDocument(document: JSONObject?): Boolean {
        if (document == null) return false
        val mime = document.optString("mime_type").lowercase(Locale.ROOT)
        if (mime.startsWith("audio/")) return true
        val extension = document.optString("file_name")
            .substringAfterLast('.', "")
            .lowercase(Locale.ROOT)
        return extension in AUDIO_EXTENSIONS
    }

    private fun openExternalUri(context: Context, nativeUri: Uri, webUri: Uri) {
        val flags = Intent.FLAG_ACTIVITY_NEW_TASK
        val nativeIntent = Intent(Intent.ACTION_VIEW, nativeUri).addFlags(flags)
        val webIntent = Intent(Intent.ACTION_VIEW, webUri).addFlags(flags)
        runCatching { context.startActivity(nativeIntent) }
            .recoverCatching { context.startActivity(webIntent) }
            .onFailure { error = "Không mở được Telegram trên thiết bị này." }
    }

    private fun friendlyError(throwable: Throwable): String = when {
        throwable is TelegramBotApiException && throwable.telegramErrorCode == 401 ->
            "Bot Token không còn hợp lệ. Hãy lấy token mới từ BotFather."
        throwable is TelegramBotApiException && throwable.telegramErrorCode == 409 ->
            "Bot đang được webhook hoặc một thiết bị khác sử dụng. Hãy dùng một bot riêng cho MeloWave."
        throwable.message?.contains("too big", ignoreCase = true) == true ->
            "File vượt giới hạn tải của Telegram Bot API. Hãy Chia sẻ file trực tiếp sang MeloWave."
        else -> throwable.localizedMessage ?: "Không thể kết nối Telegram."
    }

    private companion object {
        const val PREFS_NAME = "melowave_telegram_local_v2"
        const val KEY_TRACKS_CACHE = "local_tracks"
        const val KEY_UPDATE_OFFSET = "update_offset"
        const val KEY_POLLING_ENABLED = "polling_enabled"
        const val MAX_BOT_DOWNLOAD_BYTES = 20L * 1024L * 1024L
        val BOT_TOKEN_PATTERN = Regex("^[0-9]{5,20}:[A-Za-z0-9_-]{20,}$")
        val AUDIO_EXTENSIONS = setOf(
            "mp3", "m4a", "aac", "flac", "wav", "wave", "ogg", "oga", "opus", "amr", "wma"
        )
    }
}

private data class EmbeddedMetadata(
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long
)

/** Direct Telegram Bot API client. No MeloWave-owned server is involved. */
private class TelegramBotApi {
    suspend fun getMe(token: String): JSONObject =
        request(token, "getMe", JSONObject()).getJSONObject("result")

    suspend fun deleteWebhook(token: String) {
        request(token, "deleteWebhook", JSONObject().put("drop_pending_updates", false))
    }

    suspend fun getUpdates(token: String, offset: Long, timeoutSeconds: Int): JSONArray {
        val payload = JSONObject().apply {
            if (offset > 0L) put("offset", offset)
            put("limit", 100)
            put("timeout", timeoutSeconds.coerceIn(0, 25))
            put("allowed_updates", JSONArray().put("message"))
        }
        return request(
            token,
            "getUpdates",
            payload,
            readTimeoutMs = (timeoutSeconds.coerceAtLeast(0) + 15) * 1_000
        ).getJSONArray("result")
    }

    suspend fun getFile(token: String, fileId: String): JSONObject =
        request(token, "getFile", JSONObject().put("file_id", fileId))
            .getJSONObject("result")

    suspend fun sendMessage(token: String, chatId: Long, text: String) {
        request(
            token,
            "sendMessage",
            JSONObject().apply {
                put("chat_id", chatId)
                put("text", text.take(4_000))
                put("disable_web_page_preview", true)
            }
        )
    }

    suspend fun resendMedia(token: String, chatId: Long, track: TelegramLocalTrack) {
        val method = if (track.mediaKind == "document") "sendDocument" else "sendAudio"
        val mediaField = if (track.mediaKind == "document") "document" else "audio"
        request(
            token,
            method,
            JSONObject().apply {
                put("chat_id", chatId)
                put(mediaField, track.fileId)
                put("caption", "${track.title} - ${track.artist}".take(900))
            }
        )
    }

    suspend fun downloadFile(
        token: String,
        remotePath: String,
        destination: File,
        maxBytes: Long
    ) = withContext(Dispatchers.IO) {
        destination.parentFile?.mkdirs()
        val temporary = File(destination.parentFile, destination.name + ".part")
        if (temporary.exists()) temporary.delete()
        val connection = URL("https://api.telegram.org/file/bot$token/$remotePath")
            .openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 20_000
            connection.readTimeout = 60_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "*/*")
            connection.setRequestProperty("User-Agent", "MeloWave-Android/${BuildConfig.VERSION_NAME}")
            val status = connection.responseCode
            if (status !in 200..299) {
                throw TelegramBotApiException(status, status, "Telegram không cho tải file (HTTP $status).")
            }
            val announced = connection.contentLengthLong
            if (announced > maxBytes) throw IOException("Telegram file is too big for Bot API download.")
            var total = 0L
            connection.inputStream.use { input ->
                FileOutputStream(temporary).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > maxBytes) throw IOException("Telegram file is too big for Bot API download.")
                        output.write(buffer, 0, read)
                    }
                    output.fd.sync()
                }
            }
            if (total <= 0L) throw IOException("Telegram trả về file rỗng.")
            if (destination.exists() && !destination.delete()) {
                throw IOException("Không thể thay thế file Telegram cũ trên thiết bị.")
            }
            if (!temporary.renameTo(destination)) {
                temporary.copyTo(destination, overwrite = true)
                temporary.delete()
            }
        } finally {
            connection.disconnect()
            if (temporary.exists() && (!destination.exists() || destination.length() <= 0L)) {
                temporary.delete()
            }
        }
    }

    private suspend fun request(
        token: String,
        method: String,
        payload: JSONObject,
        readTimeoutMs: Int = 60_000
    ): JSONObject = withContext(Dispatchers.IO) {
        val connection = URL("https://api.telegram.org/bot$token/$method")
            .openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = readTimeoutMs.coerceAtLeast(20_000)
            connection.doOutput = true
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("User-Agent", "MeloWave-Android/${BuildConfig.VERSION_NAME}")
            val body = payload.toString().toByteArray(StandardCharsets.UTF_8)
            connection.outputStream.use { it.write(body) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            val response = runCatching { JSONObject(text) }.getOrElse {
                throw TelegramBotApiException(status, status, "Telegram trả dữ liệu không hợp lệ (HTTP $status).")
            }
            if (status !in 200..299 || !response.optBoolean("ok", false)) {
                val errorCode = response.optInt("error_code", status)
                val description = response.optString("description")
                    .ifBlank { "Telegram Bot API lỗi $errorCode" }
                throw TelegramBotApiException(status, errorCode, description)
            }
            response
        } finally {
            connection.disconnect()
        }
    }
}

private class TelegramBotSecretStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun save(token: String, connection: TelegramConnectionState) {
        prefs.edit()
            .putString(KEY_TOKEN, encrypt(token))
            .putString(KEY_CONNECTION, encrypt(connection.toJson().toString()))
            .apply()
    }

    fun saveConnection(connection: TelegramConnectionState) {
        val token = loadBotToken()
        if (token.isNullOrBlank()) return
        prefs.edit().putString(KEY_CONNECTION, encrypt(connection.toJson().toString())).apply()
    }

    fun loadBotToken(): String? {
        val encrypted = prefs.getString(KEY_TOKEN, null) ?: return null
        return runCatching { decrypt(encrypted) }
            .onFailure { clear() }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
    }

    fun loadConnection(): TelegramConnectionState {
        val encrypted = prefs.getString(KEY_CONNECTION, null) ?: return TelegramConnectionState()
        return runCatching {
            TelegramConnectionState.fromJson(JSONObject(decrypt(encrypted)))
        }.onFailure { clear() }
            .getOrDefault(TelegramConnectionState())
    }

    fun clear() {
        prefs.edit().remove(KEY_TOKEN).remove(KEY_CONNECTION).apply()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        val joined = ByteArray(cipher.iv.size + encrypted.size)
        System.arraycopy(cipher.iv, 0, joined, 0, cipher.iv.size)
        System.arraycopy(encrypted, 0, joined, cipher.iv.size, encrypted.size)
        return Base64.encodeToString(joined, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val joined = Base64.decode(value, Base64.NO_WRAP)
        if (joined.size <= IV_SIZE) throw IOException("Dữ liệu bot đã hỏng.")
        val iv = joined.copyOfRange(0, IV_SIZE)
        val encrypted = joined.copyOfRange(IV_SIZE, joined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), StandardCharsets.UTF_8)
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val PREFS_NAME = "melowave_telegram_local_secure_v2"
        const val KEY_TOKEN = "bot_token"
        const val KEY_CONNECTION = "connection"
        const val KEY_ALIAS = "melowave_telegram_local_aes_v2"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_SIZE = 12
    }
}

private fun createPairCode(): String {
    val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val random = SecureRandom()
    return buildString {
        append("MW_")
        repeat(10) { append(alphabet[random.nextInt(alphabet.length)]) }
    }
}

private fun stableId(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray(StandardCharsets.UTF_8))
    .take(12)
    .joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }

private fun safeFileName(value: String): String = value
    .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '.')
    .ifBlank { "Telegram Audio" }

private fun preferredExtension(fileName: String, mimeType: String, remotePath: String): String {
    val fromName = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
    if (fromName in setOf("mp3", "m4a", "aac", "flac", "wav", "wave", "ogg", "oga", "opus", "amr", "wma")) {
        return if (fromName == "wave") "wav" else fromName
    }
    val fromRemote = remotePath.substringAfterLast('.', "").lowercase(Locale.ROOT)
    if (fromRemote in setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "amr", "wma")) {
        return fromRemote
    }
    return when (mimeType.lowercase(Locale.ROOT)) {
        "audio/flac", "audio/x-flac" -> "flac"
        "audio/wav", "audio/x-wav", "audio/wave" -> "wav"
        "audio/mp4", "audio/x-m4a" -> "m4a"
        "audio/aac" -> "aac"
        "audio/ogg", "application/ogg" -> "ogg"
        "audio/opus" -> "opus"
        "audio/amr" -> "amr"
        else -> "mp3"
    }
}

private fun mimeFromFileName(fileName: String): String = when (
    fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
) {
    "flac" -> "audio/flac"
    "wav", "wave" -> "audio/wav"
    "m4a" -> "audio/mp4"
    "aac" -> "audio/aac"
    "ogg", "oga" -> "audio/ogg"
    "opus" -> "audio/opus"
    "amr" -> "audio/amr"
    else -> "audio/mpeg"
}

private fun parseArtistTitle(fileName: String): Pair<String, String> {
    val base = fileName.substringBeforeLast('.', fileName).trim()
    val separator = listOf(" - ", " – ", " — ").firstOrNull { base.contains(it) }
        ?: return "" to base
    val artist = base.substringBefore(separator).trim()
    val title = base.substringAfter(separator).trim()
    return artist to title
}

@Composable
internal fun TelegramMusicHomeCard(
    controller: MusicController,
    compact: Boolean
) {
    val colors = LocalMusicColors.current
    val telegram = controller.telegramMusic
    var showDialog by rememberSaveable { mutableStateOf(false) }
    val subtitle = when {
        telegram.connection.linked -> {
            val bot = telegram.connection.botUsername.takeIf { it.isNotBlank() }
                ?.let { "@$it" } ?: "Bot cá nhân"
            val state = if (telegram.polling) "đang chạy trên máy" else "đã dừng"
            "$bot · ${telegram.songs.size} bài · $state"
        }
        telegram.connection.pending -> "Bot đã lưu trên máy · mở Telegram và bấm Start"
        telegram.songs.isNotEmpty() -> "${telegram.songs.size} bài đã tải cục bộ · chưa kết nối bot"
        else -> "Bot cá nhân chạy trực tiếp trên điện thoại · không máy chủ MeloWave"
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showDialog = true },
        shape = RoundedCornerShape(18.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            colors.cardRaised,
                            colors.purple.copy(alpha = if (colors.isDark) 0.20f else 0.10f),
                            colors.card
                        )
                    )
                )
                .padding(horizontal = 13.dp, vertical = if (compact) 10.dp else 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(if (compact) 43.dp else 48.dp),
                shape = CircleShape,
                color = Color(0xFF229ED9).copy(alpha = if (colors.isDark) 0.24f else 0.15f),
                border = BorderStroke(1.dp, Color(0xFF4CC2F1).copy(alpha = 0.55f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.Send,
                        contentDescription = null,
                        tint = Color(0xFF35B5EA),
                        modifier = Modifier.size(if (compact) 23.dp else 26.dp)
                    )
                }
            }
            Spacer(Modifier.size(11.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Telegram Music",
                        color = colors.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 14.sp else 15.sp
                    )
                    if (telegram.connection.linked) {
                        Spacer(Modifier.size(5.dp))
                        Icon(
                            Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = colors.green,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Text(
                    subtitle,
                    color = colors.textSecondary,
                    fontSize = if (compact) 10.5.sp else 11.5.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            TextButton(
                onClick = {
                    if (telegram.songs.isNotEmpty()) telegram.openLibrary(controller)
                    else showDialog = true
                }
            ) {
                Text(
                    if (telegram.songs.isNotEmpty()) "Thư viện" else "Thiết lập",
                    color = colors.purpleBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }

    if (showDialog) {
        TelegramMusicDialog(controller = controller, onDismiss = { showDialog = false })
    }
}

@Composable
internal fun TelegramMusicLibraryPanel(
    controller: MusicController,
    onManage: () -> Unit
) {
    val colors = LocalMusicColors.current
    val telegram = controller.telegramMusic
    Surface(
        color = colors.backgroundSoft,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, colors.border)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(38.dp),
                shape = CircleShape,
                color = Color(0xFF229ED9).copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Send, null, tint = Color(0xFF35B5EA), modifier = Modifier.size(21.dp))
                }
            }
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        telegram.polling -> "Bot cá nhân đang chạy trên thiết bị"
                        telegram.connection.pending -> "Bot đang chờ bạn bấm Start"
                        telegram.connection.linked -> "Bot đã kết nối · đang dừng nhận tự động"
                        telegram.songs.isNotEmpty() -> "Nhạc Telegram đã lưu cục bộ"
                        else -> "Telegram Music chưa thiết lập"
                    },
                    color = colors.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Text(
                    when {
                        telegram.polling -> "${telegram.songs.size} bài · nhận bằng getUpdates · không máy chủ MeloWave"
                        telegram.songs.isNotEmpty() -> "${telegram.songs.size} bài nằm trên điện thoại · có thể nghe Offline"
                        else -> "Dùng bot riêng hoặc Chia sẻ file Telegram trực tiếp sang MeloWave"
                    },
                    color = colors.textSecondary,
                    fontSize = 11.sp
                )
            }
            TextButton(onClick = onManage) {
                Text("Quản lý", color = colors.purpleBright, fontSize = 12.sp)
            }
        }
    }
}

private enum class TelegramDialogMode {
    CUSTOM_BOT,
    IMPORT
}

@Composable
internal fun TelegramMusicDialog(
    controller: MusicController,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalMusicColors.current
    val telegram = controller.telegramMusic
    var mode by rememberSaveable { mutableStateOf(TelegramDialogMode.CUSTOM_BOT) }
    var botToken by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = { if (!telegram.busy) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .widthIn(max = 560.dp)
                .heightIn(max = 780.dp),
            shape = RoundedCornerShape(24.dp),
            color = colors.cardRaised,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(44.dp),
                        shape = CircleShape,
                        color = Color(0xFF229ED9).copy(alpha = 0.18f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Send, null, tint = Color(0xFF35B5EA), modifier = Modifier.size(24.dp))
                        }
                    }
                    Spacer(Modifier.size(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Telegram Music trên thiết bị", color = colors.textPrimary, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Không PHP · không MySQL · không máy chủ MeloWave", color = colors.textSecondary, fontSize = 11.5.sp)
                    }
                    IconButton(onClick = onDismiss, enabled = !telegram.busy) {
                        Icon(Icons.Rounded.Close, "Đóng", tint = colors.textSecondary)
                    }
                }

                if (telegram.connection.status != TelegramConnectionStatus.DISCONNECTED) {
                    TelegramConnectedContent(controller, onDismiss)
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        TelegramModeButton(
                            text = "Bot của tôi",
                            selected = mode == TelegramDialogMode.CUSTOM_BOT,
                            onClick = { mode = TelegramDialogMode.CUSTOM_BOT },
                            modifier = Modifier.weight(1f)
                        )
                        TelegramModeButton(
                            text = "Nhập file",
                            selected = mode == TelegramDialogMode.IMPORT,
                            onClick = { mode = TelegramDialogMode.IMPORT },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    when (mode) {
                        TelegramDialogMode.CUSTOM_BOT -> {
                            Text(
                                "Tạo một bot riêng bằng BotFather, sau đó dán Bot Token vào đây. MeloWave gọi thẳng Telegram Bot API từ điện thoại.",
                                color = colors.textSecondary,
                                fontSize = 12.sp
                            )
                            OutlinedButton(
                                onClick = { telegram.openBotFather(context) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(13.dp)
                            ) {
                                Icon(Icons.Rounded.OpenInNew, null, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.size(7.dp))
                                Text("Mở BotFather để tạo bot")
                            }
                            OutlinedTextField(
                                value = botToken,
                                onValueChange = { botToken = it.trim().take(180) },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Bot Token / mã bot") },
                                placeholder = { Text("123456789:AA...") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = {
                                    val token = botToken
                                    botToken = ""
                                    telegram.connectCustomBot(token)
                                })
                            )
                            Surface(
                                color = colors.backgroundSoft,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, colors.borderSoft)
                            ) {
                                Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("Token được mã hóa AES/GCM bằng Android Keystore và chỉ nằm trên điện thoại.", color = colors.textSecondary, fontSize = 11.sp)
                                    Text("Hãy dùng bot tạo riêng cho MeloWave. Ứng dụng sẽ xóa webhook của bot để sử dụng getUpdates cục bộ.", color = colors.textSecondary, fontSize = 11.sp)
                                    Text("Bot nhận tự động khi MeloWave còn chạy. Nếu ứng dụng đã tắt, mở lại rồi bấm Đồng bộ.", color = colors.textSecondary, fontSize = 11.sp)
                                }
                            }
                            Button(
                                onClick = {
                                    val token = botToken
                                    botToken = ""
                                    telegram.connectCustomBot(token)
                                },
                                enabled = !telegram.busy && botToken.isNotBlank(),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(13.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                            ) {
                                Text("Lưu bot và chạy trên điện thoại", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        TelegramDialogMode.IMPORT -> TelegramImportInstructions()
                    }

                    if (telegram.songs.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                telegram.openLibrary(controller)
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(13.dp)
                        ) {
                            Text("Mở ${telegram.songs.size} bài Telegram đã lưu trên máy")
                        }
                    }
                }

                telegram.error?.let { text ->
                    Surface(
                        color = Color(0xFFB3261E).copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFE26D65).copy(alpha = 0.45f))
                    ) {
                        Text(text, modifier = Modifier.padding(11.dp), color = colors.textPrimary, fontSize = 12.sp)
                    }
                }
                telegram.message?.let { text ->
                    Surface(
                        color = colors.green.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, colors.green.copy(alpha = 0.42f))
                    ) {
                        Text(text, modifier = Modifier.padding(11.dp), color = colors.textPrimary, fontSize = 12.sp)
                    }
                }
                telegram.pollingMessage?.let { text ->
                    Text("Bot cục bộ: $text", color = colors.textSecondary, fontSize = 10.5.sp)
                }
                if (telegram.busy) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = colors.purpleBright)
                        Spacer(Modifier.size(9.dp))
                        Text("Đang làm việc trực tiếp với Telegram...", color = colors.textSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelegramConnectedContent(
    controller: MusicController,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    val telegram = controller.telegramMusic
    val connection = telegram.connection
    val account = connection.telegramUsername
        .takeIf { it.isNotBlank() }
        ?.let { "@$it" }
        ?: connection.telegramDisplayName.ifBlank { "Chưa xác nhận chủ sở hữu" }
    val bot = connection.botUsername
        .takeIf { it.isNotBlank() }
        ?.let { "@$it" }
        ?: connection.botDisplayName.ifBlank { "Bot Telegram cá nhân" }

    Surface(
        color = colors.backgroundSoft,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, colors.border)
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (connection.linked) Icons.Rounded.CheckCircle else Icons.Rounded.Link,
                    null,
                    tint = if (connection.linked) colors.green else colors.purpleBright,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    when {
                        connection.pending -> "Đang chờ xác nhận bằng Start"
                        telegram.polling -> "Bot đang chạy trên điện thoại"
                        else -> "Bot đã kết nối nhưng đang dừng"
                    },
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Text("Bot: $bot", color = colors.textSecondary, fontSize = 12.sp)
            Text("Chủ sở hữu: $account", color = colors.textSecondary, fontSize = 12.sp)
            Text("Thư viện cục bộ: ${telegram.songs.size} bài hát", color = colors.textSecondary, fontSize = 12.sp)
            Text("Dữ liệu: Telegram API ↔ điện thoại; không đi qua máy chủ MeloWave", color = colors.textSecondary, fontSize = 11.sp)
        }
    }

    if (connection.pending) {
        Text(
            "Bấm nút dưới đây, sau đó bấm Start trong Telegram. Mã xác nhận ${connection.startParameter} được truyền tự động vào bot.",
            color = colors.textSecondary,
            fontSize = 12.sp
        )
        Button(
            onClick = { telegram.openBot() },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229ED9))
        ) {
            Icon(Icons.Rounded.Send, null, tint = Color.White, modifier = Modifier.size(17.dp))
            Spacer(Modifier.size(7.dp))
            Text("Mở $bot và bấm Start", color = Color.White, fontWeight = FontWeight.Bold)
        }
    } else {
        OutlinedButton(
            onClick = { telegram.openBot() },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp)
        ) {
            Icon(Icons.Rounded.OpenInNew, null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.size(7.dp))
            Text("Mở bot để gửi hoặc nghe nhạc")
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(
            onClick = { telegram.refresh() },
            enabled = !telegram.busy,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(13.dp)
        ) {
            Icon(Icons.Rounded.Refresh, null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.size(6.dp))
            Text(if (connection.pending) "Kiểm tra Start" else "Đồng bộ")
        }
        Button(
            onClick = {
                telegram.openLibrary(controller)
                onDismiss()
            },
            enabled = telegram.songs.isNotEmpty(),
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(13.dp),
            colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
        ) {
            Text("Mở thư viện", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }

    OutlinedButton(
        onClick = { telegram.setPollingEnabled(!telegram.pollingEnabled) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(13.dp)
    ) {
        Text(
            if (telegram.pollingEnabled) "Dừng bot cục bộ" else "Chạy bot cục bộ",
            fontWeight = FontWeight.SemiBold
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (telegram.songs.isNotEmpty()) {
            TextButton(onClick = { telegram.clearDownloadedMusic() }, enabled = !telegram.busy) {
                Text("Xóa nhạc Telegram trên máy", color = Color(0xFFE26D65), fontSize = 11.sp)
            }
        } else {
            Spacer(Modifier.size(1.dp))
        }
        TextButton(onClick = { telegram.disconnect() }, enabled = !telegram.busy) {
            Text("Ngắt bot", color = Color(0xFFE26D65), fontSize = 12.sp)
        }
    }
}

@Composable
private fun TelegramImportInstructions() {
    val colors = LocalMusicColors.current
    val rows = listOf(
        Triple(Icons.Rounded.ContentCopy, "Chia sẻ trực tiếp", "Trong Telegram chọn bài hát → Chia sẻ → MeloWave. File được sao chép vào Music/MeloWare trên điện thoại."),
        Triple(Icons.Rounded.Smartphone, "Không cần bot", "Cách này không cần Bot Token, PHP, MySQL hoặc máy chủ MeloWave."),
        Triple(Icons.Rounded.Send, "Dùng cho file lớn", "Telegram Bot API chỉ cho bot tải file tối đa 20 MB; với file lớn hãy dùng Chia sẻ trực tiếp."),
        Triple(Icons.Rounded.CheckCircle, "Nghe Offline", "Sau khi nhập xong, bài hát xuất hiện trong mục Đã tải và dùng được với Media3, EQ, hẹn giờ và phát nền.")
    )
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        rows.forEach { (icon, title, description) ->
            Surface(
                color = colors.backgroundSoft,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, colors.borderSoft)
            ) {
                Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.Top) {
                    Icon(icon, null, tint = colors.purpleBright, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(9.dp))
                    Column {
                        Text(title, color = colors.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                        Text(description, color = colors.textSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelegramModeButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalMusicColors.current
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) colors.purple else colors.backgroundSoft,
        border = BorderStroke(1.dp, if (selected) colors.purpleBright else colors.border)
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 9.dp),
            color = if (selected) Color.White else colors.textSecondary,
            fontSize = 11.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}
