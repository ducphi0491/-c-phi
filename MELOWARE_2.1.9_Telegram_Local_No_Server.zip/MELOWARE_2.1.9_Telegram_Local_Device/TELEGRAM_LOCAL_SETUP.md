# MeloWave Telegram Music - Chay cuc bo tren dien thoai

## Kien truc da chot

Phan Telegram Music trong goi nay khong dung:

- PHP;
- MySQL;
- webhook MeloWave;
- stream proxy;
- VPS hoac may chu rieng cua MeloWave;
- bot chung do MeloWave quan ly.

Ung dung Android goi truc tiep Telegram Bot API bang HTTPS. Bot Token cua nguoi dung duoc ma hoa AES/GCM bang Android Keystore va chi luu trong vung rieng cua ung dung tren dien thoai.

Luu y: Telegram van la dich vu Internet, vi vay ung dung bat buoc phai ket noi may chu chinh thuc cua Telegram. Yeu cau "khong may chu" o day co nghia la khong co may chu trung gian cua MeloWave.

## Cach nguoi dung thiet lap

1. Mo Telegram va tim `@BotFather`.
2. Gui lenh `/newbot`.
3. Dat ten va username cho bot.
4. Sao chep Bot Token do BotFather cap, vi du `123456789:AA...`.
5. Mo MeloWave -> trang chu -> Telegram Music -> Bot cua toi.
6. Dan Bot Token vao o `Bot Token / ma bot`.
7. Bam `Luu bot va chay tren dien thoai`.
8. MeloWave goi truc tiep `getMe`, xoa webhook cu cua bot, tao ma xac nhan cuc bo va mo bot.
9. Trong Telegram, bam `Start`.
10. Gui hoac chuyen tiep file nhac den bot.
11. MeloWave tai file ve dien thoai va hien thi trong Thu vien -> Telegram Music.

Nen tao mot bot moi chi de dung voi MeloWave. Khong dung bot dang chay o he thong khac, vi `getUpdates` va webhook khong the cung nhan cap nhat cho mot bot.

## Cach nhap nhac khong can bot

Trong Telegram:

1. Chon file nhac.
2. Chon Chia se.
3. Chon MeloWave.
4. MeloWave sao chep file vao thu muc Music/MeloWare va mo muc Da tai.

Cach nay hoat dong hoan toan tren dien thoai, khong can Bot Token, va nen dung cho file lon.

## Gioi han quan trong

- Telegram Bot API chinh thuc chi cho bot tai file toi da 20 MB qua `getFile`.
- File tren 20 MB: dung `Telegram -> Chia se -> MeloWave`.
- Bot nhan cap nhat tu dong khi tien trinh MeloWave con dang chay.
- Neu Android da dong hoan toan MeloWave, bot khong the phan hoi ngay. Mo lai ung dung va bam `Dong bo`; cac tin nhan Telegram dang cho se duoc xu ly.
- Khong nen dung cung mot Bot Token tren nhieu dien thoai, vi cac thiet bi co the tranh nhau nhan `getUpdates`.
- Khong co dong bo vi tri dang nghe tu trinh phat Telegram sang MeloWave.

## Lenh bot

Khi MeloWave dang chay, bot ho tro:

- `/help`
- `/library`
- `/recent`
- `/random`
- `/status`

Lenh `/random` gui lai mot bai da co tren Telegram bang `file_id`, de nguoi dung nghe ngay trong Telegram.

## Du lieu luu tren dien thoai

- Bot Token: ma hoa bang Android Keystore.
- Thong tin chu so huu Telegram: vung du lieu rieng cua ung dung.
- File nhac bot tai ve: `Android/data/duc_phi.music/files/Music/MeloWaveTelegram`.
- File chia se truc tiep: luu theo co che MediaStore vao Music/MeloWare.

Khi bam `Ngat bot`, cac bai da tai van duoc giu va van nghe Offline. Nut `Xoa nhac Telegram tren may` se xoa cac file bot da tai trong vung rieng cua MeloWave.

## Cac file Android da thay doi

- `TelegramMusic.kt`: viet lai toan bo theo mo hinh local-only.
- `MainActivity.kt`: giu Android Share Sheet, bo deep link ma lien ket may chu.
- `AndroidManifest.xml`: giu `ACTION_SEND audio/*`, bo intent-filter pairing.
- `MusicController.kt`: phat file Telegram tren may, waveform va thong tin ky thuat doc tu file cuc bo.
- `LibraryScreen.kt`: noi dung giao dien va dong bo theo bot cuc bo.
- `HomeScreen.kt`: the Telegram Music tren trang chu.
- `build.gradle.kts`: bo endpoint/server BuildConfig; tang `versionCode` len 41.

## Tai lieu chinh thuc

- Telegram Bot API: https://core.telegram.org/bots/api
- BotFather va tinh nang bot: https://core.telegram.org/bots/features
- Hai cach nhan update: https://core.telegram.org/bots/webhooks
