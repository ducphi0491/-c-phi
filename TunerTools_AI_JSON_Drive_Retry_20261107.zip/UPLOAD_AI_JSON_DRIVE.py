#!/usr/bin/env python3
"""Incremental, create-only upload of cached AI JSON to Google Drive/AI_Music/lyrics.

No extra Python packages required (Python 3.10+ standard library).
Default mode is a read-only preview. Upload requires explicit --upload.
Never prints tokens, never changes the OAuth token file, never deletes/overwrites Drive files.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import mimetypes
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
import uuid

API_ROOT = 'https://www.googleapis.com/drive/v3/files'
UPLOAD_URL = 'https://www.googleapis.com/upload/drive/v3/files'
ROOT_NAME = 'TunerTools_AppBackup'
PROJECT_NAME = 'AI_Music'
DEST_NAME = 'lyrics'
FOLDER_MIME = 'application/vnd.google-apps.folder'
DEFAULT_ROOT = r'C:\TunerTools\Audio\AI_Music'
DEFAULT_TOKEN_PATHS = [
    r'C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json',
    r'C:\TunerTools\BackupScripts\Drive_Buoc2C\drive_token.json',
    r'C:\TunerTools\BackupScripts\Drive_Documents\drive_token.json',
]


def to_json(data: object) -> bytes:
    return json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def read_json_file(path: Path) -> object:
    return json.loads(path.read_text(encoding='utf-8-sig'))


def http_error_message(error: Exception) -> str:
    if isinstance(error, urllib.error.HTTPError):
        return f'Google API HTTP {error.code}'
    return f'{type(error).__name__}: {str(error)[:160]}'


class DriveRest:
    def __init__(self, token_file: Path):
        self.token_file = token_file
        if not token_file.is_file():
            raise RuntimeError(f'Khong tim thay private token file: {token_file}')
        try:
            self.data = read_json_file(token_file)
        except Exception as exc:
            raise RuntimeError('Khong doc duoc JSON OAuth token') from exc
        if not isinstance(self.data, dict):
            raise RuntimeError('Dinh dang token JSON khong hop le')
        self.token = (self.data.get('token') or self.data.get('access_token') or '').strip()
        raw_expiry = str(self.data.get('expiry') or '').strip()
        if raw_expiry:
            try:
                expiry = datetime.fromisoformat(raw_expiry.replace('Z', '+00:00'))
                if expiry.tzinfo is None:
                    expiry = expiry.replace(tzinfo=timezone.utc)
                if expiry <= datetime.now(timezone.utc) + timedelta(minutes=2):
                    self.token = ''
            except ValueError:
                self.token = ''
        if not self.token:
            self.refresh()

    def refresh(self) -> None:
        credentials = {field: self.data.get(field) for field in ('refresh_token', 'client_id', 'client_secret')}
        if any(not value for value in credentials.values()):
            raise RuntimeError('Token da het han, thieu refresh_token/client_id/client_secret; khong thay doi token cu')
        payload = dict(credentials)
        payload['grant_type'] = 'refresh_token'
        req = urllib.request.Request(
            'https://oauth2.googleapis.com/token',
            data=urllib.parse.urlencode(payload).encode('utf-8'),
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            method='POST',
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.load(resp)
        self.token = str(result.get('access_token') or '')
        if not self.token:
            raise RuntimeError('OAuth refresh khong tra access_token')
        # Avoid modifying shared token; refresh is only used in this process.

    def request(self, method: str, url: str, body: bytes | None = None,
                content_type: str | None = None, retry_after_ambiguous: bool = True) -> dict:
        refreshed = False
        for attempt in range(5):
            headers = {'Authorization': 'Bearer ' + self.token, 'Accept': 'application/json'}
            if content_type:
                headers['Content-Type'] = content_type
            req = urllib.request.Request(url, headers=headers, data=body, method=method)
            try:
                with urllib.request.urlopen(req, timeout=60) as resp:
                    payload = resp.read()
                data = json.loads(payload.decode('utf-8'))
                if not isinstance(data, dict):
                    raise RuntimeError('Google API response khong phai object')
                return data
            except urllib.error.HTTPError as exc:
                if exc.code == 401 and not refreshed:
                    self.refresh()
                    refreshed = True
                    continue
                if exc.code in (408, 429, 500, 502, 503, 504) and attempt < 4:
                    if not retry_after_ambiguous and method == 'POST':
                        raise
                    time.sleep(min(8.0, 0.65 * (2 ** attempt)))
                    continue
                raise
            except (TimeoutError, ConnectionError, urllib.error.URLError):
                if not retry_after_ambiguous and method == 'POST':
                    raise
                if attempt == 4:
                    raise
                time.sleep(min(8.0, 0.65 * (2 ** attempt)))
        raise RuntimeError('Google API thu qua so lan cho phep')

    def list_files(self, folder_id: str, *, name: str | None = None) -> list[dict]:
        # Escape single quote and backslash in Drive search syntax.
        q = f"'{folder_id}' in parents and trashed = false"
        if name is not None:
            safe_name = name.replace('\\', '\\\\').replace("'", "\\'")
            q += f" and name = '{safe_name}'"
        page_token = ''
        result: list[dict] = []
        for _ in range(100):
            query = {'q': q, 'pageSize': '1000', 'fields': 'nextPageToken,files(id,name,mimeType,size)', 'spaces': 'drive'}
            if page_token:
                query['pageToken'] = page_token
            obj = self.request('GET', API_ROOT + '?' + urllib.parse.urlencode(query))
            items = obj.get('files') or []
            if not isinstance(items, list):
                raise RuntimeError('Google files.list invalid response')
            result.extend(items)
            next_token = str(obj.get('nextPageToken') or '')
            if not next_token:
                return result
            if next_token == page_token:
                raise RuntimeError('Google Drive pagination stalled')
            page_token = next_token
        raise RuntimeError('Too many Google Drive list pages')

    def child_folder(self, parent_id: str, name: str) -> str:
        matches = [f for f in self.list_files(parent_id, name=name) if f.get('mimeType') == FOLDER_MIME]
        if len(matches) != 1:
            raise RuntimeError(f'Folder Drive {name!r} missing or ambiguous (found={len(matches)})')
        return str(matches[0]['id'])

    def root_folder(self) -> str:
        # Search exact parent in My Drive (not a file named like a parent elsewhere).
        matches = [f for f in self.list_files('root', name=ROOT_NAME) if f.get('mimeType') == FOLDER_MIME]
        if len(matches) != 1:
            raise RuntimeError(f'Khong tim thay duy nhat folder {ROOT_NAME} trong My Drive (found={len(matches)})')
        return str(matches[0]['id'])

    def create_json(self, parent_id: str, path: Path) -> str:
        boundary = 'TTJsonUpload' + uuid.uuid4().hex
        metadata = to_json({'name': path.name, 'mimeType': 'application/json', 'parents': [parent_id]})
        file_bytes = path.read_bytes()
        body = (
            b'--' + boundary.encode('ascii') + b'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' +
            metadata + b'\r\n--' + boundary.encode('ascii') +
            b'\r\nContent-Type: application/json\r\n\r\n' + file_bytes +
            b'\r\n--' + boundary.encode('ascii') + b'--\r\n'
        )
        query = urllib.parse.urlencode({'uploadType': 'multipart', 'fields': 'id,name,size'})
        # A POST may have succeeded even if connection drops; do not blind-retry POST.
        data = self.request('POST', UPLOAD_URL + '?' + query, body,
                            content_type='multipart/related; boundary=' + boundary,
                            retry_after_ambiguous=False)
        return str(data.get('id') or '')


def gather(root: Path, only_id: str | None) -> tuple[list[Path], list[str]]:
    files: list[Path] = []
    warnings: list[str] = []
    parts = [
        (root / 'ZING_JSON', lambda p: p.suffix.lower() == '.json'),
        (root / 'YOUTUBE_CACHE', lambda p: p.suffix.lower() == '.json' and p.name.startswith(('lyrics_', 'meta_'))),
    ]
    names_seen: dict[str, Path] = {}
    for folder, keep in parts:
        if not folder.is_dir():
            warnings.append(f'Khong thay folder: {folder}')
            continue
        for path in sorted(folder.iterdir(), key=lambda p: p.name.casefold()):
            if not path.is_file() or not keep(path):
                continue
            if only_id:
                if folder.name == 'ZING_JSON':
                    if path.name != only_id + '.json' and not path.name.startswith(only_id + '_'):
                        continue
                elif path.name not in ('lyrics_' + only_id + '.json', 'meta_' + only_id + '.json'):
                    continue
            if path.name in names_seen:
                warnings.append(f'Trung ten file, bo qua: {path.name}')
                continue
            names_seen[path.name] = path
            try:
                if path.stat().st_size <= 0 or path.stat().st_size > 2 * 1024 * 1024:
                    raise ValueError('size 0 or > 2MB')
                data = read_json_file(path)
                if not isinstance(data, (dict, list)):
                    raise ValueError('not a JSON object or array')
                files.append(path)
            except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
                warnings.append(f'JSON loi: {path.name}: {type(exc).__name__}')
    return files, warnings


def run() -> int:
    parser = argparse.ArgumentParser(description='Upload AI cached JSON only to Google Drive AI_Music/lyrics.')
    parser.add_argument('--source', default=DEFAULT_ROOT)
    parser.add_argument('--token', default='', help='Existing PRIVATE drive_token.json path (never published)')
    parser.add_argument('--upload', action='store_true', help='EXPLICITLY upload missing files; default is read-only preview')
    parser.add_argument('--only-id', default='', help='Optional: test only one song ID, e.g. 18JJ0AEDF3CO')
    parser.add_argument('--report', default='', help='Optional report .json destination')
    parser.add_argument('--pause', type=float, default=0.7, help='Pause in seconds between file operations (default: 0.7)')
    parser.add_argument('--failure-limit', type=int, default=8, help='Stop after N consecutive failed items (default: 8)')
    args = parser.parse_args()
    if not 0.0 <= args.pause <= 30.0:
        parser.error('--pause must be between 0 and 30 seconds')
    if not 1 <= args.failure_limit <= 100:
        parser.error('--failure-limit must be 1..100')
    if args.only_id and not re.fullmatch(r'[A-Za-z0-9_-]{6,64}', args.only_id):
        parser.error('--only-id must be 6..64 safe characters')
    root = Path(args.source)
    if not root.is_dir():
        parser.error(f'Khong tim thay source: {root}')
    files, warnings = gather(root, args.only_id or None)
    if not files:
        print('Khong tim thay JSON hop le de upload. Kiem tra thu muc ZING_JSON/YOUTUBE_CACHE.')
        for w in warnings[:15]:
            print('WARN:', w)
        return 2
    token_name = args.token or next((item for item in DEFAULT_TOKEN_PATHS if Path(item).is_file()), '')
    if not token_name:
        print('Khong tim thay private drive_token.json. Chi dinh --token <duong_dan_private>.')
        return 2
    report_path = Path(args.report) if args.report else root / 'KET_QUA_UPLOAD_JSON_DRIVE.json'
    print('MODE:', 'UPLOAD' if args.upload else 'PREVIEW ONLY (read-only)')
    print('LOCAL VALID JSON:', len(files))
    print('TOKEN FILE:', 'Found (private; contents not printed)')
    drive = DriveRest(Path(token_name))
    root_id = drive.root_folder()
    ai_id = drive.child_folder(root_id, PROJECT_NAME)
    lyrics_id = drive.child_folder(ai_id, DEST_NAME)
    remote_names = {str(f.get('name')) for f in drive.list_files(lyrics_id)}
    missing = [p for p in files if p.name not in remote_names]
    print('GOOGLE DRIVE lyrics existing entries:', len(remote_names))
    print('ALREADY ON DRIVE:', len(files) - len(missing))
    print('MISSING:', len(missing))
    for p in missing[:8]:
        print(' ', p.name)
    uploaded: list[str] = []
    failed: list[dict] = []
    already_during_upload = 0
    processed = 0
    recovered_after_disconnect = 0
    stopped_due_to_errors = False
    consecutive_errors = 0

    def write_report() -> None:
        report = {
            'mode': 'upload' if args.upload else 'preview',
            'date_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'source': str(root),
            'drive_target': f'My Drive/{ROOT_NAME}/{PROJECT_NAME}/{DEST_NAME}',
            'local_valid_json_count': len(files),
            'remote_existing_count_before': len(remote_names),
            'missing_before': len(missing),
            'processed_this_run': processed,
            'remaining_unattempted': max(0, len(missing) - processed),
            'uploaded_count': len(uploaded),
            'recovered_after_disconnect': recovered_after_disconnect,
            'already_during_upload': already_during_upload,
            'failed_count': len(failed),
            'failed': failed,
            'stopped_due_to_errors': stopped_due_to_errors,
            'warnings': warnings[:300],
        }
        try:
            report_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = report_path.with_name(report_path.name + '.writing')
            tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
            tmp.replace(report_path)
        except OSError as exc:
            print('WARN: cannot save report:', str(exc)[:120])

    if args.upload:
        try:
            for idx, path in enumerate(missing, 1):
                post_attempted = False
                try:
                    # Always check Drive before an upload (resume-safe; no overwrite).
                    if drive.list_files(lyrics_id, name=path.name):
                        already_during_upload += 1
                        consecutive_errors = 0
                        if idx % 50 == 0:
                            print(f'[{idx}/{len(missing)}] already exists on Drive')
                        continue
                    post_attempted = True
                    file_id = drive.create_json(lyrics_id, path)
                    if not file_id:
                        raise RuntimeError('No Drive file ID returned')
                    uploaded.append(path.name)
                    consecutive_errors = 0
                    if idx == 1 or idx % 20 == 0 or idx == len(missing):
                        print(f'[{idx}/{len(missing)}] uploaded={len(uploaded)} failed={len(failed)}')
                except Exception as exc:
                    # A POST may have succeeded when the TCP connection dropped.
                    # Never blindly send a second POST: check the remote name first.
                    recovered = False
                    if post_attempted:
                        for check_attempt in range(3):
                            time.sleep(2.0 * (check_attempt + 1))
                            try:
                                if drive.list_files(lyrics_id, name=path.name):
                                    recovered = True
                                    break
                            except Exception as check_exc:
                                print(f'[{idx}/{len(missing)}] WARN post-check {check_attempt+1}/3: {http_error_message(check_exc)}')
                    if recovered:
                        uploaded.append(path.name)
                        recovered_after_disconnect += 1
                        consecutive_errors = 0
                        print(f'[{idx}/{len(missing)}] RECOVERED after connection drop: {path.name}')
                    else:
                        failed.append({'filename': path.name, 'error': http_error_message(exc)})
                        consecutive_errors += 1
                        print(f'[{idx}/{len(missing)}] ERROR {path.name}: {http_error_message(exc)}')
                        # Delay after a transient error rather than pounding Drive.
                        time.sleep(min(12.0, 2.0 * consecutive_errors))
                finally:
                    processed = idx
                    if idx % 20 == 0 or consecutive_errors or idx == len(missing):
                        write_report()
                    if args.pause:
                        time.sleep(args.pause)

                if consecutive_errors >= args.failure_limit:
                    stopped_due_to_errors = True
                    print(f'SAFETY STOP: {consecutive_errors} consecutive failures; remaining files were not attempted.')
                    print('Restore connectivity, then rerun the same command; existing files are skipped.')
                    break
        except KeyboardInterrupt:
            write_report()
            print('INTERRUPTED: progress report saved; rerun to resume.')
            raise

    write_report()
    print('REPORT:', report_path)
    print('DONE:', len(uploaded), 'created or recovered; failed=', len(failed),
          '; not_attempted=', max(0, len(missing) - processed), '; nothing deleted or overwritten')
    print('NOTE: Alwaysdata cached_songs uses a 600-second cache; allow it to expire before rechecking.')
    return 1 if failed or stopped_due_to_errors else 0


if __name__ == '__main__':
    try:
        raise SystemExit(run())
    except KeyboardInterrupt:
        print('Stopped. Already uploaded files remain on Drive.')
        raise SystemExit(130)
    except Exception as exc:
        print('ERROR:', http_error_message(exc), file=sys.stderr)
        raise SystemExit(1)
