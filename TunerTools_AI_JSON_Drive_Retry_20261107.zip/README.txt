TunerTools AI JSON -> Google Drive (Retry/Resume v2)
====================================================

Diem moi:
- Giu nguyen cap quyen, thu muc, format JSON, khong xoa/ghi de tren Drive.
- Khi upload bi WinError 10054, kiem tra lai file tren Drive toi da 3 lan;
  khong POST lan thu hai khi ket qua ket noi chua ro rang.
- Giam tan suat yeu cau qua -PauseSeconds (mac dinh 0.7 giay).
- Luu bao cao checkpoint moi 20 file va sau khi gap loi.
- Neu co 8 file loi lien tiep, dung an toan; chay lai de tiep tuc.
- Moi lan chay quet lai danh sach Drive, bo qua cac file da ton tai.

QUAN TRONG: KHONG CHAY 2 TIEN TRINH UPLOAD CUNG LUC.
Cho script cu hoan tat hoac dung bang Ctrl+C truoc khi thay script.

1. Giai nen ZIP vao C:\TunerTools\Tools\AI_JSON_Drive_Sync

2. Chay preview:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Drive_Sync\CHAY_UPLOAD_AI_JSON.ps1"

3. Chay upload incremental / resume:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Drive_Sync\CHAY_UPLOAD_AI_JSON.ps1" -Upload

4. Neu mang yeu, chay cham hon:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Drive_Sync\CHAY_UPLOAD_AI_JSON.ps1" -Upload -PauseSeconds 1.5

5. Xem report:
Get-Content "C:\TunerTools\Audio\AI_Music\KET_QUA_UPLOAD_JSON_DRIVE.json" -Raw | ConvertFrom-Json | Select-Object uploaded_count, failed_count, remaining_unattempted

LUU Y: CHI TRIEN KHAI LEN WINDOWS SERVER, KHONG CAN DOI PHP/KOTLIN CHO LOI 10054.
