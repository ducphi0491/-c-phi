﻿param(
    [string]$SourceDir = "C:\TunerTools\Audio\AI_Music",
    [string]$TokenFile = "",
    [string]$OnlyId = "",
    [double]$PauseSeconds = 0.7,
    [int]$FailureLimit = 8,
    [switch]$Upload
)
$ErrorActionPreference = "Stop"
$scriptFile = Join-Path $PSScriptRoot 'UPLOAD_AI_JSON_DRIVE.py'
if (-not (Test-Path -LiteralPath $scriptFile)) { throw "Missing: $scriptFile" }
$pythonArgs = @($scriptFile, '--source', $SourceDir, '--pause', $PauseSeconds.ToString([System.Globalization.CultureInfo]::InvariantCulture), '--failure-limit', "$FailureLimit")
if ($TokenFile) { $pythonArgs += @('--token', $TokenFile) }
if ($OnlyId) { $pythonArgs += @('--only-id', $OnlyId) }
if ($Upload) { $pythonArgs += '--upload' }
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 @pythonArgs
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python @pythonArgs
} else { throw 'Python 3.10+ not found.' }
if ($LASTEXITCODE -ne 0) { throw "Upload JSON check failed (exit code: $LASTEXITCODE); inspect report for failed files." }
