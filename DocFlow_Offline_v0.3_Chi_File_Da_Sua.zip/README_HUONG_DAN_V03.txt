DOCFLOW OFFLINE v0.3 - CHI CAC FILE THAY DOI (baseline: doc.zip, 20/10/2026)

1. FILES CAN THAY TRONG ANDROID STUDIO

Copy 6 file Kotlin vao:
  app/src/main/java/com/docflowoffline/

  DocFlowApp.kt       - Trang chu, menu, tim kiem/loc file gan day
  DocumentScreens.kt  - Editor Excel, cong cu go den o va tim kiem
  OfficeOoxml.kt      - Doc mo rong vung du lieu XLSX + cached formula result
  DocumentStore.kt    - Metadata thoi gian mo file gan day
  ExcelGrid.kt        - MOI: luoi Excel Canvas cuon 2 chieu, hang/cot
  Theme.kt            - Bang mau Light/Dark

Copy file build.gradle.kts vao:
  app/build.gradle.kts

2. CAC FILE KHONG CAN DOI
  MainActivity.kt, AndroidManifest.xml, PdfTools.kt, CsvEngine.kt,
  ui/theme/*, cac thu muc assets/ va res/.

3. CHUC NANG HOAT DONG
  - Trang chu gon, tim trong DANH SACH FILE GAN DAY (khong quet toan bo may).
  - Loc PDF / Word / Excel / Slide; hien thi thoi gian mo file.
  - Nut tao moi; menu TAI LIEU / CHUYEN DOI / CONG CU / THONG TIN.
  - Excel Canvas + LazyColumn: cuon lien tuc theo hang, cuon ngang theo cot.
  - Hien tieu de cot, so hang; chon o; thanh fx sua o; bam dau tick de ap dung.
  - Chuyen sheet bang chip phia duoi; tim noi dung tai sheet dang xem;
    nhap dia chi (VD AZ850) roi bam 'Di'.
  - Luu XLSX thanh ban sao, khong sua file goc.
  - Doc/cap nhat o ngoai vung cu 400 hang x 40 cot.

4. GIOI HAN CAN BIET
  - Day CHUA PHAI Collabora/LibreOffice. Khong co WYSIWYG Office day du.
  - XLSX xem truoc toi da 120000 o co noi dung, 100000 hang, 256 cot.
    Neu vuot, co canh bao; cac thanh phan chua nap van duoc giu lai trong file goc.
  - Cong thuc hien cache ket qua co san neu file co, KHONG tu tinh cong thuc.
    PDF tu Word/Excel van la xuat PDF DANG CHU, khong giu layout.
  - Code doc OOXML con gioi han compressed 40MB, zip entries 96MB.
  - File XLS/DOC/PPT cu chua duoc ho tro boi engine hien tai.
  - Tao tai lieu moi van can assets/blank.docx, blank.xlsx, blank.pptx.
  - Khong phat sinh quyen INTERNET, khong them library moi.

5. KIEM TRA
  - Kotlin JVM: core OfficeOoxml va CsvEngine bien dich OK.
  - XLSX mau 900 hang x 66 cot (59400 o): doc, sua AZ850, them BC950,
    ghi lai va xac nhan doc duoc bang openpyxl: PASS.
  - DOCX/PPTX mau: doc OK; sua/l uu DOCX co ban OK.
  - Chua build APK tren Android SDK/may that trong moi truong nay.
    Hay Gradle Sync, Build APK va gui Build Output neu gap loi.

6. VERSION
  build.gradle.kts: versionCode=3, versionName=0.3.0; applicationId GIU NGUYEN
  com.docflowoffline.dev, package Kotlin com.docflowoffline.
