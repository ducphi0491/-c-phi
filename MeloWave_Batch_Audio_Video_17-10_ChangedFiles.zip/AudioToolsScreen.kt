package duc_phi.music

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.sourceforge.lame.mp3.Lame
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

internal enum class AudioToolMode { CONVERT, EXTRACT }
private enum class AudioTarget(val extension: String, val mime: String) {
    MP3("mp3", "audio/mpeg"),
    M4A("m4a", "audio/mp4"),
    WAV("wav", "audio/x-wav")
}

private enum class BatchStatus { WAITING, PROCESSING, SAVED, FAILED }

private data class AudioBatchEntry(
    val uri: Uri,
    val name: String,
    val status: BatchStatus = BatchStatus.WAITING,
    val detail: String = ""
)

/**
 * Full-screen overlay opened from Home. Existing one-file Save As flow is kept.
 * For 2+ selections, convert sequentially and save directly to a SAF tree chosen once.
 * No input document is changed or deleted. Cancellation removes only the current temp/output.
 */
@Composable
internal fun MeloWaveAudioToolDialog(mode: AudioToolMode, onDismiss: () -> Unit) {
    val colors = LocalMusicColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val savedLabel = mwString("audio_tools.saved", "Đã lưu file thành công")
    val cancelledLabel = mwString("audio_tools.batch_cancelled", "Đã hủy chuyển đổi. Những file đã lưu được giữ lại.")
    var entries by remember(mode) { mutableStateOf<List<AudioBatchEntry>>(emptyList()) }
    var folderUri by remember(mode) { mutableStateOf<Uri?>(null) }
    var target by remember(mode) { mutableStateOf(if (mode == AudioToolMode.EXTRACT) AudioTarget.M4A else AudioTarget.MP3) }
    var bitrate by remember(mode) { mutableStateOf(192) }
    var progress by remember(mode) { mutableFloatStateOf(0f) }
    var currentIndex by remember(mode) { mutableIntStateOf(-1) }
    var busy by remember(mode) { mutableStateOf(false) }
    var saving by remember(mode) { mutableStateOf(false) }
    var message by remember(mode) { mutableStateOf("") }
    var resultFile by remember(mode) { mutableStateOf<File?>(null) }
    var savedUri by remember(mode) { mutableStateOf<Uri?>(null) }
    var task by remember(mode) { mutableStateOf<Job?>(null) }

    val isBatch = entries.size > 1
    val savedCount = entries.count { it.status == BatchStatus.SAVED }
    val failedCount = entries.count { it.status == BatchStatus.FAILED }
    val processedCount = savedCount + failedCount
    val remainingCount = entries.size - savedCount
    val overallProgress = if (isBatch && entries.isNotEmpty()) {
        ((processedCount + if (busy && currentIndex >= 0) progress else 0f) / entries.size).coerceIn(0f, 1f)
    } else progress
    val folderLabel = remember(folderUri) { folderUri?.let { displayFolderFor(context, it) }.orEmpty() }

    DisposableEffect(mode) {
        onDispose {
            task?.cancel()
            // Single-file export remains in cache until user chooses Save As or closes the dialog.
            resultFile?.delete()
        }
    }

    fun clearResult() {
        resultFile?.delete()
        resultFile = null
        savedUri = null
        progress = 0f
        currentIndex = -1
        message = ""
        entries = entries.map { it.copy(status = BatchStatus.WAITING, detail = "") }
    }

    fun replaceInputs(uris: List<Uri>) {
        if (busy || saving || uris.isEmpty()) return
        clearResult()
        entries = uris.distinctBy { it.toString() }.map { uri ->
            AudioBatchEntry(uri, displayNameFor(context, uri))
        }
    }

    fun updateEntry(index: Int, status: BatchStatus, detail: String = "") {
        entries = entries.mapIndexed { i, item ->
            if (index == i) item.copy(status = status, detail = detail) else item
        }
    }

    val pickSingle = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) replaceInputs(listOf(uri))
    }
    val pickMultiple = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) replaceInputs(uris)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null && !busy && !saving) {
            // Persist the user's tree grant. This can fail on some cloud providers: the
            // session's temporary grant remains usable so it must not block conversion.
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            if (folderUri != uri) {
                clearResult()
                folderUri = uri
            }
        }
    }

    fun writeToDocument(destination: Uri?) {
        saving = false
        if (destination == null) return
        val source = resultFile ?: return
        saving = true
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val output = context.contentResolver.openOutputStream(destination, "w")
                        ?: error("Cannot open output document")
                    output.use { stream -> source.inputStream().use { it.copyTo(stream, 128 * 1024) } }
                }
                savedUri = destination
                message = ""
                Toast.makeText(context, savedLabel, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                message = e.localizedMessage ?: "Không lưu được file"
            } finally {
                saving = false
            }
        }
    }
    val createMp3 = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { writeToDocument(it) }
    val createM4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { writeToDocument(it) }
    val createWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { writeToDocument(it) }

    val chooseDocument = {
        val inputName = entries.firstOrNull()?.name.orEmpty()
        val name = safeAudioBaseName(inputName)
        val outputName = "${name}.${target.extension}"
        when (target) {
            AudioTarget.MP3 -> createMp3.launch(outputName)
            AudioTarget.M4A -> createM4a.launch(outputName)
            AudioTarget.WAV -> createWav.launch(outputName)
        }
    }

    fun startSingle() {
        val source = entries.singleOrNull() ?: return
        if (busy || saving) return
        clearResult()
        busy = true
        val format = target
        val kbps = bitrate
        task = scope.launch {
            var temp: File? = null
            try {
                temp = withContext(Dispatchers.IO) {
                    val cache = File(context.cacheDir, "mw_audio_exports").apply { mkdirs() }
                    File.createTempFile("mw_export_", ".${format.extension}", cache)
                }
                val output = temp ?: error("Không tạo được file tạm")
                withContext(Dispatchers.IO) {
                    var lastUiAt = 0L
                    AudioExportEngine.export(
                        context, source.uri, format.extension, kbps, output,
                        check = { if (!isActive) throw CancellationException() },
                        onProgress = { fraction ->
                            val now = SystemClock.uptimeMillis()
                            if (now - lastUiAt >= 150 || fraction >= 1f) {
                                lastUiAt = now
                                progress = fraction.coerceIn(0f, 1f)
                            }
                        }
                    )
                }
                resultFile = temp
                progress = 1f
                temp = null
            } catch (_: CancellationException) {
                message = cancelledLabel
            } catch (e: Exception) {
                message = e.localizedMessage ?: "Không thể xử lý file này"
            } finally {
                temp?.delete()
                busy = false
                task = null
            }
        }
    }

    fun startBatch() {
        val tree = folderUri ?: return
        if (busy || saving || entries.size < 2) return
        val pending = entries.indices.filter { entries[it].status != BatchStatus.SAVED }
        if (pending.isEmpty()) return
        entries = entries.map { if (it.status == BatchStatus.SAVED) it else it.copy(status = BatchStatus.WAITING, detail = "") }
        progress = 0f
        message = ""
        busy = true
        val originals = entries.toList()
        val format = target
        val kbps = bitrate
        task = scope.launch {
            try {
                // Query destination names once; append (2), (3), etc. instead of overwriting.
                val reservedNames = withContext(Dispatchers.IO) { existingNamesInFolder(context, tree) }
                for (index in pending) {
                    if (!isActive) throw CancellationException()
                    currentIndex = index
                    progress = 0f
                    updateEntry(index, BatchStatus.PROCESSING)
                    var temp: File? = null
                    try {
                        temp = withContext(Dispatchers.IO) {
                            val cache = File(context.cacheDir, "mw_audio_exports").apply { mkdirs() }
                            File.createTempFile("mw_batch_", ".${format.extension}", cache)
                        }
                        val output = temp ?: error("Không tạo được file tạm")
                        withContext(Dispatchers.IO) {
                            var lastUiAt = 0L
                            AudioExportEngine.export(
                                context, originals[index].uri, format.extension, kbps, output,
                                check = { if (!isActive) throw CancellationException() },
                                onProgress = { fraction ->
                                    val now = SystemClock.uptimeMillis()
                                    if (now - lastUiAt >= 150 || fraction >= 1f) {
                                        lastUiAt = now
                                        progress = fraction.coerceIn(0f, 1f) * 0.9f
                                    }
                                }
                            )
                        }
                        withContext(Dispatchers.IO) {
                            saveBatchDocument(
                                context, tree, output, originals[index].name, format, reservedNames,
                                check = { if (!isActive) throw CancellationException() },
                                onProgress = { fraction -> progress = 0.9f + fraction.coerceIn(0f, 1f) * 0.1f }
                            )
                        }
                        updateEntry(index, BatchStatus.SAVED)
                        progress = 1f
                    } catch (_: CancellationException) {
                        updateEntry(index, BatchStatus.WAITING)
                        throw CancellationException()
                    } catch (e: Exception) {
                        // One broken/unsupported input does not stop the rest of the queue.
                        updateEntry(index, BatchStatus.FAILED, e.localizedMessage ?: "Không thể xử lý file")
                    } finally {
                        temp?.delete()
                    }
                }
            } catch (_: CancellationException) {
                message = cancelledLabel
            } catch (e: Exception) {
                message = e.localizedMessage ?: "Không thể truy cập thư mục lưu"
            } finally {
                currentIndex = -1
                progress = 0f
                busy = false
                task = null
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy && !saving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = colors.background) {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = mwString("common.close", "Đóng"),
                        modifier = Modifier.size(27.dp).clickable(enabled = !busy && !saving) { onDismiss() },
                        tint = colors.textPrimary
                    )
                    Spacer(Modifier.size(15.dp))
                    Text(
                        if (mode == AudioToolMode.CONVERT) mwString("audio_tools.convert", "Chuyển đổi nhạc")
                        else mwString("audio_tools.extract", "Tách âm thanh"),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
                Column(
                    modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(17.dp)
                ) {
                    Text(
                        if (mode == AudioToolMode.CONVERT)
                            mwString("audio_tools.batch_convert_hint", "Chọn một hoặc nhiều bài nhạc để chuyển đổi. Chế độ nhiều file sẽ tự lưu vào một thư mục.")
                        else mwString("audio_tools.batch_extract_hint", "Chọn một hoặc nhiều video để tách âm thanh. Video gốc được giữ nguyên."),
                        fontSize = 13.sp, color = colors.textSecondary
                    )
                    AudioExportSection(colors.card, colors.border) {
                        Text(mwString("audio_tools.source", "Tệp nguồn"), fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Spacer(Modifier.height(9.dp))
                        if (entries.isEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (mode == AudioToolMode.CONVERT) Icons.Rounded.MusicNote else Icons.Rounded.VideoFile,
                                    contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(28.dp)
                                )
                                Spacer(Modifier.size(12.dp))
                                Text(mwString("audio_tools.not_selected", "Chưa chọn tệp"), color = colors.textSecondary, fontSize = 13.sp)
                            }
                        } else if (!isBatch) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (mode == AudioToolMode.CONVERT) Icons.Rounded.MusicNote else Icons.Rounded.VideoFile,
                                    contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(28.dp)
                                )
                                Spacer(Modifier.size(12.dp))
                                Text(entries[0].name, color = colors.textPrimary, fontSize = 13.sp,
                                    modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            Text(
                                mwString("audio_tools.batch_selected", "Đã chọn {count} file", "count" to entries.size),
                                color = colors.purpleBright, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                            )
                            Spacer(Modifier.height(9.dp))
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth().height(216.dp),
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                itemsIndexed(entries, key = { _, item -> item.uri.toString() }) { index, entry ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        when (entry.status) {
                                            BatchStatus.SAVED -> Icon(Icons.Rounded.CheckCircle, null,
                                                tint = colors.green, modifier = Modifier.size(17.dp))
                                            BatchStatus.FAILED -> Icon(Icons.Rounded.ErrorOutline, null,
                                                tint = colors.red, modifier = Modifier.size(17.dp))
                                            BatchStatus.PROCESSING -> CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp), strokeWidth = 2.dp,
                                                color = colors.purpleBright
                                            )
                                            BatchStatus.WAITING -> Text("${index + 1}.", color = colors.textMuted, fontSize = 11.sp)
                                        }
                                        Spacer(Modifier.size(9.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(entry.name, color = colors.textPrimary, fontSize = 12.sp,
                                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            when (entry.status) {
                                                BatchStatus.FAILED -> Text(
                                                    entry.detail.ifBlank { mwString("audio_tools.batch_failed", "Thất bại") },
                                                    color = colors.red, fontSize = 11.sp,
                                                    maxLines = 2, overflow = TextOverflow.Ellipsis
                                                )
                                                BatchStatus.SAVED -> Text(
                                                    mwString("audio_tools.batch_saved", "Đã lưu"), color = colors.green, fontSize = 11.sp
                                                )
                                                BatchStatus.PROCESSING -> Text(
                                                    "${mwString("audio_tools.processing", "Đang xử lý...")} ${(progress * 100).toInt()}%",
                                                    color = colors.purpleBright, fontSize = 11.sp
                                                )
                                                BatchStatus.WAITING -> Unit
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { pickSingle.launch(if (mode == AudioToolMode.CONVERT) arrayOf("audio/*") else arrayOf("video/*")) },
                                enabled = !busy && !saving, modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, colors.purpleBright)
                            ) {
                                Text(mwString("audio_tools.pick_single", "Chọn 1 file"),
                                    color = colors.purpleBright, fontSize = 12.sp, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { pickMultiple.launch(if (mode == AudioToolMode.CONVERT) arrayOf("audio/*") else arrayOf("video/*")) },
                                enabled = !busy && !saving, modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, colors.purpleBright)
                            ) {
                                Icon(Icons.Rounded.FolderOpen, contentDescription = null,
                                    tint = colors.purpleBright, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.size(6.dp))
                                Text(mwString("audio_tools.pick_multiple", "Chọn nhiều file"),
                                    color = colors.purpleBright, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    if (isBatch) {
                        AudioExportSection(colors.card, colors.border) {
                            Text(mwString("audio_tools.batch_folder", "Thư mục lưu kết quả"),
                                color = colors.textPrimary, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (folderUri == null)
                                    mwString("audio_tools.batch_no_folder", "Chọn thư mục một lần để tự động lưu tất cả file sau chuyển đổi.")
                                else folderLabel,
                                color = colors.textSecondary, fontSize = 12.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !busy && !saving,
                                onClick = { pickFolder.launch(null) },
                                border = BorderStroke(1.dp, colors.purpleBright)
                            ) {
                                Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = colors.purpleBright)
                                Spacer(Modifier.size(8.dp))
                                Text(mwString("audio_tools.batch_choose_folder", "Chọn thư mục lưu"), color = colors.purpleBright)
                            }
                        }
                    }
                    AudioExportSection(colors.card, colors.border) {
                        Text(mwString("audio_tools.output", "Định dạng đầu ra"), color = colors.textPrimary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AudioTarget.entries.forEach { entry ->
                                val selected = target == entry
                                Surface(
                                    modifier = Modifier.weight(1f).clickable(enabled = !busy && !saving) {
                                        if (target != entry) { target = entry; clearResult() }
                                    },
                                    color = if (selected) colors.purple.copy(alpha = 0.20f) else colors.cardRaised,
                                    shape = RoundedCornerShape(13.dp),
                                    border = BorderStroke(1.dp, if (selected) colors.purpleBright else colors.border)
                                ) {
                                    Box(modifier = Modifier.padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                                        Text(entry.extension.uppercase(), color = if (selected) colors.purpleBright else colors.textPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(9.dp))
                        Text(
                            if (target == AudioTarget.WAV) mwString("audio_tools.wav_note", "WAV không nén: file có thể lớn.")
                            else if (target == AudioTarget.M4A) mwString("audio_tools.m4a_note", "M4A (AAC): ưu tiên chép luồng AAC gốc khi có thể.")
                            else mwString("audio_tools.mp3_note", "MP3: mã hóa bằng Java, có thể lâu hơn M4A."),
                            fontSize = 12.sp, color = colors.textSecondary
                        )
                        if (target != AudioTarget.WAV) {
                            Spacer(Modifier.height(14.dp))
                            Text(mwString("audio_tools.bitrate", "Chất lượng (kbps)"),
                                color = colors.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(128, 192, 256).forEach { rate ->
                                    Surface(
                                        modifier = Modifier.weight(1f).clickable(enabled = !busy && !saving) {
                                            if (bitrate != rate) { bitrate = rate; clearResult() }
                                        },
                                        color = if (rate == bitrate) colors.purple.copy(alpha = 0.20f) else colors.cardRaised,
                                        shape = RoundedCornerShape(11.dp),
                                        border = BorderStroke(1.dp, if (rate == bitrate) colors.purpleBright else colors.border)
                                    ) {
                                        Text("$rate", modifier = Modifier.padding(vertical = 10.dp),
                                            color = if (rate == bitrate) colors.purpleBright else colors.textPrimary,
                                            fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                    }
                                }
                            }
                        }
                    }
                    if (busy || resultFile != null || (isBatch && processedCount > 0)) {
                        AudioExportSection(colors.card, colors.border) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp),
                                    strokeWidth = 2.dp, color = colors.purpleBright)
                                else if (isBatch && failedCount > 0 && savedCount == 0)
                                    Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = colors.red)
                                else Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = colors.green)
                                Spacer(Modifier.size(10.dp))
                                Text(
                                    if (busy) mwString("audio_tools.processing", "Đang xử lý...")
                                    else if (isBatch) mwString("audio_tools.batch_finished", "Đã hoàn tất lượt chuyển đổi")
                                    else mwString("audio_tools.ready", "Đã xử lý xong — chọn nơi lưu file"),
                                    color = colors.textPrimary, fontWeight = FontWeight.Medium
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = overallProgress,
                                modifier = Modifier.fillMaxWidth(),
                                color = colors.purpleBright, trackColor = colors.border
                            )
                            Spacer(Modifier.height(7.dp))
                            Text("${(overallProgress * 100).toInt()}%", color = colors.textSecondary, fontSize = 12.sp)
                            if (isBatch) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    mwString("audio_tools.batch_summary", "Đã lưu {done}/{total} • Lỗi {failed}",
                                        "done" to savedCount, "total" to entries.size, "failed" to failedCount),
                                    color = colors.textSecondary, fontSize = 12.sp
                                )
                                if (busy && currentIndex in entries.indices) {
                                    Text(
                                        mwString("audio_tools.batch_current", "File {index}/{total}: {name}",
                                            "index" to currentIndex + 1, "total" to entries.size,
                                            "name" to entries[currentIndex].name),
                                        color = colors.textSecondary, fontSize = 12.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                    if (message.isNotBlank()) Text(message, color = colors.red, fontSize = 13.sp)
                    if (!isBatch && savedUri != null) {
                        OutlinedButton(onClick = {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(savedUri, target.mime)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                })
                            } catch (_: ActivityNotFoundException) {
                                Toast.makeText(context, "Không tìm thấy ứng dụng mở tệp", Toast.LENGTH_SHORT).show()
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(mwString("audio_tools.open_saved", "Mở file vừa lưu"), color = colors.purpleBright)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 15.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (busy) {
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth().height(53.dp),
                            onClick = { task?.cancel() }, border = BorderStroke(1.dp, colors.red)
                        ) { Text(mwString("audio_tools.cancel", "Hủy chuyển đổi"), color = colors.red) }
                    } else if (!isBatch && resultFile != null) {
                        Button(
                            modifier = Modifier.fillMaxWidth().height(54.dp), enabled = !saving,
                            onClick = chooseDocument,
                            colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                        ) {
                            Icon(Icons.Rounded.SaveAlt, contentDescription = null, tint = Color.White)
                            Spacer(Modifier.size(9.dp))
                            Text(mwString("audio_tools.save", "Lưu file vào điện thoại"), color = Color.White)
                        }
                    } else {
                        val canStart = if (isBatch) remainingCount > 0 && folderUri != null else entries.size == 1
                        Button(
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            enabled = canStart && !saving,
                            onClick = { if (isBatch) startBatch() else startSingle() },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                        ) {
                            Text(
                                if (isBatch && remainingCount == 0)
                                    mwString("audio_tools.batch_all_saved", "Đã lưu tất cả file")
                                else if (isBatch && processedCount > 0)
                                    mwString("audio_tools.batch_resume", "Tiếp tục / thử lại file lỗi")
                                else if (mode == AudioToolMode.CONVERT)
                                    mwString("audio_tools.start", "Bắt đầu chuyển đổi")
                                else mwString("audio_tools.extract", "Tách âm thanh"),
                                color = Color.White, fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        mwString("audio_tools.original", "MeloWave không thay đổi hoặc xóa tệp gốc."),
                        fontSize = 11.sp, color = colors.textMuted,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        }
    }
}

@Composable
private fun AudioExportSection(bg: Color, border: Color, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = bg, shape = RoundedCornerShape(19.dp),
        border = BorderStroke(1.dp, border)
    ) { Column(modifier = Modifier.padding(16.dp), content = content) }
}

private fun displayNameFor(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    } ?: uri.lastPathSegment ?: "MeloWave"
}.getOrDefault(uri.lastPathSegment ?: "MeloWave")

private fun displayFolderFor(context: Context, tree: Uri): String = runCatching {
    val folder = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    displayNameFor(context, folder)
}.getOrElse { tree.lastPathSegment ?: "Thư mục đã chọn" }

private fun safeAudioBaseName(name: String): String {
    val base = name.substringBeforeLast('.', name)
        .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
        .trim().trimEnd('.').take(88)
    return base.ifBlank { "MeloWave" }
}

private fun existingNamesInFolder(context: Context, tree: Uri): MutableSet<String> {
    val names = mutableSetOf<String>()
    // A few cloud providers cannot enumerate folder children. They can still create a new
    // document, and the provider itself will resolve collisions if supported.
    runCatching {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        context.contentResolver.query(
            children, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                cursor.getString(0)?.let { names += it.lowercase(Locale.ROOT) }
            }
        }
    }
    return names
}

private fun saveBatchDocument(
    context: Context,
    folder: Uri,
    source: File,
    originalName: String,
    target: AudioTarget,
    reservedNames: MutableSet<String>,
    check: () -> Unit,
    onProgress: (Float) -> Unit
): Uri {
    check()
    val base = safeAudioBaseName(originalName)
    var candidate = "$base.${target.extension}"
    var suffix = 2
    while (candidate.lowercase(Locale.ROOT) in reservedNames) {
        candidate = "${base.take(76)} ($suffix).${target.extension}"
        suffix++
    }
    val parent = DocumentsContract.buildDocumentUriUsingTree(folder, DocumentsContract.getTreeDocumentId(folder))
    val destination = DocumentsContract.createDocument(context.contentResolver, parent, target.mime, candidate)
        ?: error("Không tạo được file trong thư mục đã chọn")
    try {
        check()
        context.contentResolver.openOutputStream(destination, "w")?.use { output ->
            source.inputStream().use { input ->
                val buffer = ByteArray(128 * 1024)
                var written = 0L
                var lastUiAt = 0L
                val length = source.length().coerceAtLeast(1L)
                while (true) {
                    check()
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    written += read
                    val now = SystemClock.uptimeMillis()
                    if (now - lastUiAt >= 150L) {
                        lastUiAt = now
                        onProgress(written.toFloat() / length)
                    }
                }
                output.flush()
                onProgress(1f)
            }
        } ?: error("Không thể ghi file vào thư mục đã chọn")
        check()
        reservedNames += candidate.lowercase(Locale.ROOT)
        return destination
    } catch (e: Exception) {
        // Never leave a partial/malformed output behind after cancel or write error.
        runCatching { DocumentsContract.deleteDocument(context.contentResolver, destination) }
        throw e
    }
}

/** Uses Android's platform codecs for AAC/WAV, plus pure Java LAME for MP3. */
private object AudioExportEngine {
    fun export(
        context: Context, uri: Uri, format: String, bitrateKbps: Int, output: File,
        check: () -> Unit, onProgress: (Float) -> Unit
    ) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("Tệp không có luồng âm thanh có thể đọc")
            val inputFormat = extractor.getTrackFormat(trackIndex)
            extractor.selectTrack(trackIndex)
            val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION))
                inputFormat.getLong(MediaFormat.KEY_DURATION) else 0L
            val mime = inputFormat.getString(MediaFormat.KEY_MIME).orEmpty()
            if (format == "m4a" && mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                copyAac(extractor, inputFormat, output, durationUs, check, onProgress)
            } else {
                decodeAudio(extractor, inputFormat, format, bitrateKbps, output, durationUs, check, onProgress)
            }
            require(output.length() > 44) { "Không có dữ liệu âm thanh để lưu" }
        } finally {
            extractor.release()
        }
    }

    private fun copyAac(
        extractor: MediaExtractor, input: MediaFormat, target: File, duration: Long,
        check: () -> Unit, progress: (Float) -> Unit
    ) {
        var muxer: MediaMuxer? = null
        var started = false
        try {
            muxer = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val track = muxer.addTrack(input)
            muxer.start()
            started = true
            val capacity = if (input.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                max(1024 * 1024, input.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)) else 1024 * 1024
            val buffer = ByteBuffer.allocateDirect(min(capacity, 16 * 1024 * 1024))
            val info = MediaCodec.BufferInfo()
            while (true) {
                check()
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                val codecFlags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else {
                    0
                }
                info.set(0, size, max(0L, extractor.sampleTime), codecFlags)
                buffer.position(0)
                buffer.limit(size)
                muxer.writeSampleData(track, buffer, info)
                if (duration > 0) progress((info.presentationTimeUs.toFloat() / duration).coerceIn(0f, 0.99f))
                extractor.advance()
            }
            progress(1f)
        } finally {
            if (started) runCatching { muxer?.stop() }
            muxer?.release()
        }
    }

    private fun decodeAudio(
        extractor: MediaExtractor, source: MediaFormat, format: String, bitrate: Int,
        target: File, duration: Long, check: () -> Unit, progress: (Float) -> Unit
    ) {
        val mime = source.getString(MediaFormat.KEY_MIME) ?: error("Không nhận dạng được âm thanh")
        val decoder = MediaCodec.createDecoderByType(mime)
        var sink: PcmWriter? = null
        try {
            decoder.configure(source, null, null, 0)
            decoder.start()
            var inputEnded = false
            var outputEnded = false
            val info = MediaCodec.BufferInfo()
            while (!outputEnded) {
                check()
                if (!inputEnded) {
                    val index = decoder.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val buffer = decoder.getInputBuffer(index) ?: error("Decoder input buffer unavailable")
                        buffer.clear()
                        val read = extractor.readSampleData(buffer, 0)
                        if (read < 0) {
                            decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEnded = true
                        } else {
                            decoder.queueInputBuffer(index, 0, read, max(0L, extractor.sampleTime), 0)
                            extractor.advance()
                        }
                    }
                }
                val index = decoder.dequeueOutputBuffer(info, 10_000)
                when (index) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (sink != null) error("Âm thanh thay đổi định dạng trong khi xử lý")
                        sink = buildWriter(decoder.outputFormat, format, bitrate, target)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER, MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                    else -> if (index >= 0) {
                        if (sink == null) sink = buildWriter(decoder.outputFormat, format, bitrate, target)
                        if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            val data = decoder.getOutputBuffer(index) ?: error("Decoder output buffer unavailable")
                            data.position(info.offset)
                            data.limit(info.offset + info.size)
                            val raw = ByteArray(info.size)
                            data.get(raw)
                            sink!!.write(raw)
                            if (duration > 0) progress((info.presentationTimeUs.toFloat() / duration).coerceIn(0f, 0.99f))
                        }
                        outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(index, false)
                    }
                }
            }
            check()
            val writer = sink ?: error("Không tìm được dữ liệu âm thanh")
            writer.finish()
            progress(1f)
        } finally {
            runCatching { sink?.close() }
            runCatching { decoder.stop() }
            decoder.release()
        }
    }

    private fun buildWriter(outputFormat: MediaFormat, ext: String, bitrate: Int, file: File): PcmWriter {
        val sampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        require(channels in 1..2) { "Hiện chỉ hỗ trợ âm thanh mono hoặc stereo" }
        val pcmEncoding = if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING))
            outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
        require(pcmEncoding == 2) { "Thiết bị xuất PCM không phải 16-bit; chưa hỗ trợ codec này" }
        return when (ext) {
            "wav" -> WavWriter(file, sampleRate, channels)
            "mp3" -> Mp3Writer(file, sampleRate, channels, bitrate)
            "m4a" -> AacWriter(file, sampleRate, channels, bitrate)
            else -> error("Định dạng xuất không được hỗ trợ")
        }
    }

    private interface PcmWriter : Closeable {
        fun write(pcm: ByteArray)
        fun finish()
    }

    private class WavWriter(file: File, private val rate: Int, private val channels: Int) : PcmWriter {
        private val target = RandomAccessFile(file, "rw")
        private var bytes = 0L
        init { target.setLength(0); target.write(ByteArray(44)) }
        override fun write(pcm: ByteArray) {
            require(bytes + pcm.size <= 0xFFFFFFFFL - 36L) { "File WAV vượt giới hạn 4 GB" }
            target.write(pcm)
            bytes += pcm.size
        }
        override fun finish() {
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray(Charsets.US_ASCII))
            h.putInt((36L + bytes).toInt())
            h.put("WAVEfmt ".toByteArray(Charsets.US_ASCII))
            h.putInt(16)
            h.putShort(1)
            h.putShort(channels.toShort())
            h.putInt(rate)
            h.putInt(rate * channels * 2)
            h.putShort((channels * 2).toShort())
            h.putShort(16)
            h.put("data".toByteArray(Charsets.US_ASCII))
            h.putInt(bytes.toInt())
            target.seek(0)
            target.write(h.array())
        }
        override fun close() { target.close() }
    }

    private class Mp3Writer(file: File, rate: Int, private val channels: Int, bitrate: Int) : PcmWriter {
        private val stream = FileOutputStream(file)
        private val encoder = Lame()
        private var remainder = ByteArray(0)
        init {
            val flags = encoder.getFlags()
            flags.setInNumChannels(channels)
            flags.setInSampleRate(rate)
            flags.setBitRate(if (rate < 32_000) min(bitrate, 160) else bitrate)
            flags.setQuality(5)
            encoder.getId3().init(flags)
            flags.setWriteId3tagAutomatic(false)
            val state = encoder.initParams()
            require(state >= 0) { "Không khởi tạo được bộ mã hóa MP3 ($state)" }
        }
        override fun write(pcm: ByteArray) {
            val alignedSize = ((remainder.size + pcm.size) / (2 * channels)) * (2 * channels)
            val joined = if (remainder.isEmpty()) pcm else remainder + pcm
            if (alignedSize == 0) { remainder = joined; return }
            val frameBytes = channels * 2
            val maxFrames = 8192
            var offset = 0
            while (offset < alignedSize) {
                val frames = min(maxFrames, (alignedSize - offset) / frameBytes)
                val left = FloatArray(frames)
                val right = FloatArray(frames)
                for (i in 0 until frames) {
                    val p = offset + i * frameBytes
                    val l = (joined[p].toInt() and 0xff) or (joined[p + 1].toInt() shl 8)
                    left[i] = (l.toShort().toInt() shl 16).toFloat()
                    if (channels == 2) {
                        val r = (joined[p + 2].toInt() and 0xff) or (joined[p + 3].toInt() shl 8)
                        right[i] = (r.toShort().toInt() shl 16).toFloat()
                    } else {
                        right[i] = left[i]
                    }
                }
                val buffer = ByteArray((1.25 * frames).toInt() + 8192)
                val count = encoder.encodeBuffer(left, right, frames, buffer)
                require(count >= 0) { "Lỗi mã hóa MP3 ($count)" }
                if (count > 0) stream.write(buffer, 0, count)
                offset += frames * frameBytes
            }
            remainder = if (alignedSize == joined.size) ByteArray(0) else joined.copyOfRange(alignedSize, joined.size)
        }
        override fun finish() {
            require(remainder.isEmpty()) { "Âm thanh PCM thiếu dữ liệu mẫu" }
            val buffer = ByteArray(16384)
            val count = encoder.encodeFlush(buffer)
            require(count >= 0) { "Lỗi hoàn tất MP3 ($count)" }
            if (count > 0) stream.write(buffer, 0, count)
            stream.flush()
        }
        override fun close() {
            runCatching { encoder.close() }
            stream.close()
        }
    }

    private class AacWriter(file: File, rate: Int, private val channels: Int, bitrate: Int) : PcmWriter {
        private val encoder: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        private val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        private var muxStarted = false
        private var track = -1
        private var queuedFrames = 0L
        private var encoderEos = false
        private val sampleRate = rate
        private val info = MediaCodec.BufferInfo()
        init {
            val codecFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, channels).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate * 1000)
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32 * 1024)
            }
            encoder.configure(codecFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
        }
        override fun write(pcm: ByteArray) {
            var offset = 0
            val frameSize = channels * 2
            require(pcm.size % frameSize == 0) { "PCM không đồng bộ frame" }
            var emptyPolls = 0
            while (offset < pcm.size) {
                var index = encoder.dequeueInputBuffer(10_000)
                if (index < 0) { drain(false); index = encoder.dequeueInputBuffer(10_000) }
                if (index < 0) {
                    check(++emptyPolls < 500) { "AAC encoder input timed out" }
                    continue
                }
                emptyPolls = 0
                val buffer = encoder.getInputBuffer(index) ?: error("AAC input buffer unavailable")
                buffer.clear()
                val len = min(pcm.size - offset, buffer.remaining()) / frameSize * frameSize
                require(len > 0) { "AAC input buffer quá nhỏ" }
                buffer.put(pcm, offset, len)
                encoder.queueInputBuffer(index, 0, len, queuedFrames * 1_000_000L / sampleRate, 0)
                queuedFrames += len / frameSize
                offset += len
                drain(false)
            }
        }
        override fun finish() {
            var polls = 0
            while (true) {
                check(++polls < 500) { "AAC encoder EOS timed out" }
                val index = encoder.dequeueInputBuffer(10_000)
                if (index >= 0) {
                    encoder.queueInputBuffer(index, 0, 0, queuedFrames * 1_000_000L / sampleRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(false)
            }
            var attempts = 0
            while (!encoderEos && attempts++ < 400) drain(true)
            check(encoderEos) { "AAC encoder did not finish" }
        }
        private fun drain(wait: Boolean) {
            while (true) {
                val index = encoder.dequeueOutputBuffer(info, if (wait) 10_000 else 0)
                when (index) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> return
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(!muxStarted) { "AAC encoder changed output format twice" }
                        track = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxStarted = true
                    }
                    MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                    else -> if (index >= 0) {
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0) {
                            check(muxStarted) { "AAC muxer has not started" }
                            val buffer = encoder.getOutputBuffer(index) ?: error("AAC output buffer unavailable")
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            muxer.writeSampleData(track, buffer, info)
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) encoderEos = true
                        encoder.releaseOutputBuffer(index, false)
                    }
                }
            }
        }
        override fun close() {
            runCatching { encoder.stop() }
            encoder.release()
            if (muxStarted) runCatching { muxer.stop() }
            muxer.release()
        }
    }
}
