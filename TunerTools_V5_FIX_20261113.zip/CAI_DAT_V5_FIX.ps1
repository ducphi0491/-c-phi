param(
    [string]$Destination = 'C:\TunerTools\Tools\PDF_TAB_GP_WEB'
)
$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ''
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ' TunerTools Web V5 FIX - Cai dat / Cap nhat' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ('Thu muc giai nen: ' + $Source)
Write-Host ('Thu muc cai dat:  ' + $Destination)

# Prevent overwriting running V4/V5 program files.
$Url = 'http://127.0.0.1:8021/api/health'
$Running = $false
try {
    $Response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop
    if ($Response.StatusCode -eq 200) { $Running = $true }
} catch { }
if ($Running) {
    Write-Host 'LOI: Web cu dang chay tai cong 8021.' -ForegroundColor Red
    Write-Host 'Hay quay lai cua so CHAY_WEB cu va nhan ENTER de dung web; sau do cai lai.' -ForegroundColor Yellow
    exit 2
}

$Required = @('app.py', 'CHAY_WEB.bat', 'CHAY_WEB.ps1', 'vector_draft.py', 'review_bundle.py', 'static\index.html')
foreach ($File in $Required) {
    if (-not (Test-Path -LiteralPath (Join-Path $Source $File) -PathType Leaf)) {
        Write-Host ('LOI: Thieu file trong goi ZIP: ' + $File) -ForegroundColor Red
        exit 3
    }
}

# Validate original files before installing. Use only the hashes in the bundled manifest.
$HashList = Join-Path $Source 'MANIFEST_SHA256_V5.csv'
if (-not (Test-Path -LiteralPath $HashList)) {
    Write-Host 'LOI: Khong tim thay manifest kiem tra file.' -ForegroundColor Red
    exit 3
}
$Rows = @(Import-Csv -LiteralPath $HashList)
foreach ($Row in $Rows) {
    $FullPath = Join-Path $Source $Row.Path
    if (-not (Test-Path -LiteralPath $FullPath -PathType Leaf)) {
        Write-Host ('LOI: File bi thieu: ' + $Row.Path) -ForegroundColor Red
        exit 3
    }
    $Actual = (Get-FileHash -LiteralPath $FullPath -Algorithm SHA256).Hash
    if ($Actual -ne $Row.SHA256) {
        Write-Host ('LOI: File sai SHA256: ' + $Row.Path) -ForegroundColor Red
        exit 3
    }
}
Write-Host ('[OK] ' + $Rows.Count + ' file hop le (SHA256).') -ForegroundColor Green

$SourceFull = [IO.Path]::GetFullPath($Source).TrimEnd('\')
$DestFull = [IO.Path]::GetFullPath($Destination).TrimEnd('\')
if (-not (Test-Path -LiteralPath $DestFull)) {
    New-Item -ItemType Directory -Path $DestFull -Force | Out-Null
}

if (-not [string]::Equals($SourceFull, $DestFull, [StringComparison]::OrdinalIgnoreCase)) {
    # Save a small backup of the previous program; do not touch venv or local assets.
    $Backup = Join-Path $DestFull ('BACKUP_TRUOC_V5_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $OldFiles = @('app.py', 'vector_draft.py', 'CHAY_WEB.ps1', 'static\app.js', 'static\index.html')
    $AnyOld = $false
    foreach ($Old in $OldFiles) {
        $OldPath = Join-Path $DestFull $Old
        if (Test-Path -LiteralPath $OldPath -PathType Leaf) {
            $BackupPath = Join-Path $Backup $Old
            New-Item -ItemType Directory -Path (Split-Path -Parent $BackupPath) -Force | Out-Null
            Copy-Item -LiteralPath $OldPath -Destination $BackupPath -Force
            $AnyOld = $true
        }
    }
    if ($AnyOld) { Write-Host ('Da luu ban sao ma cu: ' + $Backup) }

    # Copy the known package files, preserving existing Python venv, SoundFont and user data.
    foreach ($Row in $Rows) {
        $From = Join-Path $Source $Row.Path
        $To = Join-Path $DestFull $Row.Path
        $Parent = Split-Path -Parent $To
        if (-not (Test-Path -LiteralPath $Parent)) {
            New-Item -ItemType Directory -Path $Parent -Force | Out-Null
        }
        Copy-Item -LiteralPath $From -Destination $To -Force
    }
    foreach ($Aux in @('MANIFEST_SHA256_V5.csv','CAI_DAT_V5_FIX.ps1','CAI_DAT_V5_FIX.bat','HUONG_DAN_CAI_V5_FIX.txt')) {
        Copy-Item -LiteralPath (Join-Path $Source $Aux) -Destination (Join-Path $DestFull $Aux) -Force
    }
}

$AppCode = [IO.File]::ReadAllText((Join-Path $DestFull 'app.py'))
if (-not $AppCode.Contains('version="0.5.0"')) {
    Write-Host 'LOI: app.py sau khi cai dat khong phai V5.' -ForegroundColor Red
    exit 4
}
if (-not (Test-Path -LiteralPath (Join-Path $DestFull 'review_bundle.py') -PathType Leaf)) {
    Write-Host 'LOI: Thieu bo xuat goi doi chieu V5.' -ForegroundColor Red
    exit 4
}
Write-Host '[OK] TunerTools Web V5 da duoc cai dat dung.' -ForegroundColor Green
Write-Host ('Chay: ' + (Join-Path $DestFull 'CHAY_WEB.bat')) -ForegroundColor Cyan
exit 0
