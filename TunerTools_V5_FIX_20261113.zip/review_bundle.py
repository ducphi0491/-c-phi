"""Create a reproducible, offline ZIP of source and draft GP data for review.

The bundle preserves original input bytes (optional), checked GP files, a MIDI
render of exported notes, measure mapping, ambiguity flags, PNGs and CSV/JSON.
Music XML is NOT invented: this pack deliberately does not claim to decode OMR.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from hashlib import sha256
from html import escape
from io import BytesIO, StringIO
from pathlib import Path
import csv
import json
import struct
import zipfile

import fitz
from PIL import Image, ImageDraw

VERSION = "5.0-review"
SIX_STRING_TUNING = {1:64,2:59,3:55,4:50,5:45,6:40}


def _json(obj) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, indent=2, default=str)+"\n").encode('utf-8')


def _csv(rows, columns) -> bytes:
    stream=StringIO(newline='')
    writer=csv.DictWriter(stream,fieldnames=columns, extrasaction='ignore', lineterminator='\n')
    writer.writeheader()
    for item in rows:
        writer.writerow({k:item.get(k,"") for k in columns})
    return ('\ufeff'+stream.getvalue()).encode('utf-8')


def _vlq(n):
    n=max(0,int(n)); parts=[n & 127]; n >>= 7
    while n:
        parts.insert(0,(n & 127)|128); n >>= 7
    return bytes(parts)


def _midi_file(score: dict) -> bytes:
    """Generate a standard MIDI file from *exported GP* notes for comparison."""
    ppq=480
    tempo=int(score.get('tempo') or 80)
    microseconds=round(60000000 / max(30,min(300,tempo)))
    def chunk(payload:bytes) -> bytes:
        return b'MTrk'+struct.pack('>I',len(payload))+payload
    header=bytes([255,81,3])+microseconds.to_bytes(3,'big')
    meter='4/4'
    for tr in score.get('tracks',[]):
        for measure in tr.get('measures',[]):
            meter=measure.get('time','4/4')
            break
        if tr.get('measures'):break
    try:
        top,bottom=(int(x) for x in meter.split('/'))
        assert 1<=top<=24 and bottom in (2,4,8,16,32)
    except (ValueError,AssertionError,AttributeError):
        top,bottom=4,4
    denominator_power={2:1,4:2,8:3,16:4,32:5}[bottom]
    time_event=bytes([255,88,4,top,denominator_power,24,8])
    meta=[(0,0,header),(0,1,time_event)]
    all_tracks=[]
    for ti,track in enumerate(score.get('tracks',[])):
        channel=ti%15
        if channel>=9:channel+=1
        records=list(meta) if ti==0 else []
        records.append((0,2,bytes([0xC0|channel,24])))
        for m in track.get('measures',[]):
            start=float(m.get('start',0))
            for beat in m.get('beats',[]):
                pos=float(beat.get('position',0))
                length=float(beat.get('length',.5))
                begin=max(0,round((start+pos)*ppq))
                end=max(begin+1,round((start+pos+max(.015,length)*.93)*ppq))
                for n in beat.get('notes',[]):
                    pitch=int(n.get('pitch',0))
                    if not 0<=pitch<=127:continue
                    vel=max(1,min(127,int(n.get('velocity',95))))
                    records.append((begin,3,bytes([0,0x90|channel,pitch,vel])))
                    records.append((end,1,bytes([0,0x80|channel,pitch,0])))
        records.sort(key=lambda e:(e[0],e[1]))
        payload=bytearray();last=0
        for tick,_,message in records:
            payload.extend(_vlq(tick-last));payload.extend(message);last=tick
        payload.extend(b'\x00\xff\x2f\x00')
        all_tracks.append(chunk(bytes(payload)))
    if not all_tracks:
        all_tracks=[chunk(b'\x00\xff\x2f\x00')]
    return b'MThd'+struct.pack('>IHHH',6,1 if len(all_tracks)>1 else 0,len(all_tracks),ppq)+b''.join(all_tracks)


def _draft_rows(draft):
    bars=[]; notes=[]
    if not draft:return bars,notes
    for bar in draft.get('bars',[]):
        risks=','.join(bar.get('risks',[]))
        row={
            'gp_measure':bar['number'],
            'pdf_measure_label':bar.get('source_printed_measure') or '',
            'pdf_page':bar['page'], 'pdf_system':bar['system'],
            'pdf_x0':bar['x_range'][0],'pdf_x1':bar['x_range'][1],
            'columns':bar['columns_count'],'notes':bar['notes_count'],
            'bar_boundary':bar.get('boundary_method',''),
            'rhythm_estimated':'YES',
            'label_lanes':json.dumps(bar.get('measure_number_lanes',[])),
            'risks':risks,
        }
        bars.append(row)
        for bi,beat in enumerate(bar.get('beats',[])):
            for ni,note in enumerate(beat.get('notes',[])):
                notes.append({
                    'gp_measure':bar['number'],
                    'pdf_measure_label':bar.get('source_printed_measure') or '',
                    'pdf_page':bar['page'], 'pdf_system':bar['system'],
                    'beat':bi+1,'note':ni+1,
                    'pdf_x':note['x'],'pdf_y':note['y'],
                    'string':note['string'],'fret':note['fret'],
                    'sounding_pitch':SIX_STRING_TUNING.get(note['string'],0)+note['fret'],
                    'duration_denominator_GUESSED':beat['duration'],
                    'dotted_GUESSED':beat['dotted'],
                    'confidence':'UNVERIFIED',
                    'risks':risks
                })
    return bars,notes


def _exported_notes_rows(score):
    out=[]
    for track in score.get('tracks',[]):
        for m in track.get('measures',[]):
            for beat in m.get('beats',[]):
                for n in beat.get('notes',[]):
                    out.append({
                        'track':track['index']+1,
                        'gp_measure':m['number'],
                        'voice':beat['voice']+1,
                        'beat':beat['beat']+1,
                        'note':n['note']+1,
                        'string':n['string'],'fret':n['fret'],
                        'sounding_pitch':n['pitch'],
                        'time_quarters':round(m['start']+beat['position'],5),
                        'duration_quarters':beat['length'],
                        'duration_value':beat['duration'],
                        'dotted':beat['dotted'],
                    })
    return out


def _pdf_previews(data, selected, draft, limit=12):
    measures_by_page=defaultdict(list)
    for bar in (draft or {}).get('bars',[]):
        measures_by_page[bar['page']].append(bar)
    images={}
    try:
        doc=fitz.open(stream=data,filetype='pdf')
        for page0 in selected[:limit]:
            if not (0<=page0<len(doc)):continue
            page=doc[page0];scale=min(1.65,1100/max(1,page.rect.width))
            pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale), colorspace=fitz.csRGB,alpha=False)
            original=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
            overlay=original.copy();drawer=ImageDraw.Draw(overlay,'RGBA')
            for bar in measures_by_page.get(page0+1,[]):
                lo,hi=bar['x_range']
                # System rows are identified by the y-bounds stored in audit.
                system=next((x for x in draft.get('systems_audit',[]) if x['page']==page0+1 and x['system']==bar['system']),None)
                if not system:continue
                y0,y1=system['tab_y']
                conflict='overprinted_measure_labels' in bar['risks']
                color=(224,69,78,80) if conflict else (240,146,38,85) if bar['boundary_method']=='labels_fallback' else (27,130,197,50)
                outline=(220,58,72,230) if conflict else (235,145,24,220) if bar['boundary_method']=='labels_fallback' else (36,115,186,200)
                box=[round(lo*scale),round((y0-2)*scale),round(hi*scale),round((y1+2)*scale)]
                drawer.rectangle(box, fill=color,outline=outline,width=2)
                label=str(bar.get('source_printed_measure') or '?')
                drawer.text((box[0]+4,box[1]+2),f"GP {bar['number']} / PDF {label}",fill=(38,34,32,255))
            a=BytesIO();b=BytesIO()
            original.save(a,format='PNG',optimize=True)
            overlay.save(b,format='PNG',optimize=True)
            images[page0+1]=(a.getvalue(),b.getvalue())
        doc.close()
    except Exception as exc:
        images['error']=str(exc)
    return images


def _html_report(manifest, measure_rows, note_rows, images):
    def fmt(value):return escape(str(value))
    issues=[x for x in measure_rows if 'overprinted' in x.get('risks','') or 'inferred' in x.get('bar_boundary','')]
    source_links=[]
    for p in images:
        if isinstance(p,int):
            source_links.append('<div class="card"><h3>Trang %d</h3><img src="images/page_%02d_original.png" alt="Trang goc %d"><img src="images/page_%02d_overlay.png" alt="Overlay %d"></div>' % (p,p,p,p,p))
    rows=[]
    for bar in measure_rows:
        rows.append('<tr>'+''.join('<td>'+fmt(bar.get(k,''))+'</td>' for k in ('gp_measure','pdf_measure_label','pdf_page','pdf_system','notes','columns','bar_boundary','risks'))+'</tr>')
    meta=manifest.get('analysis',{})
    return ("""<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>TunerTools V5 | Audit report</title><style>
    body{font-family:system-ui,sans-serif;margin:0 auto;max-width:1160px;background:#f7f8fb;color:#222;padding:20px}
    header{background:#172e42;color:white;padding:26px;border-radius:14px}h1{margin:0 0 12px;font-size:25px}
    .box,.card{background:white;border-radius:12px;padding:15px;margin:16px 0;border:1px solid #dce2e8}
    .warn{border-left:5px solid #d17b28;padding:14px;background:#fff9ed}img{width:100%%;display:block;margin:8px 0;border:1px solid #e2e6e9}
    table{width:100%%;border-collapse:collapse;font-size:12px}th,td{text-align:left;border-bottom:1px solid #ddd;padding:5px;vertical-align:top}
    th{background:#e8eef5;position:sticky;top:0}.scroll{max-height:650px;overflow:auto}
    </style></head><body><header><h1>TunerTools V5 - Bao cao doi chieu</h1><div>Ban nhap GP - KHONG chung nhan do chinh xac nhan dien</div></header>
    <div class="box"><b>File goc:</b> %s | <b>Hash:</b> %s<br><b>GP bars:</b> %s | <b>Printed number labels:</b> %s | <b>Unresolved labels:</b> %s</div>
    <div class="warn">Cac thong so truong do trong che do PDF vector deu duoc UOC LUONG. Neu so thu tu o nhip chong len nhau, he thong se giu nguyen canh bao, KHONG tu cho la da phuc hoi noi dung am nhac.</div>
    <div class="box"><h2>Vung can kiem tra: %d</h2><p>Xem measures.csv va input file, so sanh tung o nhip truoc khi su dung ban GP.</p></div>
    <div class="box"><h2>Danh sach o nhip nhap</h2><div class="scroll"><table><thead><tr><th>GP bar</th><th>PDF label</th><th>Page</th><th>System</th><th>Notes</th><th>Columns</th><th>Boundary</th><th>Risk</th></tr></thead><tbody>%s</tbody></table></div></div>
    <div class="box"><h2>PDF source / bar detection overlays</h2>%s</div>
    <footer>Goi du lieu may tinh cuc bo. MIDI la ban phat tu file GP xuat, khong phai am thanh goc cua PDF.</footer></body></html>""" % (
        fmt(manifest.get('source',{}).get('filename','')),
        fmt(manifest.get('source',{}).get('sha256','')),
        fmt(meta.get('output_measures','?')),
        fmt(meta.get('printed_measure_label_count','?')),
        fmt(meta.get('unresolved_count','?')),
        len(issues),''.join(rows),''.join(source_links)
    )).encode('utf-8')


def generate_review_zip(job:dict, *, include_source:bool=True) -> bytes:
    source=job.get('source_file') or b''
    filename=job.get('source_filename','source.pdf')
    draft=job.get('audit_draft')
    score=job.get('score') or {}
    report=job.get('report') or {}
    measures, source_notes=_draft_rows(draft)
    exported=_exported_notes_rows(score)
    selected=[i-1 for i in (job.get('selected_pages') or [])]
    if not selected and filename.lower().endswith('.pdf') and source:
        with fitz.open(stream=source,filetype='pdf') as doc:
            selected=list(range(len(doc)))
    images=_pdf_previews(source,selected,draft) if include_source and filename.lower().endswith('.pdf') and source else {}
    analysis=(draft or {}).get('label_audit', {})
    manifest={
        'format':'tunertools_v5_review_bundle',
        'version':VERSION,'created_utc':datetime.now(timezone.utc).isoformat(),
        'source':{'filename':filename,'sha256':sha256(source).hexdigest() if source else '',
                  'bytes':len(source),'included':bool(include_source and source)},
        'conversion_mode':report.get('mode','unknown'),
        'tempo_bpm':score.get('tempo'),
        'time_signature':(draft or {}).get('time_signature'),
        'selected_pages':[x+1 for x in selected],
        'analysis':analysis,
        'output_notes':len(exported),
        'source_digit_candidates':len(source_notes),
        'rhythm_estimated_bars':len(measures) if draft else None,
        'edited_after_recognition':len(job.get('edit_history',[])),
        'warnings':report.get('warnings',[]),
        'export_warnings':job.get('export_warnings',{}),
        'file_sha256':{k:sha256(v).hexdigest() for k,v in job.get('files',{}).items()},
        'limitations':[
            'The PDF is not an authoritative MusicXML transcription.',
            'MIDI is synthesized from GP output, not source recording.',
            'No measured note accuracy is claimed.',
        ]
    }
    b=BytesIO()
    with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        z.writestr('manifest.json',_json(manifest))
        z.writestr('source_notes.csv',_csv(source_notes,['gp_measure','pdf_measure_label','pdf_page','pdf_system','beat','note','pdf_x','pdf_y','string','fret','sounding_pitch','duration_denominator_GUESSED','dotted_GUESSED','confidence','risks']))
        z.writestr('output_notes.csv',_csv(exported,['track','gp_measure','voice','beat','note','string','fret','sounding_pitch','time_quarters','duration_quarters','duration_value','dotted']))
        z.writestr('measures.csv',_csv(measures,['gp_measure','pdf_measure_label','pdf_page','pdf_system','pdf_x0','pdf_x1','columns','notes','bar_boundary','rhythm_estimated','label_lanes','risks']))
        z.writestr('exported_score.json',_json(score))
        z.writestr('recognition_diagnostics.json',_json({'draft':draft,'report':report,'edit_history':job.get('edit_history',[])}))
        z.writestr('GP_output/result.mid',_midi_file(score))
        for fmt,data in job.get('files',{}).items():z.writestr('GP_output/result.'+fmt,data)
        if source and include_source:
            suffix=Path(filename).suffix.lower()
            if suffix not in ('.pdf','.png','.jpg','.jpeg','.webp','.gp3','.gp4','.gp5'):suffix='.dat'
            z.writestr('source/original'+suffix,source)
        for page,contents in images.items():
            if not isinstance(page,int):continue
            orig,marked=contents
            z.writestr('images/page_%02d_original.png'%page,orig)
            z.writestr('images/page_%02d_overlay.png'%page,marked)
        z.writestr('OPEN_REVIEW.html',_html_report(manifest,measures,source_notes,images))
        z.writestr('README_FIRST.txt',(
          'TUNERTOOLS V5 - COMPARISON PACKAGE\n\n'
          '1) Keep the original PDF/PNG in this ZIP when sharing for a true comparison.\n'
          '2) Open OPEN_REVIEW.html to inspect page overlays and mapped GP measures.\n'
          '3) measures.csv maps GP bars to source page, PDF measure label and source x range.\n'
          '4) source_notes.csv holds original PDF fret locations and ASSUMED rhythm.\n'
          '5) output_notes.csv holds notes ACTUALLY saved in GP after your edits.\n'
          '6) GP_output/result.mid lets you audition timing outside TunerTools.\n'
          '7) recognition_diagnostics.json includes possible overlapping numbers.\n\n'
          'IMPORTANT: rhythm, tremolo, ornament and lyrics are NOT automatically verified.\n'
          'If numbers overlap on a PDF, a missing label is not proof that a\n'
          'recoverable, independent bar exists in the original drawing.\n'
        ).encode('utf-8'))
    return b.getvalue()
