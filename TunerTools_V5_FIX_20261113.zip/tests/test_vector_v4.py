"""Reliable local checks of the vector extraction and V4 web route.

No pretrained or proprietary models are required for these tests.
"""
import io
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import fitz
from fastapi.testclient import TestClient
import app
from vector_draft import extract_vector_draft, _rhythm_from_spacing


def synthetic_tab_pdf():
    pdf=fitz.open()
    page=pdf.new_page(width=595,height=842)
    # One staff 5 lines and TAB with 6 lines, approx like a notation PDF.
    for i in range(5):
        page.draw_rect(fitz.Rect(30,40+i*5.4,510,40+i*5.4+.5),color=None,fill=(0,0,0))
    for i in range(6):
        page.draw_rect(fitz.Rect(30,125+i*7.8,510,125+i*7.8+.5),color=None,fill=(0,0,0))
    for x in [270,510]:
        page.draw_rect(fitz.Rect(x,125,x+.7,125+5*7.8),fill=(0,0,0),color=None)
    # Get bbox-center to sit near the first string: draw using ascender-aware
    # font metrics: Helvetica fontsize 9 has midpoint around baseline-4.
    for x in [50,85,120,155,190,225,280,315,350,385,420,455]:
        page.insert_text((x,129),str((x//10)%9),fontsize=9,fontname='helv')
    data=pdf.tobytes()
    pdf.close()
    return data


def test_vector_draft_not_empty_and_not_claiming_accuracy():
    data=synthetic_tab_pdf()
    result=extract_vector_draft(data,[0],time_sig='6/8',bpm=80)
    assert result['total_notes']>0
    assert result['mode']=='vector_draft'
    assert 'BẢN NHÁP' in result['warnings'][0]
    assert result['time_signature']=='6/8'
    for bar in result['bars']:
        assert abs(sum(beat['length'] for beat in bar['beats'])-3.)<0.0001
        assert all(b['rhythm_estimated'] for b in bar['beats'])


def test_invalid_time_and_scan_fail_safely():
    data=synthetic_tab_pdf()
    try:
        extract_vector_draft(data,[0],time_sig='nonsense')
        assert False
    except ValueError: pass
    blank=fitz.open()
    blank.new_page()
    blob=blank.tobytes()
    blank.close()
    try:
        extract_vector_draft(blob,[0],time_sig='6/8')
        assert False
    except ValueError as exc:
        assert 'Không đọc' in str(exc)


def test_rhythm_estimator_6_8():
    c=[{'x':(i+1)*20,'notes':[{'string':1,'fret':0}]} for i in range(6)]
    out, uncertain=_rhythm_from_spacing(c,140,6,8)
    assert len(out)==6
    assert all(b['duration']==8 and b['dotted'] is False for b in out)
    assert abs(sum(b['length'] for b in out)-3)<1e-6


def test_health_v4_and_vector_inspect():
    client=TestClient(app.app)
    info=client.get('/api/health').json()
    assert info['version']=='0.5.0'
    assert info['vector_draft'] is True
    r=client.post('/api/inspect',files={'file':('example.pdf',synthetic_tab_pdf(),'application/pdf')})
    assert r.status_code==200, r.text
    assert r.json()['vector_summary']['available']
