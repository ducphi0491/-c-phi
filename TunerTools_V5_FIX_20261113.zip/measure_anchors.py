"""Vector PDF measure-label detection and conservative measure boundary repair.

Numbers printed above a staff are hints, not proof of measure timing. In some
PDFs multiple number sequences are overprinted on the same system; they are
reported as collisions instead of silently treating them as recovered bars.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any


def detect_lanes(page, tab: dict, prior_tab: dict | None = None) -> list[dict[str, Any]]:
    top = float(tab['lines'][0])
    prev_bottom = float(prior_tab['lines'][-1]) if prior_tab else 0.0
    # Notes in the previous system are not measure labels. Labels belong in
    # the band well above the current TAB system, usually just above its staff.
    y_min = max(0.0, prev_bottom + 3.0)
    y_max = top - 18.0
    if y_min >= y_max:
        return []
    records = []
    for w in page.get_text('words'):
        x0,y0,x1,y1,txt=w[:5]
        if not txt.isdecimal():
            continue
        val=int(txt)
        if not (1 <= val <= 2000 and 27 < x0 < page.rect.width - 12):
            continue
        if not (y_min <= y0 <= y_max and 3 < y1-y0 < 12.5):
            continue
        # Deduplicate text twice emitted by a PDF (e.g. tempo marker).
        if any(r['number']==val and abs(r['x']-x0)<.2 and abs(r['y']-y0)<.2 for r in records):
            continue
        records.append({'number':val,'x':round(float(x0),2),'y':round(float(y0),2)})
    rows=[]
    for item in sorted(records,key=lambda r:(r['y'],r['x'])):
        if not rows or abs(item['y']-rows[-1]['y'])>2.5:
            rows.append({'y':item['y'],'items':[item]})
        else:
            rows[-1]['items'].append(item)
    lanes=[]
    for row in rows:
        ordered=sorted(row['items'],key=lambda r:r['x'])
        # Strictly increasing and consecutive printed measure numbers; short
        # sequences of random TAB fret values therefore usually do not pass.
        if len(ordered)<2 or len(ordered)>12:
            continue
        values=[r['number'] for r in ordered]
        if any(b!=a+1 for a,b in zip(values,values[1:])):
            continue
        if any(b['x']-a['x']<13 for a,b in zip(ordered,ordered[1:])):
            continue
        lanes.append({'y':round(row['y'],1),'labels':ordered,
                      'numbers':values,'count':len(values)})
    return sorted(lanes,key=lambda v:v['y'])


def resolve_boundaries(notes: list[dict], barlines: list[float], lanes: list[dict],
                       tab: dict) -> dict:
    """Partition based on barlines, supplement with printed labels when needed.

    A multiple-lane conflict is not solved by this function: select one
    physical lane and record the other printed sequences as ambiguous.
    """
    if not notes:
        return {'edges': [],'labels':[],'lanes':lanes,'problems':['no_frets'],
                'method':'none','missing_labels':[]}
    xs=[n['x'] for n in notes]
    left=min(xs)-max(7.0,float(tab['spacing']))
    right=max(xs)+max(9.0,float(tab['spacing'])*1.4)
    active=[x for x in barlines if left+2 < x < right+14]
    count=len(active) if active else 0
    # Last barline is the right boundary of the last measure; source PDF may
    # omit internal barlines but still expose printed labels above it.
    if lanes:
        primary=min(lanes,key=lambda ln: (
            abs(ln['count']-count) if count else 0,
            -ln['count'] if not count else 0,
            ln['y']
        ))
    else:
        primary=None
    problems=[]
    missing=[]
    if len(lanes)>1:
        problems.append('overprinted_measure_number_lanes')
        missing=[n for lane in lanes if lane is not primary for n in lane['numbers']]
    chosen=primary['labels'] if primary else []
    expected=len(chosen)
    if expected>=2 and (not active or count<expected):
        # Use starts printed above individual measures as a fallback. Unlike
        # rhythm inference this can be checked visually with the PDF.
        anchors=[r['x'] for r in chosen]
        edges=[min(left, anchors[0]-2.0)]
        edges.extend(anchors[1:])
        edges.append(max(right, max(active,default=-1)))
        method='labels_fallback'
        problems.append('barlines_missing_used_label_starts')
    else:
        edges=[left]+sorted(active)
        if edges[-1] < max(xs)+2:
            edges.append(right)
        method='vector_barlines' if active else 'single_region_unverified'
    dedup=[]
    for x in edges:
        if not dedup or x-dedup[-1]>2:
            dedup.append(float(x))
    if len(dedup)<2:
        dedup=[left,right]
    if chosen and (len(dedup)-1)!=expected:
        problems.append('measure_label_count_mismatch')
    return {'edges':dedup,'labels':chosen,'lanes':lanes,'problems':problems,
            'method':method,'missing_labels':missing,'printed_count':expected,
            'barlines_found':len(active)}


def audit_summary(draft: dict) -> dict:
    all_labels=set()
    omitted=set()
    conflicts=[]
    sources=draft.get('systems_audit',[])
    for system in sources:
        for lane in system.get('lanes',[]):
            all_labels.update(lane['numbers'])
        omitted.update(system.get('unresolved_labels',[]))
        if len(system.get('lanes',[]))>1:
            conflicts.append({'page':system['page'],'system':system['system'],
                              'lanes':[l['numbers'] for l in system['lanes']],
                              'selected':system.get('selected_labels',[])})
    return {'printed_measure_label_count':len(all_labels),
            'printed_first':min(all_labels,default=None),
            'printed_last':max(all_labels,default=None),
            'unresolved_printed_labels':sorted(omitted),
            'unresolved_count':len(omitted),
            'overprinted_system_count':len(conflicts),
            'overprinted_systems':conflicts,
            'output_measures':len(draft.get('bars',[])),
            'note':'Printed numbers are NOT proof of correct reconstruction.'}
