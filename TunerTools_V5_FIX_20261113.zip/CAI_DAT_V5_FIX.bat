@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAI_DAT_V5_FIX.ps1"
if errorlevel 1 (
    echo.
    echo Cai dat V5 chua thanh cong. Vui long gui anh loi PowerShell.
    pause
    exit /b 1
)
call "C:\TunerTools\Tools\PDF_TAB_GP_WEB\CHAY_WEB.bat"
endlocal
