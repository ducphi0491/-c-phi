# TunerTools V5 - Review package and conservative PDF measure segmentation

## What changed

- Measure number labels on vector PDFs are detected as candidate anchors.
- Missing vector barlines may be supplemented with printed measure starts.
- Overprinted numeric lanes are explicitly reported; no automatic invention of independent content.
- GP output, source PDF, original notes, exported notes, MIDI and source overlays can be exported as one review ZIP.
- GP note edits are recorded; final score and raw detections are both preserved.
- The interface still shows staff + TAB and supports playback/editing and GP3/GP4/GP5 export when conversion succeeds.

## Sample (not included in the package)

`ban_nhac.pdf` (6 pages, user-provided, checked with the vector extractor):

| Page | V4 bar regions | V5 bar regions | Printed measure labels |
|---|---:|---:|---:|
| 1 | 20 | 20 | 1-20 |
| 2 | 20 | 20 | 21-45; lanes 21-24 / 25-29 overlap |
| 3 | 25 | 25 | 46-74; lanes 46-49 / 50-53 overlap |
| 4 | 13 | 17 | 75-91 |
| 5 | 7 | 10 | 92-104; lanes 92-93 / 94-96 overlap |
| 6 | 4 | 4 | 105-111; lanes 105-108 / 109-111 overlap |
| **Total** | **89** | **96** | **111 labels / 15 not uniquely mapped** |

NOTE: 96 regions are NOT 96 musicologically validated bars. At least four groups of printed labels share the same graphical system, and full rhythmic reconstruction is unsolved. On the sample, 4 extracted fret digits remain unmapped, which is reported separately.

## Verification

- 18 automated tests passed in local Linux/Python container.
- JavaScript syntax passes `node --check`.
- ZIP (source, CSV, JSON, MIDI, PNG, HTML) was generated and CRC-tested with a synthetic GP score.
- Application endpoint `/api/review-package/{id}` tested with include_source=1/0 and invalid argument.
- This environment could not install `PyGuitarPro` due to no network access, so full GP write/read-through and Windows GUI testing have NOT been completed here. Existing V4 GP export paths are preserved; verify the GP output on the user's Windows installation.

## Deliberate limitations

- No verified OMR for note duration, rests, ties, tremolo, H/P or multiple voices.
- PDF original and overlay can contain overlapping/ambiguous printed measure numbers.
- Image/PDF scan recognition still depends on the optional OCR/OMR engine.
- No proprietary EZMusic/Orpheus code or model weights bundled.
- Audio MIDI comes from the GP draft, not the PDF source.
