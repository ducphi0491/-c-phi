#!/usr/bin/env python3
# Offline ONNX model integrity & smoke test for an Orpheus model pack.
# It does NOT implement score recognition or MusicXML decoding.
import argparse
import hashlib
import json
import os
import sys
import time
import zipfile
from pathlib import Path

MODEL_NAMES = ("layout.onnx", "encoder.onnx", "decoder.onnx", "orpheus.json")
STRIP_WIDTHS = (512, 768, 1024, 1280, 1664)


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest().lower()


def shape_json(shape):
    return [str(x) if not isinstance(x, (int, float)) else x for x in shape]


def main():
    p = argparse.ArgumentParser(description="Kiem tra va chay thu mo hinh Orpheus ONNX tren Windows")
    p.add_argument("--zip", dest="zip_path", required=True, type=Path)
    p.add_argument("--image", dest="image_path", type=Path, default=None)
    p.add_argument("--out", dest="out_dir", type=Path, default=Path("KET_QUA_KIEM_THU"))
    p.add_argument("--width", type=int, default=512, choices=STRIP_WIDTHS)
    p.add_argument("--only-check", action="store_true", help="Chi kiem tra goi ZIP/SHA-256; khong can onnxruntime")
    args = p.parse_args()

    if not args.zip_path.is_file():
        p.error("Khong tim thay file ZIP: " + str(args.zip_path))
    args.out_dir.mkdir(parents=True, exist_ok=True)
    notes = []
    report = {
        "model_zip": str(args.zip_path.resolve()),
        "image": str(args.image_path.resolve()) if args.image_path else None,
        "tests": {},
        "limitations": [
            "Khong phai he thong OMR hoan chinh.",
            "Tien xu ly anh la thu nghiem, khong duoc xac minh la dung voi EZMusic.",
            "Khong co bo tokenizer/ghip token ra MusicXML.",
            "Gia tri du doan tren anh thu khong chung minh do chinh xac nhan dien not.",
        ],
    }

    def log(s):
        s = str(s)
        print(s, flush=True)
        notes.append(s)

    def save():
        (args.out_dir / "ket_qua.txt").write_text("\n".join(notes) + "\n", encoding="utf-8")
        (args.out_dir / "ket_qua.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    try:
        log("=== ORPHEUS TEST ===")
        log("File: " + str(args.zip_path.resolve()))
        with zipfile.ZipFile(args.zip_path, "r") as z:
            corrupt = z.testzip()
            if corrupt is not None:
                raise RuntimeError("ZIP CRC loi tai file: " + corrupt)
            manifest = json.loads(z.read("manifest.json").decode("utf-8-sig"))
            model_cfg = json.loads(z.read("orpheus.json").decode("utf-8-sig"))
            expected = {r["path"]: r for r in manifest["files"]}
            missing = sorted(set(MODEL_NAMES) - set(z.namelist()))
            extra = sorted(set(expected) - set(MODEL_NAMES))
            if missing or extra:
                raise RuntimeError(f"Danh sach file bat thuong: thieu={missing}, ngoai_du_kien={extra}")
            bytes_sum = 0
            models_dir = args.out_dir / "models"
            models_dir.mkdir(exist_ok=True)
            for filename in MODEL_NAMES:
                item = expected.get(filename)
                if item is None:
                    raise RuntimeError("Manifest thieu: " + filename)
                content = z.read(filename)
                actual_hash = sha256_hex(content)
                actual_size = len(content)
                if actual_size != int(item["bytes"]):
                    raise RuntimeError(f"Sai dung luong {filename}: got={actual_size}, want={item['bytes']}")
                if actual_hash != str(item["sha256"]).lower():
                    raise RuntimeError(f"SHA-256 khong khop: {filename}")
                # Only allow exact names from the manifest; no path traversal extraction.
                (models_dir / filename).write_bytes(content)
                log(f"[OK] {filename}: {actual_size:,} bytes / SHA-256 OK")
                bytes_sum += actual_size
            if bytes_sum != int(manifest["bytes"]):
                raise RuntimeError("Tong dung luong khong khop manifest")
            if model_cfg.get("name") != manifest.get("name") or model_cfg.get("version") != manifest.get("version"):
                raise RuntimeError("Manifest va orpheus.json khong khop phien ban")
            log(f"[OK] Version={manifest['version']}; total={bytes_sum:,} bytes (~{bytes_sum/1_000_000:.2f} MB)")
            report["version"] = manifest["version"]
            report["bytes"] = bytes_sum
            report["tests"]["zip_and_sha256"] = "PASS"

        if args.only_check:
            log("[DONE] Da xong kiem tra tinh toan ven. Chua chay ONNX.")
            report["status"] = "ZIP_OK_INFERENCE_NOT_RUN"
            save()
            return 0

        try:
            import numpy as np
            import onnxruntime as ort
            from PIL import Image, ImageOps
        except ImportError as err:
            raise RuntimeError("Chua cai numpy, onnxruntime, pillow. Hay chay qua file .ps1. " + str(err)) from err

        log("ONNX Runtime: " + ort.__version__)
        options = ort.SessionOptions()
        options.intra_op_num_threads = min(4, max(os.cpu_count() or 2, 1))
        options.inter_op_num_threads = 1
        sessions = {}
        for name in ("layout", "encoder", "decoder"):
            path = models_dir / (name + ".onnx")
            t0 = time.perf_counter()
            sess = ort.InferenceSession(str(path), sess_options=options, providers=["CPUExecutionProvider"])
            dt = (time.perf_counter() - t0) * 1000
            sessions[name] = sess
            input_meta = [{"name": i.name, "type": i.type, "shape": shape_json(i.shape)} for i in sess.get_inputs()]
            output_meta = [{"name": o.name, "type": o.type, "shape": shape_json(o.shape)} for o in sess.get_outputs()]
            report["tests"][name + "_load"] = {"status": "PASS", "ms": round(dt, 1), "inputs": input_meta, "outputs": output_meta}
            log(f"[OK] Loaded {name}.onnx in {dt:.0f} ms")
            for d in input_meta:
                log("     input: " + json.dumps(d, ensure_ascii=False))
            for d in output_meta:
                log("     output: " + json.dumps(d, ensure_ascii=False))

        # This is intentionally NOT an accurate replica of proprietary preprocessing.
        if args.image_path is not None:
            if not args.image_path.is_file():
                raise RuntimeError("Khong tim thay anh: " + str(args.image_path))
            img = Image.open(args.image_path).convert("L")
            log(f"Anh dau vao: {args.image_path.name} ({img.width} x {img.height})")
            report["image"] = str(args.image_path.resolve())
        else:
            # Synthetic staff-like image tests computational execution, not recognition.
            img = Image.new("L", (512, 384), 255)
            from PIL import ImageDraw
            d = ImageDraw.Draw(img)
            for y in (90, 106, 122, 138, 154):
                d.line((40, y, 475, y), fill=0, width=2)
            log("Khong co anh: dung hinh khuong nhac gia de thu ky thuat. KHONG danh gia do chinh xac OMR.")

        # Scale into a <=768px canvas for the layout smoke test. Keep aspect ratio and pad to 16.
        img_layout = img.copy()
        target_long = 768
        scale = target_long / max(img.width, img.height)
        if abs(scale - 1) > 1e-6:
            newsize = (max(16, int(round(img.width * scale))), max(16, int(round(img.height * scale))))
            img_layout = img.resize(newsize, Image.Resampling.BILINEAR)
        w = ((img_layout.width + 15) // 16) * 16
        h = ((img_layout.height + 15) // 16) * 16
        canvas = Image.new("L", (w, h), 255)
        canvas.paste(img_layout, (0, 0))
        page = np.asarray(canvas, dtype=np.float32)[None, None, :, :] / 255.0
        t0 = time.perf_counter()
        classes = sessions["layout"].run(None, {"page": page})[0]
        elapsed = (time.perf_counter() - t0) * 1000
        labels = np.asarray(classes[0], dtype=np.int64)
        if labels.ndim != 2:
            raise RuntimeError("Output layout bat thuong: " + str(classes.shape))
        uniq, count = np.unique(labels, return_counts=True)
        overview = {str(int(k)): int(v) for k, v in zip(uniq, count)}
        report["tests"]["layout_inference"] = {"status": "PASS", "ms": round(elapsed, 1), "output_shape": list(classes.shape), "class_pixel_counts": overview}
        log(f"[OK] layout inference: {elapsed:.0f} ms, output {list(classes.shape)}, classes {overview}")
        palette = np.asarray([[255, 255, 255], [237, 94, 86], [54, 141, 218], [241, 193, 50], [63, 185, 143], [164, 117, 211], [95, 95, 95]], dtype=np.uint8)
        colored = palette[np.mod(labels, len(palette))]
        Image.fromarray(colored, "RGB").save(args.out_dir / "layout_classes.png")
        grayscale = np.asarray(canvas.resize((labels.shape[1], labels.shape[0])), dtype=np.uint8)
        blend = (0.6 * np.repeat(grayscale[:, :, None], 3, axis=2) + 0.4 * colored).astype(np.uint8)
        Image.fromarray(blend, "RGB").save(args.out_dir / "layout_overlay.png")

        # Encoder smoke test: fit a whole image inside a 320xW crop, not a true detected staff strip.
        strip_canvas = Image.new("L", (args.width, 320), 255)
        fit_img = ImageOps.contain(img, (args.width, 320), method=Image.Resampling.BILINEAR)
        strip_canvas.paste(fit_img, ((args.width - fit_img.width)//2, (320 - fit_img.height)//2))
        strip = np.asarray(strip_canvas, dtype=np.float32)[None, None, :, :] / 255.0
        t0 = time.perf_counter()
        cross = sessions["encoder"].run(None, {"strip": strip})[0]
        elapsed = (time.perf_counter() - t0) * 1000
        report["tests"]["encoder_inference"] = {"status": "PASS", "ms": round(elapsed, 1), "output_shape": list(cross.shape), "finite": bool(np.isfinite(cross).all())}
        log(f"[OK] encoder inference: {elapsed:.0f} ms, cross shape {list(cross.shape)}")
        if not np.isfinite(cross).all():
            raise RuntimeError("Encoder co NaN hoac Inf")

        # Decoder single-step smoke test only, using a dummy token ID (not necessarily BOS).
        selfk = np.zeros((6, 1, 8, 512, 32), dtype=np.float32)
        selfv = np.zeros_like(selfk)
        mask = np.zeros((1, 1, 1, 512), dtype=np.float32)
        input_decoder = {
            "token": np.asarray([[0]], dtype=np.int32),
            "step": np.asarray([0], dtype=np.int32),
            "selfK": selfk,
            "selfV": selfv,
            "cross": np.asarray(cross, dtype=np.float32),
            "mask": mask,
        }
        t0 = time.perf_counter()
        decoded = sessions["decoder"].run(None, input_decoder)
        elapsed = (time.perf_counter() - t0) * 1000
        sizes = [list(x.shape) for x in decoded]
        is_finite = all(bool(np.isfinite(x).all()) for x in decoded)
        report["tests"]["decoder_one_step"] = {"status": "PASS" if is_finite else "FAIL", "ms": round(elapsed, 1), "shapes": sizes, "finite": is_finite}
        log(f"[OK] decoder 1 buoc: {elapsed:.0f} ms, outputs={sizes}, finite={is_finite}")
        if not is_finite:
            raise RuntimeError("Decoder co NaN hoac Inf")

        log("---")
        log("DA CHAY THANH CONG 3 MO HINH ONNX tren CPU.")
        log("CHUA CHUNG MINH doc dung not, nhip hoac xuat MusicXML.")
        log("Tien xu ly va token hien la gia dinh de smoke test, khong phai pipeline EZMusic.")
        log("Xem hinh layout_classes.png va layout_overlay.png trong thu muc ket qua.")
        report["status"] = "ONNX_SMOKE_TEST_PASS_NOT_OMR_VALIDATED"
        save()
        return 0
    except Exception as exc:
        log("[ERROR] " + type(exc).__name__ + ": " + str(exc))
        report["status"] = "FAILED"
        report["error"] = type(exc).__name__ + ": " + str(exc)
        save()
        return 1


if __name__ == "__main__":
    sys.exit(main())
