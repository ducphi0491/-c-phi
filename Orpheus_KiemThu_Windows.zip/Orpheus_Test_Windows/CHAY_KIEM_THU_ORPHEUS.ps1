param(
    [string]$ZipFile = "",
    [string]$ImageFile = "",
    [ValidateSet(512, 768, 1024, 1280, 1664)]
    [int]$Width = 512,
    [switch]$CheckOnly
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$testScript = Join-Path $scriptDir "kiem_thu_orpheus.py"

if (-not (Test-Path -LiteralPath $testScript -PathType Leaf)) {
    throw "Khong tim thay kiem_thu_orpheus.py. Giai nen day du bo cong cu vao cung thu muc."
}

if ([string]::IsNullOrWhiteSpace($ZipFile)) {
    $candidate1 = Join-Path $scriptDir "orpheus-android-1-2026-10-27.zip"
    $candidate2 = Join-Path (Split-Path -Parent $scriptDir) "orpheus-android-1-2026-10-27.zip"
    if (Test-Path -LiteralPath $candidate1) {
        $ZipFile = $candidate1
    } elseif (Test-Path -LiteralPath $candidate2) {
        $ZipFile = $candidate2
    } else {
        throw "Khong tim thay ZIP. Hay chi dinh -ZipFile 'C:\DuongDan\orpheus-android-1-2026-10-27.zip'"
    }
}
$ZipFile = (Resolve-Path -LiteralPath $ZipFile).Path
$venv = Join-Path $scriptDir ".venv"
$python = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    $pyLauncher = Get-Command py -ErrorAction SilentlyContinue
    $pyExe = Get-Command python -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        & py -3 -m venv $venv
    } elseif ($pyExe) {
        & python -m venv $venv
    } else {
        throw "Chua cai Python. Cai Python 3.11/3.12 (64-bit) tu python.org, sau do chay lai."
    }
    if ($LASTEXITCODE -ne 0) { throw "Khong tao duoc Python virtual environment." }
}

if (-not $CheckOnly) {
    Write-Host "Dang kiem tra onnxruntime, numpy, pillow ..."
    & $python -c "import numpy, PIL, onnxruntime" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Cai cac goi can thiet vao virtual environment (chi lan dau) ..."
        & $python -m pip install --disable-pip-version-check --only-binary=:all: numpy pillow onnxruntime
        if ($LASTEXITCODE -ne 0) { throw "Khong cai duoc thu vien Python. Hay kiem tra Internet/Python 64-bit." }
    }
}

$toolArgs = @($testScript, "--zip", $ZipFile, "--out", (Join-Path $scriptDir "KET_QUA_KIEM_THU"), "--width", [string]$Width)
if (-not [string]::IsNullOrWhiteSpace($ImageFile)) {
    $ImageFile = (Resolve-Path -LiteralPath $ImageFile).Path
    $toolArgs += @("--image", $ImageFile)
}
if ($CheckOnly) { $toolArgs += "--only-check" }

& $python @toolArgs
if ($LASTEXITCODE -ne 0) { throw "Kiem thu that bai. Xem KET_QUA_KIEM_THU\ket_qua.txt" }
Write-Host "HOAN TAT. Xem KET_QUA_KIEM_THU\ket_qua.txt"
