@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package duc_phi.music

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.session.MediaSession
import android.media.MediaMetadata
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
// region Merged source: MeloWavePlaybackService.kt
/**
 * One MusicController for the UI and the music service. In particular, disposing the
 * Compose screen must NOT release its ExoPlayer while music is playing in the background.
 * All methods are called on the Android main thread.
 */
internal object MeloWavePlaybackRuntime {
    private var sharedController: MusicController? = null
    private var activityReferences = 0
    private var service: MeloWavePlaybackService? = null
    private var serviceStartRequested = false

    fun obtain(context: Context): MusicController = sharedController ?: MusicController(context.applicationContext)
        .also { sharedController = it }

    fun attachActivity() { activityReferences++ }

    fun detachActivity() {
        activityReferences = (activityReferences - 1).coerceAtLeast(0)
        releaseIfUnused()
    }

    fun attachService(instance: MeloWavePlaybackService) {
        service = instance
        serviceStartRequested = false
    }

    fun detachService(instance: MeloWavePlaybackService) {
        if (service === instance) service = null
        serviceStartRequested = false
        releaseIfUnused()
    }

    private fun releaseIfUnused() {
        if (activityReferences == 0 && service == null && !serviceStartRequested) {
            sharedController?.release()
            sharedController = null
        }
    }

    fun onPlaybackChanged() { service?.refreshPlayback() }
    fun onSeekChanged() { service?.refreshSeekPosition() }

    fun ensureService(context: Context) {
        service?.let { it.refreshPlayback(); return }
        if (serviceStartRequested) return
        serviceStartRequested = true
        try {
            ContextCompat.startForegroundService(
                context.applicationContext,
                Intent(context.applicationContext, MeloWavePlaybackService::class.java)
                    .setAction(MeloWavePlaybackService.ACTION_ACTIVATE)
            )
        } catch (error: Exception) {
            serviceStartRequested = false
            Log.w("MeloWavePlayback", "Unable to start media playback service", error)
        }
    }
}

/**
 * Real Android MediaSession + media-style notification for lock screen, Bluetooth
 * headset keys and Android system media controls. Owns the controller reference
 * while playback is active, even after MainActivity is destroyed.
 */
class MeloWavePlaybackService : Service() {
    companion object {
        const val ACTION_ACTIVATE = "duc_phi.music.PLAYBACK_ACTIVATE"
        private const val ACTION_PLAY_PAUSE = "duc_phi.music.PLAYBACK_PLAY_PAUSE"
        private const val ACTION_NEXT = "duc_phi.music.PLAYBACK_NEXT"
        private const val ACTION_PREVIOUS = "duc_phi.music.PLAYBACK_PREVIOUS"
        private const val ACTION_STOP = "duc_phi.music.PLAYBACK_STOP"
        private const val CHANNEL_ID = "melowave_media_playback"
        private const val NOTIFICATION_ID = 19421
    }

    private lateinit var controller: MusicController
    private lateinit var mediaSession: MediaSession
    private lateinit var notifications: NotificationManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val artworkScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var artworkJob: Job? = null
    private var notificationStarted = false
    private var currentArtKey: String? = null
    private var currentArt: Bitmap? = null
    private var currentMetadataSongId: String? = null
    private var currentMetadataDuration: Long = -1L
    private var lastStateId: String? = null
    private var lastPlaying = false
    private var lastLoading = false
    private var lastPlaybackState = -1
    private var seekUpdatePending = false

    private val ticker = object : Runnable {
        override fun run() {
            refreshPlayback()
            mainHandler.postDelayed(this, 1500L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        notifications = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createMediaNotificationChannel()
        controller = MeloWavePlaybackRuntime.obtain(applicationContext)
        val musicController = this.controller // Service controller, not MediaSession.controller.
        mediaSession = MediaSession(this, "MeloWave").apply {
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    if (!musicController.player.isPlaying &&
                        !(musicController.isLoading && musicController.player.playWhenReady)) {
                        musicController.togglePlayback()
                    }
                    refreshPlayback()
                }
                override fun onPause() {
                    musicController.pauseForSystemMediaControls()
                    refreshPlayback()
                }
                override fun onSkipToNext() { musicController.next(); refreshPlayback() }
                override fun onSkipToPrevious() { musicController.previous(); refreshPlayback() }
                override fun onSeekTo(pos: Long) { musicController.seekTo(pos); refreshPlayback() }
                override fun onStop() {
                    musicController.pauseForSystemMediaControls()
                    stopForegroundAndNotification()
                    stopSelf()
                }
            }, mainHandler)
            isActive = true
        }
        MeloWavePlaybackRuntime.attachService(this)
        mainHandler.post(ticker)
    }

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> {
                if (controller.player.playWhenReady) controller.pauseForSystemMediaControls()
                else controller.togglePlayback()
            }
            ACTION_NEXT -> controller.next()
            ACTION_PREVIOUS -> controller.previous()
            ACTION_STOP -> {
                controller.pauseForSystemMediaControls()
                stopForegroundAndNotification()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        refreshPlayback()
        if (controller.currentSong == null) stopSelf()
        return START_NOT_STICKY
    }

    /** Called when the controller changes song, playback state or ExoPlayer instance. */
    internal fun refreshSeekPosition() {
        seekUpdatePending = true
        refreshPlayback()
    }

    internal fun refreshPlayback() {
        if (!::mediaSession.isInitialized) return
        val song = controller.currentSong
        if (song == null || controller.castConnected ||
            song.source == SongSource.MOVIE || song.source == SongSource.INTERNET_P2P) {
            if (notificationStarted) {
                stopForegroundAndNotification()
                stopSelf()
            }
            return
        }

        val artworkUrl = controller.artworkFor(song)
        val artKey = "${song.id}|${artworkUrl.orEmpty()}"
        if (artKey != currentArtKey) {
            currentArtKey = artKey
            currentArt = null
            artworkJob?.cancel()
            artworkJob = artworkScope.launch {
                val bitmap = readAlbumArt(song, artworkUrl)
                withContext(Dispatchers.Main) {
                    if (currentArtKey == artKey) {
                        currentArt = bitmap
                        updateSessionMetadata()
                        if (notificationStarted) notifications.notify(NOTIFICATION_ID, makeNotification())
                    }
                }
            }
        }
        val duration = effectiveDuration()
        if (song.id != currentMetadataSongId || duration != currentMetadataDuration) {
            updateSessionMetadata()
        }

        val isPlaying = controller.player.isPlaying
        val buffering = controller.isLoading
        val state = controller.player.playbackState
        // SystemUI advances the seek bar from PlaybackState speed/position.
        // Republish only on a state change or explicit seek, never every 2 seconds.
        if (song.id != lastStateId || isPlaying != lastPlaying || buffering != lastLoading ||
            state != lastPlaybackState || seekUpdatePending) {
            lastStateId = song.id
            lastPlaying = isPlaying
            lastLoading = buffering
            lastPlaybackState = state
            seekUpdatePending = false
            updateSessionState()
            val notification = makeNotification()
            if (!notificationStarted) {
                try {
                    val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
                    ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)
                    notificationStarted = true
                } catch (error: Exception) {
                    Log.e("MeloWavePlayback", "Media notification/foreground service failed", error)
                    stopSelf()
                }
            } else {
                notifications.notify(NOTIFICATION_ID, notification)
            }
        }
    }

    private fun effectiveDuration(): Long {
        val playerDuration = controller.player.duration
        return when {
            playerDuration > 0 && playerDuration < Long.MAX_VALUE / 2 -> playerDuration
            controller.durationMs > 1L -> controller.durationMs
            else -> controller.currentSong?.durationMs ?: 0L
        }.coerceAtLeast(0L)
    }

    private fun updateSessionMetadata() {
        val song = controller.currentSong ?: return
        currentMetadataSongId = song.id
        currentMetadataDuration = effectiveDuration()
        val metadata = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, song.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, song.artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, song.album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, currentMetadataDuration)
            .apply {
                currentArt?.let { artwork ->
                    // One bitmap only: media-session metadata travels across Binder.
                    putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artwork)
                }
            }.build()
        mediaSession.setMetadata(metadata)
    }

    private fun updateSessionState() {
        val state = when {
            controller.isLoading -> PlaybackState.STATE_BUFFERING
            controller.player.isPlaying -> PlaybackState.STATE_PLAYING
            controller.player.playbackState == androidx.media3.common.Player.STATE_ENDED -> PlaybackState.STATE_STOPPED
            else -> PlaybackState.STATE_PAUSED
        }
        val canSeek = effectiveDuration() > 0L
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
                PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP or
                (if (canSeek) PlaybackState.ACTION_SEEK_TO else 0L)
        mediaSession.setPlaybackState(PlaybackState.Builder()
            .setActions(actions)
            .setState(state, controller.player.currentPosition.coerceAtLeast(0L),
                if (state == PlaybackState.STATE_PLAYING) 1f else 0f,
                SystemClock.elapsedRealtime())
            .build())
    }

    private fun makeNotification(): Notification {
        val song = controller.currentSong
        val paused = !controller.player.isPlaying
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(this, 101, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val style = Notification.MediaStyle()
            .setMediaSession(mediaSession.sessionToken)
            .setShowActionsInCompactView(0, 1, 2)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(song?.title ?: "MeloWave")
            .setContentText(song?.artist?.ifBlank { "MeloWave" } ?: "MeloWave")
            .setSubText("MeloWave")
            .setContentIntent(contentIntent)
            .setLargeIcon(currentArt)
            .setStyle(style)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(!paused)
            .addAction(android.R.drawable.ic_media_previous, "Bài trước", actionIntent(ACTION_PREVIOUS, 102))
            .addAction(if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause,
                if (paused) "Phát" else "Tạm dừng", actionIntent(ACTION_PLAY_PAUSE, 103))
            .addAction(android.R.drawable.ic_media_next, "Bài tiếp", actionIntent(ACTION_NEXT, 104))
            .build()
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(this, requestCode,
            Intent(this, MeloWavePlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun createMediaNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            notifications.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "MeloWave · Điều khiển nhạc",
                    NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Phát nhạc và điều khiển trên màn hình khóa"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun stopForegroundAndNotification() {
        if (notificationStarted) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            notificationStarted = false
        }
        notifications.cancel(NOTIFICATION_ID)
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(ticker)
        artworkJob?.cancel()
        artworkScope.cancel()
        stopForegroundAndNotification()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        MeloWavePlaybackRuntime.detachService(this)
        super.onDestroy()
    }

    private fun readAlbumArt(song: SongItem, artworkUrl: String?): Bitmap? = runCatching {
        val artUri = artworkUrl?.takeIf { it.isNotBlank() }?.let(Uri::parse)
        val bytes = if (artUri != null) readArtworkBytes(artUri) else null
        val decodedBytes = bytes ?: if (song.source in setOf(
                SongSource.LOCAL_MEDIASTORE, SongSource.DOWNLOADED, SongSource.APP_RESOURCE)) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, song.uri)
                retriever.embeddedPicture
            } finally { retriever.release() }
        } else null
        decodedBytes?.let { bytesToSmallBitmap(it) }
    }.onFailure { Log.d("MeloWavePlayback", "Album cover not available: ${it.message}") }.getOrNull()

    private fun readArtworkBytes(uri: Uri): ByteArray? {
        return when (uri.scheme?.lowercase()) {
            "content", "file", "android.resource" ->
                contentResolver.openInputStream(uri)?.use { input ->
                    input.readNBytesCompat(4_000_001).takeIf { it.size <= 4_000_000 }
                }
            "http", "https" -> {
                val connection = (URL(uri.toString()).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 3500
                    instanceFollowRedirects = true
                }
                try {
                    if (connection.responseCode !in 200..299 || connection.contentLengthLong > 4_000_000L)
                        null
                    else connection.inputStream.use { input ->
                        val bytes = input.readNBytesCompat(4_000_001)
                        bytes.takeIf { it.size <= 4_000_000 }
                    }
                } finally { connection.disconnect() }
            }
            else -> null
        }
    }

    private fun java.io.InputStream.readNBytesCompat(maxBytes: Int): ByteArray {
        val result = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (result.size() < maxBytes) {
            val count = read(buffer, 0, minOf(buffer.size, maxBytes - result.size()))
            if (count < 0) break
            result.write(buffer, 0, count)
        }
        return result.toByteArray()
    }

    private fun bytesToSmallBitmap(bytes: ByteArray): Bitmap? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        val longest = maxOf(options.outWidth, options.outHeight)
        if (longest <= 0) return null
        var sample = 1
        while (longest / sample > 512) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
            BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val maxDimension = maxOf(decoded.width, decoded.height)
        if (maxDimension <= 320) return decoded
        val width = (decoded.width * 320f / maxDimension).toInt().coerceAtLeast(1)
        val height = (decoded.height * 320f / maxDimension).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(decoded, width, height, true)
        if (scaled !== decoded) decoded.recycle()
        return scaled
    }
}
// endregion Merged source: MeloWavePlaybackService.kt

// region Merged source: MeloWaveAudioDsp.kt
/** Shared, lock-free controls read from ExoPlayer's audio thread. */
internal class MeloWaveDspSettings(
    normalizationEnabled: Boolean = false,
    targetLufs: Float = -14f,
    limiterEnabled: Boolean = true,
    limiterCeilingDb: Float = -1f,
) {
    @Volatile var normalizationEnabled: Boolean = normalizationEnabled
    @Volatile var targetLufs: Float = targetLufs
    @Volatile var limiterEnabled: Boolean = limiterEnabled
    @Volatile var limiterCeilingDb: Float = limiterCeilingDb
    @Volatile var maxNormalizationBoostDb: Float = 8f
}

internal data class MeloWaveDspSnapshot(
    val active: Boolean = false,
    val momentaryLufs: Float = -70f,
    val integratedLufs: Float = -70f,
    val normalizationGainDb: Float = 0f,
    val inputPeakDbfs: Float = -90f,
    val limiterReductionDb: Float = 0f,
)

internal class MeloWaveDspMetrics {
    @Volatile private var active = false
    @Volatile private var momentaryLufs = -70f
    @Volatile private var integratedLufs = -70f
    @Volatile private var normalizationGainDb = 0f
    @Volatile private var inputPeakDbfs = -90f
    @Volatile private var limiterReductionDb = 0f

    internal fun update(
        active: Boolean,
        momentaryLufs: Float,
        integratedLufs: Float,
        normalizationGainDb: Float,
        inputPeakDbfs: Float,
        limiterReductionDb: Float,
    ) {
        this.active = active
        this.momentaryLufs = momentaryLufs
        this.integratedLufs = integratedLufs
        this.normalizationGainDb = normalizationGainDb
        this.inputPeakDbfs = inputPeakDbfs
        this.limiterReductionDb = limiterReductionDb
    }

    internal fun reset() = update(false, -70f, -70f, 0f, -90f, 0f)

    fun snapshot(): MeloWaveDspSnapshot = MeloWaveDspSnapshot(
        active = active,
        momentaryLufs = momentaryLufs,
        integratedLufs = integratedLufs,
        normalizationGainDb = normalizationGainDb,
        inputPeakDbfs = inputPeakDbfs,
        limiterReductionDb = limiterReductionDb,
    )
}

/** One DSP chain belongs to exactly one ExoPlayer/AudioSink. */
internal class MeloWaveAudioDspChain(
    context: Context,
    settings: MeloWaveDspSettings,
) {
    val metrics = MeloWaveDspMetrics()
    private val processor = MeloWaveR128LimiterProcessor(settings, metrics)

    val renderersFactory = object : DefaultRenderersFactory(context) {
        override fun buildAudioSink(
            context: Context,
            enableFloatOutput: Boolean,
            enableAudioTrackPlaybackParams: Boolean,
        ): AudioSink = DefaultAudioSink.Builder(context)
            // User AudioProcessors are fed 16-bit PCM by DefaultAudioSink.
            .setEnableFloatOutput(false)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(arrayOf<AudioProcessor>(processor))
            .build()
    }
}

/**
 * Real-time BS.1770/R128-style loudness measurement + smooth normalization and a look-ahead
 * dynamic peak limiter. The processor receives 16-bit PCM after Media3's ToInt16 processor.
 */
private class MeloWaveR128LimiterProcessor(
    private val settings: MeloWaveDspSettings,
    private val metrics: MeloWaveDspMetrics,
) : BaseAudioProcessor() {
    private var sampleRate = 48_000
    private var channelCount = 2
    private var filters: Array<KWeightingFilter> = emptyArray()

    private var stepFrames = 4_800
    private var stepFrameCount = 0
    private var stepEnergy = 0.0
    private val recentStepEnergies = ArrayDeque<Double>()
    private val gatedBlockEnergies = ArrayDeque<Double>()
    private var momentaryLufs = -70f
    private var integratedLufs = -70f

    private var targetNormalizationGainDb = 0f
    private var currentNormalizationGainDb = 0f
    private var normalizationGainLinear = 1f

    private var lookAheadFrames = 384
    private var ringCapacity = 385
    private var delayedSamples = FloatArray(ringCapacity * channelCount)
    private var delayedPeaks = FloatArray(ringCapacity)
    private var delayedSequence = LongArray(ringCapacity)
    private var writeFrame = 0
    private var readFrame = 0
    private var delayedFrameCount = 0
    private var sequenceCounter = 0L
    private data class PeakPoint(val sequence: Long, val peak: Float)
    private val peakDeque = ArrayDeque<PeakPoint>()

    private var limiterGain = 1f
    private var inputPeak = 0f
    private var lastPublishedFrames = 0L
    private var processedFrames = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount <= 0) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun onFlush() {
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8_000)
        channelCount = inputAudioFormat.channelCount.coerceAtLeast(1)
        filters = Array(channelCount) { KWeightingFilter(sampleRate.toDouble()) }
        stepFrames = max(1, sampleRate / 10)
        lookAheadFrames = max(1, (sampleRate * 0.008).toInt())
        ringCapacity = lookAheadFrames + 1
        delayedSamples = FloatArray(ringCapacity * channelCount)
        delayedPeaks = FloatArray(ringCapacity)
        delayedSequence = LongArray(ringCapacity)
        resetStreamState()
    }

    override fun onReset() {
        filters = emptyArray()
        resetStreamState()
    }

    private fun resetStreamState() {
        filters.forEach { it.reset() }
        stepFrameCount = 0
        stepEnergy = 0.0
        recentStepEnergies.clear()
        gatedBlockEnergies.clear()
        momentaryLufs = -70f
        integratedLufs = -70f
        targetNormalizationGainDb = 0f
        currentNormalizationGainDb = 0f
        normalizationGainLinear = 1f
        writeFrame = 0
        readFrame = 0
        delayedFrameCount = 0
        sequenceCounter = 0L
        peakDeque.clear()
        limiterGain = 1f
        inputPeak = 0f
        lastPublishedFrames = 0L
        processedFrames = 0L
        metrics.reset()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return
        inputBuffer.order(ByteOrder.nativeOrder())
        val bytesPerFrame = channelCount * 2
        val inputFrames = inputBuffer.remaining() / bytesPerFrame
        if (inputFrames <= 0) return
        val maxOutputFrames = inputFrames
        val output = replaceOutputBuffer(maxOutputFrames * bytesPerFrame)
        val frame = FloatArray(channelCount)
        repeat(inputFrames) {
            var framePeak = 0f
            var weightedEnergy = 0.0
            for (channel in 0 until channelCount) {
                val sample = inputBuffer.short / 32768f
                frame[channel] = sample
                framePeak = max(framePeak, kotlin.math.abs(sample))
                val weighted = filters[channel].process(sample.toDouble())
                val channelWeight = when {
                    channelCount <= 3 -> 1.0
                    channel == 3 -> 0.0 // LFE is excluded by BS.1770.
                    channel >= 4 -> 1.41 // Surround/back channels.
                    else -> 1.0
                }
                weightedEnergy += weighted * weighted * channelWeight
            }
            updateLoudness(weightedEnergy)
            updateNormalizationGain()

            val preGainPeak = framePeak * normalizationGainLinear
            inputPeak = max(inputPeak * 0.9995f, preGainPeak)
            val sequence = sequenceCounter++
            val sampleOffset = writeFrame * channelCount
            for (channel in 0 until channelCount) {
                delayedSamples[sampleOffset + channel] = frame[channel] * normalizationGainLinear
            }
            delayedPeaks[writeFrame] = preGainPeak
            delayedSequence[writeFrame] = sequence
            while (peakDeque.isNotEmpty() && peakDeque.last().peak <= preGainPeak) peakDeque.removeLast()
            peakDeque.addLast(PeakPoint(sequence, preGainPeak))
            writeFrame = (writeFrame + 1) % ringCapacity
            delayedFrameCount++

            if (delayedFrameCount > lookAheadFrames) {
                writeDelayedFrame(output)
            }
            processedFrames++
            maybePublishMetrics()
        }
        output.flip()
    }

    override fun onQueueEndOfStream() {
        if (delayedFrameCount <= 0) return
        val output = replaceOutputBuffer(delayedFrameCount * channelCount * 2)
        while (delayedFrameCount > 0) writeDelayedFrame(output)
        output.flip()
        maybePublishMetrics(force = true)
    }

    private fun writeDelayedFrame(output: ByteBuffer) {
        val maxPeak = peakDeque.firstOrNull()?.peak ?: delayedPeaks[readFrame]
        val ceilingLinear = 10.0.pow(settings.limiterCeilingDb.coerceIn(-6f, -0.1f) / 20.0).toFloat()
        val targetGain = if (settings.limiterEnabled && maxPeak > ceilingLinear && maxPeak > 0f) {
            (ceilingLinear / maxPeak).coerceIn(0.05f, 1f)
        } else 1f
        val attackSeconds = 0.002f
        val releaseSeconds = 0.080f
        val time = if (targetGain < limiterGain) attackSeconds else releaseSeconds
        val coefficient = exp(-1.0 / max(1.0, sampleRate.toDouble() * time.toDouble())).toFloat()
        limiterGain = targetGain + (limiterGain - targetGain) * coefficient
        if (targetGain < limiterGain && maxPeak * limiterGain > ceilingLinear) {
            // Look-ahead normally makes the envelope reach the target in time; this final clamp
            // guarantees that no sample exceeds the selected ceiling.
            limiterGain = min(limiterGain, ceilingLinear / max(maxPeak, 1e-9f))
        }

        val offset = readFrame * channelCount
        for (channel in 0 until channelCount) {
            val value = (delayedSamples[offset + channel] * limiterGain).coerceIn(-1f, 0.999969f)
            output.putShort((value * 32767f).toInt().toShort())
        }
        val outputSequence = delayedSequence[readFrame]
        if (peakDeque.isNotEmpty() && peakDeque.first().sequence <= outputSequence) peakDeque.removeFirst()
        readFrame = (readFrame + 1) % ringCapacity
        delayedFrameCount--
    }

    private fun updateLoudness(frameEnergy: Double) {
        stepEnergy += frameEnergy
        stepFrameCount++
        if (stepFrameCount < stepFrames) return
        val averageStepEnergy = stepEnergy / stepFrameCount.toDouble()
        recentStepEnergies.addLast(averageStepEnergy)
        while (recentStepEnergies.size > 4) recentStepEnergies.removeFirst()
        if (recentStepEnergies.size == 4) {
            val blockEnergy = recentStepEnergies.sum() / 4.0
            val blockLufs = energyToLufs(blockEnergy)
            momentaryLufs = blockLufs
            if (blockLufs > -70f) {
                gatedBlockEnergies.addLast(blockEnergy)
                if (gatedBlockEnergies.size > 18_000) gatedBlockEnergies.removeFirst()
                integratedLufs = calculateIntegratedLufs()
                if (gatedBlockEnergies.size >= 10 && settings.normalizationEnabled) {
                    targetNormalizationGainDb = (settings.targetLufs.coerceIn(-23f, -9f) - integratedLufs)
                        .coerceIn(-12f, settings.maxNormalizationBoostDb.coerceIn(0f, 12f))
                } else if (!settings.normalizationEnabled) {
                    targetNormalizationGainDb = 0f
                }
            }
        }
        stepEnergy = 0.0
        stepFrameCount = 0
    }

    private fun calculateIntegratedLufs(): Float {
        if (gatedBlockEnergies.isEmpty()) return -70f
        val absolute = gatedBlockEnergies.filter { energyToLufs(it) > -70f }
        if (absolute.isEmpty()) return -70f
        val ungatedMean = absolute.average()
        val relativeGate = energyToLufs(ungatedMean) - 10f
        val finalGate = max(-70f, relativeGate)
        val relative = absolute.filter { energyToLufs(it) > finalGate }
        return energyToLufs(if (relative.isEmpty()) ungatedMean else relative.average())
    }

    private fun updateNormalizationGain() {
        if (!settings.normalizationEnabled) targetNormalizationGainDb = 0f
        val target = targetNormalizationGainDb
        val timeSeconds = if (target < currentNormalizationGainDb) 0.35f else 2.5f
        val coefficient = exp(-1.0 / max(1.0, sampleRate.toDouble() * timeSeconds.toDouble())).toFloat()
        currentNormalizationGainDb = target + (currentNormalizationGainDb - target) * coefficient
        normalizationGainLinear = 10.0.pow(currentNormalizationGainDb / 20.0).toFloat()
    }

    private fun maybePublishMetrics(force: Boolean = false) {
        val interval = max(1, sampleRate / 4)
        if (!force && processedFrames - lastPublishedFrames < interval) return
        lastPublishedFrames = processedFrames
        val reductionDb = if (limiterGain >= 0.99999f) 0f else (-20f * log10(max(limiterGain, 1e-6f)))
        val peakDb = if (inputPeak <= 1e-9f) -90f else 20f * log10(inputPeak)
        metrics.update(
            active = true,
            momentaryLufs = momentaryLufs,
            integratedLufs = integratedLufs,
            normalizationGainDb = currentNormalizationGainDb,
            inputPeakDbfs = peakDb,
            limiterReductionDb = reductionDb,
        )
    }

    private fun energyToLufs(energy: Double): Float = if (energy <= 1e-12) -70f else {
        (-0.691 + 10.0 * log10(energy)).toFloat().coerceIn(-70f, 12f)
    }
}

private class KWeightingFilter(sampleRate: Double) {
    private val shelf = Biquad.highShelf(sampleRate, 1_681.974450955533, 3.999843853973347, 1.0)
    private val highPass = Biquad.highPass(sampleRate, 38.13547087602444, 0.5003270373238773)
    fun process(sample: Double): Double = highPass.process(shelf.process(sample))
    fun reset() { shelf.reset(); highPass.reset() }
}

private class Biquad(
    private val b0: Double,
    private val b1: Double,
    private val b2: Double,
    private val a1: Double,
    private val a2: Double,
) {
    private var z1 = 0.0
    private var z2 = 0.0
    fun process(input: Double): Double {
        val output = b0 * input + z1
        z1 = b1 * input - a1 * output + z2
        z2 = b2 * input - a2 * output
        return output
    }
    fun reset() { z1 = 0.0; z2 = 0.0 }

    companion object {
        fun highPass(sampleRate: Double, frequency: Double, q: Double): Biquad {
            val w0 = 2.0 * PI * frequency / sampleRate
            val c = cos(w0)
            val s = sin(w0)
            val alpha = s / (2.0 * q)
            val a0 = 1.0 + alpha
            return Biquad(
                b0 = ((1.0 + c) / 2.0) / a0,
                b1 = (-(1.0 + c)) / a0,
                b2 = ((1.0 + c) / 2.0) / a0,
                a1 = (-2.0 * c) / a0,
                a2 = (1.0 - alpha) / a0,
            )
        }

        fun highShelf(sampleRate: Double, frequency: Double, gainDb: Double, slope: Double): Biquad {
            val a = 10.0.pow(gainDb / 40.0)
            val w0 = 2.0 * PI * frequency / sampleRate
            val c = cos(w0)
            val s = sin(w0)
            val alpha = s / 2.0 * sqrt((a + 1.0 / a) * (1.0 / slope - 1.0) + 2.0)
            val beta = 2.0 * sqrt(a) * alpha
            val a0 = (a + 1.0) - (a - 1.0) * c + beta
            return Biquad(
                b0 = a * ((a + 1.0) + (a - 1.0) * c + beta) / a0,
                b1 = -2.0 * a * ((a - 1.0) + (a + 1.0) * c) / a0,
                b2 = a * ((a + 1.0) + (a - 1.0) * c - beta) / a0,
                a1 = 2.0 * ((a - 1.0) - (a + 1.0) * c) / a0,
                a2 = ((a + 1.0) - (a - 1.0) * c - beta) / a0,
            )
        }
    }
}
// endregion Merged source: MeloWaveAudioDsp.kt
