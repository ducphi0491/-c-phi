# MeloWare - Hướng dẫn 4 chế độ chia sẻ và đa ngôn ngữ

## File đã thay đổi

- `MainActivity.kt`
  - Giữ cơ chế kiểm tra cập nhật Google Play âm thầm, không hiện màn hình loading khi mở app.
  - Lần cài đầu: tự dùng ngôn ngữ thiết bị nếu có trong danh sách hỗ trợ.
  - Nếu ngôn ngữ thiết bị không được hỗ trợ: hiển thị hộp chọn ngôn ngữ bắt buộc.
  - Danh sách ngôn ngữ được đọc từ JSON.
- `MusicUiComponents.kt`
  - Thêm bộ đọc JSON đa ngôn ngữ, fallback an toàn.
  - Thêm icon Hướng dẫn và hộp thoại hướng dẫn từng bước dùng chung.
- `NowPlayingScreen.kt`
  - Thêm Hướng dẫn cho: Điện thoại - Điện thoại và Chia sẻ link.
  - Dịch menu 4 chế độ và các thao tác chính.
- `MeloWareLaptop.kt`
  - Thêm Hướng dẫn cho: Điện thoại - Máy tính.
  - Bỏ phần hướng dẫn dài luôn hiển thị; chỉ mở khi nhấn icon Hướng dẫn.
- `MeloWareInternet.kt`
  - Thêm Hướng dẫn cho: Kết nối qua Internet.
  - Dịch các thao tác ghép nối chính.
- `assets/meloware_languages.json`
  - Một file JSON duy nhất quản lý ngôn ngữ.
  - Có 15 ngôn ngữ: vi, en, zh, ja, ko, es, fr, de, ru, pt, id, hi, ar, th, it.

## Vị trí đặt file JSON trong Android Studio

Tạo thư mục nếu chưa có và chép file vào đúng đường dẫn:

```text
app/src/main/assets/meloware_languages.json
```

Không đặt JSON trong `res/drawable` hoặc `res/raw`.

## File Kotlin

Chép 5 file Kotlin vào cùng package hiện tại của dự án:

```text
app/src/main/java/duc_phi/music/
```

## Cách kiểm tra

1. Build và mở app trên thiết bị có ngôn ngữ thuộc danh sách hỗ trợ: app tự chọn ngôn ngữ máy.
2. Để thử hộp chọn ngôn ngữ lần đầu, xóa dữ liệu app hoặc gỡ và cài lại, sau đó đổi ngôn ngữ máy sang ngôn ngữ ngoài danh sách.
3. Mở menu `Kết nối & chia sẻ`.
4. Vào lần lượt 4 mục; ở góc trên có icon dấu hỏi.
5. Nhấn icon để xem hướng dẫn từng bước riêng cho đúng chế độ.
6. Vào `Cài đặt -> Ngôn ngữ` để đổi ngôn ngữ; menu chia sẻ và hướng dẫn đổi ngay, không cần khởi động lại.

## Phạm vi chuyển ngôn ngữ của bản này

Bộ máy JSON đã được tích hợp ở cấp ứng dụng. Bản này đã chuyển toàn bộ phần Cài đặt ngôn ngữ, menu 4 chế độ chia sẻ, các nút ghép nối chính và toàn bộ nội dung hướng dẫn mới. Những màn hình cũ còn dùng chuỗi viết trực tiếp trong Kotlin sẽ tiếp tục hiện tiếng Việt cho đến khi được chuyển thêm key vào JSON.

## Không thay đổi

- Không sửa `build.gradle.kts`.
- Không thêm thư viện.
- Không sửa Firebase Rules.
- Không thay đổi logic phát nhạc, WebRTC, LAN, Google Drive, Cast hoặc quảng cáo.
