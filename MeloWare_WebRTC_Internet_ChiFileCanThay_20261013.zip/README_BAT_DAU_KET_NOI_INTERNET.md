# MeloWare - WebRTC P2P giai doan 1

Muc tieu: 2 dien thoai o 2 mang khac nhau tao phong, may A chap nhan,
va trao doi HELLO qua WebRTC DataChannel. Chua truyen nhac.

## Files

- `meloware2/build.gradle.kts` (sua): bo sung Firebase Authentication va
  WebRTC prefixed-stripped; giu tat ca dependency da dung va In-App Update.
- `meloware2/NowPlayingScreen.kt` (sua): giu 3 menu LAN; bo sung menu thu 4.
- `meloware2/MeloWareInternet.kt` (them moi, chi 1 file .kt): Firebase
  ghép noi + WebRTC DataChannel + man hinh thu nghiem.
- `meloware2/MainActivity.kt` (ban moi nhat user gui, giu nguyen)
- 6 file project con lai giu nguyen so voi `meloware2.zip`.
- `FIREBASE_RULES_CHI_THEM_NHANH.txt`: fragment rules can merge, KHONG
  duoc paste de thay the toan bo Rules hien co.

## B1 - Firebase Console

1. Mo https://console.firebase.google.com, chon dung project MeloWare.
2. Authentication -> Sign-in method -> Enable Anonymous -> Save.
3. Realtime Database -> Rules: backup Rules goc, them ONLY
   "meloware_internet_rooms" tu file rules vao ben trong "rules".
   Giu nguyen nhanh "usage_stats" va tat ca policy hien co.
4. Neu chua chac ve vi tri chen, gui noi dung Firebase Rules hien tai
   cho ChatGPT de duoc huong dan merge; KHONG bat `.read`/`.write`: true.

## B2 - Android Studio

1. Thay dung `app/build.gradle.kts` moi.
2. Thay `NowPlayingScreen.kt` moi.
3. Them `MeloWareInternet.kt` cung package `duc_phi.music` va duong dan
   Java/Kotlin nhu cac file .kt hien tai.
4. KHONG thay MainActivity cu neu ban da dung ban bat buoc cap nhat moi nhat.
5. Sync Gradle; xac nhan Maven Central co trong `settings.gradle.kts`.
6. Build/Run tren 2 dien thoai.

## B3 - Kiem thu (khong can chung Wi-Fi)

1. May A: MeloWare -> man nghe nhac -> Wi-Fi -> `4. Ket noi qua Internet`.
   Bam `May A - Tao ma ket noi`, sao chep ma 16 ky tu.
2. May B: dung 4G/5G hoac Wi-Fi khac -> mo cung menu -> nhap ma ->
   `May B - Tham gia phong`.
3. May A: bam `Chap nhan cho may B ket noi`.
4. Doi thay `WebRTC DataChannel da ket noi` tren ca 2 may.
5. Bam `Gui HELLO` tren A. B phai thay `Tin nhan nhan duoc: HELLO...`.
6. Neu khong ket noi: mo Logcat va loc `MeloWareP2P` tren ca 2 may.

## Gioi han giai doan 1

- STUN-only: NAT mang 4G/5G co the can TURN.
- Giao dien chi mo luc nguoi dung giu app foreground; chua co foreground service.
- Chua gui danh sach thu muc, audio online hoac tai file; day la giai doan
  xac thuc ket noi truoc khi dua truyen nhac vao.
- Chua compile Android APK trong moi truong tao file; can Sync/Build trong
  Android Studio thuc te va gui Build Output neu loi.

## Xu ly su co

- `Firebase Anonymous Auth that bai`: kiem tra Authentication provider Anonymous.
- `Permission denied` Firebase: kiem tra merge Rules va database URL.
- `Cannot find livekit.org.webrtc`: kiem tra repo mavenCentral / gradle sync.
- `ICE FAILED` / DataChannel khong OPEN: thu tren 2 Wi-Fi khac nhau;
  neu LTE thiet bi han che P2P, can TURN sau.
