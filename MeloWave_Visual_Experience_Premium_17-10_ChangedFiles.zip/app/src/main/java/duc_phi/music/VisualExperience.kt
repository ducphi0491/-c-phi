package duc_phi.music

import android.content.Context
import android.graphics.Color as AndroidColor
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.LinkedHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

internal enum class VisualWaveformStyle {
    CLASSIC,
    BARS,
    MIRROR,
    NEON
}

internal enum class VisualSpectrumStyle {
    OFF,
    BARS_32,
    CIRCULAR
}

internal enum class VisualAlbumEffect {
    STATIC,
    GLOW,
    VINYL
}

internal enum class VisualBackgroundStyle {
    ALBUM_GRADIENT,
    BLURRED_ARTWORK
}

internal enum class VisualColorMode {
    ALBUM,
    MELOWAVE
}

internal enum class VisualPlayerLayout {
    CLASSIC,
    IMMERSIVE,
    KARAOKE
}

internal enum class VisualPerformanceMode {
    AUTO,
    BATTERY,
    SMOOTH
}

@Immutable
internal data class VisualExperienceSettings(
    val waveformStyle: VisualWaveformStyle = VisualWaveformStyle.CLASSIC,
    val spectrumStyle: VisualSpectrumStyle = VisualSpectrumStyle.OFF,
    val albumEffect: VisualAlbumEffect = VisualAlbumEffect.STATIC,
    val backgroundStyle: VisualBackgroundStyle = VisualBackgroundStyle.ALBUM_GRADIENT,
    val colorMode: VisualColorMode = VisualColorMode.MELOWAVE,
    val playerLayout: VisualPlayerLayout = VisualPlayerLayout.CLASSIC,
    val performanceMode: VisualPerformanceMode = VisualPerformanceMode.AUTO
) {
    companion object {
        val DEFAULT = VisualExperienceSettings()
    }
}

internal class VisualExperienceStore(context: Context) {
    private val preferences = context.getSharedPreferences(
        "melowave_visual_experience",
        Context.MODE_PRIVATE
    )

    var settings by mutableStateOf(readSettings())
        private set

    fun update(value: VisualExperienceSettings) {
        settings = value
        preferences.edit()
            .putString("waveform", value.waveformStyle.name)
            .putString("spectrum", value.spectrumStyle.name)
            .putString("album_effect", value.albumEffect.name)
            .putString("background", value.backgroundStyle.name)
            .putString("color_mode", value.colorMode.name)
            .putString("player_layout", value.playerLayout.name)
            .putString("performance", value.performanceMode.name)
            .apply()
    }

    fun reset() = update(VisualExperienceSettings.DEFAULT)

    private fun readSettings(): VisualExperienceSettings = VisualExperienceSettings(
        waveformStyle = enumValue("waveform", VisualWaveformStyle.CLASSIC),
        spectrumStyle = enumValue("spectrum", VisualSpectrumStyle.OFF),
        albumEffect = enumValue("album_effect", VisualAlbumEffect.STATIC),
        backgroundStyle = enumValue("background", VisualBackgroundStyle.ALBUM_GRADIENT),
        colorMode = enumValue("color_mode", VisualColorMode.MELOWAVE),
        playerLayout = enumValue("player_layout", VisualPlayerLayout.CLASSIC),
        performanceMode = enumValue("performance", VisualPerformanceMode.AUTO)
    )

    private inline fun <reified T : Enum<T>> enumValue(key: String, fallback: T): T {
        val stored = preferences.getString(key, null) ?: return fallback
        return runCatching { enumValueOf<T>(stored) }.getOrDefault(fallback)
    }
}

@Immutable
internal data class VisualAlbumPalette(
    val primary: Color,
    val secondary: Color,
    val backgroundTop: Color,
    val backgroundBottom: Color
)

internal fun visualThemePalette(colors: MusicColors): VisualAlbumPalette = VisualAlbumPalette(
    primary = colors.purpleBright,
    secondary = colors.magenta,
    backgroundTop = if (colors.isDark) colors.background else colors.backgroundSoft,
    backgroundBottom = colors.background
)

private object VisualPaletteCache {
    private const val MAX_ENTRIES = 64
    private val entries = object : LinkedHashMap<String, VisualAlbumPalette>(MAX_ENTRIES, 0.75f, true) {
        override fun removeEldestEntry(
            eldest: MutableMap.MutableEntry<String, VisualAlbumPalette>?
        ): Boolean = size > MAX_ENTRIES
    }

    fun get(key: String): VisualAlbumPalette? = synchronized(entries) { entries[key] }

    fun put(key: String, palette: VisualAlbumPalette) {
        synchronized(entries) { entries[key] = palette }
    }
}

@Composable
internal fun rememberVisualAlbumPalette(
    artworkUrl: String?,
    colors: MusicColors,
    enabled: Boolean = true
): VisualAlbumPalette {
    val context = LocalContext.current.applicationContext
    val fallback = remember(colors) { visualThemePalette(colors) }
    if (!enabled || artworkUrl.isNullOrBlank()) return fallback
    val cacheKey = remember(artworkUrl, colors.isDark) {
        artworkUrl?.takeIf { it.isNotBlank() }?.let { "$it|${colors.isDark}" }
    }

    return produceState(
        cacheKey?.let(VisualPaletteCache::get) ?: fallback,
        cacheKey,
        fallback
    ) {
        val key = cacheKey ?: run {
            value = fallback
            return@produceState
        }
        VisualPaletteCache.get(key)?.let {
            value = it
            return@produceState
        }

        val analyzed = withContext(Dispatchers.IO) {
            runCatching {
                val request = ImageRequest.Builder(context)
                    .data(artworkUrl)
                    .allowHardware(false)
                    .size(96)
                    .build()
                val result = context.imageLoader.execute(request)
                val drawable = (result as? SuccessResult)?.drawable ?: return@runCatching fallback
                val bitmap = drawable.toBitmap(width = 96, height = 96)
                analyzeVisualPalette(bitmap, colors.isDark, fallback)
            }.getOrDefault(fallback)
        }
        VisualPaletteCache.put(key, analyzed)
        value = analyzed
    }.value
}

private fun analyzeVisualPalette(
    bitmap: android.graphics.Bitmap,
    isDark: Boolean,
    fallback: VisualAlbumPalette
): VisualAlbumPalette {
    if (bitmap.width <= 0 || bitmap.height <= 0) return fallback

    var hueX = 0.0
    var hueY = 0.0
    var saturationSum = 0.0
    var valueSum = 0.0
    var weightSum = 0.0
    val hsv = FloatArray(3)
    val stepX = max(1, bitmap.width / 24)
    val stepY = max(1, bitmap.height / 24)

    var y = 0
    while (y < bitmap.height) {
        var x = 0
        while (x < bitmap.width) {
            val pixel = bitmap.getPixel(x, y)
            if (AndroidColor.alpha(pixel) >= 180) {
                AndroidColor.colorToHSV(pixel, hsv)
                val saturation = hsv[1]
                val brightness = hsv[2]
                if (brightness in 0.10f..0.96f && saturation >= 0.10f) {
                    val weight = 0.30 + saturation * 0.70
                    val angle = hsv[0] / 180.0 * PI
                    hueX += cos(angle) * weight
                    hueY += sin(angle) * weight
                    saturationSum += saturation * weight
                    valueSum += brightness * weight
                    weightSum += weight
                }
            }
            x += stepX
        }
        y += stepY
    }

    if (weightSum < 4.0) return fallback

    var hue = Math.toDegrees(atan2(hueY, hueX)).toFloat()
    if (hue < 0f) hue += 360f
    val averageSaturation = (saturationSum / weightSum).toFloat().coerceIn(0.42f, 0.90f)
    val averageValue = (valueSum / weightSum).toFloat().coerceIn(0.40f, 0.92f)

    val primary = hsvComposeColor(
        hue,
        max(0.58f, averageSaturation),
        if (isDark) max(0.80f, averageValue) else min(0.70f, averageValue)
    )
    val secondary = hsvComposeColor(
        (hue + 38f) % 360f,
        max(0.54f, averageSaturation * 0.92f),
        if (isDark) 0.96f else 0.66f
    )
    val backgroundTop = if (isDark) {
        lerp(primary, Color(0xFF020612), 0.78f)
    } else {
        lerp(primary, Color.White, 0.86f)
    }
    val backgroundBottom = if (isDark) {
        lerp(secondary, Color(0xFF01040B), 0.88f)
    } else {
        lerp(secondary, Color(0xFFF4F7FC), 0.91f)
    }
    return VisualAlbumPalette(primary, secondary, backgroundTop, backgroundBottom)
}

private fun hsvComposeColor(hue: Float, saturation: Float, value: Float): Color =
    Color(AndroidColor.HSVToColor(floatArrayOf(hue, saturation, value)))

@Immutable
internal data class VisualSpectrumFrame(
    val values: FloatArray = FloatArray(64),
    val active: Boolean = false,
    val error: String? = null
)

@Composable
internal fun rememberVisualSpectrum(
    audioSessionId: Int,
    enabled: Boolean,
    performanceMode: VisualPerformanceMode
): VisualSpectrumFrame {
    var frame by remember { mutableStateOf(VisualSpectrumFrame()) }
    val lifecycleOwner = LocalLifecycleOwner.current
    var lifecycleActive by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            lifecycleActive = when (event) {
                Lifecycle.Event.ON_START,
                Lifecycle.Event.ON_RESUME -> true
                Lifecycle.Event.ON_PAUSE,
                Lifecycle.Event.ON_STOP,
                Lifecycle.Event.ON_DESTROY -> false
                else -> lifecycleActive
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val captureEnabled = enabled && lifecycleActive
    DisposableEffect(audioSessionId, captureEnabled, performanceMode) {
        if (!captureEnabled || audioSessionId <= 0) {
            frame = VisualSpectrumFrame()
            onDispose { }
        } else {
            val mainHandler = Handler(Looper.getMainLooper())
            var visualizer: Visualizer? = null
            var previous = FloatArray(64)

            val result = runCatching {
                Visualizer(audioSessionId).also { capture ->
                    val range = Visualizer.getCaptureSizeRange()
                    val requested = when (performanceMode) {
                        VisualPerformanceMode.BATTERY -> 256
                        VisualPerformanceMode.AUTO -> 512
                        VisualPerformanceMode.SMOOTH -> 1024
                    }
                    capture.captureSize = requested.coerceIn(range[0], range[1])
                    capture.scalingMode = Visualizer.SCALING_MODE_NORMALIZED
                    val maxRate = Visualizer.getMaxCaptureRate().coerceAtLeast(1_000)
                    val rate = when (performanceMode) {
                        VisualPerformanceMode.BATTERY -> (maxRate * 0.36f).toInt()
                        VisualPerformanceMode.AUTO -> (maxRate * 0.62f).toInt()
                        VisualPerformanceMode.SMOOTH -> maxRate
                    }.coerceIn(1_000, maxRate)
                    capture.setDataCaptureListener(
                        object : Visualizer.OnDataCaptureListener {
                            override fun onWaveFormDataCapture(
                                visualizer: Visualizer?,
                                waveform: ByteArray?,
                                samplingRate: Int
                            ) = Unit

                            override fun onFftDataCapture(
                                visualizer: Visualizer?,
                                fft: ByteArray?,
                                samplingRate: Int
                            ) {
                                val bytes = fft ?: return
                                if (bytes.size < 8) return
                                val next = visualFftBands(bytes, previous)
                                previous = next
                                mainHandler.post {
                                    frame = VisualSpectrumFrame(values = next, active = true)
                                }
                            }
                        },
                        rate,
                        false,
                        true
                    )
                    capture.enabled = true
                }
            }
            visualizer = result.getOrNull()
            if (visualizer == null) {
                frame = VisualSpectrumFrame(
                    error = result.exceptionOrNull()?.localizedMessage
                        ?: "Visualizer is unavailable on this device."
                )
            }

            onDispose {
                mainHandler.removeCallbacksAndMessages(null)
                runCatching { visualizer?.enabled = false }
                runCatching { visualizer?.release() }
                visualizer = null
                frame = VisualSpectrumFrame()
            }
        }
    }

    return frame
}

private fun visualFftBands(bytes: ByteArray, previous: FloatArray): FloatArray {
    val half = bytes.size / 2
    val output = FloatArray(64)
    val maxBin = (half - 1).coerceAtLeast(2)
    val logMax = ln(maxBin.toDouble())
    for (index in output.indices) {
        val fraction = index.toDouble() / (output.lastIndex.coerceAtLeast(1)).toDouble()
        val bin = exp(logMax * fraction).toInt().coerceIn(1, maxBin)
        val realIndex = (bin * 2).coerceAtMost(bytes.lastIndex)
        val imagIndex = (realIndex + 1).coerceAtMost(bytes.lastIndex)
        val real = bytes[realIndex].toInt().toDouble()
        val imaginary = bytes[imagIndex].toInt().toDouble()
        val magnitude = sqrt(real * real + imaginary * imaginary)
        val normalized = (ln(1.0 + magnitude) / ln(1.0 + 181.0)).toFloat().coerceIn(0f, 1f)
        val old = previous.getOrElse(index) { 0f }
        output[index] = if (normalized >= old) {
            old * 0.42f + normalized * 0.58f
        } else {
            old * 0.82f + normalized * 0.18f
        }
    }
    return output
}

@Composable
internal fun VisualPlayerBackground(
    song: SongItem,
    artworkUrl: String?,
    settings: VisualExperienceSettings,
    palette: VisualAlbumPalette,
    colors: MusicColors,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        if (
            settings.backgroundStyle == VisualBackgroundStyle.BLURRED_ARTWORK &&
            !artworkUrl.isNullOrBlank()
        ) {
            ArtworkImage(
                song = song,
                artworkUrl = artworkUrl,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(scaleX = 1.22f, scaleY = 1.22f)
                    .blur(if (settings.performanceMode == VisualPerformanceMode.BATTERY) 28.dp else 46.dp),
                cornerRadius = 0
            )
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        if (colors.isDark) {
                            listOf(
                                Color.Black.copy(alpha = 0.38f),
                                palette.backgroundTop.copy(alpha = 0.83f),
                                colors.background.copy(alpha = 0.96f)
                            )
                        } else {
                            listOf(
                                Color.White.copy(alpha = 0.54f),
                                palette.backgroundTop.copy(alpha = 0.84f),
                                colors.background.copy(alpha = 0.95f)
                            )
                        }
                    )
                )
            )
        } else {
            val gradientColors = if (settings.colorMode == VisualColorMode.MELOWAVE) {
                if (colors.isDark) {
                    listOf(colors.background, Color(0xFF0A0B22), colors.background)
                } else {
                    listOf(colors.background, colors.backgroundSoft, colors.background)
                }
            } else {
                listOf(
                    palette.backgroundTop,
                    lerp(palette.backgroundTop, palette.backgroundBottom, 0.55f),
                    palette.backgroundBottom
                )
            }
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(gradientColors)
                )
            )
        }
    }
}

@Composable
internal fun VisualArtworkStage(
    song: SongItem,
    artworkUrl: String?,
    settings: VisualExperienceSettings,
    palette: VisualAlbumPalette,
    spectrum: FloatArray,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    // Do not keep an infinite animation running for the default/static player.
    // The animation objects only exist while their matching effect is active.
    val rotation = if (settings.albumEffect == VisualAlbumEffect.VINYL && isPlaying) {
        val vinylTransition = rememberInfiniteTransition(label = "visual_vinyl_motion")
        val animatedRotation by vinylTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = if (settings.performanceMode == VisualPerformanceMode.BATTERY) 28_000 else 20_000,
                    easing = LinearEasing
                ),
                repeatMode = RepeatMode.Restart
            ),
            label = "visual_vinyl_rotation"
        )
        animatedRotation
    } else {
        0f
    }
    val pulse = if (
        settings.albumEffect == VisualAlbumEffect.GLOW &&
        isPlaying &&
        settings.performanceMode != VisualPerformanceMode.BATTERY
    ) {
        val glowTransition = rememberInfiniteTransition(label = "visual_glow_motion")
        val animatedPulse by glowTransition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = if (settings.performanceMode == VisualPerformanceMode.SMOOTH) 680 else 920
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "visual_glow_pulse"
        )
        animatedPulse
    } else {
        1f
    }

    val activeSpectrum = remember(spectrum) {
        if (spectrum.any { it > 0.01f }) spectrum else FloatArray(64) { index ->
            val x = index.toFloat() / 63f
            (0.13f + abs(sin(x * PI.toFloat() * 5f)) * 0.20f).coerceIn(0f, 1f)
        }
    }
    val plainArtwork = settings.spectrumStyle == VisualSpectrumStyle.OFF &&
            settings.albumEffect == VisualAlbumEffect.STATIC
    val artFraction = when (settings.spectrumStyle) {
        VisualSpectrumStyle.CIRCULAR -> 0.70f
        VisualSpectrumStyle.BARS_32 -> 0.78f
        VisualSpectrumStyle.OFF -> if (plainArtwork) 1.00f else 0.88f
    }
    val albumShape = if (settings.albumEffect == VisualAlbumEffect.VINYL) {
        CircleShape
    } else {
        RoundedCornerShape(if (settings.playerLayout == VisualPlayerLayout.IMMERSIVE) 30.dp else 24.dp)
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            if (settings.albumEffect == VisualAlbumEffect.GLOW) {
                val glowScale = if (isPlaying) pulse else 1f
                drawCircle(
                    color = palette.primary.copy(alpha = 0.12f),
                    radius = size.minDimension * 0.49f * glowScale,
                    center = center
                )
                drawCircle(
                    color = palette.secondary.copy(alpha = 0.18f),
                    radius = size.minDimension * 0.43f * glowScale,
                    center = center
                )
            }

            when (settings.spectrumStyle) {
                VisualSpectrumStyle.OFF -> Unit
                VisualSpectrumStyle.BARS_32 -> {
                    val count = when (settings.performanceMode) {
                        VisualPerformanceMode.BATTERY -> 16
                        VisualPerformanceMode.AUTO -> 24
                        VisualPerformanceMode.SMOOTH -> 32
                    }
                    val gap = size.width / count
                    val baseline = size.height * 0.96f
                    val maxHeight = size.height * 0.18f
                    repeat(count) { index ->
                        val source = (index.toFloat() / (count - 1).coerceAtLeast(1) * activeSpectrum.lastIndex)
                            .toInt().coerceIn(0, activeSpectrum.lastIndex)
                        val level = activeSpectrum[source]
                        val x = (index + 0.5f) * gap
                        val height = 3.dp.toPx() + maxHeight * level
                        val tone = index.toFloat() / count.coerceAtLeast(1)
                        drawLine(
                            color = lerp(palette.primary, palette.secondary, tone),
                            start = Offset(x, baseline),
                            end = Offset(x, baseline - height),
                            strokeWidth = min(4.dp.toPx(), gap * 0.46f),
                            cap = StrokeCap.Round
                        )
                    }
                }
                VisualSpectrumStyle.CIRCULAR -> {
                    val count = when (settings.performanceMode) {
                        VisualPerformanceMode.BATTERY -> 28
                        VisualPerformanceMode.AUTO -> 40
                        VisualPerformanceMode.SMOOTH -> 56
                    }
                    val radius = size.minDimension * 0.365f
                    val maxLength = size.minDimension * 0.095f
                    repeat(count) { index ->
                        val source = (index.toFloat() / count * activeSpectrum.size)
                            .toInt().coerceIn(0, activeSpectrum.lastIndex)
                        val level = activeSpectrum[source]
                        val angle = -PI.toFloat() / 2f + (index.toFloat() / count) * PI.toFloat() * 2f
                        val length = 2.dp.toPx() + level * maxLength
                        val start = Offset(
                            center.x + cos(angle) * radius,
                            center.y + sin(angle) * radius
                        )
                        val end = Offset(
                            center.x + cos(angle) * (radius + length),
                            center.y + sin(angle) * (radius + length)
                        )
                        drawLine(
                            color = lerp(palette.primary, palette.secondary, index.toFloat() / count),
                            start = start,
                            end = end,
                            strokeWidth = 2.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                    drawCircle(
                        color = palette.primary.copy(alpha = 0.26f),
                        radius = radius - 5.dp.toPx(),
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize(artFraction)
                .aspectRatio(1f)
                .graphicsLayer {
                    rotationZ = if (settings.albumEffect == VisualAlbumEffect.VINYL && isPlaying) rotation else 0f
                    val scale = if (
                        settings.albumEffect == VisualAlbumEffect.GLOW &&
                        isPlaying &&
                        settings.performanceMode != VisualPerformanceMode.BATTERY
                    ) pulse else 1f
                    scaleX = scale
                    scaleY = scale
                }
                .shadow(
                    elevation = if (plainArtwork) 0.dp else if (settings.albumEffect == VisualAlbumEffect.STATIC) 9.dp else 18.dp,
                    shape = albumShape,
                    ambientColor = palette.primary.copy(alpha = 0.46f),
                    spotColor = palette.secondary.copy(alpha = 0.46f)
                )
                .border(
                    width = if (plainArtwork) 0.dp else if (settings.albumEffect == VisualAlbumEffect.STATIC) 1.dp else 2.dp,
                    brush = Brush.linearGradient(listOf(palette.primary, palette.secondary)),
                    shape = albumShape
                )
                .clip(albumShape)
        ) {
            ArtworkImage(
                song = song,
                artworkUrl = artworkUrl,
                modifier = Modifier.fillMaxSize(),
                cornerRadius = if (settings.albumEffect == VisualAlbumEffect.VINYL) 240 else 24
            )
            if (settings.albumEffect == VisualAlbumEffect.VINYL) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    repeat(5) { ring ->
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.10f + ring * 0.018f),
                            radius = size.minDimension * (0.25f + ring * 0.055f),
                            center = center,
                            style = Stroke(width = 1.dp.toPx())
                        )
                    }
                    drawCircle(
                        color = Color.Black.copy(alpha = 0.62f),
                        radius = size.minDimension * 0.065f,
                        center = center
                    )
                    drawCircle(
                        color = palette.secondary,
                        radius = size.minDimension * 0.020f,
                        center = center
                    )
                }
            }
        }
    }
}

private data class VisualOption<T>(
    val value: T,
    val label: String,
    val premium: Boolean = true
)

@Composable
internal fun VisualExperienceDialog(
    song: SongItem,
    artworkUrl: String?,
    currentSettings: VisualExperienceSettings,
    albumPalette: VisualAlbumPalette,
    themePalette: VisualAlbumPalette,
    spectrum: FloatArray,
    isPlaying: Boolean,
    premiumLocked: Boolean,
    hasVisualizerPermission: Boolean,
    onApply: (VisualExperienceSettings, Boolean) -> Unit,
    onOpenPremium: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    var draft by remember(currentSettings) { mutableStateOf(currentSettings) }
    val previewPalette = if (draft.colorMode == VisualColorMode.ALBUM) albumPalette else themePalette
    val premiumSelected = visualUsesPremiumFeatures(draft)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(28.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.46f))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 7.dp, top = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = colors.purple.copy(alpha = 0.16f)
                    ) {
                        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = colors.purpleBright)
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            mwString("visual.title", "Visual Experience"),
                            color = colors.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            mwString("visual.subtitle", "Customize the Now Playing screen"),
                            color = colors.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, mwString("common.close", "Close"), tint = colors.textSecondary)
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                                .clip(RoundedCornerShape(22.dp))
                        ) {
                            VisualPlayerBackground(
                                song = song,
                                artworkUrl = artworkUrl,
                                settings = draft,
                                palette = previewPalette,
                                colors = colors,
                                modifier = Modifier.fillMaxSize()
                            )
                            VisualArtworkStage(
                                song = song,
                                artworkUrl = artworkUrl,
                                settings = draft,
                                palette = previewPalette,
                                spectrum = spectrum,
                                isPlaying = isPlaying,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(190.dp)
                            )
                            Surface(
                                modifier = Modifier.align(Alignment.TopStart).padding(9.dp),
                                shape = RoundedCornerShape(10.dp),
                                color = Color.Black.copy(alpha = 0.42f)
                            ) {
                                Text(
                                    mwString("visual.live_preview", "Live preview"),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }

                    if (premiumLocked) {
                        item {
                            Surface(
                                modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenPremium),
                                shape = RoundedCornerShape(15.dp),
                                color = colors.purple.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.36f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    MeloWarePremiumCrown(modifier = Modifier.size(25.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            mwString("visual.premium_title", "Premium visual styles"),
                                            color = colors.textPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            mwString("visual.premium_detail", "Preview every style, then activate Premium to apply it."),
                                            color = colors.textSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Icon(Icons.Rounded.Lock, null, tint = colors.purpleBright)
                                }
                            }
                        }
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.waveform", "Waveform"),
                            icon = Icons.Rounded.GraphicEq,
                            options = listOf(
                                VisualOption(VisualWaveformStyle.CLASSIC, mwString("visual.waveform.classic", "Classic"), premium = false),
                                VisualOption(VisualWaveformStyle.BARS, mwString("visual.waveform.bars", "Bars")),
                                VisualOption(VisualWaveformStyle.MIRROR, mwString("visual.waveform.mirror", "Mirror")),
                                VisualOption(VisualWaveformStyle.NEON, mwString("visual.waveform.neon", "Neon"))
                            ),
                            selected = draft.waveformStyle,
                            premiumLocked = premiumLocked,
                            onSelect = { draft = draft.copy(waveformStyle = it) }
                        )
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.spectrum", "Real-time spectrum"),
                            icon = Icons.Rounded.Equalizer,
                            options = listOf(
                                VisualOption(VisualSpectrumStyle.OFF, mwString("visual.off", "Off"), premium = false),
                                VisualOption(VisualSpectrumStyle.BARS_32, mwString("visual.spectrum.bars", "32 bars")),
                                VisualOption(VisualSpectrumStyle.CIRCULAR, mwString("visual.spectrum.circular", "Circular"))
                            ),
                            selected = draft.spectrumStyle,
                            premiumLocked = premiumLocked,
                            onSelect = { draft = draft.copy(spectrumStyle = it) }
                        )
                        if (draft.spectrumStyle != VisualSpectrumStyle.OFF && !hasVisualizerPermission) {
                            Text(
                                mwString(
                                    "visual.permission_hint",
                                    "Android audio permission is requested only to draw the spectrum. MeloWave does not record the microphone."
                                ),
                                color = colors.textSecondary,
                                fontSize = 10.5.sp,
                                lineHeight = 14.sp,
                                modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp)
                            )
                        }
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.album_effect", "Album effect"),
                            icon = Icons.Rounded.Album,
                            options = listOf(
                                VisualOption(VisualAlbumEffect.STATIC, mwString("visual.album.static", "Static"), premium = false),
                                VisualOption(VisualAlbumEffect.GLOW, mwString("visual.album.glow", "Glow")),
                                VisualOption(VisualAlbumEffect.VINYL, mwString("visual.album.vinyl", "Vinyl"))
                            ),
                            selected = draft.albumEffect,
                            premiumLocked = premiumLocked,
                            onSelect = { draft = draft.copy(albumEffect = it) }
                        )
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.background", "Player background"),
                            icon = Icons.Rounded.Stars,
                            options = listOf(
                                VisualOption(VisualBackgroundStyle.ALBUM_GRADIENT, mwString("visual.background.gradient", "Gradient"), premium = false),
                                VisualOption(VisualBackgroundStyle.BLURRED_ARTWORK, mwString("visual.background.blur", "Blurred cover"))
                            ),
                            selected = draft.backgroundStyle,
                            premiumLocked = premiumLocked,
                            onSelect = { draft = draft.copy(backgroundStyle = it) }
                        )
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.colors", "Visual colors"),
                            icon = Icons.Rounded.AutoAwesome,
                            options = listOf(
                                VisualOption(VisualColorMode.MELOWAVE, mwString("visual.colors.melowave", "MeloWave"), premium = false),
                                VisualOption(VisualColorMode.ALBUM, mwString("visual.colors.album", "From cover"))
                            ),
                            selected = draft.colorMode,
                            premiumLocked = premiumLocked,
                            onSelect = { draft = draft.copy(colorMode = it) }
                        )
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.layout", "Player layout"),
                            icon = Icons.Rounded.MusicNote,
                            options = listOf(
                                VisualOption(VisualPlayerLayout.CLASSIC, mwString("visual.layout.classic", "Classic"), premium = false),
                                VisualOption(VisualPlayerLayout.IMMERSIVE, mwString("visual.layout.immersive", "Immersive")),
                                VisualOption(VisualPlayerLayout.KARAOKE, mwString("visual.layout.karaoke", "Karaoke"))
                            ),
                            selected = draft.playerLayout,
                            premiumLocked = premiumLocked,
                            onSelect = { draft = draft.copy(playerLayout = it) }
                        )
                    }

                    item {
                        VisualSection(
                            title = mwString("visual.performance", "Performance"),
                            icon = Icons.Rounded.AutoAwesome,
                            options = listOf(
                                VisualOption(VisualPerformanceMode.AUTO, mwString("visual.performance.auto", "Auto"), premium = false),
                                VisualOption(VisualPerformanceMode.BATTERY, mwString("visual.performance.battery", "Battery saver"), premium = false),
                                VisualOption(VisualPerformanceMode.SMOOTH, mwString("visual.performance.smooth", "Smooth"), premium = false)
                            ),
                            selected = draft.performanceMode,
                            premiumLocked = false,
                            onSelect = { draft = draft.copy(performanceMode = it) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { draft = VisualExperienceSettings.DEFAULT },
                        modifier = Modifier.height(46.dp)
                    ) {
                        Icon(Icons.Rounded.RestartAlt, null, tint = colors.textSecondary)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            mwString("visual.reset", "Reset"),
                            color = colors.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Button(
                        onClick = {
                            if (premiumLocked && premiumSelected) {
                                onOpenPremium()
                            } else {
                                onApply(
                                    draft,
                                    draft.spectrumStyle != VisualSpectrumStyle.OFF && !hasVisualizerPermission
                                )
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                    ) {
                        if (premiumLocked && premiumSelected) {
                            MeloWarePremiumCrown(modifier = Modifier.size(21.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(mwString("visual.unlock", "Unlock Premium"), fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Rounded.Check, null, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(mwString("visual.apply", "Apply"), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private fun visualUsesPremiumFeatures(settings: VisualExperienceSettings): Boolean =
    settings.waveformStyle != VisualWaveformStyle.CLASSIC ||
        settings.spectrumStyle != VisualSpectrumStyle.OFF ||
        settings.albumEffect != VisualAlbumEffect.STATIC ||
        settings.backgroundStyle != VisualBackgroundStyle.ALBUM_GRADIENT ||
        settings.colorMode != VisualColorMode.MELOWAVE ||
        settings.playerLayout != VisualPlayerLayout.CLASSIC

@Composable
private fun <T> VisualSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    options: List<VisualOption<T>>,
    selected: T,
    premiumLocked: Boolean,
    onSelect: (T) -> Unit
) {
    val colors = LocalMusicColors.current
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = colors.purpleBright, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text(
                title,
                color = colors.textPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options, key = { it.value.toString() }) { option ->
                val isSelected = option.value == selected
                Surface(
                    modifier = Modifier.clickable { onSelect(option.value) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) {
                        colors.purple.copy(alpha = if (colors.isDark) 0.28f else 0.17f)
                    } else {
                        colors.cardRaised.copy(alpha = 0.86f)
                    },
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) colors.purpleBright else colors.border
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isSelected) {
                            Icon(
                                Icons.Rounded.Check,
                                null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                        }
                        Text(
                            option.label,
                            color = if (isSelected) colors.textPrimary else colors.textSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (premiumLocked && option.premium) {
                            Spacer(Modifier.width(5.dp))
                            Icon(
                                Icons.Rounded.Lock,
                                null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
