# TunerTools Documents: unzip and upload to Google Drive in one run.
# Run on the Windows IIS machine that contains the Documents files.
$ErrorActionPreference = 'Stop'
$zipDirectory = Join-Path $env:USERPROFILE 'Downloads'
$target = 'C:\TunerTools\BackupScripts\Drive_Documents'
$source = 'C:\inetpub\wwwroot\document'
$output = 'C:\TunerTools\BackupPrep\Drive_Documents'

$zip = Get-ChildItem -LiteralPath $zipDirectory -Filter 'TunerTools_Documents_Upload_1Click_20261106*.zip' -File -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($null -eq $zip) {
    throw "Missing ZIP in $zipDirectory. Download TunerTools_Documents_Upload_1Click_20261106.zip first."
}
if (-not (Test-Path -LiteralPath $source -PathType Container)) {
    throw "Documents source folder not found: $source. Check its location on the IIS Windows server."
}
$tokenCandidates = @(
    'C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json',
    (Join-Path $target 'drive_token.json'),
    'C:\TunerTools\BackupScripts\Drive_Buoc2C\drive_token.json'
)
$token = $tokenCandidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $token) {
    throw 'No existing drive_token.json found. Reuse the private token from the previous app-guides backup; do not send or upload the token publicly.'
}

Write-Host "ZIP: $($zip.FullName)" -ForegroundColor Cyan
Write-Host "SOURCE: $source" -ForegroundColor Cyan
Write-Host "TARGET: $target" -ForegroundColor Cyan
Write-Host 'TOKEN: Existing private OAuth file (contents hidden)' -ForegroundColor Cyan
New-Item -ItemType Directory -Path $target -Force | Out-Null
Expand-Archive -LiteralPath $zip.FullName -DestinationPath $target -Force
$runner = Join-Path $target 'CHAY_UPLOAD_DOCUMENTS.ps1'
if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) {
    throw "Missing uploader script after extraction: $runner"
}

Write-Host 'Starting incremental Google Drive upload...' -ForegroundColor Yellow
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runner -SourceDir $source -TokenFile $token -OutputDir $output
$code = $LASTEXITCODE
if ($code -ne 0) {
    throw "Upload did not finish (exit code $code). Fix the error and run this script again. Uploaded files will be checked and reused."
}

$summary = Join-Path $output 'KET_QUA_UPLOAD_DOCUMENTS.txt'
if (-not (Test-Path -LiteralPath $summary -PathType Leaf)) {
    throw "Upload returned success but the report is missing: $summary"
}
Write-Host 'UPLOAD COMPLETE. SUMMARY:' -ForegroundColor Green
Get-Content -LiteralPath $summary -Encoding UTF8
Write-Host "Index for alwaysdata: $(Join-Path $output 'documents_drive_index.php')" -ForegroundColor Green
