param(
    [string]$SourceDir = 'C:\inetpub\wwwroot\document',
    [string]$TokenFile = '',
    [string]$OutputDir = 'C:\TunerTools\BackupPrep\Drive_Documents',
    [switch]$Upload
)
$ErrorActionPreference = 'Stop'
$ToolDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Script = Join-Path $ToolDir '03_upload_documents.py'
if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) {
    throw "Cannot find source Documents folder: $SourceDir"
}
$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) { $pythonExe = $py.Source; $pythonPrefix = @('-3') }
else {
    $py = Get-Command python -ErrorAction SilentlyContinue
    if (-not $py) { throw 'Python 3.10+ is needed.' }
    $pythonExe = $py.Source
    $pythonPrefix = @()
}
$argsForPython = @($pythonPrefix) + @($Script, '--source', $SourceDir, '--output', $OutputDir)
if ($Upload) {
    if (-not $TokenFile) { $TokenFile = Join-Path $ToolDir 'drive_token.json' }
    if (-not (Test-Path -LiteralPath $TokenFile -PathType Leaf)) {
        throw "Private OAuth token JSON not found: $TokenFile"
    }
    $argsForPython += @('--token', $TokenFile, '--upload')
}
& $pythonExe @argsForPython
if ($LASTEXITCODE -ne 0) { throw "Documents backup stopped with error $LASTEXITCODE" }
Write-Host ('Manifest: ' + (Join-Path $OutputDir 'documents_drive_manifest.json'))
if ($Upload) { Write-Host ('Copy to alwaysdata: ' + (Join-Path $OutputDir 'documents_drive_index.php')) }
