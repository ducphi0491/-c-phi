param(
    [string]$SourceDir = 'C:\inetpub\wwwroot\document',
    [string]$TokenFile = '',
    [string]$OutputDir = 'C:\TunerTools\BackupPrep\Drive_Documents'
)
$ErrorActionPreference = 'Stop'
$env:PYTHONIOENCODING = 'utf-8'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch { }

Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ' TUNERTOOLS DOCUMENTS - GOOGLE DRIVE AUTO UPLOAD' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) {
    throw "Khong tim thay thu muc: $SourceDir. Hay chay tren Windows Server IIS, hoac truyen -SourceDir."
}

if ([string]::IsNullOrWhiteSpace($TokenFile)) {
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($env:TUNERTOOLS_DRIVE_TOKEN_FILE)) {
        $candidates += $env:TUNERTOOLS_DRIVE_TOKEN_FILE
    }
    $candidates += (Join-Path $PSScriptRoot 'drive_token.json')
    $candidates += 'C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json'
    $candidates += 'C:\TunerTools\BackupScripts\Drive_Documents\drive_token.json'
    $candidates += 'C:\TunerTools\BackupScripts\Drive_Buoc2C\drive_token.json'
    $found = @($candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1)
    if ($found.Count -lt 1) {
        throw 'Khong tim thay drive_token.json da dung voi backup app-guides. Duong dan cu: C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json. KHONG gui token qua chat.'
    }
    $TokenFile = $found[0]
}
if (-not (Test-Path -LiteralPath $TokenFile -PathType Leaf)) {
    throw "Token OAuth khong ton tai tai: $TokenFile"
}

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
Write-Host ("Source : " + $SourceDir)
Write-Host ("Output : " + $OutputDir)
Write-Host ("Token  : existing private OAuth file (NOT copied or modified)")
Write-Host ('Google : My Drive/TunerTools_AppBackup/document')
Write-Host 'Upload is incremental: only new/changed files are transferred.'
Write-Host ''

$started = Get-Date -Format 'yyyyMMdd_HHmmss'
$logFile = Join-Path $OutputDir "documents_upload_$started.log"
$transcribing = $false
try {
    try {
        Start-Transcript -LiteralPath $logFile -ErrorAction Stop | Out-Null
        $transcribing = $true
    } catch {
        Write-Host 'Canh bao: khong the ghi log PowerShell, van tiep tuc upload.' -ForegroundColor Yellow
    }

    $worker = Join-Path $PSScriptRoot '03_drive_documents.ps1'
    & $worker -SourceDir $SourceDir -TokenFile $TokenFile -OutputDir $OutputDir -Upload
    if ($LASTEXITCODE -ne 0) { throw "Uploader exited with code $LASTEXITCODE" }

    $manifestPath = Join-Path $OutputDir 'documents_drive_manifest.json'
    $indexPath = Join-Path $OutputDir 'documents_drive_index.php'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw 'Khong thay manifest sau upload.'
    }
    $report = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $files = @($report.files)
    $verified = @($files | Where-Object { $_.drive_file_id -and $_.status -in @('uploaded', 'updated', 'unchanged') }).Count
    $missing = [int]$report.total_files - $verified
    if ($report.status -ne 'complete' -or $missing -ne 0 -or -not (Test-Path -LiteralPath $indexPath -PathType Leaf)) {
        throw "Upload CHUA HOAN TAT: status=$($report.status), missing=$missing. Chay lai de tiep tuc."
    }

    $uploadedCount = @($files | Where-Object { $_.status -eq 'uploaded' }).Count
    $updatedCount = @($files | Where-Object { $_.status -eq 'updated' }).Count
    $unchangedCount = @($files | Where-Object { $_.status -eq 'unchanged' }).Count
    $gb = [Math]::Round(([double]$report.total_bytes) / 1GB, 3)
    $lines = @(
        'TUNERTOOLS DOCUMENTS BACKUP - COMPLETE',
        "Status: $($report.status)",
        "Files: $verified / $($report.total_files)",
        "Uploaded new: $uploadedCount",
        "Updated: $updatedCount",
        "Unchanged/skipped: $unchangedCount",
        "Total source size: $gb GB",
        "Google Drive folder ID: $($report.documents_drive_id)",
        "Private PHP index: $indexPath",
        "Manifest: $manifestPath",
        '',
        'NEXT: Upload documents_drive_index.php to alwaysdata alongside api_documents_drive.php.',
        'Do not upload documents_drive_manifest.json or drive_token.json to a public web folder.'
    )
    $summary = Join-Path $OutputDir 'KET_QUA_UPLOAD_DOCUMENTS.txt'
    [System.IO.File]::WriteAllLines($summary, $lines, (New-Object System.Text.UTF8Encoding($true)))
    Write-Host ''
    Write-Host 'UPLOAD DOCUMENTS COMPLETED AND CHECKED' -ForegroundColor Green
    $lines | ForEach-Object { Write-Host $_ }
} finally {
    if ($transcribing) { try { Stop-Transcript | Out-Null } catch { } }
}
