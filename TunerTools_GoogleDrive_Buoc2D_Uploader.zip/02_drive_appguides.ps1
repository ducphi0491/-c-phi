[CmdletBinding()]
param(
    [string]$SourceDir = "C:\TunerTools\Web\tunertools\app-guides",
    [string]$TokenFile = "C:\TunerTools\Secrets\drive_token.json",
    [string]$OutputDir = "C:\TunerTools\BackupPrep\Drive_AppGuides",
    [switch]$Upload
)

$ErrorActionPreference = 'Stop'
$script = Join-Path $PSScriptRoot "drive_appguides_upload.py"
if (-not (Test-Path -LiteralPath $script -PathType Leaf)) {
    throw "Script Python missing: $script"
}
$python = Get-Command python.exe -ErrorAction SilentlyContinue
if ($null -eq $python) {
    $python = Get-Command py.exe -ErrorAction SilentlyContinue
}
if ($null -eq $python) {
    throw "Python 3.9+ is required. Install Python or add it to PATH."
}
$cmdArgs = @($script, '--source', $SourceDir, '--output', $OutputDir)
if ($Upload) {
    $cmdArgs += @('--token', $TokenFile, '--upload')
}
Write-Host "`n=== TunerTools AppGuides Backup ===" -ForegroundColor Cyan
Write-Host "Source: $SourceDir"
Write-Host "Output: $OutputDir"
if ($Upload) {
    Write-Host "MODE: UPLOAD WITH EXISTING OAUTH" -ForegroundColor Yellow
} else {
    Write-Host "MODE: CHECK ONLY (no Drive requests)" -ForegroundColor Green
}
& $python.Source @cmdArgs
if ($LASTEXITCODE -ne 0) { throw "Backup script exit code: $LASTEXITCODE" }
