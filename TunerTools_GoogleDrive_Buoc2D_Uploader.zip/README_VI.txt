TUNERTOOLS - BUOC 2D: DONG BO APP-GUIDES BANG CHINH OAUTH GP
=============================================================

NGUYEN NHAN CAN XU LY
- Google Drive browser mo duoc folder cu, nhung API voi token hien tai
  tra HTTP 404 va khong tim thay folder do qua files.list.
- Neu token co scope drive.file, day la han che quyen theo TUNG FILE,
  khong phai loi PHP. Viec thay doi URL hoac them tim kiem bang ten
  khong the sua truc tiep.
- Cach khong thay doi OAuth: tao folder moi bang CHINH OAuth GP va
  upload tung file qua cung OAuth. Folder va file moi se thuoc pham vi
  app co the truy cap. Thu muc/tep cu tren Drive KHONG bi sua hay xoa.

KHONG BAO GIO gui drive_token.json cho ChatGPT, khong dua len webroot,
khong ghi token vao tin nhan, khong public thu muc chua token.

1. GIAI NEN:
   C:\TunerTools\BackupScripts\Drive_Buoc2D\

2. KIEM TRA TRUOC (KHONG DOI GOOGLE DRIVE):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\BackupScripts\Drive_Buoc2D\02_drive_appguides.ps1" -SourceDir "C:\TunerTools\Web\tunertools\app-guides"
   Neu duong dan khac, thay -SourceDir bang thu muc app-guides thuc te.
   Ket qua luu trong C:\TunerTools\BackupPrep\Drive_AppGuides\app_guides_drive_manifest.json
   O che do CHECK ONLY: khong truy cap Google Drive; khong can token.

3. CHUAN BI TOKEN O WINDOWS (CHO BUOC UPLOAD):
   Can file drive_token.json co refresh_token, client_id, client_secret
   DUNG CUNG OAUTH CLIENT dang duoc api_gp_drive.php su dung.
   Neu token dang o alwaysdata, tai bang SFTP quan ly rieng, luu tai:
   C:\TunerTools\Secrets\drive_token.json
   Khong upload/serve file token qua URL cong khai.
   KHONG XOA hoac DANG NHAP LAI OAuth GP, KHONG thay doi token o alwaysdata.

4. KHI DUOC PHE DUYET DONG BO, MOI CHAY:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\BackupScripts\Drive_Buoc2D\02_drive_appguides.ps1" -SourceDir "C:\TunerTools\Web\tunertools\app-guides" -TokenFile "C:\TunerTools\Secrets\drive_token.json" -Upload

   Script tao My Drive / TunerTools_AppBackup / app-guides tu chinh OAuth.
   Khong co gang ghi de vao thu muc tunertools/app-guides cu da tao bang browser.
   Upload video.mp4, 15 file .vtt, thumbnail, guide.json trong 7 danh muc.
   Dung chunk 4 MiB. Chay lai an toan: neu MD5 khop thi bo qua.
   Neu file thay doi, script cap nhat file da duoc chinh app upload.
   KHONG XOA file local hoac file Drive cu. Can du dung luong Drive.

5. SAU KHI UPLOAD:
   Sao luu ID app_guides_folder_id trong app_guides_drive_manifest.json.
   Trong api_guides_drive_check.php, thay TT_GUIDES_ROOT_ID bang ID MOI.
   Ghi de file PHP kiem tra, truy cap ?action=check.
   Neu ok=true, tiep tuc tao api_guides_drive.php va Android fallback.

BAO MAT VA GIOI HAN
- PHP kiem tra hien tai chi doc OAuth. Tool nay la bo upload rieng,
  khong sua api_gp_drive.php hoac drive_token.json.
- Neu token GP khong duoc cap quyen tao file, script se bao HTTP 403,
  khong tu xin scope moi va khong thay doi token.
- Khong upload cac tep ngoai cau truc app-guides. Co canh bao neu thay.
- Khong sao luu Documents trong buoc nay; tai lieu co phan quyen duoc
  xu ly rieng sau khi video da thanh cong.
- Folder app-owned moi co the xuat hien trong tai khoan Google cua
  OAuth token, khong nhat thiet trung voi tai khoan dang mo tren Chrome.
- Khong duoc xoa thu muc app-guides cu tren Drive truoc khi test thanh cong.
- Vi viec upload bang PHP co the vuot gioi han dung luong/timeouts,
  script upload truc tiep tu Windows den Google Drive API.
