#!/usr/bin/env python3
"""TunerTools app-guides backup uploader, Python 3.9+ standard library only.

Safe defaults: without --upload this ONLY reads local files and writes a local
inventory; Google Drive calls are made only when --upload is explicitly set.
Uses the same Drive OAuth client/refresh token as api_gp_drive.php (drive_token.json).
Does not modify the token, local source, or pre-existing browser-created folders.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import mimetypes
import os
import re
from pathlib import Path
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

CATEGORIES = ('songs', 'chords', 'tuner', 'metronome', 'training', 'documents', 'settings')
LANGUAGES = ('vi', 'en', 'es', 'fr', 'de', 'ru', 'ja', 'zh', 'th', 'lo', 'km', 'ko', 'pt', 'sw', 'ar')
FOLDER_MIME = 'application/vnd.google-apps.folder'
GOOGLE_DRIVE = 'https://www.googleapis.com/drive/v3/files'
GOOGLE_UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files'
CHUNK_SIZE = 4 * 1024 * 1024   # multiple of 256KiB for Drive resumable upload
RETRY_STATUSES = (408, 429, 500, 502, 503, 504)


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def dump_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.partial')
    with temp.open('w', encoding='utf-8', newline='\n') as out:
        json.dump(obj, out, indent=2, ensure_ascii=False)
        out.write('\n')
    os.replace(temp, path)


def file_hash(path: Path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with path.open('rb') as reader:
        while True:
            piece = reader.read(1024 * 1024)
            if not piece:
                break
            h.update(piece)
    return h.hexdigest()


def classify(relative: Path) -> str | None:
    chunks = relative.parts
    if len(chunks) < 3 or chunks[0] not in CATEGORIES:
        return None
    if re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,63}', chunks[1]) is None:
        return None
    if len(chunks) == 3 and chunks[2] == 'guide.json':
        return 'metadata'
    if len(chunks) == 3 and chunks[2] in ('thumbnail.jpg', 'thumbnail.png', 'thumbnail.webp'):
        return 'thumbnail'
    if len(chunks) == 4 and chunks[2] == 'videos' and chunks[3] == 'video.mp4':
        return 'video'
    if len(chunks) == 4 and chunks[2] == 'subtitles' and chunks[3] in {x + '.vtt' for x in LANGUAGES}:
        return 'subtitle'
    return None


def inventory(source: Path, calculate_hash: bool) -> tuple[list[dict], list[str]]:
    entries = []
    warnings = []
    for item in sorted(source.rglob('*')):
        if item.is_symlink():
            warnings.append('Skipped link: ' + str(item.relative_to(source)))
            continue
        if not item.is_file():
            continue
        rel = item.relative_to(source)
        kind = classify(rel)
        if not kind:
            warnings.append('Unrecognized guide file (not uploaded): ' + rel.as_posix())
            continue
        info = {
            'relative_path': rel.as_posix(),
            'type': kind,
            'size_bytes': item.stat().st_size,
            'md5': file_hash(item, 'md5') if calculate_hash else '',
            'sha256': file_hash(item, 'sha256') if calculate_hash else '',
            'drive_file_id': None,
            'status': 'local_only',
        }
        entries.append(info)
    return entries, warnings


class DriveError(RuntimeError):
    pass


class DriveClient:
    def __init__(self, token_path: Path):
        self.token_path = token_path
        with token_path.open('r', encoding='utf-8-sig') as f:
            self.token = json.load(f)
        if not isinstance(self.token, dict):
            raise DriveError('OAuth token JSON must be an object')
        self.access_token = ''
        self.refresh()

    def refresh(self):
        required = ('refresh_token', 'client_id', 'client_secret')
        if not all(self.token.get(k) for k in required):
            raise DriveError('Token missing refresh_token/client_id/client_secret; same OAuth token required')
        body = urllib.parse.urlencode({
            'grant_type': 'refresh_token',
            'refresh_token': self.token['refresh_token'],
            'client_id': self.token['client_id'],
            'client_secret': self.token['client_secret'],
        }).encode('utf-8')
        request = urllib.request.Request('https://oauth2.googleapis.com/token', body,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}, method='POST')
        try:
            with urllib.request.urlopen(request, timeout=40) as response:
                result = json.load(response)
        except urllib.error.HTTPError as err:
            raise DriveError('OAuth refresh HTTP ' + str(err.code) + '; token is unchanged') from None
        except Exception as err:
            raise DriveError('OAuth refresh network error: ' + str(err)) from err
        self.access_token = result.get('access_token') or ''
        if not self.access_token:
            raise DriveError('OAuth refresh returned no access_token')

    def request(self, url: str, method: str = 'GET', body: bytes | None = None,
                headers: dict | None = None, allow308: bool = False) -> tuple[int, bytes, Any]:
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or parsed.hostname not in ('www.googleapis.com', 'oauth2.googleapis.com'):
            raise DriveError('Unexpected upload host; refusing to send OAuth credentials')
        last_status = 0
        for attempt in range(6):
            request_headers = {
                'Authorization': 'Bearer ' + self.access_token,
                'Accept': 'application/json',
            }
            if headers:
                request_headers.update(headers)
            req = urllib.request.Request(url, body, headers=request_headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=120) as response:
                    return response.status, response.read(), response.headers
            except urllib.error.HTTPError as e:
                last_status = e.code
                payload = e.read(4096)
                if allow308 and e.code == 308:
                    return 308, payload, e.headers
                if e.code == 401 and attempt == 0:
                    self.refresh()
                    continue
                if e.code in RETRY_STATUSES and attempt < 5:
                    time.sleep(min(12, 2 ** attempt))
                    continue
                # Never expose headers or authentication material.
                reason = ''
                try:
                    raw = json.loads(payload)
                    err_obj = raw.get('error', {})
                    reason = str(err_obj.get('status', '')) if isinstance(err_obj, dict) else ''
                except Exception:
                    pass
                raise DriveError(f'Google API HTTP {e.code} {reason}; method={method}') from None
            except (OSError, TimeoutError) as e:
                if attempt < 5:
                    time.sleep(min(12, 2 ** attempt))
                    continue
                raise DriveError('Google API network failure: ' + str(e)) from e
        raise DriveError('Google API exhausted retries HTTP ' + str(last_status))

    def json_request(self, url: str, method='GET', payload: dict | None = None) -> dict:
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None
        headers = {'Content-Type': 'application/json; charset=UTF-8'} if data is not None else None
        code, body, _ = self.request(url, method, data, headers)
        if code < 200 or code >= 300:
            raise DriveError('Unexpected API HTTP ' + str(code))
        try:
            result = json.loads(body)
        except Exception as e:
            raise DriveError('Google API returned invalid JSON') from e
        return result

    def list_named(self, parent_id: str | None, name: str, folder: bool | None = None) -> list[dict]:
        safe_name = name.replace('\\', '\\\\').replace("'", "\\'")
        terms = [f"name = '{safe_name}'", 'trashed = false']
        if parent_id:
            terms.append(f"'{parent_id}' in parents")
        else:
            terms.append("'root' in parents")
        if folder is True:
            terms.append("mimeType = 'application/vnd.google-apps.folder'")
        elif folder is False:
            terms.append("mimeType != 'application/vnd.google-apps.folder'")
        items = []
        page_token = ''
        while True:
            query = {
                'q': ' and '.join(terms),
                'fields': 'nextPageToken,files(id,name,mimeType,size,md5Checksum,parents)',
                'pageSize': '100',
                'spaces': 'drive',
            }
            if page_token:
                query['pageToken'] = page_token
            result = self.json_request(GOOGLE_DRIVE + '?' + urllib.parse.urlencode(query))
            items += result.get('files', [])
            page_token = result.get('nextPageToken', '')
            if not page_token:
                break
        return items

    def ensure_folder(self, name: str, parent_id: str | None) -> str:
        matches = self.list_named(parent_id, name, folder=True)
        if len(matches) > 1:
            raise DriveError(f'Multiple visible folders named {name}; stop to avoid wrong selection')
        if matches:
            return matches[0]['id']
        # When parent_id=None, new folder is created in the OAuth account's My Drive.
        metadata: dict[str, Any] = {'name': name, 'mimeType': FOLDER_MIME}
        if parent_id:
            metadata['parents'] = [parent_id]
        result = self.json_request(GOOGLE_DRIVE + '?fields=id,name,mimeType', 'POST', metadata)
        folder_id = result.get('id')
        if not folder_id:
            raise DriveError('Drive folder creation returned no id')
        return folder_id

    def upload(self, parent_id: str, path: Path, filename: str, md5: str) -> tuple[str, str]:
        matches = self.list_named(parent_id, filename, folder=False)
        if len(matches) > 1:
            raise DriveError(f'Multiple Drive files named {filename} in same folder; refusing to overwrite')
        existing = matches[0] if matches else None
        if existing and existing.get('md5Checksum', '').lower() == md5.lower():
            return existing['id'], 'unchanged'

        mime = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        size = path.stat().st_size
        metadata: dict[str, Any] = {'name': filename, 'mimeType': mime}
        method = 'POST'
        if existing:
            url = GOOGLE_UPLOAD + '/' + urllib.parse.quote(existing['id'], safe='')
            method = 'PATCH'
        else:
            url = GOOGLE_UPLOAD
            metadata['parents'] = [parent_id]
        url += '?uploadType=resumable&fields=id,name,size,md5Checksum'
        payload = json.dumps(metadata, ensure_ascii=False).encode('utf-8')
        status, _, headers = self.request(url, method=method, body=payload, headers={
            'Content-Type': 'application/json; charset=utf-8',
            'X-Upload-Content-Type': mime,
            'X-Upload-Content-Length': str(size),
        })
        if status not in (200, 201):
            raise DriveError('Could not create resumable upload session HTTP ' + str(status))
        upload_url = headers.get('Location', '')
        if not upload_url:
            raise DriveError('Google upload session has no Location')

        offset = 0
        with path.open('rb') as reader:
            if size == 0:
                status, response, _ = self.request(upload_url, 'PUT', b'', {
                    'Content-Type': mime, 'Content-Length': '0', 'Content-Range': 'bytes */0'
                }, allow308=True)
                if status not in (200, 201):
                    raise DriveError('Empty file upload incomplete')
                result = json.loads(response)
                return result['id'], 'updated' if existing else 'uploaded'

            while offset < size:
                reader.seek(offset)
                chunk = reader.read(min(CHUNK_SIZE, size - offset))
                if not chunk:
                    raise DriveError('Unexpected EOF while uploading ' + filename)
                end = offset + len(chunk) - 1
                try:
                    status, response, response_headers = self.request(upload_url, 'PUT', chunk, {
                        'Content-Type': mime,
                        'Content-Length': str(len(chunk)),
                        'Content-Range': f'bytes {offset}-{end}/{size}',
                    }, allow308=True)
                except DriveError:
                    # A request may have reached Google even when connection died.
                    # Query accepted range and resume without duplicating bytes.
                    status, response, response_headers = self.request(upload_url, 'PUT', b'', {
                        'Content-Length': '0',
                        'Content-Range': f'bytes */{size}',
                    }, allow308=True)
                    if status in (200, 201):
                        result = json.loads(response)
                        return result['id'], 'updated' if existing else 'uploaded'
                    if status != 308:
                        raise DriveError('Cannot determine resumable upload status')
                    accepted = response_headers.get('Range', '')
                    if accepted.startswith('bytes=') and '-' in accepted:
                        offset = int(accepted.rsplit('-', 1)[-1]) + 1
                    else:
                        offset = 0
                    continue

                if status in (200, 201):
                    result = json.loads(response)
                    result_id = result.get('id')
                    if not result_id:
                        raise DriveError('Uploaded file returned no Drive id')
                    return result_id, 'updated' if existing else 'uploaded'
                if status != 308:
                    raise DriveError('Unexpected resumable upload HTTP ' + str(status))
                accepted = response_headers.get('Range', '')
                if accepted.startswith('bytes=') and '-' in accepted:
                    accepted_end = int(accepted.rsplit('-', 1)[-1])
                    offset = accepted_end + 1
                else:
                    offset = 0
        raise DriveError('Upload ended without completion response')


def main() -> int:
    parser = argparse.ArgumentParser(description='AppGuides Drive backup using existing GP OAuth (no token changes)')
    parser.add_argument('--source', required=True, help='Local app-guides root')
    parser.add_argument('--token', required=False, help='Private local copy of existing drive_token.json; required for --upload')
    parser.add_argument('--output', required=True, help='Output directory for reports/manifests')
    parser.add_argument('--upload', action='store_true', help='Explicitly create Drive folders and upload files')
    parser.add_argument('--root-name', default='TunerTools_AppBackup', help='New app-owned root; not the existing manually created tunertools folder')
    args = parser.parse_args()
    source = Path(args.source).expanduser().resolve()
    outdir = Path(args.output).expanduser().resolve()
    if not source.is_dir():
        print('ERROR: source directory does not exist:', source, file=sys.stderr)
        return 2
    if outdir == source or source in outdir.parents:
        print('ERROR: output directory cannot be inside source directory', file=sys.stderr)
        return 2
    entries, warnings = inventory(source, args.upload)
    print('AppGuides files:', len(entries), 'source:', source)
    print('Total MB:', round(sum(x['size_bytes'] for x in entries) / 1048576, 2))
    for category in CATEGORIES:
        print('  ' + category + ':', sum(1 for x in entries if x['relative_path'].startswith(category + '/')))
    if warnings:
        print('Warnings:', len(warnings), '(see report)')
    if not entries and args.upload:
        print('ERROR: No valid guide files to upload. Check --source.', file=sys.stderr)
        return 2

    result = {
        'schema_version': 1,
        'created_at_utc': now(),
        'status': 'uploaded' if args.upload else 'inventory_only',
        'source_dir': str(source),
        'root_folder_name': args.root_name,
        'root_folder_id': None,
        'app_guides_folder_id': None,
        'files': entries,
        'warnings': warnings,
        'total_files': len(entries),
        'total_bytes': sum(x['size_bytes'] for x in entries),
    }
    report = outdir / 'app_guides_drive_manifest.json'
    dump_json(report, result)
    if not args.upload:
        print('CHECK-ONLY. Nothing accessed or changed on Google Drive.')
        print('Manifest:', report)
        return 0

    if not args.token:
        print('ERROR: --token is required when --upload is set', file=sys.stderr)
        return 2
    token_path = Path(args.token).expanduser().resolve()
    if not token_path.is_file():
        print('ERROR: local private OAuth token file is missing', file=sys.stderr)
        return 2

    print('Connecting to Drive with current OAuth client. Token file is never modified.')
    client = DriveClient(token_path)
    root_id = client.ensure_folder(args.root_name, None)
    guides_id = client.ensure_folder('app-guides', root_id)
    result['root_folder_id'] = root_id
    result['app_guides_folder_id'] = guides_id
    dump_json(report, result)
    print('App-created app-guides folder ID:', guides_id)
    folder_ids = {'': guides_id}
    failed = 0
    for i, entry in enumerate(entries, 1):
        rel = Path(entry['relative_path'])
        try:
            parent_key = ''
            parent_id = guides_id
            for part in rel.parts[:-1]:
                next_key = (parent_key + '/' + part).strip('/')
                if next_key not in folder_ids:
                    folder_ids[next_key] = client.ensure_folder(part, parent_id)
                parent_id = folder_ids[next_key]
                parent_key = next_key
            file_id, status = client.upload(parent_id, source / rel, rel.name, entry['md5'])
            entry['drive_file_id'] = file_id
            entry['status'] = status
            print(f'[{i}/{len(entries)}] {status}: {entry["relative_path"]}')
        except Exception as e:
            failed += 1
            entry['status'] = 'error'
            entry['error'] = str(e)
            print(f'[{i}/{len(entries)}] FAILED {entry["relative_path"]}: {e}', file=sys.stderr)
        finally:
            # A manifest written per-file permits recovery after interruption.
            dump_json(report, result)

    template_file = Path(__file__).parent / 'api_guides_drive_check.php'
    if template_file.is_file():
        template = template_file.read_text(encoding='utf-8')
        pattern = r"const TT_GUIDES_ROOT_ID = '[A-Za-z0-9_-]+';"
        if len(re.findall(pattern, template)) == 1:
            patched = re.sub(pattern, "const TT_GUIDES_ROOT_ID = '" + guides_id + "';", template)
            (outdir / 'api_guides_drive_check.php').write_text(patched, encoding='utf-8')
            print('Ready PHP checker:', outdir / 'api_guides_drive_check.php')
    result['status'] = 'complete' if failed == 0 else 'partial_failure'
    result['failed_files'] = failed
    result['completed_at_utc'] = now()
    dump_json(report, result)
    print('Manifest:', report)
    print('App-guides ID for PHP: ', guides_id)
    print('Failed files:', failed)
    return 0 if failed == 0 else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (DriveError, OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print('ERROR:', error, file=sys.stderr)
        sys.exit(1)
