#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TunerTools: audit and import real Songsterr metadata into a FRESH GP catalog.

Read-only source: C:\\inetpub\\wwwroot\\tab\\songsterr_database.db
Writable destination: C:\\TunerToolsGP_Fresh\\gp_fresh_1600000.db

Run an audit first; no changes to the original Songsterr database.
The import retains the original song ID/title/artist, and sets a local path
compatible with tt_gp_bulk.py. It never uploads any files itself.
"""
from __future__ import annotations

import argparse
import csv
import os
import sqlite3
import sys
from pathlib import Path

from tt_gp_bulk import (
    EXTENSIONS, FRESH_MARKER, connect_db, ensure_fresh_run,
    meta_get, meta_set, progress_stats,
)


def open_source(db_file: Path) -> sqlite3.Connection:
    if not db_file.is_file():
        raise SystemExit(f'Source DB not found: {db_file}')
    # URI mode=ro guarantees no writes to the source DB.
    uri = db_file.resolve().as_uri() + '?mode=ro'
    con = sqlite3.connect(uri, uri=True, timeout=60)
    con.execute('PRAGMA query_only=ON')
    try:
        columns = {r[1] for r in con.execute('PRAGMA table_info(songs)')}
    except sqlite3.Error as exc:
        con.close()
        raise SystemExit(f'Cannot inspect source songs table: {exc}') from exc
    expected = {'id', 'title', 'artist', 'file_path', 'format'}
    if not expected <= columns:
        con.close()
        raise SystemExit(f'Source DB missing columns: {sorted(expected - columns)}')
    return con


def clean_relative(raw: str | None, prefix: str) -> str | None:
    """Normalize database paths, reject traversal and external paths."""
    if raw is None:
        return None
    s = str(raw).strip().replace('\\', '/')
    if not s or s.startswith('/') or ':' in s or '\x00' in s:
        return None
    while s.startswith('./'):
        s = s[2:]
    parts = s.split('/')
    if not parts or any(x in ('', '.', '..') for x in parts):
        return None
    if parts[0].lower() == prefix.lower():
        parts = parts[1:]
    if not parts:
        return None
    return '/'.join(parts)


def locate_file(root: Path, rel: str, extras: tuple[str, ...]) -> tuple[Path, str] | None:
    """Try path relative to 'tab', then optionally 'tab/Kho_Tab_Songsterr'."""
    candidates = [rel]
    for extra in extras:
        if rel.casefold().startswith(extra.casefold() + '/'):
            continue
        candidates.append(extra + '/' + rel)
    for candidate in candidates:
        path = root.joinpath(*candidate.split('/'))
        if path.is_file() and path.suffix.lower() in EXTENSIONS:
            return path, candidate
    return None


def source_counts(con: sqlite3.Connection) -> tuple[int, int, int, int]:
    row = con.execute('''
        SELECT COUNT(*),
               SUM(CASE WHEN TRIM(COALESCE(id,''))='' THEN 1 ELSE 0 END),
               SUM(CASE WHEN TRIM(COALESCE(file_path,''))='' THEN 1 ELSE 0 END),
               SUM(CASE WHEN TRIM(COALESCE(id,''))<>'' AND
                             TRIM(COALESCE(file_path,''))<>'' THEN 1 ELSE 0 END)
        FROM songs
    ''').fetchone()
    return tuple(int(x or 0) for x in row)


def audit(args: argparse.Namespace, root: Path, src: sqlite3.Connection) -> None:
    total, blank_id, blank_path, candidate = source_counts(src)
    print('=== AUDIT SONGSTERR (READ ONLY) ===', flush=True)
    print(f'Rows: {total:,} | Empty IDs: {blank_id:,} | Empty paths: {blank_path:,}')
    print(f'Rows with both ID and path: {candidate:,}')
    maxrow = int(src.execute('SELECT MAX(rowid) FROM songs').fetchone()[0] or 0)
    sample_size = max(1, min(200, args.samples, maxrow))
    present = absent = invalid = 0
    found_examples, bad_examples = [], []
    for index in range(sample_size):
        rowid = 1 + (maxrow - 1) * index // max(1, sample_size - 1)
        row = src.execute('''
            SELECT id, file_path FROM songs
            WHERE rowid >= ? AND TRIM(COALESCE(id,'')) <> ''
              AND TRIM(COALESCE(file_path,'')) <> ''
            ORDER BY rowid LIMIT 1
        ''', (rowid,)).fetchone()
        if row is None:
            continue
        rel = clean_relative(row[1], root.name)
        if rel is None:
            invalid += 1
            if len(bad_examples) < 8:
                bad_examples.append(str(row[1]))
            continue
        match = locate_file(root, rel, args.extra)
        if match is not None:
            present += 1
            if len(found_examples) < 5:
                found_examples.append(match[1])
        else:
            absent += 1
            if len(bad_examples) < 8:
                bad_examples.append(rel)
    print(f'Sampled: present={present}, missing={absent}, invalid_path={invalid}')
    for path in found_examples:
        print('  OK:', path)
    for path in bad_examples:
        print('  NOT FOUND:', path)
    print('No DB changes and no Google Drive uploads.')
    if not present:
        print('WARNING: No local paths matched. Check --source before import.')


def import_catalog(args: argparse.Namespace, root: Path, src: sqlite3.Connection) -> None:
    target = Path(args.db).expanduser().resolve()
    if target == Path(args.original).expanduser().resolve():
        raise SystemExit('Source DB and destination DB must be different.')
    if target.is_relative_to(root):
        raise SystemExit('Destination DB must be outside your source folder.')
    if not target.is_file():
        raise SystemExit('Fresh destination DB missing. Restore the EMPTY fresh DB first.')
    dst = connect_db(target)
    report = target.with_name('songsterr_import_missing_samples.csv')
    try:
        ensure_fresh_run(dst)
        previous_source = meta_get(dst, 'local_source')
        if previous_source and previous_source != str(root):
            raise SystemExit(f'Target belongs to another source folder: {previous_source}')
        previous_prefix = meta_get(dst, 'relative_prefix')
        if previous_prefix and previous_prefix != root.name:
            raise SystemExit(f'Target path prefix is {previous_prefix!r}, not {root.name!r}')
        previous_import = meta_get(dst, 'metadata_source')
        original = str(Path(args.original).expanduser().resolve())
        if previous_import and previous_import != original:
            raise SystemExit(f'Different import already registered: {previous_import}')
        existing = dst.execute('SELECT COUNT(*) FROM songs').fetchone()[0]
        uploaded = dst.execute("SELECT COUNT(*) FROM songs WHERE COALESCE(TRIM(drive_file_id),'') <> ''").fetchone()[0]
        if uploaded:
            raise SystemExit('Target already contains Drive IDs; do not change metadata while uploading.')
        if existing and not previous_import:
            raise SystemExit('Target has existing rows from scan. Do not overwrite it. '
                             'Make a NEW empty DB or contact before importing.')
        meta_set(dst, 'metadata_source', original)
        meta_set(dst, 'local_source', str(root))
        meta_set(dst, 'relative_prefix', root.name)

        stats = dict(scanned=0, inserted=0, missing_id=0,
                     missing_path=0, unsafe_path=0, missing_file=0, invalid_ext=0,
                     duplicates=0)
        missing_examples = 0
        print('Import original metadata. This process does NOT upload files.', flush=True)
        with report.open('w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(['reason', 'song_id', 'original_file_path'])
            cursor = src.execute('SELECT id,title,artist,file_path,format FROM songs')
            for row in cursor:
                stats['scanned'] += 1
                sid, title, artist, raw_path, fmt = row
                sid = str(sid).strip() if sid is not None else ''
                if not sid:
                    stats['missing_id'] += 1
                    continue
                if raw_path is None or not str(raw_path).strip():
                    stats['missing_path'] += 1
                    continue
                rel = clean_relative(raw_path, root.name)
                if rel is None:
                    stats['unsafe_path'] += 1
                    continue
                if Path(rel).suffix.lower() not in EXTENSIONS:
                    stats['invalid_ext'] += 1
                    continue
                located = locate_file(root, rel, args.extra)
                if located is None:
                    stats['missing_file'] += 1
                    if missing_examples < 200:
                        writer.writerow(['missing_file', sid, raw_path])
                        missing_examples += 1
                    continue
                local_file, resolved_relative = located
                full_path = root.name + '/' + resolved_relative
                try:
                    cur = dst.execute('''
                        INSERT OR IGNORE INTO songs
                          (id,title,artist,file_path,format,drive_file_id,local_test_path)
                        VALUES (?,?,?,?,?,NULL,?)
                    ''', (sid, title or local_file.stem, artist or '', full_path,
                          local_file.suffix.lower().lstrip('.'), str(local_file)))
                    if cur.rowcount:
                        stats['inserted'] += 1
                    else:
                        stats['duplicates'] += 1
                except sqlite3.Error as exc:
                    dst.rollback()
                    raise SystemExit(f'SQLite error at row {stats["scanned"]}: {exc}') from exc
                if stats['scanned'] % 5000 == 0:
                    dst.commit()
                if stats['scanned'] % 100000 == 0:
                    print(f'  Read {stats["scanned"]:,} | Inserted {stats["inserted"]:,} '
                          f'| Missing physical files {stats["missing_file"]:,}', flush=True)
            dst.commit()
        print('=== IMPORT SUMMARY ===')
        for key, count in stats.items():
            print(f'{key}: {count:,}')
        print('Missing-file examples:', report)
        progress_stats(dst)
        print('NEXT: run tt_gp_bulk.py scan to add unlisted physical files and rebuild FTS5.')
        print('No uploads performed. Original DB was opened read-only.')
    finally:
        dst.close()


def main() -> None:
    ap = argparse.ArgumentParser(description='Audit/import real Songsterr metadata (never uploads)')
    ap.add_argument('command', choices=('audit', 'import'))
    ap.add_argument('--original', default=r'C:\inetpub\wwwroot\tab\songsterr_database.db')
    ap.add_argument('--source', default=r'C:\inetpub\wwwroot\tab')
    ap.add_argument('--db', default='gp_fresh_1600000.db')
    ap.add_argument('--extra', action='append', default=['Kho_Tab_Songsterr'],
                    help='Fallback folder relative to --source for original paths')
    ap.add_argument('--samples', type=int, default=150)
    args = ap.parse_args()
    root = Path(args.source).expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f'GP source folder not found: {root}')
    source_db = Path(args.original).expanduser().resolve()
    with open_source(source_db) as src:
        if args.command == 'audit':
            audit(args, root, src)
        elif args.command == 'import':
            import_catalog(args, root, src)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        raise SystemExit('\nStopped. Import is resumable; do not delete the destination DB.')
