from __future__ import annotations

import importlib.util
import hashlib
import threading
import json
import mimetypes
import platform
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .audio_tools import command_exists
from .config import settings
from .demo_score import create_demo_musicxml, demo_note_events
from .job_store import JobNotFoundError, job_store
from .processor import submit_job
from .playback_modes import prepare_variants, midi_to_events, write_mode_midi
from .live_score import create_arrangement_xml
from .security import validate_audio_filename, validate_youtube_url


app = FastAPI(
    title="AudioSheet Studio",
    version="1.0.6",
    description="Local-first audio-to-MIDI and MusicXML transcription web app.",
)
app.mount("/static", StaticFiles(directory=settings.web_dir), name="static")
_score_cache_lock = threading.Lock()  # prevent simultaneous writes to same score
PIANO_SAMPLES = ("A0", "C1", "Ds1", "Fs1", "A1", "C2", "Ds2", "Fs2", "A2", "C3", "Ds3", "Fs3", "A3", "C4", "Ds4", "Fs4", "A4", "C5", "Ds5", "Fs5", "A5", "C6", "Ds6", "Fs6", "A6", "C7", "Ds7", "Fs7", "A7", "C8")


async def _save_upload(upload: UploadFile, destination: Path, limit_bytes: int) -> int:
    total = 0
    try:
        with destination.open("wb") as handle:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit_bytes:
                    raise ValueError(
                        f"Upload is larger than the configured {settings.max_upload_mb} MB limit"
                    )
                handle.write(chunk)
    finally:
        await upload.close()
    if total == 0:
        raise ValueError("The uploaded file is empty")
    return total


def _get_public_job(job_id: str) -> dict:
    try:
        return job_store.public(job_store.get(job_id))
    except JobNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Job not found") from exc


@app.get("/api/health")
def health() -> dict:
    return {
        "status": "ok",
        "version": "1.0.6",
        "piano_playback_modes": ["melody", "light", "full"],
        "dynamic_musicxml": True,
        "sampled_piano_files": sum(
            (settings.web_dir / "piano_samples" / (name + ".mp3")).is_file()
            for name in PIANO_SAMPLES
        ),
        "sampled_piano_expected": len(PIANO_SAMPLES),
        "python": platform.python_version(),
        "ffmpeg": command_exists("ffmpeg") and command_exists("ffprobe"),
        "basic_pitch": importlib.util.find_spec("basic_pitch") is not None,
        "music21": importlib.util.find_spec("music21") is not None,
        "yt_dlp": importlib.util.find_spec("yt_dlp") is not None,
        "youtube_enabled": settings.allow_youtube,
        "local_osmd": (settings.web_dir / "vendor" / "opensheetmusicdisplay.min.js").exists(),
        "limits": {
            "max_upload_mb": settings.max_upload_mb,
            "max_audio_seconds": settings.max_audio_seconds,
            "workers": settings.worker_count,
        },
    }


@app.post("/api/jobs", status_code=202)
async def create_job(
    audio_file: Annotated[UploadFile | None, File()] = None,
    youtube_url: Annotated[str | None, Form()] = None,
    title: Annotated[str, Form()] = "",
    mode: Annotated[str, Form()] = "piano",
    bpm: Annotated[float, Form()] = 0,
    time_signature: Annotated[str, Form()] = "4/4",
    quantization: Annotated[int, Form()] = 16,
    split_pitch: Annotated[int, Form()] = 60,
    minimum_midi: Annotated[int, Form()] = 36,
    maximum_midi: Annotated[int, Form()] = 96,
    onset_threshold: Annotated[float, Form()] = 0.5,
    frame_threshold: Annotated[float, Form()] = 0.3,
    minimum_note_length_ms: Annotated[float, Form()] = 127.7,
    accepted_rights: Annotated[bool, Form()] = False,
) -> dict:
    has_file = audio_file is not None and bool(audio_file.filename)
    has_url = bool((youtube_url or "").strip())
    if has_file == has_url:
        raise HTTPException(status_code=400, detail="Choose exactly one input: audio file or YouTube URL")
    if not accepted_rights:
        raise HTTPException(status_code=400, detail="You must confirm that you have the right to process this audio")
    if mode not in {"piano", "lead", "raw"}:
        raise HTTPException(status_code=400, detail="Mode must be piano, lead, or raw")
    if time_signature not in {"4/4", "3/4", "6/8"}:
        raise HTTPException(status_code=400, detail="Unsupported time signature")
    if quantization not in {8, 16, 32}:
        raise HTTPException(status_code=400, detail="Quantization must be 8, 16, or 32")
    if bpm != 0 and not 40 <= bpm <= 240:
        raise HTTPException(status_code=400, detail="BPM must be 0 for automatic detection or between 40 and 240")
    if not 36 <= split_pitch <= 84:
        raise HTTPException(status_code=400, detail="Piano split pitch must be between MIDI 36 and 84")
    if not 0 <= minimum_midi < maximum_midi <= 127:
        raise HTTPException(status_code=400, detail="Invalid MIDI note range")
    if not 0.05 <= onset_threshold <= 0.95 or not 0.05 <= frame_threshold <= 0.95:
        raise HTTPException(status_code=400, detail="Detection thresholds must be between 0.05 and 0.95")
    if not 20 <= minimum_note_length_ms <= 1000:
        raise HTTPException(status_code=400, detail="Minimum note length must be between 20 and 1000 ms")

    clean_title = title.strip()[:200]
    payload = {
        "source_type": "upload" if has_file else "youtube",
        "source_name": "",
        "title": clean_title,
        "mode": mode,
        "bpm_requested": float(bpm),
        "bpm_used": None,
        "time_signature": time_signature,
        "quantization": int(quantization),
        "split_pitch": int(split_pitch),
        "minimum_midi": int(minimum_midi),
        "maximum_midi": int(maximum_midi),
        "onset_threshold": float(onset_threshold),
        "frame_threshold": float(frame_threshold),
        "minimum_note_length_ms": float(minimum_note_length_ms),
        "duration_seconds": None,
    }

    if has_url:
        if not settings.allow_youtube:
            raise HTTPException(status_code=403, detail="YouTube input is disabled by the server")
        try:
            payload["youtube_url"] = validate_youtube_url(youtube_url or "")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    job = job_store.create(payload)
    try:
        if has_file and audio_file is not None:
            safe_name = validate_audio_filename(audio_file.filename or "audio")
            suffix = Path(safe_name).suffix.lower()
            stored_name = f"source{suffix}"
            destination = job_store.job_dir(job["id"]) / stored_name
            await _save_upload(
                audio_file,
                destination,
                limit_bytes=settings.max_upload_mb * 1024 * 1024,
            )
            source_name = Path(safe_name).stem[:200]
            job = job_store.update(
                job["id"],
                source_filename=stored_name,
                source_name=source_name,
                title=clean_title or source_name,
            )
        submit_job(job["id"])
        return job_store.public(job)
    except ValueError as exc:
        job_store.delete(job["id"])
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:
        job_store.delete(job["id"])
        raise


@app.post("/api/demo", status_code=201)
def create_demo(mode: str = "piano") -> dict:
    if mode not in {"piano", "lead", "raw"}:
        raise HTTPException(status_code=400, detail="Mode must be piano, lead, or raw")
    job = job_store.create(
        {
            "source_type": "demo",
            "source_name": "Built-in C major demo",
            "title": "AudioSheet Studio Demo",
            "mode": mode,
            "bpm_requested": 100.0,
            "bpm_used": 100.0,
            "time_signature": "4/4",
            "quantization": 16,
            "duration_seconds": 9.6,
        }
    )
    try:
        filename = "sheet.musicxml"
        create_demo_musicxml(job_store.job_dir(job["id"]) / filename, mode=mode)
        job = job_store.update(
            job["id"],
            status="done",
            progress=100,
            message="Demo score is ready",
            artifacts=[
                {
                    "filename": filename,
                    "label": "Demo MusicXML sheet",
                    "kind": "musicxml",
                    "url": f"/api/jobs/{job['id']}/files/{filename}",
                }
            ],
        )
        return job_store.public(job)
    except Exception as exc:
        job_store.update(job["id"], status="failed", progress=100, error=str(exc), message="Demo failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc


def _playback_for_job(job_id: str) -> tuple[dict, dict]:
    """Create playback variants for both NEW and already completed v1.0.3 jobs."""
    job = _get_public_job(job_id)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail="The transcription is not finished yet")
    directory = job_store.job_dir(job_id)
    note_file = directory / "note_events.json"
    if note_file.is_file():
        try:
            original = json.loads(note_file.read_text(encoding="utf-8"))
        except (ValueError, OSError) as exc:
            raise HTTPException(status_code=422, detail="Could not read the note events JSON") from exc
        if not isinstance(original, list):
            raise HTTPException(status_code=422, detail="Invalid note events JSON")
    elif job.get("source_type") == "demo":
        original = [
            {"start": a, "end": b, "pitch": p, "velocity": round(v * 127)}
            for a, b, p, v, _ in demo_note_events()
        ]
    else:
        raise HTTPException(status_code=404, detail="This job does not have note_events.json")

    reference_file = directory / "reference.mid"
    reference = None
    if reference_file.is_file():
        try:
            reference = midi_to_events(str(reference_file))
        except (ValueError, OSError, EOFError) as exc:
            raise HTTPException(status_code=422, detail="Invalid reference MIDI: " + str(exc)[:180]) from exc
    return prepare_variants(original, reference), job


@app.get("/api/jobs/{job_id}/playback")
def get_job_playback(job_id: str) -> dict:
    return _playback_for_job(job_id)[0]


@app.get("/api/jobs/{job_id}/playback-midi/{variant}")
def download_playback_midi(job_id: str, variant: str) -> FileResponse:
    if variant not in {"melody", "light", "full"}:
        raise HTTPException(status_code=400, detail="Unknown playback arrangement")
    payload, job = _playback_for_job(job_id)
    notes = payload["modes"][variant]["notes"]
    if not notes:
        raise HTTPException(status_code=422, detail="There are no notes in this arrangement")
    destination = job_store.job_dir(job_id) / f"piano_{variant}.mid"
    write_mode_midi(notes, str(destination), bpm=float(job.get("bpm_used") or 100))
    return FileResponse(destination, media_type="audio/midi", filename=f"AudioSheet_{variant}.mid")


@app.get("/api/jobs/{job_id}/playback-score/{variant}")
def download_playback_score(job_id: str, variant: str) -> FileResponse:
    """MusicXML re-created from exactly the notes selected for A, B or C.

    Does not run Basic Pitch again; older completed jobs are supported.
    C is invalidated automatically when the optional reference MIDI changes.
    """
    if variant not in {"melody", "light", "full"}:
        raise HTTPException(status_code=400, detail="Unknown sheet arrangement")
    payload, job = _playback_for_job(job_id)
    notes = payload["modes"][variant]["notes"]
    if not notes:
        raise HTTPException(status_code=422, detail="No notes in this arrangement")
    directory = job_store.job_dir(job_id)
    source = directory / "note_events.json"
    reference = directory / "reference.mid"
    def identity(path: Path) -> str:
        if not path.is_file():
            return "missing"
        stat = path.stat()
        return f"{stat.st_mtime_ns}:{stat.st_size}"
    bpm = float(job.get("bpm_used") or 100)
    time_signature = str(job.get("time_signature") or "4/4")
    quantization = int(job.get("quantization") or 16)
    split_pitch = int(job.get("split_pitch") or 60)
    signature = "|".join([
        "score_v106", variant, identity(source),
        identity(reference) if variant == "full" else "no_reference",
        str(bpm), time_signature, str(quantization), str(split_pitch),
        str(job.get("title") or ""),
    ])
    checksum = hashlib.sha256(signature.encode("utf-8")).hexdigest()[:16]
    destination = directory / f"piano_mode_{variant}_{checksum}.musicxml"
    with _score_cache_lock:
        if not destination.is_file():
            try:
                xml = create_arrangement_xml(
                    notes, variant, title=str(job.get("title") or "AudioSheet Studio"),
                    bpm=bpm, time_signature=time_signature,
                    quantization=quantization, split_pitch=split_pitch,
                    duration_seconds=payload["duration_seconds"],
                )
            except (TypeError, ValueError) as exc:
                raise HTTPException(status_code=422, detail="Could not arrange MusicXML: " + str(exc)[:180]) from exc
            temp = destination.with_suffix(".musicxml.tmp")
            temp.write_bytes(xml)
            temp.replace(destination)
            # Avoid accumulating many old C scores when reference MIDI changes.
            for stale in directory.glob(f"piano_mode_{variant}_*.musicxml"):
                if stale != destination:
                    stale.unlink(missing_ok=True)
    return FileResponse(
        destination,
        media_type="application/vnd.recordare.musicxml+xml",
        filename=f"AudioSheet_{variant}.musicxml",
        headers={"Cache-Control": "no-store"},
    )


@app.post("/api/jobs/{job_id}/reference-midi")
async def upload_reference_midi(job_id: str, midi_file: Annotated[UploadFile, File()]) -> dict:
    """Optional manual MIDI comparison, e.g. user's Ledutu export for mode C."""
    job = _get_public_job(job_id)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail="Choose a completed transcription")
    source_name = Path(midi_file.filename or "").name
    if Path(source_name).suffix.lower() not in {".mid", ".midi"}:
        await midi_file.close()
        raise HTTPException(status_code=400, detail="Please select a .mid or .midi file")
    destination = job_store.job_dir(job_id) / "reference.mid"
    temp = destination.with_suffix(".mid.upload")
    try:
        await _save_upload(midi_file, temp, limit_bytes=4 * 1024 * 1024)
        with temp.open("rb") as handle:
            if handle.read(4) != b"MThd":
                raise ValueError("Not a valid MIDI file")
        midi_to_events(str(temp))
        temp.replace(destination)
    except ValueError as exc:
        temp.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc)[:260]) from exc
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    return _playback_for_job(job_id)[0]


@app.delete("/api/jobs/{job_id}/reference-midi", status_code=204)
def delete_reference_midi(job_id: str) -> None:
    job = _get_public_job(job_id)
    if job.get("status") != "done":
        raise HTTPException(status_code=409, detail="Choose a completed transcription")
    (job_store.job_dir(job_id) / "reference.mid").unlink(missing_ok=True)


@app.get("/api/jobs")
def list_jobs(limit: int = 20) -> list[dict]:
    return [job_store.public(job) for job in job_store.list_recent(limit)]


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict:
    return _get_public_job(job_id)


@app.delete("/api/jobs/{job_id}", status_code=204)
def delete_job(job_id: str) -> None:
    try:
        job_store.delete(job_id)
    except JobNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Job not found") from exc


@app.get("/api/jobs/{job_id}/files/{filename}")
def get_job_file(job_id: str, filename: str) -> FileResponse:
    job = _get_public_job(job_id)
    allowed = {artifact["filename"] for artifact in job.get("artifacts", [])}
    if filename not in allowed:
        raise HTTPException(status_code=404, detail="Artifact not found")
    path = job_store.job_dir(job_id) / Path(filename).name
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Artifact not found")
    media_type, _ = mimetypes.guess_type(path.name)
    if path.suffix.lower() in {".musicxml", ".xml"}:
        media_type = "application/vnd.recordare.musicxml+xml"
    return FileResponse(path, media_type=media_type or "application/octet-stream", filename=path.name)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(settings.web_dir / "index.html")
