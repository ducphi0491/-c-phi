(() => {
  "use strict";

  const form = document.getElementById("transcriptionForm");
  const audioFile = document.getElementById("audioFile");
  const youtubeUrl = document.getElementById("youtubeUrl");
  const dropZone = document.getElementById("dropZone");
  const fileLabel = document.getElementById("fileLabel");
  const submitButton = document.getElementById("submitButton");
  const demoButton = document.getElementById("demoButton");
  const jobSection = document.getElementById("jobSection");
  const resultSection = document.getElementById("resultSection");
  const toast = document.getElementById("toast");

  let activeSource = "upload";
  let currentJobId = null;
  let pollToken = 0;
  let osmd = null;
  let osmdPromise = null;
  let scoreRenderToken = 0;
  let lastJobForScore = null;
  let zoom = 1.0;
  let playbackData = null;
  let playbackMode = 'light';
  let userSeeking = false;
  const pianoPlay = document.getElementById('pianoPlay');
  const pianoStop = document.getElementById('pianoStop');
  const pianoSeek = document.getElementById('pianoSeek');
  const pianoStatus = document.getElementById('playbackStatus');
  const pianoTime = document.getElementById('pianoTime');
  const pianoSoundStatus = document.getElementById('pianoSoundStatus');
  const activeSheetDownload = document.getElementById('activeSheetDownload');
  const referenceMidiFile = document.getElementById('referenceMidiFile');
  const removeReference = document.getElementById('clearReferenceMidi');
  const pianoPlayer = new window.AudioSheetPianoPlayer({
    onUpdate: ({ time, duration, playing }) => {
      pianoPlay.textContent = playing ? '❚❚ Tạm dừng' : '▶ Phát piano';
      pianoTime.textContent = `${formatTime(time)} / ${formatTime(duration)}`;
      if (!userSeeking) pianoSeek.value = String(duration ? Math.round(1000 * time / duration) : 0);
    },
    onLoading: ({ message, failed }) => {
      pianoSoundStatus.textContent = message;
      pianoSoundStatus.classList.toggle('warning', !!failed);
    },
  });

  function formatTime(seconds) {
    const value = Math.max(0, Math.floor(seconds || 0));
    return `${Math.floor(value / 60)}:${String(value % 60).padStart(2, '0')}`;
  }

  function choosePlaybackMode(mode) {
    if (!playbackData || !playbackData.modes || !playbackData.modes[mode]) return;
    playbackMode = mode;
    document.querySelectorAll('.playback-mode').forEach(label => {
      const selected = label.dataset.playbackMode === mode;
      label.classList.toggle('selected', selected);
      const radio = label.querySelector('input');
      if (radio) radio.checked = selected;
    });
    const chosen = playbackData.modes[mode];
    pianoPlayer.setNotes(chosen.notes, playbackData.duration_seconds, mode);
    pianoPlay.disabled = chosen.notes.length === 0;
    pianoStop.disabled = chosen.notes.length === 0;
    pianoSeek.disabled = chosen.notes.length === 0;
    pianoStatus.textContent = `${chosen.count.toLocaleString('vi-VN')} nốt`;
    // A/B/C update both the sound AND the score (old v1.0.5 only changed sound).
    if (currentJobId && lastJobForScore === currentJobId) {
      renderArrangementSheet(currentJobId, mode);
    }
    document.getElementById('playbackHint').textContent =
      mode === 'melody' ? 'A: rút giai điệu chính, nối một số nốt ngắt vụn. Có thể bỏ sót nốt thật.' :
      mode === 'light' ? 'B: giai điệu + nốt bass thưa, được giảm âm lượng để tiếng đàn bớt dày.' :
      playbackData.reference_active ? 'C: đang phát MIDI ngoài do bạn chọn. Không phải kết quả dự đoán của AI.' :
      'C: toàn bộ nốt AI nhận dạng, để nghe đối chiếu với hai chế độ đã lọc.';
  }

  function refreshPlaybackPanel() {
    if (!playbackData) return;
    for (const [id, mode] of [['countMelody', 'melody'], ['countLight', 'light'], ['countFull', 'full']]) {
      const item = playbackData.modes[mode];
      document.getElementById(id).textContent = `${item.count.toLocaleString('vi-VN')} nốt`;
    }
    const active = playbackData.reference_active;
    document.getElementById('fullModeLabel').textContent = active ? 'C · MIDI tham chiếu' : 'C · Toàn bộ nốt AI';
    document.getElementById('midiComparisonText').textContent = active
      ? `C đang phát MIDI đối chiếu; đã căn thời điểm nốt đầu (dịch ${playbackData.reference_offset_seconds || 0}s). Chưa đồng bộ BPM hoặc nhịp. Bấm 'Bỏ' để quay lại nốt AI.`
      : 'C mặc định phát tất cả nốt AI. Muốn so với Ledutu, chọn file .mid do Ledutu xuất.';
    removeReference.classList.toggle('hidden', !active);
    choosePlaybackMode(playbackMode);
  }

  function clearPlaybackUi() {
    pianoPlayer.stop();
    playbackData = null;
    pianoPlay.disabled = true;
    pianoStop.disabled = true;
    pianoSeek.disabled = true;
    pianoSeek.value = '0';
    pianoStatus.textContent = 'Đang chuẩn bị';
    pianoSoundStatus.textContent = 'Piano ghi âm Salamander: tải mẫu khi nhấn Phát.';
    pianoSoundStatus.classList.remove('warning');
    lastJobForScore = null;
    scoreRenderToken++;
    const selectedSheet = document.getElementById('activeSheetDownload');
    if (selectedSheet) { selectedSheet.removeAttribute('href'); selectedSheet.classList.add('hidden'); }
    document.getElementById('scoreModeTitle').textContent = 'Sheet nhạc đang chọn';
  }

  async function loadPlayback(job) {
    clearPlaybackUi();
    try {
      const payload = await requestJson(`/api/jobs/${job.id}/playback`);
      if (currentJobId !== job.id) return;
      playbackData = payload;
      lastJobForScore = job.id;
      refreshPlaybackPanel();
      const controls = document.getElementById('downloadButtons');
      ['melody', 'light', 'full'].forEach((mode, i) => {
        const midi = document.createElement('a');
        midi.href = `/api/jobs/${job.id}/playback-midi/${mode}`;
        midi.download = `AudioSheet_${mode}.mid`;
        midi.textContent = `MIDI ${['A', 'B', 'C'][i]}`;
        midi.className = 'playback-download';
        controls.appendChild(midi);
        const xml = document.createElement('a');
        xml.href = `/api/jobs/${job.id}/playback-score/${mode}`;
        xml.download = `AudioSheet_${mode}.musicxml`;
        xml.textContent = `Sheet ${['A', 'B', 'C'][i]}`;
        xml.className = 'playback-download sheet-download';
        controls.appendChild(xml);
      });
      return true;
    } catch (error) {
      pianoStatus.textContent = 'Không tải được nốt';
      document.getElementById('playbackHint').textContent =
        `Không nạp được dữ liệu phát đàn: ${error.message || String(error)}. ` +
        'Sheet nhạc và các file xuất trước đó vẫn sử dụng bình thường.';
      return false;
    }
  }

  document.querySelectorAll('input[name="playback_mode"]').forEach(radio => {
    radio.addEventListener('change', () => {
      if (radio.checked) choosePlaybackMode(radio.value);
    });
  });

  pianoPlay.addEventListener('click', async () => {
    try {
      if (pianoPlayer.isPlaying) {
        pianoPlayer.pause();
      } else {
        document.getElementById('audioPlayer').pause();
        pianoPlay.disabled = true;
        await pianoPlayer.play();
      }
    } catch (error) {
      showToast(`Khong the phat piano: ${error.message || error}`, true);
    } finally {
      pianoPlay.disabled = !(playbackData && playbackData.modes[playbackMode].notes.length);
    }
  });
  pianoStop.addEventListener('click', () => pianoPlayer.stop());
  pianoSeek.addEventListener('pointerdown', () => { userSeeking = true; });
  pianoSeek.addEventListener('pointerup', () => { window.setTimeout(() => { userSeeking = false; }, 50); });
  pianoSeek.addEventListener('input', () => {
    if (!playbackData) return;
    userSeeking = true;
    pianoTime.textContent = `${formatTime(Number(pianoSeek.value) / 1000 * pianoPlayer.duration)} / ${formatTime(pianoPlayer.duration)}`;
  });
  pianoSeek.addEventListener('change', async () => {
    userSeeking = false;
    try { await pianoPlayer.seek(Number(pianoSeek.value) / 1000 * pianoPlayer.duration); }
    catch (error) { showToast(error.message || String(error), true); }
  });
  document.getElementById('pianoVolume').addEventListener('input', event => {
    pianoPlayer.setVolume(Number(event.target.value) / 100);
  });
  document.getElementById('audioPlayer').addEventListener('play', () => pianoPlayer.pause());

  referenceMidiFile.addEventListener('change', async () => {
    const midi = referenceMidiFile.files && referenceMidiFile.files[0];
    if (!midi || !currentJobId) return;
    if (midi.size > 4 * 1024 * 1024) {
      showToast('MIDI doi chieu phai nho hon 4 MB.', true);
      referenceMidiFile.value = '';
      return;
    }
    const jobId = currentJobId;
    try {
      pianoPlayer.stop();
      pianoStatus.textContent = 'Đang nạp MIDI';
      const data = new FormData();
      data.append('midi_file', midi);
      const payload = await requestJson(`/api/jobs/${jobId}/reference-midi`, { method: 'POST', body: data });
      if (currentJobId !== jobId) return;
      playbackData = payload;
      playbackMode = 'full';
      refreshPlaybackPanel();
      showToast('Da nap MIDI doi chieu. Bam Phat piano de nghe che do C.');
    } catch (error) {
      pianoStatus.textContent = 'Lỗi nạp MIDI';
      showToast(error.message || String(error), true);
    } finally {
      referenceMidiFile.value = '';
    }
  });

  removeReference.addEventListener('click', async () => {
    if (!currentJobId) return;
    const jobId = currentJobId;
    try {
      await fetch(`/api/jobs/${jobId}/reference-midi`, { method: 'DELETE' }).then(response => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
      });
      if (currentJobId !== jobId) return;
      playbackData = await requestJson(`/api/jobs/${jobId}/playback`);
      playbackMode = 'full';
      refreshPlaybackPanel();
      showToast('Da quay lai cac not AI o che do C.');
    } catch (error) { showToast(error.message || String(error), true); }
  });


  const statusRank = {
    queued: 0,
    fetching: 0,
    normalizing: 1,
    transcribing: 2,
    arranging: 3,
    done: 4,
    failed: -1,
  };

  const statusText = {
    queued: "Dang cho bo xu ly",
    fetching: "Dang lay nguon am thanh",
    normalizing: "Dang chuan hoa am thanh",
    transcribing: "AI dang nhan dang not",
    arranging: "Dang tao khuong nhac",
    done: "Da hoan tat",
    failed: "Xu ly that bai",
  };

  function showToast(message, isError = false) {
    toast.textContent = message;
    toast.classList.toggle("error", isError);
    toast.classList.add("show");
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3600);
  }

  async function requestJson(url, options = {}) {
    const response = await fetch(url, options);
    let payload = null;
    try {
      payload = await response.json();
    } catch (_) {
      payload = null;
    }
    if (!response.ok) {
      const message = payload && payload.detail ? payload.detail : `HTTP ${response.status}`;
      throw new Error(message);
    }
    return payload;
  }

  function switchSource(source) {
    activeSource = source;
    document.querySelectorAll(".source-tab").forEach((button) => {
      const active = button.dataset.source === source;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
    });
    document.getElementById("uploadSource").classList.toggle("active", source === "upload");
    document.getElementById("youtubeSource").classList.toggle("active", source === "youtube");
  }

  document.querySelectorAll(".source-tab").forEach((button) => {
    button.addEventListener("click", () => switchSource(button.dataset.source));
  });

  function updateFileLabel(file) {
    if (!file) {
      fileLabel.innerHTML = "K&#233;o th&#7843; file v&#224;o &#273;&#226;y ho&#7863;c b&#7845;m &#273;&#7875; ch&#7885;n";
      return;
    }
    const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
    fileLabel.textContent = `${file.name} (${sizeMb} MB)`;
  }

  audioFile.addEventListener("change", () => updateFileLabel(audioFile.files[0]));
  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.add("dragging");
    });
  });
  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.remove("dragging");
    });
  });
  dropZone.addEventListener("drop", (event) => {
    const files = event.dataTransfer.files;
    if (!files || !files.length) return;
    const transfer = new DataTransfer();
    transfer.items.add(files[0]);
    audioFile.files = transfer.files;
    updateFileLabel(files[0]);
  });

  function validateClientInput() {
    if (activeSource === "upload" && !audioFile.files.length) {
      throw new Error("Hay chon mot file am thanh.");
    }
    if (activeSource === "youtube" && !youtubeUrl.value.trim()) {
      throw new Error("Hay dan link YouTube.");
    }
    if (!document.getElementById("acceptedRights").checked) {
      throw new Error("Ban can xac nhan quyen su dung noi dung am thanh.");
    }
  }

  function makeFormData() {
    const data = new FormData(form);
    if (activeSource === "upload") {
      data.delete("youtube_url");
    } else {
      data.delete("audio_file");
    }
    if (!document.getElementById("acceptedRights").checked) {
      data.set("accepted_rights", "false");
    }
    return data;
  }

  function resetJobUi() {
    clearPlaybackUi();
    resultSection.classList.add("hidden");
    document.getElementById("jobError").classList.add("hidden");
    document.getElementById("jobError").textContent = "";
    jobSection.classList.remove("hidden");
  }

  function renderJob(job) {
    const progress = Number(job.progress || 0);
    document.getElementById("jobTitle").textContent = job.title || job.source_name || "Tao ban nhac";
    document.getElementById("jobPercent").textContent = `${Math.round(progress)}%`;
    document.getElementById("progressBar").style.width = `${Math.max(0, Math.min(100, progress))}%`;
    document.getElementById("jobMessage").textContent = job.message || statusText[job.status] || job.status;
    const rank = statusRank[job.status] ?? 0;
    document.querySelectorAll("#processSteps span").forEach((node, index) => {
      node.classList.toggle("complete", rank > index || job.status === "done");
      node.classList.toggle("active", rank === index && job.status !== "done");
    });
    const errorBox = document.getElementById("jobError");
    if (job.status === "failed") {
      errorBox.textContent = job.error || "Khong the xu ly tep am thanh nay.";
      errorBox.classList.remove("hidden");
    }
  }

  async function pollJob(jobId) {
    const token = ++pollToken;
    currentJobId = jobId;
    while (token === pollToken) {
      const job = await requestJson(`/api/jobs/${jobId}`);
      renderJob(job);
      if (job.status === "done") {
        await showResult(job);
        await loadRecentJobs();
        return;
      }
      if (job.status === "failed") {
        submitButton.disabled = false;
        await loadRecentJobs();
        return;
      }
      await new Promise((resolve) => window.setTimeout(resolve, 1300));
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      validateClientInput();
      submitButton.disabled = true;
      resetJobUi();
      jobSection.scrollIntoView({ behavior: "smooth", block: "center" });
      const job = await requestJson("/api/jobs", { method: "POST", body: makeFormData() });
      renderJob(job);
      await pollJob(job.id);
    } catch (error) {
      submitButton.disabled = false;
      showToast(error.message || String(error), true);
    }
  });

  demoButton.addEventListener("click", async () => {
    try {
      demoButton.disabled = true;
      resetJobUi();
      const mode = document.getElementById("mode").value;
      const job = await requestJson(`/api/demo?mode=${encodeURIComponent(mode)}`, { method: "POST" });
      renderJob(job);
      await showResult(job);
      await loadRecentJobs();
      jobSection.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (error) {
      showToast(error.message || String(error), true);
    } finally {
      demoButton.disabled = false;
    }
  });

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`Cannot load ${src}`));
      document.head.appendChild(script);
    });
  }

  async function ensureOsmd() {
    if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
    if (osmdPromise) return osmdPromise;
    osmdPromise = (async () => {
      const sources = [
        "/static/vendor/opensheetmusicdisplay.min.js",
        "https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.1.3/build/opensheetmusicdisplay.min.js",
      ];
      let lastError = null;
      for (const source of sources) {
        try {
          await loadScript(source);
          if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
        } catch (error) {
          lastError = error;
        }
      }
      throw lastError || new Error("OpenSheetMusicDisplay is unavailable");
    })();
    try { return await osmdPromise; }
    catch (error) { osmdPromise = null; throw error; }
  }

  async function renderArrangementSheet(jobId, mode) {
    const descriptions = {
      melody: 'A · Chỉ giai điệu — một khuông',
      light: 'B · Giai điệu và bass — hai khuông',
      full: playbackData && playbackData.reference_active
        ? 'C · MIDI tham chiếu — hai khuông'
        : 'C · Toàn bộ nốt AI — hai khuông',
    };
    const desc = descriptions[mode] || mode;
    document.getElementById('scoreModeTitle').textContent = desc;
    const letter = { melody: 'A', light: 'B', full: 'C' }[mode];
    const selectedSheet = document.getElementById('activeSheetDownload');
    selectedSheet.href = `/api/jobs/${jobId}/playback-score/${mode}`;
    selectedSheet.download = `AudioSheet_${mode}.musicxml`;
    selectedSheet.textContent = `⬇ MusicXML bản ${letter}`;
    selectedSheet.classList.remove('hidden');
    await renderMusicXml(selectedSheet.href);
  }

  async function renderMusicXml(url) {
    const token = ++scoreRenderToken;
    const loading = document.getElementById("scoreLoading");
    const container = document.getElementById("scoreContainer");
    loading.textContent = 'Đang dựng khuông nhạc cho chế độ đã chọn...';
    loading.classList.remove('hidden');
    container.innerHTML = '';
    osmd = null;
    try {
      const library = await ensureOsmd();
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const xml = await response.text();
      if (token !== scoreRenderToken) return;
      const currentOsmd = new library.OpenSheetMusicDisplay(container, {
        autoResize: true,
        backend: "svg",
        drawTitle: true,
        drawComposer: true,
        drawingParameters: "compacttight",
      });
      currentOsmd.Zoom = zoom;
      await currentOsmd.load(xml);
      if (token !== scoreRenderToken) return;
      currentOsmd.render();
      osmd = currentOsmd;
      loading.classList.add('hidden');
      updateZoomLabel();
    } catch (error) {
      if (token !== scoreRenderToken) return;
      loading.textContent = "Không thể hiển thị MusicXML: " + (error.message || error);
      showToast("Khong the tai bo hien thi sheet nhac.", true);
    }
  }

  function artifactLabel(artifact) {
    const labels = {
      musicxml: "Tai MusicXML",
      midi: "Tai MIDI",
      pdf: "Tai PDF",
      csv: "Tai CSV",
      json: "Tai JSON",
      audio: "Tai WAV",
    };
    return labels[artifact.kind] || artifact.label || artifact.filename;
  }

  async function showResult(job) {
    currentJobId = job.id;
    submitButton.disabled = false;
    resultSection.classList.remove("hidden");
    document.getElementById("resultTitle").textContent = job.title || job.source_name || "Sheet nhac da san sang";
    const meta = [];
    if (job.mode) meta.push(job.mode === "piano" ? "Piano hai tay" : job.mode === "lead" ? "Lead sheet" : "Ban chep tho");
    if (job.bpm_used) meta.push(`${job.bpm_used} BPM`);
    if (job.time_signature) meta.push(`Nhip ${job.time_signature}`);
    if (job.duration_seconds) meta.push(`${job.duration_seconds}s audio`);
    document.getElementById("resultMeta").textContent = meta.join("  /  ");

    const buttons = document.getElementById("downloadButtons");
    buttons.innerHTML = "";
    const artifacts = Array.isArray(job.artifacts) ? job.artifacts : [];
    artifacts.filter((item) => item.kind !== "audio").forEach((artifact, index) => {
      const link = document.createElement("a");
      link.href = artifact.url;
      link.download = artifact.filename;
      link.textContent = artifactLabel(artifact);
      if (artifact.kind === "musicxml" || (!index && artifact.kind !== "pdf")) {
        link.classList.add("primary-download");
      }
      buttons.appendChild(link);
    });

    const audioArtifact = artifacts.find((item) => item.kind === "audio");
    const audioPreview = document.getElementById("audioPreview");
    if (audioArtifact) {
      document.getElementById("audioPlayer").src = audioArtifact.url;
      audioPreview.classList.remove("hidden");
    } else {
      document.getElementById("audioPlayer").removeAttribute("src");
      audioPreview.classList.add("hidden");
    }

    const playbackLoaded = await loadPlayback(job);

    // Only show the original sheet if this old job has no usable playback data.
    // Never overwrite a freshly rendered A/B/C sheet with the old MusicXML.
    if (!playbackLoaded) {
      const xmlArtifact = artifacts.find(item => item.kind === 'musicxml');
      if (xmlArtifact) await renderMusicXml(xmlArtifact.url);
    }
    resultSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function updateZoomLabel() {
    document.getElementById("zoomValue").textContent = `${Math.round(zoom * 100)}%`;
  }

  function applyZoom(nextZoom) {
    zoom = Math.max(0.4, Math.min(2.0, nextZoom));
    updateZoomLabel();
    if (osmd) {
      osmd.Zoom = zoom;
      osmd.render();
    }
  }

  document.getElementById("zoomIn").addEventListener("click", () => applyZoom(zoom + 0.1));
  document.getElementById("zoomOut").addEventListener("click", () => applyZoom(zoom - 0.1));
  document.getElementById("fitScore").addEventListener("click", () => {
    const width = document.getElementById("scoreContainer").clientWidth;
    applyZoom(width < 720 ? 0.62 : width < 1000 ? 0.82 : 1.0);
  });
  document.getElementById("printScore").addEventListener("click", () => {
    document.body.classList.add("print-score");
    window.print();
    window.setTimeout(() => document.body.classList.remove("print-score"), 400);
  });

  async function loadRecentJobs() {
    const container = document.getElementById("recentJobs");
    try {
      const jobs = await requestJson("/api/jobs?limit=8");
      container.innerHTML = "";
      if (!jobs.length) {
        container.innerHTML = '<span class="muted">Chua co du lieu.</span>';
        return;
      }
      jobs.forEach((job) => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "recent-job";
        item.innerHTML = `
          <strong></strong>
          <span class="job-state ${job.status === "failed" ? "failed" : ""}"></span>
          <small></small>
        `;
        item.querySelector("strong").textContent = job.title || job.source_name || job.id.slice(0, 8);
        item.querySelector(".job-state").textContent = job.status === "done" ? "Hoan tat" : job.status === "failed" ? "Loi" : `${job.progress || 0}%`;
        item.querySelector("small").textContent = new Date(job.created_at).toLocaleString("vi-VN");
        item.addEventListener("click", async () => {
          try {
            resetJobUi();
            renderJob(job);
            if (job.status === "done") await showResult(job);
            else if (job.status !== "failed") await pollJob(job.id);
            else jobSection.scrollIntoView({ behavior: "smooth" });
          } catch (error) {
            showToast(error.message || String(error), true);
          }
        });
        container.appendChild(item);
      });
    } catch (error) {
      container.innerHTML = '<span class="muted">Khong the tai lich su.</span>';
    }
  }

  async function loadHealth(showMessage = false) {
    const list = document.getElementById("healthList");
    const text = document.getElementById("healthText");
    try {
      const health = await requestJson("/api/health");
      const checks = [
        ["FFmpeg", health.ffmpeg],
        ["Basic Pitch (thu vien da cai)", health.basic_pitch],
        ["music21", health.music21],
        ["yt-dlp", health.yt_dlp],
        ["OSMD local", health.local_osmd],
        [`Mẫu piano thật (${health.sampled_piano_files || 0}/${health.sampled_piano_expected || 30})`,
           (health.sampled_piano_files || 0) === (health.sampled_piano_expected || 30)],
      ];
      list.innerHTML = "";
      checks.forEach(([label, ok]) => {
        const row = document.createElement("div");
        row.className = "health-row";
        row.innerHTML = `<span>${label}</span><i class="health-dot ${ok ? "ok" : ""}"></i>`;
        list.appendChild(row);
      });
      const coreOk = health.ffmpeg && health.basic_pitch && health.music21;
      text.textContent = coreOk
        ? `AudioSheet v${health.version || "1.0"}. Da nhan dien thu vien, chua kiem tra kha nang nap model AI. Gioi han ${health.limits.max_upload_mb} MB / ${Math.round(health.limits.max_audio_seconds / 60)} phut. Chay scripts/diagnose_ai.py de thu model thuc te.`
        : "Thieu cong cu xu ly cot loi. Hay kiem tra cai dat va chay scripts/diagnose_ai.py.";
      if (showMessage) showToast(coreOk ? "Thu vien da cai. Hay chay chan doan model AI." : "He thong dang thieu thanh phan.", !coreOk);
    } catch (error) {
      text.textContent = "Khong ket noi duoc API.";
      list.innerHTML = "";
      if (showMessage) showToast(error.message || String(error), true);
    }
  }

  document.getElementById("healthButton").addEventListener("click", () => {
    loadHealth(true);
    document.querySelector(".info-panel").scrollIntoView({ behavior: "smooth", block: "center" });
  });
  document.getElementById("refreshJobs").addEventListener("click", loadRecentJobs);

  loadHealth();
  loadRecentJobs();
})();
