/* AudioSheet Studio 1.0.6 - sampled acoustic piano for all three arrangements.
 * Salamander Grand Piano V3 (Alexander Holm), CC BY 3.0; see LICENSE_PIANO_SAMPLES.txt.
 * Sound generation uses native Web Audio API - no npm, Node.js or soundfont library.
 * When MP3 samples cannot be downloaded, a clearly labeled synthesized backup is played.
 */
(() => {
  'use strict';

  // Pitch keys published by the Tone.js Salamander sample collection.
  const SAMPLE_KEYS = [
    'A0', 'C1', 'Ds1', 'Fs1', 'A1', 'C2', 'Ds2', 'Fs2', 'A2',
    'C3', 'Ds3', 'Fs3', 'A3', 'C4', 'Ds4', 'Fs4', 'A4',
    'C5', 'Ds5', 'Fs5', 'A5', 'C6', 'Ds6', 'Fs6', 'A6',
    'C7', 'Ds7', 'Fs7', 'A7', 'C8',
  ];
  const PC = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const SAMPLES = SAMPLE_KEYS.map(name => {
    const match = /^([A-G])(s?)(\d)$/.exec(name);
    return { name, midi: (Number(match[3]) + 1) * 12 + PC[match[1]] + (match[2] ? 1 : 0) };
  });

  class AudioSheetPianoPlayer {
    constructor(callbacks = {}) {
      this.callbacks = callbacks;
      this.audioContext = null;
      this.master = null;
      this.notes = [];
      this.duration = 0;
      this.position = 0;
      this.mode = 'light';
      this.volume = 0.65;
      this.isPlaying = false;
      this.ctxStart = 0;
      this.nextIndex = 0;
      this.timer = null;
      this.frame = null;
      this.voices = [];
      this.voiceByPitch = new Map();
      this.sampleBuffers = new Map();
      this.samplePromises = new Map();
      this.sampleFailures = new Set();
      this.sampleMode = 'unknown';
      this.remoteDisabled = false;
      this.generation = 0;
    }

    setNotes(notes, duration, mode = 'light') {
      this.stop();
      this.notes = Array.isArray(notes) ? notes.filter(n =>
        Number.isFinite(n.start) && Number.isFinite(n.end) &&
        Number.isInteger(n.pitch) && n.pitch >= 0 && n.pitch <= 127 && n.end > n.start
      ).sort((a, b) => a.start - b.start || b.pitch - a.pitch) : [];
      this.duration = Math.max(0, Number(duration) || 0,
        this.notes.length ? this.notes[this.notes.length - 1].end : 0);
      this.mode = mode;
      this.position = 0;
      this.sampleMode = 'unknown';
      this._emit();
    }

    _emitLoading(message, failed = false) {
      if (this.callbacks.onLoading) this.callbacks.onLoading({ message, failed });
    }

    setVolume(value) {
      this.volume = Math.max(0, Math.min(1, Number(value) || 0));
      if (this.master && this.audioContext) {
        this.master.gain.setTargetAtTime(this.volume * 0.7, this.audioContext.currentTime, 0.02);
      }
    }

    async _prepare() {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) throw new Error('Trình duyệt không hỗ trợ Web Audio. Hãy dùng Chrome hoặc Edge.');
      if (!this.audioContext) {
        this.audioContext = new AudioContext();
        this.master = this.audioContext.createGain();
        this.master.gain.value = this.volume * 0.7;
        const compressor = this.audioContext.createDynamicsCompressor();
        compressor.threshold.value = -14;
        compressor.knee.value = 14;
        compressor.ratio.value = 2.5;
        compressor.attack.value = 0.004;
        compressor.release.value = 0.15;
        this.master.connect(compressor);
        compressor.connect(this.audioContext.destination);
      }
      await this.audioContext.resume(); // called directly in the user click handler
    }

    _sampleForPitch(pitch) {
      let nearest = SAMPLES[0];
      for (const candidate of SAMPLES) {
        if (Math.abs(pitch - candidate.midi) < Math.abs(pitch - nearest.midi)) nearest = candidate;
      }
      return nearest;
    }

    async _downloadSample(sample) {
      if (this.sampleBuffers.has(sample.name)) return this.sampleBuffers.get(sample.name);
      if (this.samplePromises.has(sample.name)) return this.samplePromises.get(sample.name);
      const pending = (async () => {
        const urls = [
          `/static/piano_samples/${sample.name}.mp3`,
          ...(this.remoteDisabled ? [] : [`https://tonejs.github.io/audio/salamander/${sample.name}.mp3`]),
        ];
        let lastError = null;
        for (const url of urls) {
          let controller;
          let timer;
          try {
            controller = new AbortController();
            timer = window.setTimeout(() => controller.abort(), 9000);
            const response = await fetch(url, { signal: controller.signal });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const bytes = await response.arrayBuffer();
            if (bytes.byteLength < 2500) throw new Error('Tệp âm thanh quá nhỏ.');
            const buffer = await this.audioContext.decodeAudioData(bytes);
            if (!buffer || !buffer.duration || !buffer.numberOfChannels) throw new Error('MP3 không hợp lệ.');
            this.sampleBuffers.set(sample.name, buffer);
            this.sampleFailures.delete(sample.name);
            return buffer;
          } catch (error) {
            lastError = error;
            // If the CDN cannot be reached, do not spend another minute
            // retrying it for every different pitch. Offline mode is quick.
            if (url.startsWith('https://') && (error.name === 'AbortError' || error instanceof TypeError)) {
              this.remoteDisabled = true;
            }
          } finally {
            if (timer) window.clearTimeout(timer);
          }
        }
        this.sampleFailures.add(sample.name);
        throw new Error(`Không tải được mẫu piano ${sample.name}: ${lastError}`);
      })();
      this.samplePromises.set(sample.name, pending);
      try { return await pending; }
      finally { this.samplePromises.delete(sample.name); }
    }

    async _loadSamplesForNotes() {
      const names = new Set(this.notes.map(n => this._sampleForPitch(n.pitch).name));
      const requests = SAMPLES.filter(x => names.has(x.name) && !this.sampleBuffers.has(x.name));
      if (!requests.length) {
        this.sampleMode = 'recorded';
        this._emitLoading('Piano thật (Salamander Grand Piano) đã sẵn sàng.');
        return;
      }
      let completed = 0;
      let failed = 0;
      this._emitLoading(`Đang tải tiếng piano thật: 0/${requests.length} mẫu...`);
      let cursor = 0;
      const workers = Array.from({ length: Math.min(5, requests.length) }, async () => {
        while (cursor < requests.length) {
          const sample = requests[cursor++];
          try { await this._downloadSample(sample); }
          catch (_) { failed++; }
          finally {
            completed++;
            this._emitLoading(`Đã tải ${completed}/${requests.length} mẫu piano${failed ? ` (${failed} lỗi)` : ''}.`);
          }
        }
      });
      await Promise.all(workers);
      this.sampleMode = failed === requests.length ? 'synth' : failed ? 'mixed' : 'recorded';
      if (failed) {
        this._emitLoading(
          failed === requests.length
            ? 'Không tải được piano ghi âm. Đang dùng tiếng tổng hợp dự phòng; hãy chạy TAI_AM_THANH_PIANO.bat.'
            : `Một số mẫu piano chưa tải được (${failed}). Những nốt đó dùng âm dự phòng.`, true,
        );
      } else {
        this._emitLoading('Piano ghi âm: Salamander Grand Piano V3 · sẵn sàng.');
      }
    }

    _indexAt(time) {
      let low = 0, high = this.notes.length;
      while (low < high) {
        const mid = (low + high) >>> 1;
        if (this.notes[mid].start < time) low = mid + 1;
        else high = mid;
      }
      return low;
    }

    _emit() {
      if (this.callbacks.onUpdate) this.callbacks.onUpdate({
        time: this.currentTime(), duration: this.duration,
        playing: this.isPlaying, mode: this.mode, instrument: this.sampleMode,
      });
    }

    currentTime() {
      return this.isPlaying && this.audioContext
        ? Math.min(this.duration, this.position + this.audioContext.currentTime - this.ctxStart)
        : this.position;
    }

    async play() {
      if (this.isPlaying) return;
      if (!this.notes.length) throw new Error('Không có nốt nhạc để phát.');
      const token = this.generation;
      await this._prepare();
      if (this.position >= this.duration - 0.02) this.position = 0;
      await this._loadSamplesForNotes();
      if (token !== this.generation) return; // switched A/B/C while loading
      this.ctxStart = this.audioContext.currentTime;
      this.nextIndex = this._indexAt(this.position - 0.000001);
      this.isPlaying = true;
      this.timer = window.setInterval(() => this._schedule(), 50);
      this._schedule();
      this._tick();
      this._emit();
    }

    _tick() {
      if (!this.isPlaying) return;
      if (this.currentTime() >= this.duration) {
        this.stop();
        return;
      }
      this._emit();
      this.frame = window.requestAnimationFrame(() => this._tick());
    }

    _schedule() {
      if (!this.isPlaying || !this.audioContext) return;
      const until = this.currentTime() + 0.25;
      const now = this.audioContext.currentTime;
      this.voices = this.voices.filter(v => v.until > now);
      while (this.nextIndex < this.notes.length) {
        const note = this.notes[this.nextIndex];
        if (note.start > until) break;
        this.nextIndex++;
        const when = this.ctxStart + note.start - this.position;
        if (when < now - 0.045) continue;
        if (this.voices.filter(v => v.until > when).length >= 22) continue;
        this._playNote(note, Math.max(now, when));
      }
    }

    _playNote(note, when) {
      const c = this.audioContext;
      const seconds = Math.max(0.06, Math.min(6, note.end - note.start));
      const volume = Math.min(1, Math.max(0.11, (Number(note.velocity) || 64) / 127));
      const modeGain = this.mode === 'full' ? 0.28 : this.mode === 'light' ? 0.40 : 0.48;
      const until = when + seconds + 0.13;
      const envelope = c.createGain();
      const level = modeGain * Math.pow(volume, 1.5);
      envelope.gain.setValueAtTime(0.0001, when);
      envelope.gain.exponentialRampToValueAtTime(Math.max(0.0001, level), when + 0.006);
      envelope.gain.setValueAtTime(Math.max(0.0001, level * 0.67), when + Math.min(seconds * 0.6, 0.17));
      envelope.gain.setValueAtTime(Math.max(0.0001, level * 0.58), when + seconds);
      envelope.gain.exponentialRampToValueAtTime(0.0001, until);
      envelope.connect(this.master);

      const sample = this._sampleForPitch(note.pitch);
      const buffer = this.sampleBuffers.get(sample.name);
      const sources = [];
      if (buffer) {
        const source = c.createBufferSource();
        source.buffer = buffer;
        source.playbackRate.setValueAtTime(Math.pow(2, (note.pitch - sample.midi) / 12), when);
        source.connect(envelope);
        source.start(when);
        source.stop(until);
        sources.push(source);
      } else {
        // Explicit fallback only. The UI labels this as synthesized, not real piano.
        const hz = 440 * Math.pow(2, (note.pitch - 69) / 12);
        for (const [type, ratio, strength] of [['triangle', 1, 0.76], ['sine', 2.004, 0.17], ['sine', 3.01, 0.06]]) {
          if (hz * ratio > c.sampleRate * 0.43) continue;
          const osc = c.createOscillator();
          const gain = c.createGain();
          gain.gain.value = strength * 0.27;
          osc.type = type;
          osc.frequency.setValueAtTime(hz * ratio, when);
          osc.connect(gain);
          gain.connect(envelope);
          osc.start(when);
          osc.stop(until);
          sources.push(osc);
        }
      }
      const previous = this.voiceByPitch.get(note.pitch);
      if (previous && previous.until > when + 0.015) {
        try {
          previous.envelope.gain.cancelScheduledValues(when);
          previous.envelope.gain.setTargetAtTime(0.0001, when, 0.007);
          for (const source of previous.sources) source.stop(when + 0.028);
        } catch (_) { /* already ended */ }
        previous.until = when + 0.028;
      }
      const voice = { until, pitch: note.pitch, sources, envelope };
      this.voices.push(voice);
      this.voiceByPitch.set(note.pitch, voice);
    }

    _silence() {
      if (!this.audioContext) return;
      const now = this.audioContext.currentTime;
      for (const voice of this.voices) {
        try {
          voice.envelope.gain.cancelScheduledValues(now);
          voice.envelope.gain.setTargetAtTime(0.0001, now, 0.003);
          for (const src of voice.sources) src.stop(now + 0.025);
        } catch (_) { /* a scheduled voice has already stopped */ }
      }
      this.voices = [];
      this.voiceByPitch.clear();
    }

    _halt() {
      if (this.timer !== null) window.clearInterval(this.timer);
      if (this.frame !== null) window.cancelAnimationFrame(this.frame);
      this.timer = null;
      this.frame = null;
      this.isPlaying = false;
      this._silence();
    }

    pause() {
      if (!this.isPlaying) return;
      this.position = this.currentTime();
      this._halt();
      this._emit();
    }

    stop() {
      this.generation++;
      this._halt();
      this.position = 0;
      this.nextIndex = 0;
      this._emit();
    }

    async seek(time) {
      const playing = this.isPlaying;
      this._halt();
      this.position = Math.max(0, Math.min(this.duration, Number(time) || 0));
      this._emit();
      if (playing) await this.play();
    }
  }
  window.AudioSheetPianoPlayer = AudioSheetPianoPlayer;
})();
