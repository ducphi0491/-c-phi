DOCFLOW - SETTINGS AND FIREBASE AUTH INTEGRATION (23/10/2026)

Files changed/added:
- MainActivity.kt: bottom Settings icon, VI/EN for main screens, persisted light/dark,
  Firebase sign-in state, routes to new settings page.
- DocFlowPreferences.kt (new): local language/appearance preferences.
- DocFlowSettingsScreen.kt (new): settings, Google sign-in/out UI, Premium placeholder,
  admin-only next-step entry.
- DocFlowAccount.kt (new): Credential Manager -> Google ID token -> Firebase Auth.
- build.gradle.kts: credentials / firebase-auth dependencies and conditional google-services plugin.
- AndroidManifest.xml: INTERNET permission (document tools still work offline).

Replace MainActivity.kt and add the 3 new Kotlin files in the SAME source
folder (package com.docflowoffline). Replace the existing app module's
build.gradle.kts and AndroidManifest.xml; do NOT modify applicationId.

WHAT WORKS NOW
1. All main tabs and settings navigation; appearance choices System/Light/Dark persist.
2. Vietnamese/English for bottom navigation, main tools/conversion and settings screens.
   The detailed Word/Excel/PDF editors and folder catalog are still Vietnamese.
3. Sign-in flow is implemented, but needs your Firebase project configuration.
4. Premium and admin records screens are UI placeholders: no payment or Firestore reads.

FOR FIREBASE AUTH TO WORK
1. Register an Android app with package / applicationId ducphi.docflow in Firebase.
2. Enable Firebase Authentication -> Sign-in method -> Google.
3. Register debug/release SHA-1 and SHA-256 certificate fingerprints.
4. Download the updated google-services.json from Firebase and place it at
   app/google-services.json, i.e. in the same folder as the module's build.gradle.kts.
   Use exactly that filename. With the file present, the conditional Google Services
   Gradle plugin automatically generates google_app_id and default_web_client_id.
5. Ensure Google's Maven repository (google()) is present in the project settings,
   sync Gradle and rebuild. Test Google account sign-in on a real device with
   Google Play services.

ADMIN AND PRIVACY
- The address ducphi0491@gmail.com reveals the *UI entry* only after a verified
  Google -> Firebase login, but it does NOT grant database permissions.
- Do not try to read lists of Firebase Authentication users from the Android app.
  That needs Firebase Admin SDK in trusted Cloud Functions/backend, or an
  explicitly scoped Firestore collection containing allowable profile fields.
- Secure read permissions using a server-set custom claim like admin=true,
  checked in Firebase Rules/backend. Don't trust the client-side email check.
- No access to passwords or secret tokens; do not write such data to Firestore.
- Next phase: ask for Firebase project information, database kind/collections,
  data fields to display, security rules, and (non-secret) google-services.json.

Compilation: This bundle contains only selected source files, not a complete
Android Studio project. No Gradle/Android SDK is available in this environment;
Android build/runtime and Google login have not been executed here.
