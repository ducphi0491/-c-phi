package com.docflowoffline

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await

/**
 * Google -> Firebase Authentication. No passwords, raw ID tokens, or login histories are persisted.
 * The admin email check is ONLY for hiding/showing UI: Firebase Rules/backend must enforce access.
 * This class deliberately does not read other users' records.
 */
internal object DocFlowAccount {
    const val ADMIN_EMAIL = "ducphi0491@gmail.com"

    fun firebaseAuthOrNull(context: Context): FirebaseAuth? {
        return runCatching {
            if (FirebaseApp.getApps(context).isEmpty() && FirebaseApp.initializeApp(context) == null) {
                null
            } else FirebaseAuth.getInstance()
        }.getOrNull()
    }

    private fun webClientId(context: Context): String? {
        val resource = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        if (resource == 0) return null
        return context.getString(resource).takeIf { it.isNotBlank() }
    }

    fun isConfigured(context: Context): Boolean =
        firebaseAuthOrNull(context) != null && webClientId(context) != null

    fun isAdminUi(user: FirebaseUser?): Boolean =
        user?.isEmailVerified == true && user.email?.equals(ADMIN_EMAIL, ignoreCase = true) == true

    suspend fun signIn(activity: Activity): FirebaseUser {
        val firebase = firebaseAuthOrNull(activity)
            ?: error("Firebase chưa được cấu hình cho ứng dụng này.")
        val clientId = webClientId(activity)
            ?: error("Thiếu Web Client ID. Hãy thêm google-services.json và bật Google Sign-In trong Firebase.")

        val option = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(activity).getCredential(
            context = activity,
            request = request
        )
        val googleToken = (result.credential as? CustomCredential)
            ?.takeIf { it.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL }
            ?.let { GoogleIdTokenCredential.createFrom(it.data).idToken }
            ?: error("Google không trả về thông tin đăng nhập hợp lệ.")
        // Firebase verifies the Google identity before accepting the session.
        val authResult = firebase.signInWithCredential(
            GoogleAuthProvider.getCredential(googleToken, null)
        ).await()
        return authResult.user ?: error("Firebase không cung cấp phiên đăng nhập.")
    }

    suspend fun signOut(activity: Activity) {
        firebaseAuthOrNull(activity)?.signOut()
        // Prevent a previously selected account from being silently reused.
        runCatching {
            CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest())
        }
    }
}
