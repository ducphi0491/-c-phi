package com.docflowoffline

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf

/** Only non-sensitive UI preferences are saved on the device. */
internal enum class DocLanguage(val key: String) { VI("vi"), EN("en") }
internal enum class DocAppearance(val key: String) { SYSTEM("system"), LIGHT("light"), DARK("dark") }

internal class DocFlowPreferences(context: Context) {
    private val storage = context.applicationContext.getSharedPreferences("docflow_display", Context.MODE_PRIVATE)

    fun language(): DocLanguage = DocLanguage.entries.firstOrNull {
        it.key == storage.getString("language", "vi")
    } ?: DocLanguage.VI

    fun appearance(): DocAppearance = DocAppearance.entries.firstOrNull {
        it.key == storage.getString("appearance", "system")
    } ?: DocAppearance.SYSTEM

    fun setLanguage(language: DocLanguage) {
        storage.edit().putString("language", language.key).apply()
    }

    fun setAppearance(appearance: DocAppearance) {
        storage.edit().putString("appearance", appearance.key).apply()
    }
}

internal val LocalDocLanguage = compositionLocalOf { DocLanguage.VI }
internal val LocalDocIsDark = compositionLocalOf { false }

/** UI strings in the entry screens; document editors retain their existing source text. */
@Composable
internal fun dfText(vi: String, en: String): String =
    if (LocalDocLanguage.current == DocLanguage.EN) en else vi
