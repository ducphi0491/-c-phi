#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only inspection of the user's existing Songsterr SQLite database.

Does not copy, write, merge, upload, or modify any records.
"""
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

DEFAULT_ORIGINAL = r'C:\inetpub\wwwroot\tab\songsterr_database.db'
CANDIDATES = (
    'id', 'song_id', 'songsterr_id', 'title', 'name', 'song_name',
    'artist', 'author', 'file_path', 'path', 'filename', 'file_name',
    'format', 'extension',
)


def quoted(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def inspect_db(path: Path, max_tables: int = 30, samples: int = 2) -> None:
    path = path.expanduser().resolve()
    if not path.is_file():
        raise SystemExit(f'Khong tim thay CSDL: {path}')
    # URI with mode=ro prevents accidental database writes.
    uri = path.as_uri() + '?mode=ro'
    con = sqlite3.connect(uri, uri=True, timeout=30)
    try:
        con.execute('PRAGMA query_only=ON')
        print('FILE:', path)
        print(f'SIZE: {path.stat().st_size / 1024 / 1024:.1f} MiB')
        tables = [row[0] for row in con.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """) if not row[0].endswith(('_fts_data', '_fts_idx', '_fts_docsize', '_fts_config'))]
        print('TABLE COUNT:', len(tables))
        for name in tables[:max_tables]:
            table_sql = quoted(name)
            columns = [(r[1], r[2]) for r in con.execute('PRAGMA table_info(' + table_sql + ')')]
            print('\nTABLE:', name)
            print('COLUMNS:', ', '.join(f'{n} ({t or "?"})' for n, t in columns))
            try:
                total = con.execute('SELECT COUNT(*) FROM ' + table_sql).fetchone()[0]
                print('ROWS:', f'{total:,}')
            except sqlite3.Error as exc:
                print('ROWS: unable to count:', exc)
            by_lower = {n.lower(): n for n, _ in columns}
            wanted = [by_lower[n] for n in CANDIDATES if n in by_lower]
            if wanted and samples:
                select_fields = ', '.join(quoted(n) for n in wanted)
                try:
                    q = f'SELECT {select_fields} FROM {table_sql} LIMIT ?'
                    records = con.execute(q, (samples,)).fetchall()
                    for i, values in enumerate(records, 1):
                        safe = {col: (str(value)[:160] if value is not None else None)
                                for col, value in zip(wanted, values)}
                        print(f'SAMPLE {i}:', safe)
                except sqlite3.Error as exc:
                    print('SAMPLE: unable to read:', exc)
        if len(tables) > max_tables:
            print(f'... {len(tables) - max_tables} additional tables omitted. Use --max-tables.')
        print('\nREAD-ONLY COMPLETE. Database was not changed.')
    finally:
        con.close()


def main() -> None:
    p = argparse.ArgumentParser(description='Kiem tra bang/cot DB Songsterr goc - chi doc')
    p.add_argument('--db', default=DEFAULT_ORIGINAL, help='Duong dan songsterr_database.db')
    p.add_argument('--max-tables', type=int, default=30)
    p.add_argument('--samples', type=int, default=2)
    args = p.parse_args()
    inspect_db(Path(args.db), max(1, args.max_tables), max(0, min(args.samples, 5)))


if __name__ == '__main__':
    main()
