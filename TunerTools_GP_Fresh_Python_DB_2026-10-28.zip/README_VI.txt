TUNER TOOLS - BO CONG CU GOOGLE DRIVE FRESH (1.600.000 FILE)
Ngay tao: 28/10/2026
===========================================================

1. DUNG DE LAM GI?
- BAT DAU TU SO 0. File .db dinh kem la SQLite MOI, 0 bai, 0 Drive ID.
- KHONG su dung database thu nghiem 5.000 bai, KHONG su dung thu muc Google Drive cu.
- DOC file .gp/.gp3/.gp4/.gp5/.gp6/.gp7/.gp8/.gpx tren may Windows.
- Tao chi muc tim kiem SQLite, sau do upload GP len Google My Drive.
- Luu Drive ID vao file gp_fresh_1600000.db de theo doi va tiep tuc khi ngat.
- KHONG xoa/di chuyen file GP goc. KHONG ghi sua songsterr_database.db goc.

2. GIAI NEN
Giai nen TAT CA file trong ZIP truc tiep vao:
    C:\TunerToolsGP_Fresh\

Cau truc se la:
    C:\TunerToolsGP_Fresh\tt_gp_bulk.py
    C:\TunerToolsGP_Fresh\check_db.py
    C:\TunerToolsGP_Fresh\requirements.txt
    C:\TunerToolsGP_Fresh\gp_fresh_1600000.db
    C:\TunerToolsGP_Fresh\README_VI.txt

Kho file NGUON van giu nguyen:
    C:\inetpub\wwwroot\tab\
        G\ H\ ... Z\ Kho_Tab_Songsterr\ ...
        songsterr_database.db

QUAN TRONG: Chi giai nen .db TRONG mot lan truoc khi scan.
Neu truoc do ban da scan/upload, KHONG ghi de .db co du lieu bang .db trong ZIP.

3. CAI THU VIEN (Windows PowerShell)
    cd C:\TunerToolsGP_Fresh
    py --version
    py -m pip install -r requirements.txt

Yeu cau Python >=3.11. Neu py khong nhan, can cai Python truoc.

4. KIEM TRA songsterr_database.db GOC - CAN LAM TRUOC
    py check_db.py --db "C:\inetpub\wwwroot\tab\songsterr_database.db"

Co the luu ket qua ra text de gui kiem tra:
    py check_db.py --db "C:\inetpub\wwwroot\tab\songsterr_database.db" > db_structure.txt

check_db.py CHI DOC, khong ghi, khong chuyen metadata vao DB moi.
CAN kiem tra cau truc DB goc de biet co the lay chinh xac title, artist,
Songsterr ID va duong dan local khong. Chua du thong tin de tu ghep.

5. QUET FILE LOCAL VA TAO DANH MUC MOI
    py tt_gp_bulk.py scan --source "C:\inetpub\wwwroot\tab" --db "gp_fresh_1600000.db"

Chuong trinh doc tat ca thu muc con tu goc tab, bao gom Kho_Tab_Songsterr.
CHI doc file GP. Khong dua .db, .json, .py vao danh muc bai hat.
- id: tao ma local-* tu duong dan (KHONG phai Songsterr ID chinh thuc).
- title: tam thoi lay tu ten file (chua doi chieu DB goc).
- artist: tam thoi suy doan theo ten file khi co dau ' - '.
- file_path: luu dang 'tab/G/...' hoac 'tab/Kho_Tab_Songsterr/...'.
- drive_file_id: NULL cho toi khi upload thanh cong.

KIEM TRA SO FILE SAU QUET:
    py tt_gp_bulk.py status --db "gp_fresh_1600000.db"

Nen doi chieu so file, thong tin bai hat va duong dan truoc khi upload.
Neu metadata title/artist/ID trong DB goc khac voi ten file, can sua
script import/ghep metadata SAU khi kiem tra db_structure.txt.

6. CHUAN BI GOOGLE DRIVE OAUTH (SAU KHI DA KIEM TRA METADATA)
Can tai khoan Google Drive co du dung luong va quyen upload.
Neu co token tu PHP, chi sao chep ban RIENG TU drive_token.json co quyen
GHI vao C:\TunerToolsGP_Fresh, KHONG dua vao C:\inetpub\wwwroot.
Neu chua co token, tao OAuth Desktop credentials.json tu Google Cloud
Project da bat Google Drive API, dat vao thu muc cong cu va chay:
    py tt_gp_bulk.py auth

Kiem tra dung email tai khoan truoc khi upload.
Khong share drive_token.json / credentials.json cho bat ky ai.

7. UPLOAD THU 100 FILE (KHONG CHAY DAI TRA NGAY)
    py tt_gp_bulk.py upload --source "C:\inetpub\wwwroot\tab" --db "gp_fresh_1600000.db" --workers 4 --rate 2.5 --limit 100 --yes

Lan dau chay lenh upload moi TAO thu muc Drive goc MOI.
Chuong trinh chia file vao 256 thu muc con 00...ff, luu Drive ID vao SQLite.

KIEM TRA MAU FILE:
    py tt_gp_bulk.py verify --source "C:\inetpub\wwwroot\tab" --db "gp_fresh_1600000.db" --sample 20

8. UPLOAD TOAN BO (CHI KHI 100 FILE THU DA OK)
    py tt_gp_bulk.py upload --source "C:\inetpub\wwwroot\tab" --db "gp_fresh_1600000.db" --workers 4 --rate 2.5 --limit 0 --yes

- --limit 0: xu ly het file chua co Drive ID.
- Chay lai LENH NAY khi mat mang: bo qua file da ghi ID thanh cong.
- Chay status tu PowerShell thu 2 de xem tien do.
- Khong nen chay 2 uploader dong thoi tren cung mot .db.

9. SAU KHI HOAN TAT
Dung uploader. Sao luu va checkpoint SQLite truoc khi chuyen len PHP:
    py -c "import sqlite3; c=sqlite3.connect('gp_fresh_1600000.db'); print(c.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchall()); c.close()"
Sau do kiem tra bang va API PHP truoc khi thay database production.
PHP/API va tai khoan OAuth phai co quyen DOC cac file vua upload.
Cac dong metadata tu ten file co the KHONG chinh xac neu chua ghep DB goc.

10. CANH BAO QUAN TRONG
- Mot folder My Drive khong qua 500.000 muc truc tiep. Da chia 256 folder.
- Google khuyen nghi khong de mot tai khoan tao/so huu tren 500.000 muc
  khi migrate quy mo lon vi co the anh huong hieu nang, du gioi han cung
  so muc/tai khoan cao hon. 1.600.000 file can can nhac kien truc so huu.
- Drive can du DUNG LUONG THUC TE. 256 folder KHONG tang quota.
- Gioi han 2.5 lan upload/giay de tranh API write rate limit.
- Chi dua file len Google Drive neu ban co quyen tai len va phan phoi.
- Bo cong cu duoc test OFFLINE voi SQLite va file mau. KHONG the kiem thu
  OAuth/upload that tren tai khoan Google cua ban tu day.
