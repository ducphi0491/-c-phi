# AudioSheet Studio 1.3.0 - 2026-11-03

- Added Beat This! beat/downbeat tracking (`small0`, MIT).
- Added `rhythm_map.json` as the shared timing source for sound, MIDI, MusicXML and PDF.
- Detects anacrusis/pickup measures instead of forcing measure 1 at second zero.
- Supports local tempo maps and 4/4 -> 2/4 -> 4/4 meter changes.
- Quantizes note starts/durations inside each detected measure, with triplet candidates.
- Re-runs chord windows and piano arrangement on detected measure/half-measure boundaries.
- Writes pickup measure 0 and meter changes to MusicXML.
- Writes tempo/time-signature changes to MIDI.
- Uses adaptive 2-4 measures per system instead of forcing one measure per line.
- Hides ambiguous legacy B_light download artifacts from the interface.
- Keeps librosa and constant-tempo fallbacks when Beat This! is unavailable.
