# AudioSheet Studio 1.3.0

AudioSheet Studio converts audio or permitted YouTube sources into MIDI, MusicXML and PDF.

## v1.3 rhythm-grid pipeline

1. FFmpeg normalizes audio.
2. Beat This! detects beats and downbeats in the isolated PyTorch environment.
3. AudioSheet detects pickup measures, local tempo and meter changes (including 2/4 inside 4/4 songs).
4. Demucs separates vocals, bass, drums and other accompaniment.
5. Basic Pitch transcribes pitched stems.
6. Every A/B/C arrangement is quantized against the same rhythm map.
7. MIDI, MusicXML, playback and PDF share that exact score-time axis.

Beat This! falls back to a dynamic librosa tracker, then to a constant-tempo grid if required.

Start on Windows with `CHAY_WEBSITE.bat`. See `HUONG_DAN_V1.3.0.txt`.
