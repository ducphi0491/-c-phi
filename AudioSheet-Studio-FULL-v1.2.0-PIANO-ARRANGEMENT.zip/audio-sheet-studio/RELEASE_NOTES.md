# AudioSheet Studio 1.2.0 - 2026-11-03

## Piano Arrangement v2

- B now has Easy, Standard and Full levels.
- Standard adds voice-led chord shells, inversions and bass movement.
- Full adds left-hand arpeggios, right-hand voicings and restrained fills from the accompaniment stem.
- Chord inference now supports dominant 7, major 7, minor 7, half-diminished, diminished 7, sus2, sus4 and slash bass.
- Chord selection is smoothed across the song instead of scoring each bar independently.
- Older v1.1 jobs are upgraded from `arrangements.json` or `note_events.json` without re-running the AI models.

## Notation and PDF

- Piano modes request four measures per system.
- Basic triplet values are emitted with MusicXML time-modification.
- A/B-level/C playback, MIDI, MusicXML and PDF always use the same note list.
- The v1.1 `light` API/file aliases continue to point to B Standard.
