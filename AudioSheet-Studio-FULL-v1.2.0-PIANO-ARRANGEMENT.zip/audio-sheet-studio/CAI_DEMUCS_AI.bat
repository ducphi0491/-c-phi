@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DEMUCS_PYTHON=%CD%\.demucs-venv\Scripts\python.exe"

echo ==================================================
echo  AudioSheet Studio 1.1 - Cai Demucs AI tach stem
echo ==================================================
echo  Demucs duoc cai trong moi truong rieng de khong xung dot TensorFlow.
echo  Lan dau can Internet va co the tai hon 1 GB du lieu.
echo.

py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo [LOI] Khong tim thay Python 3.11.
  exit /b 1
)

if not exist "%DEMUCS_PYTHON%" (
  echo [1/4] Tao moi truong .demucs-venv...
  py -3.11 -m venv .demucs-venv
  if errorlevel 1 exit /b 1
)

echo [2/4] Cap nhat pip...
"%DEMUCS_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip wheel setuptools
if errorlevel 1 exit /b 1

echo [3/4] Cai PyTorch CPU chinh thuc...
"%DEMUCS_PYTHON%" -m pip install --disable-pip-version-check --index-url https://download.pytorch.org/whl/cpu torch torchaudio
if errorlevel 1 exit /b 1

echo [4/4] Cai Demucs...
"%DEMUCS_PYTHON%" -m pip install --disable-pip-version-check -r requirements_demucs.txt
if errorlevel 1 exit /b 1

echo.
"%DEMUCS_PYTHON%" scripts\check_demucs.py
if errorlevel 1 (
  echo [LOI] Demucs chua san sang.
  exit /b 1
)

echo.
echo [OK] Demucs da san sang. Model htdemucs se tu tai o lan tach stem dau tien.
exit /b 0
