from __future__ import annotations

import shutil
from pathlib import Path

from reportlab.pdfgen import canvas

from app import processor
from app.job_store import job_store


def test_stem_pipeline_writes_three_scores_and_pdfs(monkeypatch) -> None:
    job = job_store.create({
        'source_type': 'upload',
        'source_filename': 'source.wav',
        'source_name': 'Fixture',
        'title': 'Fixture song',
        'mode': 'piano',
        'bpm_requested': 100,
        'bpm_used': None,
        'time_signature': '4/4',
        'quantization': 16,
        'split_pitch': 60,
        'minimum_midi': 36,
        'maximum_midi': 96,
        'onset_threshold': .5,
        'frame_threshold': .3,
        'minimum_note_length_ms': 120,
        'separate_stems': True,
    })
    directory = job_store.job_dir(job['id'])
    (directory / 'source.wav').write_bytes(b'fixture')

    def fake_normalize(source, target, max_seconds):
        target.write_bytes(b'normalized')
        return 4.0

    def fake_prepare(source, target, max_seconds, duration=None):
        target.write_bytes(b'audio')
        return target

    def fake_separate(source, destination, log_path=None):
        destination.mkdir(parents=True, exist_ok=True)
        result = {}
        for name in ('vocals', 'bass', 'drums', 'other'):
            path = destination / f'{name}.wav'
            path.write_bytes(name.encode())
            result[name] = path
        return result

    def fake_transcribe(**kwargs):
        source = kwargs['source']
        if source == 'vocals':
            return [
                {'start': 0, 'end': .5, 'pitch': 68, 'velocity': 92, 'confidence': .9, 'source': source},
                {'start': .6, 'end': 1.1, 'pitch': 69, 'velocity': 88, 'confidence': .88, 'source': source},
            ]
        if source == 'bass':
            return [{'start': 0, 'end': 1.2, 'pitch': 42, 'velocity': 74, 'confidence': .74, 'source': source}]
        return [
            {'start': 0, 'end': 1.2, 'pitch': 54, 'velocity': 68, 'confidence': .68, 'source': source},
            {'start': 0, 'end': 1.2, 'pitch': 61, 'velocity': 64, 'confidence': .64, 'source': source},
        ]

    def fake_pdf(xml_path: Path, pdf_path: Path):
        doc = canvas.Canvas(str(pdf_path))
        doc.drawString(72, 760, xml_path.name)
        doc.save()
        return 'test-renderer'

    monkeypatch.setattr(processor, 'normalize_audio', fake_normalize)
    monkeypatch.setattr(processor, 'estimate_bpm', lambda path: 100.0)
    monkeypatch.setattr(processor, 'prepare_separation_audio', fake_prepare)
    monkeypatch.setattr(processor, 'prepare_stem_for_ai', fake_prepare)
    monkeypatch.setattr(processor, 'separate_stems', fake_separate)
    monkeypatch.setattr(processor, '_transcribe_stem', fake_transcribe)
    monkeypatch.setattr(processor, 'export_musicxml_to_pdf', fake_pdf)
    monkeypatch.setattr(processor, 'demucs_info', lambda: {'available': True, 'version': 'test', 'model': 'htdemucs'})
    monkeypatch.setattr(processor, 'pdf_engine_status', lambda: {'available': True, 'preferred': 'test-renderer'})

    try:
        processor._process_job(job['id'])
        result = job_store.get(job['id'])
        assert result['status'] == 'done', result.get('error')
        assert result['pipeline'] == 'stem_separated'
        assert result['pdf_ready'] is True
        filenames = {item['filename'] for item in result['artifacts']}
        for variant, letter in [('melody', 'A'), ('light_easy', 'B'), ('light_standard', 'B'), ('light_full', 'B'), ('full', 'C')]:
            assert f'sheet_{letter}_{variant}.mid' in filenames
            assert f'sheet_{letter}_{variant}.musicxml' in filenames
            assert f'sheet_{letter}_{variant}.pdf' in filenames
        assert all('/' not in name and '\\' not in name for name in filenames)
        assert {'stem_vocals.wav', 'stem_bass.wav', 'stem_other.wav', 'stem_drums.wav'} <= filenames
        assert (directory / 'pipeline_manifest.json').is_file()
        assert (directory / 'arrangements.json').is_file()
    finally:
        if directory.exists():
            job_store.delete(job['id'])
