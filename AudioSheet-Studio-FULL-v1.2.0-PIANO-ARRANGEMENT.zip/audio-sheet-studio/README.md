# AudioSheet Studio 1.2.0

Local-first audio-to-sheet website using FFmpeg, Demucs, Basic Pitch, music21/OpenSheetMusicDisplay and sampled piano playback.

## Main pipelines

- **A · Vocal melody** — cleaned monophonic melody from the vocal stem.
- **B · Piano Arrangement** — Easy, Standard and Full levels.
- **C · Full transcription** — pitched notes retained from separated stems.

Version 1.2.0 adds extended chord qualities, slash-bass detection, smoothed harmonic rhythm, voice-led right-hand voicings, left-hand arpeggios, arrangement fills, basic triplet MusicXML and four measures per system for piano modes.

Run `CHAY_WEBSITE.bat` on Windows. Existing v1.1 jobs are upgraded from saved note data without re-running Demucs.

See `HUONG_DAN_V1.2.0.txt` for Vietnamese update instructions.
