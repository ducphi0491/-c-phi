@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PROJECT_PYTHON=%CD%\.venv\Scripts\python.exe"
set "DEMUCS_PYTHON=%CD%\.demucs-venv\Scripts\python.exe"

echo ==================================================
echo  AudioSheet Studio 1.2.0 - PIANO ARRANGEMENT 3 MUC
echo ==================================================
echo.

if not exist "%PROJECT_PYTHON%" (
  echo [CAI DAT] Dang cai website lan dau...
  call "%~dp0install_windows.bat"
  if errorlevel 1 goto :failure
)

"%PROJECT_PYTHON%" -c "import pkg_resources" >nul 2>&1
if errorlevel 1 (
  echo [SUA LOI] Dang khoi phuc pkg_resources...
  "%PROJECT_PYTHON%" -m pip install --disable-pip-version-check "setuptools==80.9.0"
  if errorlevel 1 goto :failure
)

echo [KIEM TRA] Basic Pitch va bo xuat PDF...
"%PROJECT_PYTHON%" scripts\check_install.py
if errorlevel 1 (
  echo [CAI DAT] Thanh phan cot loi chua du, dang cai bo sung...
  call "%~dp0install_windows.bat"
  if errorlevel 1 goto :failure
)

if not exist "web\piano_samples\C4.mp3" (
  echo.
  echo [CAI DAT] Dang tai 30 mau piano Salamander lan dau...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\download_piano_samples.ps1"
  if errorlevel 1 echo [CANH BAO] Chua tai du mau piano; website se dung am tong hop du phong.
)

if not exist "%DEMUCS_PYTHON%" (
  echo.
  echo [CAI DAT] Chua co Demucs. Dang cai tu dong lan dau...
  call "%~dp0CAI_DEMUCS_AI.bat"
  if errorlevel 1 (
    echo.
    echo [CANH BAO] Khong cai duoc Demucs. Website van mo duoc.
    echo Khi tao bai, bo chon muc "Tu dong tach giong va nhac cu" de dung che do du phong.
  )
) else (
  "%DEMUCS_PYTHON%" scripts\check_demucs.py >nul 2>&1
  if errorlevel 1 (
    echo [SUA LOI] Moi truong Demucs bi thieu. Dang cai lai...
    call "%~dp0CAI_DEMUCS_AI.bat"
  )
)

echo.
echo [OK] Dang mo http://127.0.0.1:8000
echo Giu cua so nay mo trong khi su dung website.
echo.
start "" powershell -NoProfile -WindowStyle Hidden -Command "$u='http://127.0.0.1:8000/api/health'; for($i=0;$i -lt 60;$i++){try{$r=Invoke-WebRequest -UseBasicParsing $u -TimeoutSec 1; if($r.StatusCode -eq 200){Start-Process 'http://127.0.0.1:8000'; break}}catch{}; Start-Sleep -Milliseconds 500}"
"%PROJECT_PYTHON%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
set "APP_EXIT=%ERRORLEVEL%"
echo.
echo Website da dung. Ma thoat: %APP_EXIT%
pause
exit /b %APP_EXIT%

:failure
echo.
echo [LOI] Khong the khoi dong AudioSheet Studio.
echo Chay lai install_windows.bat va gui noi dung loi neu van khong duoc.
pause
exit /b 1
