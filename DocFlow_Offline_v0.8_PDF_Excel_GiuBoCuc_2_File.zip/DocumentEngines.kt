package com.docflowoffline

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.StringReader
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.OutputStream
import kotlin.math.min

// ================ OfficeOoxml.kt ================
/**
 * Conservative OOXML reader + basic editor. This is NOT LibreOffice/Collabora.
 * The original ZIP's non-edited entries are copied byte-for-byte after inflation.
 * Saving is restricted to plain DOCX paragraphs and selected XLSX cells.
 * This class has no Android dependencies so its document logic can be unit-tested on a JVM.
 */
object OfficeOoxml {
    private const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val P = "http://schemas.openxmlformats.org/presentationml/2006/main"
    private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG_R = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val CT = "http://schemas.openxmlformats.org/package/2006/content-types"
    private const val XML = "http://www.w3.org/XML/1998/namespace"
    private const val MAX_ENTRY = 24 * 1024 * 1024
    private const val MAX_TOTAL = 96 * 1024 * 1024
    private const val MAX_ENTRIES = 2500

    data class Word(val paragraphs: List<String>, val editable: Boolean, val reason: String?)
    // cells contain editable source values (formulas retain their leading '=');
    // displayCells hold cached formula results for a more natural spreadsheet grid.
    data class Sheet(
        val name: String,
        val partPath: String,
        val cells: Map<String, String>,
        val displayCells: Map<String, String> = emptyMap(),
        val maxRow: Int = 1,
        val maxCol: Int = 1,
        val truncated: Boolean = false,
        val appearances: Map<String, CellAppearance> = emptyMap()
    )
    data class Workbook(val sheets: List<Sheet>)
    data class Slide(val number: Int, val partPath: String, val paragraphs: List<String>)
    data class SlideChange(val partPath: String, val index: Int, val text: String)
    data class CellChange(val sheetPath: String, val address: String, val value: String, val cachedValue: String? = null)

    /** Visual properties supported by the lightweight editor; original OOXML styling is otherwise preserved. */
    data class CellAppearance(
        val bold: Boolean = false, val italic: Boolean = false, val underline: Boolean = false,
        val alignment: String = "general", val fillRgb: String? = null, val percent: Boolean = false
    )
    /** Null = keep the original property; fillRgb="" clears the cell highlight. */
    data class StyleChange(
        val sheetPath: String, val address: String,
        val bold: Boolean? = null, val italic: Boolean? = null, val underline: Boolean? = null,
        val alignment: String? = null, val fillRgb: String? = null, val numFmtId: Int? = null
    )

    fun readWord(data: ByteArray): Word {
        val parts = unzip(data)
        val document = parse(parts["word/document.xml"] ?: error("Không tìm thấy nội dung Word."))
        val body = document.getElementsByTagNameNS(W, "body").item(0) as? Element
            ?: error("Cấu trúc Word không hợp lệ.")
        val paragraphs = body.getElementsByTagNameNS(W, "p")
        val texts = (0 until paragraphs.length).map { index ->
            val node = paragraphs.item(index) as Element
            node.getElementsByTagNameNS(W, "t").asSequence().joinToString("") { it.textContent ?: "" }
        }
        val unsupported = listOf("tbl", "drawing", "pict", "object", "sdt", "hyperlink", "fldChar", "instrText", "ins", "del", "br", "tab", "altChunk")
        val complexPart = unsupported.firstOrNull { document.getElementsByTagNameNS(W, it).length > 0 }
        val editable = complexPart == null && paragraphs.length <= 400
        val reason = when {
            complexPart != null -> "Có thành phần $complexPart. Chỉ cho xem trước để tránh làm hỏng bố cục; cần bộ máy Collabora để chỉnh sửa đầy đủ."
            !editable -> "Tệp có quá nhiều đoạn cho bộ chỉnh sửa đơn giản."
            else -> null
        }
        return Word(texts, editable, reason)
    }

    fun writeWord(original: ByteArray, newParagraphs: List<String>): ByteArray {
        require(newParagraphs.size <= 400) { "Tối đa 400 đoạn ở chế độ chỉnh sửa cơ bản." }
        val previous = readWord(original)
        require(previous.editable) { previous.reason ?: "Tài liệu này chỉ hỗ trợ xem trước." }
        val zip = unzip(original).toMutableMap()
        val xml = parse(zip.getValue("word/document.xml"))
        val body = xml.getElementsByTagNameNS(W, "body").item(0) as Element
        val paragraphs = body.getElementsByTagNameNS(W, "p").asSequence().map { it as Element }.toList()
        for (index in paragraphs.indices) {
            if (index >= newParagraphs.size) {
                body.removeChild(paragraphs[index])
            } else {
                writeParagraph(xml, paragraphs[index], newParagraphs[index])
            }
        }
        for (index in paragraphs.size until newParagraphs.size) {
            val paragraph = xml.createElementNS(W, "w:p")
            writeParagraph(xml, paragraph, newParagraphs[index])
            val sectPr = body.getElementsByTagNameNS(W, "sectPr").item(0)
            if (sectPr != null && sectPr.parentNode == body) body.insertBefore(paragraph, sectPr)
            else body.appendChild(paragraph)
        }
        zip["word/document.xml"] = serialize(xml)
        return zipEntries(zip)
    }

    private fun writeParagraph(doc: Document, paragraph: Element, value: String) {
        val textNodes = paragraph.getElementsByTagNameNS(W, "t")
        if (textNodes.length == 0) {
            val run = doc.createElementNS(W, "w:r")
            val text = doc.createElementNS(W, "w:t")
            text.setAttributeNS(XML, "xml:space", "preserve")
            text.textContent = value
            run.appendChild(text)
            paragraph.appendChild(run)
        } else {
            for (i in 0 until textNodes.length) {
                val text = textNodes.item(i) as Element
                text.textContent = if (i == 0) value else ""
                if (i == 0) text.setAttributeNS(XML, "xml:space", "preserve")
            }
        }
    }

    fun readWorkbook(data: ByteArray): Workbook {
        val zip = unzip(data)
        val wb = parse(zip["xl/workbook.xml"] ?: error("Không phải file XLSX hợp lệ."))
        val rels = zip["xl/_rels/workbook.xml.rels"]?.let(::parse)
        val relation = mutableMapOf<String, String>()
        rels?.getElementsByTagNameNS(PKG_R, "Relationship")?.asSequence()?.forEach {
            val e = it as Element
            val target = e.getAttribute("Target")
            if (!target.startsWith("http://") && !target.startsWith("https://")) {
                relation[e.getAttribute("Id")] = normalizePartPath("xl", target)
            }
        }
        val strings = zip["xl/sharedStrings.xml"]?.let { sheetStrings(parse(it)) } ?: emptyList()
        val styleTable = zip["xl/styles.xml"]?.let(::parse)?.let(::readStyleTable).orEmpty()
        val sheets = wb.getElementsByTagNameNS(S, "sheet").asSequence().mapIndexedNotNull { i, node ->
            val element = node as Element
            val path = relation[element.getAttributeNS(R, "id")] ?: "xl/worksheets/sheet${i + 1}.xml"
            val sheetBytes = zip[path] ?: return@mapIndexedNotNull null
            val loaded = loadCells(parse(sheetBytes), strings, styleTable)
            Sheet(
                element.getAttribute("name").ifBlank { "Sheet ${i + 1}" }, path,
                loaded.cells, loaded.displayCells, loaded.maxRow, loaded.maxCol, loaded.truncated, loaded.appearances
            )
        }.toList()
        require(sheets.isNotEmpty()) { "Không tìm thấy worksheet để hiển thị." }
        return Workbook(sheets)
    }

    private fun sheetStrings(document: Document): List<String> {
        return document.getElementsByTagNameNS(S, "si").asSequence().map { node ->
            (node as Element).getElementsByTagNameNS(S, "t").asSequence().joinToString("") { it.textContent ?: "" }
        }.toList()
    }

    // Keep bounded RAM use on mobile, and tell the UI when a workbook is only partially loaded.
    private const val PREVIEW_MAX_ROWS = 100_000
    private const val PREVIEW_MAX_COLUMNS = 256
    private const val PREVIEW_MAX_NONEMPTY_CELLS = 120_000

    private data class LoadedCells(
        val cells: Map<String, String>, val displayCells: Map<String, String>,
        val maxRow: Int, val maxCol: Int, val truncated: Boolean,
        val appearances: Map<String, CellAppearance>
    )

    private fun loadCells(document: Document, strings: List<String>, styleTable: List<CellAppearance>): LoadedCells {
        val cells = LinkedHashMap<String, String>()
        val display = HashMap<String, String>()
        val appearances = HashMap<String, CellAppearance>()
        val nodes = document.getElementsByTagNameNS(S, "c")
        var maxRow = 1
        var maxCol = 1
        var truncated = false
        for (i in 0 until nodes.length) {
            val cell = nodes.item(i) as Element
            val address = cell.getAttribute("r").uppercase(Locale.ROOT)
            val row = address.dropWhile(Char::isLetter).toIntOrNull() ?: continue
            val col = colNumber(address.takeWhile(Char::isLetter))
            if (row !in 1..PREVIEW_MAX_ROWS || col !in 1..PREVIEW_MAX_COLUMNS) {
                truncated = true
                continue
            }
            maxRow = maxOf(maxRow, row)
            maxCol = maxOf(maxCol, col)
            val appearance = styleTable.getOrNull(cell.getAttribute("s").toIntOrNull() ?: 0)
            if (appearance != null && appearance != CellAppearance() && appearances.size < PREVIEW_MAX_NONEMPTY_CELLS) {
                appearances[address] = appearance
            }
            val value = cellValue(cell, strings)
            if (value.isEmpty()) continue
            if (cells.size >= PREVIEW_MAX_NONEMPTY_CELLS) {
                truncated = true
                continue
            }
            cells[address] = value
            if (value.startsWith("=")) {
                val cached = cell.getElementsByTagNameNS(S, "v").item(0)?.textContent.orEmpty()
                if (cached.isNotBlank()) display[address] = cached
            }
        }
        return LoadedCells(cells, display, maxRow, maxCol, truncated, appearances)
    }

    private fun cellValue(cell: Element, strings: List<String>): String {
        val formula = cell.getElementsByTagNameNS(S, "f").item(0)?.textContent
        if (!formula.isNullOrBlank()) return "=$formula"
        val rawValue = cell.getElementsByTagNameNS(S, "v").item(0)?.textContent.orEmpty()
        return when (cell.getAttribute("t")) {
            "s" -> rawValue.toIntOrNull()?.let(strings::getOrNull) ?: rawValue
            "inlineStr" -> cell.getElementsByTagNameNS(S, "t").asSequence().joinToString("") { it.textContent.orEmpty() }
            "b" -> if (rawValue == "1") "TRUE" else "FALSE"
            else -> rawValue
        }
    }


    /** Resolve fonts/fills for cells which have a direct style index. Styles are never flattened on save. */
    private fun readStyleTable(styles: Document): List<CellAppearance> {
        val root = styles.documentElement
        val fonts = (root.getElementsByTagNameNS(S, "fonts").item(0) as? Element)
            ?.childElements(S, "font").orEmpty()
        val fills = (root.getElementsByTagNameNS(S, "fills").item(0) as? Element)
            ?.childElements(S, "fill").orEmpty()
        val xfs = (root.getElementsByTagNameNS(S, "cellXfs").item(0) as? Element)
            ?.childElements(S, "xf").orEmpty()
        return xfs.map { xf ->
            val font = fonts.getOrNull(xf.getAttribute("fontId").toIntOrNull() ?: 0)
            val fill = fills.getOrNull(xf.getAttribute("fillId").toIntOrNull() ?: 0)
            val alignment = (xf.getElementsByTagNameNS(S, "alignment").item(0) as? Element)
                ?.getAttribute("horizontal").orEmpty().ifBlank { "general" }
            val rgb = (fill?.getElementsByTagNameNS(S, "fgColor")?.item(0) as? Element)
                ?.getAttribute("rgb")?.takeIf { it.length == 8 || it.length == 6 }?.takeLast(6)
            val numFmt = xf.getAttribute("numFmtId").toIntOrNull() ?: 0
            CellAppearance(
                bold = (font?.getElementsByTagNameNS(S, "b")?.length ?: 0) > 0,
                italic = (font?.getElementsByTagNameNS(S, "i")?.length ?: 0) > 0,
                underline = (font?.getElementsByTagNameNS(S, "u")?.length ?: 0) > 0,
                alignment = alignment, fillRgb = rgb,
                percent = numFmt == 9 || numFmt == 10
            )
        }
    }

    fun writeWorkbook(original: ByteArray, edits: List<CellChange>, styles: List<StyleChange> = emptyList()): ByteArray {
        require(edits.size + styles.size <= 3000) { "Tối đa 3000 thao tác ô cho mỗi lần lưu ở phiên bản thử nghiệm." }
        if (edits.isEmpty() && styles.isEmpty()) return original.copyOf()
        val validPaths = readWorkbook(original).sheets.map { it.partPath }.toSet()
        val zip = unzip(original).toMutableMap()
        val grouped = edits.groupBy { it.sheetPath }
        val styled = styles.groupBy { it.sheetPath }
        val stylesheet = if (styles.isNotEmpty()) {
            val bytes = zip["xl/styles.xml"] ?: error("Tệp XLSX không có styles.xml để ghi định dạng.")
            parse(bytes)
        } else null
        (grouped.keys + styled.keys).forEach { path ->
            require(path in validPaths) { "Worksheet không thuộc tài liệu: $path" }
            val doc = parse(zip.getValue(path))
            grouped[path].orEmpty().forEach { change ->
                updateCell(doc, change.address, change.value, change.cachedValue)
            }
            styled[path].orEmpty().forEach { change ->
                updateCellStyle(doc, stylesheet ?: error("Thiếu style."), change)
            }
            zip[path] = serialize(doc)
        }
        if (stylesheet != null) zip["xl/styles.xml"] = serialize(stylesheet)
        // A different calculation result might be required when opening with Excel/LibreOffice.
        zip["xl/workbook.xml"]?.let { old ->
            val doc = parse(old)
            val root = doc.documentElement
            val calcPr = doc.getElementsByTagNameNS(S, "calcPr").item(0) as? Element
                ?: doc.createElementNS(S, "calcPr").also(root::appendChild)
            calcPr.setAttribute("fullCalcOnLoad", "1")
            calcPr.setAttribute("forceFullCalc", "1")
            zip["xl/workbook.xml"] = serialize(doc)
        }
        // When formulas are edited, the old calcChain is no longer trustworthy.
        if (edits.any { it.value.trim().startsWith("=") } && zip.remove("xl/calcChain.xml") != null) {
            zip["xl/_rels/workbook.xml.rels"]?.let { old ->
                val rels = parse(old)
                removeWhere(rels.documentElement, "Relationship", PKG_R) {
                    (it as Element).getAttribute("Type").endsWith("/calcChain")
                }
                zip["xl/_rels/workbook.xml.rels"] = serialize(rels)
            }
            zip["[Content_Types].xml"]?.let { old ->
                val ct = parse(old)
                removeWhere(ct.documentElement, "Override", CT) {
                    (it as Element).getAttribute("PartName") == "/xl/calcChain.xml"
                }
                zip["[Content_Types].xml"] = serialize(ct)
            }
        }
        return zipEntries(zip)
    }

    private fun removeWhere(root: Element, name: String, namespace: String, condition: (Node) -> Boolean) {
        val nodes = root.getElementsByTagNameNS(namespace, name).asSequence().toList()
        nodes.filter(condition).forEach { it.parentNode.removeChild(it) }
    }

    private fun updateCell(document: Document, address: String, text: String, cachedValue: String? = null) {
        val normalized = address.trim().uppercase(Locale.ROOT)
        require(normalized.matches(Regex("[A-Z]{1,3}[1-9][0-9]{0,5}"))) { "Địa chỉ ô không hợp lệ: $address" }
        val cell = locateCell(document, normalized)
        // Keep attributes such as style 's'; remove only old value/formula contents.
        val children = (0 until cell.childNodes.length).map { cell.childNodes.item(it) }
        children.filter { it.localName in setOf("f", "v", "is") && it.namespaceURI == S }
            .forEach(cell::removeChild)
        val cleaned = text.trim()
        when {
            cleaned.startsWith("=") && cleaned.length > 1 -> {
                cell.removeAttribute("t")
                cell.appendChild(document.createElementNS(S, "f").also { it.textContent = cleaned.substring(1) })
                if (cachedValue != null) {
                    cell.appendChild(document.createElementNS(S, "v").also { it.textContent = cachedValue })
                }
            }
            cleaned.matches(Regex("[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[Ee][+-]?[0-9]+)?")) -> {
                cell.removeAttribute("t")
                cell.appendChild(document.createElementNS(S, "v").also { it.textContent = cleaned })
            }
            else -> {
                cell.setAttribute("t", "inlineStr")
                val inline = document.createElementNS(S, "is")
                val t = document.createElementNS(S, "t")
                t.setAttributeNS(XML, "xml:space", "preserve")
                t.textContent = text
                inline.appendChild(t)
                cell.appendChild(inline)
            }
        }
    }


    /** Creates only the target cell; all unrelated rows, formulas and styles remain unchanged. */
    private fun locateCell(document: Document, normalized: String): Element {
        require(normalized.matches(Regex("[A-Z]{1,3}[1-9][0-9]{0,5}"))) { "Địa chỉ ô không hợp lệ: $normalized" }
        val rowNo = normalized.dropWhile(Char::isLetter).toInt()
        val column = colNumber(normalized.takeWhile(Char::isLetter))
        require(rowNo in 1..PREVIEW_MAX_ROWS && column in 1..PREVIEW_MAX_COLUMNS) {
            "Chế độ cơ bản chỉ chỉnh sửa A1:IV100000."
        }
        val root = document.documentElement
        val sheetData = root.getElementsByTagNameNS(S, "sheetData").item(0) as? Element
            ?: document.createElementNS(S, "sheetData").also(root::appendChild)
        val row = sheetData.childElements(S, "row").firstOrNull { it.getAttribute("r").toIntOrNull() == rowNo }
            ?: document.createElementNS(S, "row").also { newRow ->
                newRow.setAttribute("r", rowNo.toString())
                val next = sheetData.childElements(S, "row").firstOrNull {
                    (it.getAttribute("r").toIntOrNull() ?: Int.MAX_VALUE) > rowNo
                }
                sheetData.insertBefore(newRow, next)
            }
        return row.childElements(S, "c").firstOrNull { it.getAttribute("r").equals(normalized, true) }
            ?: document.createElementNS(S, "c").also { newCell ->
                newCell.setAttribute("r", normalized)
                val next = row.childElements(S, "c").firstOrNull {
                    colNumber(it.getAttribute("r").takeWhile(Char::isLetter)) > column
                }
                row.insertBefore(newCell, next)
            }
    }

    /** Clone the original xf/font so other formatting (borders, size, formats) remains intact. */
    private fun updateCellStyle(sheet: Document, styles: Document, change: StyleChange) {
        val cell = locateCell(sheet, change.address.uppercase(Locale.ROOT))
        val root = styles.documentElement
        val fonts = root.getElementsByTagNameNS(S, "fonts").item(0) as? Element
            ?: error("Không tìm thấy danh sách font trong styles.xml")
        val fills = root.getElementsByTagNameNS(S, "fills").item(0) as? Element
            ?: error("Không tìm thấy danh sách fill trong styles.xml")
        val xfs = root.getElementsByTagNameNS(S, "cellXfs").item(0) as? Element
            ?: error("Không tìm thấy danh sách cellXfs trong styles.xml")
        val xfArray = xfs.childElements(S, "xf")
        val originalXf = xfArray.getOrNull(cell.getAttribute("s").toIntOrNull() ?: 0)
            ?: xfArray.firstOrNull() ?: error("styles.xml không có cellXfs")
        val newXf = originalXf.cloneNode(true) as Element
        if (change.bold != null || change.italic != null || change.underline != null) {
            val allFonts = fonts.childElements(S, "font")
            val originalFont = allFonts.getOrNull(originalXf.getAttribute("fontId").toIntOrNull() ?: 0)
                ?: allFonts.firstOrNull() ?: error("styles.xml không có font")
            val font = originalFont.cloneNode(true) as Element
            fun toggle(name: String, value: Boolean?) {
                if (value == null) return
                font.childElements(S, name).forEach(font::removeChild)
                if (value) font.appendChild(styles.createElementNS(S, name))
            }
            toggle("b", change.bold)
            toggle("i", change.italic)
            toggle("u", change.underline)
            val fontIndex = fonts.childElements(S, "font").size
            fonts.appendChild(font)
            fonts.setAttribute("count", (fontIndex + 1).toString())
            newXf.setAttribute("fontId", fontIndex.toString())
            newXf.setAttribute("applyFont", "1")
        }
        if (change.fillRgb != null) {
            if (change.fillRgb.isBlank()) {
                newXf.setAttribute("fillId", "0")
            } else {
                val rgb = change.fillRgb.uppercase(Locale.ROOT)
                require(rgb.matches(Regex("[0-9A-F]{6}"))) { "Màu RGB không hợp lệ." }
                val newFill = styles.createElementNS(S, "fill")
                val pattern = styles.createElementNS(S, "patternFill")
                pattern.setAttribute("patternType", "solid")
                pattern.appendChild(styles.createElementNS(S, "fgColor").also { it.setAttribute("rgb", "FF$rgb") })
                pattern.appendChild(styles.createElementNS(S, "bgColor").also { it.setAttribute("indexed", "64") })
                newFill.appendChild(pattern)
                val fillIndex = fills.childElements(S, "fill").size
                fills.appendChild(newFill)
                fills.setAttribute("count", (fillIndex + 1).toString())
                newXf.setAttribute("fillId", fillIndex.toString())
            }
            newXf.setAttribute("applyFill", "1")
        }
        if (change.alignment != null) {
            val align = (newXf.childElements(S, "alignment").firstOrNull()
                ?: styles.createElementNS(S, "alignment").also(newXf::appendChild))
            align.setAttribute("horizontal", change.alignment)
            newXf.setAttribute("applyAlignment", "1")
        }
        if (change.numFmtId != null) {
            newXf.setAttribute("numFmtId", change.numFmtId.toString())
            newXf.setAttribute("applyNumberFormat", "1")
        }
        val xfIndex = xfs.childElements(S, "xf").size
        xfs.appendChild(newXf)
        xfs.setAttribute("count", (xfIndex + 1).toString())
        cell.setAttribute("s", xfIndex.toString())
    }

    fun readPresentation(original: ByteArray): List<Slide> {
        val zip = unzip(original)
        val paths = zip.keys.filter { it.matches(Regex("ppt/slides/slide[0-9]+\\.xml")) }
            .sortedBy { it.substringAfterLast("/slide").substringBefore(".xml").toInt() }
        return paths.mapIndexed { index, path ->
            val doc = parse(zip.getValue(path))
            val paragraphs = doc.getElementsByTagNameNS(A, "p").asSequence().map { item ->
                val element = item as Element
                element.getElementsByTagNameNS(A, "t").asSequence().joinToString("") { it.textContent.orEmpty() }
            }.toList()
            Slide(index + 1, path, paragraphs)
        }
    }

    /** Edits existing slide text in-place; it cannot create shapes, alter geometry or add slides. */
    fun writePresentation(original: ByteArray, edits: List<SlideChange>): ByteArray {
        if (edits.isEmpty()) return original.copyOf()
        val parts = unzip(original).toMutableMap()
        val valid = readPresentation(original).map { it.partPath }.toSet()
        edits.groupBy { it.partPath }.forEach { (path, changes) ->
            require(path in valid) { "Slide không nằm trong tệp PPTX." }
            val xml = parse(parts.getValue(path))
            val paragraphs = xml.getElementsByTagNameNS(A, "p").asSequence().map { it as Element }.toList()
            changes.forEach { change ->
                require(change.index in paragraphs.indices) { "Không tìm thấy đoạn chữ trên slide." }
                val paragraph = paragraphs[change.index]
                val tNodes = paragraph.getElementsByTagNameNS(A, "t")
                require(tNodes.length > 0) { "Chỉ chỉnh sửa đoạn đã có văn bản." }
                for (i in 0 until tNodes.length) {
                    tNodes.item(i).textContent = if (i == 0) change.text else ""
                }
            }
            parts[path] = serialize(xml)
        }
        return zipEntries(parts)
    }

    /** A strict document size guard prevents huge or malicious ZIP inflation. */
    private fun unzip(source: ByteArray): LinkedHashMap<String, ByteArray> {
        require(source.size <= MAX_TOTAL) { "Tệp vượt quá 96 MB." }
        val parts = linkedMapOf<String, ByteArray>()
        var totalSize = 0L
        ZipInputStream(ByteArrayInputStream(source)).use { stream ->
            while (true) {
                val entry = stream.nextEntry ?: break
                if (!entry.isDirectory) {
                    require(totalEntries(parts) <= MAX_ENTRIES) { "Tệp chứa quá nhiều thành phần." }
                    val bytes = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    while (true) {
                        val read = stream.read(buffer)
                        if (read < 0) break
                        bytes.write(buffer, 0, read)
                        totalSize += read
                        require(bytes.size() <= MAX_ENTRY && totalSize <= MAX_TOTAL) {
                            "Tệp Office quá lớn hoặc có dấu hiệu ZIP bomb."
                        }
                    }
                    val name = entry.name
                    require(!name.startsWith('/') && !name.contains("..")) { "Đường dẫn không an toàn trong tệp Office." }
                    parts[name] = bytes.toByteArray()
                }
                stream.closeEntry()
            }
        }
        return LinkedHashMap(parts)
    }

    private fun totalEntries(entries: Map<String, ByteArray>): Int = entries.size + 1

    private fun zipEntries(entries: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            entries.forEach { (name, bytes) ->
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun parse(bytes: ByteArray): Document {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = true
        runCatching { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { f.setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        f.isExpandEntityReferences = false
        val builder = f.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> org.xml.sax.InputSource(StringReader("")) }
        return builder.parse(ByteArrayInputStream(bytes))
    }

    private fun serialize(document: Document): ByteArray {
        val factory = TransformerFactory.newInstance()
        try { factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) } catch (_: Exception) { }
        val transformer = factory.newTransformer()
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
        transformer.setOutputProperty(OutputKeys.INDENT, "no")
        val out = ByteArrayOutputStream()
        transformer.transform(DOMSource(document), StreamResult(out))
        return out.toByteArray()
    }

    private fun normalizePartPath(base: String, target: String): String {
        val sections = mutableListOf<String>()
        val raw = if (target.startsWith('/')) target.removePrefix("/") else "$base/$target"
        raw.replace('\\', '/').split('/').forEach {
            when (it) {
                "", "." -> Unit
                ".." -> if (sections.isNotEmpty()) sections.removeAt(sections.lastIndex) else error("Đường dẫn ngoài gói OOXML")
                else -> sections += it
            }
        }
        return sections.joinToString("/")
    }

    private fun org.w3c.dom.NodeList.asSequence(): Sequence<Node> = sequence {
        for (i in 0 until length) yield(item(i))
    }
    private fun Element.childElements(ns: String, local: String): List<Element> =
        (0 until childNodes.length).mapNotNull { childNodes.item(it) as? Element }
            .filter { it.namespaceURI == ns && it.localName == local }

    private fun colNumber(letters: String): Int {
        if (letters.isEmpty()) return -1
        var number = 0
        for (char in letters.uppercase(Locale.ROOT)) {
            if (char !in 'A'..'Z') return -1
            number = number * 26 + (char - 'A') + 1
        }
        return number
    }

    fun cellAddress(row: Int, column: Int): String {
        require(row >= 1 && column in 1..16384)
        var c = column
        val label = StringBuilder()
        while (c > 0) {
            c--
            label.append(('A'.code + c % 26).toChar())
            c /= 26
        }
        return label.reverse().toString() + row
    }
}


// ================ PdfTools.kt ================
object PdfTools {
    private fun ready(context: Context) { PDFBoxResourceLoader.init(context.applicationContext) }

    fun merge(context: Context, inputFiles: List<Uri>, output: OutputStream) {
        require(inputFiles.size >= 2) { "Chọn tối thiểu hai tệp PDF để ghép." }
        ready(context)
        PDDocument().use { target ->
            val merger = PDFMergerUtility()
            inputFiles.forEach { uri ->
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    PDDocument.load(stream).use { document -> merger.appendDocument(target, document) }
                } ?: throw IOException("Không mở được PDF: $uri")
            }
            target.save(output)
        }
    }

    /** 1-based page range e.g. "1-3,5,8-9" */
    fun extract(context: Context, source: Uri, pages: String, output: OutputStream) {
        ready(context)
        context.contentResolver.openInputStream(source)?.use { stream ->
            PDDocument.load(stream).use { document ->
                val indices = parsePageRange(pages, document.numberOfPages)
                PDDocument().use { result ->
                    indices.forEach { page -> result.importPage(document.getPage(page - 1)) }
                    result.save(output)
                }
            }
        } ?: throw IOException("Không mở được tệp PDF nguồn.")
    }

    fun parsePageRange(spec: String, total: Int): List<Int> {
        require(total > 0)
        val unique = linkedSetOf<Int>()
        spec.split(',').forEach { part ->
            val token = part.trim()
            require(token.matches(Regex("[1-9][0-9]*(?:\\s*-\\s*[1-9][0-9]*)?"))) { "Khoảng trang không hợp lệ: $token" }
            val numbers = token.split('-').map { it.trim().toInt() }
            val start = numbers.first()
            val end = numbers.last()
            require(start <= end && start in 1..total && end in 1..total) { "Trang phải thuộc khoảng 1..$total" }
            require(end - start <= 2000) { "Khoảng trang quá dài." }
            for (index in start..end) unique.add(index)
        }
        require(unique.isNotEmpty()) { "Chưa chọn trang." }
        return unique.toList()
    }

    fun renderPage(context: Context, uri: Uri, pageIndex: Int, maxWidth: Int = 1280): Pair<Bitmap, Int> {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Không mở được PDF.")
        descriptor.use { fd ->
            PdfRenderer(fd).use { renderer ->
                require(pageIndex in 0 until renderer.pageCount) { "Trang không hợp lệ." }
                renderer.openPage(pageIndex).use { page ->
                    val scale = min(maxWidth.toFloat() / page.width, 3f).coerceAtLeast(0.2f)
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap to renderer.pageCount
                }
            }
        }
    }

    fun pagePng(context: Context, uri: Uri, pageIndex: Int, output: OutputStream) {
        val (bitmap, _) = renderPage(context, uri, pageIndex, 1900)
        try {
            require(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) { "Không thể ghi PNG." }
        } finally { bitmap.recycle() }
    }

    fun imagesToPdf(context: Context, uris: List<Uri>, output: OutputStream) {
        require(uris.isNotEmpty()) { "Chưa chọn hình ảnh." }
        val pdf = PdfDocument()
        try {
            val pageWidth = 595
            val pageHeight = 842
            val padding = 28f
            uris.forEachIndexed { index, uri ->
                val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
                    val buffer = ByteArrayOutputStream()
                    val chunk = ByteArray(8192)
                    while (true) {
                        val n = stream.read(chunk)
                        if (n < 0) break
                        require(buffer.size() + n <= 24 * 1024 * 1024) { "Ảnh quá lớn." }
                        buffer.write(chunk, 0, n)
                    }
                    buffer.toByteArray()
                } ?: throw IOException("Không đọc được hình ảnh: $uri")
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Định dạng ảnh không hợp lệ." }
                var sample = 1
                while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    ?: throw IOException("Không giải mã được hình ảnh.")
                try {
                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create())
                    page.canvas.drawColor(Color.WHITE)
                    val xScale = (pageWidth - padding * 2) / bitmap.width
                    val yScale = (pageHeight - padding * 2) / bitmap.height
                    val ratio = min(xScale, yScale)
                    val width = bitmap.width * ratio
                    val height = bitmap.height * ratio
                    page.canvas.drawBitmap(bitmap, null,
                        android.graphics.RectF((pageWidth - width) / 2f, (pageHeight - height) / 2f,
                            (pageWidth + width) / 2f, (pageHeight + height) / 2f),
                        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    pdf.finishPage(page)
                } finally { bitmap.recycle() }
            }
            pdf.writeTo(output)
        } finally {
            pdf.close()
        }
    }
}

/** Simple text-to-PDF fallback; it does not preserve Word/Excel page layout. */
object TextPdfExporter {
    fun create(text: String, output: OutputStream, title: String = "Tài liệu") {
        val document = PdfDocument()
        try {
            val width = 595
            val height = 842
            val margin = 42f
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(30, 40, 56)
                textSize = 12f
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            }
            val lineHeight = 19f
            var pageNumber = 0
            var y = 0f
            var page: PdfDocument.Page? = null
            fun nextPage() {
                if (page != null) document.finishPage(page!!)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create())
                page!!.canvas.drawColor(Color.WHITE)
                y = margin
                paint.textSize = 9f
                paint.color = Color.GRAY
                page!!.canvas.drawText("$title  |  $pageNumber", margin, y, paint)
                paint.textSize = 12f
                paint.color = Color.rgb(30, 40, 56)
                y += 32f
            }
            nextPage()
            for (line in text.replace("\r\n", "\n").split('\n')) {
                val fragments = wrap(line, paint, width - 2 * margin)
                for (fragment in fragments) {
                    if (y > height - margin) nextPage()
                    page!!.canvas.drawText(fragment, margin, y, paint)
                    y += lineHeight
                }
            }
            if (page != null) document.finishPage(page!!)
            document.writeTo(output)
        } finally {
            document.close()
        }
    }

    private fun wrap(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isEmpty()) return listOf("")
        val lines = mutableListOf<String>()
        var rest = text.replace('\t', ' ')
        while (rest.isNotEmpty()) {
            val fit = paint.breakText(rest, true, maxWidth, null).coerceAtLeast(1)
            if (fit >= rest.length) {
                lines.add(rest)
                break
            }
            val end = rest.lastIndexOf(' ', fit).takeIf { it > 0 } ?: fit
            lines.add(rest.substring(0, end).trimEnd())
            rest = rest.substring(end).trimStart()
        }
        return lines
    }
}


// ================ CsvEngine.kt ================
/** RFC 4180-style quoted fields; supports commas, escaped quotes and CRLF/newlines. */
object CsvEngine {
    fun parse(input: String, maxRows: Int = 5000): List<List<String>> {
        val result = mutableListOf<List<String>>()
        var record = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < input.length) {
            val ch = input[i]
            when {
                inQuotes && ch == '"' && i + 1 < input.length && input[i + 1] == '"' -> {
                    field.append('"')
                    i++
                }
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    record.add(field.toString())
                    field.setLength(0)
                }
                (ch == '\r' || ch == '\n') && !inQuotes -> {
                    record.add(field.toString())
                    result.add(record)
                    if (result.size >= maxRows) error("CSV quá lớn cho chế độ chỉnh sửa cơ bản.")
                    record = mutableListOf()
                    field.setLength(0)
                    if (ch == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
                }
                else -> field.append(ch)
            }
            i++
        }
        if (inQuotes) error("CSV không hợp lệ: thiếu dấu nháy đóng.")
        if (field.isNotEmpty() || record.isNotEmpty()) {
            record.add(field.toString())
            result.add(record)
        }
        return result
    }

    fun write(rows: List<List<String>>): String = rows.joinToString("\r\n") { row ->
        row.joinToString(",") { cell ->
            if (cell.any { it == ',' || it == '\n' || it == '\r' || it == '"' })
                "\"" + cell.replace("\"", "\"\"") + "\""
            else cell
        }
    }
}

// ================ PDF -> Excel (layout-aware offline conversion) ================
/**
 * PDF pages are drawings, not spreadsheets. This converter reconstructs editable
 * XLSX cells from vector table borders + positioned text when they exist.
 * Each page also has an ORIGINAL image reference sheet for visual checking.
 * Scan-only pages become an embedded image, NOT fake editable text: real OCR
 * would require an OCR model which is not included in this build.
 */
object PdfExcelConverter {
    private const val MAX_PAGES = 80
    private const val MAX_INPUT_BYTES = 75L * 1024 * 1024
    private const val MAX_GLYPHS = 90_000
    private const val MAX_CELLS = 95_000

    fun convert(context: Context, uri: Uri, output: OutputStream) {
        PDFBoxResourceLoader.init(context.applicationContext)
        val temporary = java.io.File.createTempFile("docflow_pdf_to_excel_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                temporary.outputStream().buffered().use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var copied = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        copied += n
                        if (copied > MAX_INPUT_BYTES) throw IOException("PDF quá lớn để chuyển offline (tối đa 75 MB).")
                        out.write(buffer, 0, n)
                    }
                }
            } ?: throw IOException("Không mở được PDF nguồn.")
            java.io.FileInputStream(temporary).use { source ->
                PDDocument.load(source).use { pdf ->
                    val pages = pdf.numberOfPages
                    require(pages in 1..MAX_PAGES) { "Hỗ trợ PDF từ 1 đến $MAX_PAGES trang trong một lần." }
                    val result = ArrayList<OfflineXlsxWriter.SheetData>(pages * 2)
                    var total = 0
                    for (number in 1..pages) {
                        val page = pdf.getPage(number - 1)
                        val width = page.cropBox.width.coerceAtLeast(50f)
                        val height = page.cropBox.height.coerceAtLeast(50f)
                        val extractor = object : com.tom_roush.pdfbox.text.PDFTextStripper() {
                            val glyphs = ArrayList<PdfPageGrid.Glyph>()
                            init { sortByPosition = true; startPage = number; endPage = number }
                            override fun writeString(text: String, textPositions: MutableList<com.tom_roush.pdfbox.text.TextPosition>) {
                                for (pos in textPositions) {
                                    val value = pos.unicode ?: continue
                                    if (value.isBlank()) continue
                                    if (glyphs.size >= MAX_GLYPHS) throw IOException("Trang $number chứa quá nhiều ký tự.")
                                    glyphs.add(PdfPageGrid.Glyph(
                                        value, pos.xDirAdj, pos.yDirAdj,
                                        pos.widthDirAdj.coerceAtLeast(0.1f), pos.heightDir.coerceAtLeast(1f),
                                        pos.fontSizeInPt.coerceIn(6f, 34f),
                                        pos.font?.name?.contains("Bold", true) == true
                                    ))
                                }
                            }
                        }
                        extractor.getText(pdf)
                        val graphics = if ((page.rotation % 360 + 360) % 360 == 0) {
                            runCatching { PdfVectorGrid(page, height).apply { processPage(page) } }.getOrNull()
                        } else null
                        val hasText = extractor.glyphs.size >= 2
                        val image = renderReference(temporary, number - 1)
                        if (hasText) {
                            val grid = PdfPageGrid.analyze(
                                extractor.glyphs, graphics?.lines.orEmpty(), graphics?.fills.orEmpty(),
                                width, height
                            )
                            total += grid.rows.sumOf { it.size }
                            require(total <= MAX_CELLS) { "Vượt $MAX_CELLS ô. Hãy chia PDF thành tệp nhỏ hơn." }
                            result.add(grid.copy(name = "Trang $number"))
                            result.add(OfflineXlsxWriter.SheetData(
                                name = "Gốc $number",
                                rows = listOf(mapOf(0 to "Ảnh đối chiếu PDF gốc (không sửa chữ trong ảnh).")),
                                referenceJpeg = image, pageWidthPt = width, pageHeightPt = height
                            ))
                        } else {
                            // A scan does NOT magically become editable text without OCR.
                            result.add(OfflineXlsxWriter.SheetData(
                                name = "Trang $number (ảnh)",
                                rows = listOf(mapOf(0 to "PDF scan: chưa có OCR, nội dung là ảnh tham chiếu.")),
                                referenceJpeg = image, pageWidthPt = width, pageHeightPt = height
                            ))
                        }
                    }
                    OfflineXlsxWriter.write(result, output)
                }
            }
        } finally {
            temporary.delete()
        }
    }

    private fun renderReference(file: java.io.File, index: Int): ByteArray {
        val fd = android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
        android.graphics.pdf.PdfRenderer(fd).use { renderer ->
            renderer.openPage(index).use { page ->
                val scale = minOf(1.8f, 1400f / maxOf(page.width, page.height).toFloat())
                val w = (page.width * scale).toInt().coerceAtLeast(1)
                val h = (page.height * scale).toInt().coerceAtLeast(1)
                val bitmap = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                try {
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return ByteArrayOutputStream().use { out ->
                        check(bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out))
                        out.toByteArray()
                    }
                } finally { bitmap.recycle() }
            }
        }
    }
}

/** PDF vector graphic callback signatures follow PdfBox-Android, not desktop PDFBox. */
internal class PdfVectorGrid(
    page: com.tom_roush.pdfbox.pdmodel.PDPage, private val pageHeight: Float
) : com.tom_roush.pdfbox.contentstream.PDFGraphicsStreamEngine(page) {
    data class Line(val x1: Float, val y1: Float, val x2: Float, val y2: Float)
    data class Fill(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val rgb: String)
    val lines = mutableListOf<Line>()
    val fills = mutableListOf<Fill>()
    private val path = ArrayList<Line>()
    private var current = android.graphics.PointF()
    private var first = android.graphics.PointF()

    private fun segment(x1: Float, y1: Float, x2: Float, y2: Float) {
        if (path.size >= 6000) return
        if (kotlin.math.abs(x1 - x2) < 0.65f || kotlin.math.abs(y1 - y2) < 0.65f) {
            path.add(Line(x1, pageHeight - y1, x2, pageHeight - y2))
        }
    }
    override fun appendRectangle(p0: android.graphics.PointF, p1: android.graphics.PointF,
                                 p2: android.graphics.PointF, p3: android.graphics.PointF) {
        segment(p0.x,p0.y,p1.x,p1.y);segment(p1.x,p1.y,p2.x,p2.y)
        segment(p2.x,p2.y,p3.x,p3.y);segment(p3.x,p3.y,p0.x,p0.y)
        first = android.graphics.PointF(p0.x,p0.y); current = android.graphics.PointF(p0.x,p0.y)
    }
    override fun moveTo(x: Float, y: Float) { current = android.graphics.PointF(x,y); first = android.graphics.PointF(x,y) }
    override fun lineTo(x: Float, y: Float) {
        segment(current.x,current.y,x,y); current = android.graphics.PointF(x,y)
    }
    override fun curveTo(x1: Float,y1: Float,x2: Float,y2: Float,x3: Float,y3: Float) {
        current = android.graphics.PointF(x3,y3) // Curves are not spreadsheet grid lines.
    }
    override fun getCurrentPoint(): android.graphics.PointF = current
    override fun closePath() { segment(current.x,current.y,first.x,first.y); current = first }
    override fun clip(windingRule: android.graphics.Path.FillType) = Unit
    override fun endPath() { path.clear() }
    override fun strokePath() { if (lines.size < 10000) lines.addAll(path.take(10000-lines.size)); path.clear() }
    override fun fillPath(windingRule: android.graphics.Path.FillType) {
        // A rectangular filled area can be used for Excel background color.
        if (path.size == 4 && fills.size < 1000) {
            val points = path.flatMap { listOf(it.x1 to it.y1, it.x2 to it.y2) }
            val left = points.minOf { it.first }; val right = points.maxOf { it.first }
            val top = points.minOf { it.second }; val bottom = points.maxOf { it.second }
            if (right-left > 6f && bottom-top > 5f) {
                val color = runCatching { getGraphicsState().nonStrokingColor.toRGB() }.getOrNull()
                if (color != null) {
                    val rgb = "%06X".format(color and 0xFFFFFF)
                    if (rgb != "FFFFFF") fills.add(Fill(left,top,right,bottom,rgb))
                }
            }
        }
        path.clear()
    }
    override fun fillAndStrokePath(windingRule: android.graphics.Path.FillType) {
        val saved = path.toList(); fillPath(windingRule)
        if (lines.size < 10000) lines.addAll(saved.take(10000-lines.size))
    }
    override fun drawImage(pdImage: com.tom_roush.pdfbox.pdmodel.graphics.image.PDImage) = Unit
    override fun shadingFill(shadingName: com.tom_roush.pdfbox.cos.COSName) = Unit
}

/** Pure data/geometry core: runnable with JVM unit tests, no Android dependency. */
internal object PdfPageGrid {
    data class Glyph(val text: String, val x: Float, val y: Float, val w: Float, val h: Float,
                     val fontSize: Float = 11f, val bold: Boolean = false)

    private fun quantize(values: List<Float>, tolerance: Float): List<Float> {
        if (values.isEmpty()) return emptyList()
        val sorted = values.filter { it.isFinite() }.sorted()
        if (sorted.isEmpty()) return emptyList()
        val result = ArrayList<Float>()
        var start = sorted.first(); var sum = start; var size = 1
        for (v in sorted.drop(1)) {
            if (v - start <= tolerance) { sum += v; size++ }
            else { result.add(sum / size); start = v; sum = v; size = 1 }
        }
        result.add(sum / size)
        return result
    }
    private fun bracket(v: Float, edges: List<Float>): Int =
        (edges.binarySearch(v).let { if (it >= 0) it.coerceAtMost(edges.lastIndex - 1) else -it - 2 })
            .coerceIn(0, edges.size - 2)

    private data class TextLine(val y: Float, val h: Float, val chars: MutableList<Glyph>)
    private fun textLines(glyphs: List<Glyph>): List<TextLine> {
        val lines = ArrayList<TextLine>()
        for (g in glyphs.sortedWith(compareBy<Glyph> { it.y }.thenBy { it.x })) {
            val line = lines.lastOrNull()
            if (line != null && kotlin.math.abs(g.y-line.y) < maxOf(2.5f, minOf(4f,g.h*.4f))) {
                line.chars.add(g)
            } else lines.add(TextLine(g.y,g.h, mutableListOf(g)))
        }
        return lines
    }
    fun analyze(glyphs: List<Glyph>, sourceLines: List<PdfVectorGrid.Line>, fills: List<PdfVectorGrid.Fill>,
                width: Float, height: Float): OfflineXlsxWriter.SheetData {
        val lines = textLines(glyphs)
        val vertical = sourceLines.filter { kotlin.math.abs(it.x1-it.x2) < 1.1f && kotlin.math.abs(it.y2-it.y1) > 8f }
        val horizontal = sourceLines.filter { kotlin.math.abs(it.y1-it.y2) < 1.1f && kotlin.math.abs(it.x2-it.x1) > 15f }
        val grid = vertical.size >= 3 && horizontal.size >= 3
        if (!grid) {
            // Preserve v0.7 table extraction for unruled PDFs. Avoid making up borders.
            val rows = PdfTableLayout.extract(glyphs.map { PdfTableLayout.Glyph(it.text,it.x,it.y,it.w,it.h) })
            return OfflineXlsxWriter.SheetData("Trang", rows)
        }
        val tableXs = quantize(vertical.map { it.x1 }.filter { it in 0f..width }, 2f)
        val tableYs = quantize(horizontal.map { it.y1 }.filter { it in 0f..height }, 2f)
        if (tableXs.size < 2 || tableYs.size < 2 || tableXs.size > 55 || tableYs.size > 550) {
            val rows = PdfTableLayout.extract(glyphs.map { PdfTableLayout.Glyph(it.text,it.x,it.y,it.w,it.h) })
            return OfflineXlsxWriter.SheetData("Trang", rows)
        }
        val xs = (listOf(0f) + tableXs + listOf(width)).sorted().let { quantize(it,1.5f) }
        val ysBase = (listOf(0f) + tableYs + listOf(height)).sorted().let { quantize(it,1.5f) }
        // Add missing row boundaries for text outside ruled tables, e.g. headings/footers.
        val moreY = ArrayList<Float>()
        for (i in 0 until lines.size-1) {
            val a = lines[i]; val b = lines[i+1]
            if (b.y-a.y > 9f && bracket(a.y-a.h/2,ysBase) == bracket(b.y-b.h/2,ysBase)) {
                val between = (a.y+b.y)/2f
                val section = bracket(between,ysBase)
                val hasRuledRows = tableYs.any { it > ysBase[section]+1.5f && it < ysBase[section+1]-1.5f }
                if (!hasRuledRows) moreY.add(between)
            }
        }
        val ys = quantize((ysBase+moreY).sorted(), 1.4f)
        val rowCount = ys.size-1; val colCount = xs.size-1
        if (rowCount <= 0 || colCount <= 0 || rowCount > 560) throw IOException("Bảng quá phức tạp để dựng thành Excel.")
        if (rowCount * colCount > 12_000) {
            // Avoid quadratic line intersection work on huge drawings; preserve the
            // original appearance in the companion screenshot sheet instead.
            return OfflineXlsxWriter.SheetData("Trang", PdfTableLayout.extract(
                glyphs.map { PdfTableLayout.Glyph(it.text,it.x,it.y,it.w,it.h) }
            ))
        }
        val values = ArrayList<MutableMap<Int,String>>(rowCount)
        repeat(rowCount) { values.add(LinkedHashMap()) }
        val styles = LinkedHashMap<Pair<Int,Int>, OfflineXlsxWriter.CellStyle>()
        val merged = ArrayList<OfflineXlsxWriter.Merge>()
        fun verticalHere(x: Float, top: Float, bottom: Float): Boolean = vertical.any {
            kotlin.math.abs(it.x1-x) < 2.2f &&
                maxOf(it.y1,it.y2) >= bottom-2.2f && minOf(it.y1,it.y2) <= top+2.2f
        }
        fun horizontalHere(y: Float, left: Float, right: Float): Boolean = horizontal.any {
            kotlin.math.abs(it.y1-y) < 2.2f &&
                maxOf(it.x1,it.x2) >= right-2.2f && minOf(it.x1,it.x2) <= left+2.2f
        }
        // Pre-create ruled blank cells so the visible table grid survives export.
        for (r in 0 until rowCount) for (c in 0 until colCount) {
            val l=xs[c]; val rr=xs[c+1]; val t=ys[r]; val b=ys[r+1]
            val borders = OfflineXlsxWriter.Borders(
                left=verticalHere(l,t,b), right=verticalHere(rr,t,b),
                top=horizontalHere(t,l,rr), bottom=horizontalHere(b,l,rr)
            )
            val fill = fills.lastOrNull { it.x1 <= l+1 && it.x2 >= rr-1 && it.y1 <= t+1 && it.y2 >= b-1 }?.rgb
            if (borders != OfflineXlsxWriter.Borders() || fill != null) {
                styles[r to c] = OfflineXlsxWriter.CellStyle(borders=borders, fillRgb=fill)
            }
        }
        for (line in lines) {
            val r = bracket(line.y-line.h/2,ys)
            val row = line.chars.sortedBy { it.x }
            val outsideTable = line.y < tableYs.first() - 2f || line.y > tableYs.last() + 2f
            // Do not cut a report title into multiple cells simply because it crosses
            // an imaginary column boundary outside the actual ruled table.
            val groups = if (outsideTable) {
                sortedMapOf(bracket(row.first().x, xs) to row)
            } else row.groupBy { bracket(it.x+it.w/2,xs) }.toSortedMap()
            for ((c, chars) in groups) {
                val sorted = chars.sortedBy { it.x }
                val b = StringBuilder()
                var lastEnd = 0f
                for (g in sorted) {
                    val space = g.x-lastEnd
                    if (b.isNotEmpty() && space > maxOf(2.6f,g.h*.27f)) b.append(' ')
                    b.append(g.text)
                    lastEnd = maxOf(lastEnd,g.x+g.w)
                }
                val text = b.toString().trim().take(32700)
                if (text.isEmpty()) continue
                val prev = values[r][c]
                values[r][c] = if (prev.isNullOrBlank()) text else "$prev\n$text"
                val center = sorted.first().x+(sorted.last().x+sorted.last().w-sorted.first().x)/2f
                val align = if (kotlin.math.abs(center-(xs[c]+xs[c+1])/2f) < (xs[c+1]-xs[c])*.13f) "center" else "left"
                val current = styles[r to c] ?: OfflineXlsxWriter.CellStyle()
                styles[r to c] = current.copy(
                    bold = sorted.any { it.bold }, fontSize = sorted.map { it.fontSize }.average().toInt().coerceIn(8,22),
                    alignment = align
                )
            }
        }
        // A title or other unruled row can span columns. Only merge if no text in other columns.
        for (r in 0 until rowCount) {
            val occupied = values[r].keys.sorted()
            if (occupied.size != 1 || colCount < 3) continue
            val c=occupied[0]
            val t=ys[r]; val b=ys[r+1]
            var last=c
            while (last < colCount-1 && !verticalHere(xs[last+1],t,b) && !values[r].containsKey(last+1)) last++
            if (last>c && (b-t)<150f) merged.add(OfflineXlsxWriter.Merge(r,c,r,last))
        }
        return OfflineXlsxWriter.SheetData(
            name="Trang", rows=values, colWidthsPt=(0 until colCount).map { xs[it+1]-xs[it] },
            rowHeightsPt=(0 until rowCount).map { ys[it+1]-ys[it] },
            merges=merged, cellStyles=styles
        )
    }
}

/** Writes editable OOXML cells, merged ranges, borders, font/fill and original PDF page snapshots. */
internal object OfflineXlsxWriter {
    data class Borders(val left:Boolean=false, val right:Boolean=false, val top:Boolean=false, val bottom:Boolean=false)
    data class CellStyle(val bold:Boolean=false, val fontSize:Int=11, val fillRgb:String?=null,
                         val alignment:String="left", val borders:Borders=Borders())
    data class Merge(val r1:Int, val c1:Int, val r2:Int, val c2:Int)
    data class SheetData(
        val name:String, val rows:List<Map<Int,String>>,
        val colWidthsPt:List<Float> = emptyList(), val rowHeightsPt:List<Float> = emptyList(),
        val merges:List<Merge> = emptyList(), val cellStyles:Map<Pair<Int,Int>,CellStyle> = emptyMap(),
        val referenceJpeg:ByteArray? = null, val pageWidthPt:Float = 595f, val pageHeightPt:Float = 842f
    )
    private const val M = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
    private data class Font(val bold:Boolean, val size:Int)
    private class Styles {
        val fonts = LinkedHashMap<Font,Int>().apply { put(Font(false,11),0) }
        val fills = LinkedHashMap<String,Int>().apply { put("",0) }
        val borders = LinkedHashMap<Borders,Int>().apply { put(Borders(),0) }
        val variants = LinkedHashMap<CellStyle,Int>().apply { put(CellStyle(),0) }
        fun id(style:CellStyle):Int {
            if (style == CellStyle()) return 0
            if (variants.size >= 512) return 0 // avoid workbook style explosion
            fonts.getOrPut(Font(style.bold,style.fontSize)) { fonts.size }
            if (!style.fillRgb.isNullOrEmpty()) fills.getOrPut(style.fillRgb.uppercase(java.util.Locale.ROOT)) { fills.size+1 }
            borders.getOrPut(style.borders) { borders.size }
            return variants.getOrPut(style) { variants.size }
        }
        fun xml():String = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"$M\">")
            append("<fonts count=\"${fonts.size}\">")
            fonts.forEach { (font,_) ->
                append("<font>"); if(font.bold) append("<b/>")
                append("<sz val=\"${font.size}\"/><name val=\"Calibri\"/></font>")
            }
            append("</fonts><fills count=\"${fills.size+1}\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>")
            fills.entries.filter { it.key.isNotEmpty() }.forEach { (rgb,_) ->
                append("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF$rgb\"/><bgColor indexed=\"64\"/></patternFill></fill>")
            }
            append("</fills><borders count=\"${borders.size}\">")
            borders.forEach { (border,_) ->
                append("<border>")
                for ((n,on) in listOf("left" to border.left,"right" to border.right,"top" to border.top,"bottom" to border.bottom)) {
                    if(on) append("<$n style=\"thin\"><color rgb=\"FF7A8592\"/></$n>") else append("<$n/>")
                }
                append("<diagonal/></border>")
            }
            append("</borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>")
            append("<cellXfs count=\"${variants.size}\">")
            variants.forEach { (style,_) ->
                val fid = fonts.getValue(Font(style.bold,style.fontSize))
                val fillId=style.fillRgb?.uppercase(java.util.Locale.ROOT)?.let { fills[it] } ?: 0
                val bid=borders.getValue(style.borders)
                append("<xf numFmtId=\"0\" fontId=\"$fid\" fillId=\"$fillId\" borderId=\"$bid\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"${style.alignment}\" vertical=\"center\" wrapText=\"1\"/></xf>")
            }
            append("</cellXfs></styleSheet>")
        }
    }
    fun write(sheets:List<SheetData>, output:OutputStream) {
        require(sheets.isNotEmpty()) { "Không có trang xuất." }
        val styles=Styles()
        sheets.forEach { it.cellStyles.values.forEach(styles::id) }
        ZipOutputStream(output).use { zip ->
            fun part(name:String, bytes:ByteArray) {
                zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry()
            }
            fun xmlPart(name:String, s:String)=part(name,s.toByteArray(Charsets.UTF_8))
            val images=sheets.mapIndexedNotNull { i, s -> if(s.referenceJpeg!=null) i else null }
            xmlPart("[Content_Types].xml",buildString {
                append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>")
                if(images.isNotEmpty()) append("<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>")
                append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
                sheets.indices.forEach { append("<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>") }
                images.forEach { append("<Override PartName=\"/xl/drawings/drawing${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>") }
                append("</Types>")
            })
            xmlPart("_rels/.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            xmlPart("xl/workbook.xml", buildString {
                append("<?xml version=\"1.0\"?><workbook xmlns=\"$M\" xmlns:r=\"$REL\"><sheets>")
                sheets.forEachIndexed { i,s -> append("<sheet name=\"${escape(s.name.take(31))}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>") }
                append("</sheets></workbook>")
            })
            xmlPart("xl/_rels/workbook.xml.rels",buildString {
                append("<?xml version=\"1.0\"?><Relationships xmlns=\"$PKG\">")
                sheets.indices.forEach { append("<Relationship Id=\"rId${it+1}\" Type=\"$REL/worksheet\" Target=\"worksheets/sheet${it+1}.xml\"/>") }
                append("<Relationship Id=\"rId${sheets.size+1}\" Type=\"$REL/styles\" Target=\"styles.xml\"/></Relationships>")
            })
            xmlPart("xl/styles.xml",styles.xml())
            sheets.forEachIndexed { i,sheet ->
                xmlPart("xl/worksheets/sheet${i+1}.xml",buildSheet(sheet,styles))
                if(sheet.referenceJpeg!=null) {
                    xmlPart("xl/worksheets/_rels/sheet${i+1}.xml.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/drawing\" Target=\"../drawings/drawing${i+1}.xml\"/></Relationships>")
                    xmlPart("xl/drawings/drawing${i+1}.xml",imageDrawing(sheet))
                    xmlPart("xl/drawings/_rels/drawing${i+1}.xml.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/image\" Target=\"../media/page${i+1}.jpg\"/></Relationships>")
                    part("xl/media/page${i+1}.jpg",sheet.referenceJpeg)
                }
            }
        }
    }
    private fun buildSheet(sheet:SheetData, styles:Styles):String = buildString {
        val maxRow = maxOf(1,sheet.rows.size,sheet.rowHeightsPt.size)
        val maxCol = maxOf(1,sheet.colWidthsPt.size,(sheet.rows.flatMap { it.keys }.maxOrNull() ?: 0)+1)
        require(maxRow<=10000 && maxCol<=256) { "Kích thước bảng vượt khả năng xử lý offline." }
        append("<?xml version=\"1.0\"?><worksheet xmlns=\"$M\" xmlns:r=\"$REL\">")
        append("<dimension ref=\"A1:${column(maxCol-1)}$maxRow\"/><sheetViews><sheetView workbookViewId=\"0\"/></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/>")
        append("<cols>")
        (0 until maxCol).forEach { c ->
            val w = sheet.colWidthsPt.getOrNull(c)?.let { (it * (96.0/72.0)/7.0).coerceIn(2.0,120.0) }
                ?: 14.0
            append("<col min=\"${c+1}\" max=\"${c+1}\" width=\"${"%.2f".format(java.util.Locale.US,w)}\" customWidth=\"1\"/>")
        }
        append("</cols><sheetData>")
        for (r in 0 until maxRow) {
            val height=sheet.rowHeightsPt.getOrNull(r)?.coerceIn(10f,320f)
            append("<row r=\"${r+1}\"")
            if(height!=null) append(" ht=\"${"%.2f".format(java.util.Locale.US,height)}\" customHeight=\"1\"")
            append(">")
            val row=sheet.rows.getOrNull(r).orEmpty()
            val keys=(row.keys + sheet.cellStyles.keys.filter { it.first==r }.map { it.second }).distinct().sorted()
            for (c in keys) {
                if (c !in 0 until maxCol) continue
                val text=row[c]
                val styleId=styles.id(sheet.cellStyles[r to c]?:CellStyle())
                append("<c r=\"${column(c)}${r+1}\"")
                if (styleId != 0) append(" s=\"$styleId\"")
                if(text==null) { append("/>"); continue }
                require(text.length<=32767) { "Nội dung ô Excel vượt giới hạn 32.767 ký tự." }
                val number=numericValue(text.trim())
                if(number!=null) append("><v>$number</v></c>")
                else append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">${escape(text)}</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData>")
        if(sheet.merges.isNotEmpty()) {
            append("<mergeCells count=\"${sheet.merges.size}\">")
            sheet.merges.forEach { m -> append("<mergeCell ref=\"${column(m.c1)}${m.r1+1}:${column(m.c2)}${m.r2+1}\"/>") }
            append("</mergeCells>")
        }
        if(sheet.referenceJpeg!=null) append("<drawing r:id=\"rId1\"/>")
        append("<pageMargins left=\"0.25\" right=\"0.25\" top=\"0.25\" bottom=\"0.25\" header=\"0\" footer=\"0\"/></worksheet>")
    }
    private fun imageDrawing(sheet:SheetData):String {
        val cx=(sheet.pageWidthPt*12700f).toLong().coerceAtLeast(12700L)
        val cy=(sheet.pageHeightPt*12700f).toLong().coerceAtLeast(12700L)
        return """<?xml version="1.0"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="$REL"><xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:ext cx="$cx" cy="$cy"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Trang PDF goc"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>"""
    }
    private fun column(col:Int):String {
        var v=col+1; val s=StringBuilder()
        while(v>0) { v--; s.append(('A'.code+v%26).toChar());v/=26 }
        return s.reverse().toString()
    }
    private fun numericValue(s:String):String? {
        if(s.isBlank() || s.length>17 || s.startsWith('+') || (s.length>1 && s[0]=='0' && s[1].isDigit())) return null
        val normalized = when {
            s.matches(Regex("-?(?:0|[1-9][0-9]{0,12})")) -> s
            s.matches(Regex("-?(?:0|[1-9][0-9]{0,12})[.,][0-9]{1,2}")) -> s.replace(',','.')
            s.matches(Regex("-?[1-9][0-9]{0,2}(?:\\.[0-9]{3})+,[0-9]{1,2}")) -> s.replace(".","").replace(',','.')
            else -> return null
        }
        return normalized.takeIf { it.toDoubleOrNull()?.isFinite()==true }
    }
    private fun escape(s:String):String = buildString(s.length+32) {
        for(c in s) when(c) {
            '&'->append("&amp;")
            '<'->append("&lt;")
            '>'->append("&gt;")
            '"'->append("&quot;")
            '\''->append("&apos;")
            else -> if(c=='\t'||c=='\n'||c=='\r'||c.code>=32) append(c)
        }
    }
}

// ================ existing unruled table parsing ================
internal object PdfTableLayout {
    data class Glyph(val text: String, val x: Float, val y: Float, val width: Float, val height: Float)
    private data class Cluster(val glyphs: MutableList<Glyph>, var y: Float, var height: Float)
    private data class CellFragment(val x: Float, val text: String)

    fun extract(glyphs: List<Glyph>): List<Map<Int, String>> {
        if (glyphs.isEmpty()) return emptyList()
        val sorted = glyphs.filter { it.text.isNotBlank() && it.x.isFinite() && it.y.isFinite() }
            .sortedWith(compareBy<Glyph> { it.y }.thenBy { it.x })
        if (sorted.isEmpty()) return emptyList()
        val lines = ArrayList<Cluster>()
        for (g in sorted) {
            val last = lines.lastOrNull()
            val tolerance = if (last == null) 0f else minOf(3.7f, maxOf(2.1f, last.height * 0.36f))
            if (last != null && kotlin.math.abs(last.y - g.y) <= tolerance) {
                last.glyphs.add(g)
                val n = last.glyphs.size
                last.y = (last.y * (n - 1) + g.y) / n
                last.height = maxOf(last.height, g.height)
            } else {
                lines.add(Cluster(mutableListOf(g), g.y, g.height))
            }
        }
        val rows: List<List<CellFragment>> = lines.map { line ->
            val chars = line.glyphs.sortedBy { it.x }
            val fragments = ArrayList<CellFragment>()
            var startX = chars.first().x
            var endX = startX
            val current = StringBuilder()
            val gapLimit = maxOf(9f, minOf(19f, line.height * 0.90f))
            fun addFragment() {
                val s = current.toString().trim().replace(Regex("[\\t ]+"), " ")
                if (s.isNotEmpty()) fragments.add(CellFragment(startX, s))
                current.setLength(0)
            }
            for (g in chars) {
                val gap = g.x - endX
                if (current.isNotEmpty() && gap > gapLimit) {
                    addFragment()
                    startX = g.x
                } else if (current.isNotEmpty() && gap > 2.6f && !current.last().isWhitespace()) {
                    // Keep normal word spaces inside a cell; split only on wide visual gaps.
                    current.append(' ')
                }
                current.append(g.text)
                endX = maxOf(endX, g.x + g.width)
            }
            addFragment()
            fragments
        }.filter { it.isNotEmpty() }
        if (rows.isEmpty()) return emptyList()

        // Use the most typical multi-column line as a positional template.
        // A PDF has no real column metadata; on irregular pages, one-column text is safer.
        val possible = rows.filter { it.size in 2..35 }
        val anchors: List<Float> = if (possible.isEmpty()) listOf(rows.first().first().x) else {
            val commonSize = possible.groupingBy { it.size }.eachCount()
                .maxWithOrNull(compareBy<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })!!.key
            val representative = possible.first { it.size == commonSize }
            representative.map { it.x }
        }
        return rows.map { fragments ->
            val line = LinkedHashMap<Int, String>()
            var prevCol = -1
            for (cell in fragments) {
                var col = anchors.indices.minByOrNull { kotlin.math.abs(anchors[it] - cell.x) } ?: 0
                col = maxOf(col, prevCol + 1)
                if (col >= 256) throw IOException("Trang PDF có quá nhiều cột để xuất Excel.")
                line[col] = cell.text
                prevCol = col
            }
            line
        }
    }
}

