package duc_phi.music

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.app.FragmentActivity
import kotlin.math.PI
import kotlin.math.sin
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.QueryProductDetailsParams

/** IDs MUST match the subscription and prepaid base plans in Google Play Console. */
private const val PREMIUM_PRODUCT_ID = "meloware_premium"
private const val PREMIUM_6M_BASE_PLAN = "premium-6m"
private const val PREMIUM_12M_BASE_PLAN = "premium-12m"

private data class PremiumDisplayOffer(
    val formattedPrice: String,
    val billingPeriod: String
)

/**
 * Stage 2: safe catalog/UI preparation. NO charge, NO unlock and NO trial start here.
 * Checkout is deliberately deferred until purchase verification / acknowledgement
 * and paid feature gates are implemented and tested in Stage 3.
 * Never flip a local boolean to grant paid entitlement.
 */
private class PremiumCatalogReader(private val activity: FragmentActivity) {
    var loading by mutableStateOf(true)
        private set
    var connected by mutableStateOf(false)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var sixMonth by mutableStateOf<PremiumDisplayOffer?>(null)
        private set
    var twelveMonth by mutableStateOf<PremiumDisplayOffer?>(null)
        private set

    private var closed = false
    private val billingClient = BillingClient.newBuilder(activity.applicationContext)
        .setListener { _, _ -> /* Stage 2 cannot accept payments. */ }
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .enablePrepaidPlans()
                .build()
        )
        .enableAutoServiceReconnection()
        .build()

    fun start() {
        if (closed) return
        loading = true
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (closed) return
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    connected = true
                    refresh()
                } else {
                    connected = false
                    loading = false
                    errorMessage = result.debugMessage
                }
            }

            override fun onBillingServiceDisconnected() {
                if (closed) return
                connected = false
                loading = false
            }
        })
    }

    fun refresh() {
        if (closed) return
        if (!billingClient.isReady) {
            start()
            return
        }
        loading = true
        errorMessage = null
        val query = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PREMIUM_PRODUCT_ID)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                )
            )
            .build()
        billingClient.queryProductDetailsAsync(query) { result, response ->
            if (closed) return@queryProductDetailsAsync
            activity.runOnUiThread {
                if (closed) return@runOnUiThread
                loading = false
                if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                    errorMessage = result.debugMessage
                    sixMonth = null
                    twelveMonth = null
                    return@runOnUiThread
                }
                val details: ProductDetails? = response.productDetailsList
                    .firstOrNull { it.productId == PREMIUM_PRODUCT_ID }
                sixMonth = details?.subscriptionOfferDetails
                    ?.firstOrNull { it.basePlanId == PREMIUM_6M_BASE_PLAN && it.offerId == null }
                    ?.let { offer ->
                        PremiumDisplayOffer(
                            formattedPrice = offer.pricingPhases.pricingPhaseList.lastOrNull()?.formattedPrice.orEmpty(),
                            billingPeriod = offer.pricingPhases.pricingPhaseList.lastOrNull()?.billingPeriod.orEmpty()
                        )
                    }
                twelveMonth = details?.subscriptionOfferDetails
                    ?.firstOrNull { it.basePlanId == PREMIUM_12M_BASE_PLAN && it.offerId == null }
                    ?.let { offer ->
                        PremiumDisplayOffer(
                            formattedPrice = offer.pricingPhases.pricingPhaseList.lastOrNull()?.formattedPrice.orEmpty(),
                            billingPeriod = offer.pricingPhases.pricingPhaseList.lastOrNull()?.billingPeriod.orEmpty()
                        )
                    }
            }
        }
    }

    fun close() {
        closed = true
        billingClient.endConnection()
    }
}

/**
 * Compact Premium overview: all rights are planned until entitlement rules exist.
 * IMPORTANT: no checkout or unlock is offered at this stage.
 */
@Composable
internal fun MeloWarePremiumDialog(activity: FragmentActivity, onDismiss: () -> Unit) {
    val colors = LocalMusicColors.current
    val catalog = remember(activity) { PremiumCatalogReader(activity) }
    var selectedPlan by remember { mutableStateOf(PREMIUM_6M_BASE_PLAN) }

    DisposableEffect(catalog) {
        catalog.start()
        onDispose { catalog.close() }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .heightIn(max = 660.dp),
            color = colors.card,
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Heading: show the content before prices, without large empty banners.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PremiumHeroBadge()
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            mwString("premium.title", "MeloWare Premium"),
                            color = colors.textPrimary, fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            mwString("premium.subtitle", "Mở khóa các tính năng nâng cao"),
                            color = colors.textSecondary, fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = mwString("common.close", "Đóng"),
                            tint = colors.textSecondary
                        )
                    }
                }

                // Showcase only planned benefits; do not imply features are unlocked.
                // Ads-free playback is intentionally LAST as requested.
                Surface(
                    color = colors.backgroundSoft,
                    shape = RoundedCornerShape(15.dp),
                    border = BorderStroke(1.dp, colors.border)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Icon(
                                Icons.Rounded.WorkspacePremium,
                                contentDescription = null,
                                tint = colors.purpleBright,
                                modifier = Modifier.size(17.dp)
                            )
                            Text(
                                mwString("premium.benefits_title", "Quyền lợi dự kiến"),
                                color = colors.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        PremiumBenefitCard(
                            type = PremiumBenefitType.EQUALIZER,
                            title = mwString("premium.benefit_equalizer", "Tùy chỉnh Equalizer nâng cao"),
                            detail = mwString("premium.benefit_equalizer_detail", "Tùy chỉnh âm thanh theo sở thích của bạn.")
                        )
                        PremiumBenefitCard(
                            type = PremiumBenefitType.CLOUD,
                            title = mwString("premium.benefit_drive", "Tiện ích Google Drive & chia sẻ nâng cao"),
                            detail = mwString("premium.benefit_drive_detail", "Quản lý và chia sẻ nhạc giữa các thiết bị linh hoạt.")
                        )
                        PremiumBenefitCard(
                            type = PremiumBenefitType.AD_FREE,
                            title = mwString("premium.benefit_ads", "Nghe nhạc không quảng cáo"),
                            detail = mwString("premium.benefit_ads_detail", "Thưởng thức âm nhạc mà không bị quảng cáo làm gián đoạn.")
                        )
                    }
                }

                // Trial has not been switched on in this version.
                Surface(
                    color = colors.purple.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Rounded.WorkspacePremium, contentDescription = null,
                            tint = colors.purpleBright, modifier = Modifier.size(17.dp))
                        Text(
                            mwString("premium.trial_short", "Dùng thử 30 ngày miễn phí (chưa mở)"),
                            color = colors.textPrimary, fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Text(
                    mwString("premium.choose_plan_short", "Chọn gói Premium"),
                    color = colors.textPrimary, fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                PremiumPlanCard(
                    title = mwString("premium.plan6_short", "6 tháng"),
                    expectedPrice = mwString("premium.expected1", "Dự kiến 1 USD"),
                    displayOffer = catalog.sixMonth,
                    loading = catalog.loading,
                    selected = selectedPlan == PREMIUM_6M_BASE_PLAN,
                    onSelect = { selectedPlan = PREMIUM_6M_BASE_PLAN }
                )
                PremiumPlanCard(
                    title = mwString("premium.plan12_short", "12 tháng"),
                    expectedPrice = mwString("premium.expected2", "Dự kiến 2 USD"),
                    displayOffer = catalog.twelveMonth,
                    loading = catalog.loading,
                    selected = selectedPlan == PREMIUM_12M_BASE_PLAN,
                    onSelect = { selectedPlan = PREMIUM_12M_BASE_PLAN }
                )

                Text(
                    mwString("premium.prepaid", "Trả trước một lần, không tự gia hạn"),
                    color = colors.textSecondary, fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                // Disabled on purpose: no purchase verification or paid feature gates yet.
                Button(
                    onClick = {}, enabled = false,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.purple)
                ) {
                    Icon(Icons.Rounded.CreditCard, contentDescription = null,
                        modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(mwString("premium.activate_wait", "Kích hoạt Premium — sắp ra mắt"))
                }

                if (catalog.errorMessage != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(mwString("premium.price_load_error", "Chưa tải được giá Google Play"),
                            color = colors.textSecondary, fontSize = 11.sp,
                            modifier = Modifier.weight(1f))
                        TextButton(onClick = { catalog.refresh() }, enabled = !catalog.loading) {
                            Text(mwString("premium.retry_short", "Thử lại"),
                                color = colors.purpleBright, fontSize = 11.sp)
                        }
                    }
                }

                Text(
                    mwString(
                        "premium.disclaimer_short",
                        "Các quyền lợi trên đang được chuẩn bị. Phiên bản này chưa thể thanh toán hoặc kích hoạt dùng thử."
                    ),
                    color = colors.textSecondary,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

/** Animated Premium crown and sparkle; isolated from the rest of the dialog. */
@Composable
private fun PremiumHeroBadge() {
    val colors = LocalMusicColors.current
    val transition = rememberInfiniteTransition(label = "premium_hero")
    val scale by transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "crown_pulse"
    )
    Box(
        modifier = Modifier.size(46.dp)
            .background(
                brush = Brush.linearGradient(
                    listOf(
                        colors.purple.copy(alpha = 0.26f),
                        colors.blue.copy(alpha = 0.21f)
                    )
                ),
                shape = RoundedCornerShape(14.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.WorkspacePremium,
            contentDescription = null,
            tint = colors.purpleBright,
            modifier = Modifier.size(28.dp).graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
        )
        Icon(
            Icons.Rounded.AutoAwesome,
            contentDescription = null,
            tint = colors.cyan,
            modifier = Modifier.align(Alignment.TopEnd)
                .padding(3.dp)
                .size(11.dp)
                .graphicsLayer { alpha = 0.55f + (scale - 0.96f) * 3.5f }
        )
    }
}

/** Small Compose-only animations: no external assets, threads, timers or libraries. */
private enum class PremiumBenefitType { EQUALIZER, CLOUD, AD_FREE }

@Composable
private fun PremiumBenefitCard(type: PremiumBenefitType, title: String, detail: String) {
    val colors = LocalMusicColors.current
    val accent = when (type) {
        PremiumBenefitType.EQUALIZER -> colors.cyan
        PremiumBenefitType.CLOUD -> colors.blue
        PremiumBenefitType.AD_FREE -> colors.green
    }
    Surface(
        color = colors.cardRaised.copy(alpha = if (colors.isDark) 0.68f else 0.85f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.7.dp, accent.copy(alpha = 0.28f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PremiumBenefitAnimatedIcon(type = type, accent = accent)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = title,
                    color = colors.textPrimary,
                    fontSize = 12.5.sp,
                    lineHeight = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = detail,
                    color = colors.textSecondary,
                    fontSize = 10.5.sp,
                    lineHeight = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun PremiumBenefitAnimatedIcon(type: PremiumBenefitType, accent: Color) {
    // Each card animates independently, so prices, Billing queries and the dialog
    // outside this small icon are not recomposed on every animation frame.
    val transition = rememberInfiniteTransition(label = "premium_icon_${type.name}")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (type) {
                    PremiumBenefitType.EQUALIZER -> 1550
                    PremiumBenefitType.CLOUD -> 2300
                    PremiumBenefitType.AD_FREE -> 2800
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "premium_icon_progress"
    )
    val drift = sin(phase * 2f * PI.toFloat())
    Box(
        modifier = Modifier
            .size(48.dp)
            .background(
                brush = Brush.linearGradient(
                    listOf(accent.copy(alpha = 0.24f), accent.copy(alpha = 0.08f))
                ),
                shape = RoundedCornerShape(14.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        when (type) {
            PremiumBenefitType.EQUALIZER -> {
                Canvas(modifier = Modifier.size(29.dp)) {
                    val count = 5
                    val barWidth = size.width / 8.2f
                    val spacing = (size.width - count * barWidth) / (count - 1)
                    for (index in 0 until count) {
                        val wave = (sin((phase + index * 0.18f) * 2f * PI.toFloat()) + 1f) / 2f
                        val barHeight = size.height * (0.27f + wave * 0.65f)
                        drawRoundRect(
                            color = accent,
                            topLeft = Offset(index * (barWidth + spacing), (size.height - barHeight) / 2f),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(barWidth / 2f)
                        )
                    }
                }
            }
            PremiumBenefitType.CLOUD -> {
                Icon(
                    Icons.Rounded.Cloud,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(30.dp).graphicsLayer {
                        translationY = drift * 3.5f
                        scaleX = 1f + drift * 0.035f
                        scaleY = 1f + drift * 0.035f
                    }
                )
                Icon(
                    Icons.Rounded.Share,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.align(Alignment.BottomEnd)
                        .padding(3.dp)
                        .size(16.dp)
                        .graphicsLayer { translationX = drift * 2f }
                )
            }
            PremiumBenefitType.AD_FREE -> {
                Icon(
                    Icons.Rounded.Block,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(29.dp).graphicsLayer {
                        rotationZ = drift * 6f
                        scaleX = 1f + drift * 0.04f
                        scaleY = 1f + drift * 0.04f
                    }
                )
            }
        }
    }
}

@Composable
private fun PremiumPlanCard(
    title: String,
    expectedPrice: String,
    displayOffer: PremiumDisplayOffer?,
    loading: Boolean,
    selected: Boolean,
    onSelect: () -> Unit
) {
    val colors = LocalMusicColors.current
    Surface(
        onClick = onSelect,
        modifier = Modifier.fillMaxWidth(),
        color = if (selected) colors.purple.copy(alpha = 0.10f) else colors.backgroundSoft,
        border = BorderStroke(1.dp, if (selected) colors.purpleBright else colors.border),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Icon(
                if (selected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (selected) colors.purpleBright else colors.textSecondary,
                modifier = Modifier.size(20.dp)
            )
            Column(modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = colors.textPrimary, fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold)
                Text(
                    if (loading) mwString("premium.checking", "Đang kiểm tra gói")
                    else if (displayOffer == null) mwString("premium.unpublished", "Chưa mở bán trên Google Play")
                    else mwString("premium.ready_but_locked", "Đã tìm thấy gói · chờ hoàn thiện thanh toán"),
                    color = colors.textSecondary, fontSize = 10.sp
                )
            }
            Text(
                displayOffer?.formattedPrice?.takeIf { it.isNotBlank() } ?: expectedPrice,
                color = colors.purpleBright, fontWeight = FontWeight.Bold,
                fontSize = 13.sp, textAlign = TextAlign.End
            )
        }
    }
}
