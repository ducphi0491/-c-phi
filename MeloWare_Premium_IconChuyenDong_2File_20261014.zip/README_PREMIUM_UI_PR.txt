MELOWARE PREMIUM - GIAO DIEN PR VOI ICON CHUYEN DONG (14/10/2026)

Nguon: MeloWare_15_10_Premium_UI_NganGon_20261014.zip (bo ma nguon Premium moi nhat).

CHI THAY 2 FILE:
1. MeloWarePremium.kt -> app/src/main/java/duc_phi/music/MeloWarePremium.kt
2. meloware_languages.json -> app/src/main/assets/meloware_languages.json

THAY DOI:
- Thu tu quyen loi: 1) Equalizer nang cao; 2) Google Drive & chia se;
  3) Nghe nhac khong quang cao (CUOI CUNG).
- Moi quyen loi co the rieng, icon mau va mo ta ngan.
- Icon Equalizer: thanh am tan dao dong.
- Icon Cloud/Share: chuyen dong nhe theo chu ky.
- Icon khong quang cao: xoay va nhip nhe.
- Bieu tuong Premium o dau trang: nhip nhe va co diem sang.
- Hieu ung Compose chay khi hop thoai dang mo, khong them thu vien.
- Bo sung 3 khoa dich mo ta/quyen loi cho tat ca 15 ngon ngu.
- Giu nguyen gia du kien, lay gia tu Google Play, chon goi 6/12 thang.

QUAN TRONG:
- Van CHUA thuc hien thanh toan va kich hoat dung thu trong phien ban nay.
- "Quyen loi du kien" khong co nghia cac tinh nang da duoc mo khoa.
- Button thanh toan van khoa; khong tao giao dich hay tu dong gia han.
- KHONG DOI MainActivity, build.gradle.kts, WebRTC, Google Drive, Cast, Ads.
- build.gradle.kts hien tai co Billing thuong 9.1.0 (khong phai KTX).

KIEM TRA:
- Kotlin: da doi chieu cu phap, thu vien Compose va can bang dau ngoac.
- JSON: parse hop le va du 15 ngon ngu co cung 282 khoa dich.
- Chua co Android SDK/Gradle project day du de build APK tai moi truong nay.

SAU KHI THAY:
Android Studio -> Sync Project with Gradle Files -> Build -> Rebuild Project.
Mo Cai dat -> Kich hoat Premium de xem hoat anh va thu tu quyen loi.
