pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        // Repository containing Java LAME 3.98.4.
        // Required by AudioToolsScreen.kt for net.sourceforge.lame.mp3.Lame.
        maven {
            name = "Terrestris"
            url = uri("https://nexus.terrestris.de/repository/public/")
            content {
                includeGroup("com.github.nwaldispuehl")
            }
        }
    }
}

rootProject.name = "music"
include(":app")
