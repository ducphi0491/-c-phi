TUNERTOOLS - MEDIA3 VIDEO + SAP XEP BAI TAP V8
Ngay: 2026-10-09

FILE NEN
- Gamefolder.kt duoc sua truc tiep tu ban V7 dang co Media3 va phan quyen thu muc.
- api_documents.php duoc sua tu ban server video-switch V5 gan nhat.
- build.gradle.kts giu nguyen ban Media3 da build truoc do; chi dong goi de doi chieu.

PHAM VI SUA
1. Khoi phuc sap xep so tu nhien tai 3 vi tri:
   - Danh sach file tren may.
   - Danh sach dang hien thi sau tim kiem/loc.
   - Danh sach video Truoc/Tiep theo.
   Ket qua: Bai 1, Bai 2, ... Bai 10, Bai 10.1, Bai 11.

2. Sua truong hop mot nhom MP4 khong phat duoc:
   - PHP khong con cat moi HTTP Range thanh toi da 2 MB.
   - Server tra dung chinh xac byte range ma Media3 yeu cau.
   - Van kiem tra connection_aborted() theo tung khoi 64 KB de giai phong luong khi nguoi dung thoat video.
   - Neu finfo tra application/octet-stream, PHP dung MIME theo duoi file, vi du MP4 -> video/mp4.
   - Android gan MIME ro rang cho MediaItem.
   - Bat decoder fallback cua Media3.
   - Nut Thu lai xoa cache cua rieng video bi loi va tao lai playlist.
   - Man hinh loi hien ma PlaybackException de xac dinh codec/container/network neu con loi.

3. Giam tai may chu:
   - Cham trang thai dung documents-health.json hoac action=health, khong dung action=list.
   - Kiem tra online moi 30 giay; offline moi 15 giay.

KHONG THAY DOI
- admin.kt.
- Phan quyen Gmail/thu muc.
- Giao dien tai lieu.
- Upload, doi ten, xoa, tai file.
- Chuc nang anh/PDF.
- Cac file SongMainScreen, SongRepository, SongTabComponents, api_songs.php.

THU TU CAP NHAT
1. Sao luu file cu.
2. Chep api_documents.php vao:
   C:\inetpub\wwwroot\api_documents.php
3. Chep documents-health.json vao:
   C:\inetpub\wwwroot\documents-health.json
4. Chep Gamefolder.kt vao dung package cua project Android.
5. build.gradle.kts chi can thay neu project chua co 3 dependency Media3. Neu dang build duoc V7 thi GIU NGUYEN file Gradle hien tai.
6. Android Studio:
   - Sync Project with Gradle Files
   - Build > Clean Project
   - Build > Rebuild Project

KIEM TRA
A. Thu tu:
   Bai 1 -> Bai 2 -> ... -> Bai 10 -> Bai 10.1 -> Bai 11.

B. Video:
   - Mo video trong thu muc truoc day bi loi.
   - Dang xem thi Back.
   - Mo video khac ngay.
   - Thu nut Video truoc/Tiep theo.
   - Thoat Tai lieu va mo lai.

NEU VAN CO VIDEO KHONG PHAT
Man hinh V8 se hien them ma nhu:
- ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
- ERROR_CODE_PARSING_CONTAINER_MALFORMED
- ERROR_CODE_IO_BAD_HTTP_STATUS
Gui lai dung ma nay va 1 file video mau de kiem tra codec bang ffprobe/MediaInfo.
