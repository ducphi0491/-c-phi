MELOWARE - FIX THU VIEN DA NGON NGU (14/10/2026)

Nguon: meloware14.10.zip + ban FIX Settings/Home ngay 14/10/2026.

CHI THAY 3 FILE:
1. app/src/main/java/duc_phi/music/LibraryScreen.kt
2. app/src/main/java/duc_phi/music/MusicUiComponents.kt
3. app/src/main/assets/meloware_languages.json

LibraryScreen.kt: chuyen cac nhan trong tab Thu vien, bo loc, the nguon, Google Drive Picker,
file/folder, playlists va cong cu cat/ghep/nhac chuong sang mwString().
MusicUiComponents.kt: dich du phong nhan 'Nghe si chua biet' o SongRow (khong doi metadata that).
JSON: 85 khoa Library moi, tong 247 khoa moi ngon ngu, 15 ngon ngu, du {count}, {time}.

GIU NGUYEN:
- MainActivity.kt ban da sua (tu dong/chon thu cong ngon ngu)
- HomeScreen.kt, NowPlayingScreen.kt, MusicController.kt, Firebase, WebRTC, LAN
- Gradle va thu vien

BUILD:
- Sao luu 3 file cu.
- Sao chep 3 file theo dung duong dan.
- Android Studio > Build > Rebuild Project.
- Chon tieng Trung/Russian/Nhat tai Cai dat > Ngon ngu, mo tab Thu vien.

Luu y: Ten bai hat, ten thu muc va nghe si thuc te la du lieu ca nhan, khong bi dich.
Chuoi loi tu dich vu ben ngoai/MusicController co the van o ngon ngu nguon.
Da kiem tra JSON, khoa, placeholder va cau truc Kotlin, chua build Android APK thuc te.
