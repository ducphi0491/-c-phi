# TunerTools - Video hướng dẫn đầu tiên (1 MP4 + phụ đề 15 ngôn ngữ)

## Nội dung
Video 32,858 giây, dọc 720x1280. Không có lời thuyết minh (âm thanh im lặng).
Phụ đề là **câu hướng dẫn thao tác trên màn hình** được biên soạn theo từng mốc thời gian, không phải bản chép lời nói.
Các bước: mở app, tìm bài với “50 năm”, chọn “50 Năm Về Sau”, xem lời/hợp âm, cuộn xem thế bấm, quay về đầu, đổi tông C→D, mở BPM.

## Cách tải lên máy chủ
Giải nén ZIP rồi tải nguyên thư mục `app-guides/songs/search/` vào thư mục web `tunertools.top/app-guides/songs/search/` đang có.
Nếu có thư mục `search` cũ, hãy **gộp/ghi đè nội dung của riêng thư mục search**. KHÔNG xóa các nhóm khác và KHÔNG ghi đè `api_songs.php`.

Cấu trúc đích:

```
app-guides/songs/search/
  guide.json                 (tiêu đề + mô tả 15 ngôn ngữ)
  captions.json              (10 đoạn hướng dẫn, mốc thời gian, nội dung 15 ngôn ngữ)
  thumbnail.jpg              (ảnh xem trước)
  videos/video.mp4           (bản gốc video bạn đã gửi)
  subtitles/{vi,en,es,fr,de,ru,ja,zh,th,lo,km,ko,pt,sw,ar}.vtt
```

Không cần upload `captions.json` cho API hoạt động, nhưng nên giữ để chỉnh câu chữ và làm lồng tiếng sau này.
PHP `api_guides.php` đã gửi ở Bước 1 tự phát hiện bài này khi `videos/video.mp4` tồn tại. Chuyển ngôn ngữ chỉ thay file phụ đề, KHÔNG thay video.

### Kiểm tra sau khi upload
- https://tunertools.top/api_guides.php?category=songs&lang=vi
- https://tunertools.top/api_guides.php?category=songs&lang=ja
- https://tunertools.top/preview_guides.html

Chỉ làm các bước trên **sau khi** `api_guides.php` và thư mục `app-guides/` đã được cài lên hosting.
Hiện chưa tích hợp trình phát hướng dẫn vào Android, cần một bước chỉnh Kotlin sau khi API và video thật được kiểm tra.

## Lưu ý
- `audio_language: vi` trong `guide.json` là mã fallback của API hiện tại (giao diện quay bằng tiếng Việt); **video này không có giọng nói** (`has_narration:false`).
- Mốc thời gian được căn theo thao tác xuất hiện trên màn hình. Có thể tinh chỉnh thêm sau khi xem trực tiếp bản WebVTT trong trình phát.
- Phụ đề Lao, Khmer, Swahili, Arabic và các bản dịch khác là bản biên soạn đầu tiên; nên nhờ người bản ngữ rà lại trước khi công khai rộng rãi.
- Không chạy Python trên máy chủ. PHP chỉ phục vụ catalog; MP4 và VTT là file tĩnh.
