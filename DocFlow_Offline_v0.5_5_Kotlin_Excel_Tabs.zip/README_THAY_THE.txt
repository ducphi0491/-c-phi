DOCFLOW OFFLINE v0.5 - GOM MA NGUON THANH 5 FILE KOTLIN
====================================================

Nguon: doc_ver1.zip (ban nguoi dung gui ngay 20/10/2026).
Package: com.docflowoffline. Khong thay applicationId.

1. SAO LUU truoc khi thay
   Sao chep thu muc app/src/main/java/com/docflowoffline ra ngoai project.

2. XOA NHUNG FILE KOTLIN CU sau trong:
   app/src/main/java/com/docflowoffline/

   CatalogScreens.kt
   CsvEngine.kt
   DocFlowApp.kt
   DocumentCatalog.kt
   DocumentScreens.kt
   DocumentStore.kt
   ExcelGrid.kt
   MainActivity.kt
   OfficeOoxml.kt
   PdfTools.kt
   Theme.kt

   Khong xoa assets/, res/, AndroidManifest.xml, build.gradle.kts.
   Neu con file .kt phien ban cu trong cung package, se co loi
   Conflicting overloads / Redeclaration khi build.

3. CHEP 5 FILE .kt MOI o ZIP vao cung thu muc:
   MainActivity.kt     : Activity, theme, navigation, home, convert, tools
   DocumentScreens.kt : Word, PowerPoint, TXT, CSV, PDF
   ExcelEditor.kt     : Excel mobile UI, ribbons, Canvas sheet, zoom
   DocumentStorage.kt : DocumentStore, folder catalog, browser
   DocumentEngines.kt : OOXML, PDFBox/Android PDF, CSV

4. BUILD:
   Android Studio > Sync Project with Gradle Files > Build > Rebuild Project.
   Giữ nguyên AndroidManifest.xml va app/build.gradle.kts dang build duoc.
   Khong can them thu vien moi.

EXCEL - CAC CHUC NANG CO CODE
---------------------------
+ Trang chu: chon o, sua cong thuc/gia tri, sao chep/cat/dan 1 o trong app,
  xoa noi dung, Undo/Redo toi da 30 moc, Bold/Italic/Underline, can trai/giua/phai,
  to vang, dinh dang % (luu trong XLSX).
+ Chen: ngay, gio, dau tick, so thu tu theo hang, dan noi dung.
+ Cong thuc: tao SUM/AVERAGE/COUNT/MIN/MAX theo cot va cac hang truoc;
  xem ket qua tinh thu voi vung so co ban (toi da 30.000 o).
+ Du lieu: loc chuoi va sap xep tang/giam theo cot dang chon. LUON la che do
  XEM TAM, KHONG thay doi thu tu du lieu trong file XLSX da luu.
+ Danh gia: tim kiem, Undo/Redo, xem gioi han chuc nang.
+ Xem: phong to/thu nho, an/hien duong luoi, thanh fx, thu gon ribbon,
  doi sheet. Giao dien bang tinh chiem phan lon man hinh.
+ Luu ban sao XLSX giu nguyen tep goc va cac phan tu OOXML khong chinh sua.
  Nhung cong thuc moi ngoai 5 ham co ban se cho Excel/LibreOffice tinh lai.

QUAN TRONG
----------
- Giao dien tham khao Excel mobile, KHONG phai Microsoft Excel 100% va khong
  su dung ma nguon hay thuong hieu Microsoft.
- KHONG co LibreOffice/Collabora Native Engine. KHONG ho tro PivotTable,
  chart WYSIWYG, macro/VBA, merge/split cells, sap xep ghi vao tep,
  bo loc AutoFilter that su, hay toan bo ham Excel.
- Chi mot o duoc chinh sua moi lan; sao chep/dan ap dung trong ung dung.
- Luu format co ban yeu cau XLSX co xl/styles.xml; neu thieu app se bao loi
  va khong ghi file thay vi tao XLSX sai.
- Toi da ~120.000 o co gia tri / 100.000 hang / 256 cot duoc nap trong
  che do tinh gon. Nhieu tep phuc tap chi co the hien thi mot phan.
- Word/PPT/PDF tiep tuc dung bo may co ban truoc do, khong thay doi logic.
- Khong them quyen Internet va khong yeu cau server.

KIEM TRA DA LAM
---------------
+ Biên dịch thanh cong phan OfficeOoxml voi kotlinc/JVM (khong co Android SDK).
+ Test XLSX mau: thay gia tri va cong thuc, ghi styles bold/italic/underline,
  alignment, fill RGB, percent; doc lai dung; XML hop le.
+ Test ham tinh thu SUM/AVERAGE/COUNT/MIN/MAX va unknown formula.
+ Da kiem tra 5 file package com.docflowoffline, khong trung import truc tiep.
+ Chua build APK tren Android Studio/SDK hay chay tren Xiaomi trong moi truong nay.
  Neu co loi compile, vui long gui lai 4-5 dong loi 'e: file...' dau tien.
