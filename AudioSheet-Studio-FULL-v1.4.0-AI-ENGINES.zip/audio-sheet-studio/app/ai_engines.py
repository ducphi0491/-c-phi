"""Optional, isolated inference adapters for AudioSheet Studio.

This module never downloads or executes model weights in the FastAPI process.
The selected model is invoked via a dedicated WSL/Linux Python environment.
Missing/incompatible models raise explicit errors; the caller records any fallback.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from .config import ROOT_DIR

ENGINE_META = {
    "sheetsage2": {
        "name": "SheetSage2 (research only)",
        "repository": "m-a-p/SheetSage2",
        "license": "CC BY-NC 4.0 model weights; non-commercial only",
        "venv": ".ai-sheetsage2-venv",
    },
    "pop2piano": {
        "name": "Pop2Piano (experimental piano cover)",
        "repository": "sweetcocoa/pop2piano",
        "license": "Checkpoint terms must be confirmed separately before commercial use; Essentia is AGPL-3.0",
        "venv": ".ai-pop2piano-venv",
    },
}


class AIEngineError(RuntimeError):
    """A user-selected external engine is not available or could not finish."""


def _venv_marker(engine: str) -> Path:
    return ROOT_DIR / ENGINE_META[engine]["venv"] / "pyvenv.cfg"


def _runner_path() -> Path:
    return ROOT_DIR / "scripts" / "run_advanced_ai.sh"


def available_engines() -> dict[str, dict[str, Any]]:
    """Cheap availability check; does NOT download models or check gated credentials."""
    on_windows = os.name == "nt"
    wsl_executable = shutil.which("wsl.exe") if on_windows else None
    result: dict[str, dict[str, Any]] = {}
    for engine, meta in ENGINE_META.items():
        marker = _venv_marker(engine)
        local_python = ROOT_DIR / meta["venv"] / "bin" / "python"
        runtime_ok = bool(wsl_executable) if on_windows else local_python.exists()
        result[engine] = {
            "name": meta["name"], "repository": meta["repository"],
            "license": meta["license"],
            "installed": marker.is_file() and runtime_ok,
            "requires_wsl_on_windows": True,
            "model_downloaded": "unknown",  # Deliberately not inferred from an installed venv.
        }
    return result


def _wsl_path(path: Path) -> str:
    try:
        process = subprocess.run(
            ["wsl.exe", "--exec", "wslpath", "-a", "-u", str(path.resolve())],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise AIEngineError("Không kết nối được WSL2. Chạy 'wsl --status' và kiểm tra Ubuntu đã được cài.") from exc
    if process.returncode != 0 or not process.stdout.strip():
        raise AIEngineError("WSL2 không chuyển được đường dẫn ổ đĩa. " + process.stderr.strip()[:200])
    return process.stdout.strip()


def _execution_command(engine: str, audio_path: Path, output_dir: Path) -> list[str]:
    if sys.platform == "win32":
        if not shutil.which("wsl.exe"):
            raise AIEngineError("Model AI mới cần WSL2/Ubuntu. Windows: mở PowerShell (Admin), chạy 'wsl --install'.")
        return [
            "wsl.exe", "--exec", "/bin/bash",
            _wsl_path(_runner_path()), engine,
            _wsl_path(audio_path), _wsl_path(output_dir),
        ]
    return ["/bin/bash", str(_runner_path()), engine, str(audio_path), str(output_dir)]


def run_advanced_engine(
    engine: str, audio_path: Path, output_dir: Path,
    *, timeout_seconds: int = 7200,
) -> dict[str, Any]:
    if engine not in ENGINE_META:
        raise ValueError("Unknown AI engine")
    if not audio_path.is_file():
        raise AIEngineError("Không tìm thấy file âm thanh để chạy mô hình AI.")
    if not _venv_marker(engine).is_file():
        raise AIEngineError(
            f"{ENGINE_META[engine]['name']} chưa được cài trong môi trường riêng. "
            "Chạy CAI_AI_NANG_CAO.bat, chọn engine và khởi động lại website."
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / "model.log"
    command = _execution_command(engine, audio_path, output_dir)
    try:
        with log_path.open("w", encoding="utf-8") as logfile:
            result = subprocess.run(
                command, stdout=logfile, stderr=subprocess.STDOUT,
                timeout=max(30, int(timeout_seconds)), check=False,
            )
    except subprocess.TimeoutExpired as exc:
        raise AIEngineError(f"{engine}: hết thời gian phân tích, xem {log_path.name} trong thư mục tác vụ.") from exc
    except OSError as exc:
        raise AIEngineError(f"Không khởi động được engine {engine}: {exc}") from exc
    if result.returncode != 0:
        try:
            tail = " ".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-3:])[:320]
        except OSError:
            tail = ""
        raise AIEngineError(f"{engine} không chạy thành công (mã {result.returncode}). {tail}")
    metadata_file = output_dir / "result.json"
    if not metadata_file.is_file():
        raise AIEngineError(f"{engine} không tạo result.json; xem {log_path.name}.")
    try:
        metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise AIEngineError(f"{engine} trả về metadata không hợp lệ.") from exc
    if not isinstance(metadata, dict) or metadata.get("engine") != engine:
        raise AIEngineError(f"{engine} trả về sai định dạng engine.")
    for name in metadata.get("midi_files", []):
        if (not isinstance(name, str) or name not in {"pop2piano.mid", "melody_vocal.mid", "melody_instrumental.mid", "chords.mid", "transcription.mid"}
                or not (output_dir / name).is_file()):
            raise AIEngineError(f"{engine} thiếu MIDI kết quả cần thiết: {name}")
    return metadata
