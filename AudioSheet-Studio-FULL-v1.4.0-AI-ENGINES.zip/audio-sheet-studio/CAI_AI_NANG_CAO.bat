@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==========================================
echo AudioSheet Studio - CAI AI NANG CAO (WSL2)
echo ==========================================
echo.
echo [1] Pop2Piano - tao ban phoi piano B (thu nghiem)
echo [2] SheetSage2 - melody va hop am (chi nghien cuu phi thuong mai)
echo [3] Ca hai engine (tai du lieu rat lon)
echo [Q] Thoat
echo.
choice /c 123Q /n /m "Chon 1, 2, 3 hoac Q: "
if errorlevel 4 exit /b 0
if errorlevel 3 goto :both
if errorlevel 2 goto :sheet
set "ENGINE=pop2piano"
goto :install
:both
set "ENGINE=both"
goto :install
:sheet
set "ENGINE=sheetsage2"
:install
where wsl.exe >nul 2>&1
if errorlevel 1 goto :no_wsl
for /f "usebackq delims=" %%P in (`wsl.exe --exec wslpath -a -u "%~dp0scripts\install_advanced_ai.sh"`) do set "WSL_SCRIPT=%%P"
if not defined WSL_SCRIPT goto :no_wsl
echo.
echo Dang cai %ENGINE% trong Ubuntu/WSL; KHONG thay doi moi truong website .venv.
wsl.exe --exec /bin/bash "%WSL_SCRIPT%" "%ENGINE%"
if errorlevel 1 goto :failed
echo.
echo [OK] Moi truong %ENGINE% da cai. Khoi dong lai CHAY_WEBSITE.bat.
pause
exit /b 0
:no_wsl
echo [LOI] WSL2/Ubuntu chua san sang. Mo PowerShell (Admin): wsl --install
echo Khoi dong lai Windows, mo Ubuntu lan dau va chay lai file nay.
pause
exit /b 1
:failed
echo.
echo [LOI] Cai AI that bai. Kiem tra Python 3.10/3.11, ffmpeg va ket noi mang trong WSL.
echo Ubuntu: sudo apt update ^&^& sudo apt install -y python3.11 python3.11-venv ffmpeg
pause
exit /b 1
