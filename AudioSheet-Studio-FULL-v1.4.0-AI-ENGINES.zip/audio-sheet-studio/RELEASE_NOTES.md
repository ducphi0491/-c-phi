# AudioSheet Studio v1.4.0 - 2026-11-03

- Optional SheetSage2 lead-sheet adapter for A (melody and chord timeline); separate WSL2 environment and non-commercial research license check.
- Optional Pop2Piano real Transformer MIDI generation for B; Easy/Standard/Full filter densities from actual model MIDI.
- Keep Basic Pitch/Beat This!/Demucs and legacy v1.3 arranger fully functional by default.
- Record **requested vs actually used** engine for both A and B; visible warning on model error instead of silent fallback.
- ZIP includes WSL2 installer, Linux worker scripts, Python integration, tests and documentation; no checkpoint distribution.
- Existing synchronized MIDI / MusicXML / PDF exports are kept.
- All new tests use synthetic/mock model output; actual checkpoint inference on Windows/WSL2 remains unverified and needs user-side confirmation.

Previous releases documented in `HUONG_DAN_V1.3.0.txt` and the retained source history.
