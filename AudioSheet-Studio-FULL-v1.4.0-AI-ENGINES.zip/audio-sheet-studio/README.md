# AudioSheet Studio v1.4.0 - Advanced AI Engine Selector

AudioSheet Studio is a local Windows website (FastAPI, music21, OSMD) converting owned/permitted audio into synchronized MIDI, MusicXML, piano audio and PDF. The stable v1.3 rhythm grid remains available as default.

## Quick start

1. Extract this ZIP into `C:\`, overwriting `C:\audio-sheet-studio\` (do not delete the old folder).
2. Keep your `.venv`, `.demucs-venv`, `data/jobs` and `web/piano_samples` from the installed version.
3. Double-click `CHAY_WEBSITE.bat` and open `http://127.0.0.1:8000`.
4. Use Basic Pitch (A) and AudioSheet Arranger (B) to operate without WSL2. C retains Basic Pitch stem transcription. A/B/C maintain separate MIDI/MusicXML/PDF exports.
5. **Optional**: Install WSL2 and run `CAI_AI_NANG_CAO.bat` to enable Pop2Piano and/or SheetSage2. Detailed instructions in `HUONG_DAN_V1.4.0.txt`.

## Advanced engines (explicit opt-in only)

- **A: SheetSage2** - transcribes vocal/instrumental melody plus chords. **Weights CC BY-NC 4.0, non-commercial research only.** Hugging Face access to its parent MERT-v2 may be required; upstream code executes with `trust_remote_code=True`. The user must explicitly choose this option and acknowledge the restriction.
- **B: Pop2Piano** - generates a piano-cover MIDI, which is split into Easy/Standard/Full density tiers. Windows currently needs WSL2 for the model's Essentia Python dependency. Confirm checkpoint terms and Essentia AGPL-3.0 obligations before commercial use.
- **C: Basic Pitch** - existing stem transcription remains unchanged.

Model checkpoints and dependencies are **not bundled**. Each engine runs in a separate Linux/WSL Python venv. If a selected engine fails, AudioSheet reports fallback prominently both in the UI and in `pipeline_manifest.json`; it never presents a legacy result as if the model succeeded.

## Core v1.3 pipeline retained

FFmpeg -> Beat This! (beat/downbeat/pickup/meter/tempo) -> Demucs (stem separation) -> Basic Pitch (raw stem notes) -> optional AI overrides -> piano arrangement -> MIDI/MusicXML/PDF. A/B/C playback, notation, and downloads share note events.

See `HUONG_DAN_V1.4.0.txt` for WSL2 setup and license notes. Models are experimental; actual superiority over Ledutu has not been established.
