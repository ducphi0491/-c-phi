package com.docflowoffline

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await



// One file for display preferences, Firebase Google account and the Settings tab.
// ==================== PREFERENCES AND LANGUAGE ====================
/** Only non-sensitive UI preferences are saved on the device. */
enum class DocLanguage(val key: String) { VI("vi"), EN("en") }
enum class DocAppearance(val key: String) { SYSTEM("system"), LIGHT("light"), DARK("dark") }

internal class DocFlowPreferences(context: Context) {
    private val storage = context.applicationContext.getSharedPreferences("docflow_display", Context.MODE_PRIVATE)

    fun language(): DocLanguage = DocLanguage.entries.firstOrNull {
        it.key == storage.getString("language", "vi")
    } ?: DocLanguage.VI

    fun appearance(): DocAppearance = DocAppearance.entries.firstOrNull {
        it.key == storage.getString("appearance", "system")
    } ?: DocAppearance.SYSTEM

    fun setLanguage(language: DocLanguage) {
        storage.edit().putString("language", language.key).apply()
    }

    fun setAppearance(appearance: DocAppearance) {
        storage.edit().putString("appearance", appearance.key).apply()
    }
}

internal val LocalDocLanguage = compositionLocalOf { DocLanguage.VI }
internal val LocalDocIsDark = compositionLocalOf { false }

/** UI strings in the entry screens; document editors retain their existing source text. */
@Composable
internal fun dfText(vi: String, en: String): String =
    if (LocalDocLanguage.current == DocLanguage.EN) en else vi

// ==================== FIREBASE AUTHENTICATION ====================
/**
 * Google Credential Manager -> Firebase Auth -> Cloud Firestore.
 * Collects only UID, verified email, public display name and sign-in timestamps.
 * A per-user record is written only after the visitor confirms the disclosure
 * and finishes an interactive Google login. No passwords, tokens, document
 * content, IP addresses or device identifiers are captured here.
 *
 * The email test below only affects the UI. Firestore Security Rules MUST
 * authorize admin list access on the Firebase server.
 */
internal object DocFlowAccount {
    const val ADMIN_EMAIL = "ducphi0491@gmail.com"
    private const val USER_COLLECTION = "docflow_users"

    var profileSaved by mutableStateOf(false)
        private set
    var profileError by mutableStateOf<String?>(null)
        private set

    data class UserProfile(
        val uid: String,
        val email: String,
        val name: String,
        val createdAt: Timestamp?,
        val lastLoginAt: Timestamp?
    )

    fun firebaseAuthOrNull(context: Context): FirebaseAuth? {
        return runCatching {
            if (FirebaseApp.getApps(context).isEmpty() && FirebaseApp.initializeApp(context) == null) {
                null
            } else FirebaseAuth.getInstance()
        }.getOrNull()
    }

    private fun webClientId(context: Context): String? {
        val resource = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        if (resource == 0) return null
        return context.getString(resource).takeIf { it.isNotBlank() }
    }

    fun isConfigured(context: Context): Boolean =
        firebaseAuthOrNull(context) != null && webClientId(context) != null

    fun isAdminUi(user: FirebaseUser?): Boolean =
        user?.isEmailVerified == true && user.email?.equals(ADMIN_EMAIL, ignoreCase = true) == true

    /** Refresh just the allowed profile fields, using server-side timestamps. */
    suspend fun saveOwnProfile(user: FirebaseUser) {
        val email = user.email?.takeIf { it.isNotBlank() }
            ?: error("Tài khoản Google không cung cấp địa chỉ email.")
        if (!user.isEmailVerified) error("Email Google chưa được xác minh.")

        profileSaved = false
        profileError = null
        try {
            val database = FirebaseFirestore.getInstance()
            val ref = database.collection(USER_COLLECTION).document(user.uid)
            // Transaction preserves the original createdAt for returning users.
            database.runTransaction { tx ->
                val existing = tx.get(ref)
                val record = mutableMapOf<String, Any>(
                    "uid" to user.uid,
                    "email" to email,
                    "displayName" to user.displayName.orEmpty().take(120),
                    "lastLoginAt" to FieldValue.serverTimestamp()
                )
                if (!existing.exists()) {
                    record["createdAt"] = FieldValue.serverTimestamp()
                }
                tx.set(ref, record, SetOptions.merge())
                true
            }.await()
            profileSaved = true
        } catch (e: Exception) {
            profileError = e.localizedMessage ?: e.javaClass.simpleName
            throw e
        }
    }

    suspend fun signIn(activity: Activity): FirebaseUser {
        val firebase = firebaseAuthOrNull(activity)
            ?: error("Firebase chưa được cấu hình cho ứng dụng này.")
        val clientId = webClientId(activity)
            ?: error("Thiếu Web Client ID. Hãy thêm google-services.json và bật Google Sign-In trong Firebase.")

        profileSaved = false
        profileError = null
        val option = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(activity).getCredential(
            context = activity,
            request = request
        )
        val googleToken = (result.credential as? CustomCredential)
            ?.takeIf { it.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL }
            ?.let { GoogleIdTokenCredential.createFrom(it.data).idToken }
            ?: error("Google không trả về thông tin đăng nhập hợp lệ.")
        val authResult = firebase.signInWithCredential(
            GoogleAuthProvider.getCredential(googleToken, null)
        ).await()
        val signedIn = authResult.user ?: error("Firebase không cung cấp phiên đăng nhập.")

        // Login succeeds even if Firestore is offline or its rules deny the write.
        // A visible error is shown on the Account screen; there is no silent data loss.
        try {
            saveOwnProfile(signedIn)
        } catch (_: Exception) {
            // The authentication session remains valid.
        }
        return signedIn
    }

    /** Read-only admin view. Enforcement of list permission happens in Firestore Rules. */
    suspend fun loadUserProfilesForAdmin(user: FirebaseUser): List<UserProfile> {
        if (!isAdminUi(user)) error("Tài khoản này không có quyền quản trị.")
        // Request fresh server data rather than potentially stale cached results.
        val snapshot = FirebaseFirestore.getInstance()
            .collection(USER_COLLECTION)
            .orderBy("lastLoginAt", Query.Direction.DESCENDING)
            .limit(100)
            .get(Source.SERVER)
            .await()
        return snapshot.documents.map { doc ->
            UserProfile(
                uid = doc.getString("uid") ?: doc.id,
                email = doc.getString("email").orEmpty(),
                name = doc.getString("displayName").orEmpty(),
                createdAt = doc.getTimestamp("createdAt"),
                lastLoginAt = doc.getTimestamp("lastLoginAt")
            )
        }
    }

    suspend fun signOut(activity: Activity) {
        firebaseAuthOrNull(activity)?.signOut()
        profileSaved = false
        profileError = null
        // Avoid automatically selecting the previous Google account.
        runCatching {
            CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest())
        }
    }
}

// ==================== INFORMATION AND SETTINGS PAGE ====================
/** Settings + account consent + verified admin-only Firestore directory. */
@Composable
internal fun DocFlowSettingsScreen(
    language: DocLanguage,
    changeLanguage: (DocLanguage) -> Unit,
    appearance: DocAppearance,
    changeAppearance: (DocAppearance) -> Unit,
    firebaseUser: FirebaseUser?,
    firebaseConfigured: Boolean,
    signInBusy: Boolean,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit
) {
    var languageDialog by remember { mutableStateOf(false) }
    var appearanceDialog by remember { mutableStateOf(false) }
    var premiumDialog by remember { mutableStateOf(false) }
    var adminDialog by remember { mutableStateOf(false) }
    var disclosureDialog by remember { mutableStateOf(false) }
    var savingProfile by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val english = language == DocLanguage.EN
    fun t(vi: String, en: String): String = if (english) en else vi

    if (languageDialog) {
        SettingsSelectionDialog(
            title = t("Chọn ngôn ngữ", "Choose language"),
            choices = listOf("Tiếng Việt", "English"),
            selected = if (language == DocLanguage.VI) 0 else 1,
            dismiss = { languageDialog = false },
            choose = {
                changeLanguage(if (it == 0) DocLanguage.VI else DocLanguage.EN)
                languageDialog = false
            }
        )
    }
    if (appearanceDialog) {
        SettingsSelectionDialog(
            title = t("Chọn giao diện", "Appearance"),
            choices = listOf(
                t("Theo hệ thống", "Use device setting"),
                t("Chế độ sáng", "Light"),
                t("Chế độ tối", "Dark")
            ),
            selected = when (appearance) {
                DocAppearance.SYSTEM -> 0
                DocAppearance.LIGHT -> 1
                DocAppearance.DARK -> 2
            },
            dismiss = { appearanceDialog = false },
            choose = {
                changeAppearance(DocAppearance.entries[it])
                appearanceDialog = false
            }
        )
    }
    if (premiumDialog) {
        AlertDialog(
            onDismissRequest = { premiumDialog = false },
            icon = { Icon(Icons.Default.WorkspacePremium, null) },
            title = { Text(t("DocFlow Premium", "DocFlow Premium")) },
            text = {
                Text(t(
                    "Giao diện Premium đã được chuẩn bị. Chưa tích hợp Google Play Billing, chưa có gói bán và chưa phát sinh thanh toán.",
                    "The Premium page is ready. Google Play Billing and paid plans are not connected yet; no payment will occur."
                ))
            },
            confirmButton = {
                TextButton(onClick = { premiumDialog = false }) { Text(t("Đóng", "Close")) }
            }
        )
    }
    if (disclosureDialog) {
        AlertDialog(
            onDismissRequest = { disclosureDialog = false },
            icon = { Icon(Icons.Default.PrivacyTip, contentDescription = null) },
            title = { Text(t("Lưu thông tin đăng nhập", "Save sign-in details")) },
            text = {
                Text(t(
                    "Khi bạn chọn Đồng ý và đăng nhập, DocFlow sẽ lưu UID Firebase, tên hiển thị, email Google và thời gian ghi nhận vào Cloud Firestore. Chỉ bạn và quản trị viên được phép xem hồ sơ; không lưu nội dung tài liệu, mật khẩu hay mã đăng nhập vào Firestore.",
                    "By agreeing and signing in, DocFlow stores your Firebase UID, display name, Google email and sign-in activity times in Cloud Firestore. Only you and the authorized administrator can view your profile. Documents, passwords and login tokens are not stored in Firestore."
                ))
            },
            confirmButton = {
                TextButton(onClick = {
                    disclosureDialog = false
                    val user = firebaseUser
                    if (user == null) {
                        onSignIn()
                    } else if (!savingProfile) {
                        scope.launch {
                            savingProfile = true
                            try {
                                DocFlowAccount.saveOwnProfile(user)
                            } catch (_: Exception) {
                                // The account card shows the Firestore error and lets the user retry.
                            } finally {
                                savingProfile = false
                            }
                        }
                    }
                }) {
                    Text(if (firebaseUser == null)
                        t("Đồng ý & đăng nhập", "Agree & sign in")
                    else t("Đồng ý & lưu", "Agree & save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { disclosureDialog = false }) {
                    Text(t("Hủy", "Cancel"))
                }
            }
        )
    }
    if (adminDialog && DocFlowAccount.isAdminUi(firebaseUser) && firebaseUser != null) {
        DocFlowAdminUsersDialog(
            firebaseUser = firebaseUser,
            english = english,
            onDismiss = { adminDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Box(
                    Modifier.size(56.dp).background(
                        MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp)
                    ), contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Settings, null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(29.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(t("Thông tin & cài đặt", "Information & settings"),
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text(t("Tùy chỉnh trải nghiệm DocFlow", "Make DocFlow yours"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { SettingsHeading(t("Tài khoản", "Account")) }
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            Modifier.size(46.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(if (firebaseUser == null) Icons.Default.PersonOutline else Icons.Default.Person,
                                null, modifier = Modifier.size(25.dp),
                                tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(firebaseUser?.displayName?.takeIf { it.isNotBlank() }
                                ?: t("Chưa đăng nhập", "Not signed in"),
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(firebaseUser?.email ?: t("Đăng nhập bằng tài khoản Google", "Sign in with Google"),
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (DocFlowAccount.isAdminUi(firebaseUser)) {
                            Icon(Icons.Default.VerifiedUser, null,
                                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    if (firebaseUser == null) {
                        Button(onClick = { disclosureDialog = true }, enabled = !signInBusy, modifier = Modifier.fillMaxWidth()) {
                            if (signInBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.Login, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(t("Đăng nhập bằng Google", "Continue with Google"))
                        }
                        if (!firebaseConfigured) {
                            Text(t(
                                "Cần bổ sung cấu hình Firebase để kích hoạt đăng nhập.",
                                "Firebase configuration is required to enable sign-in."
                            ), style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        if (DocFlowAccount.profileSaved) {
                            Text(t("Hồ sơ đã lưu trên Firebase.", "Profile saved to Firebase."),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        if (DocFlowAccount.profileError != null) {
                            Text(t("Đã đăng nhập, nhưng chưa lưu được hồ sơ: ",
                                "Signed in, but profile could not be saved: ") +
                                DocFlowAccount.profileError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error)
                        }
                        if (!DocFlowAccount.profileSaved) {
                            OutlinedButton(
                                onClick = { disclosureDialog = true },
                                enabled = !savingProfile && !signInBusy,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (savingProfile) CircularProgressIndicator(
                                    Modifier.size(16.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Default.CloudUpload, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(7.dp))
                                Text(t("Lưu hồ sơ vào Firebase", "Save profile to Firebase"))
                            }
                        }
                        OutlinedButton(onClick = onSignOut, enabled = !signInBusy && !savingProfile,
                            modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Logout, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(t("Đăng xuất", "Sign out"))
                        }
                    }
                }
            }
        }
        if (DocFlowAccount.isAdminUi(firebaseUser)) {
            item {
                SettingsEntry(
                    title = t("Quản trị Firebase", "Firebase admin"),
                    detail = t("Xem 100 tài khoản đăng nhập gần nhất", "View 100 most recently signed-in accounts"),
                    icon = Icons.Default.AdminPanelSettings,
                    onClick = { adminDialog = true },
                    accent = MaterialTheme.colorScheme.primary
                )
            }
        }
        item { SettingsHeading(t("Cài đặt", "Preferences")) }
        item {
            SettingsEntry(
                title = t("Ngôn ngữ", "Language"),
                detail = if (language == DocLanguage.VI) "Tiếng Việt" else "English",
                icon = Icons.Default.Language,
                onClick = { languageDialog = true }
            )
        }
        item {
            val mode = when (appearance) {
                DocAppearance.SYSTEM -> t("Theo hệ thống", "Follow system")
                DocAppearance.LIGHT -> t("Sáng", "Light")
                DocAppearance.DARK -> t("Tối", "Dark")
            }
            SettingsEntry(
                title = t("Giao diện", "Appearance"),
                detail = mode,
                icon = if (appearance == DocAppearance.DARK) Icons.Default.DarkMode else Icons.Default.Palette,
                onClick = { appearanceDialog = true }
            )
        }
        item {
            SettingsEntry(
                title = "Premium",
                detail = t("Khám phá tính năng · chưa mở thanh toán", "Explore features · billing not yet enabled"),
                icon = Icons.Default.WorkspacePremium,
                onClick = { premiumDialog = true }
            )
        }
        item { SettingsHeading(t("Về ứng dụng", "About the app")) }
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("DocFlow", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(t("Đọc, chỉnh sửa và chuyển đổi tài liệu trên thiết bị.",
                        "View, edit and convert documents on your device."),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("DOCX · XLSX · PPTX · PDF · TXT · CSV",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(t("Xử lý tài liệu vẫn hoạt động offline; chỉ đăng nhập mới cần Internet.",
                        "Document editing stays offline; only sign-in needs Internet."),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/** Read-only, server-backed account list. Never writes to other users' records. */
@Composable
private fun DocFlowAdminUsersDialog(
    firebaseUser: FirebaseUser,
    english: Boolean,
    onDismiss: () -> Unit
) {
    fun t(vi: String, en: String) = if (english) en else vi
    val scope = rememberCoroutineScope()
    var loading by remember(firebaseUser.uid) { mutableStateOf(true) }
    var profiles by remember(firebaseUser.uid) { mutableStateOf<List<DocFlowAccount.UserProfile>>(emptyList()) }
    var error by remember(firebaseUser.uid) { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            error = null
            try {
                profiles = DocFlowAccount.loadUserProfilesForAdmin(firebaseUser)
            } catch (e: Exception) {
                error = e.localizedMessage ?: e.javaClass.simpleName
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(firebaseUser.uid) {
        try {
            profiles = DocFlowAccount.loadUserProfilesForAdmin(firebaseUser)
        } catch (e: Exception) {
            error = e.localizedMessage ?: e.javaClass.simpleName
        } finally {
            loading = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.AdminPanelSettings, null) },
        title = { Text(t("Người dùng DocFlow", "DocFlow users")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(t(
                    "Danh sách tối đa 100 hồ sơ gần nhất, chỉ gồm người đã đăng nhập và đồng ý lưu dữ liệu.",
                    "Up to 100 recent profiles, from people who signed in and agreed to save their data."
                ), style = MaterialTheme.typography.bodySmall)
                when {
                    loading -> Box(Modifier.fillMaxWidth().height(80.dp),
                        contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    error != null -> Text(
                        t("Không thể đọc Firestore: ", "Cannot read Firestore: ") + error,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                    profiles.isEmpty() -> Text(t(
                        "Chưa có hồ sơ. Kiểm tra Firestore Rules và thử đăng nhập một tài khoản.",
                        "No profiles yet. Check Firestore Rules and sign in with a user account."
                    ))
                    else -> {
                        Text(t("Đã đọc: ", "Loaded: ") + profiles.size,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodySmall)
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().heightIn(max = 390.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(profiles, key = { it.uid }) { user ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(user.name.ifBlank { user.email },
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.bodyMedium)
                                        Text(user.email, style = MaterialTheme.typography.bodySmall)
                                        Text("UID: ${user.uid}",
                                            style = MaterialTheme.typography.labelSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis)
                                        Text(t("Tạo: ", "Created: ") + formatDocFlowTime(user.createdAt),
                                            style = MaterialTheme.typography.labelSmall)
                                        Text(t("Ghi nhận gần nhất: ", "Last recorded: ") +
                                            formatDocFlowTime(user.lastLoginAt),
                                            style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(t("Đóng", "Close")) }
        },
        dismissButton = {
            TextButton(onClick = { refresh() }, enabled = !loading) {
                Text(t("Tải lại", "Refresh"))
            }
        }
    )
}

private fun formatDocFlowTime(value: Timestamp?): String {
    if (value == null) return "—"
    return SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(value.toDate())
}

@Composable
private fun SettingsHeading(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 2.dp))
}

@Composable
private fun SettingsEntry(
    title: String,
    detail: String,
    icon: ImageVector,
    onClick: () -> Unit,
    accent: Color = MaterialTheme.colorScheme.primary
) {
    Surface(onClick = onClick, color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            Box(Modifier.size(43.dp).background(
                accent.copy(alpha = .12f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(23.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(detail, style = MaterialTheme.typography.bodySmall,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, null, modifier = Modifier.size(22.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsSelectionDialog(
    title: String,
    choices: List<String>,
    selected: Int,
    dismiss: () -> Unit,
    choose: (Int) -> Unit
) {
    AlertDialog(onDismissRequest = dismiss, title = { Text(title) },
        text = {
            Column {
                choices.forEachIndexed { index, text ->
                    Surface(onClick = { choose(index) }, color = Color.Transparent) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                            RadioButton(selected = index == selected, onClick = null)
                            Text(text, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = dismiss) { Text(dfText("Đóng", "Close")) }
        }
    )
}
