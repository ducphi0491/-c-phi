TUNERTOOLS - MEDIA3 EXOPLAYER (BASE TU FILE GOC NGUOI DUNG GUI)
===============================================================

PHAM VI SUA DOI
---------------
Chi 2 file duoc thay doi:
1. Gamefolder.kt
2. build.gradle.kts (module app)

Khong sua admin.kt, SongTabComponents.kt, SongMainScreen.kt,
SongRepository.kt, api_songs.php hay cac chuc nang khac cua du an.

NOI DUNG DA TICH HOP
--------------------
- Thay VideoView + MediaPlayer trong man hinh Tai lieu Guitar bang Media3 ExoPlayer.
- Video van phat ben trong app bang PlayerView, khong mo trinh duyet/app ngoai.
- Dung mot ExoPlayer chung cho toan bo man hinh Tai lieu Guitar.
- Khi chuyen video, chi doi MediaItem; khong tao lai player cho tung video.
- Tao playlist cac video trong folder hien tai.
- Preload 5 giay dau cua video ke tiep bang Media3 playlist preload.
- Cache toi da 256 MB, tu dong xoa du lieu cu nhat khi day.
- Cache key on dinh, khong bi mat cache khi ticket URL tren server thay doi.
- Luu vi tri dang xem cua toi da 100 video trong phien man hinh hien tai.
- Khi dong video, stop() duoc goi de huy luong mang dang phat ngay.
- Thanh tua su dung scrubbing mode cua Media3 de tua muot hon.
- Giu nguyen dieu khien cu: Play/Pause, tua, toc do 0.5x-3.0x,
  full screen, video truoc/sau, nut tai xuong va giao dien cu.
- Giam tao thumbnail online tu 2 luong con 1 luong de tranh tranh bang thong.
- Khong ep Activity ve portrait khi nguoi dung chua tung bat full screen.

DEPENDENCY DA THEM
------------------
Media3 1.11.1:
- androidx.media3:media3-exoplayer
- androidx.media3:media3-ui
- androidx.media3:media3-database

CACH THAY FILE
--------------
1. Sao luu 2 file hien tai.
2. Thay Gamefolder.kt vao dung package:
   app/src/main/java/ducphi/tunnerinstrument/Gamefolder.kt
3. Thay build.gradle.kts vao module app:
   app/build.gradle.kts
4. Android Studio -> Sync Project with Gradle Files.
5. Build -> Clean Project.
6. Build -> Rebuild Project.

KIEM TRA SAU KHI BUILD
----------------------
- Mo mot folder co nhieu video.
- Mo video 1, xem vai giay, nhan video tiep theo lien tuc.
- Back ra danh sach roi mo video khac.
- Tua, doi toc do va full screen.
- Quay lai video da xem de xac nhan cache/vi tri xem hoat dong.

XAC NHAN KY THUAT
-----------------
- Gamefolder.kt: Kotlin PSI syntax check = OK.
- build.gradle.kts: Kotlin PSI syntax check = OK.
- Khong the chay full Gradle build trong bo file rieng le vi khong co toan bo project,
  settings.gradle, version catalog, resources va Android SDK cua du an.

CAC FILE DIFF
-------------
- Gamefolder_media3.diff
- build_gradle_media3.diff
Dung de doi chieu chinh xac nhung vi tri da thay doi.
