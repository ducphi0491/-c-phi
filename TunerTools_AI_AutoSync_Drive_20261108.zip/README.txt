TUNERTOOLS AI MUSIC -> GOOGLE DRIVE (Nov 08, 2026)
Python 3.10+ stdlib only. Use existing PRIVATE OAuth drive_token.json. Never share token.

1) Extract ALL files into:
   C:\TunerTools\Tools\AI_Drive_AutoSync

2) Upload ONLY the known missing OGG (QGQK47AO9MIR / Mot Dem Say):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CHAY_UPLOAD_MOT_DEM_SAY.ps1" -Preview
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CHAY_UPLOAD_MOT_DEM_SAY.ps1"

3) Preview a FULL sync across the approved sources:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CHAY_DONG_BO_TU_DONG.ps1"

4) Verify PHP catalog (may need up to 10 minutes to refresh):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\KIEM_TRA_MOT_DEM_SAY.ps1"

5) Install a scheduled incremental sync (PowerShell RUN AS ADMINISTRATOR):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CAI_LICH_DONG_BO_15_PHUT.ps1"

6) To manually run a full sync (upload missing only):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\CHAY_DONG_BO_TU_DONG.ps1" -Apply

7) Stop the scheduled task later (PowerShell RUN AS ADMINISTRATOR):
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_Drive_AutoSync\GO_LICH_DONG_BO.ps1"

LOCAL SOURCE (ONLY):
  C:\TunerTools\Audio\AI_Music\ZING_AUDIO          -> Drive AI_Music/stream_cache
  C:\TunerTools\Audio\AI_Music\YOUTUBE_CACHE audio -> Drive AI_Music/stream_cache
  C:\TunerTools\Audio\AI_Music\ZING_JSON           -> Drive AI_Music/lyrics
  C:\TunerTools\Audio\AI_Music\YOUTUBE_CACHE JSON  -> Drive AI_Music/lyrics

DRIVE DESTINATION (ONLY):
  My Drive/TunerTools_AppBackup/AI_Music/stream_cache
  My Drive/TunerTools_AppBackup/AI_Music/lyrics

SECURITY:
  - Does not scan other Drive folders or subfolders.
  - Does not delete, move, rename or overwrite Drive files.
  - Existing exact names are skipped. Different bytes/duplicate name are reported.
  - New files must have valid names and be stable for 120 seconds during scheduled sync.
  - Each upload verifies size and MD5 via live Google Drive file metadata.
  - Interrupted upload response is checked by live Drive list; not blindly re-uploaded.
  - At most 50 files per scheduled run, 15 minute recurrence. Remaining files next run.
  - If source folders are temporarily missing, auto sync stops safely.
  - No PHP or Android code change is needed for synchronization.
  - PHP cached_songs can take up to 600 seconds to update after upload.

REPORT:
  C:\TunerTools\Audio\AI_Music\Reports\Drive_AutoSync\AI_DRIVE_SYNC_LAST_RUN.json
  C:\TunerTools\Audio\AI_Music\Reports\Drive_AutoSync\TaskLogs\Sync_YYYYMMDD.log

If token file is not in the known BackupScripts default locations, provide -TokenFile
with its full local path to each wrapper. For scheduled tasks, configure this
into CHAY_DONG_BO_TU_DONG.ps1 securely; do not embed the secret into scripts.

IMPORTANT: The sync tool counts FILES, not Android tab SONGS. On Android,
filtering and de-duplication can change tab totals. Once uploaded, verify the
song in the Drive API and test app tabs after the PHP cache refresh.
