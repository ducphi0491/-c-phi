#!/usr/bin/env python3
"""TunerTools AI cache -> Google Drive, create-only and resumable.

Strict targets:
  ZING_AUDIO + YOUTUBE_CACHE audio  => AI_Music/stream_cache
  ZING_JSON  + YOUTUBE_CACHE JSON   => AI_Music/lyrics

No file outside these source/target folders is scanned. No delete, move,
overwrite, rename, or Drive folder creation. Python 3.10+, stdlib only.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib import error, parse, request

from DOI_CHIEU_AI_DRIVE import (
    AUDIO_EXTS, FOLDER_MIME, GOOGLE_FILES, GoogleReader,
    SOURCE_DEFAULT, TOKEN_DEFAULTS, find_local_files,
)

UPLOAD_URL = "https://www.googleapis.com/upload/drive/v3/files"
MIME_AUDIO = {
    ".ogg": "audio/ogg", ".mp3": "audio/mpeg", ".wav": "audio/wav",
    ".m4a": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac",
    ".opus": "audio/opus", ".webm": "audio/webm",
}
ZING_JSON = re.compile(r"^[A-Za-z0-9]{6,64}(?:_.+)?\.json$", re.I)
YOUTUBE_JSON = re.compile(r"^(?:lyrics|meta)_[A-Za-z0-9_-]{11}\.json$", re.I)
LOCK_FILE = "AI_DRIVE_SYNC_RUNNING.lock"
ID_RE = re.compile(r"^[A-Za-z0-9]{6,64}$")
CHUNK = 8 * 1024 * 1024


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def short_error(exc: Exception) -> str:
    if isinstance(exc, error.HTTPError):
        return "Google HTTP " + str(exc.code)
    return type(exc).__name__ + ": " + str(exc)[:160]


def sha_md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as fp:
        for buf in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(buf)
    return h.hexdigest()


def remote_by_name(items: list[dict], allowed_exts: set[str]) -> dict[str, list[dict]]:
    grouped = defaultdict(list)
    for o in items:
        n = o.get("name")
        if isinstance(n, str) and o.get("mimeType") != FOLDER_MIME and Path(n).suffix.lower() in allowed_exts:
            grouped[n].append(o)
    return dict(grouped)


def check_stable(path: Path, min_age: int) -> tuple[int, int]:
    if not path.is_file():
        raise RuntimeError("Local file missing")
    s = path.stat()
    if s.st_size <= 0:
        raise RuntimeError("Source file empty")
    age = time.time() - s.st_mtime
    if age < min_age:
        raise RuntimeError("Source file still new/writing: age=%ds < %ds" % (age, min_age))
    return s.st_size, s.st_mtime_ns


def remote_detail(drive: GoogleReader, file_id: str) -> dict:
    u = GOOGLE_FILES + "/" + parse.quote(file_id, safe="") + "?" + parse.urlencode({
        "fields": "id,name,mimeType,size,md5Checksum,parents",
    })
    return drive.get(u)


def remote_content_equal(drive: GoogleReader, info: dict, local: Path, require_md5: bool) -> bool:
    if str(info.get("size", "")) != str(local.stat().st_size):
        return False
    if not require_md5:
        return True
    meta = remote_detail(drive, str(info["id"]))
    checksum = str(meta.get("md5Checksum") or "").lower()
    if not checksum:
        raise RuntimeError("Drive file has no MD5 checksum")
    if checksum != sha_md5(local):
        raise RuntimeError("Drive and Server MD5 differ (same filename)")
    return True


def create_session(drive: GoogleReader, folder_id: str, local: Path, mime: str) -> str:
    metadata = json.dumps({"name": local.name, "mimeType": mime, "parents": [folder_id]},
                          ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    url = UPLOAD_URL + "?" + parse.urlencode({
        "uploadType": "resumable", "fields": "id,name,size,md5Checksum,parents"
    })
    req = request.Request(url, data=metadata, method="POST", headers={
        "Authorization": "Bearer " + drive.token,
        "Content-Type": "application/json; charset=UTF-8",
        "X-Upload-Content-Type": mime,
        "X-Upload-Content-Length": str(local.stat().st_size),
    })
    with request.urlopen(req, timeout=65) as resp:
        if resp.status not in (200, 201):
            raise RuntimeError("Drive session returned HTTP " + str(resp.status))
        location = resp.headers.get("Location", "")
    if not location.startswith("https://www.googleapis.com/"):
        raise RuntimeError("Drive resumable upload location is not expected Google host")
    return location


def put_chunks(location: str, local: Path, mime: str) -> dict:
    total = local.stat().st_size
    written = 0
    with local.open("rb") as fp:
        while written < total:
            chunk = fp.read(min(CHUNK, total - written))
            if not chunk:
                raise RuntimeError("Source file truncated during upload")
            end = written + len(chunk) - 1
            req = request.Request(location, data=chunk, method="PUT", headers={
                "Content-Type": mime,
                "Content-Range": f"bytes {written}-{end}/{total}",
                "Content-Length": str(len(chunk)),
            })
            try:
                with request.urlopen(req, timeout=180) as resp:
                    status = resp.status
                    body = resp.read()
                    response_headers = resp.headers
            except error.HTTPError as exc:
                if exc.code != 308:
                    raise
                status = 308
                response_headers = exc.headers
                body = b""
            if status == 308:
                ack = response_headers.get("Range", "")
                if not ack.startswith("bytes=0-"):
                    raise RuntimeError("Drive did not acknowledge upload byte range")
                last = int(ack.split("-")[-1])
                if last != end:
                    raise RuntimeError("Drive acknowledged unexpected byte range")
                written += len(chunk)
                continue
            if status in (200, 201):
                if end + 1 != total:
                    raise RuntimeError("Drive completed the upload before all chunks")
                try:
                    o = json.loads(body.decode("utf-8"))
                except Exception as exc:
                    raise RuntimeError("Invalid Drive create JSON") from exc
                if not isinstance(o, dict) or not o.get("id"):
                    raise RuntimeError("No Drive file ID returned")
                return o
            raise RuntimeError("Drive uploaded chunk returned HTTP " + str(status))
    raise RuntimeError("Drive session ended without final completion")


def upload_one(drive: GoogleReader, folder_id: str, local: Path, kind: str) -> dict:
    mime = "application/json" if kind == "lyrics" else MIME_AUDIO[local.suffix.lower()]
    url = create_session(drive, folder_id, local, mime)
    return put_chunks(url, local, mime)


def choose_files(root: Path, single_id: str | None) -> tuple[dict[str, list[Path]], dict]:
    result: dict[str, list[Path]] = {"audio": [], "lyrics": []}
    if single_id:
        if not ID_RE.fullmatch(single_id):
            raise RuntimeError("Invalid Zing ID")
        source = root / "ZING_AUDIO" / ("zing_acapella_" + single_id + ".ogg")
        if not source.is_file():
            raise RuntimeError("Cannot find expected ZING_AUDIO file: " + str(source))
        return {"audio": [source], "lyrics": []}, {"invalid": [], "missing": []}

    found, diag = find_local_files(root)
    if diag["folders_missing"]:
        raise RuntimeError("Local source folder missing: " + ", ".join(diag["folders_missing"]))
    issues = []
    for kind in ("audio", "lyrics"):
        for name, places in found[kind].items():
            if len(places) != 1:
                issues.append("Duplicate local filename " + name)
                continue
            p = Path(places[0][0])
            if kind == "lyrics":
                permitted = ZING_JSON.fullmatch(name) if p.parent.name == "ZING_JSON" else YOUTUBE_JSON.fullmatch(name)
                if not permitted:
                    issues.append("Skipped unrecognized JSON filename " + name)
                    continue
            result[kind].append(p)
        result[kind].sort(key=lambda p: p.name.casefold())
    return result, {"invalid": diag["invalid_json"],
                    "unrecognized_audio": diag["unrecognized_audio"],
                    "issues": issues, "missing": diag["folders_missing"]}


def acquire_lock(report_dir: Path):
    """Exclusive OS-level Windows file lock (automatically released on process exit)."""
    p = report_dir / LOCK_FILE
    fp = p.open("a+b")
    if os.name == "nt":
        import msvcrt
        fp.seek(0)
        if fp.read(1) == b"":
            fp.write(b"0")
            fp.flush()
        fp.seek(0)
        try:
            msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            fp.close()
            raise RuntimeError("Another AI Drive sync is currently running")
    else:
        import fcntl
        try:
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fp.close()
            raise RuntimeError("Another AI Drive sync is currently running")
    return fp


def sync(args: argparse.Namespace) -> int:
    root = Path(args.source)
    if not root.is_dir():
        raise RuntimeError("Source folder missing: " + str(root))
    report = Path(args.report) if args.report else root / "Reports" / "Drive_AutoSync"
    report.mkdir(parents=True, exist_ok=True)
    lock = acquire_lock(report)
    try:
        return sync_locked(args, root, report)
    finally:
        lock.close()


def sync_locked(args: argparse.Namespace, root: Path, report: Path) -> int:
    files, diagnostics = choose_files(root, args.single_id)
    token = Path(args.token) if args.token else next((Path(x) for x in TOKEN_DEFAULTS if Path(x).is_file()), None)
    if token is None or not token.is_file():
        raise RuntimeError("OAuth drive_token.json missing. Provide -TokenFile to PowerShell wrapper")
    print("===== TUNERTOOLS AI DRIVE SYNC =====")
    print("MODE:", "APPLY / CREATE ONLY" if args.apply else "PREVIEW / READ ONLY")
    print("SOURCE:", root)
    print("DRIVE: TunerTools_AppBackup/AI_Music/{stream_cache,lyrics} ONLY")
    print("TOKEN: found, never printed")
    print("UTC:", stamp())
    if diagnostics.get("issues"):
        print("LOCAL WARNINGS:", len(diagnostics["issues"]))
        for issue in diagnostics["issues"][:10]:
            print("  -", issue)
    if diagnostics.get("invalid"):
        print("INVALID JSON (NOT UPLOADED):", len(diagnostics["invalid"]))
    if diagnostics.get("unrecognized_audio"):
        print("UNRECOGNIZED AUDIO (NOT UPLOADED):", len(diagnostics["unrecognized_audio"]))

    drive = GoogleReader(token)
    root_id = drive.folder("root", "TunerTools_AppBackup")
    ai_id = drive.folder(root_id, "AI_Music")
    ids = {
        "audio": drive.folder(ai_id, "stream_cache"),
        "lyrics": drive.folder(ai_id, "lyrics"),
    }
    remote = {
        "audio": remote_by_name(drive.list_files(ids["audio"]), AUDIO_EXTS),
        "lyrics": remote_by_name(drive.list_files(ids["lyrics"]), {".json"}),
    }
    print("DRIVE AUDIO FILENAMES:", len(remote["audio"]))
    print("DRIVE JSON FILENAMES:", len(remote["lyrics"]))
    pending: list[tuple[str, Path]] = []
    existing = 0
    conflicts: list[dict] = []
    unstable = []
    for kind in ("audio", "lyrics"):
        for path in files[kind]:
            matches = remote[kind].get(path.name, [])
            if len(matches) > 1:
                conflicts.append({"file": path.name, "reason": "Multiple Drive files with same name"})
                continue
            if len(matches) == 1:
                try:
                    if remote_content_equal(drive, matches[0], path, require_md5=bool(args.single_id)):
                        existing += 1
                    else:
                        conflicts.append({"file": path.name, "reason": "Different file size; no overwrite"})
                except Exception as exc:
                    conflicts.append({"file": path.name, "reason": short_error(exc)})
                continue
            try:
                check_stable(path, args.min_age)
            except Exception as exc:
                unstable.append({"file": path.name, "reason": short_error(exc)})
                continue
            pending.append((kind, path))
    print("LOCAL AUDIO:", len(files["audio"]), "LOCAL JSON:", len(files["lyrics"]))
    print("PRESENT:", existing, "MISSING NEW:", len(pending),
          "CONFLICT:", len(conflicts), "NOT_READY:", len(unstable))
    for kind, path in pending[:12]:
        print("  TO UPLOAD:", kind.upper(), path.name)
    for c in conflicts[:8]:
        print("  CONFLICT:", c["file"], c["reason"])
    for c in unstable[:8]:
        print("  WAIT:", c["file"], c["reason"])
    result = {
        "utc": stamp(), "apply": args.apply,
        "source": str(root), "target": "AI_Music/{stream_cache,lyrics}",
        "local_audio": len(files["audio"]), "local_lyrics": len(files["lyrics"]),
        "drive_audio": len(remote["audio"]), "drive_lyrics": len(remote["lyrics"]),
        "existing": existing, "pending": len(pending),
        "conflicts": conflicts, "unstable": unstable,
        "created": [], "failed": [], "remaining": [],
    }
    if not args.apply:
        print("PREVIEW: No files uploaded. Run again with -Apply to create missing files.")
        result_path = report / "AI_DRIVE_SYNC_LAST_PREVIEW.json"
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print("REPORT:", result_path)
        return 0 if not conflicts else 2

    for idx, (kind, path) in enumerate(pending[:args.max_files], start=1):
        print("[%d/%d] %s" % (idx, min(len(pending), args.max_files), path.name))
        try:
            size, mtime = check_stable(path, args.min_age)
            # Re-read the exact destination name immediately before create.
            exact = [x for x in drive.list_files(ids[kind], path.name)
                     if x.get("name") == path.name and x.get("mimeType") != FOLDER_MIME]
            if exact:
                if len(exact) == 1 and remote_content_equal(drive, exact[0], path, require_md5=True):
                    print("  SKIP: Already uploaded by another run")
                    continue
                raise RuntimeError("Existing Drive name conflicts; refusing overwrite")
            created_obj = None
            post_exception = None
            try:
                created_obj = upload_one(drive, ids[kind], path, kind)
            except Exception as exc:
                post_exception = exc
            # Do not re-POST after ambiguous errors. Verify remote by live listing.
            confirmed = None
            for attempt in range(4):
                time.sleep(1.0 + attempt * 1.2)
                exact = [x for x in drive.list_files(ids[kind], path.name)
                         if x.get("name") == path.name and x.get("mimeType") != FOLDER_MIME]
                if len(exact) == 1:
                    confirmed = exact[0]
                    break
                if len(exact) > 1:
                    raise RuntimeError("Duplicate Drive filename after upload; manual review needed")
            if confirmed is None:
                if post_exception:
                    raise RuntimeError("Upload status unresolved: " + short_error(post_exception))
                raise RuntimeError("Drive file was not visible after upload")
            if post_exception is not None:
                print("  NOTICE: Upload response was interrupted; Drive shows the file now")
            stat = path.stat()
            if stat.st_size != size or stat.st_mtime_ns != mtime:
                raise RuntimeError("Source file changed during upload; manual validation needed")
            if not remote_content_equal(drive, confirmed, path, require_md5=True):
                raise RuntimeError("Drive size mismatch after upload")
            result["created"].append({"kind": kind, "file": path.name,
                                     "bytes": size, "drive_id": str(confirmed.get("id"))})
            print("  OK: Drive size and MD5 verified")
        except Exception as exc:
            result["failed"].append({"kind": kind, "file": path.name, "error": short_error(exc)})
            print("  FAILED:", short_error(exc))
        if args.pause:
            time.sleep(args.pause)
    result["remaining"] = [p.name for _, p in pending[args.max_files:]]
    result_path = report / "AI_DRIVE_SYNC_LAST_RUN.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("===== COMPLETE =====")
    print("UPLOADED:", len(result["created"]), "FAILED:", len(result["failed"]),
          "QUEUED_FOR_NEXT_RUN:", len(result["remaining"]))
    print("REPORT:", result_path)
    print("PHP cached_songs may be stale for up to 600 seconds.")
    print("No files on Google Drive were overwritten, renamed or deleted.")
    return 1 if (result["failed"] or conflicts) else 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=SOURCE_DEFAULT)
    parser.add_argument("--token", default="")
    parser.add_argument("--report", default="")
    parser.add_argument("--single-id", default="", help="Only one Zing ID .ogg from ZING_AUDIO")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--min-age", type=int, default=60)
    parser.add_argument("--max-files", type=int, default=50)
    parser.add_argument("--pause", type=float, default=1.5)
    args = parser.parse_args()
    if args.min_age < 0 or args.min_age > 86400:
        parser.error("--min-age must be 0..86400")
    if args.max_files < 1 or args.max_files > 1000:
        parser.error("--max-files must be 1..1000")
    if args.pause < 0 or args.pause > 30:
        parser.error("--pause must be 0..30")
    sys.stdout.reconfigure(errors="replace")
    try:
        return sync(args)
    except Exception as exc:
        print("ERROR:", short_error(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
