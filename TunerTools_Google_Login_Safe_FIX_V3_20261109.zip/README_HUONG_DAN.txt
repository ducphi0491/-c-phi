TUNERTOOLS - GOOGLE LOGIN SAFE FIX V3
====================================
Muc tieu: Sua loi ban Google_IDToken_FIX truoc do khien dang nhap tai khoan Google bi loi.
File nguon: TunerTools_Google_IDToken_Gamefolder_Admin_FIX_20261109.zip (V2).
Chua xac minh APK tren dien thoai thuc te.

NGUYEN NHAN DA XAC NHAN TRONG CODE V2
- buildTunerGoogleSignInOptions() da them requestIdToken(WEB_CLIENT_ID) vao
  luong dang nhap Google DUNG CHUNG. Day la thay doi so voi file goc.
- Khi Google OAuth Android Client chua dung package/SHA-1, dang nhap yeu cau
  ID token co the that bai (thuong ApiException 10).
- Nhan Dang nhap lai tai trang Admin truoc do goi signOut(), lam mat phien
  Google cua cac chuc nang khac.

DA SUA
1. Gamefolder.kt
   - buildTunerGoogleSignInOptions: tra lai cach dang nhap cu chi
     requestEmail + requestProfile, KHONG ep requestIdToken.
   - Them buildTunerDocumentsGoogleSignInOptions: yeu cau ID token CHI
     trong man hinh Documents/SongTab co tinh nang xac thuc ri eng.
   - Khi thieu token: hien thi can xac thuc Documents, KHONG tu signOut.
   - Chi signOut khi nguoi dung chu dong chon Doi tai khoan.
   - Hien thi ma loi Google OAuth neu viec cap ID token that bai.
2. admin.kt
   - Dung rieng Documents sign-in client.
   - Nut Dang nhap/ Dang nhap lai khong tu dang xuat tai khoan Google.
   - Nut Doi tai khoan (chu dong) van cho phep signOut.
3. tt_documents_oauth.xml
   - Giu Web Client ID tu XML nguoi dung da cung cap, khong thay doi.
   - Neu project da co string name=tt_documents_web_client_id, CHI GIU MOT.

CAI DAT
1. Sao luu Gamefolder.kt va admin.kt hien dang dung.
2. Thay 2 file Kotlin bang file trong thu muc Android/ cua ZIP.
3. XML dat tai app/src/main/res/values/tt_documents_oauth.xml.
   Neu da co XML nay va Web Client ID dung, KHONG can thay/tao ban thu hai.
4. Android Studio -> Build -> Rebuild Project -> build va cai APK MOI.
   Uu tien cai cap nhat de khong mat du lieu ung dung, khong can go app.
5. Thu DANG NHAP TAI KHOAN GOOGLE thong thuong truoc (khong vao
   Admin/Documents). Phan nay phai hoat dong nhu truoc.
6. Vao Admin -> Quyen tai lieu -> Dang nhap bang Google, de cap
   ID token RIENG cho Documents. KHONG phai dang xuat tai khoan chinh.
7. Neu Documents van bao ma Google 10, phai cau hinh OAuth Android Client
   theo muc ben duoi. Khong the bo qua xac minh ID token de cap quyen.

BAT BUOC KIEM TRA GOOGLE CLOUD NEU DOCUMENTS VAN LOI
- Google Cloud -> dung project chua Web Client ID da dung trong XML.
- Google Auth Platform -> Clients: can co client LOAI ANDROID cung project.
- Package name: lay applicationId thuc trong app/build.gradle.kts (hoac .gradle).
- SHA-1: fingerprint cua dung APK dang cai (debug/release/Play Store).
  Android Studio Terminal (o root du an): .\gradlew.bat signingReport
  Google Play version: lay App signing key certificate SHA-1 trong Play Console.
- Tao Android OAuth Client voi applicationId + SHA-1 tuong ung.
- Web Client ID trong XML phai TRUNG voi TUNERTOOLS_DOCUMENTS_WEB_CLIENT_ID
  trong /home/tuner/private/tt_documents_private.php tren Alwaysdata.
- Khong can tao lai OAuth Desktop Uploader, Drive Token, MySQL hay JSON 93 TK.
- Neu sau do bao google_identity_not_verified, can kiem tra claims token (aud,
  iss, email_verified, exp, sub) qua chan doan AN TOAN phia may chu.
  Tuyet doi khong gui Google ID token, token Drive, session secret len chat.

PHAM VI KIEM TRA DUOC THUC HIEN
- So sanh diff voi ma nguon goc va ban V2.
- Test static luong dang nhap, UI khong tu signOut va giao tiep server.
- Trich xuat ham build options THUC TE va bien dich/chay kiem thu bang kotlinc.
- Chua build toan bo Android APK (thieu toan bo du an va SDK tuong ung).

NEU MUON KHOI PHUC TAM THOI NGAY
- Dung backup Gamefolder.kt + admin.kt da build/chay on truoc dot
  Drive Primary; ap dat lai sau khi backup.
- Luu y ban goc co the khong co co che Documents Drive Primary va xac thuc
  Google ID token moi; phuong an nay chi de khoi phuc dang nhap co ban.
