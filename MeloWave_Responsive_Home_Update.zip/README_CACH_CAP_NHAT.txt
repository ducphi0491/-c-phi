MeloWave - Responsive Home update (16/10/2026)

Thay the HAI file trong app/src/main/java/duc_phi/music/:
  1. HomeScreen.kt
  2. MusicUiComponents.kt

Diem thay doi:
- Phan noi dung Home su dung padding cua Scaffold, khong cong lai status bar.
- Cac khoi header, search, banner, cong cu am thanh gon hon tren man hinh thap.
- Hai the cong cu giu trong mot hang; chieu cao the khong thap hon 48dp.
- Anh bia bai hat gan day 112dp tren man hinh thap, 100dp tren man hinh rat thap,
  132dp tren man hinh lon; danh sach van cuon ngang binh thuong.
- MiniPlayer tai Home duoc ha khoang 8dp; thanh play o duoi khong bi day
  xuong vung nut dieu huong Android.
- Khong thay 16 anh WebP hoac build.gradle.kts.
- Chua build APK trong Android Studio; vui long chay thu tren may thuc te.
