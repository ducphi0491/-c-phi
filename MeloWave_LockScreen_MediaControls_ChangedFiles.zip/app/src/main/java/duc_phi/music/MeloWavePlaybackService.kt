package duc_phi.music

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.session.MediaSession
import android.media.MediaMetadata
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * One MusicController for the UI and the music service. In particular, disposing the
 * Compose screen must NOT release its ExoPlayer while music is playing in the background.
 * All methods are called on the Android main thread.
 */
internal object MeloWavePlaybackRuntime {
    private var sharedController: MusicController? = null
    private var activityReferences = 0
    private var service: MeloWavePlaybackService? = null
    private var serviceStartRequested = false

    fun obtain(context: Context): MusicController = sharedController ?: MusicController(context.applicationContext)
        .also { sharedController = it }

    fun attachActivity() { activityReferences++ }

    fun detachActivity() {
        activityReferences = (activityReferences - 1).coerceAtLeast(0)
        releaseIfUnused()
    }

    fun attachService(instance: MeloWavePlaybackService) {
        service = instance
        serviceStartRequested = false
    }

    fun detachService(instance: MeloWavePlaybackService) {
        if (service === instance) service = null
        serviceStartRequested = false
        releaseIfUnused()
    }

    private fun releaseIfUnused() {
        if (activityReferences == 0 && service == null && !serviceStartRequested) {
            sharedController?.release()
            sharedController = null
        }
    }

    fun onPlaybackChanged() { service?.refreshPlayback() }
    fun onSeekChanged() { service?.refreshSeekPosition() }

    fun ensureService(context: Context) {
        service?.let { it.refreshPlayback(); return }
        if (serviceStartRequested) return
        serviceStartRequested = true
        try {
            ContextCompat.startForegroundService(
                context.applicationContext,
                Intent(context.applicationContext, MeloWavePlaybackService::class.java)
                    .setAction(MeloWavePlaybackService.ACTION_ACTIVATE)
            )
        } catch (error: Exception) {
            serviceStartRequested = false
            Log.w("MeloWavePlayback", "Unable to start media playback service", error)
        }
    }
}

/**
 * Real Android MediaSession + media-style notification for lock screen, Bluetooth
 * headset keys and Android system media controls. Owns the controller reference
 * while playback is active, even after MainActivity is destroyed.
 */
class MeloWavePlaybackService : Service() {
    companion object {
        const val ACTION_ACTIVATE = "duc_phi.music.PLAYBACK_ACTIVATE"
        private const val ACTION_PLAY_PAUSE = "duc_phi.music.PLAYBACK_PLAY_PAUSE"
        private const val ACTION_NEXT = "duc_phi.music.PLAYBACK_NEXT"
        private const val ACTION_PREVIOUS = "duc_phi.music.PLAYBACK_PREVIOUS"
        private const val ACTION_STOP = "duc_phi.music.PLAYBACK_STOP"
        private const val CHANNEL_ID = "melowave_media_playback"
        private const val NOTIFICATION_ID = 19421
    }

    private lateinit var controller: MusicController
    private lateinit var mediaSession: MediaSession
    private lateinit var notifications: NotificationManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val artworkScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var artworkJob: Job? = null
    private var notificationStarted = false
    private var currentArtKey: String? = null
    private var currentArt: Bitmap? = null
    private var currentMetadataSongId: String? = null
    private var currentMetadataDuration: Long = -1L
    private var lastStateId: String? = null
    private var lastPlaying = false
    private var lastLoading = false
    private var lastPlaybackState = -1
    private var seekUpdatePending = false

    private val ticker = object : Runnable {
        override fun run() {
            refreshPlayback()
            mainHandler.postDelayed(this, 1500L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        notifications = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createMediaNotificationChannel()
        controller = MeloWavePlaybackRuntime.obtain(applicationContext)
        mediaSession = MediaSession(this, "MeloWave").apply {
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    if (!controller.player.isPlaying &&
                        !(controller.isLoading && controller.player.playWhenReady)) {
                        controller.togglePlayback()
                    }
                    refreshPlayback()
                }
                override fun onPause() {
                    controller.pauseForSystemMediaControls()
                    refreshPlayback()
                }
                override fun onSkipToNext() { controller.next(); refreshPlayback() }
                override fun onSkipToPrevious() { controller.previous(); refreshPlayback() }
                override fun onSeekTo(pos: Long) { controller.seekTo(pos); refreshPlayback() }
                override fun onStop() {
                    controller.pauseForSystemMediaControls()
                    stopForegroundAndNotification()
                    stopSelf()
                }
            }, mainHandler)
            isActive = true
        }
        MeloWavePlaybackRuntime.attachService(this)
        mainHandler.post(ticker)
    }

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> {
                if (controller.player.playWhenReady) controller.pauseForSystemMediaControls()
                else controller.togglePlayback()
            }
            ACTION_NEXT -> controller.next()
            ACTION_PREVIOUS -> controller.previous()
            ACTION_STOP -> {
                controller.pauseForSystemMediaControls()
                stopForegroundAndNotification()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        refreshPlayback()
        if (controller.currentSong == null) stopSelf()
        return START_NOT_STICKY
    }

    /** Called when the controller changes song, playback state or ExoPlayer instance. */
    internal fun refreshSeekPosition() {
        seekUpdatePending = true
        refreshPlayback()
    }

    internal fun refreshPlayback() {
        if (!::mediaSession.isInitialized) return
        val song = controller.currentSong
        if (song == null || controller.castConnected ||
            song.source == SongSource.MOVIE || song.source == SongSource.INTERNET_P2P) {
            if (notificationStarted) {
                stopForegroundAndNotification()
                stopSelf()
            }
            return
        }

        val artworkUrl = controller.artworkFor(song)
        val artKey = "${song.id}|${artworkUrl.orEmpty()}"
        if (artKey != currentArtKey) {
            currentArtKey = artKey
            currentArt = null
            artworkJob?.cancel()
            artworkJob = artworkScope.launch {
                val bitmap = readAlbumArt(song, artworkUrl)
                withContext(Dispatchers.Main) {
                    if (currentArtKey == artKey) {
                        currentArt = bitmap
                        updateSessionMetadata()
                        if (notificationStarted) notifications.notify(NOTIFICATION_ID, makeNotification())
                    }
                }
            }
        }
        val duration = effectiveDuration()
        if (song.id != currentMetadataSongId || duration != currentMetadataDuration) {
            updateSessionMetadata()
        }

        val isPlaying = controller.player.isPlaying
        val buffering = controller.isLoading
        val state = controller.player.playbackState
        // SystemUI advances the seek bar from PlaybackState speed/position.
        // Republish only on a state change or explicit seek, never every 2 seconds.
        if (song.id != lastStateId || isPlaying != lastPlaying || buffering != lastLoading ||
            state != lastPlaybackState || seekUpdatePending) {
            lastStateId = song.id
            lastPlaying = isPlaying
            lastLoading = buffering
            lastPlaybackState = state
            seekUpdatePending = false
            updateSessionState()
            val notification = makeNotification()
            if (!notificationStarted) {
                try {
                    val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
                    ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)
                    notificationStarted = true
                } catch (error: Exception) {
                    Log.e("MeloWavePlayback", "Media notification/foreground service failed", error)
                    stopSelf()
                }
            } else {
                notifications.notify(NOTIFICATION_ID, notification)
            }
        }
    }

    private fun effectiveDuration(): Long {
        val playerDuration = controller.player.duration
        return when {
            playerDuration > 0 && playerDuration < Long.MAX_VALUE / 2 -> playerDuration
            controller.durationMs > 1L -> controller.durationMs
            else -> controller.currentSong?.durationMs ?: 0L
        }.coerceAtLeast(0L)
    }

    private fun updateSessionMetadata() {
        val song = controller.currentSong ?: return
        currentMetadataSongId = song.id
        currentMetadataDuration = effectiveDuration()
        val metadata = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, song.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, song.artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, song.album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, currentMetadataDuration)
            .apply {
                currentArt?.let { artwork ->
                    // One bitmap only: media-session metadata travels across Binder.
                    putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artwork)
                }
            }.build()
        mediaSession.setMetadata(metadata)
    }

    private fun updateSessionState() {
        val state = when {
            controller.isLoading -> PlaybackState.STATE_BUFFERING
            controller.player.isPlaying -> PlaybackState.STATE_PLAYING
            controller.player.playbackState == androidx.media3.common.Player.STATE_ENDED -> PlaybackState.STATE_STOPPED
            else -> PlaybackState.STATE_PAUSED
        }
        val canSeek = effectiveDuration() > 0L
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
            PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
            PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP or
            (if (canSeek) PlaybackState.ACTION_SEEK_TO else 0L)
        mediaSession.setPlaybackState(PlaybackState.Builder()
            .setActions(actions)
            .setState(state, controller.player.currentPosition.coerceAtLeast(0L),
                if (state == PlaybackState.STATE_PLAYING) 1f else 0f,
                SystemClock.elapsedRealtime())
            .build())
    }

    private fun makeNotification(): Notification {
        val song = controller.currentSong
        val paused = !controller.player.isPlaying
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(this, 101, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val style = Notification.MediaStyle()
            .setMediaSession(mediaSession.sessionToken)
            .setShowActionsInCompactView(0, 1, 2)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(song?.title ?: "MeloWave")
            .setContentText(song?.artist?.ifBlank { "MeloWave" } ?: "MeloWave")
            .setSubText("MeloWave")
            .setContentIntent(contentIntent)
            .setLargeIcon(currentArt)
            .setStyle(style)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(!paused)
            .addAction(android.R.drawable.ic_media_previous, "Bài trước", actionIntent(ACTION_PREVIOUS, 102))
            .addAction(if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause,
                if (paused) "Phát" else "Tạm dừng", actionIntent(ACTION_PLAY_PAUSE, 103))
            .addAction(android.R.drawable.ic_media_next, "Bài tiếp", actionIntent(ACTION_NEXT, 104))
            .build()
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(this, requestCode,
            Intent(this, MeloWavePlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun createMediaNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            notifications.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "MeloWave · Điều khiển nhạc",
                    NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Phát nhạc và điều khiển trên màn hình khóa"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun stopForegroundAndNotification() {
        if (notificationStarted) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            notificationStarted = false
        }
        notifications.cancel(NOTIFICATION_ID)
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(ticker)
        artworkJob?.cancel()
        artworkScope.cancel()
        stopForegroundAndNotification()
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        MeloWavePlaybackRuntime.detachService(this)
        super.onDestroy()
    }

    private fun readAlbumArt(song: SongItem, artworkUrl: String?): Bitmap? = runCatching {
        val artUri = artworkUrl?.takeIf { it.isNotBlank() }?.let(Uri::parse)
        val bytes = if (artUri != null) readArtworkBytes(artUri) else null
        val decodedBytes = bytes ?: if (song.source in setOf(
                SongSource.LOCAL_MEDIASTORE, SongSource.DOWNLOADED, SongSource.APP_RESOURCE)) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, song.uri)
                retriever.embeddedPicture
            } finally { retriever.release() }
        } else null
        decodedBytes?.let { bytesToSmallBitmap(it) }
    }.onFailure { Log.d("MeloWavePlayback", "Album cover not available: ${it.message}") }.getOrNull()

    private fun readArtworkBytes(uri: Uri): ByteArray? {
        return when (uri.scheme?.lowercase()) {
            "content", "file", "android.resource" ->
                contentResolver.openInputStream(uri)?.use { input ->
                    input.readNBytesCompat(4_000_001).takeIf { it.size <= 4_000_000 }
                }
            "http", "https" -> {
                val connection = (URL(uri.toString()).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 3500
                    instanceFollowRedirects = true
                }
                try {
                    if (connection.responseCode !in 200..299 || connection.contentLengthLong > 4_000_000L)
                        null
                    else connection.inputStream.use { input ->
                        val bytes = input.readNBytesCompat(4_000_001)
                        bytes.takeIf { it.size <= 4_000_000 }
                    }
                } finally { connection.disconnect() }
            }
            else -> null
        }
    }

    private fun java.io.InputStream.readNBytesCompat(maxBytes: Int): ByteArray {
        val result = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (result.size() < maxBytes) {
            val count = read(buffer, 0, minOf(buffer.size, maxBytes - result.size()))
            if (count < 0) break
            result.write(buffer, 0, count)
        }
        return result.toByteArray()
    }

    private fun bytesToSmallBitmap(bytes: ByteArray): Bitmap? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        val longest = maxOf(options.outWidth, options.outHeight)
        if (longest <= 0) return null
        var sample = 1
        while (longest / sample > 512) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
            BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val maxDimension = maxOf(decoded.width, decoded.height)
        if (maxDimension <= 320) return decoded
        val width = (decoded.width * 320f / maxDimension).toInt().coerceAtLeast(1)
        val height = (decoded.height * 320f / maxDimension).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(decoded, width, height, true)
        if (scaled !== decoded) decoded.recycle()
        return scaled
    }
}
