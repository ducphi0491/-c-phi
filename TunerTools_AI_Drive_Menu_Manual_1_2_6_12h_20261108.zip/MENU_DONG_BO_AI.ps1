﻿$ErrorActionPreference = 'Stop'
try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch { }

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Saved upload-session URLs are limited to SYSTEM and Administrators.
# Run the same menu elevated for both manual and automatic operations.
if (-not (Test-Administrator)) {
    Write-Host 'Can quyen Administrator de upload va cai lich.' -ForegroundColor Yellow
    Write-Host 'Dang yeu cau UAC...'
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $psArgs = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
    try {
        Start-Process -FilePath $psExe -ArgumentList $psArgs -Verb RunAs -Wait -ErrorAction Stop
    } catch {
        Write-Host ('Khong mo duoc quyen Administrator: ' + $_.Exception.Message) -ForegroundColor Red
        exit 1
    }
    exit 0
}

$run = Join-Path $PSScriptRoot 'CHAY_DONG_BO_AI.ps1'
$schedule = Join-Path $PSScriptRoot 'LICH_DONG_BO_AI.ps1'
function Pause-Menu {
    [void](Read-Host 'Nhan ENTER de tiep tuc')
}
function Show-ScheduleStatus {
    try {
        & $schedule -Action Status
    } catch {
        Write-Host ('Khong doc duoc lich: ' + $_.Exception.Message) -ForegroundColor Yellow
    }
}
function Schedule-Menu {
    $back = $false
    while (-not $back) {
        Clear-Host
        Write-Host '===== CAI DAT DONG BO TU DONG =====' -ForegroundColor Cyan
        Show-ScheduleStatus
        Write-Host ''
        Write-Host '  1. Dong bo moi 1 gio'
        Write-Host '  2. Dong bo moi 2 gio'
        Write-Host '  3. Dong bo moi 6 gio'
        Write-Host '  4. Dong bo moi 12 gio'
        Write-Host '  5. TAT lich tu dong (khong xoa file Drive)'
        Write-Host '  0. Quay lai'
        $choice = (Read-Host 'Chon').Trim()
        $hours = switch ($choice) {
            '1' { 1 }
            '2' { 2 }
            '3' { 6 }
            '4' { 12 }
            default { 0 }
        }
        try {
            if ($hours -gt 0) {
                & $schedule -Action Set -Hours $hours
                Write-Host 'Da luu lich. Ban van co the dong bo thu cong bat cu luc nao.' -ForegroundColor Green
                Pause-Menu
                $back = $true
            } elseif ($choice -eq '5') {
                & $schedule -Action Disable
                Write-Host 'Da tat lich. Du lieu tren Google Drive duoc giu nguyen.' -ForegroundColor Green
                Pause-Menu
                $back = $true
            } elseif ($choice -eq '0') {
                $back = $true
            } else {
                Write-Host 'Lua chon khong hop le.' -ForegroundColor Yellow
                Pause-Menu
            }
        } catch {
            Write-Host ('LOI CAI LICH: ' + $_.Exception.Message) -ForegroundColor Red
            Pause-Menu
        }
    }
}

while ($true) {
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host ' TUNERTOOLS - AI MUSIC -> GOOGLE DRIVE' -ForegroundColor Cyan
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host 'Drive chi dung 2 folder: stream_cache + lyrics'
    Write-Host 'Upload file moi, khong xoa/ghi de Drive.'
    Write-Host ''
    Show-ScheduleStatus
    Write-Host ''
    Write-Host '  1. CHAY THU CONG NGAY (upload file con thieu)'
    Write-Host '  2. CHAY THEO THOI GIAN (1/2/6/12 gio)'
    Write-Host '  0. THOAT'
    Write-Host ''
    $choice = (Read-Host 'Chon').Trim()
    switch ($choice) {
        '1' {
            Write-Host 'Dang dong bo thu cong. Khong dong cua so khi dang upload.' -ForegroundColor Yellow
            try {
                & $run -MaxFiles 1000
                Write-Host 'DONG BO HOAN THANH. Xem ket qua UPLOADED / FAILED o tren.' -ForegroundColor Green
            } catch {
                Write-Host ('DONG BO GAP LOI: ' + $_.Exception.Message) -ForegroundColor Red
            }
            Pause-Menu
        }
        '2' { Schedule-Menu }
        '0' { exit 0 }
        default { Write-Host 'Lua chon khong hop le.' -ForegroundColor Yellow; Pause-Menu }
    }
}
