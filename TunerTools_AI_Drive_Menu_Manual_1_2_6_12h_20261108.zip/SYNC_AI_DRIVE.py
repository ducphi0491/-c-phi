#!/usr/bin/env python3
"""TunerTools AI cache -> Google Drive, create-only and resumable.

Strict targets:
  ZING_AUDIO + YOUTUBE_CACHE audio  => AI_Music/stream_cache
  ZING_JSON  + YOUTUBE_CACHE JSON   => AI_Music/lyrics

No file outside these source/target folders is scanned. No delete, move,
overwrite, rename, or Drive folder creation. Python 3.10+, stdlib only.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
import http.client
import socket
import ssl
import subprocess
from functools import lru_cache
from pathlib import Path
import re
import sys
import time
from urllib import error, parse, request

from DOI_CHIEU_AI_DRIVE import (
    AUDIO_EXTS, FOLDER_MIME, GOOGLE_FILES, GoogleReader,
    SOURCE_DEFAULT, TOKEN_DEFAULTS, find_local_files,
)

UPLOAD_URL = "https://www.googleapis.com/upload/drive/v3/files"
MIME_AUDIO = {
    ".ogg": "audio/ogg", ".mp3": "audio/mpeg", ".wav": "audio/wav",
    ".m4a": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac",
    ".opus": "audio/opus", ".webm": "audio/webm",
}
ZING_JSON = re.compile(r"^[A-Za-z0-9]{6,64}(?:_.+)?\.json$", re.I)
YOUTUBE_JSON = re.compile(r"^(?:lyrics|meta)_[A-Za-z0-9_-]{11}\.json$", re.I)
LOCK_FILE = "AI_DRIVE_SYNC_RUNNING.lock"
ID_RE = re.compile(r"^[A-Za-z0-9]{6,64}$")
CHUNK = 1 * 1024 * 1024
RETRY_HTTP = {408, 429, 500, 502, 503, 504}
SESSION_DIR = ".upload_sessions"


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def short_error(exc: Exception) -> str:
    if isinstance(exc, error.HTTPError):
        return "Google HTTP " + str(exc.code)
    return type(exc).__name__ + ": " + str(exc)[:160]


def sha_md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as fp:
        for buf in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(buf)
    return h.hexdigest()


def remote_by_name(items: list[dict], allowed_exts: set[str]) -> dict[str, list[dict]]:
    grouped = defaultdict(list)
    for o in items:
        n = o.get("name")
        if isinstance(n, str) and o.get("mimeType") != FOLDER_MIME and Path(n).suffix.lower() in allowed_exts:
            grouped[n].append(o)
    return dict(grouped)


def check_stable(path: Path, min_age: int) -> tuple[int, int]:
    if not path.is_file():
        raise RuntimeError("Local file missing")
    s = path.stat()
    if s.st_size <= 0:
        raise RuntimeError("Source file empty")
    age = time.time() - s.st_mtime
    if age < min_age:
        raise RuntimeError("Source file still new/writing: age=%ds < %ds" % (age, min_age))
    return s.st_size, s.st_mtime_ns


def remote_detail(drive: GoogleReader, file_id: str) -> dict:
    u = GOOGLE_FILES + "/" + parse.quote(file_id, safe="") + "?" + parse.urlencode({
        "fields": "id,name,mimeType,size,md5Checksum,parents",
    })
    return drive.get(u)


def remote_content_equal(drive: GoogleReader, info: dict, local: Path, require_md5: bool) -> bool:
    if str(info.get("size", "")) != str(local.stat().st_size):
        return False
    if not require_md5:
        return True
    meta = remote_detail(drive, str(info["id"]))
    checksum = str(meta.get("md5Checksum") or "").lower()
    if not checksum:
        raise RuntimeError("Drive file has no MD5 checksum")
    if checksum != sha_md5(local):
        raise RuntimeError("Drive and Server MD5 differ (same filename)")
    return True


class UploadSessionExpired(RuntimeError):
    pass


def validate_session_location(location: str) -> str:
    u = parse.urlsplit(location)
    # The URI is an upload credential. Never print it to logs.
    if u.scheme != "https" or u.hostname != "www.googleapis.com" or not u.path.startswith("/upload/drive/v3/files"):
        raise RuntimeError("Invalid Google Drive resumable session URL")
    return location


@lru_cache(maxsize=16)
def session_dir(report: Path) -> Path:
    """Restrict saved Google upload sessions to SYSTEM and local Administrators."""
    d = report / SESSION_DIR
    d.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        command = ["icacls.exe", str(d), "/inheritance:r", "/grant:r",
                   "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F", "/Q"]
        proc = subprocess.run(command, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError("Unable to protect Drive upload session directory ACL; run as Administrator")
    else:
        d.chmod(0o700)
    return d


def state_path(report: Path, kind: str, path: Path, folder_id: str) -> Path:
    key = hashlib.sha256((kind + "\0" + str(path.resolve()) + "\0" + folder_id).encode('utf-8')).hexdigest()
    return session_dir(report) / (key + ".json")


def save_session(path: Path, info: dict) -> None:
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(info, ensure_ascii=False), encoding='utf-8')
    if os.name != "nt":
        tmp.chmod(0o600)
    os.replace(tmp, path)


def load_session(path: Path, source: Path, folder_id: str) -> str | None:
    if not path.exists():
        return None
    info = json.loads(path.read_text(encoding='utf-8'))
    stat = source.stat()
    if (info.get('file') != str(source.resolve()) or info.get('folder_id') != folder_id
            or info.get('size') != stat.st_size or info.get('mtime_ns') != stat.st_mtime_ns):
        raise RuntimeError("Source changed since unfinished upload; check session manually before retry")
    return validate_session_location(str(info['location']))


def create_session(drive: GoogleReader, folder_id: str, local: Path, mime: str) -> str:
    metadata = json.dumps({"name": local.name, "mimeType": mime, "parents": [folder_id]},
                          ensure_ascii=False, separators=(",", ":")).encode('utf-8')
    url = UPLOAD_URL + "?" + parse.urlencode({
        "uploadType": "resumable", "fields": "id,name,size,md5Checksum,parents"
    })
    for attempt in range(4):
        req = request.Request(url, data=metadata, method="POST", headers={
            "Authorization": "Bearer " + drive.token,
            "Content-Type": "application/json; charset=UTF-8",
            "X-Upload-Content-Type": mime,
            "X-Upload-Content-Length": str(local.stat().st_size),
        })
        try:
            with request.urlopen(req, timeout=60) as resp:
                if resp.status != 200:
                    raise RuntimeError("Drive session returned HTTP " + str(resp.status))
                return validate_session_location(resp.headers.get("Location", ""))
        except error.HTTPError as exc:
            if exc.code == 401 and attempt < 3:
                drive.refresh()
            elif exc.code not in RETRY_HTTP or attempt == 3:
                raise
        except (error.URLError, TimeoutError, ConnectionError, socket.timeout, http.client.RemoteDisconnected, ssl.SSLError):
            if attempt == 3:
                raise
        time.sleep(min(8, 1.5 * (2 ** attempt)))
    raise RuntimeError("Unable to initialize Drive upload")


def resumable_response(req: request.Request, timeout: int):
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.headers, resp.read()
    except error.HTTPError as exc:
        if exc.code == 308:
            return 308, exc.headers, b''
        if exc.code in (404, 410):
            raise UploadSessionExpired('Drive session expired') from exc
        raise


def received_offset(headers, total: int) -> int:
    raw = headers.get("Range", "").strip()
    if not raw:
        return 0
    match = re.fullmatch(r"bytes=0-(\d+)", raw)
    if not match:
        raise RuntimeError("Unexpected upload Range response")
    offset = int(match.group(1)) + 1
    if offset < 0 or offset > total:
        raise RuntimeError("Invalid Drive upload offset")
    return offset


def status_query(location: str, total: int, timeout: int):
    # For Google Drive's interrupted upload recovery:
    # PUT Content-Range: bytes */TOTAL, Content-Length: 0
    req = request.Request(location, data=b'', method='PUT', headers={
        'Content-Range': 'bytes */' + str(total), 'Content-Length': '0',
    })
    status, headers, body = resumable_response(req, timeout)
    if status == 308:
        return received_offset(headers, total), None
    if status in (200, 201):
        obj = json.loads(body.decode('utf-8'))
        if not isinstance(obj, dict) or not obj.get('id'):
            raise RuntimeError("Drive completed, but no file ID was returned")
        return total, obj
    raise RuntimeError('Unexpected Drive session status: HTTP ' + str(status))


def recover_status(location: str, total: int, timeout: int, retries: int = 5):
    for attempt in range(retries):
        try:
            return status_query(location, total, min(timeout, 90))
        except UploadSessionExpired:
            raise
        except error.HTTPError as exc:
            if exc.code not in RETRY_HTTP:
                raise
        except (error.URLError, TimeoutError, ConnectionError, socket.timeout, http.client.RemoteDisconnected, ssl.SSLError):
            pass
        if attempt < retries - 1:
            time.sleep(min(12, 2 * (2 ** attempt)))
    raise RuntimeError("Cannot determine Drive upload offset after retries; saved session for next run")


def upload_chunk(location: str, data: bytes, start: int, total: int, mime: str, timeout: int):
    end = start + len(data) - 1
    req = request.Request(location, data=data, method="PUT", headers={
        "Content-Type": mime,
        "Content-Range": f"bytes {start}-{end}/{total}",
        "Content-Length": str(len(data)),
    })
    status, headers, body = resumable_response(req, timeout)
    if status == 308:
        return received_offset(headers, total), None
    if status in (200, 201):
        if end + 1 != total:
            raise RuntimeError("Drive completed before last file chunk")
        obj = json.loads(body.decode('utf-8'))
        if not isinstance(obj, dict) or not obj.get('id'):
            raise RuntimeError("Drive completion did not return a file ID")
        return total, obj
    raise RuntimeError("Unexpected Drive chunk HTTP " + str(status))


def put_chunks(location: str, local: Path, mime: str, chunk: int, timeout: int,
               resume_existing: bool) -> dict:
    total = local.stat().st_size
    offset = 0
    if resume_existing:
        offset, completed = recover_status(location, total, timeout)
        if completed:
            return completed
        print('  RESUME: Google Drive acknowledged %d/%d bytes' % (offset, total))
    retries = 0
    active_chunk = chunk
    with local.open('rb') as fp:
        while offset < total:
            fp.seek(offset)
            data = fp.read(min(active_chunk, total - offset))
            if not data:
                raise RuntimeError("Source file truncated during upload")
            try:
                next_offset, completed = upload_chunk(location, data, offset, total, mime, timeout)
            except UploadSessionExpired:
                raise
            except Exception as exc:
                transient = isinstance(exc, (error.URLError, TimeoutError, ConnectionError,
                                            socket.timeout, http.client.RemoteDisconnected, ssl.SSLError))
                if isinstance(exc, error.HTTPError):
                    transient = exc.code in RETRY_HTTP
                if not transient:
                    raise
                retries += 1
                active_chunk = max(256 * 1024, active_chunk // 2)
                print("  NETWORK RETRY %d/8: querying received bytes; next chunk=%d KiB" %
                      (retries, active_chunk // 1024))
                # Never blindly repeat a timed-out chunk. Ask the existing session first.
                next_offset, completed = recover_status(location, total, timeout)
                if completed:
                    return completed
                if retries >= 8:
                    raise RuntimeError("Too many upload interruptions; saved session for next run") from exc
                time.sleep(min(12, 1.5 * (2 ** min(retries, 4))))
            if completed:
                return completed
            if next_offset < offset or next_offset > total:
                raise RuntimeError("Drive acknowledged invalid byte offset")
            if next_offset == offset:
                if retries == 0:
                    retries = 1
                if retries >= 8:
                    raise RuntimeError("No upload progress after retries; saved session")
                time.sleep(min(12, 1.5 * (2 ** min(retries, 4))))
            else:
                offset = next_offset
                retries = 0
                print("  PROGRESS: %d/%d bytes (%.1f%%)" % (offset, total, 100 * offset / total))
    # A 308 Range that reaches total is unexpected; query completion rather than re-POST.
    _, completed = recover_status(location, total, timeout)
    if completed:
        return completed
    raise RuntimeError("Drive has all bytes but has not finalized; saved session for next run")


def upload_one(drive: GoogleReader, folder_id: str, local: Path,
               kind: str, report: Path, chunk: int, timeout: int) -> tuple[dict, Path]:
    mime = 'application/json' if kind == 'lyrics' else MIME_AUDIO[local.suffix.lower()]
    sp = state_path(report, kind, local, folder_id)
    location = load_session(sp, local, folder_id)
    is_resume = location is not None
    if not location:
        location = create_session(drive, folder_id, local, mime)
        stat = local.stat()
        save_session(sp, {
            'file': str(local.resolve()), 'folder_id': folder_id,
            'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
            'location': location, 'utc': stamp(),
        })
    try:
        return put_chunks(location, local, mime, chunk, timeout, is_resume), sp
    except UploadSessionExpired:
        # An expired session might already have committed the last chunk.
        # Check exact destination name before starting any replacement session.
        exact = [o for o in drive.list_files(folder_id, local.name)
                 if o.get('name') == local.name and o.get('mimeType') != FOLDER_MIME]
        if len(exact) == 1 and remote_content_equal(drive, exact[0], local, require_md5=True):
            return exact[0], sp
        if exact:
            raise RuntimeError('Drive filename conflict after upload session expiry')
        sp.unlink(missing_ok=True)
        location = create_session(drive, folder_id, local, mime)
        stat = local.stat()
        save_session(sp, {
            'file': str(local.resolve()), 'folder_id': folder_id,
            'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
            'location': location, 'utc': stamp(),
        })
        return put_chunks(location, local, mime, chunk, timeout, False), sp


def choose_files(root: Path, single_id: str | None) -> tuple[dict[str, list[Path]], dict]:
    result: dict[str, list[Path]] = {"audio": [], "lyrics": []}
    if single_id:
        if not ID_RE.fullmatch(single_id):
            raise RuntimeError("Invalid Zing ID")
        source = root / "ZING_AUDIO" / ("zing_acapella_" + single_id + ".ogg")
        if not source.is_file():
            raise RuntimeError("Cannot find expected ZING_AUDIO file: " + str(source))
        return {"audio": [source], "lyrics": []}, {"invalid": [], "missing": []}

    found, diag = find_local_files(root)
    if diag["folders_missing"]:
        raise RuntimeError("Local source folder missing: " + ", ".join(diag["folders_missing"]))
    issues = []
    for kind in ("audio", "lyrics"):
        for name, places in found[kind].items():
            if len(places) != 1:
                issues.append("Duplicate local filename " + name)
                continue
            p = Path(places[0][0])
            if kind == "lyrics":
                permitted = ZING_JSON.fullmatch(name) if p.parent.name == "ZING_JSON" else YOUTUBE_JSON.fullmatch(name)
                if not permitted:
                    issues.append("Skipped unrecognized JSON filename " + name)
                    continue
            result[kind].append(p)
        result[kind].sort(key=lambda p: p.name.casefold())
    return result, {"invalid": diag["invalid_json"],
                    "unrecognized_audio": diag["unrecognized_audio"],
                    "issues": issues, "missing": diag["folders_missing"]}


def acquire_lock(report_dir: Path):
    """Exclusive OS-level Windows file lock (automatically released on process exit)."""
    p = report_dir / LOCK_FILE
    fp = p.open("a+b")
    if os.name == "nt":
        import msvcrt
        fp.seek(0)
        if fp.read(1) == b"":
            fp.write(b"0")
            fp.flush()
        fp.seek(0)
        try:
            msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            fp.close()
            raise RuntimeError("Another AI Drive sync is currently running")
    else:
        import fcntl
        try:
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fp.close()
            raise RuntimeError("Another AI Drive sync is currently running")
    return fp


def sync(args: argparse.Namespace) -> int:
    root = Path(args.source)
    if not root.is_dir():
        raise RuntimeError("Source folder missing: " + str(root))
    report = Path(args.report) if args.report else root / "Reports" / "Drive_AutoSync"
    report.mkdir(parents=True, exist_ok=True)
    lock = acquire_lock(report)
    try:
        return sync_locked(args, root, report)
    finally:
        lock.close()


def sync_locked(args: argparse.Namespace, root: Path, report: Path) -> int:
    files, diagnostics = choose_files(root, args.single_id)
    token = Path(args.token) if args.token else next((Path(x) for x in TOKEN_DEFAULTS if Path(x).is_file()), None)
    if token is None or not token.is_file():
        raise RuntimeError("OAuth drive_token.json missing. Provide -TokenFile to PowerShell wrapper")
    print("===== TUNERTOOLS AI DRIVE SYNC =====")
    print("MODE:", "APPLY / CREATE ONLY" if args.apply else "PREVIEW / READ ONLY")
    print("SOURCE:", root)
    print("DRIVE: TunerTools_AppBackup/AI_Music/{stream_cache,lyrics} ONLY")
    print("TOKEN: found, never printed")
    print("UTC:", stamp())
    print("UPLOAD: chunk=%d KiB, timeout=%ds, resumes interrupted sessions" %
          (args.chunk_kib, args.put_timeout))
    if diagnostics.get("issues"):
        print("LOCAL WARNINGS:", len(diagnostics["issues"]))
        for issue in diagnostics["issues"][:10]:
            print("  -", issue)
    if diagnostics.get("invalid"):
        print("INVALID JSON (NOT UPLOADED):", len(diagnostics["invalid"]))
    if diagnostics.get("unrecognized_audio"):
        print("UNRECOGNIZED AUDIO (NOT UPLOADED):", len(diagnostics["unrecognized_audio"]))

    drive = GoogleReader(token)
    root_id = drive.folder("root", "TunerTools_AppBackup")
    ai_id = drive.folder(root_id, "AI_Music")
    ids = {
        "audio": drive.folder(ai_id, "stream_cache"),
        "lyrics": drive.folder(ai_id, "lyrics"),
    }
    remote = {
        "audio": remote_by_name(drive.list_files(ids["audio"]), AUDIO_EXTS),
        "lyrics": remote_by_name(drive.list_files(ids["lyrics"]), {".json"}),
    }
    print("DRIVE AUDIO FILENAMES:", len(remote["audio"]))
    print("DRIVE JSON FILENAMES:", len(remote["lyrics"]))
    pending: list[tuple[str, Path]] = []
    existing = 0
    conflicts: list[dict] = []
    unstable = []
    for kind in ("audio", "lyrics"):
        for path in files[kind]:
            matches = remote[kind].get(path.name, [])
            if len(matches) > 1:
                conflicts.append({"file": path.name, "reason": "Multiple Drive files with same name"})
                continue
            if len(matches) == 1:
                try:
                    if remote_content_equal(drive, matches[0], path, require_md5=bool(args.single_id)):
                        existing += 1
                        if args.apply:
                            state_path(report, kind, path, ids[kind]).unlink(missing_ok=True)
                    else:
                        conflicts.append({"file": path.name, "reason": "Different file size; no overwrite"})
                except Exception as exc:
                    conflicts.append({"file": path.name, "reason": short_error(exc)})
                continue
            try:
                check_stable(path, args.min_age)
            except Exception as exc:
                unstable.append({"file": path.name, "reason": short_error(exc)})
                continue
            pending.append((kind, path))
    print("LOCAL AUDIO:", len(files["audio"]), "LOCAL JSON:", len(files["lyrics"]))
    print("PRESENT:", existing, "MISSING NEW:", len(pending),
          "CONFLICT:", len(conflicts), "NOT_READY:", len(unstable))
    for kind, path in pending[:12]:
        print("  TO UPLOAD:", kind.upper(), path.name)
    for c in conflicts[:8]:
        print("  CONFLICT:", c["file"], c["reason"])
    for c in unstable[:8]:
        print("  WAIT:", c["file"], c["reason"])
    result = {
        "utc": stamp(), "apply": args.apply,
        "source": str(root), "target": "AI_Music/{stream_cache,lyrics}",
        "local_audio": len(files["audio"]), "local_lyrics": len(files["lyrics"]),
        "drive_audio": len(remote["audio"]), "drive_lyrics": len(remote["lyrics"]),
        "existing": existing, "pending": len(pending),
        "conflicts": conflicts, "unstable": unstable,
        "created": [], "failed": [], "remaining": [],
    }
    if not args.apply:
        print("PREVIEW: No files uploaded. Run again with -Apply to create missing files.")
        result_path = report / "AI_DRIVE_SYNC_LAST_PREVIEW.json"
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print("REPORT:", result_path)
        return 0 if not conflicts else 2

    for idx, (kind, path) in enumerate(pending[:args.max_files], start=1):
        print("[%d/%d] %s" % (idx, min(len(pending), args.max_files), path.name))
        try:
            size, mtime = check_stable(path, args.min_age)
            # Re-read the exact destination name immediately before create.
            exact = [x for x in drive.list_files(ids[kind], path.name)
                     if x.get("name") == path.name and x.get("mimeType") != FOLDER_MIME]
            if exact:
                if len(exact) == 1 and remote_content_equal(drive, exact[0], path, require_md5=True):
                    print("  SKIP: Already uploaded by another run")
                    state_path(report, kind, path, ids[kind]).unlink(missing_ok=True)
                    continue
                raise RuntimeError("Existing Drive name conflicts; refusing overwrite")
            created_obj = None
            post_exception = None
            try:
                created_obj, finished_session_path = upload_one(drive, ids[kind], path, kind, report,
                                                            args.chunk_kib * 1024, args.put_timeout)
            except Exception as exc:
                post_exception = exc
            # Do not re-POST after ambiguous errors. Verify remote by live listing.
            confirmed = None
            for attempt in range(4):
                time.sleep(1.0 + attempt * 1.2)
                exact = [x for x in drive.list_files(ids[kind], path.name)
                         if x.get("name") == path.name and x.get("mimeType") != FOLDER_MIME]
                if len(exact) == 1:
                    confirmed = exact[0]
                    break
                if len(exact) > 1:
                    raise RuntimeError("Duplicate Drive filename after upload; manual review needed")
            if confirmed is None:
                if post_exception:
                    raise RuntimeError("Upload status unresolved: " + short_error(post_exception))
                raise RuntimeError("Drive file was not visible after upload")
            if post_exception is not None:
                print("  NOTICE: Upload response was interrupted; Drive shows the file now")
            stat = path.stat()
            if stat.st_size != size or stat.st_mtime_ns != mtime:
                raise RuntimeError("Source file changed during upload; manual validation needed")
            if not remote_content_equal(drive, confirmed, path, require_md5=True):
                raise RuntimeError("Drive size mismatch after upload")
            result["created"].append({"kind": kind, "file": path.name,
                                     "bytes": size, "drive_id": str(confirmed.get("id"))})
            finished_session_path.unlink(missing_ok=True)
            print("  OK: Drive size and MD5 verified")
        except Exception as exc:
            result["failed"].append({"kind": kind, "file": path.name, "error": short_error(exc)})
            print("  FAILED:", short_error(exc))
        if args.pause:
            time.sleep(args.pause)
    result["remaining"] = [p.name for _, p in pending[args.max_files:]]
    result_path = report / "AI_DRIVE_SYNC_LAST_RUN.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("===== COMPLETE =====")
    print("UPLOADED:", len(result["created"]), "FAILED:", len(result["failed"]),
          "QUEUED_FOR_NEXT_RUN:", len(result["remaining"]))
    print("REPORT:", result_path)
    print("PHP cached_songs may be stale for up to 600 seconds.")
    print("No files on Google Drive were overwritten, renamed or deleted.")
    return 1 if (result["failed"] or conflicts) else 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=SOURCE_DEFAULT)
    parser.add_argument("--token", default="")
    parser.add_argument("--report", default="")
    parser.add_argument("--single-id", default="", help="Only one Zing ID .ogg from ZING_AUDIO")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--min-age", type=int, default=60)
    parser.add_argument("--max-files", type=int, default=50)
    parser.add_argument("--pause", type=float, default=1.5)
    parser.add_argument("--chunk-kib", type=int, default=1024, help="Chunk 256/512/1024/2048/4096 KiB")
    parser.add_argument("--put-timeout", type=int, default=300, help="Per-chunk timeout seconds")
    args = parser.parse_args()
    if args.min_age < 0 or args.min_age > 86400:
        parser.error("--min-age must be 0..86400")
    if args.max_files < 1 or args.max_files > 1000:
        parser.error("--max-files must be 1..1000")
    if args.pause < 0 or args.pause > 30:
        parser.error("--pause must be 0..30")
    if args.chunk_kib not in (256, 512, 1024, 2048, 4096):
        parser.error("--chunk-kib must be 256, 512, 1024, 2048 or 4096")
    if args.put_timeout < 30 or args.put_timeout > 1800:
        parser.error("--put-timeout must be 30..1800 seconds")
    sys.stdout.reconfigure(errors="replace")
    try:
        return sync(args)
    except Exception as exc:
        print("ERROR:", short_error(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
