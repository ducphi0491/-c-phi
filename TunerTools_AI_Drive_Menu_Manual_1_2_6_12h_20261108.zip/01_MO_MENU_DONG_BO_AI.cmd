@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0MENU_DONG_BO_AI.ps1"
if errorlevel 1 (
    echo.
    echo MENU GAP LOI. Kiem tra quyen Administrator va file trong ZIP.
)
echo.
pause
