﻿param(
    [switch]$Task,
    [switch]$Preview,
    [string]$SourceDir = 'C:\TunerTools\Audio\AI_Music',
    [string]$TokenFile = '',
    [ValidateRange(1,1000)] [int]$MaxFiles = 200,
    [ValidateRange(0,86400)] [int]$MinAgeSeconds = 120,
    [ValidateSet(256,512,1024,2048,4096)] [int]$ChunkKiB = 1024,
    [ValidateRange(30,1800)] [int]$PutTimeoutSeconds = 300
)
$ErrorActionPreference = 'Stop'
$engine = Join-Path $PSScriptRoot 'SYNC_AI_DRIVE.py'
$inventory = Join-Path $PSScriptRoot 'DOI_CHIEU_AI_DRIVE.py'
if (-not (Test-Path -LiteralPath $engine -PathType Leaf)) { throw 'Missing SYNC_AI_DRIVE.py' }
if (-not (Test-Path -LiteralPath $inventory -PathType Leaf)) { throw 'Missing DOI_CHIEU_AI_DRIVE.py' }
if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) { throw "Missing AI_Music source: $SourceDir" }

# This config is generated when a schedule is installed. It is NOT required
# for manual mode, and it does not contain any Drive credentials.
$pythonCfg = Join-Path $PSScriptRoot 'python_path.txt'
if (Test-Path -LiteralPath $pythonCfg -PathType Leaf) {
    $pythonExe = (Get-Content -LiteralPath $pythonCfg -Raw -Encoding UTF8).Trim()
    if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) {
        throw "Saved Python executable not found: $pythonExe"
    }
    $prefix = @()
} elseif (Get-Command py.exe -ErrorAction SilentlyContinue) {
    $pythonExe = (Get-Command py.exe).Source
    $prefix = @('-3')
} elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
    $pythonExe = (Get-Command python.exe).Source
    $prefix = @()
} else {
    throw 'Python 3.10+ not found in PATH'
}

$report = Join-Path $SourceDir 'Reports\Drive_AutoSync'
$logDir = Join-Path $report 'TaskLogs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
# Only local logs older than 30 days are removed, never Drive files.
Get-ChildItem -LiteralPath $logDir -Filter 'Sync_*.log' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } |
    Remove-Item -Force -ErrorAction SilentlyContinue
$logFile = Join-Path $logDir ('Sync_{0}_{1}.log' -f (Get-Date -Format 'yyyyMMdd_HHmmss'), $PID)

$arguments = @($prefix) + @(
    $engine, '--source', $SourceDir,
    '--min-age', [string]$MinAgeSeconds,
    '--max-files', [string]$MaxFiles,
    '--chunk-kib', [string]$ChunkKiB,
    '--put-timeout', [string]$PutTimeoutSeconds,
    '--report', $report
)
if ($TokenFile) { $arguments += @('--token', $TokenFile) }
if (-not $Preview) { $arguments += '--apply' }
$label = if ($Preview) { 'PREVIEW ONLY' } elseif ($Task) { 'SCHEDULED UPLOAD' } else { 'MANUAL UPLOAD' }
$banner = ('[{0}] {1} - Python={2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $label, $pythonExe)
Write-Host $banner -ForegroundColor Cyan
Write-Host ('LOG: ' + $logFile)

$oldPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$env:PYTHONIOENCODING = 'utf-8:replace'
try {
    & $pythonExe @arguments 2>&1 | Tee-Object -FilePath $logFile
    $code = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $oldPreference
}
if ($code -ne 0) {
    throw "AI Drive sync failed (exit=$code). See log: $logFile"
}
Write-Host 'Sync finished without upload errors.' -ForegroundColor Green
