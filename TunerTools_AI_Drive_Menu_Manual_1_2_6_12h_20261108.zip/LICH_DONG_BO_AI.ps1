﻿param(
    [ValidateSet('Status','Set','Disable')] [string]$Action = 'Status',
    [ValidateSet(0,1,2,6,12)] [int]$Hours = 0
)
$ErrorActionPreference = 'Stop'
$taskName = 'TunerTools_AI_Drive_AutoSync'
$legacyName = 'TunerTools_AI_Drive_Sync_15Min'
$runner = Join-Path $PSScriptRoot 'CHAY_DONG_BO_AI.ps1'
$config = Join-Path $PSScriptRoot 'schedule_hours.txt'
$pythonCfg = Join-Path $PSScriptRoot 'python_path.txt'

function Find-Task([string]$name) {
    return (Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue | Select-Object -First 1)
}
function Require-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Please run menu as Administrator'
    }
}
function Find-Python {
    if (Get-Command py.exe -ErrorAction SilentlyContinue) {
        $executable = (& py.exe -3 -c 'import sys;print(sys.executable)' | Select-Object -Last 1).Trim()
    } elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
        $executable = (& python.exe -c 'import sys;print(sys.executable)' | Select-Object -Last 1).Trim()
    } else {
        throw 'Python 3.10+ not found'
    }
    if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) {
        throw 'Cannot resolve Python executable for scheduled task'
    }
    & $executable -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.10+ required' }
    return $executable
}

if ($Action -eq 'Status') {
    $task = Find-Task $taskName
    if ($null -ne $task) {
        $hoursText = '?'
        if (Test-Path -LiteralPath $config) {
            $hoursText = (Get-Content -LiteralPath $config -Raw -Encoding UTF8).Trim()
        }
        Write-Host ('LICH: DANG BAT (moi ' + $hoursText + ' gio); Status=' + $task.State) -ForegroundColor Green
        try {
            $info = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop
            if ($info.NextRunTime.Year -gt 2000) {
                Write-Host ('LAN CHAY TIEP: ' + $info.NextRunTime.ToString('yyyy-MM-dd HH:mm:ss'))
            }
        } catch { }
    } else {
        Write-Host 'LICH: DANG TAT (co the chay thu cong).' -ForegroundColor Yellow
    }
    if ($null -ne (Find-Task $legacyName)) {
        Write-Host 'CANH BAO: task 15-phut CU van ton tai! Cai lich moi hoac tat lich de go task cu.' -ForegroundColor Yellow
    }
    return
}

Require-Admin
if ($Action -eq 'Disable') {
    foreach ($name in @($taskName, $legacyName)) {
        if ($null -ne (Find-Task $name)) {
            Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction Stop
            Write-Host ('Removed old task: ' + $name)
        }
    }
    Remove-Item -LiteralPath $config -Force -ErrorAction SilentlyContinue
    Write-Host 'Lich da tat. Khong xoa bat ky file nao tren Google Drive.' -ForegroundColor Green
    return
}

if ($Action -eq 'Set') {
    if ($Hours -notin @(1,2,6,12)) { throw 'Choose 1, 2, 6 or 12 hours' }
    if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) { throw 'Missing CHAY_DONG_BO_AI.ps1' }
    $source = 'C:\TunerTools\Audio\AI_Music'
    if (-not (Test-Path -LiteralPath $source -PathType Container)) { throw "Missing source folder: $source" }
    $pythonExe = Find-Python
    # ASCII-path-safe UTF-8 text, not a secret.
    [System.IO.File]::WriteAllText($pythonCfg, $pythonExe, ([System.Text.UTF8Encoding]::new($false)))
    $taskCommand = 'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $runner + '" -Task'
    $startTime = (Get-Date).AddMinutes(2).ToString('HH:mm')
    Write-Host ('Registering task every ' + $Hours + ' hours; first window ~' + $startTime)
    & schtasks.exe /Create /F /SC HOURLY /MO ([string]$Hours) /ST $startTime /TN $taskName /TR $taskCommand /RU SYSTEM /RL HIGHEST
    if ($LASTEXITCODE -ne 0) { throw 'schtasks.exe failed; previous schedule not removed' }
    [System.IO.File]::WriteAllText($config, [string]$Hours, ([System.Text.UTF8Encoding]::new($false)))
    if ($null -ne (Find-Task $legacyName)) {
        Unregister-ScheduledTask -TaskName $legacyName -Confirm:$false -ErrorAction Stop
        Write-Host 'Removed legacy 15-minute task.' -ForegroundColor Green
    }
    Write-Host ('SUCCESS: auto sync every ' + $Hours + ' hours; runs as SYSTEM.') -ForegroundColor Green
    Write-Host 'Logs: C:\TunerTools\Audio\AI_Music\Reports\Drive_AutoSync\TaskLogs'
    Write-Host 'NOTE: SYSTEM must have read access to existing Google OAuth token file.' -ForegroundColor Yellow
    return
}
