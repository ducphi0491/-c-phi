#!/usr/bin/env python3
"""Read-only, file-by-file comparison: TunerTools Windows AI cache vs Google Drive.

Python >= 3.10, stdlib only. The only Google API methods used are GET; OAuth
refresh POST is used solely to obtain an access token in memory (never saved).
No file contents are uploaded and no Drive files are written or deleted.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from datetime import datetime, timedelta, timezone
import http.client
import json
import os
from pathlib import Path
import re
import ssl
import sys
import time
from urllib import error, parse, request

GOOGLE_FILES = "https://www.googleapis.com/drive/v3/files"
FOLDER_MIME = "application/vnd.google-apps.folder"
SOURCE_DEFAULT = r"C:\TunerTools\Audio\AI_Music"
TOKEN_DEFAULTS = (
    r"C:\TunerTools\BackupScripts\Drive_Buoc2D\drive_token.json",
    r"C:\TunerTools\BackupScripts\Drive_Buoc2C\drive_token.json",
    r"C:\TunerTools\BackupScripts\Drive_Documents\drive_token.json",
)
AUDIO_EXTS = {".ogg", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".opus", ".webm"}
ZING_AUDIO_PATTERN = re.compile(r"^zing_acapella_[A-Za-z0-9]{6,64}\.(ogg|mp3|wav|m4a|aac|flac|opus|webm)$", re.I)
YT_AUDIO_PATTERN = re.compile(r"^(acapella|beat_karaoke)_[A-Za-z0-9_-]{11}\.(ogg|mp3|wav|m4a|aac|flac|opus|webm)$", re.I)


class GoogleReader:
    def __init__(self, path: Path):
        self.data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(self.data, dict):
            raise RuntimeError("Invalid OAuth token file format")
        self.token = str(self.data.get("token") or self.data.get("access_token") or "")
        expiry_raw = str(self.data.get("expiry") or "")
        if expiry_raw:
            try:
                exp = datetime.fromisoformat(expiry_raw.replace("Z", "+00:00"))
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp < datetime.now(timezone.utc) + timedelta(minutes=2):
                    self.token = ""
            except ValueError:
                self.token = ""
        if not self.token:
            self.refresh()

    def refresh(self) -> None:
        keys = ("refresh_token", "client_id", "client_secret")
        payload = {key: self.data.get(key) for key in keys}
        if not all(payload.values()):
            raise RuntimeError("OAuth refresh credentials missing; reauthorize private token")
        payload["grant_type"] = "refresh_token"
        req = request.Request(
            "https://oauth2.googleapis.com/token",
            data=parse.urlencode(payload).encode("utf-8"),
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with request.urlopen(req, timeout=35) as resp:
            item = json.load(resp)
        self.token = str(item.get("access_token") or "")
        if not self.token:
            raise RuntimeError("OAuth refresh did not return an access token")

    def get(self, url: str) -> dict:
        last = None
        for attempt in range(5):
            req = request.Request(
                url,
                headers={"Authorization": "Bearer " + self.token, "Accept": "application/json"},
                method="GET",
            )
            try:
                with request.urlopen(req, timeout=50) as resp:
                    obj = json.load(resp)
                if not isinstance(obj, dict):
                    raise RuntimeError("Google response was not a JSON object")
                return obj
            except error.HTTPError as exc:
                last = exc
                if exc.code == 401 and attempt < 4:
                    self.refresh()
                    continue
                if exc.code not in (408, 429, 500, 502, 503, 504) or attempt == 4:
                    raise RuntimeError("Google API HTTP " + str(exc.code)) from exc
            except (error.URLError, TimeoutError, ConnectionError, http.client.RemoteDisconnected, ssl.SSLError) as exc:
                last = exc
                if attempt == 4:
                    raise RuntimeError("Cannot read Google Drive after retries: " + type(exc).__name__) from exc
            time.sleep(min(12, 0.8 * (2 ** attempt)))
        raise RuntimeError("Google Drive request failed: " + type(last).__name__)

    def list_files(self, parent_id: str, name: str | None = None) -> list[dict]:
        quoted = parent_id.replace("\\", "\\\\").replace("'", "\\'")
        q = "'" + quoted + "' in parents and trashed = false"
        if name is not None:
            escaped = name.replace("\\", "\\\\").replace("'", "\\'")
            q += " and name = '" + escaped + "'"
        result = []
        page_token = None
        for page in range(100):
            params = {"q": q, "pageSize": 1000, "spaces": "drive", "fields": "nextPageToken,files(id,name,mimeType,size)"}
            if page_token:
                params["pageToken"] = page_token
            obj = self.get(GOOGLE_FILES + "?" + parse.urlencode(params))
            items = obj.get("files")
            if not isinstance(items, list):
                raise RuntimeError("Google Drive did not return files array")
            result.extend(x for x in items if isinstance(x, dict))
            token = obj.get("nextPageToken")
            if not token:
                return result
            if token == page_token:
                raise RuntimeError("Google Drive page token did not advance")
            page_token = token
        raise RuntimeError("Google Drive paging exceeded 100 pages")

    def folder(self, parent_id: str, name: str) -> str:
        found = [x for x in self.list_files(parent_id, name)
                 if x.get("mimeType") == FOLDER_MIME and x.get("name") == name]
        if len(found) != 1:
            raise RuntimeError("Folder '%s' ambiguous or missing under '%s' (count=%d)" % (name, parent_id, len(found)))
        return str(found[0]["id"])


def report_csv(path: Path, header: tuple[str, ...], rows: list[tuple]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(header)
        writer.writerows(rows)


def valid_json(path: Path) -> bool:
    try:
        size = path.stat().st_size
        if not 0 < size <= 2 * 1024 * 1024:
            return False
        obj = json.loads(path.read_text(encoding="utf-8-sig"))
        return isinstance(obj, (list, dict))
    except (OSError, ValueError, UnicodeError):
        return False


def find_local_files(root: Path) -> tuple[dict, dict]:
    """Returns bucket -> {name: [(path, bytes), ...]}, plus scan diagnostics."""
    items = {"audio": defaultdict(list), "lyrics": defaultdict(list)}
    details = {"folders_missing": [], "unrecognized_audio": [], "invalid_json": [],
               "all_audio_source_files": 0, "all_json_source_files": 0,
               "ignored_other_json": 0}
    zing_audio = root / "ZING_AUDIO"
    youtube = root / "YOUTUBE_CACHE"
    zing_json = root / "ZING_JSON"
    for folder in (zing_audio, youtube, zing_json):
        if not folder.is_dir():
            details["folders_missing"].append(str(folder))
    for folder in (zing_audio, youtube):
        if not folder.is_dir():
            continue
        for p in folder.iterdir():
            if not p.is_file() or p.suffix.lower() not in AUDIO_EXTS:
                continue
            details["all_audio_source_files"] += 1
            pattern = ZING_AUDIO_PATTERN if folder == zing_audio else YT_AUDIO_PATTERN
            if not pattern.fullmatch(p.name):
                details["unrecognized_audio"].append((str(p), p.stat().st_size))
                continue
            items["audio"][p.name].append((str(p), p.stat().st_size))
    for folder in (zing_json, youtube):
        if not folder.is_dir():
            continue
        for p in folder.iterdir():
            if not p.is_file() or p.suffix.lower() != ".json":
                continue
            if folder == youtube and not p.name.startswith(("lyrics_", "meta_")):
                details["ignored_other_json"] += 1
                continue
            details["all_json_source_files"] += 1
            if not valid_json(p):
                details["invalid_json"].append((str(p), p.stat().st_size))
                continue
            items["lyrics"][p.name].append((str(p), p.stat().st_size))
    return items, details


def compare(bucket: str, local: dict, remote_raw: list[dict], out: Path) -> dict:
    remote = defaultdict(list)
    other = []
    for x in remote_raw:
        name = x.get("name")
        if not isinstance(name, str):
            continue
        if x.get("mimeType") == FOLDER_MIME:
            continue
        ext = Path(name).suffix.lower()
        if (bucket == "audio" and ext not in AUDIO_EXTS) or (bucket == "lyrics" and ext != ".json"):
            other.append(name)
            continue
        raw_size = x.get("size")
        try:
            size = int(raw_size) if raw_size is not None else None
        except (ValueError, TypeError):
            size = None
        remote[name].append((str(x.get("id") or ""), size))
    local_names = set(local)
    remote_names = set(remote)
    missing = sorted(local_names - remote_names, key=str.casefold)
    extra = sorted(remote_names - local_names, key=str.casefold)
    duplicate_local = [(name, len(v)) for name, v in local.items() if len(v) > 1]
    duplicate_remote = [(name, len(v)) for name, v in remote.items() if len(v) > 1]
    different = []
    for name in sorted(local_names & remote_names, key=str.casefold):
        if len(local[name]) != 1 or len(remote[name]) != 1:
            continue  # Duplicated names need human review; compare would be misleading.
        local_size = local[name][0][1]
        remote_size = remote[name][0][1]
        if remote_size is not None and local_size != remote_size:
            different.append((name, local_size, remote_size, local[name][0][0]))
    case_only = []
    case_remote = defaultdict(list)
    for name in remote_names:
        case_remote[name.casefold()].append(name)
    for name in missing:
        for match in case_remote.get(name.casefold(), []):
            if match != name:
                case_only.append((name, match))
    report_csv(out / (bucket + "_missing_on_drive.csv"), ("filename", "local_path", "size_bytes"),
               [(n, local[n][0][0], local[n][0][1]) for n in missing])
    report_csv(out / (bucket + "_only_on_drive.csv"), ("filename", "drive_id", "size_bytes"),
               [(n, remote[n][0][0], remote[n][0][1]) for n in extra])
    report_csv(out / (bucket + "_size_different.csv"), ("filename", "local_size_bytes", "drive_size_bytes", "local_path"), different)
    report_csv(out / (bucket + "_duplicate_local.csv"), ("filename", "copies"), sorted(duplicate_local))
    report_csv(out / (bucket + "_duplicate_drive.csv"), ("filename", "copies"), sorted(duplicate_remote))
    report_csv(out / (bucket + "_case_different.csv"), ("local_filename", "drive_filename"), case_only)
    return {
        "local_file_count": sum(map(len, local.values())),
        "local_unique_filenames": len(local),
        "drive_file_count": sum(map(len, remote.values())),
        "drive_unique_filenames": len(remote),
        "same_filename": len(local_names & remote_names),
        "missing_on_drive": len(missing),
        "only_on_drive": len(extra),
        "size_different": len(different),
        "duplicate_local_filenames": len(duplicate_local),
        "duplicate_drive_filenames": len(duplicate_remote),
        "case_only_difference": len(case_only),
        "other_files_in_drive_folder": len(other),
        "first_missing": missing[:8],
        "first_only_on_drive": extra[:8],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only TunerTools AI Drive inventory audit")
    parser.add_argument("--source", default=SOURCE_DEFAULT, help="Local C:/.../AI_Music directory")
    parser.add_argument("--token", default="", help="Path to private drive_token.json")
    parser.add_argument("--report", default="", help="Folder for audit CSV/JSON output")
    args = parser.parse_args()
    root = Path(args.source)
    if not root.is_dir():
        parser.error("Source folder not found: " + str(root))
    local, info = find_local_files(root)
    output = Path(args.report) if args.report else root / "Reports" / "Drive_Audit"
    output.mkdir(parents=True, exist_ok=True)
    selected = Path(args.token) if args.token else next((Path(p) for p in TOKEN_DEFAULTS if Path(p).is_file()), None)
    if not selected or not selected.is_file():
        parser.error("Private drive_token.json not found; pass --token path")
    print("MODE: READ ONLY - NO DRIVE UPLOAD / DELETE / UPDATE")
    print("LOCAL SOURCE:", str(root))
    print("TOKEN FILE: Found (content never printed)")
    print("Scanning Drive folders...")
    reader = GoogleReader(selected)
    folder = reader.folder("root", "TunerTools_AppBackup")
    ai_id = reader.folder(folder, "AI_Music")
    audio_id = reader.folder(ai_id, "stream_cache")
    lyrics_id = reader.folder(ai_id, "lyrics")
    remote_audio = reader.list_files(audio_id)
    remote_lyrics = reader.list_files(lyrics_id)
    print("Drive stream_cache entries:", len(remote_audio))
    print("Drive lyrics entries:", len(remote_lyrics))
    audio_summary = compare("audio", local["audio"], remote_audio, output)
    lyrics_summary = compare("lyrics", local["lyrics"], remote_lyrics, output)
    report_csv(output / "unrecognized_audio.csv", ("local_path", "size_bytes"), info["unrecognized_audio"])
    report_csv(output / "invalid_json.csv", ("local_path", "size_bytes"), info["invalid_json"])
    complete = not info["folders_missing"]
    summary = {
        "date_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "mode": "read_only",
        "local_root": str(root),
        "drive_root": "My Drive/TunerTools_AppBackup/AI_Music",
        "local_folders_complete": complete,
        "local_scan": info,
        "audio": audio_summary,
        "lyrics": lyrics_summary,
    }
    (output / "SUMMARY.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n" + "=" * 75)
    for name, entry in (("AUDIO", audio_summary), ("LYRICS JSON", lyrics_summary)):
        print(name)
        print("  LOCAL:", entry["local_file_count"], "files /", entry["local_unique_filenames"], "unique names")
        print("  DRIVE:", entry["drive_file_count"], "files /", entry["drive_unique_filenames"], "unique names")
        print("  SAME FILENAMES:", entry["same_filename"])
        print("  MISSING ON DRIVE:", entry["missing_on_drive"])
        print("  ONLY ON DRIVE:", entry["only_on_drive"])
        print("  SIZE DIFFERENT:", entry["size_different"])
        print("  DUPLICATE NAMES (LOCAL / DRIVE):", entry["duplicate_local_filenames"], "/", entry["duplicate_drive_filenames"])
        print("  EXAMPLE MISSING:", entry["first_missing"][:3])
    if info["folders_missing"]:
        print("WARNING: MISSING LOCAL SOURCE FOLDERS:", ", ".join(info["folders_missing"]))
        print("  Counts are incomplete until folders are restored / correct --source used.")
    if info["unrecognized_audio"]:
        print("WARNING: Unrecognized local audio filenames:", len(info["unrecognized_audio"]))
    if info["invalid_json"]:
        print("WARNING: Invalid/too-large JSON:", len(info["invalid_json"]))
    print("REPORT:", str(output))
    print("DETAILS: audio_missing_on_drive.csv and lyrics_missing_on_drive.csv")
    print("NOTICE: A matched filename + file size is not a content hash verification.")
    print("NOTICE: This compares live Drive API files, not the 600-second Alwaysdata catalog cache.")
    return 0 if complete else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted: no Drive changes were made.", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        print("ERROR:", type(exc).__name__ + ":", str(exc), file=sys.stderr)
        raise SystemExit(1)
