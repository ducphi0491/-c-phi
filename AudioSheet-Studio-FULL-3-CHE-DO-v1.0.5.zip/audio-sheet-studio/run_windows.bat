@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PROJECT_PYTHON=%CD%\.venv\Scripts\python.exe"
set "AI_REPAIRED=0"

echo ================================================
echo  AudioSheet Studio 1.0.5 - Windows Start
echo ================================================
echo.

if not exist "%PROJECT_PYTHON%" (
  echo [SETUP] The Python environment is missing. Installing dependencies...
  call "%~dp0install_windows.bat"
  if errorlevel 1 goto :failure
)

rem resampy used by Basic Pitch still imports pkg_resources.
rem setuptools 82 and above removed it, so repair older environments once.
"%PROJECT_PYTHON%" -c "import pkg_resources" >nul 2>&1
if errorlevel 1 (
  echo [FIX] Repairing missing pkg_resources without reinstalling TensorFlow...
  "%PROJECT_PYTHON%" -m pip install --disable-pip-version-check --no-input "setuptools==80.9.0"
  if errorlevel 1 goto :failure
  "%PROJECT_PYTHON%" -c "import pkg_resources" >nul 2>&1
  if errorlevel 1 goto :failure
  set "AI_REPAIRED=1"
)

rem Check that critical imports work, not just that packages are installed.
echo.
echo [CHECK] Checking installed components...
"%PROJECT_PYTHON%" "scripts\check_install.py"
if errorlevel 1 goto :failure

rem After a repair, verify the actual AI model once before opening the site.
if "%AI_REPAIRED%"=="1" (
  echo.
  echo [CHECK] Running a one-time AI model test after repair...
  "%PROJECT_PYTHON%" "scripts\diagnose_ai.py"
  if errorlevel 1 (
    echo.
    echo [ERROR] The model test failed. See data\ai_diagnostics.txt
    goto :failure
  )
)

echo.
echo [OK] Starting website at http://127.0.0.1:8000
echo Keep this window open while using the website.
echo.
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://127.0.0.1:8000"
"%PROJECT_PYTHON%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
set "APP_EXIT=%ERRORLEVEL%"
echo.
echo The website has stopped. Exit code: %APP_EXIT%
pause
exit /b %APP_EXIT%

:failure
echo.
echo [ERROR] Could not start AudioSheet Studio.
echo If the error continues, run:
echo   .venv\Scripts\python.exe scripts\diagnose_ai.py
echo and open data\ai_diagnostics.txt for details.
pause
exit /b 1
