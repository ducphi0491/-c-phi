/* AudioSheet Studio - local Web Audio piano-like synthesizer.
 * No SoundFont download, external CDN, or extra Windows installation needed.
 * Three arrangements come from /api/jobs/{id}/playback; this file only plays them.
 */
(() => {
  'use strict';

  class AudioSheetPianoPlayer {
    constructor(callbacks = {}) {
      this.callbacks = callbacks;
      this.audioContext = null;
      this.master = null;
      this.notes = [];
      this.duration = 0;
      this.position = 0;
      this.isPlaying = false;
      this.timer = null;
      this.frame = null;
      this.nextIndex = 0;
      this.voices = [];
      this.voiceByPitch = new Map();
      this.mode = 'light';
      this.volume = 0.65;
    }

    setNotes(notes, duration, mode = 'light') {
      this.stop();
      this.notes = Array.isArray(notes) ? notes.filter(note =>
        Number.isFinite(note.start) && Number.isFinite(note.end) &&
        Number.isInteger(note.pitch) && note.end > note.start
      ).sort((a, b) => a.start - b.start || b.pitch - a.pitch) : [];
      this.duration = Math.max(0, Number(duration) || 0,
        this.notes.length ? this.notes[this.notes.length - 1].end : 0);
      this.mode = mode;
      this.position = 0;
      this._emit();
    }

    setVolume(value) {
      this.volume = Math.max(0, Math.min(1, Number(value) || 0));
      if (this.master && this.audioContext) {
        const now = this.audioContext.currentTime;
        this.master.gain.setTargetAtTime(this.volume * 0.55, now, 0.02);
      }
    }

    async _prepare() {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) throw new Error('Trinh duyet khong ho tro Web Audio API.');
      if (!this.audioContext) {
        this.audioContext = new AudioContext();
        this.master = this.audioContext.createGain();
        this.master.gain.value = this.volume * 0.55;
        const compressor = this.audioContext.createDynamicsCompressor();
        compressor.threshold.value = -19;
        compressor.knee.value = 24;
        compressor.ratio.value = 5;
        compressor.attack.value = 0.005;
        compressor.release.value = 0.20;
        this.master.connect(compressor);
        compressor.connect(this.audioContext.destination);
      }
      await this.audioContext.resume();
    }

    _indexAt(time) {
      let low = 0;
      let high = this.notes.length;
      while (low < high) {
        const mid = (low + high) >>> 1;
        if (this.notes[mid].start < time) low = mid + 1;
        else high = mid;
      }
      return low;
    }

    _emit() {
      if (this.callbacks.onUpdate) {
        this.callbacks.onUpdate({
          time: this.currentTime(), duration: this.duration,
          playing: this.isPlaying, mode: this.mode,
        });
      }
    }

    currentTime() {
      if (this.isPlaying && this.audioContext) {
        return Math.min(this.duration, this.position + this.audioContext.currentTime - this.ctxStart);
      }
      return this.position;
    }

    async play() {
      if (this.isPlaying) return;
      if (!this.notes.length) throw new Error('Khong co not nhac de phat.');
      await this._prepare(); // user click unlocks browser audio
      if (this.position >= this.duration - 0.02) this.position = 0;
      this.ctxStart = this.audioContext.currentTime;
      this.nextIndex = this._indexAt(this.position - 0.000001);
      this.isPlaying = true;
      this.timer = window.setInterval(() => this._schedule(), 55);
      this._schedule();
      this._tick();
      this._emit();
    }

    _tick() {
      if (!this.isPlaying) return;
      if (this.currentTime() >= this.duration) {
        this.stop();
        return;
      }
      this._emit();
      this.frame = window.requestAnimationFrame(() => this._tick());
    }

    _schedule() {
      if (!this.isPlaying || !this.audioContext) return;
      const playedUntil = this.currentTime() + 0.23;
      const now = this.audioContext.currentTime;
      this.voices = this.voices.filter(voice => voice.until > now);
      while (this.nextIndex < this.notes.length) {
        const note = this.notes[this.nextIndex];
        if (note.start > playedUntil) break;
        this.nextIndex++;
        // At most 20 simultaneous tones to avoid clipping/stuttering.
        const scheduledAt = this.ctxStart + note.start - this.position;
        if (scheduledAt < now - 0.035) continue;
        if (this.voices.filter(v => v.until > scheduledAt).length >= 20) continue;
        this._playNote(note, Math.max(now, scheduledAt));
      }
    }

    _playNote(note, startAt) {
      const context = this.audioContext;
      const hz = 440 * Math.pow(2, (note.pitch - 69) / 12);
      const duration = Math.max(0.08, Math.min(5, note.end - note.start));
      const stopAt = startAt + duration + 0.13;
      const velocity = Math.max(0.15, Math.min(1, Number(note.velocity || 64) / 127));
      const modeGain = this.mode === 'full' ? 0.31 : this.mode === 'light' ? 0.62 : 0.72;
      const noteGain = modeGain * 0.12 * velocity * velocity;

      const envelope = context.createGain();
      envelope.gain.setValueAtTime(0.0001, startAt);
      envelope.gain.exponentialRampToValueAtTime(Math.max(0.0002, noteGain), startAt + 0.009);
      envelope.gain.exponentialRampToValueAtTime(Math.max(0.0001, noteGain * 0.52), startAt + 0.090);
      envelope.gain.exponentialRampToValueAtTime(Math.max(0.0001, noteGain * 0.19), startAt + duration);
      envelope.gain.exponentialRampToValueAtTime(0.0001, stopAt - 0.014);
      envelope.connect(this.master);

      // Inharmonic partials with a fast transient: lightweight piano-like tone.
      // Synthesized directly on device; not a sampled concert grand.
      const harmonics = [
        ['triangle', 1, 0.83], ['sine', 2.003, 0.18], ['sine', 3.008, 0.08],
      ];
      const oscillators = [];
      for (const [type, harmonic, strength] of harmonics) {
        if (hz * harmonic > context.sampleRate * 0.44) continue;
        const oscillator = context.createOscillator();
        oscillator.type = type;
        oscillator.frequency.setValueAtTime(hz * harmonic, startAt);
        const partial = context.createGain();
        partial.gain.value = strength;
        oscillator.connect(partial);
        partial.connect(envelope);
        oscillator.start(startAt);
        oscillator.stop(stopAt);
        oscillators.push(oscillator);
      }

      // Avoid doubling sustained notes of identical pitch in rapid passages.
      const previous = this.voiceByPitch.get(note.pitch);
      if (previous && previous.until > startAt + 0.012) {
        previous.until = Math.min(previous.until, startAt + 0.025);
        try {
          previous.envelope.gain.cancelScheduledValues(startAt);
          previous.envelope.gain.setValueAtTime(0.0001, startAt + 0.012);
          for (const oscillator of previous.oscillators) oscillator.stop(startAt + 0.025);
        } catch (_) { /* old scheduled voice already ended */ }
      }
      const voice = { until: stopAt, pitch: note.pitch, oscillators, envelope };
      this.voices.push(voice);
      this.voiceByPitch.set(note.pitch, voice);
    }

    _silence() {
      if (!this.audioContext) return;
      const at = this.audioContext.currentTime;
      for (const voice of this.voices) {
        try {
          voice.envelope.gain.cancelScheduledValues(at);
          voice.envelope.gain.setValueAtTime(0.0001, at);
          for (const oscillator of voice.oscillators) oscillator.stop(at + 0.005);
        } catch (_) { /* Voice already stopped */ }
      }
      this.voices = [];
      this.voiceByPitch.clear();
    }

    _halt() {
      if (this.timer !== null) window.clearInterval(this.timer);
      if (this.frame !== null) window.cancelAnimationFrame(this.frame);
      this.timer = null;
      this.frame = null;
      this.isPlaying = false;
      this._silence();
    }

    pause() {
      if (!this.isPlaying) return;
      this.position = this.currentTime();
      this._halt();
      this._emit();
    }

    stop() {
      this._halt();
      this.position = 0;
      this.nextIndex = 0;
      this._emit();
    }

    async seek(time) {
      const wasPlaying = this.isPlaying;
      this._halt();
      this.position = Math.max(0, Math.min(this.duration, Number(time) || 0));
      this._emit();
      if (wasPlaying) await this.play();
    }
  }

  window.AudioSheetPianoPlayer = AudioSheetPianoPlayer;
})();
