from __future__ import annotations

import importlib.util
import mimetypes
import platform
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .audio_tools import command_exists
from .config import settings
from .demo_score import create_demo_musicxml
from .job_store import JobNotFoundError, job_store
from .processor import submit_job
from .security import validate_audio_filename, validate_youtube_url


app = FastAPI(
    title="AudioSheet Studio",
    version="1.0.0",
    description="Local-first audio-to-MIDI and MusicXML transcription web app.",
)
app.mount("/static", StaticFiles(directory=settings.web_dir), name="static")


async def _save_upload(upload: UploadFile, destination: Path, limit_bytes: int) -> int:
    total = 0
    try:
        with destination.open("wb") as handle:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit_bytes:
                    raise ValueError(
                        f"Upload is larger than the configured {settings.max_upload_mb} MB limit"
                    )
                handle.write(chunk)
    finally:
        await upload.close()
    if total == 0:
        raise ValueError("The uploaded file is empty")
    return total


def _get_public_job(job_id: str) -> dict:
    try:
        return job_store.public(job_store.get(job_id))
    except JobNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Job not found") from exc


@app.get("/api/health")
def health() -> dict:
    return {
        "status": "ok",
        "python": platform.python_version(),
        "ffmpeg": command_exists("ffmpeg") and command_exists("ffprobe"),
        "basic_pitch": importlib.util.find_spec("basic_pitch") is not None,
        "music21": importlib.util.find_spec("music21") is not None,
        "yt_dlp": importlib.util.find_spec("yt_dlp") is not None,
        "youtube_enabled": settings.allow_youtube,
        "local_osmd": (settings.web_dir / "vendor" / "opensheetmusicdisplay.min.js").exists(),
        "limits": {
            "max_upload_mb": settings.max_upload_mb,
            "max_audio_seconds": settings.max_audio_seconds,
            "workers": settings.worker_count,
        },
    }


@app.post("/api/jobs", status_code=202)
async def create_job(
    audio_file: Annotated[UploadFile | None, File()] = None,
    youtube_url: Annotated[str | None, Form()] = None,
    title: Annotated[str, Form()] = "",
    mode: Annotated[str, Form()] = "piano",
    bpm: Annotated[float, Form()] = 0,
    time_signature: Annotated[str, Form()] = "4/4",
    quantization: Annotated[int, Form()] = 16,
    split_pitch: Annotated[int, Form()] = 60,
    minimum_midi: Annotated[int, Form()] = 36,
    maximum_midi: Annotated[int, Form()] = 96,
    onset_threshold: Annotated[float, Form()] = 0.5,
    frame_threshold: Annotated[float, Form()] = 0.3,
    minimum_note_length_ms: Annotated[float, Form()] = 127.7,
    accepted_rights: Annotated[bool, Form()] = False,
) -> dict:
    has_file = audio_file is not None and bool(audio_file.filename)
    has_url = bool((youtube_url or "").strip())
    if has_file == has_url:
        raise HTTPException(status_code=400, detail="Choose exactly one input: audio file or YouTube URL")
    if not accepted_rights:
        raise HTTPException(status_code=400, detail="You must confirm that you have the right to process this audio")
    if mode not in {"piano", "lead", "raw"}:
        raise HTTPException(status_code=400, detail="Mode must be piano, lead, or raw")
    if time_signature not in {"4/4", "3/4", "6/8"}:
        raise HTTPException(status_code=400, detail="Unsupported time signature")
    if quantization not in {8, 16, 32}:
        raise HTTPException(status_code=400, detail="Quantization must be 8, 16, or 32")
    if bpm != 0 and not 40 <= bpm <= 240:
        raise HTTPException(status_code=400, detail="BPM must be 0 for automatic detection or between 40 and 240")
    if not 36 <= split_pitch <= 84:
        raise HTTPException(status_code=400, detail="Piano split pitch must be between MIDI 36 and 84")
    if not 0 <= minimum_midi < maximum_midi <= 127:
        raise HTTPException(status_code=400, detail="Invalid MIDI note range")
    if not 0.05 <= onset_threshold <= 0.95 or not 0.05 <= frame_threshold <= 0.95:
        raise HTTPException(status_code=400, detail="Detection thresholds must be between 0.05 and 0.95")
    if not 20 <= minimum_note_length_ms <= 1000:
        raise HTTPException(status_code=400, detail="Minimum note length must be between 20 and 1000 ms")

    clean_title = title.strip()[:200]
    payload = {
        "source_type": "upload" if has_file else "youtube",
        "source_name": "",
        "title": clean_title,
        "mode": mode,
        "bpm_requested": float(bpm),
        "bpm_used": None,
        "time_signature": time_signature,
        "quantization": int(quantization),
        "split_pitch": int(split_pitch),
        "minimum_midi": int(minimum_midi),
        "maximum_midi": int(maximum_midi),
        "onset_threshold": float(onset_threshold),
        "frame_threshold": float(frame_threshold),
        "minimum_note_length_ms": float(minimum_note_length_ms),
        "duration_seconds": None,
    }

    if has_url:
        if not settings.allow_youtube:
            raise HTTPException(status_code=403, detail="YouTube input is disabled by the server")
        try:
            payload["youtube_url"] = validate_youtube_url(youtube_url or "")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    job = job_store.create(payload)
    try:
        if has_file and audio_file is not None:
            safe_name = validate_audio_filename(audio_file.filename or "audio")
            suffix = Path(safe_name).suffix.lower()
            stored_name = f"source{suffix}"
            destination = job_store.job_dir(job["id"]) / stored_name
            await _save_upload(
                audio_file,
                destination,
                limit_bytes=settings.max_upload_mb * 1024 * 1024,
            )
            source_name = Path(safe_name).stem[:200]
            job = job_store.update(
                job["id"],
                source_filename=stored_name,
                source_name=source_name,
                title=clean_title or source_name,
            )
        submit_job(job["id"])
        return job_store.public(job)
    except ValueError as exc:
        job_store.delete(job["id"])
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:
        job_store.delete(job["id"])
        raise


@app.post("/api/demo", status_code=201)
def create_demo(mode: str = "piano") -> dict:
    if mode not in {"piano", "lead", "raw"}:
        raise HTTPException(status_code=400, detail="Mode must be piano, lead, or raw")
    job = job_store.create(
        {
            "source_type": "demo",
            "source_name": "Built-in C major demo",
            "title": "AudioSheet Studio Demo",
            "mode": mode,
            "bpm_requested": 100.0,
            "bpm_used": 100.0,
            "time_signature": "4/4",
            "quantization": 16,
            "duration_seconds": 9.6,
        }
    )
    try:
        filename = "sheet.musicxml"
        create_demo_musicxml(job_store.job_dir(job["id"]) / filename, mode=mode)
        job = job_store.update(
            job["id"],
            status="done",
            progress=100,
            message="Demo score is ready",
            artifacts=[
                {
                    "filename": filename,
                    "label": "Demo MusicXML sheet",
                    "kind": "musicxml",
                    "url": f"/api/jobs/{job['id']}/files/{filename}",
                }
            ],
        )
        return job_store.public(job)
    except Exception as exc:
        job_store.update(job["id"], status="failed", progress=100, error=str(exc), message="Demo failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/jobs")
def list_jobs(limit: int = 20) -> list[dict]:
    return [job_store.public(job) for job in job_store.list_recent(limit)]


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict:
    return _get_public_job(job_id)


@app.delete("/api/jobs/{job_id}", status_code=204)
def delete_job(job_id: str) -> None:
    try:
        job_store.delete(job_id)
    except JobNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Job not found") from exc


@app.get("/api/jobs/{job_id}/files/{filename}")
def get_job_file(job_id: str, filename: str) -> FileResponse:
    job = _get_public_job(job_id)
    allowed = {artifact["filename"] for artifact in job.get("artifacts", [])}
    if filename not in allowed:
        raise HTTPException(status_code=404, detail="Artifact not found")
    path = job_store.job_dir(job_id) / Path(filename).name
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Artifact not found")
    media_type, _ = mimetypes.guess_type(path.name)
    if path.suffix.lower() in {".musicxml", ".xml"}:
        media_type = "application/vnd.recordare.musicxml+xml"
    return FileResponse(path, media_type=media_type or "application/octet-stream", filename=path.name)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(settings.web_dir / "index.html")
