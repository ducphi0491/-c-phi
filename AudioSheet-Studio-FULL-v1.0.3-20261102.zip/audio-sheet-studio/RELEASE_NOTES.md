# AudioSheet Studio 1.0.3 - Full consolidated Windows package

## Fixes combined

- Complete original v1.0.0 website (no changes to supported features).
- v1.0.1 AI traceback diagnostics, `scripts/diagnose_ai.py` and improved error messages.
- v1.0.2 `setuptools==80.9.0` compatibility pin for `resampy` / `pkg_resources`.
- Windows one-click `CHAY_WEBSITE.bat` and auto-repair in `run_windows.bat`.
- `check_install.py` tests actual imports (including TensorFlow and Basic Pitch inference), not only installed package metadata.
- During repair, the launcher also runs the full AI model diagnostic once.

## Overwrite policy

Unzip into `C:\AudioSheetStudio` so the project is `C:\AudioSheetStudio\audio-sheet-studio`.
Overwrite matching source files; **do not delete the existing folder**. The ZIP does not contain `.venv`, `.env`, or job audio/results, so existing files remain when copying over.

## Verification and limitations

Python source syntax and ZIP layout are checked in the build environment. Windows installation and real Basic Pitch inference must be tested on the user's machine. The source package does not contain preinstalled TensorFlow, models outside those installed with Basic Pitch, or private user data.

---

# AudioSheet Studio 1.0.0

Release date: 2026-11-02

## Included

- FastAPI local web server and responsive Vietnamese user interface.
- Audio upload: MP3, WAV, FLAC, OGG, M4A, AAC, and WEBM.
- Authorized YouTube input through yt-dlp.
- FFmpeg normalization to mono 22.05 kHz WAV.
- Spotify Basic Pitch audio-to-MIDI transcription.
- music21 MusicXML generation in piano, lead-sheet, and raw modes.
- Browser sheet rendering with OpenSheetMusicDisplay.
- MIDI, MusicXML, CSV, JSON, WAV, and optional PDF outputs.
- File-backed local job history and one-worker processing queue.
- Windows scripts, Linux scripts, and Docker setup.

## Verification performed in the build environment

- Python source compilation: passed.
- JavaScript syntax check: passed.
- FastAPI health and root endpoint tests: passed.
- Filename and YouTube host validation tests: passed.
- Live local HTTP health response: passed.

The build environment used Python 3.13 and did not contain TensorFlow, Basic Pitch,
or music21. Therefore, a full real-audio AI inference was not executed there. The
release intentionally targets Python 3.11. After installation, run:

    .venv\Scripts\python.exe scripts\check_install.py

A fully ready machine should report OK for FFmpeg, FastAPI, music21, basic_pitch,
and yt_dlp.

## Known limitations

- Best results come from a clear solo instrument recording.
- Lead-sheet chord names are heuristic suggestions.
- Piano hand separation is pitch-based, not pianist fingering analysis.
- No stem separation, guitar tablature, user accounts, or distributed worker queue yet.
- Public Internet deployment needs authentication, HTTPS, rate limits, cleanup jobs,
  a database, and a dedicated processing queue.
