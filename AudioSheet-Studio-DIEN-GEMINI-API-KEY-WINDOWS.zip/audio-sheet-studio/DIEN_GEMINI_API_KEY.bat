@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title AudioSheet Studio - Cau hinh Gemini API Key

echo.
echo ==========================================================
echo  AUDIOSHEET - DIEN GEMINI API KEY TU CLIPBOARD
echo ==========================================================
echo.
echo 1. Mo https://aistudio.google.com/api-keys
echo 2. Nhan nut COPY ben phai mot API key trong danh sach.
echo 3. Tro lai cua so nay va nhan phim bat ky.
echo.
if not exist "%~dp0CHAY_GEMINI.bat" (
  echo [LOI] Khong tim thay CHAY_GEMINI.bat cung thu muc.
  echo Hay giai nen ZIP vao C:\ de tao duong dan C:\audio-sheet-studio.
  pause
  exit /b 2
)
pause >nul

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0DIEN_GEMINI_API_KEY.ps1"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
  echo.
  echo [LOI] Chua cap nhat duoc API key. Kiem tra thong bao phia tren.
  pause
  exit /b %RESULT%
)

echo.
echo [THANH CONG] Da cap nhat GEMINI_API_KEY trong .env.
echo [BUOC TIEP] Dong website (Ctrl+C), sau do chay KIEM_TRA_GEMINI.bat.
echo [LUU Y] Neu van bao loi consent, tich chon dong y gui audio len Google.
echo.
pause
exit /b 0
