# AudioSheet Studio v1.5.0 - local Gemini API key helper.
# Reads key from clipboard; never displays, logs, or uploads the key.
# Requires Windows PowerShell 5.1 and desktop clipboard access.
$ErrorActionPreference = 'Stop'

try {
    $projectDir = $PSScriptRoot
    $projectFile = Join-Path $projectDir 'CHAY_GEMINI.bat'
    if (-not (Test-Path -LiteralPath $projectFile -PathType Leaf)) {
        throw 'Sai thu muc AudioSheet. Can giai nen hai file vao C:\audio-sheet-studio.'
    }

    $clipboard = Get-Clipboard -Raw -ErrorAction Stop
    if ($null -eq $clipboard) {
        throw 'Clipboard dang trong. Hay bam nut COPY cua API key tren Google AI Studio.'
    }
    $key = ([string]$clipboard).Trim()
    if ($key -notmatch '^AIza[0-9A-Za-z_-]{20,}$') {
        throw 'Clipboard khong giong Gemini API key. Hay nhan bieu tuong COPY ben phai dung dong API key, khong copy 4 ky tu cuoi.'
    }

    $envPath = Join-Path $projectDir '.env'
    $examplePath = Join-Path $projectDir '.env.example'
    if (Test-Path -LiteralPath $envPath -PathType Leaf) {
        $original = [System.IO.File]::ReadAllText($envPath)
    } elseif (Test-Path -LiteralPath $examplePath -PathType Leaf) {
        $original = [System.IO.File]::ReadAllText($examplePath)
    } else {
        $original = "GEMINI_MODEL=gemini-3.8-flash`r`nGEMINI_TIMEOUT_SECONDS=180`r`n"
    }

    # Preserve all other .env settings. Replace only GEMINI_API_KEY, de-duping it.
    $lines = $original -split '\r?\n'
    $newLines = New-Object 'System.Collections.Generic.List[string]'
    $found = $false
    foreach ($line in $lines) {
        if ($line -match '^\s*GEMINI_API_KEY\s*=') {
            if (-not $found) {
                $newLines.Add(('GEMINI_API_KEY=' + $key))
                $found = $true
            }
        } else {
            $newLines.Add($line)
        }
    }
    if (-not $found) {
        $newLines.Add(('GEMINI_API_KEY=' + $key))
    }
    $result = ($newLines -join "`r`n").TrimEnd([char[]]@([char]13, [char]10)) + "`r`n"

    # Atomic replacement of .env: do not leave a backup copy of a secret.
    $tempPath = Join-Path $projectDir ('.env.pending.' + [guid]::NewGuid().ToString('N'))
    try {
        $utf8 = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($tempPath, $result, $utf8)
        if (Test-Path -LiteralPath $envPath -PathType Leaf) {
            [System.IO.File]::Replace($tempPath, $envPath, $null)
        } else {
            [System.IO.File]::Move($tempPath, $envPath)
        }
    } finally {
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) {
            Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
        }
    }

    # Clear clipboard after saving to reduce accidental disclosure.
    try { Set-Clipboard -Value '' -ErrorAction Stop } catch { }
    Write-Host '[OK] GEMINI_API_KEY da luu trong .env (khong hien thi key).' -ForegroundColor Green
    Write-Host '[OK] Da giu nguyen cac cau hinh khac.' -ForegroundColor Green
    Write-Host '[CHU Y] Khoi dong lai website de nap cau hinh moi.'
    exit 0
} catch {
    Write-Host ('[LOI] ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
