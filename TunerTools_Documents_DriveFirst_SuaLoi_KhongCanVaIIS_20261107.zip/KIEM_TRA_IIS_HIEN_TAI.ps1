param([string]$IisPhp='C:\inetpub\wwwroot\api_documents.php')
$ErrorActionPreference='Stop'
if (-not (Test-Path -LiteralPath $IisPhp -PathType Leaf)) {
    Write-Host 'IIS API documents file not found.' -ForegroundColor Red
    exit 2
}
$raw=[System.IO.File]::ReadAllText($IisPhp)
$hasPermissionMe=$raw.Contains("'permission_me'") -or $raw.Contains('"permission_me"')
$hasLogin=$raw.Contains("'auth_login'") -or $raw.Contains('"auth_login"')
$hasAction=$raw.Contains('$action')
Write-Host '=== DOCUMENTS IIS READ-ONLY COMPATIBILITY TEST ===' -ForegroundColor Cyan
Write-Host ("api_documents.php : {0}" -f $IisPhp)
Write-Host ("auth_login action : {0}" -f $hasLogin)
Write-Host ("permission_me action : {0}" -f $hasPermissionMe)
Write-Host ("action dispatcher : {0}" -f $hasAction)
Write-Host 'No file was modified. No credentials were displayed.'
if (-not $hasPermissionMe -or -not $hasLogin) {
    Write-Host 'IMPORTANT: Do not deploy the new Alwaysdata PHP yet. The IIS auth contract needs review.' -ForegroundColor Red
    exit 3
}
Write-Host 'Static check passed. Live permission_me request still needs a logged-in Android session.' -ForegroundColor Green
