package com.docflowoffline

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import android.provider.DocumentsContract
import java.util.ArrayDeque
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

// ================ DocumentStore.kt ================
object DocumentStore {
    const val DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    const val PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    const val PDF = "application/pdf"
    const val CSV = "text/csv"
    const val TSV = "text/tab-separated-values"
    const val TXT = "text/plain"

    enum class TextFormat(val extension: String, val mime: String, val title: String) {
        TXT("txt", DocumentStore.TXT, "văn bản"),
        CSV("csv", DocumentStore.CSV, "CSV"),
        TSV("tsv", DocumentStore.TSV, "TSV")
    }

    sealed class OpenFile(
        open val uri: Uri,
        open val name: String,
        open val restoredDraft: Boolean = false
    ) {
        /** Unique per open operation, even when URI and content are identical. */
        val editorSessionKey: Any = Any()

        data class Word(
            override val uri: Uri,
            override val name: String,
            val bytes: ByteArray,
            val data: OfficeOoxml.Word,
            override val restoredDraft: Boolean = false
        ) : OpenFile(uri, name, restoredDraft)

        data class Excel(
            override val uri: Uri,
            override val name: String,
            val bytes: ByteArray,
            val data: OfficeOoxml.Workbook,
            override val restoredDraft: Boolean = false
        ) : OpenFile(uri, name, restoredDraft)

        data class Slides(
            override val uri: Uri,
            override val name: String,
            val bytes: ByteArray,
            val slides: List<OfficeOoxml.Slide>,
            override val restoredDraft: Boolean = false
        ) : OpenFile(uri, name, restoredDraft)

        data class Pdf(override val uri: Uri, override val name: String) : OpenFile(uri, name)

        data class Text(
            override val uri: Uri,
            override val name: String,
            val value: String,
            val format: TextFormat,
            override val restoredDraft: Boolean = false
        ) : OpenFile(uri, name, restoredDraft)
    }

    fun fileName(context: Context, uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Tai_lieu"
    }

    fun open(context: Context, uri: Uri): OpenFile {
        val name = fileName(context, uri)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val kind = if (ext in setOf("docx", "xlsx", "pptx", "pdf", "txt", "csv", "tsv")) ext
            else when (context.contentResolver.getType(uri)) {
                DOCX -> "docx"
                XLSX -> "xlsx"
                PPTX -> "pptx"
                PDF -> "pdf"
                CSV -> "csv"
                TSV -> "tsv"
                TXT -> "txt"
                else -> ext
            }
        return when (kind) {
            "docx" -> {
                openOfficeWithDraft(context, uri, name, DocumentDraftStore.Kind.WORD) { bytes, restored ->
                    OpenFile.Word(uri, name, bytes, OfficeOoxml.readWord(bytes), restored)
                }
            }
            "xlsx" -> {
                openOfficeWithDraft(context, uri, name, DocumentDraftStore.Kind.EXCEL) { bytes, restored ->
                    OpenFile.Excel(uri, name, bytes, OfficeOoxml.readWorkbook(bytes), restored)
                }
            }
            "pptx" -> {
                openOfficeWithDraft(context, uri, name, DocumentDraftStore.Kind.SLIDES) { bytes, restored ->
                    OpenFile.Slides(uri, name, bytes, OfficeOoxml.readPresentation(bytes), restored)
                }
            }
            "pdf" -> OpenFile.Pdf(uri, name)
            "txt", "csv", "tsv" -> {
                val format = when (kind) {
                    "csv" -> TextFormat.CSV
                    "tsv" -> TextFormat.TSV
                    else -> TextFormat.TXT
                }
                val draft = DocumentDraftStore.load(context, uri, name, DocumentDraftStore.Kind.TEXT)
                val bytes = draft ?: readUpTo(context, uri, 10 * 1024 * 1024)
                // BOM UTF-8 only; older encodings need a future encoding chooser.
                val body = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
                OpenFile.Text(uri, name, body, format, draft != null)
            }
            else -> throw IllegalArgumentException("Định dạng .$ext chưa được hỗ trợ. Hãy chọn DOCX, XLSX, PPTX, PDF, TXT, CSV hoặc TSV.")
        }
    }

    private fun <T : OpenFile> openOfficeWithDraft(
        context: Context,
        uri: Uri,
        name: String,
        kind: DocumentDraftStore.Kind,
        factory: (ByteArray, Boolean) -> T
    ): T {
        val draft = DocumentDraftStore.load(context, uri, name, kind)
        if (draft != null) {
            try {
                return factory(draft, true)
            } catch (_: Exception) {
                // A partial/corrupt private draft must never prevent opening the source file.
                DocumentDraftStore.discard(context, uri)
            }
        }
        return factory(readUpTo(context, uri), false)
    }

    fun readUpTo(context: Context, uri: Uri, maxBytes: Int = 40 * 1024 * 1024): ByteArray {
        val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Không mở được tệp.")
        return input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(16384)
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                if (out.size() + n > maxBytes) throw IOException("Tệp quá lớn (giới hạn ${maxBytes / (1024 * 1024)} MB trong phiên bản thử nghiệm).")
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        }
    }

    data class Recent(val uri: String, val name: String, val openedAt: Long = 0L)
    fun recent(context: Context): List<Recent> = runCatching {
        val json = JSONArray(context.getSharedPreferences("recent_files", Context.MODE_PRIVATE).getString("files", "[]"))
        (0 until json.length()).mapNotNull { i ->
            val item = json.optJSONObject(i) ?: return@mapNotNull null
            val uri = item.optString("uri")
            val name = item.optString("name")
            if (uri.isEmpty() || name.isEmpty()) null else Recent(uri, name, item.optLong("openedAt", 0L))
        }
    }.getOrDefault(emptyList())

    fun remember(context: Context, uri: Uri, name: String) {
        val list = (listOf(Recent(uri.toString(), name, System.currentTimeMillis())) +
            recent(context).filterNot { it.uri == uri.toString() }).take(30)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("openedAt", it.openedAt)) }
        context.getSharedPreferences("recent_files", Context.MODE_PRIVATE).edit().putString("files", arr.toString()).apply()
    }

    fun persistReadPermission(context: Context, uri: Uri) {
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    fun suggestedCopyName(original: String, ext: String): String =
        original.substringBeforeLast('.', original) + "_edited." + ext
}


// ================ DocumentDraftStore.kt ================
/**
 * Private, atomic autosave storage for editable documents.
 *
 * A draft is keyed by its source URI and is accepted only while the source file still has the
 * same size/last-modified signature (when the provider exposes those values). Epochs prevent a
 * delayed autosave task from recreating a draft after the user explicitly discarded or saved it.
 */
internal object DocumentDraftStore {
    enum class Kind(val id: String, val maxBytes: Int) {
        WORD("word", 96 * 1024 * 1024),
        EXCEL("excel", 96 * 1024 * 1024),
        SLIDES("slides", 96 * 1024 * 1024),
        TEXT("text", 10 * 1024 * 1024)
    }

    private data class SourceSignature(val size: Long, val modified: Long)
    private data class RuntimeState(
        val epoch: AtomicLong = AtomicLong(0),
        val revision: AtomicLong = AtomicLong(0),
        val lastSavedRevision: AtomicLong = AtomicLong(0)
    )

    private const val DIRECTORY = "docflow_drafts"
    private val states = ConcurrentHashMap<String, RuntimeState>()
    private val locks = ConcurrentHashMap<String, Any>()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun epoch(uri: Uri): Long = state(uri).epoch.get()
    fun nextRevision(uri: Uri): Long = state(uri).revision.incrementAndGet()

    fun load(context: Context, uri: Uri, sourceName: String, kind: Kind): ByteArray? {
        val key = key(uri)
        return synchronized(locks.getOrPut(key) { Any() }) {
            val metaFile = File(folder(context), "$key.json")
            val dataFile = File(folder(context), "$key.bin")
            if (!metaFile.isFile || !dataFile.isFile) return@synchronized null
            runCatching {
                val meta = JSONObject(metaFile.readText(Charsets.UTF_8))
                require(meta.optString("uri") == uri.toString())
                require(meta.optString("kind") == kind.id)
                val minimumLength = if (kind == Kind.TEXT) 0L else 1L
                require(dataFile.length() in minimumLength..kind.maxBytes.toLong())
                val savedSize = meta.optLong("sourceSize", -1L)
                val savedModified = meta.optLong("sourceModified", -1L)
                val current = sourceSignature(context, uri)
                val sourceChanged =
                    (savedSize >= 0L && current.size >= 0L && savedSize != current.size) ||
                        (savedModified > 0L && current.modified > 0L && savedModified != current.modified)
                require(!sourceChanged)
                val storedName = meta.optString("sourceName")
                require(storedName.isBlank() || sourceName.isBlank() || storedName == sourceName ||
                    savedSize >= 0L || savedModified > 0L)
                val bytes = dataFile.readBytes()
                val expectedHash = meta.optString("sha256")
                require(expectedHash.isBlank() || expectedHash == sha256Hex(bytes))
                bytes
            }.getOrElse {
                // Invalidate queued writes from any old editor session as well as removing the files.
                discard(context, uri)
                null
            }
        }
    }

    fun save(
        context: Context,
        uri: Uri,
        sourceName: String,
        kind: Kind,
        expectedEpoch: Long,
        revision: Long,
        bytes: ByteArray
    ) {
        require(bytes.isNotEmpty() || kind == Kind.TEXT) { "Bản nháp không có dữ liệu." }
        require(bytes.size <= kind.maxBytes) { "Bản nháp vượt quá giới hạn ${kind.maxBytes / (1024 * 1024)} MB." }
        val key = key(uri)
        val runtime = state(uri)
        if (runtime.epoch.get() != expectedEpoch || revision < runtime.lastSavedRevision.get()) return
        synchronized(locks.getOrPut(key) { Any() }) {
            if (runtime.epoch.get() != expectedEpoch || revision < runtime.lastSavedRevision.get()) return
            val dir = folder(context)
            val dataFile = File(dir, "$key.bin")
            val metaFile = File(dir, "$key.json")
            val dataTemp = File(dir, "$key.bin.tmp")
            val metaTemp = File(dir, "$key.json.tmp")
            val signature = sourceSignature(context, uri)
            dataTemp.outputStream().use { output ->
                output.write(bytes)
                output.flush()
                runCatching { (output as? java.io.FileOutputStream)?.fd?.sync() }
            }
            val meta = JSONObject()
                .put("version", 1)
                .put("uri", uri.toString())
                .put("sourceName", sourceName)
                .put("kind", kind.id)
                .put("sourceSize", signature.size)
                .put("sourceModified", signature.modified)
                .put("updatedAt", System.currentTimeMillis())
                .put("revision", revision)
                .put("sha256", sha256Hex(bytes))
            metaTemp.writeText(meta.toString(), Charsets.UTF_8)
            if (runtime.epoch.get() != expectedEpoch || revision < runtime.lastSavedRevision.get()) {
                dataTemp.delete(); metaTemp.delete(); return
            }
            atomicReplace(dataTemp, dataFile)
            atomicReplace(metaTemp, metaFile)
            runtime.lastSavedRevision.accumulateAndGet(revision, ::maxOf)
        }
    }

    fun saveAsync(
        context: Context,
        uri: Uri,
        sourceName: String,
        kind: Kind,
        expectedEpoch: Long,
        revision: Long,
        producer: () -> ByteArray
    ) {
        val app = context.applicationContext
        ioScope.launch {
            runCatching {
                if (state(uri).epoch.get() == expectedEpoch) {
                    save(app, uri, sourceName, kind, expectedEpoch, revision, producer())
                }
            }
        }
    }

    /**
     * Delete the current draft without invalidating the editor session. A revision barrier is
     * raised first, so an older autosave already queued on Dispatchers.IO cannot recreate the
     * draft after the user has undone all local changes.
     */
    fun removeCurrent(context: Context, uri: Uri, expectedEpoch: Long) {
        val runtime = state(uri)
        if (runtime.epoch.get() != expectedEpoch) return
        val barrier = runtime.revision.incrementAndGet()
        runtime.lastSavedRevision.accumulateAndGet(barrier, ::maxOf)
        synchronized(locks.getOrPut(key(uri)) { Any() }) {
            if (runtime.epoch.get() == expectedEpoch) removeFiles(context, key(uri))
        }
    }

    /** Explicit save/discard: invalidate all queued writes from the old editor instance. */
    fun discard(context: Context, uri: Uri) {
        val runtime = state(uri)
        runtime.epoch.incrementAndGet()
        runtime.lastSavedRevision.set(0)
        synchronized(locks.getOrPut(key(uri)) { Any() }) { removeFiles(context, key(uri)) }
    }

    private fun state(uri: Uri): RuntimeState = states.getOrPut(key(uri)) { RuntimeState() }

    private fun folder(context: Context): File = File(context.filesDir, DIRECTORY).apply { mkdirs() }

    private fun key(uri: Uri): String =
        sha256Hex(uri.toString().toByteArray(Charsets.UTF_8)).take(32)

    private fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(Locale.ROOT, it.toInt() and 0xFF) }

    private fun sourceSignature(context: Context, uri: Uri): SourceSignature {
        var size = -1L
        var modified = -1L
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    val modifiedIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                    if (modifiedIndex >= 0 && !cursor.isNull(modifiedIndex)) modified = cursor.getLong(modifiedIndex)
                }
            }
        }
        return SourceSignature(size, modified)
    }

    private fun atomicReplace(temp: File, target: File) {
        if (target.exists() && !target.delete()) throw IOException("Không thay được bản nháp cũ.")
        if (!temp.renameTo(target)) {
            temp.inputStream().use { input -> target.outputStream().use(input::copyTo) }
            temp.delete()
        }
    }

    private fun removeFiles(context: Context, key: String) {
        val dir = folder(context)
        listOf("$key.bin", "$key.json", "$key.bin.tmp", "$key.json.tmp")
            .forEach { File(dir, it).delete() }
    }
}


// ================ DocumentCatalog.kt ================
/** Virtual format folders backed ONLY by document trees explicitly authorized by the user. */
internal enum class CatalogKind(val title: String, val subtitle: String) {
    PDF("PDF", ".pdf"),
    EXCEL("Excel", ".xlsx · .xls · .csv"),
    WORD("Word", ".docx · .doc"),
    SLIDES("PowerPoint", ".pptx · .ppt"),
    TEXT("Văn bản", ".txt · .tsv")
}

internal fun catalogKind(name: String): CatalogKind? = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
    "pdf" -> CatalogKind.PDF
    "xlsx", "xls", "csv" -> CatalogKind.EXCEL
    "docx", "doc" -> CatalogKind.WORD
    "pptx", "ppt" -> CatalogKind.SLIDES
    "txt", "tsv" -> CatalogKind.TEXT
    else -> null
}

internal fun isSupportedDocument(name: String): Boolean =
    name.substringAfterLast('.', "").lowercase(Locale.ROOT) in setOf("pdf", "xlsx", "csv", "docx", "pptx", "txt", "tsv")

internal data class CatalogFolder(val uri: String, val name: String)

internal data class CatalogItem(
    val uri: String,
    val name: String,
    val kind: CatalogKind,
    val path: String,
    val modifiedAt: Long,
    val size: Long
)

internal data class CatalogScan(val items: List<CatalogItem>, val warnings: List<String>, val limited: Boolean)

internal object DocumentCatalog {
    private const val PREFS = "docflow_document_folders"
    private const val FOLDERS = "folders"
    private const val MAX_TREES = 12
    private const val MAX_NODES = 15000
    private const val MAX_DEPTH = 12

    fun folders(context: Context): List<CatalogFolder> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(FOLDERS, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val obj = array.optJSONObject(i) ?: return@mapNotNull null
            val uri = obj.optString("uri")
            val name = obj.optString("name")
            if (uri.isBlank()) null else CatalogFolder(uri, name.ifBlank { "Thư mục đã chọn" })
        }
    }.getOrDefault(emptyList())

    private fun saveFolders(context: Context, value: List<CatalogFolder>) {
        val array = JSONArray()
        value.forEach { array.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(FOLDERS, array.toString()).apply()
    }

    fun add(context: Context, tree: Uri): List<CatalogFolder> {
        val existing = folders(context)
        require(existing.size < MAX_TREES || existing.any { it.uri == tree.toString() }) {
            "Chỉ có thể theo dõi tối đa $MAX_TREES thư mục. Hãy bỏ bớt một thư mục."
        }
        context.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val name = runCatching {
            val root = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            context.contentResolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull().orEmpty().ifBlank { "Thư mục ${folders(context).size + 1}" }
        val next = existing.filterNot { it.uri == tree.toString() } + CatalogFolder(tree.toString(), name)
        saveFolders(context, next)
        return next
    }

    fun remove(context: Context, folder: CatalogFolder): List<CatalogFolder> {
        val next = folders(context).filterNot { it.uri == folder.uri }
        saveFolders(context, next)
        runCatching {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(folder.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        return next
    }

    /** Execute on Dispatchers.IO. Enumerates the selected trees, never the entire phone. */
    fun scan(context: Context, folders: List<CatalogFolder>): CatalogScan {
        val resolver = context.contentResolver
        val granted = resolver.persistedUriPermissions.filter { it.isReadPermission }.map { it.uri.toString() }.toSet()
        val warnings = mutableListOf<String>()
        val items = LinkedHashMap<String, CatalogItem>()
        var nodes = 0
        var limited = false
        for (folder in folders) {
            if (folder.uri !in granted) {
                warnings += "Không còn quyền đọc: ${folder.name}. Hãy chọn lại thư mục."
                continue
            }
            try {
                val treeUri = Uri.parse(folder.uri)
                data class Pending(val documentId: String, val relative: String, val depth: Int)
                val queue = ArrayDeque<Pending>()
                queue.add(Pending(DocumentsContract.getTreeDocumentId(treeUri), folder.name, 0))
                while (queue.isNotEmpty()) {
                    if (nodes >= MAX_NODES) { limited = true; break }
                    val dir = queue.removeFirst()
                    val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, dir.documentId)
                    val projection = arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                        DocumentsContract.Document.COLUMN_SIZE
                    )
                    resolver.query(children, projection, null, null, null)?.use { cursor ->
                        while (cursor.moveToNext()) {
                            nodes++
                            if (nodes > MAX_NODES) { limited = true; break }
                            val id = cursor.getString(0) ?: continue
                            val name = cursor.getString(1) ?: continue
                            val mime = cursor.getString(2).orEmpty()
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                if (dir.depth < MAX_DEPTH) queue.add(Pending(id, "${dir.relative}/$name", dir.depth + 1))
                                else limited = true
                            } else {
                                val kind = catalogKind(name) ?: continue
                                val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                                items.putIfAbsent(documentUri.toString(), CatalogItem(
                                    uri = documentUri.toString(), name = name, kind = kind,
                                    path = dir.relative, modifiedAt = if (cursor.isNull(3)) 0L else cursor.getLong(3),
                                    size = if (cursor.isNull(4)) 0L else cursor.getLong(4)
                                ))
                            }
                        }
                    }
                    if (limited) break
                }
            } catch (e: Exception) {
                warnings += "Không quét được ${folder.name}: ${e.message ?: "lỗi truy cập"}"
            }
            if (limited) break
        }
        return CatalogScan(items.values.sortedWith(compareByDescending<CatalogItem> { it.modifiedAt }.thenBy { it.name.lowercase(Locale.ROOT) }), warnings, limited)
    }
}


// ================ CatalogScreens.kt ================
private fun kindIcon(kind: CatalogKind): ImageVector = when (kind) {
    CatalogKind.PDF -> Icons.Default.PictureAsPdf
    CatalogKind.EXCEL -> Icons.Default.TableChart
    CatalogKind.WORD -> Icons.Default.Description
    CatalogKind.SLIDES -> Icons.Default.Slideshow
    CatalogKind.TEXT -> Icons.Default.Notes
}

private fun kindColor(kind: CatalogKind): Color = when (kind) {
    CatalogKind.PDF -> Color(0xFFCC4147)
    CatalogKind.EXCEL -> Color(0xFF138451)
    CatalogKind.WORD -> Color(0xFF2473B9)
    CatalogKind.SLIDES -> Color(0xFFE16B34)
    CatalogKind.TEXT -> Color(0xFF916E38)
}

@Composable
internal fun CategoryFolderGrid(
    indexed: List<CatalogItem>,
    recent: List<DocumentStore.Recent>,
    scanning: Boolean,
    folders: List<CatalogFolder>,
    open: (CatalogKind) -> Unit,
    addFolder: () -> Unit,
    manageFolders: () -> Unit
) {
    val kinds = remember { listOf(CatalogKind.PDF, CatalogKind.EXCEL, CatalogKind.WORD, CatalogKind.SLIDES, CatalogKind.TEXT) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(dfTextKey("Thư mục theo định dạng"), modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            TextButton(onClick = manageFolders) { Icon(Icons.Default.Folder, null, Modifier.size(18.dp)); Text(dfTextKey("Quản lý")) }
        }
        kinds.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { kind ->
                    val seen = indexed.count { it.kind == kind }
                    val recentCount = recent.count { catalogKind(it.name) == kind }
                    Surface(
                        onClick = { open(kind) },
                        modifier = Modifier.weight(1f).height(99.dp),
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shadowElevation = 1.dp
                    ) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 9.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            DocFlowFileLogo(kind, modifier = Modifier.size(48.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(dfTextKey(kind.title), fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (seen > 0) "$seen tệp đã tìm thấy"
                                     else if (recentCount > 0) "$recentCount tệp gần đây"
                                     else if (scanning) "Đang tìm..." else "Mở thư mục",
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.ChevronRight, null, Modifier.size(17.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (folders.isEmpty()) {
            TextButton(onClick = addFolder) {
                Icon(Icons.Default.CreateNewFolder, null, Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text(dfTextKey("Thêm thư mục để hiển thị thêm tài liệu"))
            }
        } else {
            Text("Đang theo dõi ${folders.size} thư mục đã cấp quyền" +
                if (scanning) " · Đang cập nhật" else "",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
internal fun CategoryFolderScreen(
    kind: CatalogKind,
    files: List<CatalogItem>,
    recent: List<DocumentStore.Recent>,
    folders: List<CatalogFolder>,
    scanning: Boolean,
    warnings: List<String>,
    limited: Boolean,
    openItem: (String, String) -> Unit,
    addFolder: () -> Unit,
    manageFolders: () -> Unit,
    refresh: () -> Unit
) {
    var search by remember(kind) { mutableStateOf("") }
    val candidates = remember(files, kind, search) {
        files.filter { it.kind == kind && (search.isBlank() || it.name.contains(search.trim(), ignoreCase = true)) }
    }
    val groups = remember(candidates) { candidates.groupBy { it.path } }
    val nonIndexed = remember(recent, files, kind, search) {
        val indexedUris = files.map { it.uri }.toSet()
        recent.filter { catalogKind(it.name) == kind && it.uri !in indexedUris &&
            (search.isBlank() || it.name.contains(search.trim(), ignoreCase = true)) }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).background(kindColor(kind).copy(alpha = .12f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center) {
                    DocFlowFileLogo(kind, Modifier.size(40.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Thư mục ${kind.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(dfTextKey(kind.subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = refresh, enabled = !scanning) {
                    Icon(Icons.Default.Refresh, "Quét lại")
                }
            }
        }
        item {
            OutlinedTextField(value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("Tìm tệp ${kind.title}...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = if (search.isNotEmpty()) {
                    { IconButton(onClick = { search = "" }) { Icon(Icons.Default.Close, "Xóa") } }
                } else null)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = addFolder, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.CreateNewFolder, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(dfTextKey("Thêm thư mục"))
                }
                OutlinedButton(onClick = manageFolders) { Text("Đã chọn (${folders.size})") }
            }
        }
        if (scanning) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (warnings.isNotEmpty() || limited) item {
            Text((warnings + if (limited) listOf("Đã đạt giới hạn quét. Hãy chọn thư mục cụ thể hơn để xem đủ tệp.")
                    else emptyList()).joinToString("\n"),
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (groups.isEmpty() && nonIndexed.isEmpty() && !scanning) item {
            Surface(shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Chưa có tệp ${kind.title}", fontWeight = FontWeight.Medium)
                    Text(dfTextKey("Chọn thư mục chứa tài liệu. DocFlow sẽ phân loại tệp vào đây và các thư mục con."),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = addFolder) { Text(dfTextKey("Chọn thư mục")) }
                }
            }
        }
        if (nonIndexed.isNotEmpty()) {
            item { Text(dfTextKey("Đã mở gần đây"), fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.titleSmall) }
            items(nonIndexed, key = { "recent:${it.uri}" }) { record ->
                CategoryFileRow(record.name, "Đã mở gần đây", kind, onClick = { openItem(record.uri, record.name) })
            }
        }
        groups.forEach { (path, contents) ->
            item(key = "path:$path") {
                Text(path, fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.titleSmall, maxLines = 2,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(contents, key = { "file:${it.uri}" }) { record ->
                CategoryFileRow(record.name,
                    (if (record.modifiedAt > 0L) DateFormat.getDateInstance(DateFormat.SHORT).format(Date(record.modifiedAt))
                     else "Tài liệu") + if (record.size > 0L) " · ${record.size / 1024} KB" else "",
                    kind,
                    onClick = { openItem(record.uri, record.name) })
            }
        }
        if (files.isNotEmpty()) item {
            Text(dfTextKey("Chỉ hiển thị tệp trong các thư mục đã được cấp quyền. ") +
                "Định dạng .doc, .xls, .ppt đời cũ cần chuyển sang định dạng mới để chỉnh sửa.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryFileRow(name: String, detail: String, kind: CatalogKind, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(13.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DocFlowFileLogo(kind, Modifier.size(36.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
internal fun FolderSourcesDialog(
    folders: List<CatalogFolder>,
    onDismiss: () -> Unit,
    onAdd: () -> Unit,
    onRemove: (CatalogFolder) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dfTextKey("Thư mục được phép truy cập")) },
        text = {
            Column(Modifier.heightIn(max = 390.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(dfTextKey("DocFlow chỉ quét thư mục bạn chọn và các thư mục con. Không cần quyền đọc toàn bộ bộ nhớ."),
                    style = MaterialTheme.typography.bodySmall)
                if (folders.isEmpty()) Text(dfTextKey("Chưa chọn thư mục nào."))
                folders.forEach { folder ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Folder, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(folder.name, modifier = Modifier.weight(1f),
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { onRemove(folder) }) {
                            Icon(Icons.Default.DeleteOutline, "Bỏ quyền thư mục")
                        }
                    }
                }
                Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(dfTextKey("Chọn thư mục khác"))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(dfTextKey("Đóng")) } }
    )
}
