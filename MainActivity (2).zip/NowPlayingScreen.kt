package duc_phi.music

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer as AndroidEqualizer
import android.media.audiofx.LoudnessEnhancer
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Piano
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speaker
import androidx.compose.material.icons.rounded.Stars
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
internal fun NowPlayingScreen(controller: MusicController) {
    val colors = LocalMusicColors.current
    val song = controller.currentSong
    var showEqualizer by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }

    BackHandler { controller.goBackFromPlayer() }

    if (song == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background),
            contentAlignment = Alignment.Center
        ) {
            EmptyLibraryState(
                title = "Chưa có bài đang phát",
                description = "Chọn một bài hát trong Trang chủ hoặc Thư viện.",
                buttonText = "Mở Thư viện",
                onButton = { controller.openLibrary() }
            )
        }
        return
    }

    androidx.compose.runtime.LaunchedEffect(song.id) {
        controller.ensureArtwork(song)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(colors.background, Color(0xFF0A0B22), colors.background)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 26.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            NowPlayingHeader(
                song = song,
                source = controller.sourceLabel(song.source),
                onBack = controller::goBackFromPlayer,
                onFavorite = { controller.toggleFavorite(song) },
                isFavorite = controller.isFavorite(song)
            )
        }

        item {
            ArtworkImage(
                song = song,
                artworkUrl = controller.artworkFor(song),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 560.dp)
                    .height(390.dp),
                cornerRadius = 26
            )
        }

        item {
            TrackTitleBlock(
                controller = controller,
                song = song
            )
        }

        item {
            PlaybackProgress(
                positionMs = controller.positionMs,
                durationMs = controller.durationMs,
                onSeek = controller::seekTo
            )
        }

        item {
            MainPlaybackControls(controller)
        }

        item {
            PlayerActions(
                controller = controller,
                song = song,
                onEqualizer = { showEqualizer = true },
                onTimer = { showTimer = true }
            )
        }

        item {
            QueuePanel(controller)
        }
    }

    if (showEqualizer) {
        EqualizerDialog(
            audioSessionId = controller.audioSessionId,
            onDismiss = { showEqualizer = false }
        )
    }

    if (showTimer) {
        SleepTimerDialog(
            currentMinutes = controller.sleepTimerMinutesLeft,
            onSelect = { minutes ->
                controller.setSleepTimer(minutes)
                showTimer = false
            },
            onDismiss = { showTimer = false }
        )
    }
}

@Composable
private fun NowPlayingHeader(
    song: SongItem,
    source: String,
    onBack: () -> Unit,
    onFavorite: () -> Unit,
    isFavorite: Boolean
) {
    val colors = LocalMusicColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Quay lại", tint = colors.textPrimary)
        }
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ĐANG PHÁT",
                color = colors.purpleBright,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (song.source == SongSource.PERSONAL_DRIVE || song.source == SongSource.PUBLIC_DRIVE) {
                    Icon(
                        Icons.Rounded.Cloud,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                }
                Text(source, color = colors.textSecondary, fontSize = 13.sp)
            }
        }
        IconButton(onClick = onFavorite) {
            Icon(
                imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = "Yêu thích",
                tint = if (isFavorite) colors.magenta else colors.textSecondary
            )
        }
    }
}

@Composable
private fun TrackTitleBlock(
    controller: MusicController,
    song: SongItem
) {
    val colors = LocalMusicColors.current
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    color = colors.textPrimary,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    text = song.artist,
                    color = colors.textSecondary,
                    fontSize = 19.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = { controller.toggleFavorite(song) }) {
                Icon(
                    imageVector = if (controller.isFavorite(song)) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = "Yêu thích",
                    tint = if (controller.isFavorite(song)) colors.magenta else colors.textSecondary,
                    modifier = Modifier.size(31.dp)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetadataChip(controller.sourceLabel(song.source), Icons.Rounded.Cloud)
            MetadataChip(controller.formatBadge(song), Icons.Rounded.MusicNote)
            if (song.mimeType?.contains("flac", ignoreCase = true) == true) {
                MetadataChip("Lossless", Icons.Rounded.Equalizer)
            }
        }
    }
}

@Composable
private fun MetadataChip(text: String, icon: ImageVector) {
    val colors = LocalMusicColors.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = colors.purple.copy(alpha = 0.13f),
        border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.32f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = colors.purpleBright, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text(text, color = colors.purpleBright, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PlaybackProgress(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit
) {
    val colors = LocalMusicColors.current
    var dragging by remember { mutableStateOf(false) }
    var localValue by remember { mutableStateOf(0f) }
    val safeDuration = max(1L, durationMs)
    val value = if (dragging) localValue else positionMs.toFloat().coerceIn(0f, safeDuration.toFloat())

    Column {
        Slider(
            value = value,
            onValueChange = {
                dragging = true
                localValue = it
            },
            onValueChangeFinished = {
                onSeek(localValue.toLong())
                dragging = false
            },
            valueRange = 0f..safeDuration.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = colors.purpleBright,
                activeTrackColor = colors.purpleBright,
                inactiveTrackColor = colors.border
            )
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatDuration(value.toLong()), color = colors.textSecondary, fontSize = 12.sp)
            Text(formatDuration(safeDuration), color = colors.textSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MainPlaybackControls(controller: MusicController) {
    val colors = LocalMusicColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = controller::toggleShuffle, modifier = Modifier.size(46.dp)) {
            Icon(
                Icons.Rounded.Shuffle,
                contentDescription = "Ngẫu nhiên",
                tint = if (controller.shuffleEnabled) colors.purpleBright else colors.textSecondary
            )
        }
        IconButton(onClick = controller::previous, modifier = Modifier.size(54.dp)) {
            Icon(
                Icons.Rounded.SkipPrevious,
                contentDescription = "Bài trước",
                tint = colors.textPrimary,
                modifier = Modifier.size(38.dp)
            )
        }
        Box(
            modifier = Modifier
                .size(86.dp)
                .shadow(22.dp, CircleShape)
                .background(
                    Brush.linearGradient(listOf(colors.purpleBright, colors.purple, colors.magenta)),
                    CircleShape
                )
                .clickable(onClick = controller::togglePlayback),
            contentAlignment = Alignment.Center
        ) {
            if (controller.isLoading) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(35.dp)
                )
            } else {
                Icon(
                    imageVector = if (controller.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (controller.isPlaying) "Tạm dừng" else "Phát",
                    tint = Color.White,
                    modifier = Modifier.size(46.dp)
                )
            }
        }
        IconButton(onClick = controller::next, modifier = Modifier.size(54.dp)) {
            Icon(
                Icons.Rounded.SkipNext,
                contentDescription = "Bài tiếp theo",
                tint = colors.textPrimary,
                modifier = Modifier.size(38.dp)
            )
        }
        IconButton(onClick = controller::cycleRepeat, modifier = Modifier.size(46.dp)) {
            Icon(
                imageVector = if (controller.repeatSetting == RepeatSetting.ONE) {
                    Icons.Rounded.RepeatOne
                } else {
                    Icons.Rounded.Repeat
                },
                contentDescription = "Lặp lại",
                tint = if (controller.repeatSetting == RepeatSetting.OFF) colors.textSecondary else colors.purpleBright
            )
        }
    }
}

@Composable
private fun PlayerActions(
    controller: MusicController,
    song: SongItem,
    onEqualizer: () -> Unit,
    onTimer: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        PlayerAction(Icons.Rounded.Equalizer, "Equalizer", onEqualizer)
        PlayerAction(Icons.Rounded.PlaylistPlay, "Danh sách") { controller.openLibrary() }
        PlayerAction(Icons.Rounded.Timer, "Hẹn giờ", onTimer)
        PlayerAction(Icons.Rounded.Download, "Tải về") { controller.downloadSongForOffline(song) }
        PlayerAction(Icons.Rounded.Share, "Chia sẻ", controller::shareCurrentSong)
    }
}

@Composable
private fun PlayerAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    val colors = LocalMusicColors.current
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(52.dp),
            shape = RoundedCornerShape(16.dp),
            color = colors.cardRaised,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = colors.textSecondary, modifier = Modifier.size(25.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = colors.textPrimary, fontSize = 11.sp)
    }
}

@Composable
private fun QueuePanel(controller: MusicController) {
    val colors = LocalMusicColors.current
    val queue = controller.queueFromCurrent()
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = colors.card.copy(alpha = 0.97f),
        border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.46f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Danh sách phát",
                    color = colors.textPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Text("${queue.size} bài", color = colors.textSecondary, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            if (queue.isEmpty()) {
                Text("Danh sách đang trống", color = colors.textSecondary)
            } else {
                queue.take(6).forEachIndexed { offset, item ->
                    val absoluteIndex = controller.currentIndex + offset
                    androidx.compose.runtime.LaunchedEffect(item.id) { controller.ensureArtwork(item) }
                    SongRow(
                        song = item,
                        artworkUrl = controller.artworkFor(item),
                        isCurrent = offset == 0,
                        isFavorite = controller.isFavorite(item),
                        onClick = { controller.playQueueIndex(absoluteIndex) },
                        onFavorite = { controller.toggleFavorite(item) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EqualizerDialog(
    audioSessionId: Int,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.90f),
            shape = RoundedCornerShape(24.dp),
            color = colors.backgroundSoft,
            border = BorderStroke(1.dp, colors.purple.copy(alpha = 0.45f))
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                EqualizerPanel(
                    audioSessionId = audioSessionId,
                    onImportAudio = {},
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 38.dp)
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 4.dp, end = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Đóng",
                        tint = colors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun SleepTimerDialog(
    currentMinutes: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalMusicColors.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Hẹn giờ tắt nhạc",
                    color = colors.textPrimary,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
                if (currentMinutes > 0) {
                    Text(
                        "Còn khoảng $currentMinutes phút",
                        color = colors.purpleBright,
                        fontSize = 13.sp
                    )
                }
                listOf(15, 30, 45, 60, 90).forEach { minutes ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(minutes) },
                        shape = RoundedCornerShape(14.dp),
                        color = colors.cardRaised,
                        border = BorderStroke(1.dp, colors.borderSoft)
                    ) {
                        Text(
                            "$minutes phút",
                            color = colors.textPrimary,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                TextButton(
                    onClick = { onSelect(0) },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Tắt hẹn giờ", color = colors.red)
                }
            }
        }
    }
}

// ==================== EQUALIZER GỐC ĐÃ TÍCH HỢP ====================
// Lớp hỗ trợ đa ngôn ngữ cục bộ cho EqualizerPanel
private class EqLocalStrings(val lang: String) {
    fun custom() = when(lang) { "en" -> "Custom"; "zh" -> "自定义"; "ja" -> "カスタム"; "ko" -> "맞춤"; "es" -> "Personalizado"; "fr" -> "Personnalisé"; "ru" -> "Польз."; else -> "Tùy chỉnh" }
    fun advanced() = when(lang) { "en" -> "Advanced (5 bands)"; "zh" -> "高级 (5频段)"; "ja" -> "高度 (5バンド)"; "ko" -> "고급 (5밴드)"; "es" -> "Avanzado (5 bandas)"; else -> "Nâng cao (5 băng tần)" }
    fun reset() = when(lang) { "en" -> "Reset"; "zh" -> "重置"; "ja" -> "リセット"; "ko" -> "초기화"; "es" -> "Restablecer"; "fr" -> "Réinitialiser"; else -> "Đặt lại" }
    fun advancedEq() = when(lang) { "en" -> "Advanced EQ"; "zh" -> "高级均衡器"; "ja" -> "高度なEQ"; "ko" -> "고급 EQ"; "es" -> "Ecualizador avanzado"; else -> "EQ nâng cao" }
    fun bandDesc() = when(lang) { "en" -> "5 bands · -6 dB to +6 dB"; "zh" -> "5频段 · -6 dB 至 +6 dB"; "ja" -> "5バンド · -6 dB 〜 +6 dB"; else -> "5 băng tần · -6 dB đến +6 dB" }
    fun flat() = when(lang) { "en" -> "Flat"; "zh" -> "平坦"; "ja" -> "フラット"; "ko" -> "평면"; "es" -> "Plano"; else -> "Đặt phẳng" }
    fun done() = when(lang) { "en" -> "Done"; "zh" -> "完成"; "ja" -> "完了"; "ko" -> "완료"; "es" -> "Hecho"; "fr" -> "Terminé"; else -> "Xong" }
    fun openFile() = when(lang) { "en" -> "Open file"; "zh" -> "打开文件"; "ja" -> "ファイルを開く"; "ko" -> "파일 열기"; else -> "Mở tệp" }
    fun close() = when(lang) { "en" -> "Close"; "zh" -> "关闭"; "ja" -> "閉じる"; "ko" -> "닫기"; else -> "Đóng" }
    fun errStartPlay() = when(lang) { "en" -> "Start playing music to enable EQ."; "zh" -> "开始播放音乐以启用EQ。"; else -> "Bắt đầu phát nhạc để kích hoạt EQ trên phiên âm thanh." }
    fun errNoFx() = when(lang) { "en" -> "Device does not provide AudioEffect."; "zh" -> "设备不提供AudioEffect。"; else -> "Thiết bị này chưa cung cấp AudioEffect cho phiên phát hiện tại." }
}

private data class EqPreset(
    val name: String,
    val bass: Int,
    val mid: Int,
    val treble: Int,
    val icon: ImageVector
)

@Composable
internal fun EqualizerPanel(
    audioSessionId: Int,
    onImportAudio: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalMusicColors.current
    val appLanguage = LocalAppLanguage.current
    val eqStrings = remember(appLanguage) { EqLocalStrings(appLanguage) }

    val eqPresets = remember(appStrings.lang) {
        listOf(
            EqPreset(eqStrings.custom(), 4, 2, 3, Icons.Rounded.Tune),
            EqPreset("Normal", 0, 0, 0, Icons.Rounded.Remove),
            EqPreset("Bass Boost", 6, 1, 5, Icons.Rounded.Speaker),
            EqPreset("Pop", 2, 1, 3, Icons.Rounded.Stars),
            EqPreset("Rock", 4, 0, 3, Icons.Rounded.ElectricBolt),
            EqPreset("Jazz", 1, 3, 4, Icons.Rounded.Piano),
            EqPreset("Classic", 0, 2, 3, Icons.Rounded.Album),
        )
    }

    var bass by rememberSaveable { mutableIntStateOf(4) }
    var mid by rememberSaveable { mutableIntStateOf(2) }
    var treble by rememberSaveable { mutableIntStateOf(3) }
    var selectedPresetIndex by rememberSaveable { mutableIntStateOf(0) }
    var loudnessEnabled by rememberSaveable { mutableStateOf(true) }
    var advancedMode by rememberSaveable { mutableStateOf(false) }
    var showAdvancedDialog by rememberSaveable { mutableStateOf(false) }

    var band60 by rememberSaveable { mutableIntStateOf(4) }
    var band230 by rememberSaveable { mutableIntStateOf(3) }
    var band910 by rememberSaveable { mutableIntStateOf(2) }
    var band3600 by rememberSaveable { mutableIntStateOf(2) }
    var band14000 by rememberSaveable { mutableIntStateOf(3) }

    val audioFxEngine = remember { AudioFxEngine() }
    var audioFxReady by remember { mutableStateOf(false) }

    LaunchedEffect(audioSessionId) {
        audioFxReady = audioFxEngine.attach(audioSessionId)
    }

    LaunchedEffect(
        audioFxReady, advancedMode, bass, mid, treble,
        band60, band230, band910, band3600, band14000, loudnessEnabled,
    ) {
        delay(100L)
        if (audioFxReady) {
            withContext(Dispatchers.IO) {
                if (advancedMode) {
                    audioFxEngine.applyFiveBand(
                        intArrayOf(band60, band230, band910, band3600, band14000),
                    )
                } else {
                    audioFxEngine.applyThreeBand(bass, mid, treble)
                }
                audioFxEngine.setLoudness(loudnessEnabled)
            }
        }
    }

    DisposableEffect(audioFxEngine) {
        onDispose { audioFxEngine.release() }
    }

    fun selectPreset(index: Int, preset: EqPreset) {
        selectedPresetIndex = index
        advancedMode = false
        if (index != 0) {
            bass = preset.bass
            mid = preset.mid
            treble = preset.treble
        }
    }

    fun updateBass(value: Int) {
        bass = value.coerceIn(-6, 6)
        selectedPresetIndex = 0
        advancedMode = false
    }

    fun updateMid(value: Int) {
        mid = value.coerceIn(-6, 6)
        selectedPresetIndex = 0
        advancedMode = false
    }

    fun updateTreble(value: Int) {
        treble = value.coerceIn(-6, 6)
        selectedPresetIndex = 0
        advancedMode = false
    }

    fun resetEqualizer() {
        bass = 0
        mid = 0
        treble = 0
        band60 = 0
        band230 = 0
        band910 = 0
        band3600 = 0
        band14000 = 0
        selectedPresetIndex = 1
        advancedMode = false
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        shape = RoundedCornerShape(18.dp),
        color = palette.card.copy(alpha = 0.94f),
        border = BorderStroke(1.dp, palette.border),
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp).fillMaxSize()) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = null,
                        tint = palette.textSecondary,
                        modifier = Modifier.size(26.dp),
                    )
                    Text(
                        text = "Equalizer",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(end = 2.dp),
            ) {
                itemsIndexed(eqPresets, key = { _, it -> it.name }) { index, preset ->
                    PresetChip(
                        label = preset.name,
                        icon = preset.icon,
                        selected = selectedPresetIndex == index,
                        onClick = { selectPreset(index, preset) },
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Row(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Top,
            ) {
                EqControlColumn(
                    label = "BASS",
                    value = bass,
                    onValueChange = ::updateBass,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
                EqControlColumn(
                    label = "MID",
                    value = mid,
                    onValueChange = ::updateMid,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
                EqControlColumn(
                    label = "TREBLE",
                    value = treble,
                    onValueChange = ::updateTreble,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(
                    onClick = {
                        if (!advancedMode) {
                            band60 = bass
                            band230 = ((bass + mid) / 2f).roundToInt()
                            band910 = mid
                            band3600 = ((mid + treble) / 2f).roundToInt()
                            band14000 = treble
                        }
                        showAdvancedDialog = true
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.border),
                    contentPadding = PaddingValues(
                        horizontal = 12.dp,
                        vertical = 7.dp,
                    ),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = palette.purpleBright,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = eqStrings.advanced(),
                        color = palette.textPrimary,
                        fontSize = 12.sp,
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(
                    onClick = ::resetEqualizer,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.border),
                    contentPadding = PaddingValues(
                        horizontal = 11.dp,
                        vertical = 7.dp,
                    ),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.RestartAlt,
                        contentDescription = null,
                        tint = palette.textSecondary,
                        modifier = Modifier.size(17.dp),
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = eqStrings.reset(),
                        color = palette.textPrimary,
                        fontSize = 12.sp,
                    )
                }
            }

            if (audioSessionId <= 0 || !audioFxReady) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (audioSessionId <= 0) eqStrings.errStartPlay() else eqStrings.errNoFx(),
                    color = palette.textMuted,
                    fontSize = 11.sp,
                )
            }
        }
    }

    if (showAdvancedDialog) {
        AdvancedEqDialog(
            values = listOf(band60, band230, band910, band3600, band14000),
            eqStrings = eqStrings,
            onValueChange = { index, value ->
                when (index) {
                    0 -> band60 = value
                    1 -> band230 = value
                    2 -> band910 = value
                    3 -> band3600 = value
                    4 -> band14000 = value
                }
                advancedMode = true
                selectedPresetIndex = 0
            },
            onFlat = {
                band60 = 0
                band230 = 0
                band910 = 0
                band3600 = 0
                band14000 = 0
                advancedMode = true
                selectedPresetIndex = 0
            },
            onDismiss = { showAdvancedDialog = false },
        )
    }
}

@Composable
private fun PresetChip(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val palette = LocalMusicColors.current
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(9.dp),
        color = if (selected) palette.purple else palette.cardRaised,
        border = BorderStroke(
            1.dp,
            if (selected) palette.purpleBright else palette.borderSoft,
        ),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Color.White else palette.textSecondary,
                modifier = Modifier.size(15.dp)
            )
            Text(
                text = label,
                color = if (selected) Color.White else palette.textPrimary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun EqControlColumn(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalMusicColors.current
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = label,
            color = palette.textPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
        Spacer(modifier = Modifier.height(8.dp))
        VerticalEqFader(
            label = label,
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .width(60.dp)
                .weight(1f),
        )
        Spacer(modifier = Modifier.height(8.dp))
        RotaryKnob(
            label = label,
            value = value,
            onValueChange = onValueChange,
        )
    }
}

@Composable
private fun VerticalEqFader(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalMusicColors.current
    val density = LocalDensity.current
    var heightPx by remember { mutableFloatStateOf(1f) }
    val topPaddingPx = with(density) { 18.dp.toPx() }
    val bottomPaddingPx = with(density) { 18.dp.toPx() }

    fun valueForY(y: Float): Int {
        val trackHeight = max(1f, heightPx - topPaddingPx - bottomPaddingPx)
        val normalizedFromTop = ((y - topPaddingPx) / trackHeight).coerceIn(0f, 1f)
        return (6f - normalizedFromTop * 12f).roundToInt().coerceIn(-6, 6)
    }

    Box(
        modifier = modifier
            .onSizeChanged { heightPx = it.height.toFloat() }
            .semantics {
                contentDescription = "$label ${formatDb(value)} dB"
            }
            .pointerInput(heightPx, onValueChange) {
                detectTapGestures { offset ->
                    onValueChange(valueForY(offset.y))
                }
            }
            .pointerInput(heightPx, onValueChange, value) {
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        onValueChange(valueForY(offset.y))
                    },
                    onVerticalDrag = { change, _ ->
                        onValueChange(valueForY(change.position.y))
                        change.consume()
                    },
                )
            },
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val x = size.width * 0.66f
            val top = 18.dp.toPx()
            val bottom = size.height - 18.dp.toPx()
            val centerY = (top + bottom) / 2f
            val normalized = (value + 6f) / 12f
            val thumbY = bottom - normalized * (bottom - top)

            drawLine(
                color = palette.border,
                start = Offset(x, top),
                end = Offset(x, bottom),
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round,
            )

            drawLine(
                brush = Brush.verticalGradient(
                    colors = listOf(palette.purpleBright, palette.blue),
                    startY = top,
                    endY = bottom,
                ),
                start = Offset(x, thumbY),
                end = Offset(x, bottom),
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round,
            )

            for (tick in 0..12) {
                val y = top + (bottom - top) * (tick / 12f)
                val isMajor = tick == 0 || tick == 6 || tick == 12
                val tickHalfWidth = if (isMajor) 13.dp.toPx() else 6.dp.toPx()
                drawLine(
                    color = if (isMajor) palette.border else palette.borderSoft,
                    start = Offset(x - tickHalfWidth, y),
                    end = Offset(x + tickHalfWidth, y),
                    strokeWidth = if (isMajor) 1.2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }

            drawLine(
                color = palette.border,
                start = Offset(size.width * 0.22f, centerY),
                end = Offset(size.width * 0.96f, centerY),
                strokeWidth = 1.dp.toPx(),
            )

            drawCircle(
                color = palette.purple.copy(alpha = 0.18f),
                radius = 14.dp.toPx(),
                center = Offset(x, thumbY),
            )
            drawCircle(
                color = Color.White,
                radius = 9.dp.toPx(),
                center = Offset(x, thumbY),
            )
            drawCircle(
                color = if(palette.isDark) Color(0xFFD8DFEA) else Color.Gray,
                radius = 9.dp.toPx(),
                center = Offset(x, thumbY),
                style = Stroke(width = 1.dp.toPx()),
            )
        }

        Text(
            text = "+6dB",
            color = palette.textSecondary,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.TopStart),
        )
        Text(
            text = "0dB",
            color = palette.textPrimary,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterStart),
        )
        Text(
            text = "-6dB",
            color = palette.textSecondary,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.BottomStart),
        )
    }
}

@Composable
private fun RotaryKnob(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
) {
    val palette = LocalMusicColors.current
    Box(
        modifier = Modifier
            .size(68.dp)
            .semantics {
                contentDescription = "Núm $label ${formatDb(value)} dB"
            }
            .pointerInput(value, onValueChange) {
                var accumulatedDrag = 0f

                detectDragGestures { change, dragAmount ->
                    val delta = (dragAmount.x - dragAmount.y) / 12f
                    accumulatedDrag += delta

                    val intDelta = accumulatedDrag.roundToInt()
                    if (intDelta != 0) {
                        onValueChange((value + intDelta).coerceIn(-6, 6))
                        accumulatedDrag -= intDelta
                    }
                    change.consume()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(68.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension * 0.42f
            val startAngle = 135f
            val totalSweep = 270f
            val normalized = (value + 6f) / 12f
            val activeSweep = totalSweep * normalized

            for (tick in 0..24) {
                val angle = startAngle + totalSweep * (tick / 24f)
                val radians = angle * PI.toFloat() / 180f
                val outer = radius * 1.22f
                val inner = radius * if (tick % 4 == 0) 1.06f else 1.11f
                val start = Offset(
                    x = center.x + cos(radians) * inner,
                    y = center.y + sin(radians) * inner,
                )
                val end = Offset(
                    x = center.x + cos(radians) * outer,
                    y = center.y + sin(radians) * outer,
                )
                drawLine(
                    color = if (tick / 24f <= normalized) {
                        palette.purpleBright
                    } else {
                        palette.textMuted
                    },
                    start = start,
                    end = end,
                    strokeWidth = if (tick % 4 == 0) 2.dp.toPx() else 1.3.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }

            drawArc(
                color = palette.border,
                startAngle = startAngle,
                sweepAngle = totalSweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(palette.purple, palette.blue, palette.purple),
                    center = center,
                ),
                startAngle = startAngle,
                sweepAngle = activeSweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = if(palette.isDark) listOf(Color(0xFF172437), Color(0xFF07111E)) else listOf(palette.backgroundSoft, palette.background),
                    center = center,
                    radius = radius,
                ),
                radius = radius * 0.88f,
                center = center,
            )
            drawCircle(
                color = palette.textMuted,
                radius = radius * 0.88f,
                center = center,
                style = Stroke(width = 1.dp.toPx()),
            )

            val indicatorAngle = (startAngle + activeSweep) * PI.toFloat() / 180f
            val indicatorCenter = Offset(
                x = center.x + cos(indicatorAngle) * radius * 0.64f,
                y = center.y + sin(indicatorAngle) * radius * 0.64f,
            )
            drawCircle(
                color = if(palette.isDark) Color.White else palette.purpleBright,
                radius = 2.3.dp.toPx(),
                center = indicatorCenter,
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = formatDb(value),
                color = palette.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun AdvancedEqDialog(
    values: List<Int>,
    eqStrings: EqLocalStrings,
    onValueChange: (index: Int, value: Int) -> Unit,
    onFlat: () -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalMusicColors.current
    val labels = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            shape = RoundedCornerShape(22.dp),
            color = palette.card,
            border = BorderStroke(1.dp, palette.border),
            shadowElevation = 20.dp,
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = palette.purpleBright,
                        )
                        Column {
                            Text(
                                text = eqStrings.advancedEq(),
                                color = palette.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = eqStrings.bandDesc(),
                                color = palette.textSecondary,
                                fontSize = 11.sp,
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = eqStrings.close(),
                            tint = palette.textSecondary,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                labels.forEachIndexed { index, label ->
                    AdvancedBandRow(
                        label = label,
                        value = values.getOrElse(index) { 0 },
                        onValueChange = { onValueChange(index, it) },
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = onFlat) {
                        Text(
                            text = eqStrings.flat(),
                            color = palette.textSecondary,
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.purple,
                            contentColor = Color.White,
                        ),
                    ) {
                        Text(eqStrings.done())
                    }
                }
            }
        }
    }
}

@Composable
private fun AdvancedBandRow(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
) {
    val palette = LocalMusicColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = palette.textPrimary,
            fontSize = 12.sp,
            modifier = Modifier.width(58.dp),
        )
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.roundToInt().coerceIn(-6, 6)) },
            valueRange = -6f..6f,
            steps = 11,
            colors = SliderDefaults.colors(
                thumbColor = if(palette.isDark) Color.White else palette.purple,
                activeTrackColor = palette.purple,
                inactiveTrackColor = palette.border,
            ),
            modifier = Modifier.weight(1f),
        )
        Text(
            text = "${formatDb(value)} dB",
            color = palette.purpleBright,
            fontSize = 11.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(56.dp),
        )
    }
}

private fun formatDb(value: Int): String = if (value > 0) "+$value" else value.toString()

private class AudioFxEngine {
    private var equalizer: AndroidEqualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var bassBoost: BassBoost? = null
    private var sessionId: Int = 0

    fun attach(newSessionId: Int): Boolean {
        if (newSessionId <= 0) {
            release()
            return false
        }
        if (newSessionId == sessionId && (equalizer != null || loudnessEnhancer != null || bassBoost != null)) {
            return true
        }

        release()
        sessionId = newSessionId

        equalizer = runCatching {
            AndroidEqualizer(0, newSessionId).apply {
                enabled = true
            }
        }.getOrNull()

        loudnessEnhancer = runCatching {
            LoudnessEnhancer(newSessionId).apply {
                setTargetGain(600)
                enabled = false
            }
        }.getOrNull()

        bassBoost = runCatching {
            BassBoost(0, newSessionId).apply {
                enabled = true
            }
        }.getOrNull()

        return equalizer != null || loudnessEnhancer != null || bassBoost != null
    }

    private fun applyHardwareBass(bassValue: Int) {
        val effect = bassBoost ?: return
        runCatching {
            if (bassValue > 0) {
                effect.enabled = true
                val strength = ((bassValue / 6f) * 1000f).coerceIn(0f, 1000f).toInt().toShort()
                effect.setStrength(strength)
            } else {
                effect.enabled = false
            }
        }
    }

    fun applyThreeBand(bass: Int, mid: Int, treble: Int) {
        applyHardwareBass(bass)

        val effect = equalizer ?: return
        val levelRange = runCatching { effect.bandLevelRange }.getOrNull() ?: return
        if (levelRange.size < 2) return
        val minimumLevel = levelRange[0].toInt()
        val maximumLevel = levelRange[1].toInt()
        val bandCount = runCatching { effect.numberOfBands.toInt() }.getOrDefault(0)

        for (bandIndex in 0 until bandCount) {
            val band = bandIndex.toShort()
            val centerHz = runCatching { effect.getCenterFreq(band) / 1000f }.getOrDefault(0f)
            val desiredDb = when {
                centerHz < 300f -> bass
                centerHz < 4000f -> mid
                else -> treble
            }
            val desiredMillibels = (desiredDb * 100).coerceIn(minimumLevel, maximumLevel)
            runCatching {
                effect.setBandLevel(band, desiredMillibels.toShort())
            }
        }
    }

    fun applyFiveBand(values: IntArray) {
        if (values.isNotEmpty()) {
            applyHardwareBass(values[0])
        }

        val effect = equalizer ?: return
        if (values.size < 5) return
        val levelRange = runCatching { effect.bandLevelRange }.getOrNull() ?: return
        if (levelRange.size < 2) return
        val minimumLevel = levelRange[0].toInt()
        val maximumLevel = levelRange[1].toInt()
        val targetFrequencies = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
        val bandCount = runCatching { effect.numberOfBands.toInt() }.getOrDefault(0)

        for (bandIndex in 0 until bandCount) {
            val band = bandIndex.toShort()
            val centerHz = runCatching { effect.getCenterFreq(band) / 1000f }.getOrDefault(1f)
            val closestTarget = targetFrequencies.indices.minByOrNull { targetIndex ->
                abs(ln(max(centerHz, 1f).toDouble() / targetFrequencies[targetIndex].toDouble()))
            } ?: 0
            val desiredMillibels = (values[closestTarget] * 100)
                .coerceIn(minimumLevel, maximumLevel)
            runCatching {
                effect.setBandLevel(band, desiredMillibels.toShort())
            }
        }
    }

    fun setLoudness(enabled: Boolean) {
        val effect = loudnessEnhancer ?: return
        runCatching {
            effect.setTargetGain(600)
            effect.enabled = enabled
        }
    }

    fun release() {
        runCatching { equalizer?.enabled = false }
        runCatching { loudnessEnhancer?.enabled = false }
        runCatching { bassBoost?.enabled = false }
        runCatching { equalizer?.release() }
        runCatching { loudnessEnhancer?.release() }
        runCatching { bassBoost?.release() }
        equalizer = null
        loudnessEnhancer = null
        bassBoost = null
        sessionId = 0
    }
}
