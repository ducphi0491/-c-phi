@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ================================================
echo AudioSheet - CAI AI NANG CAO (Windows / WSL2)
echo ================================================
echo.
echo [1] Pop2Piano       - Ubuntu/WSL2 (chua ho tro Server 2019)
echo [2] SheetSage2      - WINDOWS CPU, KHONG CAN WSL2
echo [3] Ca hai          - SheetSage2 Windows + Pop2Piano WSL2
echo [Q] Thoat
echo.
choice /c 123Q /n /m "Chon 1, 2, 3 hoac Q: "
if errorlevel 4 exit /b 0
if errorlevel 3 goto :both
if errorlevel 2 goto :sheet
goto :pop
:sheet
call "%~dp0CAI_SHEETSAGE2_WINDOWS.bat"
exit /b %ERRORLEVEL%
:both
call "%~dp0CAI_SHEETSAGE2_WINDOWS.bat"
if errorlevel 1 exit /b 1
echo.
echo [NEXT] Cai Pop2Piano voi Ubuntu/WSL2 (neu Windows ho tro).
:pop
where wsl.exe >nul 2>&1
if errorlevel 1 goto :no_wsl
set "WSL_SCRIPT="
for /f "usebackq delims=" %%P in (`wsl.exe --exec wslpath -a -u "%~dp0scripts\install_advanced_ai.sh"`) do set "WSL_SCRIPT=%%P"
if not defined WSL_SCRIPT goto :no_wsl
echo.
echo Dang cai Pop2Piano trong Ubuntu. Khong thay doi .venv.
wsl.exe --exec /bin/bash "%WSL_SCRIPT%" pop2piano
if errorlevel 1 goto :failed
 echo [OK] Pop2Piano environment installed.
pause
exit /b 0
:no_wsl
echo [LOI] Pop2Piano can WSL2/Ubuntu.
echo Windows Server 2019 KHONG ho tro WSL2; SheetSage2 van co the cai truc tiep voi lua chon 2.
pause
exit /b 1
:failed
echo [LOI] Pop2Piano install failed. Check Ubuntu/WSL2, ffmpeg and pip.
pause
exit /b 1
