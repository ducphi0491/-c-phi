@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo =============================================================
echo  AudioSheet - SheetSage2 (WINDOWS NATIVE CPU - KHONG CAN WSL)
echo =============================================================
echo.
echo Windows Server 2019 / Python 3.10 hoac 3.11 (64 bit).
echo Chi cai vao .sheetsage2-venv, khong sua .venv hay .demucs-venv.
echo Model weights: CC BY-NC 4.0, chi nghien cuu PHI THUONG MAI.
echo Model tai them hang GB khi chay lan dau.
echo.
choice /c YN /m "Xac nhan chi su dung cho nghien cuu phi thuong mai (Y/N)?"
if errorlevel 2 exit /b 1
echo.
where py >nul 2>&1
if errorlevel 1 goto :try_python
py -3.11 --version >nul 2>&1
if not errorlevel 1 (
  py -3.11 "%~dp0scripts\install_sheetsage2_windows.py"
  goto :result
)
py -3.10 --version >nul 2>&1
if not errorlevel 1 (
  py -3.10 "%~dp0scripts\install_sheetsage2_windows.py"
  goto :result
)
:try_python
where python >nul 2>&1
if errorlevel 1 goto :try_existing
python -c "import sys; sys.exit(0 if sys.version_info[:2] in [(3,10),(3,11)] else 1)" >nul 2>&1
if not errorlevel 1 (
  python "%~dp0scripts\install_sheetsage2_windows.py"
  goto :result
)
:try_existing
if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" "%~dp0scripts\install_sheetsage2_windows.py"
  goto :result
)
echo [LOI] Khong tim thay Python 3.10/3.11 (64 bit).
echo Hay cai Python 3.11 nhu website AudioSheet hien tai.
pause
exit /b 2
:result
if errorlevel 1 goto :failed
echo.
echo [OK] Cai dat thu vien SheetSage2 hoan tat.
echo Khoi dong lai CHAY_WEBSITE.bat va chon SheetSage2 trong trang web.
echo Kiem tra nhanh bang KIEM_TRA_SHEETSAGE2_WINDOWS.bat.
pause
exit /b 0
:failed
echo.
echo [LOI] Cai dat that bai. Xem logs\sheetsage2-install.log.
echo Kiem tra FFmpeg PATH, ket noi Internet va Python 64 bit.
pause
exit /b 1
