@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo  Kiem tra SheetSage2 - Windows Native CPU
 echo ============================================================
echo.
if not exist ".sheetsage2-venv\Scripts\python.exe" (
  echo [CHUA CAI] Chay CAI_SHEETSAGE2_WINDOWS.bat truoc.
  pause
  exit /b 1
)
".sheetsage2-venv\Scripts\python.exe" "scripts\check_sheetsage2_windows.py" %*
set "CHECK_EXIT=%ERRORLEVEL%"
echo.
if "%CHECK_EXIT%"=="0" (
  echo [OK] Cac thu vien CPU phu hop. Chua dam bao model da tai.
) else (
  echo [LOI] Kiem tra that bai. Doc thong bao ben tren.
)
echo Muon tai/kiem tra checkpoint that: goi BAT nay voi tham so --load-model.
pause
exit /b %CHECK_EXIT%
