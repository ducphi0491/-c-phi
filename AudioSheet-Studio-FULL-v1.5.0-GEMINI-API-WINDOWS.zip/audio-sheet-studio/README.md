# AudioSheet Studio v1.5.0 – Gemini API Harmony Assistant (Windows Server 2019)

**Gemini API is an optional cloud harmony/structure assistant, NOT a replacement for exact note-to-MIDI transcription.** For the Windows Server 2019 setup:

1. Overlay this ZIP on `C:\audio-sheet-studio` without deleting existing `.venv`, `.demucs-venv`, `data` or `web\piano_samples`.
2. Run `CAI_GEMINI_API.bat` (one-time lightweight dependency install), edit `.env` and add `GEMINI_API_KEY` from [Google AI Studio](https://aistudio.google.com/apikey). Never share the key.
3. Run `KIEM_TRA_GEMINI.bat` to validate configuration and optionally test Google API connectivity, then open `CHAY_GEMINI.bat`.
4. On the website, select **Gemini API – harmony/structure** and explicitly consent to the audio upload. Keep Basic Pitch as engine A and AudioSheet heuristic as engine B. PDF, MIDI, MusicXML and piano audio follow B's validated chords.
5. Compare `gemini_analysis.json` (Gemini estimates) with `analysis.json` (validated chords) and the `Engine THUC TE` label. On error or unreliable guesses, AudioSheet intentionally falls back to local chords with a warning.

This requires an Internet connection, a user-provided Google API key and API quota. **No WSL2, Ubuntu, large model checkpoints or NVIDIA GPU are needed for Gemini**. Core Basic Pitch, Beat This!, Demucs (if enabled), piano samples, OSMD and PDF exporter are unchanged. A/C note output remains based on the local transcriber. The API sends a compressed mono MP3 for analysis and attempts to delete its remote Files API upload afterward; file storage may persist according to Google's retention policy.

**Validation:** Local Python/JS/API/MIDI/MusicXML/PDF integration tests use mocked Gemini responses; no live Google account, real model inference or improvement against Ledutu was verified. Model availability can vary by account: change `GEMINI_MODEL` in `.env` if necessary. Current default `gemini-3.8-flash` follows Google's model guidance as of Nov 2026.

Full setup guide: `HUONG_DAN_GEMINI_V1.5.0.txt`.

---

# AudioSheet Studio v1.4.1 - SheetSage2 Native Windows (stage 1)

AudioSheet Studio converts permitted audio into piano sheet/MIDI/MusicXML/PDF on a local FastAPI website. Version 1.4.1 updates **only the optional SheetSage2 integration for Windows Server 2019** and keeps the entire existing A/B/C pipeline.

## Windows Server 2019, Xeon, 32GB, GTX 1060

1. Stop the website with Ctrl+C, unpack the FULL ZIP **on top of** `C:\audio-sheet-studio` (do not delete the old directory).
2. Keep `.venv`, `.demucs-venv`, `data` and `web\piano_samples` untouched.
3. Double-click `CAI_AI_NANG_CAO.bat` and choose **2**, or open `CAI_SHEETSAGE2_WINDOWS.bat` directly. A 64-bit Python 3.10/3.11 and FFmpeg must already be installed. No WSL/Ubuntu required for SheetSage2.
4. The installer creates only `.sheetsage2-venv` and installs CPU PyTorch/SheetSage2 Python dependencies. Models are **not** downloaded until your first analysis.
5. Restart `CHAY_WEBSITE.bat`, refresh your browser with Ctrl+F5, choose A = SheetSage2, confirm **non-commercial research**, and submit audio you are allowed to process.
6. Look at `Engine THUC TE` in the result. A successful run should show `A = sheetsage2`; otherwise read the clearly flagged fallback and `data\jobs\<id>\advanced_ai\sheetsage2\model.log`.

Quick dependency check: `KIEM_TRA_SHEETSAGE2_WINDOWS.bat`.
The advanced installer logs to `logs\sheetsage2-install.log`.

**Important limitations:** Checkpoint weights are CC BY-NC 4.0 and the parent MERT-v2 model has its own terms. This is a research-only feature, not a licensed production/commercial endpoint. The upstream Python code is executed with `trust_remote_code=True`. Model download/loading on Windows Server 2019 and the real quality advantage over Basic Pitch/ledutu are **not verified on the user's machine**. Actual inference may require significant RAM and time. No AI checkpoint, FFmpeg binary or licensed model weights are bundled in this project ZIP.

## Unchanged pipelines

- A default: Basic Pitch vocal melody. A optional: SheetSage2 melody and chord analysis (with A MIDI and dynamic PDF).
- B default: heuristic arrangement Easy/Standard/Full. B optional: Pop2Piano requires Linux/WSL2, **not available on Windows Server 2019** through this installer.
- C: Basic Pitch stem transcription, unchanged.
- Rhythm: Beat This! with fallback; Demucs separation; Salamander piano samples; OSMD and Chrome/Edge PDF.
- Existing data and stored jobs are preserved.

See `HUONG_DAN_V1.4.1_WINDOWS.txt` for troubleshooting and notes.
