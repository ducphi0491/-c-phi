(() => {
  "use strict";

  const params = new URLSearchParams(location.search);
  const jobId = params.get("job") || "";
  const mode = params.get("mode") || "light_standard";
  const autoPrint = params.get("auto") !== "0";
  const letter = mode === "melody" ? "A" : mode === "full" ? "C" : "B";
  const labels = {
    melody: "A · Giai điệu hát",
    light: "B · Piano Tiêu chuẩn",
    light_easy: "B · Piano Dễ",
    light_standard: "B · Piano Tiêu chuẩn",
    light_full: "B · Piano Đầy đủ",
    full: "C · Phiên âm đầy đủ",
  };
  const status = document.getElementById("status");
  const score = document.getElementById("score");
  const title = `AudioSheet_${letter}_${mode}`;

  document.title = title;
  document.getElementById("viewTitle").textContent = `${labels[mode] || mode} · PDF giống trên web`;
  document.getElementById("printButton").addEventListener("click", () => window.print());
  document.getElementById("closeButton").addEventListener("click", () => window.close());

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`Không tải được ${src}`));
      document.head.appendChild(script);
    });
  }

  async function ensureOsmd() {
    if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
    await loadScript("https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.1.3/build/opensheetmusicdisplay.min.js");
    if (!window.opensheetmusicdisplay) throw new Error("OpenSheetMusicDisplay chưa sẵn sàng");
    return window.opensheetmusicdisplay;
  }

  async function render() {
    try {
      if (!jobId) throw new Error("Thiếu mã tác vụ");
      const osmdLibrary = await ensureOsmd();
      const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}/playback-score/${encodeURIComponent(mode)}`, { cache: "no-store" });
      if (!response.ok) {
        let message = `HTTP ${response.status}`;
        try {
          const payload = await response.json();
          if (payload && payload.detail) message = payload.detail;
        } catch (_) {}
        throw new Error(message);
      }
      const xml = await response.text();
      const osmd = new osmdLibrary.OpenSheetMusicDisplay(score, {
        autoResize: false,
        backend: "svg",
        drawTitle: true,
        drawComposer: true,
        drawingParameters: "compacttight",
        pageFormat: "A4_P",
      });
      osmd.Zoom = 0.76;
      await osmd.load(xml);
      osmd.render();
      if (document.fonts && document.fonts.ready) await document.fonts.ready;
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      status.textContent = "Khuông nhạc đã sẵn sàng. Chọn Save as PDF / Lưu thành PDF trong cửa sổ in.";
      window.__AUDIOSHEET_PRINT_READY__ = true;
      if (autoPrint) window.setTimeout(() => window.print(), 450);
    } catch (error) {
      status.classList.add("error");
      status.textContent = "Không thể dựng PDF giống giao diện web: " + (error.message || String(error));
    }
  }

  render();
})();
