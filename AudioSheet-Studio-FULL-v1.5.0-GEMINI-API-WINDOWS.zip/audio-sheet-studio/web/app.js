(() => {
  "use strict";

  const form = document.getElementById("transcriptionForm");
  const audioFile = document.getElementById("audioFile");
  const youtubeUrl = document.getElementById("youtubeUrl");
  const dropZone = document.getElementById("dropZone");
  const fileLabel = document.getElementById("fileLabel");
  const submitButton = document.getElementById("submitButton");
  const demoButton = document.getElementById("demoButton");
  const jobSection = document.getElementById("jobSection");
  const resultSection = document.getElementById("resultSection");
  const toast = document.getElementById("toast");

  let activeSource = "upload";
  let currentJobId = null;
  let pollToken = 0;
  let osmd = null;
  let osmdPromise = null;
  let scoreRenderToken = 0;
  let lastJobForScore = null;
  let zoom = 1.0;
  let playbackData = null;
  let playbackMode = 'light_standard';
  let selectedBMode = 'light_standard';
  const B_MODES = new Set(['light_easy', 'light_standard', 'light_full']);
  let userSeeking = false;
  const pianoPlay = document.getElementById('pianoPlay');
  const pianoStop = document.getElementById('pianoStop');
  const pianoTest = document.getElementById('pianoTest');
  const pianoSeek = document.getElementById('pianoSeek');
  const pianoStatus = document.getElementById('playbackStatus');
  const pianoTime = document.getElementById('pianoTime');
  const pianoSoundStatus = document.getElementById('pianoSoundStatus');
  const activeSheetDownload = document.getElementById('activeSheetDownload');
  const activeMidiDownload = document.getElementById('activeMidiDownload');
  const activePdfDownload = document.getElementById('activePdfDownload');
  const referenceMidiFile = document.getElementById('referenceMidiFile');
  const removeReference = document.getElementById('clearReferenceMidi');
  const pianoPlayer = new window.AudioSheetPianoPlayer({
    onUpdate: ({ time, duration, playing }) => {
      pianoPlay.textContent = playing ? '❚❚ Tạm dừng' : '▶ Phát piano';
      pianoTime.textContent = `${formatTime(time)} / ${formatTime(duration)}`;
      if (!userSeeking) pianoSeek.value = String(duration ? Math.round(1000 * time / duration) : 0);
    },
    onLoading: ({ message, failed }) => {
      pianoSoundStatus.textContent = message;
      pianoSoundStatus.classList.toggle('warning', !!failed);
    },
  });

  function formatTime(seconds) {
    const value = Math.max(0, Math.floor(seconds || 0));
    return `${Math.floor(value / 60)}:${String(value % 60).padStart(2, '0')}`;
  }

  function normalizePlaybackMode(mode) {
    return mode === 'light' ? 'light_standard' : mode;
  }

  function isBMode(mode) {
    return B_MODES.has(normalizePlaybackMode(mode));
  }

  function modeLetter(mode) {
    mode = normalizePlaybackMode(mode);
    return mode === 'melody' ? 'A' : mode === 'full' ? 'C' : 'B';
  }

  function modeLabel(mode) {
    mode = normalizePlaybackMode(mode);
    return {
      melody: 'A · Giai điệu hát',
      light_easy: 'B · Piano Dễ',
      light_standard: 'B · Piano Tiêu chuẩn',
      light_full: 'B · Piano Đầy đủ',
      full: playbackData && playbackData.reference_active ? 'C · MIDI tham chiếu' : 'C · Phiên âm đầy đủ',
    }[mode] || mode;
  }

  function choosePlaybackMode(mode) {
    mode = normalizePlaybackMode(mode);
    if (!playbackData || !playbackData.modes || !playbackData.modes[mode]) return;
    if (isBMode(mode)) selectedBMode = mode;
    playbackMode = mode;
    document.querySelectorAll('.playback-mode').forEach(label => {
      const groupB = label.dataset.playbackGroup === 'B';
      const selected = groupB ? isBMode(mode) : normalizePlaybackMode(label.dataset.playbackMode) === mode;
      label.classList.toggle('selected', selected);
      const radio = label.querySelector('input');
      if (radio) radio.checked = selected;
    });
    document.querySelectorAll('[data-b-mode]').forEach(button => {
      button.classList.toggle('selected', button.dataset.bMode === mode);
    });
    const chosen = playbackData.modes[mode];
    pianoPlayer.setNotes(chosen.notes, playbackData.duration_seconds, mode);
    pianoPlay.disabled = chosen.notes.length === 0;
    pianoStop.disabled = chosen.notes.length === 0;
    pianoSeek.disabled = chosen.notes.length === 0;
    pianoStatus.textContent = `${chosen.count.toLocaleString('vi-VN')} nốt`;
    if (currentJobId && lastJobForScore === currentJobId) {
      renderArrangementSheet(currentJobId, mode);
    }
    const hints = {
      melody: 'A: giai điệu được rút từ vocal stem, làm sạch nốt vụn và hiển thị trên một khuông.',
      light_easy: 'B Dễ: melody + nốt gốc/quãng 5 tay trái, ít nốt và dễ tập.',
      light_standard: 'B Tiêu chuẩn: thêm voicing tay phải, inversion và bass chuyển động có voice-leading.',
      light_full: 'B Đầy đủ: arpeggio tay trái, bè trong, chord voicing và fill từ stem nhạc cụ; gần piano arrangement hơn.',
    };
    const engineModes = playbackData.ai_engines || {};
    if (isBMode(mode) && engineModes.piano && engineModes.piano.used === 'pop2piano') {
      document.getElementById('playbackHint').textContent = 'B Pop2Piano: MIDI piano cover do model sinh; ba mức lọc mật độ từ cùng MIDI. Sheet, piano, MIDI và PDF dùng chung nốt.';
      return;
    }
    if (mode === 'melody' && engineModes.melody && engineModes.melody.used === 'sheetsage2') {
      document.getElementById('playbackHint').textContent = 'A SheetSage2: melody lấy từ model lead-sheet (chỉ dùng nghiên cứu phi thương mại).';
      return;
    }
    document.getElementById('playbackHint').textContent = hints[mode] || (
      playbackData.reference_active ? 'C: đang dùng MIDI tham chiếu; PDF và MusicXML C cũng được tạo lại từ MIDI này.' :
      playbackData.pipeline === 'stem_separated' ? 'C: ghép vocal, bass và nhạc cụ khác đã nhận dạng; trống không bị biến thành nốt piano.' :
      'C: tác vụ cũ hoặc không tách stem nên dùng toàn bộ nốt từ bản phối đầy đủ.'
    );
  }

  function refreshPlaybackPanel() {
    if (!playbackData) return;
    const modes = playbackData.modes || {};
    const getCount = mode => modes[mode] ? modes[mode].count : 0;
    document.getElementById('countMelody').textContent = `${getCount('melody').toLocaleString('vi-VN')} nốt`;
    document.getElementById('countFull').textContent = `${getCount('full').toLocaleString('vi-VN')} nốt`;
    const levelDescriptions = {
      light_easy: 'nốt · Dễ (theo engine B thực tế)',
      light_standard: 'nốt · Tiêu chuẩn (theo engine B thực tế)',
      light_full: 'nốt · Đầy đủ (theo engine B thực tế)',
    };
    for (const [id, mode] of [['countLightEasy','light_easy'], ['countLightStandard','light_standard'], ['countLightFull','light_full']]) {
      const element = document.getElementById(id);
      if (element) element.textContent = `${getCount(mode).toLocaleString('vi-VN')} ${levelDescriptions[mode]}`;
    }
    const selected = modes[selectedBMode] ? selectedBMode : modes.light_standard ? 'light_standard' : modes.light ? 'light' : 'melody';
    selectedBMode = normalizePlaybackMode(selected);
    const bSummary = document.getElementById('countLight');
    if (bSummary) bSummary.textContent = `${modeLabel(selectedBMode).replace('B · ', '')} · ${getCount(selectedBMode).toLocaleString('vi-VN')} nốt`;
    const active = playbackData.reference_active;
    document.getElementById('fullModeLabel').textContent = active ? 'C · MIDI tham chiếu' : 'C · Phiên âm đầy đủ';
    document.getElementById('midiComparisonText').textContent = active
      ? `C đang phát MIDI đối chiếu; đã căn nốt đầu (dịch ${playbackData.reference_offset_seconds || 0}s). Bấm 'Bỏ' để quay lại AI.`
      : 'C phát bản phiên âm đầy đủ. Có thể nạp MIDI tham chiếu để so sánh.';
    removeReference.classList.toggle('hidden', !active);
    if (!modes[normalizePlaybackMode(playbackMode)]) playbackMode = selectedBMode;
    choosePlaybackMode(playbackMode);
  }

  function clearPlaybackUi() {
    pianoPlayer.stop();
    playbackData = null;
    pianoPlay.disabled = true;
    pianoStop.disabled = true;
    pianoSeek.disabled = true;
    pianoSeek.value = '0';
    pianoStatus.textContent = 'Đang chuẩn bị';
    pianoSoundStatus.textContent = 'Nhấn Thử nốt C4 để kiểm tra tiếng piano thật độc lập với AI.';
    pianoSoundStatus.classList.remove('warning');
    lastJobForScore = null;
    scoreRenderToken++;
    [activeMidiDownload, activeSheetDownload, activePdfDownload].forEach(link => {
      if (link) {
        link.removeAttribute('href');
        delete link.dataset.printUrl;
        link.classList.add('hidden');
      }
    });
    document.getElementById('scoreModeTitle').textContent = 'Sheet nhạc đang chọn';
  }

  async function loadPlayback(job) {
    clearPlaybackUi();
    try {
      const payload = await requestJson(`/api/jobs/${job.id}/playback`);
      if (currentJobId !== job.id) return;
      playbackData = payload;
      lastJobForScore = job.id;
      refreshPlaybackPanel();
      const controls = document.getElementById('downloadButtons');
      ['melody', 'light_standard', 'full'].forEach((mode, i) => {
        const letter = ['A', 'B', 'C'][i];
        const definitions = [
          [`/api/jobs/${job.id}/playback-midi/${mode}`, `AudioSheet_${letter}_${mode}.mid`, `MIDI ${letter}`, 'playback-download', ''],
          [`/api/jobs/${job.id}/playback-score/${mode}`, `AudioSheet_${letter}_${mode}.musicxml`, `MusicXML ${letter}`, 'playback-download sheet-download', ''],
          [`/api/jobs/${job.id}/playback-pdf/${mode}`, `AudioSheet_${letter}_${mode}.pdf`, `PDF ${letter}`, 'playback-download pdf-download', `/static/print_score.html?job=${encodeURIComponent(job.id)}&mode=${encodeURIComponent(mode)}&auto=1`],
        ];
        definitions.forEach(([href, filename, label, className, printUrl]) => {
          const link = document.createElement('a');
          link.href = href;
          link.download = filename;
          link.textContent = label;
          link.className = className;
          if (printUrl) link.dataset.printUrl = printUrl;
          controls.appendChild(link);
        });
      });
      return true;
    } catch (error) {
      pianoStatus.textContent = 'Không tải được nốt';
      document.getElementById('playbackHint').textContent =
        `Không nạp được dữ liệu phát đàn: ${error.message || String(error)}. ` +
        'Sheet nhạc và các file xuất trước đó vẫn sử dụng bình thường.';
      return false;
    }
  }

  document.querySelectorAll('input[name="playback_mode"]').forEach(radio => {
    radio.addEventListener('change', () => {
      if (!radio.checked) return;
      choosePlaybackMode(radio.closest('[data-playback-group="B"]') ? selectedBMode : radio.value);
    });
  });
  document.querySelectorAll('[data-b-mode]').forEach(button => {
    button.addEventListener('click', () => choosePlaybackMode(button.dataset.bMode));
  });

  pianoPlay.addEventListener('click', async () => {
    try {
      if (pianoPlayer.isPlaying) {
        pianoPlayer.pause();
      } else {
        document.getElementById('audioPlayer').pause();
        pianoPlay.disabled = true;
        await pianoPlayer.play();
      }
    } catch (error) {
      showToast(`Khong the phat piano: ${error.message || error}`, true);
    } finally {
      pianoPlay.disabled = !(playbackData && playbackData.modes[playbackMode].notes.length);
    }
  });
  pianoStop.addEventListener('click', () => pianoPlayer.stop());
  // Test the actual recorded middle-C sample, independent of transcribed AI notes.
  if (pianoTest) pianoTest.addEventListener('click', async () => {
    pianoTest.disabled = true;
    try {
      document.getElementById('audioPlayer').pause();
      await pianoPlayer.audition();
    } catch (error) {
      pianoSoundStatus.textContent = 'Không phát được piano ghi âm: ' + (error.message || String(error));
      pianoSoundStatus.classList.add('warning');
      showToast('Kiểm tra tiếng piano: ' + (error.message || String(error)), true);
    } finally {
      pianoTest.disabled = false;
    }
  });
  pianoSeek.addEventListener('pointerdown', () => { userSeeking = true; });
  pianoSeek.addEventListener('pointerup', () => { window.setTimeout(() => { userSeeking = false; }, 50); });
  pianoSeek.addEventListener('input', () => {
    if (!playbackData) return;
    userSeeking = true;
    pianoTime.textContent = `${formatTime(Number(pianoSeek.value) / 1000 * pianoPlayer.duration)} / ${formatTime(pianoPlayer.duration)}`;
  });
  pianoSeek.addEventListener('change', async () => {
    userSeeking = false;
    try { await pianoPlayer.seek(Number(pianoSeek.value) / 1000 * pianoPlayer.duration); }
    catch (error) { showToast(error.message || String(error), true); }
  });
  pianoPlayer.setVolume(Number(document.getElementById('pianoVolume').value) / 100);
  document.getElementById('pianoVolume').addEventListener('input', event => {
    pianoPlayer.setVolume(Number(event.target.value) / 100);
    document.getElementById('pianoVolumeNumber').textContent = event.target.value + '%';
  });
  document.getElementById('audioPlayer').addEventListener('play', () => pianoPlayer.pause());

  referenceMidiFile.addEventListener('change', async () => {
    const midi = referenceMidiFile.files && referenceMidiFile.files[0];
    if (!midi || !currentJobId) return;
    if (midi.size > 4 * 1024 * 1024) {
      showToast('MIDI doi chieu phai nho hon 4 MB.', true);
      referenceMidiFile.value = '';
      return;
    }
    const jobId = currentJobId;
    try {
      pianoPlayer.stop();
      pianoStatus.textContent = 'Đang nạp MIDI';
      const data = new FormData();
      data.append('midi_file', midi);
      const payload = await requestJson(`/api/jobs/${jobId}/reference-midi`, { method: 'POST', body: data });
      if (currentJobId !== jobId) return;
      playbackData = payload;
      playbackMode = 'full';
      refreshPlaybackPanel();
      showToast('Da nap MIDI doi chieu. Bam Phat piano de nghe che do C.');
    } catch (error) {
      pianoStatus.textContent = 'Lỗi nạp MIDI';
      showToast(error.message || String(error), true);
    } finally {
      referenceMidiFile.value = '';
    }
  });

  removeReference.addEventListener('click', async () => {
    if (!currentJobId) return;
    const jobId = currentJobId;
    try {
      await fetch(`/api/jobs/${jobId}/reference-midi`, { method: 'DELETE' }).then(response => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
      });
      if (currentJobId !== jobId) return;
      playbackData = await requestJson(`/api/jobs/${jobId}/playback`);
      playbackMode = 'full';
      refreshPlaybackPanel();
      showToast('Da quay lai cac not AI o che do C.');
    } catch (error) { showToast(error.message || String(error), true); }
  });


  const statusRank = {
    queued: 0,
    fetching: 0,
    normalizing: 1,
    rhythm: 2,
    separating: 3,
    transcribing: 4,
    arranging: 5,
    exporting: 6,
    done: 7,
    failed: -1,
  };

  const statusText = {
    queued: "Đang chờ bộ xử lý",
    fetching: "Đang lấy nguồn âm thanh",
    normalizing: "Đang chuẩn hóa âm thanh",
    rhythm: "Beat This! đang tìm downbeat, ô lấy đà và đổi nhịp",
    separating: "Demucs đang tách vocal, bass, trống và nhạc đệm",
    transcribing: "AI đang nhận dạng nốt theo từng stem",
    arranging: "Đang tạo ba bản A/B/C",
    exporting: "Đang xuất MIDI, MusicXML và PDF",
    done: "Đã hoàn tất",
    failed: "Xử lý thất bại",
  };

  function showToast(message, isError = false) {
    toast.textContent = message;
    toast.classList.toggle("error", isError);
    toast.classList.add("show");
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3600);
  }

  async function requestJson(url, options = {}) {
    const response = await fetch(url, options);
    let payload = null;
    try {
      payload = await response.json();
    } catch (_) {
      payload = null;
    }
    if (!response.ok) {
      const message = payload && payload.detail ? payload.detail : `HTTP ${response.status}`;
      throw new Error(message);
    }
    return payload;
  }

  function downloadBlob(blob, filename) {
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = filename || "AudioSheet.pdf";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
  }

  async function fetchAndDownloadPdf(link) {
    const originalText = link.textContent;
    const printUrl = link.dataset.printUrl || '';
    // Open synchronously from the user's click so Chrome cannot block the exact
    // OSMD print fallback after the asynchronous PDF request finishes.
    const fallbackWindow = printUrl ? window.open('about:blank', '_blank') : null;
    link.classList.add("busy");
    link.setAttribute("aria-busy", "true");
    link.textContent = "Dang tao PDF...";
    showToast("Dang tao PDF. Lan dau co the mat vai giay...");
    try {
      const response = await fetch(link.href, { cache: "no-store" });
      if (!response.ok) {
        let message = `HTTP ${response.status}`;
        try {
          const payload = await response.json();
          if (payload && payload.detail) message = payload.detail;
        } catch (_) {
          try { message = (await response.text()).slice(0, 300) || message; } catch (_) {}
        }
        throw new Error(message);
      }
      const engine = (response.headers.get('X-AudioSheet-PDF-Engine') || '').toLowerCase();
      const blob = await response.blob();
      if (!blob.size || !String(blob.type || "").includes("pdf")) {
        throw new Error("May chu khong tra ve file PDF hop le");
      }
      if (engine && !['browser_osmd', 'musescore'].includes(engine) && printUrl) {
        if (fallbackWindow) fallbackWindow.location.replace(printUrl);
        else window.location.href = printUrl;
        showToast('Bo xuat tu dong chi tao duoc ban don gian. Da mo ban PDF dung nhu giao dien web.', true);
        return;
      }
      if (fallbackWindow) fallbackWindow.close();
      downloadBlob(blob, link.download || "AudioSheet.pdf");
      showToast(engine === 'browser_osmd' ? 'Da xuat PDF bang chinh OSMD nhu tren web.' : 'Da xuat file PDF thanh cong.');
    } catch (error) {
      if (printUrl) {
        if (fallbackWindow) fallbackWindow.location.replace(printUrl);
        else window.location.href = printUrl;
        showToast('Bo xuat PDF tu dong gap loi. Da mo ban in dung chinh giao dien web; chon Save as PDF.', true);
      } else {
        if (fallbackWindow) fallbackWindow.close();
        showToast(`Khong xuat duoc PDF: ${error.message || String(error)}`, true);
      }
    } finally {
      link.classList.remove("busy");
      link.removeAttribute("aria-busy");
      link.textContent = originalText;
    }
  }

  document.addEventListener("click", (event) => {
    const link = event.target.closest("a.pdf-download");
    if (!link || !link.href || link.classList.contains("busy")) return;
    event.preventDefault();
    fetchAndDownloadPdf(link);
  });

  function switchSource(source) {
    activeSource = source;
    document.querySelectorAll(".source-tab").forEach((button) => {
      const active = button.dataset.source === source;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
    });
    document.getElementById("uploadSource").classList.toggle("active", source === "upload");
    document.getElementById("youtubeSource").classList.toggle("active", source === "youtube");
  }

  document.querySelectorAll(".source-tab").forEach((button) => {
    button.addEventListener("click", () => switchSource(button.dataset.source));
  });

  function updateFileLabel(file) {
    if (!file) {
      fileLabel.innerHTML = "K&#233;o th&#7843; file v&#224;o &#273;&#226;y ho&#7863;c b&#7845;m &#273;&#7875; ch&#7885;n";
      return;
    }
    const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
    fileLabel.textContent = `${file.name} (${sizeMb} MB)`;
  }

  audioFile.addEventListener("change", () => updateFileLabel(audioFile.files[0]));
  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.add("dragging");
    });
  });
  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropZone.classList.remove("dragging");
    });
  });
  dropZone.addEventListener("drop", (event) => {
    const files = event.dataTransfer.files;
    if (!files || !files.length) return;
    const transfer = new DataTransfer();
    transfer.items.add(files[0]);
    audioFile.files = transfer.files;
    updateFileLabel(files[0]);
  });

  function validateClientInput() {
    if (activeSource === "upload" && !audioFile.files.length) {
      throw new Error("Hay chon mot file am thanh.");
    }
    if (activeSource === "youtube" && !youtubeUrl.value.trim()) {
      throw new Error("Hay dan link YouTube.");
    }
    if (!document.getElementById("acceptedRights").checked) {
      throw new Error("Ban can xac nhan quyen su dung noi dung am thanh.");
    }
    if (document.getElementById('harmonyEngine').value === 'gemini' && !document.getElementById('geminiUploadConsent').checked) {
      throw new Error('Bạn cần xác nhận đồng ý gửi audio đến Gemini API.');
    }
    if (document.getElementById('melodyEngine').value === 'sheetsage2' && !document.getElementById('researchNoncommercial').checked) {
      throw new Error('SheetSage2 chỉ dành cho nghiên cứu phi thương mại. Cần xác nhận giấy phép model.');
    }
  }

  const melodyEngine = document.getElementById('melodyEngine');
  const pianoEngine = document.getElementById('pianoEngine');
  const harmonyEngine = document.getElementById('harmonyEngine');
  const researchLicenseRow = document.getElementById('researchLicenseRow');
  const geminiConsentRow = document.getElementById('geminiConsentRow');
  function refreshAiSelections() {
    researchLicenseRow.classList.toggle('hidden', melodyEngine.value !== 'sheetsage2');
    geminiConsentRow.classList.toggle('hidden', harmonyEngine.value !== 'gemini');
  }
  melodyEngine.addEventListener('change', refreshAiSelections);
  pianoEngine.addEventListener('change', refreshAiSelections);
  harmonyEngine.addEventListener('change', refreshAiSelections);
  refreshAiSelections();

  function makeFormData() {
    const data = new FormData(form);
    if (activeSource === "upload") {
      data.delete("youtube_url");
    } else {
      data.delete("audio_file");
    }
    if (!document.getElementById("acceptedRights").checked) {
      data.set("accepted_rights", "false");
    }
    if (!document.getElementById("separateStems").checked) {
      data.set("separate_stems", "false");
    }
    return data;
  }

  function resetJobUi() {
    clearPlaybackUi();
    resultSection.classList.add("hidden");
    document.getElementById("jobError").classList.add("hidden");
    document.getElementById("jobError").textContent = "";
    document.getElementById('aiUsedStatus').classList.add('hidden');
    jobSection.classList.remove("hidden");
  }

  function renderJob(job) {
    const progress = Number(job.progress || 0);
    document.getElementById("jobTitle").textContent = job.title || job.source_name || "Tao ban nhac";
    document.getElementById("jobPercent").textContent = `${Math.round(progress)}%`;
    document.getElementById("progressBar").style.width = `${Math.max(0, Math.min(100, progress))}%`;
    document.getElementById("jobMessage").textContent = job.message || statusText[job.status] || job.status;
    const rank = statusRank[job.status] ?? 0;
    document.querySelectorAll("#processSteps span").forEach((node, index) => {
      node.classList.toggle("complete", rank > index || job.status === "done");
      node.classList.toggle("active", rank === index && job.status !== "done");
    });
    const errorBox = document.getElementById("jobError");
    if (job.status === "failed") {
      errorBox.textContent = job.error || "Khong the xu ly tep am thanh nay.";
      errorBox.classList.remove("hidden");
    }
  }

  async function pollJob(jobId) {
    const token = ++pollToken;
    currentJobId = jobId;
    while (token === pollToken) {
      const job = await requestJson(`/api/jobs/${jobId}`);
      renderJob(job);
      if (job.status === "done") {
        await showResult(job);
        await loadRecentJobs();
        return;
      }
      if (job.status === "failed") {
        submitButton.disabled = false;
        await loadRecentJobs();
        return;
      }
      await new Promise((resolve) => window.setTimeout(resolve, 1300));
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      validateClientInput();
      submitButton.disabled = true;
      resetJobUi();
      jobSection.scrollIntoView({ behavior: "smooth", block: "center" });
      const job = await requestJson("/api/jobs", { method: "POST", body: makeFormData() });
      renderJob(job);
      await pollJob(job.id);
    } catch (error) {
      submitButton.disabled = false;
      showToast(error.message || String(error), true);
    }
  });

  demoButton.addEventListener("click", async () => {
    try {
      demoButton.disabled = true;
      resetJobUi();
      const mode = document.getElementById("mode").value;
      const job = await requestJson(`/api/demo?mode=${encodeURIComponent(mode)}`, { method: "POST" });
      renderJob(job);
      await showResult(job);
      await loadRecentJobs();
      jobSection.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (error) {
      showToast(error.message || String(error), true);
    } finally {
      demoButton.disabled = false;
    }
  });

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`Cannot load ${src}`));
      document.head.appendChild(script);
    });
  }

  async function ensureOsmd() {
    if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
    if (osmdPromise) return osmdPromise;
    osmdPromise = (async () => {
      const sources = [
        "/static/vendor/opensheetmusicdisplay.min.js",
        "https://cdn.jsdelivr.net/npm/opensheetmusicdisplay@2.1.3/build/opensheetmusicdisplay.min.js",
      ];
      let lastError = null;
      for (const source of sources) {
        try {
          await loadScript(source);
          if (window.opensheetmusicdisplay) return window.opensheetmusicdisplay;
        } catch (error) {
          lastError = error;
        }
      }
      throw lastError || new Error("OpenSheetMusicDisplay is unavailable");
    })();
    try { return await osmdPromise; }
    catch (error) { osmdPromise = null; throw error; }
  }

  async function renderArrangementSheet(jobId, mode) {
    mode = normalizePlaybackMode(mode);
    const descriptions = {
      melody: 'A · Giai điệu hát — một khuông',
      light_easy: 'B · Piano Dễ — melody + root/fifth',
      light_standard: 'B · Piano Tiêu chuẩn — voicing và bass voice-leading',
      light_full: 'B · Piano Đầy đủ — arpeggio, bè trong và fill',
      full: playbackData && playbackData.reference_active
        ? 'C · MIDI tham chiếu — hai khuông'
        : 'C · Phiên âm đầy đủ — hai khuông',
    };
    const desc = descriptions[mode] || mode;
    const letter = modeLetter(mode);
    document.getElementById('scoreModeTitle').textContent = desc;
    const links = [
      [activeMidiDownload, `/api/jobs/${jobId}/playback-midi/${mode}`, `AudioSheet_${letter}_${mode}.mid`, `⇩ MIDI ${letter}`, ''],
      [activeSheetDownload, `/api/jobs/${jobId}/playback-score/${mode}`, `AudioSheet_${letter}_${mode}.musicxml`, `⇩ MusicXML ${letter}`, ''],
      [activePdfDownload, `/api/jobs/${jobId}/playback-pdf/${mode}`, `AudioSheet_${letter}_${mode}.pdf`, `⇩ PDF ${letter}`, `/static/print_score.html?job=${encodeURIComponent(jobId)}&mode=${encodeURIComponent(mode)}&auto=1`],
    ];
    links.forEach(([link, href, filename, label, printUrl]) => {
      link.href = href;
      link.download = filename;
      link.textContent = label;
      if (printUrl) link.dataset.printUrl = printUrl;
      else delete link.dataset.printUrl;
      link.classList.remove('hidden');
    });
    await renderMusicXml(activeSheetDownload.href);
  }

  async function renderMusicXml(url) {
    const token = ++scoreRenderToken;
    const loading = document.getElementById("scoreLoading");
    const container = document.getElementById("scoreContainer");
    loading.textContent = 'Đang dựng khuông nhạc cho chế độ đã chọn...';
    loading.classList.remove('hidden');
    container.innerHTML = '';
    osmd = null;
    try {
      const library = await ensureOsmd();
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const xml = await response.text();
      if (token !== scoreRenderToken) return;
      const currentOsmd = new library.OpenSheetMusicDisplay(container, {
        autoResize: true,
        backend: "svg",
        drawTitle: true,
        drawComposer: true,
        drawingParameters: "compacttight",
      });
      currentOsmd.Zoom = zoom;
      await currentOsmd.load(xml);
      if (token !== scoreRenderToken) return;
      currentOsmd.render();
      osmd = currentOsmd;
      loading.classList.add('hidden');
      updateZoomLabel();
    } catch (error) {
      if (token !== scoreRenderToken) return;
      loading.textContent = "Không thể hiển thị MusicXML: " + (error.message || error);
      showToast("Khong the tai bo hien thi sheet nhac.", true);
    }
  }

  function artifactLabel(artifact) {
    return artifact.label || artifact.filename || artifact.kind;
  }

  async function showResult(job) {
    currentJobId = job.id;
    submitButton.disabled = false;
    resultSection.classList.remove("hidden");
    document.getElementById("resultTitle").textContent = job.title || job.source_name || "Sheet nhac da san sang";
    const meta = [];
    if (job.mode) meta.push(job.mode === "piano" ? "Piano hai tay" : job.mode === "lead" ? "Lead sheet" : "Ban chep tho");
    if (job.bpm_used) meta.push(`${job.bpm_used} BPM`);
    if (job.time_signature) meta.push(`Nhịp gốc ${job.time_signature}`);
    if (job.pickup_quarters) meta.push(`Ô lấy đà ${Number(job.pickup_quarters).toFixed(2)} phách`);
    if (job.meter_change_count) meta.push(`${job.meter_change_count} lần đổi số chỉ nhịp`);
    if (job.rhythm_engine) meta.push(`Rhythm: ${job.rhythm_engine}`);
    if (job.duration_seconds) meta.push(`${job.duration_seconds}s audio`);
    if (job.detected_key) meta.push(`Giọng ${job.detected_key}`);
    if (job.pipeline) meta.push(job.pipeline === 'stem_separated' ? 'Demucs A/B/C' : job.pipeline);
    document.getElementById("resultMeta").textContent = meta.join("  /  ");
    const aiStatus = document.getElementById('aiUsedStatus');
    const engines = job.ai_engines || {};
    const aiWarnings = Array.isArray(job.ai_warnings) ? job.ai_warnings : [];
    const aUsed = engines.melody && engines.melody.used || 'basic_pitch';
    const bUsed = engines.piano && engines.piano.used || 'heuristic';
    const hUsed = engines.harmony && engines.harmony.used || 'local';
    const hChanges = engines.harmony && Number(engines.harmony.changed_windows || 0);
    const hKey = engines.harmony && engines.harmony.key_changed;
    aiStatus.textContent = `Engine THỰC TẾ: A = ${aUsed}; B = ${bUsed}; C = Basic Pitch; Hòa âm = ${hUsed}` +
      (hChanges ? ` (${hChanges} vùng hợp âm được Gemini thay sau kiểm chứng)` : '') +
      (hKey ? ' (Tone/key đã được Gemini hiệu chỉnh và xác minh)' : '') +
      (aiWarnings.length ? `\nCẢNH BÁO: ${aiWarnings.join(' | ')}` : '');
    aiStatus.classList.toggle('warning', aiWarnings.length > 0);
    aiStatus.classList.remove('hidden');

    const buttons = document.getElementById("downloadButtons");
    buttons.innerHTML = "";
    const artifacts = Array.isArray(job.artifacts) ? job.artifacts : [];
    artifacts.filter((item) => item.kind !== "audio" && item.kind !== "stem_audio" && !item.variant).forEach((artifact, index) => {
      const link = document.createElement("a");
      link.href = artifact.url;
      link.download = artifact.filename;
      link.textContent = artifactLabel(artifact);
      if (artifact.kind === "musicxml" || (!index && artifact.kind !== "pdf")) {
        link.classList.add("primary-download");
      }
      buttons.appendChild(link);
    });

    const audioArtifact = artifacts.find((item) => item.kind === "audio");
    const audioPreview = document.getElementById("audioPreview");
    if (audioArtifact) {
      document.getElementById("audioPlayer").src = audioArtifact.url;
      audioPreview.classList.remove("hidden");
    } else {
      document.getElementById("audioPlayer").removeAttribute("src");
      audioPreview.classList.add("hidden");
    }

    const playbackLoaded = await loadPlayback(job);

    // Only show the original sheet if this old job has no usable playback data.
    // Never overwrite a freshly rendered A/B/C sheet with the old MusicXML.
    if (!playbackLoaded) {
      const xmlArtifact = artifacts.find(item => item.kind === 'musicxml');
      if (xmlArtifact) await renderMusicXml(xmlArtifact.url);
    }
    resultSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function updateZoomLabel() {
    document.getElementById("zoomValue").textContent = `${Math.round(zoom * 100)}%`;
  }

  function applyZoom(nextZoom) {
    zoom = Math.max(0.4, Math.min(2.0, nextZoom));
    updateZoomLabel();
    if (osmd) {
      osmd.Zoom = zoom;
      osmd.render();
    }
  }

  document.getElementById("zoomIn").addEventListener("click", () => applyZoom(zoom + 0.1));
  document.getElementById("zoomOut").addEventListener("click", () => applyZoom(zoom - 0.1));
  document.getElementById("fitScore").addEventListener("click", () => {
    const width = document.getElementById("scoreContainer").clientWidth;
    applyZoom(width < 720 ? 0.62 : width < 1000 ? 0.82 : 1.0);
  });
  document.getElementById("printScore").addEventListener("click", () => {
    document.body.classList.add("print-score");
    window.print();
    window.setTimeout(() => document.body.classList.remove("print-score"), 400);
  });

  async function loadRecentJobs() {
    const container = document.getElementById("recentJobs");
    try {
      const jobs = await requestJson("/api/jobs?limit=8");
      container.innerHTML = "";
      if (!jobs.length) {
        container.innerHTML = '<span class="muted">Chua co du lieu.</span>';
        return;
      }
      jobs.forEach((job) => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "recent-job";
        item.innerHTML = `
          <strong></strong>
          <span class="job-state ${job.status === "failed" ? "failed" : ""}"></span>
          <small></small>
        `;
        item.querySelector("strong").textContent = job.title || job.source_name || job.id.slice(0, 8);
        item.querySelector(".job-state").textContent = job.status === "done" ? "Hoan tat" : job.status === "failed" ? "Loi" : `${job.progress || 0}%`;
        item.querySelector("small").textContent = new Date(job.created_at).toLocaleString("vi-VN");
        item.addEventListener("click", async () => {
          try {
            resetJobUi();
            renderJob(job);
            if (job.status === "done") await showResult(job);
            else if (job.status !== "failed") await pollJob(job.id);
            else jobSection.scrollIntoView({ behavior: "smooth" });
          } catch (error) {
            showToast(error.message || String(error), true);
          }
        });
        container.appendChild(item);
      });
    } catch (error) {
      container.innerHTML = '<span class="muted">Khong the tai lich su.</span>';
    }
  }

  async function loadHealth(showMessage = false) {
    const list = document.getElementById("healthList");
    const text = document.getElementById("healthText");
    try {
      const health = await requestJson("/api/health");
      const checks = [
        ["FFmpeg", health.ffmpeg],
        ["Basic Pitch", health.basic_pitch],
        [`Gemini SDK + key (chưa kiểm tra kết nối thật)`, !!(health.gemini && health.gemini.available)],
        ["Pop2Piano / WSL2 (tùy chọn)", !!(health.advanced_ai && health.advanced_ai.pop2piano && health.advanced_ai.pop2piano.installed)],
        [`SheetSage2 / ${health.advanced_ai && health.advanced_ai.sheetsage2 && health.advanced_ai.sheetsage2.runtime === 'native_windows_cpu' ? 'Windows CPU' : 'Linux'} (phi thương mại)`, !!(health.advanced_ai && health.advanced_ai.sheetsage2 && health.advanced_ai.sheetsage2.installed)],
        [`Demucs ${health.demucs && health.demucs.version ? health.demucs.version : ''}`.trim(), !!(health.demucs && health.demucs.available)],
        [`Beat This! ${health.rhythm_grid && health.rhythm_grid.model ? '(' + health.rhythm_grid.model + ')' : ''}`.trim(), !!(health.rhythm_grid && health.rhythm_grid.enabled && health.rhythm_grid.available)],
        ["music21", health.music21],
        [`Xuất PDF (${health.pdf && health.pdf.preferred ? health.pdf.preferred : 'chưa có'})`, !!(health.pdf && health.pdf.available)],
        ["yt-dlp", health.yt_dlp],
        ["OSMD local", health.local_osmd],
        [`Mẫu piano thật (${health.sampled_piano_files || 0}/${health.sampled_piano_expected || 30})`,
           (health.sampled_piano_files || 0) === (health.sampled_piano_expected || 30)],
      ];
      list.innerHTML = "";
      checks.forEach(([label, ok]) => {
        const row = document.createElement("div");
        row.className = "health-row";
        row.innerHTML = `<span>${label}</span><i class="health-dot ${ok ? "ok" : ""}"></i>`;
        list.appendChild(row);
      });
      const coreOk = health.ffmpeg && health.basic_pitch && health.music21;
      const fullOk = coreOk && health.demucs && health.demucs.available
        && health.rhythm_grid && health.rhythm_grid.available
        && health.pdf && health.pdf.available;
      text.textContent = fullOk
        ? `AudioSheet v${health.version}. Sẵn sàng phân beat/downbeat, tách stem, tạo A/B/C và xuất PDF. Giới hạn ${health.limits.max_upload_mb} MB / ${Math.round(health.limits.max_audio_seconds / 60)} phút.`
        : coreOk
          ? `AudioSheet v${health.version}. Chế độ cơ bản hoạt động, nhưng Demucs, Beat This! hoặc bộ xuất PDF còn thiếu. Chạy lại CHAY_WEBSITE.bat để tự cài.`
          : "Thiếu công cụ xử lý cốt lõi. Hãy chạy lại CHAY_WEBSITE.bat.";
      if (showMessage) showToast(fullOk ? "Hệ thống đã sẵn sàng Rhythm Grid, A/B/C và PDF." : "Một số thành phần nâng cao còn thiếu.", !coreOk);
    } catch (error) {
      text.textContent = "Khong ket noi duoc API.";
      list.innerHTML = "";
      if (showMessage) showToast(error.message || String(error), true);
    }
  }

  document.getElementById("healthButton").addEventListener("click", () => {
    loadHealth(true);
    document.querySelector(".info-panel").scrollIntoView({ behavior: "smooth", block: "center" });
  });
  document.getElementById("refreshJobs").addEventListener("click", loadRecentJobs);

  loadHealth();
  loadRecentJobs();
})();
