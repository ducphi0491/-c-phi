"""Integrate optional model-generated MIDI with AudioSheet's A/B/C data schema.

The web player, MusicXML, MIDI, and PDF all consume these same mode notes.
Never pretend the optional model ran unless its MIDI passed validation.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any

from .playback_modes import (
    build_arrangement_levels, clean_notes, detect_key, infer_chord_timeline,
    midi_to_events,
)
from .rhythm_grid import quantize_notes_to_rhythm


def _safe_midi(path: Path, duration: float) -> list[dict[str, Any]]:
    notes = midi_to_events(str(path))
    # Reject corrupted or badly misaligned MIDI rather than showing a false result.
    safe = [item for item in clean_notes(notes) if float(item["start"]) < duration + 3.0]
    if len(safe) < 4:
        raise ValueError(f"MIDI from AI model has too few valid notes: {path.name}")
    if max(float(n["end"]) for n in safe) > duration + 10.0:
        raise ValueError(f"AI model MIDI duration exceeds the source: {path.name}")
    return safe


def apply_sheetsage2(
    payload: dict[str, Any], model_output: Path,
    *, duration: float, bpm: float, time_signature: str,
    quantization: int, rhythm: dict[str, Any],
) -> dict[str, Any]:
    vocal_path = model_output / "melody_vocal.mid"
    instrumental_path = model_output / "melody_instrumental.mid"
    # Models can export an empty vocal part for an instrumental intro. Prefer
    # real vocal notes, but use the instrumental melody if vocal is empty.
    melody_path = None
    melody = []
    for candidate in (vocal_path, instrumental_path):
        if not candidate.is_file():
            continue
        try:
            melody = _safe_midi(candidate, duration)
        except (ValueError, OSError):
            continue
        melody_path = candidate
        break
    if melody_path is None:
        raise ValueError("SheetSage2 returned no valid vocal or instrumental melody MIDI")
    melody = [dict(n, source="sheetsage2_vocal" if melody_path == vocal_path else "sheetsage2_instrumental",
                   role="melody", staff="upper") for n in melody]
    # Keep the model's onset/offset timing: a second aggressive quantizer would
    # damage a newly inferred lead sheet.
    payload["modes"]["melody"] = {
        "label": "A · SheetSage2 melody (research)", "count": len(melody), "notes": melody,
    }
    full = payload["modes"]["full"]["notes"]
    bass = [n for n in full if n.get("source") == "bass" or n.get("role") == "bass"]
    other = [n for n in full if n.get("source") in ("other", "full_mix") or n.get("role") == "other"]
    chord_path = model_output / "chords.mid"
    chord_notes = []
    if chord_path.is_file():
        try:
            chord_notes = _safe_midi(chord_path, duration)
        except (ValueError, OSError):
            # A short/empty chord track must not discard a valid AI melody.
            pass
    analysis = payload.setdefault("analysis", {})
    key = detect_key(melody + chord_notes + bass)
    chords = infer_chord_timeline(chord_notes or other, bass, bpm, time_signature, duration, key, rhythm)
    levels = build_arrangement_levels(melody, chords, bass, other, bpm, time_signature, key, rhythm)
    for name, notes in levels.items():
        notes = quantize_notes_to_rhythm(
            notes, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True,
            minimum_quarters=0.25,
        )
        payload["modes"][name] = {
            "label": {"light_easy": "B · Dễ", "light_standard": "B · Tiêu chuẩn", "light_full": "B · Đầy đủ"}[name],
            "count": len(notes), "notes": notes,
        }
    payload["modes"]["light"] = dict(payload["modes"]["light_standard"], alias_of="light_standard")
    analysis["key"] = key
    analysis["chords"] = chords
    payload["source"] += " + SheetSage2 melody/chords"
    return payload


def _cluster_events(notes: list[dict[str, Any]], tolerance: float = 0.045) -> list[list[dict[str, Any]]]:
    clusters: list[list[dict[str, Any]]] = []
    for note in sorted(notes, key=lambda n: (n["start"], -n["pitch"])):
        if not clusters or note["start"] - clusters[-1][0]["start"] > tolerance:
            clusters.append([note])
        else:
            clusters[-1].append(note)
    return clusters


def _tier_notes(notes: list[dict[str, Any]], level: str) -> list[dict[str, Any]]:
    """Reduce model MIDI density without synthesizing extra artificial notes."""
    max_upper = {"light_easy": 1, "light_standard": 2, "light_full": 5}[level]
    max_lower = {"light_easy": 1, "light_standard": 2, "light_full": 5}[level]
    min_interval = {"light_easy": 0.19, "light_standard": 0.09, "light_full": 0.0}[level]
    last_lower_start = -1e9
    result: list[dict[str, Any]] = []
    for group in _cluster_events(notes):
        upper = [n for n in group if int(n["pitch"]) >= 60]
        lower = [n for n in group if int(n["pitch"]) < 60]
        upper.sort(key=lambda n: (-int(n["pitch"]), -float(n["end"] - n["start"])))
        lower.sort(key=lambda n: (int(n["pitch"]), -float(n["end"] - n["start"])))
        for n in upper[:max_upper]:
            result.append(dict(n, staff="upper", role="piano_cover", source="pop2piano"))
        if lower and (group[0]["start"] - last_lower_start >= min_interval):
            for n in lower[:max_lower]:
                result.append(dict(n, staff="lower", role="piano_cover", source="pop2piano"))
            last_lower_start = group[0]["start"]
    return clean_notes(result)


def apply_pop2piano(payload: dict[str, Any], midi_file: Path, *, duration: float) -> dict[str, Any]:
    notes = _safe_midi(midi_file, duration)
    for level in ("light_easy", "light_standard", "light_full"):
        selected = _tier_notes(notes, level)
        if not selected:
            raise ValueError(f"Pop2Piano returned empty level {level}")
        payload["modes"][level] = {
            "label": {
                "light_easy": "B · Pop2Piano Dễ", "light_standard": "B · Pop2Piano Tiêu chuẩn",
                "light_full": "B · Pop2Piano Đầy đủ",
            }[level],
            "count": len(selected), "notes": selected,
        }
    payload["modes"]["light"] = dict(payload["modes"]["light_standard"], alias_of="light_standard")
    payload["source"] += " + Pop2Piano composer1"
    return payload
