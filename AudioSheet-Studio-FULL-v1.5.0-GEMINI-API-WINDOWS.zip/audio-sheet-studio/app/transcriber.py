from __future__ import annotations

import csv
import json
import math
import threading
from pathlib import Path
from typing import Any


_model: Any = None
_model_lock = threading.Lock()
_inference_lock = threading.Lock()


def midi_to_hz(note_number: int) -> float:
    return 440.0 * (2.0 ** ((note_number - 69) / 12.0))


def _get_model() -> Any:
    global _model
    if _model is not None:
        return _model
    with _model_lock:
        if _model is None:
            from basic_pitch import ICASSP_2022_MODEL_PATH
            from basic_pitch.inference import Model

            _model = Model(ICASSP_2022_MODEL_PATH)
    return _model


def transcribe(
    audio_path: Path,
    midi_path: Path,
    csv_path: Path,
    bpm: float,
    minimum_midi: int,
    maximum_midi: int,
    onset_threshold: float,
    frame_threshold: float,
    minimum_note_length_ms: float,
) -> list[tuple[float, float, int, float, Any]]:
    if not 0 <= minimum_midi < maximum_midi <= 127:
        raise ValueError("MIDI range must be between 0 and 127")
    if not math.isfinite(bpm) or not 20 <= bpm <= 300:
        raise ValueError("BPM must be between 20 and 300")

    try:
        from basic_pitch.inference import predict
    except ImportError as exc:
        raise RuntimeError(
            "Basic Pitch is not installed. Run the installation script with Python 3.11."
        ) from exc

    midi_path.parent.mkdir(parents=True, exist_ok=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    model = _get_model()
    with _inference_lock:
        _, midi_data, note_events = predict(
            audio_path,
            model,
            onset_threshold=onset_threshold,
            frame_threshold=frame_threshold,
            minimum_note_length=minimum_note_length_ms,
            minimum_frequency=midi_to_hz(minimum_midi),
            maximum_frequency=midi_to_hz(maximum_midi),
            midi_tempo=bpm,
        )
    midi_data.write(str(midi_path))

    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["start_time_s", "end_time_s", "pitch_midi", "velocity", "confidence_proxy", "pitch_bend"])
        for start, end, pitch, amplitude, bends in note_events:
            amplitude_value = max(0.0, min(1.0, float(amplitude)))
            writer.writerow([
                start,
                end,
                pitch,
                round(amplitude_value * 127),
                round(amplitude_value, 6),
                bends or "",
            ])

    return note_events


def note_events_to_dicts(
    note_events: list[tuple[float, float, int, float, Any]],
    *,
    source: str,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for start, end, pitch, amplitude, bends in note_events:
        amplitude_value = max(0.0, min(1.0, float(amplitude)))
        result.append(
            {
                "start": float(start),
                "end": float(end),
                "pitch": int(pitch),
                "velocity": int(round(amplitude_value * 127)),
                "confidence": round(amplitude_value, 6),
                "source": source,
                "pitch_bends": [int(value) for value in bends] if bends else None,
            }
        )
    result.sort(key=lambda item: (item["start"], -item["pitch"], -item["velocity"]))
    return result


def transcribe_to_files(
    *,
    audio_path: Path,
    output_dir: Path,
    prefix: str,
    source: str,
    bpm: float,
    minimum_midi: int,
    maximum_midi: int,
    onset_threshold: float,
    frame_threshold: float,
    minimum_note_length_ms: float,
) -> list[dict[str, Any]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    midi_path = output_dir / f"{prefix}.mid"
    csv_path = output_dir / f"{prefix}.csv"
    json_path = output_dir / f"{prefix}.json"
    events = transcribe(
        audio_path=audio_path,
        midi_path=midi_path,
        csv_path=csv_path,
        bpm=bpm,
        minimum_midi=minimum_midi,
        maximum_midi=maximum_midi,
        onset_threshold=onset_threshold,
        frame_threshold=frame_threshold,
        minimum_note_length_ms=minimum_note_length_ms,
    )
    payload = note_events_to_dicts(events, source=source)
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload
