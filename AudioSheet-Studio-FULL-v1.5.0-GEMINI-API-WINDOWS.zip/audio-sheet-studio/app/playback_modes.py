"""Arrangement and playback pipelines for AudioSheet Studio.

Version 1.1 has two paths:

* New jobs: Demucs separates vocals, bass, drums and other. Basic Pitch then
  transcribes the pitched stems separately. Modes A/B/C are built from different
  source material instead of three filters over one mixed transcription.
* Old jobs: the original full-mix note_events.json is still supported through a
  conservative fallback arranger.
"""
from __future__ import annotations

import math
from collections import defaultdict
from itertools import combinations
from typing import Any, Iterable, Sequence

from .rhythm_grid import (
    constant_rhythm_map,
    harmonic_windows,
    quantize_notes_to_rhythm,
    quarter_to_time,
    time_to_quarter,
)

MAX_EVENTS = 60000
PITCH_CLASS_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
MAJOR_PROFILE = (6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
MINOR_PROFILE = (6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

CHORD_DEFINITIONS: dict[str, tuple[int, ...]] = {
    "major": (0, 4, 7),
    "minor": (0, 3, 7),
    "dominant7": (0, 4, 7, 10),
    "major7": (0, 4, 7, 11),
    "minor7": (0, 3, 7, 10),
    "half-dim7": (0, 3, 6, 10),
    "dim": (0, 3, 6),
    "dim7": (0, 3, 6, 9),
    "sus4": (0, 5, 7),
    "sus2": (0, 2, 7),
}
CHORD_SUFFIXES = {
    "major": "",
    "minor": "m",
    "dominant7": "7",
    "major7": "Maj7",
    "minor7": "m7",
    "half-dim7": "m7(b5)",
    "dim": "dim",
    "dim7": "dim7",
    "sus4": "sus4",
    "sus2": "sus2",
}
ARRANGEMENT_LEVELS = ("light_easy", "light_standard", "light_full")


def _quantile(values: Sequence[int | float], portion: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * portion)))
    return ordered[index]


def clean_notes(
    raw: Iterable[dict[str, Any]],
    default_source: str | None = None,
) -> list[dict[str, Any]]:
    """Validate and time-sort note events while retaining useful metadata."""
    notes: list[dict[str, Any]] = []
    for index, item in enumerate(raw):
        if index >= MAX_EVENTS:
            break
        if not isinstance(item, dict):
            continue
        try:
            start = float(item["start"])
            end = float(item["end"])
            pitch = int(item["pitch"])
            velocity = int(round(float(item.get("velocity", 80))))
        except (TypeError, ValueError, KeyError, OverflowError):
            continue
        if not all(map(math.isfinite, (start, end))):
            continue
        if start < 0 or start > 3600 or end <= start + 0.025:
            continue
        if not 0 <= pitch <= 127:
            continue
        note: dict[str, Any] = {
            "start": round(start, 5),
            "end": round(min(end, start + 18), 5),
            "pitch": pitch,
            "velocity": max(1, min(127, velocity)),
        }
        for key in ("staff", "role", "source", "generated"):
            if key in item:
                note[key] = item[key]
        if default_source and not note.get("source"):
            note["source"] = default_source
        for key in ("confidence", "amplitude"):
            if key in item:
                try:
                    value = float(item[key])
                    if math.isfinite(value):
                        note[key] = max(0.0, min(1.0, value))
                except (TypeError, ValueError, OverflowError):
                    pass
        for key in ("score_start_q", "score_end_q"):
            if key in item:
                try:
                    value = float(item[key])
                    if math.isfinite(value) and value >= 0:
                        note[key] = round(value, 6)
                except (TypeError, ValueError, OverflowError):
                    pass
        notes.append(note)
    notes.sort(key=lambda n: (float(n["start"]), -int(n["pitch"]), -int(n["velocity"])))
    return notes


def merge_fragments(notes: list[dict[str, Any]], max_gap: float = 0.055) -> list[dict[str, Any]]:
    """Join short, nearly attached fragments of the same note conservatively."""
    by_key: dict[tuple[int, str, str], list[dict[str, Any]]] = defaultdict(list)
    for note in notes:
        by_key[(int(note["pitch"]), str(note.get("source") or ""), str(note.get("staff") or ""))].append(note)
    result: list[dict[str, Any]] = []
    for _, group in by_key.items():
        group.sort(key=lambda n: float(n["start"]))
        previous: dict[str, Any] | None = None
        for note in group:
            if previous is None:
                previous = dict(note)
                continue
            gap = float(note["start"]) - float(previous["end"])
            part_length = float(note["end"]) - float(note["start"])
            previous_span = float(previous["end"]) - float(previous["start"])
            joined = (
                -0.025 <= gap <= max_gap
                and part_length <= 0.75
                and previous_span <= 3.5
                and abs(int(note["velocity"]) - int(previous["velocity"])) <= 24
            )
            if joined:
                previous["end"] = round(max(float(previous["end"]), float(note["end"])), 5)
                previous["velocity"] = max(int(previous["velocity"]), int(note["velocity"]))
                if "confidence" in previous or "confidence" in note:
                    previous["confidence"] = max(float(previous.get("confidence", 0)), float(note.get("confidence", 0)))
            else:
                result.append(previous)
                previous = dict(note)
        if previous is not None:
            result.append(previous)
    result.sort(key=lambda n: (float(n["start"]), -int(n["pitch"])))
    return result


def suppress_octave_harmonics(notes: list[dict[str, Any]], onset_window: float = 0.055) -> list[dict[str, Any]]:
    """Remove only very likely octave-harmonic duplicates.

    This deliberately keeps ambiguous octave doublings. A note is removed only
    when it attacks almost simultaneously, is much weaker/shorter, and lies one
    or two octaves from a stronger event.
    """
    if not notes:
        return []
    groups: list[list[dict[str, Any]]] = []
    for note in notes:
        if groups and float(note["start"]) - float(groups[-1][0]["start"]) <= onset_window:
            groups[-1].append(note)
        else:
            groups.append([note])
    kept: list[dict[str, Any]] = []
    for group in groups:
        remove: set[int] = set()
        for i, first in enumerate(group):
            for j, second in enumerate(group):
                if i == j or j in remove:
                    continue
                interval = int(second["pitch"]) - int(first["pitch"])
                if abs(interval) not in {12, 24}:
                    continue
                strong, weak = (first, second) if int(first["velocity"]) >= int(second["velocity"]) else (second, first)
                weak_index = j if weak is second else i
                strong_duration = float(strong["end"]) - float(strong["start"])
                weak_duration = float(weak["end"]) - float(weak["start"])
                vocal_guard = weak.get("source") == "vocals" and strong.get("source") != "vocals"
                if not vocal_guard and int(weak["velocity"]) <= int(strong["velocity"]) * 0.68 and weak_duration <= strong_duration * 0.85:
                    remove.add(weak_index)
        kept.extend(note for index, note in enumerate(group) if index not in remove)
    kept.sort(key=lambda n: (float(n["start"]), -int(n["pitch"])))
    return kept


def _local_melody_score(note: dict[str, Any], pitch_center: float) -> float:
    duration = float(note["end"]) - float(note["start"])
    pitch = int(note["pitch"])
    source_bonus = 20.0 if note.get("source") == "vocals" else 0.0
    range_bonus = 8.0 if 52 <= pitch <= 86 else -0.9 * min(abs(pitch - 69), 24)
    confidence = float(note.get("confidence", note.get("amplitude", int(note["velocity"]) / 127)))
    center_penalty = abs(pitch - pitch_center) * 0.18
    return (
        int(note["velocity"]) * 0.48
        + min(duration, 1.8) * 18.0
        + confidence * 13.0
        + source_bonus
        + range_bonus
        - center_penalty
    )


def extract_melody(notes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Find a smooth monophonic melody path with dynamic programming."""
    if not notes:
        return []
    pitches = [int(n["pitch"]) for n in notes]
    velocities = [int(n["velocity"]) for n in notes]
    vocal_source = any(n.get("source") == "vocals" for n in notes)
    pitch_floor = 42 if vocal_source else max(38, min(78, int(_quantile(pitches, 0.42))))
    pitch_ceiling = 94 if vocal_source else 98
    velocity_floor = max(25 if vocal_source else 34, int(_quantile(velocities, 0.18)))
    candidates = [
        n for n in notes
        if pitch_floor <= int(n["pitch"]) <= pitch_ceiling
        and int(n["velocity"]) >= velocity_floor
        and float(n["end"]) - float(n["start"]) >= 0.055
    ]
    if not candidates:
        candidates = notes

    groups: list[list[dict[str, Any]]] = []
    for note in candidates:
        if groups and float(note["start"]) - float(groups[-1][0]["start"]) <= 0.105:
            groups[-1].append(note)
        else:
            groups.append([note])
    # Large polyphonic attacks are reduced before Viterbi to keep complexity bounded.
    pitch_center = _quantile([int(n["pitch"]) for n in candidates], 0.62)
    groups = [
        sorted(group, key=lambda n: _local_melody_score(n, pitch_center), reverse=True)[:8]
        for group in groups
    ]
    if not groups:
        return []

    scores: list[list[float]] = []
    back: list[list[int]] = []
    scores.append([_local_melody_score(note, pitch_center) for note in groups[0]])
    back.append([-1] * len(groups[0]))
    for index in range(1, len(groups)):
        current_scores: list[float] = []
        current_back: list[int] = []
        for note in groups[index]:
            best_score = -1e18
            best_parent = 0
            for parent_index, parent in enumerate(groups[index - 1]):
                interval = abs(int(note["pitch"]) - int(parent["pitch"]))
                dt = max(0.001, float(note["start"]) - float(parent["start"]))
                transition = -interval * (1.28 if dt < 0.9 else 0.82)
                if interval > 12:
                    transition -= (interval - 12) * 2.1
                if interval <= 2:
                    transition += 5.5
                if int(note["pitch"]) == int(parent["pitch"]):
                    transition += 2.0
                gap = float(note["start"]) - float(parent["end"])
                if gap > 2.0:
                    transition -= min(10.0, gap * 1.2)
                candidate_score = scores[index - 1][parent_index] + transition
                if candidate_score > best_score:
                    best_score = candidate_score
                    best_parent = parent_index
            current_scores.append(best_score + _local_melody_score(note, pitch_center))
            current_back.append(best_parent)
        scores.append(current_scores)
        back.append(current_back)

    cursor = max(range(len(scores[-1])), key=scores[-1].__getitem__)
    path: list[dict[str, Any]] = []
    for group_index in range(len(groups) - 1, -1, -1):
        path.append(dict(groups[group_index][cursor]))
        cursor = back[group_index][cursor]
        if cursor < 0 and group_index:
            cursor = 0
    path.reverse()

    result: list[dict[str, Any]] = []
    for note in path:
        if result:
            previous = result[-1]
            if float(note["start"]) < float(previous["start"]) + 0.075:
                continue
            if int(note["pitch"]) == int(previous["pitch"]) and float(note["start"]) - float(previous["end"]) <= 0.075:
                previous["end"] = max(float(previous["end"]), float(note["end"]))
                previous["velocity"] = max(int(previous["velocity"]), int(note["velocity"]))
                continue
            previous["end"] = round(min(float(previous["end"]), float(note["start"])), 5)
            previous["end"] = max(float(previous["end"]), float(previous["start"]) + 0.07)
        selected = dict(note)
        selected["staff"] = "upper"
        selected["role"] = "melody"
        selected["velocity"] = max(48, min(108, round(int(selected["velocity"]) * 0.92)))
        selected["end"] = round(min(float(selected["end"]), float(selected["start"]) + 4.5), 5)
        result.append(selected)
    return result


def detect_key(notes: list[dict[str, Any]]) -> dict[str, Any]:
    weights = [0.0] * 12
    for note in notes:
        duration = max(0.04, min(8.0, float(note["end"]) - float(note["start"])))
        weights[int(note["pitch"]) % 12] += duration * (0.3 + int(note["velocity"]) / 127.0)
    total = sum(weights)
    if total <= 0:
        return {"tonic": 0, "name": "C major", "mode": "major", "fifths": 0, "confidence": 0.0}

    def correlation(profile: Sequence[float], tonic: int) -> float:
        rotated = [profile[(pc - tonic) % 12] for pc in range(12)]
        mean_w = sum(weights) / 12
        mean_p = sum(rotated) / 12
        numerator = sum((weights[i] - mean_w) * (rotated[i] - mean_p) for i in range(12))
        denominator = math.sqrt(
            sum((value - mean_w) ** 2 for value in weights)
            * sum((value - mean_p) ** 2 for value in rotated)
        )
        return numerator / denominator if denominator else 0.0

    options: list[tuple[float, int, str]] = []
    for tonic in range(12):
        options.append((correlation(MAJOR_PROFILE, tonic), tonic, "major"))
        options.append((correlation(MINOR_PROFILE, tonic), tonic, "minor"))
    score, tonic, mode = max(options)
    fifths_major = {0: 0, 7: 1, 2: 2, 9: 3, 4: 4, 11: 5, 6: 6, 1: 7, 5: -1, 10: -2, 3: -3, 8: -4}
    # Minor keys use the signature of their relative major.
    signature_tonic = tonic if mode == "major" else (tonic + 3) % 12
    fifths = fifths_major.get(signature_tonic, 0)
    return {
        "tonic": tonic,
        "name": f"{PITCH_CLASS_NAMES[tonic]} {mode}",
        "mode": mode,
        "fifths": fifths,
        "confidence": round(max(0.0, min(1.0, (score + 1.0) / 2.0)), 3),
    }


def _time_signature_values(time_signature: str) -> tuple[int, int]:
    try:
        beats, beat_type = (int(value) for value in time_signature.split("/", 1))
    except Exception:
        return 4, 4
    if beats <= 0 or beat_type not in {2, 4, 8, 16}:
        return 4, 4
    return beats, beat_type


def _chord_pitch_classes(chord: dict[str, Any]) -> set[int]:
    root = int(chord.get("root", 0)) % 12
    intervals = CHORD_DEFINITIONS.get(str(chord.get("quality", "major")), CHORD_DEFINITIONS["major"])
    return {(root + interval) % 12 for interval in intervals}


def _chord_name(root: int, quality: str, bass_pc: int | None = None) -> str:
    name = PITCH_CLASS_NAMES[root % 12] + CHORD_SUFFIXES.get(quality, "")
    if bass_pc is not None and bass_pc % 12 != root % 12:
        name += "/" + PITCH_CLASS_NAMES[bass_pc % 12]
    return name


def _harmonic_window_seconds(bpm: float, time_signature: str) -> float:
    quarter = 60.0 / max(30.0, min(250.0, float(bpm)))
    # Half-measure harmonic rhythm is a useful default for pop music. 6/8 uses
    # one dotted-quarter pulse, while 3/4 uses half a bar.
    quarters = 2.0 if time_signature == "4/4" else 1.5
    return max(0.45, quarter * quarters)


def _weighted_pitch_classes(
    notes: list[dict[str, Any]], start: float, end: float, *, bass: bool = False
) -> list[float]:
    values = [0.0] * 12
    for note in notes:
        overlap = max(0.0, min(end, float(note["end"])) - max(start, float(note["start"])))
        if overlap <= 0:
            continue
        velocity = int(note.get("velocity", 75)) / 127.0
        pitch = int(note["pitch"])
        register = 1.0
        if bass:
            register = 1.28 if pitch < 48 else 1.0 if pitch < 60 else 0.58
        values[pitch % 12] += overlap * (0.32 + velocity) * register
    return values


def _candidate_chords(
    weights: list[float],
    bass_weights: list[float],
    scale: set[int],
) -> list[dict[str, Any]]:
    total = sum(weights)
    if total < 0.035:
        return []
    bass_total = sum(bass_weights)
    bass_pc = max(range(12), key=bass_weights.__getitem__) if bass_total > 0.02 else None
    candidates: list[dict[str, Any]] = []
    for root in range(12):
        for quality, intervals in CHORD_DEFINITIONS.items():
            pcs = {(root + interval) % 12 for interval in intervals}
            inside = sum(weights[pc] for pc in pcs)
            outside = total - inside
            root_weight = weights[root]
            third_pc = (root + intervals[1]) % 12 if len(intervals) > 1 else root
            fifth_pc = (root + intervals[2]) % 12 if len(intervals) > 2 else root
            essential = weights[third_pc] + 0.45 * weights[fifth_pc]
            seventh_weight = weights[(root + intervals[3]) % 12] if len(intervals) > 3 else 0.0
            score = inside * 1.16 - outside * 0.34 + root_weight * 0.16 + essential * 0.10
            if len(intervals) > 3:
                score += seventh_weight * 0.13
                # Do not prefer a seventh chord when the seventh is only noise.
                if seventh_weight < total * 0.018:
                    score -= total * 0.055
            if quality in {"dim7", "half-dim7", "major7"}:
                score -= total * 0.012
            if root in scale:
                score += total * 0.045
            if bass_pc is not None:
                if bass_pc == root:
                    score += bass_weights[bass_pc] * 0.42
                elif bass_pc in pcs:
                    score += bass_weights[bass_pc] * 0.22
                else:
                    score -= bass_weights[bass_pc] * 0.18
            confidence = max(0.0, min(1.0, inside / max(total, 1e-9)))
            candidates.append({
                "root": root,
                "quality": quality,
                "bass_pc": bass_pc if bass_pc in pcs else root,
                "pcs": pcs,
                "score_raw": score,
                "confidence": confidence,
            })
    candidates.sort(key=lambda item: float(item["score_raw"]), reverse=True)
    return candidates[:10]


def _chord_transition(previous: dict[str, Any], current: dict[str, Any]) -> float:
    previous_pcs = set(previous["pcs"])
    current_pcs = set(current["pcs"])
    shared = len(previous_pcs & current_pcs)
    root_a = int(previous["root"])
    root_b = int(current["root"])
    distance = min((root_b - root_a) % 12, (root_a - root_b) % 12)
    value = shared * 0.052 - distance * 0.012
    if root_a == root_b and previous["quality"] == current["quality"]:
        value += 0.24
    elif root_a == root_b:
        value += 0.08
    if distance in {5, 7}:
        value += 0.075
    if int(previous.get("bass_pc", root_a)) == int(current.get("bass_pc", root_b)):
        value += 0.025
    return value


def infer_chord_timeline(
    notes: list[dict[str, Any]],
    bass_notes: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    duration_seconds: float,
    key_info: dict[str, Any] | None = None,
    rhythm_map: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Infer a smoothed chord sequence aligned to musical measures.

    AudioSheet 1.3 no longer slices harmony from second zero with a constant
    half-measure duration.  When a rhythm map is available, every window starts
    on a detected downbeat or half-measure boundary, including pickup and 2/4
    bars.  This prevents one window from mixing the tail of one chord with the
    attack of the next.
    """
    if not math.isfinite(float(bpm)) or not 30 <= float(bpm) <= 250:
        bpm = 100.0
    duration = max(duration_seconds, max((float(n["end"]) for n in notes + bass_notes), default=0.0))
    if duration <= 0:
        return []
    tonic = int((key_info or {}).get("tonic", 0))
    mode = str((key_info or {}).get("mode", "major"))
    scale_steps = (0, 2, 4, 5, 7, 9, 11) if mode == "major" else (0, 2, 3, 5, 7, 8, 10)
    scale = {(tonic + value) % 12 for value in scale_steps}

    aligned_windows = harmonic_windows(rhythm_map)
    if not aligned_windows:
        window = _harmonic_window_seconds(bpm, time_signature)
        count = max(1, math.ceil(duration / window))
        aligned_windows = [
            {"start": index * window, "end": min(duration, (index + 1) * window), "measure": index + 1}
            for index in range(count)
        ]

    windows: list[dict[str, Any]] = []
    for item in aligned_windows:
        start = max(0.0, float(item.get("start", 0)))
        end = min(duration, float(item.get("end", start)))
        if end <= start + 0.04:
            continue
        weights = _weighted_pitch_classes(notes, start, end)
        bass_weights = _weighted_pitch_classes(bass_notes, start, end, bass=True)
        merged = [weights[pc] + bass_weights[pc] * 0.55 for pc in range(12)]
        windows.append({
            "start": start,
            "end": end,
            "measure": int(item.get("measure", 0)),
            "start_quarter": item.get("start_quarter"),
            "end_quarter": item.get("end_quarter"),
            "candidates": _candidate_chords(merged, bass_weights, scale),
        })

    last_candidates: list[dict[str, Any]] = []
    for item in windows:
        if item["candidates"]:
            last_candidates = item["candidates"]
        elif last_candidates:
            item["candidates"] = [dict(candidate, score_raw=float(candidate["score_raw"]) - 0.12) for candidate in last_candidates[:4]]
    next_candidates: list[dict[str, Any]] = []
    for item in reversed(windows):
        if item["candidates"]:
            next_candidates = item["candidates"]
        elif next_candidates:
            item["candidates"] = [dict(candidate, score_raw=float(candidate["score_raw"]) - 0.18) for candidate in next_candidates[:4]]
    windows = [item for item in windows if item["candidates"]]
    if not windows:
        return []

    scores: list[list[float]] = []
    back: list[list[int]] = []
    first = windows[0]["candidates"]
    scores.append([float(candidate["score_raw"]) for candidate in first])
    back.append([-1] * len(first))
    for index in range(1, len(windows)):
        previous_candidates = windows[index - 1]["candidates"]
        current_candidates = windows[index]["candidates"]
        current_scores: list[float] = []
        current_back: list[int] = []
        for current in current_candidates:
            best_score = -1e18
            best_parent = 0
            for parent_index, previous in enumerate(previous_candidates):
                candidate_score = scores[index - 1][parent_index] + _chord_transition(previous, current)
                if candidate_score > best_score:
                    best_score = candidate_score
                    best_parent = parent_index
            current_scores.append(best_score + float(current["score_raw"]))
            current_back.append(best_parent)
        scores.append(current_scores)
        back.append(current_back)

    cursor = max(range(len(scores[-1])), key=scores[-1].__getitem__)
    chosen: list[dict[str, Any]] = []
    for index in range(len(windows) - 1, -1, -1):
        chord = dict(windows[index]["candidates"][cursor])
        chord["start"] = round(float(windows[index]["start"]), 5)
        chord["end"] = round(float(windows[index]["end"]), 5)
        chord["measure"] = int(windows[index].get("measure", 0))
        if windows[index].get("start_quarter") is not None:
            chord["start_quarter"] = round(float(windows[index]["start_quarter"]), 6)
            chord["end_quarter"] = round(float(windows[index]["end_quarter"]), 6)
        chosen.append(chord)
        cursor = back[index][cursor]
        if cursor < 0 and index:
            cursor = 0
    chosen.reverse()

    timeline: list[dict[str, Any]] = []
    for chord in chosen:
        root = int(chord["root"]); quality = str(chord["quality"]); bass_pc = int(chord.get("bass_pc", root))
        public = {
            "start": chord["start"], "end": chord["end"],
            "root": root, "quality": quality, "bass_pc": bass_pc,
            "name": _chord_name(root, quality, bass_pc),
            "confidence": round(float(chord.get("confidence", 0.0)), 3),
            "measure": int(chord.get("measure", 0)),
        }
        if "start_quarter" in chord:
            public["start_quarter"] = chord["start_quarter"]
            public["end_quarter"] = chord["end_quarter"]
        if (timeline and timeline[-1]["root"] == root and timeline[-1]["quality"] == quality
                and timeline[-1].get("bass_pc") == bass_pc
                and abs(float(timeline[-1]["end"]) - float(public["start"])) < 0.035):
            timeline[-1]["end"] = public["end"]
            if "end_quarter" in public:
                timeline[-1]["end_quarter"] = public["end_quarter"]
            timeline[-1]["confidence"] = round((float(timeline[-1]["confidence"]) + public["confidence"]) / 2, 3)
        else:
            timeline.append(public)
    return timeline

def _root_midi(root: int, target: int, low: int = 35, high: int = 52) -> int:
    choices = [pitch for pitch in range(low, high + 1) if pitch % 12 == root]
    return min(choices, key=lambda pitch: abs(pitch - target)) if choices else max(low, min(high, target))


def _nearest_pitch_for_pc(pc: int, target: int, low: int, high: int) -> int:
    choices = [pitch for pitch in range(low, high + 1) if pitch % 12 == pc % 12]
    return min(choices, key=lambda pitch: abs(pitch - target)) if choices else max(low, min(high, target))


def _active_melody_pitch(melody: list[dict[str, Any]], at: float) -> int | None:
    active = [
        int(note["pitch"]) for note in melody
        if float(note["start"]) - 0.03 <= at < float(note["end"]) + 0.03
    ]
    return max(active) if active else None


def _choose_voicing(
    chord: dict[str, Any],
    melody_pitch: int | None,
    previous: tuple[int, ...] | None,
    count: int,
    low: int = 52,
    high: int = 79,
) -> tuple[int, ...]:
    pcs = _chord_pitch_classes(chord)
    ceiling = min(high, melody_pitch - 2) if melody_pitch is not None else high
    if ceiling < low + count - 1:
        ceiling = high
    candidates = [pitch for pitch in range(low, ceiling + 1) if pitch % 12 in pcs]
    best: tuple[float, tuple[int, ...]] | None = None
    for combo in combinations(candidates, min(count, len(pcs))):
        if len({pitch % 12 for pitch in combo}) < len(combo):
            continue
        span = combo[-1] - combo[0]
        if span > (17 if count >= 3 else 13):
            continue
        score = abs(sum(combo) / len(combo) - 64.0) * 0.28 + span * 0.08
        if previous:
            prev = tuple(sorted(previous))
            for index, pitch in enumerate(combo):
                score += abs(pitch - prev[min(index, len(prev) - 1)]) * 0.34
        root = int(chord.get("root", 0)) % 12
        intervals = CHORD_DEFINITIONS.get(str(chord.get("quality", "major")), CHORD_DEFINITIONS["major"])
        third_pc = (root + intervals[1]) % 12 if len(intervals) > 1 else root
        if third_pc not in {pitch % 12 for pitch in combo}:
            score += 4.0
        if len(intervals) > 3 and (root + intervals[3]) % 12 not in {pitch % 12 for pitch in combo}:
            score += 2.2
        if melody_pitch is not None:
            score += sum(max(0, 3 - abs(melody_pitch - pitch)) * 2.0 for pitch in combo)
        item = (score, tuple(combo))
        if best is None or item < best:
            best = item
    if best:
        return best[1]
    fallback = sorted(_nearest_pitch_for_pc(pc, 64, low, high) for pc in sorted(pcs))
    return tuple(fallback[:count])


def _generated_note(
    start: float, end: float, pitch: int, velocity: int, staff: str, role: str, chord: dict[str, Any]
) -> dict[str, Any]:
    return {
        "start": round(max(0.0, start), 5),
        "end": round(max(start + 0.055, end), 5),
        "pitch": max(0, min(127, int(pitch))),
        "velocity": max(1, min(127, int(velocity))),
        "source": "generated_arrangement",
        "generated": True,
        "staff": staff,
        "role": role,
        "chord": chord.get("name", ""),
    }


def _chord_quarter_bounds(
    chord: dict[str, Any], rhythm_map: dict[str, Any] | None, bpm: float
) -> tuple[float, float]:
    if chord.get("start_quarter") is not None and chord.get("end_quarter") is not None:
        return float(chord["start_quarter"]), float(chord["end_quarter"])
    return (
        time_to_quarter(rhythm_map, float(chord.get("start", 0)), bpm),
        time_to_quarter(rhythm_map, float(chord.get("end", 0)), bpm),
    )


def _generated_note_q(
    start_q: float,
    end_q: float,
    pitch: int,
    velocity: int,
    staff: str,
    role: str,
    chord: dict[str, Any],
    rhythm_map: dict[str, Any] | None,
    bpm: float,
) -> dict[str, Any]:
    start = quarter_to_time(rhythm_map, start_q, bpm)
    end = quarter_to_time(rhythm_map, max(start_q + 0.05, end_q), bpm)
    note = _generated_note(start, end, pitch, velocity, staff, role, chord)
    note["score_start_q"] = round(start_q, 6)
    note["score_end_q"] = round(max(start_q + 0.05, end_q), 6)
    return note


def build_easy_arrangement(
    melody: list[dict[str, Any]],
    chords: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    rhythm_map: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Melody plus sparse root/fifth bass aligned to detected beats."""
    result = [dict(note, staff="upper", role="melody") for note in melody]
    previous_bass = 43
    for chord in chords:
        start_q, end_q = _chord_quarter_bounds(chord, rhythm_map, bpm)
        span_q = end_q - start_q
        if span_q <= 0.05:
            continue
        bass_pc = int(chord.get("bass_pc", chord["root"]))
        bass_pitch = _nearest_pitch_for_pc(bass_pc, previous_bass, 35, 52)
        previous_bass = bass_pitch
        fifth_pitch = _nearest_pitch_for_pc((int(chord["root"]) + 7) % 12, bass_pitch + 5, 38, 57)
        length_q = min(0.88, span_q)
        result.append(_generated_note_q(start_q, start_q + length_q, bass_pitch, 44, "lower", "bass_root", chord, rhythm_map, bpm))
        second_q = start_q + span_q / 2.0
        if second_q < end_q - 0.18:
            result.append(_generated_note_q(second_q, min(end_q, second_q + length_q), fifth_pitch, 37, "lower", "bass_fifth", chord, rhythm_map, bpm))
    result.sort(key=lambda n: (float(n["start"]), str(n.get("staff")), -int(n["pitch"])))
    return result


def build_light_arrangement(
    melody: list[dict[str, Any]],
    chords: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    rhythm_map: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    return build_easy_arrangement(melody, chords, bpm, time_signature, rhythm_map)


def build_standard_arrangement(
    melody: list[dict[str, Any]],
    chords: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    rhythm_map: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Melody, voice-led shells and a downbeat-aware two-pulse left hand."""
    result = [dict(note, staff="upper", role="melody") for note in melody]
    previous_bass = 43
    previous_voicing: tuple[int, ...] | None = None
    for chord in chords:
        start_q, end_q = _chord_quarter_bounds(chord, rhythm_map, bpm)
        span_q = end_q - start_q
        if span_q <= 0.05:
            continue
        root = int(chord["root"]); bass_pc = int(chord.get("bass_pc", root))
        bass_pitch = _nearest_pitch_for_pc(bass_pc, previous_bass, 34, 50)
        previous_bass = bass_pitch
        fifth = _nearest_pitch_for_pc((root + 7) % 12, bass_pitch + 7, 40, 59)
        bass_len_q = min(span_q, 0.88)
        result.append(_generated_note_q(start_q, start_q + bass_len_q, bass_pitch, 48, "lower", "bass_root", chord, rhythm_map, bpm))
        midpoint_q = start_q + span_q / 2.0
        if midpoint_q < end_q - 0.15:
            second = fifth if abs(fifth - bass_pitch) <= 12 else bass_pitch + 12
            result.append(_generated_note_q(midpoint_q, min(end_q, midpoint_q + bass_len_q), second, 41, "lower", "bass_motion", chord, rhythm_map, bpm))

        voicing_qs = [start_q]
        if span_q >= 3.2:
            voicing_qs.append(midpoint_q)
        for at_q in voicing_qs:
            at = quarter_to_time(rhythm_map, at_q, bpm)
            melody_pitch = _active_melody_pitch(melody, at)
            voicing = _choose_voicing(chord, melody_pitch, previous_voicing, 2, 52, 76)
            previous_voicing = voicing
            length_q = min(end_q - at_q, 1.65)
            for pitch in voicing:
                if melody_pitch is not None and abs(pitch - melody_pitch) <= 1:
                    continue
                result.append(_generated_note_q(at_q, at_q + length_q, pitch, 43, "upper", "rh_voicing", chord, rhythm_map, bpm))
    return _density_prune(clean_notes(result), max_at_once=6)


def _chord_at(chords: list[dict[str, Any]], at: float) -> dict[str, Any] | None:
    for chord in chords:
        if float(chord["start"]) - 0.02 <= at < float(chord["end"]) + 0.02:
            return chord
    return None


def build_rich_arrangement(
    melody: list[dict[str, Any]],
    chords: list[dict[str, Any]],
    other_notes: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    key_info: dict[str, Any] | None = None,
    rhythm_map: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Full piano arrangement aligned to quarter/eighth positions of the grid."""
    result = [dict(note, staff="upper", role="melody") for note in melody]
    previous_bass = 42
    previous_voicing: tuple[int, ...] | None = None
    for chord in chords:
        start_q, end_q = _chord_quarter_bounds(chord, rhythm_map, bpm)
        span_q = end_q - start_q
        if span_q <= 0.05:
            continue
        root = int(chord["root"]); bass_pc = int(chord.get("bass_pc", root))
        bass = _nearest_pitch_for_pc(bass_pc, previous_bass, 33, 49)
        previous_bass = bass
        intervals = CHORD_DEFINITIONS.get(str(chord.get("quality", "major")), (0, 4, 7))
        third_pc = (root + intervals[1]) % 12
        fifth_pc = (root + 7) % 12
        root_oct = _nearest_pitch_for_pc(root, bass + 12, 45, 62)
        third = _nearest_pitch_for_pc(third_pc, root_oct + 3, 47, 65)
        fifth = _nearest_pitch_for_pc(fifth_pc, root_oct + 7, 47, 67)
        pattern = (bass, fifth, root_oct, third, fifth, third, root_oct, fifth)
        cursor_q = start_q; index = 0
        while cursor_q < end_q - 0.08:
            pitch = pattern[index % len(pattern)]
            accent = 50 if index % 4 == 0 else 39 if index % 2 else 43
            result.append(_generated_note_q(cursor_q, min(end_q, cursor_q + 0.41), pitch, accent, "lower", "lh_arpeggio", chord, rhythm_map, bpm))
            cursor_q += 0.5
            index += 1

        at_q = start_q
        while at_q < end_q - 0.12:
            at = quarter_to_time(rhythm_map, at_q, bpm)
            melody_pitch = _active_melody_pitch(melody, at)
            voicing = _choose_voicing(chord, melody_pitch, previous_voicing, 3, 51, 78)
            previous_voicing = voicing
            length_q = min(end_q - at_q, 1.8)
            for pitch in voicing:
                if melody_pitch is not None and abs(pitch - melody_pitch) <= 1:
                    continue
                result.append(_generated_note_q(at_q, at_q + length_q, pitch, 39, "upper", "rh_voicing", chord, rhythm_map, bpm))
            at_q += 2.0

    tonic = int((key_info or {}).get("tonic", 0)); mode = str((key_info or {}).get("mode", "major"))
    scale_steps = (0, 2, 4, 5, 7, 9, 11) if mode == "major" else (0, 2, 3, 5, 7, 8, 10)
    scale = {(tonic + step) % 12 for step in scale_steps}
    last_fill = -10.0
    for note in other_notes:
        start = float(note["start"]); duration = float(note["end"]) - start; pitch = int(note["pitch"])
        if start < last_fill + 0.28 or duration < 0.075 or not 55 <= pitch <= 88 or int(note["velocity"]) < 38:
            continue
        if _active_melody_pitch(melody, start) is not None:
            continue
        chord = _chord_at(chords, start)
        if chord is None:
            continue
        if pitch % 12 not in _chord_pitch_classes(chord) and pitch % 12 not in scale:
            continue
        fill = dict(note)
        fill.update(
            staff="upper", role="fill", source="other_fill", generated=True,
            velocity=max(35, min(67, round(int(note["velocity"]) * 0.67))),
            end=round(min(float(note["end"]), start + 0.78), 5),
        )
        result.append(fill); last_fill = start
    return _density_prune(clean_notes(result), max_at_once=8)


def build_arrangement_levels(
    melody: list[dict[str, Any]],
    chords: list[dict[str, Any]],
    bass_notes: list[dict[str, Any]],
    other_notes: list[dict[str, Any]],
    bpm: float,
    time_signature: str,
    key_info: dict[str, Any] | None = None,
    rhythm_map: dict[str, Any] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    _ = bass_notes
    return {
        "light_easy": build_easy_arrangement(melody, chords, bpm, time_signature, rhythm_map),
        "light_standard": build_standard_arrangement(melody, chords, bpm, time_signature, rhythm_map),
        "light_full": build_rich_arrangement(melody, chords, other_notes, bpm, time_signature, key_info, rhythm_map),
    }

def _density_prune(notes: list[dict[str, Any]], max_at_once: int = 7) -> list[dict[str, Any]]:
    groups: list[list[dict[str, Any]]] = []
    for note in sorted(notes, key=lambda n: (float(n["start"]), -int(n["pitch"]))):
        if groups and float(note["start"]) - float(groups[-1][0]["start"]) <= 0.060:
            groups[-1].append(note)
        else:
            groups.append([note])
    result: list[dict[str, Any]] = []
    for group in groups:
        def score(note: dict[str, Any]) -> float:
            priority = {"melody": 100, "bass": 55, "bass_root": 50, "other": 0}.get(str(note.get("role")), 10)
            duration = float(note["end"]) - float(note["start"])
            return priority + int(note["velocity"]) * 0.5 + min(duration, 2.0) * 10
        selected: list[dict[str, Any]] = []
        used_pitch: set[int] = set()
        for note in sorted(group, key=score, reverse=True):
            pitch = int(note["pitch"])
            if pitch in used_pitch:
                continue
            selected.append(note)
            used_pitch.add(pitch)
            if len(selected) >= max_at_once:
                break
        result.extend(selected)
    result.sort(key=lambda n: (float(n["start"]), -int(n["pitch"])))
    return result


def build_full_arrangement(
    melody: list[dict[str, Any]],
    bass_notes: list[dict[str, Any]],
    other_notes: list[dict[str, Any]],
    split_pitch: int = 60,
) -> list[dict[str, Any]]:
    combined: list[dict[str, Any]] = []
    for note in melody:
        combined.append(dict(note, staff="upper", role="melody"))
    for note in bass_notes:
        if int(note["pitch"]) > 67 or int(note["velocity"]) < 24:
            continue
        combined.append(dict(note, staff="lower", role="bass", velocity=max(30, min(90, int(note["velocity"])))))
    for note in other_notes:
        duration = float(note["end"]) - float(note["start"])
        if duration < 0.07 or int(note["velocity"]) < 27:
            continue
        role = "other"
        staff = "lower" if int(note["pitch"]) < split_pitch else "upper"
        combined.append(dict(note, staff=staff, role=role, velocity=max(24, min(96, int(note["velocity"]) * 0.82))))
    combined = merge_fragments(clean_notes(combined), max_gap=0.045)
    combined = suppress_octave_harmonics(combined)
    return _density_prune(combined, max_at_once=7)


def _align_reference(reference_notes: list[dict[str, Any]], original: list[dict[str, Any]]) -> float:
    if not reference_notes or not original:
        return 0.0
    offset = round(float(original[0]["start"]) - float(reference_notes[0]["start"]), 4)
    if abs(offset) > 0.025:
        for note in reference_notes:
            note["start"] = round(max(0.0, float(note["start"]) + offset), 5)
            note["end"] = round(max(float(note["start"]) + 0.03, float(note["end"]) + offset), 5)
    return offset


def apply_reference_to_payload(payload: dict[str, Any], reference: Iterable[dict[str, Any]] | None) -> dict[str, Any]:
    if reference is None:
        payload["reference_active"] = False
        payload["reference_offset_seconds"] = 0.0
        return payload
    reference_notes = clean_notes(reference, default_source="reference")
    if not reference_notes:
        payload["reference_active"] = False
        payload["reference_offset_seconds"] = 0.0
        return payload
    original = payload.get("modes", {}).get("full", {}).get("notes", [])
    offset = _align_reference(reference_notes, original)
    payload = {**payload, "modes": {**payload.get("modes", {})}}
    payload["modes"]["full"] = {
        "label": "C · MIDI tham chiếu",
        "count": len(reference_notes),
        "notes": reference_notes,
    }
    payload["reference_active"] = True
    payload["reference_offset_seconds"] = offset
    return payload


def prepare_stem_variants(
    vocal_raw: Iterable[dict[str, Any]],
    bass_raw: Iterable[dict[str, Any]],
    other_raw: Iterable[dict[str, Any]],
    *,
    bpm: float,
    time_signature: str,
    duration_seconds: float,
    split_pitch: int = 60,
    reference: Iterable[dict[str, Any]] | None = None,
    rhythm_map: dict[str, Any] | None = None,
    quantization: int = 16,
) -> dict[str, Any]:
    vocal_original = clean_notes(vocal_raw, "vocals")
    bass_original = clean_notes(bass_raw, "bass")
    other_original = clean_notes(other_raw, "other")

    rhythm = rhythm_map or constant_rhythm_map(duration_seconds, bpm, time_signature)
    bpm = float(rhythm.get("bpm") or bpm)
    vocal = suppress_octave_harmonics(merge_fragments(vocal_original, max_gap=0.085))
    bass = suppress_octave_harmonics(merge_fragments(bass_original, max_gap=0.060))
    other = suppress_octave_harmonics(merge_fragments(other_original, max_gap=0.045))
    melody = extract_melody(vocal or other)
    melody = quantize_notes_to_rhythm(
        melody, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True, minimum_quarters=0.25
    )
    key_info = detect_key(melody + bass + other)
    chords = infer_chord_timeline(other, bass, bpm, time_signature, duration_seconds, key_info, rhythm)
    levels = build_arrangement_levels(melody, chords, bass, other, bpm, time_signature, key_info, rhythm)
    levels = {
        name: quantize_notes_to_rhythm(
            notes, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True, minimum_quarters=0.25
        )
        for name, notes in levels.items()
    }
    full = build_full_arrangement(melody, bass, other, split_pitch=split_pitch)
    full = quantize_notes_to_rhythm(
        full, rhythm, bpm=bpm, quantization=max(16, quantization), allow_triplets=True, minimum_quarters=0.125
    )
    duration = max(
        duration_seconds,
        max((float(n["end"]) for n in melody + full + sum(levels.values(), [])), default=0.0),
    )
    payload: dict[str, Any] = {
        "version": 4,
        "source": "Demucs stems + Basic Pitch + Beat/downbeat grid + AudioSheet arranger v3",
        "pipeline": "stem_separated",
        "arranger_version": "3.0",
        "duration_seconds": round(duration, 2),
        "rhythm": rhythm,
        "reference_active": False,
        "reference_offset_seconds": 0.0,
        "raw_count": len(vocal_original) + len(bass_original) + len(other_original),
        "merged_count": len(vocal) + len(bass) + len(other),
        "stem_counts": {
            "vocals_raw": len(vocal_original), "vocals_clean": len(vocal),
            "bass_raw": len(bass_original), "bass_clean": len(bass),
            "other_raw": len(other_original), "other_clean": len(other),
        },
        "analysis": {"key": key_info, "chords": chords, "rhythm": rhythm},
        "arrangement_levels": {"default": "light_standard", "available": list(ARRANGEMENT_LEVELS)},
        "modes": {
            "melody": {"label": "A · Giai điệu hát", "count": len(melody), "notes": melody},
            "light_easy": {"label": "B · Dễ", "count": len(levels["light_easy"]), "notes": levels["light_easy"]},
            "light_standard": {"label": "B · Tiêu chuẩn", "count": len(levels["light_standard"]), "notes": levels["light_standard"]},
            "light_full": {"label": "B · Đầy đủ", "count": len(levels["light_full"]), "notes": levels["light_full"]},
            "full": {"label": "C · Phiên âm đầy đủ", "count": len(full), "notes": full},
        },
    }
    payload["modes"]["light"] = dict(payload["modes"]["light_standard"], alias_of="light_standard")
    return apply_reference_to_payload(payload, reference)


def ensure_arrangement_levels(
    payload: dict[str, Any],
    *,
    bpm: float,
    time_signature: str,
    split_pitch: int = 60,
    rhythm_map: dict[str, Any] | None = None,
    quantization: int = 16,
) -> dict[str, Any]:
    """Upgrade older arrangements and align them to the rhythm map."""
    modes = payload.setdefault("modes", {})
    duration = float(payload.get("duration_seconds") or 0.0)
    rhythm = rhythm_map or (payload.get("rhythm") if isinstance(payload.get("rhythm"), dict) else None)
    rhythm = rhythm or constant_rhythm_map(duration or 1.0, bpm, time_signature)
    bpm = float(rhythm.get("bpm") or bpm)
    if (int(payload.get("version") or 0) >= 4 and
            all(name in modes and isinstance(modes[name], dict) for name in ARRANGEMENT_LEVELS)):
        payload["rhythm"] = rhythm
        payload.setdefault("analysis", {})["rhythm"] = rhythm
        payload.setdefault("arrangement_levels", {"default": "light_standard", "available": list(ARRANGEMENT_LEVELS)})
        modes["light"] = dict(modes["light_standard"], alias_of="light_standard")
        return payload

    melody = clean_notes((modes.get("melody") or {}).get("notes", []), "vocals")
    full = clean_notes((modes.get("full") or {}).get("notes", []))
    bass = [
        note for note in full
        if note.get("source") == "bass" or str(note.get("role", "")).startswith("bass")
        or (note.get("staff") == "lower" and int(note["pitch"]) < split_pitch)
    ]
    other = [
        note for note in full
        if note.get("source") in {"other", "full_mix"} or note.get("role") in {"other", "fill"}
    ]
    if not other:
        other = [note for note in full if note not in bass and note.get("role") != "melody"]
    melody = quantize_notes_to_rhythm(
        melody, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True, minimum_quarters=0.25
    )
    analysis = payload.setdefault("analysis", {})
    key_info = analysis.get("key") if isinstance(analysis.get("key"), dict) else detect_key(melody + bass + other)
    chords = infer_chord_timeline(other or full, bass, bpm, time_signature, duration, key_info, rhythm)
    levels = build_arrangement_levels(melody, chords, bass, other, bpm, time_signature, key_info, rhythm)
    levels = {
        name: quantize_notes_to_rhythm(
            notes, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True, minimum_quarters=0.25
        )
        for name, notes in levels.items()
    }
    for name, notes in levels.items():
        label = {"light_easy": "B · Dễ", "light_standard": "B · Tiêu chuẩn", "light_full": "B · Đầy đủ"}[name]
        modes[name] = {"label": label, "count": len(notes), "notes": notes}
    modes["melody"] = {"label": (modes.get("melody") or {}).get("label", "A · Giai điệu"), "count": len(melody), "notes": melody}
    modes["light"] = dict(modes["light_standard"], alias_of="light_standard")
    analysis["key"] = key_info; analysis["chords"] = chords; analysis["rhythm"] = rhythm
    payload["version"] = 4; payload["arranger_version"] = "3.0"; payload["rhythm"] = rhythm
    payload["arrangement_levels"] = {"default": "light_standard", "available": list(ARRANGEMENT_LEVELS)}
    payload["source"] = str(payload.get("source") or "") + " · upgraded rhythm-grid arranger v3"
    return payload

def extract_light_bass(notes: list[dict[str, Any]], melody: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Backward-compatible fallback used for old full-mix jobs."""
    if not notes:
        return []
    pitches = [int(n["pitch"]) for n in notes]
    floor = min(59, int(_quantile(pitches, 0.36)))
    candidates = [n for n in notes if int(n["pitch"]) <= floor and int(n["velocity"]) >= 35]
    bass: list[dict[str, Any]] = []
    last_at = -5.0
    for note in sorted(candidates, key=lambda n: (float(n["start"]), -int(n["velocity"]))):
        if float(note["start"]) < last_at + 1.05:
            continue
        bass.append({
            "start": note["start"],
            "end": round(min(float(note["end"]), float(note["start"]) + 1.2), 5),
            "pitch": note["pitch"],
            "velocity": 35,
            "source": "fallback_mix",
            "staff": "lower",
            "role": "bass",
        })
        last_at = float(note["start"])
    return bass


def prepare_variants(
    raw: Iterable[dict[str, Any]],
    reference: Iterable[dict[str, Any]] | None = None,
    *,
    bpm: float = 100.0,
    time_signature: str = "4/4",
    split_pitch: int = 60,
    rhythm_map: dict[str, Any] | None = None,
    quantization: int = 16,
) -> dict[str, Any]:
    """Fallback for jobs that only have one full-mix transcription."""
    original = clean_notes(raw, "full_mix")
    merged = suppress_octave_harmonics(merge_fragments(original))
    duration = max((float(n["end"]) for n in original), default=0.0)
    rhythm = rhythm_map or constant_rhythm_map(duration or 1.0, bpm, time_signature)
    bpm = float(rhythm.get("bpm") or bpm)
    melody = extract_melody(merged)
    melody = quantize_notes_to_rhythm(
        melody, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True, minimum_quarters=0.25
    )
    key_info = detect_key(merged)
    bass = extract_light_bass(merged, melody)
    other = [note for note in merged if note not in bass]
    chords = infer_chord_timeline(merged, bass, bpm, time_signature, duration, key_info, rhythm)
    levels = build_arrangement_levels(melody, chords, bass, other, bpm, time_signature, key_info, rhythm)
    levels = {
        name: quantize_notes_to_rhythm(
            notes, rhythm, bpm=bpm, quantization=quantization, allow_triplets=True, minimum_quarters=0.25
        )
        for name, notes in levels.items()
    }
    full = [dict(n, staff="lower" if int(n["pitch"]) < split_pitch else "upper") for n in original]
    full = quantize_notes_to_rhythm(
        full, rhythm, bpm=bpm, quantization=max(16, quantization), allow_triplets=True, minimum_quarters=0.125
    )
    payload: dict[str, Any] = {
        "version": 4,
        "source": "Basic Pitch full mix + beat/downbeat grid + AudioSheet arranger v3",
        "pipeline": "legacy_full_mix",
        "arranger_version": "3.0",
        "raw_count": len(original), "merged_count": len(merged),
        "duration_seconds": round(duration, 2), "rhythm": rhythm,
        "reference_active": False, "reference_offset_seconds": 0.0,
        "analysis": {"key": key_info, "chords": chords, "rhythm": rhythm},
        "arrangement_levels": {"default": "light_standard", "available": list(ARRANGEMENT_LEVELS)},
        "modes": {
            "melody": {"label": "A · Giai điệu ước lượng", "count": len(melody), "notes": melody},
            "light_easy": {"label": "B · Dễ", "count": len(levels["light_easy"]), "notes": levels["light_easy"]},
            "light_standard": {"label": "B · Tiêu chuẩn", "count": len(levels["light_standard"]), "notes": levels["light_standard"]},
            "light_full": {"label": "B · Đầy đủ", "count": len(levels["light_full"]), "notes": levels["light_full"]},
            "full": {"label": "C · Toàn bộ nốt AI", "count": len(full), "notes": full},
        },
    }
    payload["modes"]["light"] = dict(payload["modes"]["light_standard"], alias_of="light_standard")
    return apply_reference_to_payload(payload, reference)

def midi_to_events(midi_path: str) -> list[dict[str, Any]]:
    import pretty_midi

    midi = pretty_midi.PrettyMIDI(midi_path)
    data: list[dict[str, Any]] = []
    for instrument in midi.instruments:
        if instrument.is_drum:
            continue
        for note in instrument.notes:
            data.append({
                "start": note.start,
                "end": note.end,
                "pitch": note.pitch,
                "velocity": note.velocity,
                "source": "reference",
            })
            if len(data) >= MAX_EVENTS:
                raise ValueError("Reference MIDI has too many notes (maximum 60000).")
    if not data:
        raise ValueError("The reference MIDI contains no playable pitched notes.")
    if max(float(n["end"]) for n in data) > 1200:
        raise ValueError("The reference MIDI is too long (over 20 minutes).")
    return clean_notes(data)


def write_mode_midi(
    notes: list[dict[str, Any]],
    out_path: str,
    bpm: float = 100,
    rhythm_map: dict[str, Any] | None = None,
) -> None:
    """Write MIDI with tempo/meter changes from the same grid as MusicXML."""
    if not rhythm_map:
        import pretty_midi

        midi = pretty_midi.PrettyMIDI(initial_tempo=float(bpm) if 30 <= float(bpm) <= 250 else 100)
        upper = pretty_midi.Instrument(program=0, name="AudioSheet Piano RH")
        lower = pretty_midi.Instrument(program=0, name="AudioSheet Piano LH")
        for note in clean_notes(notes):
            target = lower if note.get("staff") == "lower" else upper
            target.notes.append(pretty_midi.Note(
                velocity=int(note["velocity"]), pitch=int(note["pitch"]),
                start=float(note["start"]), end=float(note["end"]),
            ))
        if upper.notes: midi.instruments.append(upper)
        if lower.notes: midi.instruments.append(lower)
        if not midi.instruments: midi.instruments.append(upper)
        midi.write(out_path)
        return

    import mido

    ticks_per_beat = 480
    midi = mido.MidiFile(type=1, ticks_per_beat=ticks_per_beat)

    def q_tick(value: float) -> int:
        return max(0, int(round(value * ticks_per_beat)))

    def append_absolute(track: mido.MidiTrack, events: list[tuple[int, int, mido.Message | mido.MetaMessage]]) -> None:
        previous = 0
        for tick, _, message in sorted(events, key=lambda item: (item[0], item[1])):
            message.time = max(0, tick - previous)
            track.append(message)
            previous = tick
        track.append(mido.MetaMessage("end_of_track", time=0))

    meta = mido.MidiTrack(); midi.tracks.append(meta)
    meta_events: list[tuple[int, int, mido.MetaMessage]] = [(0, 0, mido.MetaMessage("track_name", name="AudioSheet Rhythm Map", time=0))]
    tempo_changes = rhythm_map.get("tempo_changes") if isinstance(rhythm_map.get("tempo_changes"), list) else []
    if not tempo_changes:
        tempo_changes = [{"quarter": 0.0, "bpm": float(rhythm_map.get("bpm") or bpm)}]
    if float(tempo_changes[0].get("quarter", 0)) > 1e-6:
        tempo_changes = [{"quarter": 0.0, "bpm": float(rhythm_map.get("bpm") or bpm)}] + tempo_changes
    for item in tempo_changes:
        value = max(30.0, min(250.0, float(item.get("bpm") or bpm)))
        meta_events.append((q_tick(float(item.get("quarter", 0))), 1, mido.MetaMessage("set_tempo", tempo=mido.bpm2tempo(value), time=0)))
    meter_changes = rhythm_map.get("meter_changes") if isinstance(rhythm_map.get("meter_changes"), list) else []
    if not meter_changes:
        meter_changes = [{"quarter": 0.0, "beats": 4, "beat_type": 4}]
    if float(meter_changes[0].get("quarter", 0)) > 1e-6:
        first_measure = (rhythm_map.get("measures") or [{}])[0]
        meter_changes = [{
            "quarter": 0.0, "beats": int(first_measure.get("beats", 4)),
            "beat_type": int(first_measure.get("beat_type", 4)),
        }] + meter_changes
    for item in meter_changes:
        meta_events.append((
            q_tick(float(item.get("quarter", 0))), 2,
            mido.MetaMessage(
                "time_signature", numerator=int(item.get("beats", 4)),
                denominator=int(item.get("beat_type", 4)), time=0,
            ),
        ))
    append_absolute(meta, meta_events)

    for staff, channel, name in (("upper", 0, "AudioSheet Piano RH"), ("lower", 1, "AudioSheet Piano LH")):
        track = mido.MidiTrack(); midi.tracks.append(track)
        events: list[tuple[int, int, mido.Message | mido.MetaMessage]] = [
            (0, 0, mido.MetaMessage("track_name", name=name, time=0)),
            (0, 1, mido.Message("program_change", program=0, channel=channel, time=0)),
        ]
        for note in clean_notes(notes):
            note_staff = "lower" if note.get("staff") == "lower" else "upper"
            if note_staff != staff:
                continue
            start_q = float(note.get("score_start_q", time_to_quarter(rhythm_map, float(note["start"]), bpm)))
            end_q = float(note.get("score_end_q", time_to_quarter(rhythm_map, float(note["end"]), bpm)))
            start_tick = q_tick(start_q); end_tick = max(start_tick + 15, q_tick(end_q))
            events.append((start_tick, 3, mido.Message("note_on", note=int(note["pitch"]), velocity=int(note["velocity"]), channel=channel, time=0)))
            events.append((end_tick, 2, mido.Message("note_off", note=int(note["pitch"]), velocity=0, channel=channel, time=0)))
        append_absolute(track, events)
    midi.save(out_path)

