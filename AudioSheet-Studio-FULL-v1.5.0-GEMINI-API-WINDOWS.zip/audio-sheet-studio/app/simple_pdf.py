from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET


_STEP_INDEX = {"C": 0, "D": 1, "E": 2, "F": 3, "G": 4, "A": 5, "B": 6}


class SimplePDFError(RuntimeError):
    pass


@dataclass
class ParsedNote:
    onset: int
    duration: int
    staff: int
    step: str | None = None
    alter: int = 0
    octave: int = 4
    note_type: str = "quarter"
    dotted: bool = False
    rest: bool = False


@dataclass
class ParsedHarmony:
    onset: int
    name: str


@dataclass
class ParsedMeasure:
    number: str
    duration: int
    notes: list[ParsedNote] = field(default_factory=list)
    harmonies: list[ParsedHarmony] = field(default_factory=list)


@dataclass
class ParsedScore:
    title: str
    divisions: int
    beats: int
    beat_type: int
    fifths: int
    staves: int
    tempo: float
    measures: list[ParsedMeasure]


def _strip_namespaces(root: ET.Element) -> None:
    for element in root.iter():
        if "}" in element.tag:
            element.tag = element.tag.split("}", 1)[1]


def _int_text(parent: ET.Element | None, path: str, default: int) -> int:
    if parent is None:
        return default
    try:
        return int(float(parent.findtext(path, str(default))))
    except (TypeError, ValueError):
        return default


def _float_text(parent: ET.Element | None, path: str, default: float) -> float:
    if parent is None:
        return default
    try:
        return float(parent.findtext(path, str(default)))
    except (TypeError, ValueError):
        return default


def _harmony_name(element: ET.Element) -> str:
    step = (element.findtext("root/root-step") or "C").strip().upper()
    alter = _int_text(element, "root/root-alter", 0)
    accidental = "#" if alter > 0 else "b" if alter < 0 else ""
    kind = element.find("kind")
    kind_value = (kind.text if kind is not None and kind.text else "major").strip()
    kind_text = kind.get("text", "") if kind is not None else ""
    suffixes = {
        "major": "",
        "minor": "m",
        "diminished": "dim",
        "augmented": "aug",
        "dominant": "7",
        "major-seventh": "maj7",
        "minor-seventh": "m7",
        "suspended-fourth": "sus4",
        "suspended-second": "sus2",
    }
    suffix = kind_text or suffixes.get(kind_value, kind_value if kind_value != "none" else "")
    return f"{step}{accidental}{suffix}"


def parse_musicxml(path: Path) -> ParsedScore:
    try:
        root = ET.fromstring(path.read_bytes())
    except Exception as exc:
        raise SimplePDFError(f"Could not parse MusicXML: {exc}") from exc
    _strip_namespaces(root)

    title = (
        root.findtext("movement-title")
        or root.findtext("work/work-title")
        or path.stem
        or "AudioSheet Studio"
    ).strip()
    part = root.find("part")
    if part is None:
        raise SimplePDFError("MusicXML has no score part")

    divisions = 480
    beats = 4
    beat_type = 4
    fifths = 0
    staves = 1
    tempo = 100.0
    measures: list[ParsedMeasure] = []

    for measure_element in part.findall("measure"):
        attributes = measure_element.find("attributes")
        if attributes is not None:
            divisions = max(1, _int_text(attributes, "divisions", divisions))
            beats = max(1, _int_text(attributes, "time/beats", beats))
            beat_type = max(1, _int_text(attributes, "time/beat-type", beat_type))
            fifths = max(-7, min(7, _int_text(attributes, "key/fifths", fifths)))
            staves = max(1, min(2, _int_text(attributes, "staves", staves)))
        sound = measure_element.find("direction/sound")
        if sound is not None and sound.get("tempo"):
            try:
                tempo = float(sound.get("tempo", tempo))
            except ValueError:
                pass

        nominal_duration = max(1, round(divisions * 4 * beats / beat_type))
        parsed = ParsedMeasure(
            number=measure_element.get("number", str(len(measures) + 1)),
            duration=nominal_duration,
        )
        cursor = 0
        previous_onset = 0
        max_end = nominal_duration

        for child in list(measure_element):
            tag = child.tag
            if tag == "backup":
                cursor = max(0, cursor - _int_text(child, "duration", 0))
                continue
            if tag == "forward":
                cursor += max(0, _int_text(child, "duration", 0))
                max_end = max(max_end, cursor)
                continue
            if tag == "harmony":
                offset = _int_text(child, "offset", 0)
                parsed.harmonies.append(ParsedHarmony(max(0, cursor + offset), _harmony_name(child)))
                continue
            if tag != "note":
                continue

            duration = max(1, _int_text(child, "duration", divisions))
            is_chord = child.find("chord") is not None
            onset = previous_onset if is_chord else cursor
            if not is_chord:
                previous_onset = onset
                cursor += duration
            max_end = max(max_end, onset + duration)
            staff = max(1, min(2, _int_text(child, "staff", 1)))
            rest = child.find("rest") is not None
            pitch = child.find("pitch")
            note = ParsedNote(
                onset=onset,
                duration=duration,
                staff=staff,
                note_type=(child.findtext("type") or "quarter").strip(),
                dotted=child.find("dot") is not None,
                rest=rest,
            )
            if not rest and pitch is not None:
                note.step = (pitch.findtext("step") or "C").strip().upper()
                note.alter = _int_text(pitch, "alter", 0)
                note.octave = _int_text(pitch, "octave", 4)
            parsed.notes.append(note)

        parsed.duration = max(nominal_duration, max_end)
        measures.append(parsed)

    if not measures:
        raise SimplePDFError("MusicXML has no measures")
    return ParsedScore(title, divisions, beats, beat_type, fifths, staves, tempo, measures)


def _diatonic_value(step: str, octave: int) -> int:
    return octave * 7 + _STEP_INDEX.get(step, 0)


def _note_y(note: ParsedNote, staff_bottom: float, staff_space: float, staff: int) -> float:
    base = _diatonic_value("E", 4) if staff == 1 else _diatonic_value("G", 2)
    return staff_bottom + (_diatonic_value(note.step or "C", note.octave) - base) * (staff_space / 2.0)


def _draw_ledger_lines(pdf, x: float, y: float, staff_bottom: float, staff_space: float) -> None:
    staff_top = staff_bottom + 4 * staff_space
    pdf.setLineWidth(0.7)
    if y < staff_bottom - staff_space * 0.25:
        line_y = staff_bottom - staff_space
        while line_y >= y - staff_space * 0.25:
            pdf.line(x - 7, line_y, x + 7, line_y)
            line_y -= staff_space
    elif y > staff_top + staff_space * 0.25:
        line_y = staff_top + staff_space
        while line_y <= y + staff_space * 0.25:
            pdf.line(x - 7, line_y, x + 7, line_y)
            line_y += staff_space


def _draw_note(pdf, note: ParsedNote, x: float, staff_bottom: float, staff_space: float, divisions: int) -> None:
    y = _note_y(note, staff_bottom, staff_space, note.staff)
    _draw_ledger_lines(pdf, x, y, staff_bottom, staff_space)
    if note.alter:
        pdf.setFont("Helvetica", 8)
        pdf.drawRightString(x - 6, y - 3, "#" if note.alter > 0 else "b")

    width = 7.2
    height = 5.1
    open_head = note.note_type in {"whole", "half"} or note.duration >= divisions * 2
    pdf.setLineWidth(0.9)
    pdf.ellipse(x - width / 2, y - height / 2, x + width / 2, y + height / 2, stroke=1, fill=0 if open_head else 1)
    if note.dotted:
        pdf.circle(x + 6.2, y, 1.1, stroke=0, fill=1)

    if note.note_type == "whole" or note.duration >= divisions * 4:
        return
    middle = staff_bottom + 2 * staff_space
    stem_up = y < middle
    stem_x = x + width / 2 if stem_up else x - width / 2
    stem_end = y + 24 if stem_up else y - 24
    pdf.setLineWidth(0.8)
    pdf.line(stem_x, y, stem_x, stem_end)

    flag_count = {"eighth": 1, "16th": 2, "32nd": 3, "64th": 4}.get(note.note_type, 0)
    if flag_count:
        direction = -1 if stem_up else 1
        for index in range(flag_count):
            start_y = stem_end - index * 5 * direction
            pdf.line(stem_x, start_y, stem_x + 7, start_y - 5 * direction)


def _draw_rest(pdf, x: float, staff_bottom: float, staff_space: float, full_measure: bool) -> None:
    y = staff_bottom + 2 * staff_space
    if full_measure:
        pdf.setFillColorRGB(0, 0, 0)
        pdf.rect(x - 4, y + 1, 8, 3, stroke=0, fill=1)
    else:
        pdf.setFont("Helvetica-Oblique", 8)
        pdf.drawCentredString(x, y - 3, "r")


def _key_text(fifths: int) -> str:
    if fifths > 0:
        return f"{fifths} sharp" + ("s" if fifths != 1 else "")
    if fifths < 0:
        count = abs(fifths)
        return f"{count} flat" + ("s" if count != 1 else "")
    return "C / A minor"


def _verify_pdf(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size < 900:
        return False
    data = path.read_bytes()
    return data.startswith(b"%PDF-") and b"%%EOF" in data[-2048:]


def export_simple_musicxml_pdf(musicxml_path: Path, pdf_path: Path) -> None:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
    except Exception as exc:
        raise SimplePDFError(f"ReportLab is unavailable: {exc}") from exc

    score = parse_musicxml(musicxml_path)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    page_width, page_height = A4
    left_margin = 38.0
    right_margin = 30.0
    bottom_margin = 34.0
    top_margin = 42.0
    usable_width = page_width - left_margin - right_margin
    staff_space = 7.0
    two_staves = score.staves > 1
    measures_per_system = 4 if two_staves else 5
    system_height = 118.0 if two_staves else 76.0

    pdf = canvas.Canvas(str(pdf_path), pagesize=A4, pageCompression=1)
    pdf.setTitle(score.title)
    pdf.setAuthor("AudioSheet Studio")
    page_number = 0
    first_page = True

    def start_page() -> float:
        nonlocal page_number, first_page
        if page_number:
            pdf.showPage()
        page_number += 1
        pdf.setFillColorRGB(0, 0, 0)
        y = page_height - top_margin
        if first_page:
            pdf.setFont("Helvetica-Bold", 16)
            pdf.drawString(left_margin, y, score.title[:90])
            y -= 19
            pdf.setFont("Helvetica", 8.5)
            pdf.drawString(
                left_margin,
                y,
                f"Tempo {score.tempo:g} BPM   Time {score.beats}/{score.beat_type}   Key {_key_text(score.fifths)}",
            )
            y -= 22
            first_page = False
        else:
            pdf.setFont("Helvetica-Bold", 9)
            pdf.drawString(left_margin, y, score.title[:80])
            y -= 20
        return y

    def finish_page() -> None:
        pdf.setFont("Helvetica", 7)
        pdf.drawRightString(page_width - right_margin, 18, f"Page {page_number} - AudioSheet Studio")

    y_top = start_page()
    for system_start in range(0, len(score.measures), measures_per_system):
        system_measures = score.measures[system_start:system_start + measures_per_system]
        if y_top - system_height < bottom_margin:
            finish_page()
            y_top = start_page()

        treble_bottom = y_top - 38
        bass_bottom = treble_bottom - 58
        active_staff_bottoms = {1: treble_bottom}
        if two_staves:
            active_staff_bottoms[2] = bass_bottom
        measure_width = usable_width / max(1, len(system_measures))

        for staff_bottom in active_staff_bottoms.values():
            pdf.setLineWidth(0.65)
            for line_index in range(5):
                line_y = staff_bottom + line_index * staff_space
                pdf.line(left_margin, line_y, left_margin + usable_width, line_y)

        if two_staves:
            pdf.setLineWidth(1.0)
            pdf.line(left_margin, bass_bottom, left_margin, treble_bottom + 4 * staff_space)
            pdf.setFont("Times-BoldItalic", 15)
            pdf.drawString(left_margin + 3, treble_bottom + staff_space * 0.5, "G")
            pdf.drawString(left_margin + 3, bass_bottom + staff_space * 1.5, "F")
        else:
            pdf.setFont("Times-BoldItalic", 15)
            pdf.drawString(left_margin + 3, treble_bottom + staff_space * 0.5, "G")

        for local_index, measure in enumerate(system_measures):
            measure_x = left_margin + local_index * measure_width
            next_x = measure_x + measure_width
            pdf.setLineWidth(0.75)
            pdf.line(measure_x, active_staff_bottoms.get(2, treble_bottom), measure_x, treble_bottom + 4 * staff_space)
            if local_index == len(system_measures) - 1:
                pdf.line(next_x, active_staff_bottoms.get(2, treble_bottom), next_x, treble_bottom + 4 * staff_space)
            pdf.setFont("Helvetica", 6.5)
            pdf.drawString(measure_x + 2, treble_bottom + 4 * staff_space + 7, str(measure.number))

            inner_left = measure_x + (18 if local_index == 0 else 8)
            inner_right = next_x - 6
            inner_width = max(12.0, inner_right - inner_left)
            duration = max(1, measure.duration)

            for harmony in measure.harmonies:
                hx = inner_left + min(1.0, max(0.0, harmony.onset / duration)) * inner_width
                pdf.setFont("Helvetica-Bold", 7.5)
                pdf.drawString(hx, treble_bottom + 4 * staff_space + 15, harmony.name[:12])

            pitched_by_staff = {1: 0, 2: 0}
            rest_by_staff = {1: 0, 2: 0}
            for note in measure.notes:
                staff = note.staff if two_staves else 1
                if staff not in active_staff_bottoms:
                    staff = 1
                note.staff = staff
                x = inner_left + min(1.0, max(0.0, note.onset / duration)) * inner_width
                if note.rest:
                    rest_by_staff[staff] += 1
                    continue
                pitched_by_staff[staff] += 1
                _draw_note(pdf, note, x, active_staff_bottoms[staff], staff_space, score.divisions)

            for staff, staff_bottom in active_staff_bottoms.items():
                if pitched_by_staff[staff] == 0:
                    _draw_rest(pdf, (inner_left + inner_right) / 2, staff_bottom, staff_space, True)

        y_top -= system_height

    finish_page()
    pdf.save()
    if not _verify_pdf(pdf_path):
        pdf_path.unlink(missing_ok=True)
        raise SimplePDFError("ReportLab created an invalid PDF")
