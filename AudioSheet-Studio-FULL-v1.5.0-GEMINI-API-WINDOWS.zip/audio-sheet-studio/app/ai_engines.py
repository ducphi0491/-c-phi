"""Optional isolated AI engines for AudioSheet Studio.

SheetSage2 runs in a native Windows CPU-only venv on Windows, including Server
2019. Pop2Piano still uses Linux/WSL because of its Essentia dependency.
No model packages are imported in the FastAPI website process.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from .config import ROOT_DIR

ENGINE_META = {
    "sheetsage2": {
        "name": "SheetSage2 (non-commercial research)",
        "repository": "m-a-p/SheetSage2",
        "license": "CC BY-NC 4.0 model weights; non-commercial research only",
        "venv": ".ai-sheetsage2-venv",  # Existing Linux/WSL runtime.
        "windows_venv": ".sheetsage2-venv",  # Native Windows Server 2019 runtime.
    },
    "pop2piano": {
        "name": "Pop2Piano (experimental piano cover)",
        "repository": "sweetcocoa/pop2piano",
        "license": "Checkpoint rights must be checked; Essentia AGPL-3.0",
        "venv": ".ai-pop2piano-venv",
    },
}
NATIVE_INSTALL_MARKER = ".audiosheet-installed.json"


class AIEngineError(RuntimeError):
    """A selected external engine cannot run or produced an invalid result."""


def _is_windows() -> bool:
    return sys.platform == "win32"


def _venv_dir(engine: str) -> Path:
    meta = ENGINE_META[engine]
    if _is_windows() and engine == "sheetsage2":
        return ROOT_DIR / meta["windows_venv"]
    return ROOT_DIR / meta["venv"]


def _venv_marker(engine: str) -> Path:
    return _venv_dir(engine) / "pyvenv.cfg"


def _native_python() -> Path:
    return _venv_dir("sheetsage2") / "Scripts" / "python.exe"


def _native_installed() -> bool:
    """Installer writes a marker only AFTER pinned packages pass import checks."""
    if not _venv_marker("sheetsage2").is_file() or not _native_python().is_file():
        return False
    marker = _venv_dir("sheetsage2") / NATIVE_INSTALL_MARKER
    try:
        status = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return isinstance(status, dict) and status.get("engine") == "sheetsage2" and status.get("complete") is True


def available_engines() -> dict[str, dict[str, Any]]:
    """Fast package readiness check. A model checkpoint may still need download."""
    on_windows = _is_windows()
    wsl_executable = shutil.which("wsl.exe") if on_windows else None
    result: dict[str, dict[str, Any]] = {}
    for engine, meta in ENGINE_META.items():
        if on_windows and engine == "sheetsage2":
            installed = _native_installed()
            runtime = "native_windows_cpu"
            requires_wsl = False
            venv = meta["windows_venv"]
        else:
            linux_python = _venv_dir(engine) / "bin" / "python"
            runtime_ready = bool(wsl_executable) if on_windows else linux_python.is_file()
            installed = bool(_venv_marker(engine).is_file() and runtime_ready)
            runtime = "wsl2_linux" if on_windows else "linux"
            requires_wsl = on_windows
            venv = meta["venv"]
        result[engine] = {
            "name": meta["name"],
            "repository": meta["repository"],
            "license": meta["license"],
            "installed": installed,
            "runtime": runtime,
            "venv": venv,
            "requires_wsl_on_windows": requires_wsl,
            "model_downloaded": "unknown",  # Do not confuse pip with checkpoint downloads.
        }
    return result


def _wsl_path(path: Path) -> str:
    try:
        process = subprocess.run(
            ["wsl.exe", "--exec", "wslpath", "-a", "-u", str(path.resolve())],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=20, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise AIEngineError("Cannot reach WSL2; verify Ubuntu is installed and started.") from exc
    if process.returncode != 0 or not process.stdout.strip():
        raise AIEngineError("WSL2 could not translate the project path: " + process.stderr.strip()[:250])
    return process.stdout.strip()


def _execution_command(engine: str, audio_path: Path, output_dir: Path) -> list[str]:
    if _is_windows() and engine == "sheetsage2":
        if not _native_installed():
            raise AIEngineError("SheetSage2 Windows environment not ready. Run CAI_SHEETSAGE2_WINDOWS.bat.")
        return [
            str(_native_python()), "-I",
            str(ROOT_DIR / "scripts" / "ai_external_worker.py"),
            engine, str(audio_path.resolve()), str(output_dir.resolve()),
        ]
    runner = ROOT_DIR / "scripts" / "run_advanced_ai.sh"
    if _is_windows():
        if not shutil.which("wsl.exe"):
            raise AIEngineError("Pop2Piano requires Ubuntu/WSL2 on Windows; SheetSage2 does not.")
        return [
            "wsl.exe", "--exec", "/bin/bash",
            _wsl_path(runner), engine,
            _wsl_path(audio_path), _wsl_path(output_dir),
        ]
    return ["/bin/bash", str(runner), engine, str(audio_path), str(output_dir)]


def run_advanced_engine(
    engine: str, audio_path: Path, output_dir: Path,
    *, timeout_seconds: int = 7200,
) -> dict[str, Any]:
    if engine not in ENGINE_META:
        raise ValueError("Unknown AI engine")
    if not audio_path.is_file():
        raise AIEngineError("Audio input file not found")
    if not _venv_marker(engine).is_file():
        hint = ("CAI_SHEETSAGE2_WINDOWS.bat (no WSL2)" if _is_windows() and engine == "sheetsage2"
                else "CAI_AI_NANG_CAO.bat")
        raise AIEngineError(f"{ENGINE_META[engine]['name']} is not installed. Run {hint} first.")
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / "model.log"
    command = _execution_command(engine, audio_path, output_dir)
    try:
        with log_path.open("w", encoding="utf-8") as logfile:
            result = subprocess.run(
                command, stdout=logfile, stderr=subprocess.STDOUT,
                timeout=max(30, int(timeout_seconds)), check=False,
            )
    except subprocess.TimeoutExpired as exc:
        raise AIEngineError(f"{engine}: inference timed out; read {log_path}") from exc
    except OSError as exc:
        raise AIEngineError(f"Cannot start {engine}: {exc}") from exc
    if result.returncode != 0:
        try:
            tail = " ".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-5:])[-500:]
        except OSError:
            tail = ""
        raise AIEngineError(f"{engine} failed (exit {result.returncode}). {tail} See {log_path}")
    metadata_file = output_dir / "result.json"
    if not metadata_file.is_file():
        raise AIEngineError(f"{engine} did not write result.json. See {log_path}")
    try:
        metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise AIEngineError(f"{engine} produced malformed result.json") from exc
    if not isinstance(metadata, dict) or metadata.get("engine") != engine:
        raise AIEngineError(f"{engine} returned incorrect engine metadata")
    files = metadata.get("midi_files")
    if not isinstance(files, list) or not files:
        raise AIEngineError(f"{engine} returned no MIDI file list")
    allowed = {"pop2piano.mid", "melody_vocal.mid", "melody_instrumental.mid", "chords.mid", "transcription.mid"}
    for name in files:
        if not isinstance(name, str) or name not in allowed or not (output_dir / name).is_file():
            raise AIEngineError(f"{engine} missing expected MIDI: {name}")
    return metadata
