from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any

from .config import settings


class DemucsUnavailableError(RuntimeError):
    pass


STEM_NAMES = ("vocals", "bass", "drums", "other")


def _candidate_python_paths() -> list[Path]:
    candidates: list[Path] = []
    if settings.demucs_python:
        candidates.append(Path(settings.demucs_python))
    candidates.extend(
        [
            settings.root_dir / ".demucs-venv" / "Scripts" / "python.exe",
            settings.root_dir / ".demucs-venv" / "bin" / "python",
        ]
    )
    return candidates


def find_demucs_python() -> str | None:
    for candidate in _candidate_python_paths():
        if candidate.is_file():
            return str(candidate)
    # Docker/Linux deployments may intentionally install Demucs in the main
    # environment. Avoid importing torch into the API process; only probe it in
    # a child interpreter.
    try:
        import importlib.util

        if importlib.util.find_spec("demucs") is not None:
            return sys.executable
    except Exception:
        pass
    return None


@lru_cache(maxsize=2)
def demucs_info() -> dict[str, Any]:
    python = find_demucs_python()
    if not python:
        return {
            "available": False,
            "python": None,
            "version": None,
            "model": settings.demucs_model,
            "device": settings.demucs_device,
        }
    try:
        completed = subprocess.run(
            [
                python,
                "-c",
                "import demucs, json; print(json.dumps({'version': getattr(demucs, '__version__', 'installed')}))",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        payload = json.loads(completed.stdout.strip().splitlines()[-1])
        return {
            "available": True,
            "python": python,
            "version": str(payload.get("version") or "installed"),
            "model": settings.demucs_model,
            "device": settings.demucs_device,
        }
    except Exception as exc:
        return {
            "available": False,
            "python": python,
            "version": None,
            "model": settings.demucs_model,
            "device": settings.demucs_device,
            "error": str(exc)[:260],
        }


def demucs_available() -> bool:
    return bool(demucs_info().get("available"))


def _find_stem_directory(root: Path) -> Path:
    for vocals in root.rglob("vocals.wav"):
        directory = vocals.parent
        if all((directory / f"{name}.wav").is_file() for name in STEM_NAMES):
            return directory
    raise RuntimeError("Demucs finished but the four expected WAV stems were not found")


def separate_stems(audio_path: Path, destination: Path, log_path: Path | None = None) -> dict[str, Path]:
    """Run Demucs in an isolated interpreter and return four local WAV stems."""
    python = find_demucs_python()
    if not python or not demucs_available():
        raise DemucsUnavailableError(
            "Demucs is not installed. Close the website and run CAI_DEMUCS_AI.bat once, "
            "or disable automatic stem separation in the form."
        )
    if not audio_path.is_file():
        raise FileNotFoundError(audio_path)

    destination.mkdir(parents=True, exist_ok=True)
    raw_output = destination / "_demucs_output"
    if raw_output.exists():
        shutil.rmtree(raw_output)
    raw_output.mkdir(parents=True, exist_ok=True)

    command = [
        python,
        "-m",
        "demucs.separate",
        "-n",
        settings.demucs_model,
        "-d",
        settings.demucs_device,
        "--out",
        str(raw_output),
        "--overlap",
        "0.25",
    ]
    if settings.demucs_shifts:
        command.extend(["--shifts", str(settings.demucs_shifts)])
    command.append(str(audio_path))

    try:
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
            timeout=settings.demucs_timeout_seconds,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        if log_path:
            log_path.write_text(
                "COMMAND:\n" + " ".join(command) + "\n\nSTDOUT:\n" + completed.stdout +
                "\n\nSTDERR:\n" + completed.stderr,
                encoding="utf-8",
            )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Demucs separation timed out") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "Demucs process failed").strip()
        if log_path:
            log_path.write_text(
                "COMMAND:\n" + " ".join(command) + "\n\nERROR:\n" + detail,
                encoding="utf-8",
            )
        raise RuntimeError("Demucs separation failed: " + detail[-1800:]) from exc

    source_dir = _find_stem_directory(raw_output)
    result: dict[str, Path] = {}
    for name in STEM_NAMES:
        target = destination / f"{name}.wav"
        shutil.copy2(source_dir / f"{name}.wav", target)
        result[name] = target
    shutil.rmtree(raw_output, ignore_errors=True)
    return result
