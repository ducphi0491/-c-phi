"""Create MusicXML from the same rhythm grid used by playback and MIDI.

AudioSheet 1.3 supports pickup measures, local tempo, and meter changes.  A/B/C
all share one score-time axis, so a detected 2/4 bar or downbeat correction is
reflected in sound, MIDI, MusicXML and PDF together.
"""
from __future__ import annotations

import math
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from xml.etree import ElementTree as ET

from .rhythm_grid import constant_rhythm_map, time_to_quarter

DIVISIONS = 480
MAX_PART_VOICES = 8
MAX_MEASURES = 1600
PITCH_NAMES = ("C", "C", "D", "D", "E", "F", "F", "G", "G", "A", "A", "B")
SHARP_PCS = {1, 3, 6, 8, 10}
B_MODES = {"light", "light_easy", "light_standard", "light_full"}
MODE_ALIASES = {"light": "light_standard"}


@dataclass
class NoteGroup:
    start: int
    end: int
    pitches: tuple[int, ...]
    voice: int = 1


@dataclass
class MeasureSpec:
    index: int
    number: int
    start: int
    end: int
    beats: int
    beat_type: int
    implicit: bool
    tempo: float

    @property
    def length(self) -> int:
        return max(1, self.end - self.start)


def _add(parent: ET.Element, tag: str, value: str | int | float | None = None, **attrs: str) -> ET.Element:
    child = ET.SubElement(parent, tag, attrs)
    if value is not None:
        child.text = str(value)
    return child


def _duration_chunks(ticks: int) -> list[tuple[int, str, bool, tuple[int, int] | None]]:
    options: list[tuple[int, str, bool, tuple[int, int] | None]] = []
    for length, kind in (
        (1920, "whole"), (960, "half"), (480, "quarter"),
        (240, "eighth"), (120, "16th"), (60, "32nd"), (30, "64th"),
    ):
        options.append((length * 3 // 2, kind, True, None))
        options.append((length, kind, False, None))
    for duration, kind in ((1280, "whole"), (640, "half"), (320, "quarter"), (160, "eighth"), (80, "16th")):
        options.append((duration, kind, False, (3, 2)))
    options.sort(key=lambda item: (item[0], item[3] is None), reverse=True)
    chunks: list[tuple[int, str, bool, tuple[int, int] | None]] = []
    remaining = max(1, int(ticks))
    while remaining > 0:
        duration, kind, dotted, time_mod = next((item for item in options if item[0] <= remaining), (30, "64th", False, None))
        chunks.append((duration, kind, dotted, time_mod))
        remaining -= duration
    return chunks


def _safely_round(value: float, step: int) -> int:
    return int(round(value / step)) * step


def _adaptive_round(value: float, straight_step: int, allow_triplets: bool) -> int:
    candidates = [(_safely_round(value, straight_step), 0.0)]
    if allow_triplets:
        for triplet_step in (160, 80):
            candidates.append((_safely_round(value, triplet_step), 5.0))
    return min(candidates, key=lambda item: (abs(item[0] - value) + item[1], item[0]))[0]


def _pitch_xml(parent: ET.Element, midi_pitch: int) -> None:
    pitch = _add(parent, "pitch")
    pitch_class = midi_pitch % 12
    _add(pitch, "step", PITCH_NAMES[pitch_class])
    if pitch_class in SHARP_PCS:
        _add(pitch, "alter", 1)
    _add(pitch, "octave", midi_pitch // 12 - 1)


def _emit_note(
    parent: ET.Element,
    pitches: tuple[int, ...] | None,
    duration: int,
    kind: str,
    dotted: bool,
    voice: int,
    staff: int,
    time_mod: tuple[int, int] | None = None,
    tie_stop: bool = False,
    tie_start: bool = False,
) -> None:
    for index, pitch in enumerate(pitches if pitches is not None else (None,)):
        note = _add(parent, "note")
        if index > 0:
            _add(note, "chord")
        if pitch is None:
            _add(note, "rest")
        else:
            _pitch_xml(note, pitch)
        _add(note, "duration", duration)
        if pitch is not None and tie_stop:
            _add(note, "tie", type="stop")
        if pitch is not None and tie_start:
            _add(note, "tie", type="start")
        _add(note, "voice", voice)
        _add(note, "type", kind)
        if dotted:
            _add(note, "dot")
        if time_mod:
            modification = _add(note, "time-modification")
            _add(modification, "actual-notes", time_mod[0])
            _add(modification, "normal-notes", time_mod[1])
        _add(note, "staff", staff)
        if pitch is not None and (tie_start or tie_stop):
            notations = _add(note, "notations")
            if tie_stop:
                _add(notations, "tied", type="stop")
            if tie_start:
                _add(notations, "tied", type="start")


def _write_duration(
    parent: ET.Element,
    pitches: tuple[int, ...] | None,
    ticks: int,
    voice: int,
    staff: int,
    continuation_before: bool = False,
    continuation_after: bool = False,
) -> None:
    for index, (duration, kind, dotted, time_mod) in enumerate(_duration_chunks(ticks)):
        _emit_note(
            parent, pitches, duration, kind, dotted, voice, staff, time_mod,
            tie_stop=(index > 0 or continuation_before) if pitches else False,
            tie_start=(index < len(_duration_chunks(ticks)) - 1 or continuation_after) if pitches else False,
        )


def _place_voices(
    notes: list[dict],
    bpm: float,
    quantum: int,
    allow_triplets: bool,
    rhythm_map: dict | None,
) -> list[NoteGroup]:
    groups: dict[tuple[int, int], set[int]] = defaultdict(set)
    for note in notes:
        try:
            start = float(note["start"]); end = float(note["end"]); pitch = int(note["pitch"])
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start or not 0 <= pitch <= 127:
            continue
        start_q = float(note.get("score_start_q", time_to_quarter(rhythm_map, start, bpm)))
        end_q = float(note.get("score_end_q", time_to_quarter(rhythm_map, end, bpm)))
        onset = max(0, _adaptive_round(start_q * DIVISIONS, quantum, allow_triplets))
        stop = max(onset + min(quantum, 80 if allow_triplets else quantum), _adaptive_round(end_q * DIVISIONS, quantum, allow_triplets))
        groups[(onset, stop)].add(pitch)
    chunks = [NoteGroup(start, end, tuple(sorted(pitches))) for (start, end), pitches in groups.items()]
    chunks.sort(key=lambda item: (item.start, item.end, item.pitches))
    lanes: list[int] = []
    for group in chunks:
        for index, lane_end in enumerate(lanes):
            if lane_end <= group.start:
                lanes[index] = group.end; group.voice = index + 1; break
        else:
            if len(lanes) < MAX_PART_VOICES:
                lanes.append(group.end); group.voice = len(lanes)
            else:
                lane_index = min(range(len(lanes)), key=lanes.__getitem__)
                lanes[lane_index] = group.end; group.voice = lane_index + 1
    return chunks


def _measure_specs(
    rhythm_map: dict | None,
    bpm: float,
    time_signature: str,
    duration_seconds: float,
    final_tick: int,
) -> list[MeasureSpec]:
    rhythm = rhythm_map or constant_rhythm_map(duration_seconds or 1.0, bpm, time_signature)
    specs: list[MeasureSpec] = []
    for index, item in enumerate(rhythm.get("measures", [])):
        start = int(round(float(item.get("start_quarter", 0)) * DIVISIONS))
        end = int(round(float(item.get("end_quarter", 0)) * DIVISIONS))
        if end <= start:
            continue
        specs.append(MeasureSpec(
            index=index,
            number=int(item.get("number", index + 1)),
            start=start,
            end=end,
            beats=int(item.get("beats", 4)),
            beat_type=int(item.get("beat_type", 4)),
            implicit=bool(item.get("implicit", False)),
            tempo=float(item.get("tempo") or rhythm.get("bpm") or bpm),
        ))
    if not specs:
        beats, beat_type = (4, 4)
        try:
            beats, beat_type = (int(value) for value in time_signature.split("/", 1))
        except Exception:
            pass
        measure_ticks = DIVISIONS * 4 * beats // beat_type
        count = max(1, min(MAX_MEASURES, math.ceil(final_tick / measure_ticks)))
        specs = [MeasureSpec(i, i + 1, i * measure_ticks, (i + 1) * measure_ticks, beats, beat_type, False, bpm) for i in range(count)]
    # Extend if notes reach beyond the analyzed audio duration.
    while specs and specs[-1].end < final_tick and len(specs) < MAX_MEASURES:
        previous = specs[-1]
        nominal = DIVISIONS * 4 * previous.beats // previous.beat_type
        specs.append(MeasureSpec(
            len(specs), previous.number + 1, previous.end, previous.end + nominal,
            previous.beats, previous.beat_type, False, previous.tempo,
        ))
    if specs and specs[-1].end > final_tick + DIVISIONS // 8 and final_tick > specs[-1].start:
        # The rhythm map may include an extrapolated final bar.  Mark it partial
        # rather than padding several beats of invisible material.
        last = specs[-1]
        specs[-1] = MeasureSpec(last.index, last.number, last.start, max(last.start + 1, final_tick), last.beats, last.beat_type, True, last.tempo)
    return specs[:MAX_MEASURES]


def _measure_segments(
    groups: list[NoteGroup], specs: list[MeasureSpec]
) -> dict[tuple[int, int], list[tuple[int, int, tuple[int, ...], bool, bool]]]:
    result: dict[tuple[int, int], list[tuple[int, int, tuple[int, ...], bool, bool]]] = defaultdict(list)
    starts = [spec.start for spec in specs]
    for group in groups:
        cursor = group.start
        while cursor < group.end:
            index = max(0, bisect_right(starts, cursor) - 1)
            if index >= len(specs):
                break
            spec = specs[index]
            if cursor >= spec.end:
                cursor = spec.end
                if index + 1 < len(specs):
                    cursor = max(cursor, specs[index + 1].start)
                continue
            local = max(0, cursor - spec.start)
            stop = min(group.end, spec.end)
            result[(index, group.voice)].append((local, stop - cursor, group.pitches, cursor > group.start, stop < group.end))
            cursor = stop
    return result


def _render_voice(
    measure: ET.Element,
    entries: list[tuple[int, int, tuple[int, ...], bool, bool]],
    measure_ticks: int,
    voice: int,
    staff: int,
) -> None:
    offset = 0
    for local, span, pitches, tied_from, tied_to in sorted(entries):
        if local > offset:
            _write_duration(measure, None, local - offset, voice, staff)
        _write_duration(measure, pitches, span, voice, staff, tied_from, tied_to)
        offset = local + span
    if offset < measure_ticks:
        _write_duration(measure, None, measure_ticks - offset, voice, staff)


def _add_backup(measure: ET.Element, duration: int) -> None:
    backup = _add(measure, "backup"); _add(backup, "duration", duration)


def _harmony_xml(measure: ET.Element, chord: dict, local_ticks: int) -> None:
    root_pc = int(chord.get("root", 0)) % 12; quality = str(chord.get("quality", "major"))
    harmony = _add(measure, "harmony")
    root = _add(harmony, "root"); _add(root, "root-step", PITCH_NAMES[root_pc])
    if root_pc in SHARP_PCS: _add(root, "root-alter", 1)
    kind_map = {
        "major": ("major", ""), "minor": ("minor", "m"), "dominant7": ("dominant", "7"),
        "major7": ("major-seventh", "Maj7"), "minor7": ("minor-seventh", "m7"),
        "half-dim7": ("half-diminished", "m7(b5)"), "dim": ("diminished", "dim"),
        "dim7": ("diminished-seventh", "dim7"), "sus4": ("suspended-fourth", "sus4"),
        "sus2": ("suspended-second", "sus2"),
    }
    value, text = kind_map.get(quality, ("major", "")); kind = _add(harmony, "kind", value)
    if text: kind.set("text", text)
    bass_pc = chord.get("bass_pc")
    if bass_pc is not None and int(bass_pc) % 12 != root_pc:
        bass = _add(harmony, "bass"); bass_value = int(bass_pc) % 12
        _add(bass, "bass-step", PITCH_NAMES[bass_value])
        if bass_value in SHARP_PCS: _add(bass, "bass-alter", 1)
    if local_ticks: _add(harmony, "offset", local_ticks)


def _write_attributes(
    measure: ET.Element,
    beats: int,
    beat_type: int,
    key_fifths: int,
    two_staves: bool,
    *,
    first: bool,
) -> None:
    attrs = _add(measure, "attributes")
    if first:
        _add(attrs, "divisions", DIVISIONS)
        key = _add(attrs, "key"); _add(key, "fifths", max(-7, min(7, int(key_fifths))))
    time = _add(attrs, "time"); _add(time, "beats", beats); _add(time, "beat-type", beat_type)
    if first:
        if two_staves:
            _add(attrs, "staves", 2)
            treble = _add(attrs, "clef", number="1"); _add(treble, "sign", "G"); _add(treble, "line", 2)
            bass = _add(attrs, "clef", number="2"); _add(bass, "sign", "F"); _add(bass, "line", 4)
        else:
            clef = _add(attrs, "clef"); _add(clef, "sign", "G"); _add(clef, "line", 2)


def _write_tempo(measure: ET.Element, bpm: float, *, visible: bool) -> None:
    direction = _add(measure, "direction", placement="above")
    if not visible:
        direction.set("print-object", "no")
    direction_type = _add(direction, "direction-type")
    metronome = _add(direction_type, "metronome")
    _add(metronome, "beat-unit", "quarter"); _add(metronome, "per-minute", round(bpm, 2))
    _add(direction, "sound", tempo=str(round(bpm, 2)))


def _system_breaks(
    specs: list[MeasureSpec],
    right_segments: dict,
    left_segments: dict,
    two_staves: bool,
) -> set[int]:
    breaks: set[int] = set()
    count = 0; cost = 0.0
    for index, spec in enumerate(specs):
        event_count = sum(len(entries) for (bar, _), entries in right_segments.items() if bar == index)
        if two_staves:
            event_count += sum(len(entries) for (bar, _), entries in left_segments.items() if bar == index)
        measure_cost = 8.0 + event_count * 0.52 + (2.0 if spec.beats != 4 else 0.0)
        if index > 0 and count >= 2 and (count >= 4 or cost + measure_cost > 58.0):
            breaks.add(index); count = 0; cost = 0.0
        count += 1; cost += measure_cost
    return breaks


def _render_score_part(
    root: ET.Element,
    right_groups: list[NoteGroup],
    left_groups: list[NoteGroup],
    specs: list[MeasureSpec],
    bpm: float,
    key_fifths: int,
    chords: list[dict],
    two_staves: bool,
    rhythm_map: dict | None,
) -> None:
    part = _add(root, "part", id="P1")
    right_segments = _measure_segments(right_groups, specs)
    left_segments = _measure_segments(left_groups, specs)
    breaks = _system_breaks(specs, right_segments, left_segments, two_staves)
    starts = [spec.start for spec in specs]
    previous_meter: tuple[int, int] | None = None
    previous_tempo: float | None = None

    chords_by_measure: dict[int, list[tuple[int, dict]]] = defaultdict(list)
    for chord in chords:
        quarter = float(chord.get("start_quarter", time_to_quarter(rhythm_map, float(chord.get("start", 0)), bpm)))
        tick = int(round(quarter * DIVISIONS))
        index = max(0, bisect_right(starts, tick) - 1)
        if index < len(specs) and specs[index].start <= tick < specs[index].end:
            chords_by_measure[index].append((tick - specs[index].start, chord))

    for index, spec in enumerate(specs):
        attrs = {"number": str(spec.number)}
        if spec.implicit: attrs["implicit"] = "yes"
        measure = _add(part, "measure", **attrs)
        if index in breaks: _add(measure, "print", **{"new-system": "yes"})
        meter = (spec.beats, spec.beat_type)
        if index == 0 or meter != previous_meter:
            _write_attributes(measure, spec.beats, spec.beat_type, key_fifths, two_staves, first=index == 0)
        if index == 0 or previous_tempo is None or abs(spec.tempo - previous_tempo) >= 1.0:
            _write_tempo(measure, spec.tempo, visible=index == 0)
        previous_meter = meter; previous_tempo = spec.tempo

        for local_tick, chord in sorted(chords_by_measure.get(index, [])):
            _harmony_xml(measure, chord, max(0, local_tick))

        right_voices = sorted(voice for (bar, voice) in right_segments if bar == index)
        if not right_voices:
            _write_duration(measure, None, spec.length, 1, 1)
        else:
            for voice_index, voice in enumerate(right_voices):
                if voice_index: _add_backup(measure, spec.length)
                _render_voice(measure, right_segments[(index, voice)], spec.length, voice, 1)

        if two_staves:
            _add_backup(measure, spec.length)
            left_voices = sorted(voice for (bar, voice) in left_segments if bar == index)
            if not left_voices:
                _write_duration(measure, None, spec.length, 5, 2)
            else:
                for voice_index, voice in enumerate(left_voices):
                    if voice_index: _add_backup(measure, spec.length)
                    _render_voice(measure, left_segments[(index, voice)], spec.length, voice + 4, 2)


def create_arrangement_xml(
    notes: list[dict],
    mode: str,
    title: str,
    bpm: float = 100,
    time_signature: str = "4/4",
    quantization: int = 16,
    split_pitch: int = 60,
    duration_seconds: float = 0,
    key_fifths: int = 0,
    chords: list[dict] | None = None,
    rhythm_map: dict | None = None,
) -> bytes:
    mode = MODE_ALIASES.get(mode, mode)
    if mode not in {"melody", "light_easy", "light_standard", "light_full", "full"}:
        raise ValueError("Invalid sheet mode")
    if not 30 <= float(bpm) <= 250: bpm = 100.0
    if quantization not in {8, 16, 32}: quantization = 16
    if time_signature not in {"4/4", "3/4", "6/8"}: time_signature = "4/4"
    valid = [note for note in notes if isinstance(note, dict)]
    if not valid: raise ValueError("No notes in this arrangement")

    if mode == "melody":
        right = valid; left: list[dict] = []
    elif mode in B_MODES:
        right = [note for note in valid if note.get("staff") != "lower"]
        left = [note for note in valid if note.get("staff") == "lower"]
    else:
        right = [note for note in valid if note.get("staff") == "upper" or (not note.get("staff") and int(note.get("pitch", 60)) >= split_pitch)]
        left = [note for note in valid if note.get("staff") == "lower" or (not note.get("staff") and int(note.get("pitch", 60)) < split_pitch)]

    allow_triplets = mode in {"light_standard", "light_full", "full"}
    quantum = DIVISIONS * 4 // quantization
    right_groups = _place_voices(right, bpm, quantum, allow_triplets, rhythm_map)
    left_groups = _place_voices(left, bpm, quantum, allow_triplets, rhythm_map)
    final_tick = max(
        [int(max(0, time_to_quarter(rhythm_map, duration_seconds, bpm)) * DIVISIONS)]
        + [group.end for group in right_groups + left_groups]
    )
    specs = _measure_specs(rhythm_map, bpm, time_signature, duration_seconds, final_tick)
    two_staves = mode != "melody"

    root = ET.Element("score-partwise", version="4.0")
    work = _add(root, "work"); _add(work, "work-title", title[:160] or "AudioSheet Studio")
    _add(root, "movement-title", title[:160] or "AudioSheet Studio")
    identification = _add(root, "identification")
    _add(identification, "creator", "AudioSheet Studio 1.4.0", type="composer")
    encoding = _add(identification, "encoding"); _add(encoding, "software", "AudioSheet Studio 1.4.0")
    defaults = _add(root, "defaults")
    scaling = _add(defaults, "scaling"); _add(scaling, "millimeters", 6.4); _add(scaling, "tenths", 40)
    page_layout = _add(defaults, "page-layout"); _add(page_layout, "page-height", 1683); _add(page_layout, "page-width", 1190)
    margins = _add(page_layout, "page-margins", type="both")
    for side in ("left", "right"): _add(margins, f"{side}-margin", 52)
    for side in ("top", "bottom"): _add(margins, f"{side}-margin", 44)
    system_layout = _add(defaults, "system-layout")
    _add(system_layout, "system-distance", 105); _add(system_layout, "top-system-distance", 75)

    part_list = _add(root, "part-list")
    part_def = _add(part_list, "score-part", id="P1")
    _add(part_def, "part-name", "Melody" if not two_staves else "Piano")
    _add(part_def, "part-abbreviation", "Mel." if not two_staves else "Pno.")
    score_instrument = _add(part_def, "score-instrument", id="P1-I1")
    _add(score_instrument, "instrument-name", "Voice" if not two_staves else "Piano")
    midi_instrument = _add(part_def, "midi-instrument", id="P1-I1")
    _add(midi_instrument, "midi-channel", 1); _add(midi_instrument, "midi-program", 1)

    _render_score_part(root, right_groups, left_groups, specs, bpm, key_fifths, chords or [], two_staves, rhythm_map)
    xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    declaration_end = xml.find(b"?>") + 2
    doctype = b'<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">\n'
    return xml[:declaration_end] + b"\n" + doctype + xml[declaration_end:]
