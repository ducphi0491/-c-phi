"""Optional Gemini audio harmony analysis for AudioSheet (NOT note transcription).

Only the server reads GEMINI_API_KEY. Gemini's proposed chords are aligned to
AudioSheet's measured harmonic windows and checked against actual note events
before they are permitted to change the piano arrangements.
"""
from __future__ import annotations

import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from .config import settings
from .playback_modes import CHORD_DEFINITIONS, PITCH_CLASS_NAMES, build_arrangement_levels, clean_notes
from .rhythm_grid import quantize_notes_to_rhythm

DEFAULT_MODEL = "gemini-3.8-flash"
AUDIO_MIME = "audio/mpeg"
MAX_UPLOAD_BYTES = 24 * 1024 * 1024

# Deliberately narrow schema: a language model must not supply note events,
# timestamps for MIDI note-on/off or facts it cannot reliably measure.
class GeminiChord(BaseModel):
    start: float = Field(description="Start time in seconds from the beginning of this uploaded file")
    end: float = Field(description="End time in seconds")
    symbol: str = Field(description="Chord symbol e.g. F#m or C#7")


class GeminiSection(BaseModel):
    label: str
    start: float
    end: float


class GeminiMusicSchema(BaseModel):
    key_name: str = Field(description="e.g. F# minor; use unknown when uncertain")
    tempo_bpm_estimate: float = Field(description="Approximate BPM; use 0 when uncertain")
    sections: list[GeminiSection]
    chords: list[GeminiChord]
    notes: str = Field(description="Brief explanation of uncertainty, not individual note transcription")


PROMPT = """Analyze the uploaded MUSIC recording as a musician. Output only JSON.
Make a best-effort estimate of tonal key, musical sections and chord progression.
For chords, use absolute timestamps in SECONDS relative to the beginning of
THIS file (start=0), not measure numbers. Use standard chord symbols such as
F#m, Bm, DMaj7, C#7, G#m7(b5), D/F#, sus2, sus4. Each segment needs start and
end seconds. Prefer a smaller number of stable, musically plausible chord spans;
do not invent a new chord on every short passing note. Keep segments ordered,
non-overlapping and within the actual song. Musical sections: intro, verse,
pre-chorus, chorus, bridge, instrumental, outro (only those you can hear).
If uncertain, use an empty chords/sections array rather than fabricate. This is
HARMONY analysis, not pitch-to-MIDI transcription. Do not generate individual
notes, melodies, lyrics or pseudo-precise note-on/note-off values.
"""


class GeminiAnalysisError(RuntimeError):
    pass


def api_key() -> str:
    # Matches google-genai's precedence.
    return (os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY") or "").strip()


def sdk_available() -> bool:
    try:
        return importlib.util.find_spec("google.genai") is not None
    except (ModuleNotFoundError, ValueError):
        return False


def gemini_status() -> dict[str, Any]:
    return {
        "configured": bool(api_key()),
        "sdk_installed": sdk_available(),
        "available": bool(api_key()) and sdk_available(),
        "authorization_tested": False,  # Health is never a live connectivity check.
        "model": settings.gemini_model,
        "runtime": "windows_or_linux_https_no_wsl",
        "sends_audio_to_google": True,
    }


def _finite(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def _clean_response(data: Any, duration: float) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise GeminiAnalysisError("Gemini did not return an object of analysis data")
    chords: list[dict[str, Any]] = []
    raw_chords = data.get("chords", [])
    for item in raw_chords[:240] if isinstance(raw_chords, list) else []:
        if not isinstance(item, dict):
            continue
        start, end = _finite(item.get("start")), _finite(item.get("end"))
        symbol = str(item.get("symbol") or "").strip()[:35]
        if start is None or end is None or not symbol or end <= start or end <= 0 or start >= duration:
            continue
        chords.append({"start": round(max(0.0, start), 3), "end": round(min(duration, end), 3), "symbol": symbol})
    chords.sort(key=lambda entry: entry["start"])
    sections: list[dict[str, Any]] = []
    raw_sections = data.get("sections", [])
    for item in raw_sections[:80] if isinstance(raw_sections, list) else []:
        if not isinstance(item, dict):
            continue
        start, end = _finite(item.get("start")), _finite(item.get("end"))
        label = str(item.get("label") or "").strip()[:45]
        if start is None or end is None or not label or end <= start or end <= 0 or start >= duration:
            continue
        sections.append({"start": round(max(0.0, start), 3), "end": round(min(duration, end), 3), "label": label})
    sections.sort(key=lambda entry: entry["start"])
    estimate = _finite(data.get("tempo_bpm_estimate"))
    return {
        "key_name": str(data.get("key_name") or "unknown").strip()[:50],
        "tempo_bpm_estimate": round(estimate, 2) if estimate is not None and 30 <= estimate <= 280 else None,
        "chords": chords,
        "sections": sections,
        "notes": str(data.get("notes") or "").strip()[:450],
    }


def _prepare_audio(source: Path, destination: Path, duration: float) -> Path:
    if not source.is_file():
        raise GeminiAnalysisError("Audio input is missing")
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise GeminiAnalysisError("FFmpeg is required to prepare an MP3 for Gemini")
    # Low bandwidth audio: no need to send full 44.1k stereo PCM to cloud.
    command = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
               "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libmp3lame", "-b:a", "64k", str(destination)]
    try:
        process = subprocess.run(command, capture_output=True, text=True, timeout=min(240, max(60, int(duration) + 45)), check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GeminiAnalysisError("Unable to prepare Gemini audio with FFmpeg") from exc
    if process.returncode or not destination.is_file() or destination.stat().st_size < 100:
        raise GeminiAnalysisError("FFmpeg MP3 conversion failed: " + (process.stderr or "")[-200:])
    if destination.stat().st_size > MAX_UPLOAD_BYTES:
        destination.unlink(missing_ok=True)
        raise GeminiAnalysisError("Gemini audio exceeds 24 MB safety upload limit")
    return destination


def _client_request(upload_path: Path) -> str:
    key = api_key()
    if not key:
        raise GeminiAnalysisError("Missing GEMINI_API_KEY in .env; restart CHAY_WEBSITE.bat after editing")
    try:
        from google import genai
        from google.genai import types
    except ImportError as exc:
        raise GeminiAnalysisError("google-genai is not installed. Run CAI_GEMINI_API.bat") from exc
    client = None
    uploaded = None
    try:
        client = genai.Client(api_key=key, http_options=types.HttpOptions(timeout=settings.gemini_timeout_seconds * 1000))
        uploaded = client.files.upload(file=str(upload_path), config={"mime_type": AUDIO_MIME})
        # Large uploads may briefly remain PROCESSING; wait for the Files API.
        for _ in range(40):
            state = str(getattr(uploaded, "state", "") or "").upper()
            if "FAILED" in state:
                raise GeminiAnalysisError("Gemini Files API could not process uploaded audio")
            if "PROCESSING" not in state:
                break
            time.sleep(1.5)
            uploaded = client.files.get(name=uploaded.name)
        else:
            raise GeminiAnalysisError("Gemini audio upload did not become ready within 60 seconds")
        result = client.models.generate_content(
            model=settings.gemini_model,
            contents=[uploaded, PROMPT],
            config=types.GenerateContentConfig(
                response_mime_type="application/json", response_schema=GeminiMusicSchema,
                temperature=0.15,
            ),
        )
        if not result.text:
            raise GeminiAnalysisError("Gemini returned an empty response; check quota and safety settings")
        return result.text
    except GeminiAnalysisError:
        raise
    except Exception as exc:
        # Never expose API keys in logs, job metadata or browser alerts.
        message = str(exc)
        for secret in (key, os.getenv("GEMINI_API_KEY") or "", os.getenv("GOOGLE_API_KEY") or ""):
            if secret:
                message = message.replace(secret, "[REDACTED]")
        raise GeminiAnalysisError("Gemini API error: " + message[:400]) from None
    finally:
        if client is not None:
            if uploaded is not None and getattr(uploaded, "name", None):
                try:
                    client.files.delete(name=uploaded.name)
                except Exception:
                    pass  # Files API expires temporary uploads if deletion fails.
            try:
                client.close()
            except Exception:
                pass


def analyze_audio(source: Path, output_dir: Path, *, duration: float) -> dict[str, Any]:
    """Call Gemini once per job, validate output, and erase temporary cloud upload."""
    if not gemini_status()["available"]:
        raise GeminiAnalysisError("Gemini API is not ready (check .env and run CAI_GEMINI_API.bat)")
    output_dir.mkdir(parents=True, exist_ok=True)
    prepared = output_dir / "gemini_input.mp3"
    try:
        _prepare_audio(source, prepared, duration)
        text = _client_request(prepared)
        try:
            parsed = json.loads(text)
        except (ValueError, TypeError) as exc:
            raise GeminiAnalysisError("Gemini did not return valid JSON") from exc
        normalized = _clean_response(parsed, duration)
        if not normalized["chords"] and not normalized["sections"]:
            raise GeminiAnalysisError("Gemini produced no usable chord/section estimates")
        normalized.update({"provider": "google_gemini", "model": settings.gemini_model,
                           "accuracy": "estimates_only; NOT validated note transcription"})
        return normalized
    finally:
        prepared.unlink(missing_ok=True)


NOTE_NAMES = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
NAME_PATTERN = re.compile(r"^([A-Ga-g])([#b]?)(.*)$")


def _pitch_class(token: str) -> int | None:
    match = re.fullmatch(r"([A-Ga-g])([#b]?)", token.strip())
    if not match:
        return None
    return (NOTE_NAMES[match.group(1).upper()] + (1 if match.group(2) == "#" else -1 if match.group(2) == "b" else 0)) % 12


def parse_chord(symbol: str) -> dict[str, Any] | None:
    s = symbol.replace("♯", "#").replace("♭", "b").replace("Δ", "Maj").replace("ø", "m7(b5)").strip().replace(" ", "")
    if len(s) > 40:
        return None
    parts = s.split("/")
    if len(parts) > 2:
        return None
    match = NAME_PATTERN.fullmatch(parts[0])
    if not match:
        return None
    root = _pitch_class(match.group(1).upper() + match.group(2))
    quality = {
        "": "major", "maj": "major", "M": "major",
        "m": "minor", "min": "minor", "-": "minor",
        "7": "dominant7", "dom7": "dominant7", "M7": "major7", "Maj7": "major7", "maj7": "major7",
        "m7": "minor7", "min7": "minor7", "m7b5": "half-dim7", "m7(b5)": "half-dim7",
        "dim": "dim", "o": "dim", "dim7": "dim7", "o7": "dim7", "sus4": "sus4", "sus2": "sus2",
    }.get(match.group(3))
    if root is None or quality is None or quality not in CHORD_DEFINITIONS:
        return None
    bass = _pitch_class(parts[1]) if len(parts) == 2 else root
    if bass is None:
        return None
    chord_pcs = {(root + interval) % 12 for interval in CHORD_DEFINITIONS[quality]}
    if bass not in chord_pcs:
        return None  # Reject slash bass outside the advertised chord tones.
    canonical_suffix = {"major": "", "minor": "m", "dominant7": "7", "major7": "Maj7",
                        "minor7": "m7", "half-dim7": "m7(b5)", "dim": "dim", "dim7": "dim7",
                        "sus4": "sus4", "sus2": "sus2"}[quality]
    name = PITCH_CLASS_NAMES[root] + canonical_suffix
    if bass != root:
        name += "/" + PITCH_CLASS_NAMES[bass]
    return {"root": root, "quality": quality, "bass_pc": bass, "name": name}


def _parse_key(name: str) -> dict[str, Any] | None:
    normalized = str(name).replace("♯", "#").replace("♭", "b").strip()
    match = re.fullmatch(r"([A-Ga-g][#b]?)\s*(major|minor|maj|min|m)", normalized, flags=re.IGNORECASE)
    if not match:
        return None
    tonic = _pitch_class(match.group(1))
    if tonic is None:
        return None
    mode = "minor" if match.group(2).lower() in {"minor", "min", "m"} else "major"
    relative_major = tonic if mode == "major" else (tonic + 3) % 12
    fifths = {0: 0, 7: 1, 2: 2, 9: 3, 4: 4, 11: 5, 6: 6,
              1: 7, 5: -1, 10: -2, 3: -3, 8: -4}.get(relative_major, 0)
    return {"tonic": tonic, "mode": mode, "name": f"{PITCH_CLASS_NAMES[tonic]} {mode}", "fifths": fifths}


def _key_note_support(notes: list[dict[str, Any]], key: dict[str, Any]) -> float:
    tonic = int(key["tonic"]) % 12
    scale = (0, 2, 3, 5, 7, 8, 10) if key["mode"] == "minor" else (0, 2, 4, 5, 7, 9, 11)
    pcs = {(tonic + step) % 12 for step in scale}
    total = matching = 0.0
    for n in notes:
        weight = max(.03, min(2., float(n["end"]) - float(n["start"]))) * (
            0.4 + int(n.get("velocity", 80)) / 127.0)
        total += weight
        if int(n["pitch"]) % 12 in pcs:
            matching += weight
    return matching / total if total > 0.1 else 0.0


def _evidence_ratio(notes: list[dict[str, Any]], start: float, end: float, chord: dict[str, Any]) -> float | None:
    root = int(chord["root"])
    pcs = {(root + x) % 12 for x in CHORD_DEFINITIONS[chord["quality"]]}
    amount = total = 0.0
    for n in notes:
        overlap = max(0.0, min(end, float(n["end"])) - max(start, float(n["start"])))
        if overlap <= 0:
            continue
        value = overlap * (0.35 + int(n.get("velocity", 75)) / 127.0)
        # Bass and harmonic notes matter more than the current sung melody.
        if n.get("role") == "melody":
            value *= 0.45
        if n.get("role") == "bass":
            value *= 1.45
        total += value
        if int(n["pitch"]) % 12 in pcs:
            amount += value
    return amount / total if total > 0.1 else None


def _best_overlap(chords: list[dict[str, Any]], start: float, end: float) -> tuple[dict[str, Any] | None, float]:
    match = None
    best = 0.0
    for chord in chords:
        overlap = max(0.0, min(end, chord["end"]) - max(start, chord["start"]))
        if overlap > best:
            match, best = chord, overlap
    return match, best / max(0.001, end - start)


def apply_harmony(payload: dict[str, Any], report: dict[str, Any], *, bpm: float,
                  time_signature: str, quantization: int, rhythm: dict[str, Any] | None,
                  replace_piano: bool = True) -> tuple[dict[str, Any], dict[str, int]]:
    """Apply Gemini harmony ONLY where local note evidence supports it.

    Keep A melody and C transcription untouched. If no proposed chords pass
    validation, preserve all previous sheet/audio; never mislabel as Gemini B.
    """
    analysis = payload.get("analysis") if isinstance(payload.get("analysis"), dict) else {}
    old = analysis.get("chords") if isinstance(analysis.get("chords"), list) else []
    if not old:
        raise GeminiAnalysisError("No local chord windows to validate Gemini against")
    candidates = []
    for chord in report.get("chords", []):
        parsed = parse_chord(str(chord.get("symbol", "")))
        if parsed:
            candidates.append({**chord, **parsed})
    observed = payload.get("modes", {}).get("full", {}).get("notes", [])
    if not isinstance(observed, list):
        observed = []
    updated: list[dict[str, Any]] = []
    accepted = 0
    for current in old:
        start, end = float(current["start"]), float(current["end"])
        proposed, coverage = _best_overlap(candidates, start, end)
        ratio = _evidence_ratio(observed, start, end, proposed) if proposed is not None else None
        if (proposed and coverage >= 0.55 and ratio is not None and ratio >= 0.48):
            replacement = dict(current)
            replacement.update({k: proposed[k] for k in ("root", "quality", "bass_pc", "name")})
            replacement["confidence"] = round(ratio, 3)
            replacement["source"] = "gemini_validated_against_notes"
            updated.append(replacement)
            if any(replacement[k] != current.get(k) for k in ("root", "quality", "bass_pc")):
                accepted += 1
        else:
            updated.append(dict(current))
    # A reported tonic is NOT authoritative. Switch the key signature only if
    # notes support it better than AudioSheet's local key estimation.
    proposed_key = _parse_key(str(report.get("key_name") or ""))
    existing_key = analysis.get("key") if isinstance(analysis.get("key"), dict) else None
    key_changed = False
    if proposed_key and existing_key and len(observed) >= 8:
        new_fit = _key_note_support(observed, proposed_key)
        old_fit = _key_note_support(observed, existing_key)
        if (new_fit >= 0.73 and new_fit - old_fit >= 0.06 and
                (proposed_key["tonic"], proposed_key["mode"]) !=
                (existing_key.get("tonic"), existing_key.get("mode"))):
            analysis["key"] = {**proposed_key, "confidence": round(new_fit, 3),
                               "source": "gemini_validated_against_notes"}
            key_changed = True
    summary = {"proposed": len(report.get("chords", [])), "parsed": len(candidates),
               "changed_windows": accepted, "total_windows": len(old), "key_changed": key_changed}
    # Store estimates even when not adopted, making the distinction clear.
    analysis["gemini"] = {"model": report.get("model"), "estimated_key": report.get("key_name"),
                          "estimated_bpm": report.get("tempo_bpm_estimate"), "sections": report.get("sections", []),
                          "comparison": summary, "note": "Gemini predictions are not ground-truth notes"}
    analysis["sections"] = report.get("sections", [])
    payload["analysis"] = analysis
    if accepted == 0 or not replace_piano:
        return payload, summary
    analysis["chords"] = updated
    melody = payload["modes"]["melody"]["notes"]
    full = payload["modes"]["full"]["notes"]
    bass = [n for n in full if n.get("source") == "bass" or n.get("role") == "bass"]
    other = [n for n in full if n.get("source") in ("other", "full_mix") or n.get("role") == "other"]
    levels = build_arrangement_levels(melody, updated, bass, other, bpm, time_signature, analysis.get("key"), rhythm)
    for name, notes in levels.items():
        adjusted = quantize_notes_to_rhythm(notes, rhythm, bpm=bpm, quantization=quantization,
                                            allow_triplets=True, minimum_quarters=0.25)
        payload["modes"][name] = {"label": payload["modes"][name].get("label", name),
                                  "count": len(adjusted), "notes": adjusted}
    payload["modes"]["light"] = dict(payload["modes"]["light_standard"], alias_of="light_standard")
    payload["source"] = str(payload.get("source", "AudioSheet")) + " + Gemini-validated harmony"
    return payload, summary
