from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

from .audio_tools import run_command
from .browser_pdf import (
    BrowserPDFError,
    browser_pdf_available,
    export_with_browser_osmd,
    find_browser,
    osmd_bundle_path,
)
from .config import settings
from .simple_pdf import SimplePDFError, export_simple_musicxml_pdf


class PDFExportError(RuntimeError):
    pass


def is_valid_pdf(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size < 900:
        return False
    try:
        data = path.read_bytes()
    except OSError:
        return False
    return data.startswith(b"%PDF-") and b"%%EOF" in data[-2048:]


def find_musescore() -> str | None:
    candidates: list[str] = [
        settings.musescore_bin,
        "MuseScore4",
        "musescore4",
        "mscore4",
        "MuseScore3",
        "musescore3",
        "mscore",
    ]
    if os.name == "nt":
        for base_name in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
            base = os.getenv(base_name)
            if not base:
                continue
            candidates.extend(
                [
                    str(Path(base) / "MuseScore 4" / "bin" / "MuseScore4.exe"),
                    str(Path(base) / "MuseScore 4" / "bin" / "MuseScore.exe"),
                    str(Path(base) / "MuseScore 3" / "bin" / "MuseScore3.exe"),
                ]
            )
    for candidate in candidates:
        if not candidate:
            continue
        explicit = Path(candidate)
        if explicit.is_file():
            return str(explicit)
        located = shutil.which(candidate)
        if located:
            return located
    return None


def _export_with_musescore(musicxml_path: Path, pdf_path: Path) -> bool:
    executable = find_musescore()
    if not executable:
        return False
    temporary = pdf_path.with_suffix(".musescore.tmp.pdf")
    temporary.unlink(missing_ok=True)
    try:
        run_command([executable, "-o", str(temporary), str(musicxml_path)], timeout=300)
        if not is_valid_pdf(temporary):
            return False
        temporary.replace(pdf_path)
        return True
    except Exception:
        return False
    finally:
        temporary.unlink(missing_ok=True)


def _reportlab_available() -> bool:
    try:
        import reportlab  # noqa: F401
        return True
    except Exception:
        return False


def _export_with_reportlab(musicxml_path: Path, pdf_path: Path) -> bool:
    temporary = pdf_path.with_suffix(".reportlab.tmp.pdf")
    temporary.unlink(missing_ok=True)
    try:
        export_simple_musicxml_pdf(musicxml_path, temporary)
        if not is_valid_pdf(temporary):
            return False
        temporary.replace(pdf_path)
        return True
    finally:
        temporary.unlink(missing_ok=True)


def export_musicxml_to_pdf(
    musicxml_path: Path,
    pdf_path: Path,
    *,
    require_web_fidelity: bool = False,
) -> str:
    """Export MusicXML to PDF.

    v1.3.0 prints the same OpenSheetMusicDisplay SVG used by the website through
    local Chrome/Edge/Chromium. This preserves music glyphs exactly. The old
    Verovio -> svglib -> ReportLab path was removed because SMuFL glyphs could
    become enormous or corrupted on some Windows systems.

    When require_web_fidelity is true, no approximate renderer is accepted. The
    frontend then falls back to the browser's native Print / Save as PDF view.
    """
    if not musicxml_path.is_file():
        raise PDFExportError(f"MusicXML file not found: {musicxml_path}")
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    pdf_path.unlink(missing_ok=True)
    errors: list[str] = []

    try:
        if export_with_browser_osmd(musicxml_path, pdf_path):
            if is_valid_pdf(pdf_path):
                return "browser_osmd"
            pdf_path.unlink(missing_ok=True)
    except BrowserPDFError as exc:
        errors.append(f"Browser OSMD: {exc}")
        pdf_path.unlink(missing_ok=True)
    except Exception as exc:
        errors.append(f"Browser OSMD: {exc}")
        pdf_path.unlink(missing_ok=True)

    if require_web_fidelity:
        detail = errors[-1] if errors else (
            "Chrome/Edge and the local OpenSheetMusicDisplay bundle are required"
        )
        raise PDFExportError(
            "Could not create the exact web-layout PDF. " + detail
        )

    if _export_with_musescore(musicxml_path, pdf_path):
        return "musescore"

    if _reportlab_available():
        try:
            if _export_with_reportlab(musicxml_path, pdf_path):
                return "reportlab"
        except (SimplePDFError, Exception) as exc:
            errors.append(f"ReportLab: {exc}")
            pdf_path.unlink(missing_ok=True)

    detail = "; ".join(errors[-2:]) if errors else "No PDF renderer is available"
    raise PDFExportError(f"PDF export failed. {detail}")


def pdf_engine_status() -> dict[str, Any]:
    browser = find_browser()
    osmd = osmd_bundle_path()
    browser_ready = bool(browser and osmd)
    musescore = find_musescore()
    reportlab = _reportlab_available()
    preferred = (
        "browser_osmd" if browser_ready else "musescore" if musescore else "reportlab" if reportlab else None
    )
    return {
        "available": bool(browser_ready or musescore or reportlab),
        "preferred": preferred,
        "browser_osmd": browser_ready,
        "browser": browser,
        "local_osmd": str(osmd) if osmd else None,
        "musescore": bool(musescore),
        "verovio": False,
        "reportlab": reportlab,
        "web_fidelity": browser_ready,
        "fallback": "reportlab" if reportlab else None,
    }
