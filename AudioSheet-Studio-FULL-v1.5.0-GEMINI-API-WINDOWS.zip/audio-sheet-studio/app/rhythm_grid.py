"""Beat/downbeat, pickup, meter-map and score-time utilities.

AudioSheet 1.3 treats rhythm as a first-class artifact.  The preferred tracker
is Beat This! running in the isolated PyTorch environment.  A librosa dynamic
beat tracker and finally a deterministic constant-tempo grid are used as safe
fallbacks.
"""
from __future__ import annotations

import json
import math
import os
import statistics
import subprocess
import tempfile
from bisect import bisect_right
from pathlib import Path
from functools import lru_cache
from typing import Any, Iterable, Sequence

from .config import settings

RHYTHM_VERSION = 1


@lru_cache(maxsize=2)
def rhythm_tracker_info() -> dict[str, Any]:
    """Probe Beat This! in the isolated PyTorch interpreter."""
    try:
        from .stem_separator import find_demucs_python
        python = find_demucs_python()
        if not python:
            return {"available": False, "model": settings.rhythm_model, "engine": "librosa_dynamic"}
        completed = subprocess.run(
            [python, "-c",
             "import importlib.metadata,json; import beat_this; "
             "print(json.dumps({'version': importlib.metadata.version('beat-this')}))"],
            check=True, capture_output=True, text=True, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        payload = json.loads(completed.stdout.strip().splitlines()[-1])
        return {
            "available": True, "python": python,
            "version": str(payload.get("version") or "installed"),
            "model": settings.rhythm_model, "device": settings.rhythm_device,
            "engine": "beat_this",
        }
    except Exception as exc:
        return {
            "available": False, "model": settings.rhythm_model,
            "device": settings.rhythm_device, "engine": "librosa_dynamic",
            "error": str(exc)[:260],
        }


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return number if math.isfinite(number) else default


def _median(values: Sequence[float], default: float) -> float:
    clean = [float(value) for value in values if math.isfinite(float(value)) and float(value) > 0]
    return float(statistics.median(clean)) if clean else float(default)


def _dedupe_times(values: Iterable[Any], duration: float, tolerance: float = 0.025) -> list[float]:
    result: list[float] = []
    for raw in sorted(_finite(value, -1.0) for value in values):
        if raw < -0.02 or raw > duration + 2.0:
            continue
        value = max(0.0, raw)
        if result and value - result[-1] <= tolerance:
            result[-1] = round((result[-1] + value) / 2.0, 6)
        else:
            result.append(round(value, 6))
    return result


def _signature_values(time_signature: str) -> tuple[int, int, int, float]:
    try:
        beats, beat_type = (int(value) for value in str(time_signature).split('/', 1))
    except Exception:
        beats, beat_type = 4, 4
    if (beats, beat_type) == (6, 8):
        # Beat This! generally emits the two dotted-quarter pulses of 6/8.
        return 6, 8, 2, 1.5
    if beats == 3 and beat_type == 4:
        return 3, 4, 3, 1.0
    return 4, 4, 4, 1.0


def _constant_beats(duration: float, bpm: float, pulse_quarters: float = 1.0) -> list[float]:
    bpm = max(30.0, min(250.0, _finite(bpm, 120.0)))
    interval = 60.0 * pulse_quarters / bpm
    count = max(8, int(math.ceil(max(duration, interval) / interval)) + 3)
    return [round(index * interval, 6) for index in range(count)]


def _nearest_index(values: Sequence[float], target: float) -> int:
    if not values:
        return 0
    position = bisect_right(values, target)
    options = []
    if position < len(values):
        options.append(position)
    if position:
        options.append(position - 1)
    return min(options or [0], key=lambda index: abs(values[index] - target))


def _first_onset_time(audio_path: Path) -> float | None:
    """Return the first meaningful onset without failing the main pipeline."""
    try:
        import librosa
        import numpy as np

        y, sr = librosa.load(str(audio_path), sr=22050, mono=True)
        if y.size == 0:
            return None
        hop = 512
        envelope = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop)
        if envelope.size == 0 or float(np.max(envelope)) <= 0:
            return None
        threshold = max(float(np.max(envelope)) * 0.18, float(np.percentile(envelope, 82)) * 0.65)
        indices = np.flatnonzero(envelope >= threshold)
        if not len(indices):
            return None
        return float(librosa.frames_to_time(int(indices[0]), sr=sr, hop_length=hop))
    except Exception:
        return None


def _librosa_track(
    audio_path: Path,
    *,
    bpm_hint: float,
    time_signature: str,
) -> tuple[list[float], list[float], float | None, dict[str, Any]]:
    import librosa
    import numpy as np

    y, sr = librosa.load(str(audio_path), sr=22050, mono=True)
    hop = 512
    envelope = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop)
    if envelope.size == 0 or float(np.max(envelope)) <= 0:
        return [], [], None, {"engine": "librosa_dynamic", "confidence": 0.15}

    start_bpm = bpm_hint if 35 <= bpm_hint <= 250 else 120.0
    try:
        local_tempo = librosa.feature.tempo(
            onset_envelope=envelope,
            sr=sr,
            hop_length=hop,
            aggregate=None,
            start_bpm=start_bpm,
        )
        _, beat_frames = librosa.beat.beat_track(
            onset_envelope=envelope,
            sr=sr,
            hop_length=hop,
            start_bpm=start_bpm,
            bpm=local_tempo,
            units="frames",
            trim=False,
        )
    except TypeError:
        _, beat_frames = librosa.beat.beat_track(
            onset_envelope=envelope,
            sr=sr,
            hop_length=hop,
            start_bpm=start_bpm,
            units="frames",
            trim=False,
        )
    beat_frames = np.asarray(beat_frames, dtype=int).reshape(-1)
    beats = [float(value) for value in librosa.frames_to_time(beat_frames, sr=sr, hop_length=hop)]
    if len(beats) < 2:
        return beats, [], None, {"engine": "librosa_dynamic", "confidence": 0.20}

    _, _, pulses_per_measure, _ = _signature_values(time_signature)
    strengths = []
    for frame in beat_frames:
        left = max(0, int(frame) - 1)
        right = min(len(envelope), int(frame) + 2)
        strengths.append(float(np.max(envelope[left:right])) if right > left else 0.0)
    # Downbeat phase: reward accented beats and changes in the local onset pattern.
    phase_scores: list[float] = []
    median_strength = float(np.median(strengths)) if strengths else 0.0
    for phase in range(max(1, pulses_per_measure)):
        score = 0.0
        for index, strength in enumerate(strengths):
            if index % pulses_per_measure == phase:
                previous = strengths[index - 1] if index else median_strength
                score += strength * 1.35 + max(0.0, strength - previous) * 0.35
            else:
                score -= strength * 0.045
        phase_scores.append(score)
    phase = max(range(len(phase_scores)), key=phase_scores.__getitem__) if phase_scores else 0
    downbeats = beats[phase::pulses_per_measure]

    first_onset = None
    threshold = max(float(np.max(envelope)) * 0.18, float(np.percentile(envelope, 82)) * 0.65)
    onset_indices = np.flatnonzero(envelope >= threshold)
    if len(onset_indices):
        first_onset = float(librosa.frames_to_time(int(onset_indices[0]), sr=sr, hop_length=hop))
    confidence = 0.48
    if phase_scores and len(phase_scores) > 1:
        ordered = sorted(phase_scores, reverse=True)
        separation = max(0.0, ordered[0] - ordered[1]) / max(abs(ordered[0]), 1e-6)
        confidence = min(0.72, 0.48 + separation * 0.6)
    return beats, downbeats, first_onset, {
        "engine": "librosa_dynamic",
        "confidence": round(confidence, 3),
        "phase": phase,
    }


def _run_beat_this(audio_path: Path) -> tuple[list[float], list[float], dict[str, Any]]:
    from .stem_separator import find_demucs_python

    python = find_demucs_python()
    if not python:
        raise RuntimeError("isolated PyTorch environment is unavailable")
    worker = settings.root_dir / "scripts" / "beat_this_worker.py"
    if not worker.is_file():
        raise RuntimeError("Beat This worker is missing")
    with tempfile.TemporaryDirectory(prefix="audiosheet-rhythm-") as temporary:
        output = Path(temporary) / "rhythm.json"
        command = [
            python,
            str(worker),
            str(audio_path),
            str(output),
            settings.rhythm_model,
            settings.rhythm_device,
        ]
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
            timeout=settings.rhythm_timeout_seconds,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        if not output.is_file():
            detail = (completed.stderr or completed.stdout or "Beat This did not create output").strip()
            raise RuntimeError(detail[-1200:])
        payload = json.loads(output.read_text(encoding="utf-8"))
    beats = payload.get("beats") if isinstance(payload.get("beats"), list) else []
    downbeats = payload.get("downbeats") if isinstance(payload.get("downbeats"), list) else []
    return [float(value) for value in beats], [float(value) for value in downbeats], {
        "engine": f"beat_this:{settings.rhythm_model}",
        "confidence": 0.92 if len(downbeats) >= 4 else 0.78,
        "model": settings.rhythm_model,
        "device": settings.rhythm_device,
        "stdout": (completed.stdout or "")[-300:],
    }


def _observed_downbeat_indices(beats: Sequence[float], downbeats: Sequence[float]) -> list[int]:
    if not beats:
        return []
    interval = _median([beats[index + 1] - beats[index] for index in range(len(beats) - 1)], 0.6)
    tolerance = max(0.08, interval * 0.38)
    result: list[int] = []
    for value in downbeats:
        index = _nearest_index(beats, value)
        if abs(beats[index] - value) <= tolerance and (not result or index != result[-1]):
            result.append(index)
    return sorted(set(result))


def _choose_measure_steps(
    beats: Sequence[float],
    observed: Sequence[int],
    start_index: int,
    pulses_per_measure: int,
    duration: float,
) -> list[tuple[int, int]]:
    """Return (start_beat_index, pulse_count) for full measures.

    For 4/4 we permit isolated 2/4 measures only when Beat This reports a
    downbeat two pulses after the current one.  Missing downbeats are filled at
    the dominant meter so a single model miss cannot shift the rest of the song.
    """
    observed_set = set(observed)
    allowed = (4, 2) if pulses_per_measure == 4 else (pulses_per_measure,)
    result: list[tuple[int, int]] = []
    current = max(0, start_index)
    max_index = len(beats) - 1
    guard = 0
    while current <= max_index and guard < 2000:
        guard += 1
        step = pulses_per_measure
        if pulses_per_measure == 4:
            has_two = current + 2 in observed_set
            has_four = current + 4 in observed_set
            # A 2/4 bar is credible when the model explicitly marks it and the
            # following downbeat resumes a legal 4/4/2/4 distance.
            next_after_two = any(index in observed_set for index in (current + 4, current + 6))
            if has_two and not has_four and next_after_two:
                step = 2
            elif has_four:
                step = 4
            else:
                next_observed = next((index for index in observed if index > current), None)
                if next_observed is not None and next_observed - current == 2:
                    step = 2
        result.append((current, step))
        current += step
        if current < len(beats) and beats[current] >= duration - 0.02:
            break
        if current >= len(beats):
            break
    return result


def _extend_beats(beats: list[float], duration: float, minimum_count: int = 8) -> list[float]:
    if not beats:
        return beats
    interval = _median([beats[index + 1] - beats[index] for index in range(len(beats) - 1)], 0.6)
    result = list(beats)
    while (len(result) < minimum_count or result[-1] < duration + interval * 6) and len(result) < 20000:
        recent = [result[index + 1] - result[index] for index in range(max(0, len(result) - 9), len(result) - 1)]
        step = _median(recent, interval)
        result.append(round(result[-1] + step, 6))
    return result


def _compress_tempo_changes(changes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for item in changes:
        bpm = round(max(30.0, min(250.0, _finite(item.get("bpm"), 120.0))), 2)
        normalized = {**item, "bpm": bpm}
        if not result:
            result.append(normalized)
            continue
        if abs(float(result[-1]["bpm"]) - bpm) < 0.85:
            continue
        result.append(normalized)
    return result


def build_rhythm_map(
    *,
    beats: Iterable[Any],
    downbeats: Iterable[Any],
    duration_seconds: float,
    time_signature: str,
    engine: str,
    confidence: float,
    first_onset_time: float | None = None,
    bpm_hint: float = 0.0,
) -> dict[str, Any]:
    duration = max(0.1, _finite(duration_seconds, 0.1))
    beats_value, beat_type, pulses_per_measure, pulse_quarters = _signature_values(time_signature)
    clean_beats = _dedupe_times(beats, duration)
    clean_downbeats = _dedupe_times(downbeats, duration)
    if len(clean_beats) < 4:
        clean_beats = _constant_beats(duration, bpm_hint or 120.0, pulse_quarters)
        clean_downbeats = clean_beats[::pulses_per_measure]
        engine = "constant_fallback"
        confidence = min(float(confidence), 0.25)
    clean_beats = _extend_beats(clean_beats, duration)
    intervals = [clean_beats[index + 1] - clean_beats[index] for index in range(len(clean_beats) - 1)]
    median_interval = _median(intervals, 60.0 * pulse_quarters / max(40.0, bpm_hint or 120.0))

    observed = _observed_downbeat_indices(clean_beats, clean_downbeats)
    if not observed:
        observed = [0]
    first_full_index = observed[0]
    first_full_time = clean_beats[first_full_index]
    full_measure_quarters = beats_value * 4.0 / beat_type

    pickup_quarters = 0.0
    onset_guard = first_onset_time is None or first_onset_time <= first_full_time + 0.06
    if first_full_time >= max(0.08, median_interval * 0.18) and onset_guard:
        candidate = round((first_full_time / median_interval * pulse_quarters) * 4.0) / 4.0
        if 0.24 <= candidate <= full_measure_quarters - 0.24:
            pickup_quarters = candidate
    if pickup_quarters <= 0:
        # Treat the first detected downbeat as score position zero.  This avoids
        # generating a fake pickup from leading silence.
        first_full_index = observed[0]
        first_full_time = clean_beats[first_full_index]

    # Beat anchors map actual seconds to quarter-note score positions.
    anchors: list[dict[str, float]] = [{"time": 0.0, "quarter": 0.0}]
    for index, beat_time in enumerate(clean_beats):
        quarter = pickup_quarters + (index - first_full_index) * pulse_quarters
        if quarter < -0.001 or beat_time < -0.001:
            continue
        if beat_time <= duration + median_interval * 5:
            anchors.append({"time": round(beat_time, 6), "quarter": round(max(0.0, quarter), 6)})
    anchors.sort(key=lambda item: (item["time"], item["quarter"]))
    compact: list[dict[str, float]] = []
    for item in anchors:
        if compact and abs(item["time"] - compact[-1]["time"]) < 1e-6:
            if item["quarter"] > compact[-1]["quarter"]:
                compact[-1] = item
        elif not compact or item["quarter"] > compact[-1]["quarter"] - 1e-6:
            compact.append(item)
    anchors = compact

    steps = _choose_measure_steps(
        clean_beats, observed, first_full_index, pulses_per_measure, duration
    )
    measures: list[dict[str, Any]] = []
    measure_number = 1
    if pickup_quarters > 0:
        measures.append({
            "index": 0,
            "number": 0,
            "start": 0.0,
            "end": round(first_full_time, 6),
            "start_quarter": 0.0,
            "end_quarter": round(pickup_quarters, 6),
            "quarter_length": round(pickup_quarters, 6),
            "beats": beats_value,
            "beat_type": beat_type,
            "implicit": True,
            "tempo": round(60.0 * pulse_quarters / median_interval, 2),
        })

    current_quarter = pickup_quarters
    for start_index, pulse_count in steps:
        start_time = clean_beats[start_index]
        end_index = min(len(clean_beats) - 1, start_index + pulse_count)
        end_time = clean_beats[end_index]
        if start_time >= duration + 0.02:
            break
        if beats_value == 4 and beat_type == 4:
            measure_beats, measure_beat_type = (2, 4) if pulse_count == 2 else (4, 4)
            quarter_length = float(measure_beats)
        elif (beats_value, beat_type) == (6, 8):
            measure_beats, measure_beat_type = 6, 8
            quarter_length = 3.0
        else:
            measure_beats, measure_beat_type = beats_value, beat_type
            quarter_length = beats_value * 4.0 / beat_type
        actual_end = min(duration, end_time)
        actual_quarter_end = current_quarter + quarter_length
        implicit = False
        if actual_end < end_time - 0.02:
            fraction = max(0.0, (actual_end - start_time) / max(end_time - start_time, 1e-6))
            actual_quarter_end = current_quarter + quarter_length * fraction
            implicit = actual_quarter_end - current_quarter < quarter_length - 0.12
        local_intervals = [
            clean_beats[index + 1] - clean_beats[index]
            for index in range(start_index, min(end_index, len(clean_beats) - 1))
        ]
        tempo = 60.0 * pulse_quarters / _median(local_intervals, median_interval)
        measures.append({
            "index": len(measures),
            "number": measure_number,
            "start": round(start_time, 6),
            "end": round(actual_end, 6),
            "start_quarter": round(current_quarter, 6),
            "end_quarter": round(actual_quarter_end, 6),
            "quarter_length": round(actual_quarter_end - current_quarter, 6),
            "beats": measure_beats,
            "beat_type": measure_beat_type,
            "implicit": implicit,
            "tempo": round(max(30.0, min(250.0, tempo)), 2),
        })
        current_quarter += quarter_length
        measure_number += 1
        if actual_end >= duration - 0.02:
            break

    if not measures:
        # Should only happen for pathological inputs.
        interval = 60.0 / max(30.0, min(250.0, bpm_hint or 120.0))
        measure_length = full_measure_quarters * interval
        cursor = 0.0
        quarter = 0.0
        while cursor < duration and len(measures) < 2000:
            end = min(duration, cursor + measure_length)
            measures.append({
                "index": len(measures), "number": len(measures) + 1,
                "start": round(cursor, 6), "end": round(end, 6),
                "start_quarter": round(quarter, 6),
                "end_quarter": round(quarter + (end - cursor) / interval, 6),
                "quarter_length": round((end - cursor) / interval, 6),
                "beats": beats_value, "beat_type": beat_type,
                "implicit": end < cursor + measure_length - 0.02,
                "tempo": round(60.0 / interval, 2),
            })
            quarter += full_measure_quarters
            cursor += measure_length

    # Ensure an exact duration anchor exists for interpolation.
    q_at_duration = _interpolate_time_to_quarter(anchors, duration, default_bpm=bpm_hint or 120.0)
    if not anchors or abs(anchors[-1]["time"] - duration) > 1e-6:
        anchors.append({"time": round(duration, 6), "quarter": round(q_at_duration, 6)})
    anchors.sort(key=lambda item: item["time"])

    local_bpms = [60.0 * pulse_quarters / value for value in intervals if 0.18 <= value <= 2.0]
    bpm = _median(local_bpms, bpm_hint or 120.0)
    tempo_candidates = [
        {
            "measure": int(measure["number"]),
            "time": float(measure["start"]),
            "quarter": float(measure["start_quarter"]),
            "bpm": float(measure["tempo"]),
        }
        for measure in measures
    ]
    tempo_changes = _compress_tempo_changes(tempo_candidates)
    meter_changes: list[dict[str, Any]] = []
    previous_meter: tuple[int, int] | None = None
    for measure in measures:
        meter = (int(measure["beats"]), int(measure["beat_type"]))
        if meter != previous_meter:
            meter_changes.append({
                "measure": int(measure["number"]),
                "time": float(measure["start"]),
                "quarter": float(measure["start_quarter"]),
                "beats": meter[0],
                "beat_type": meter[1],
            })
            previous_meter = meter

    return {
        "version": RHYTHM_VERSION,
        "engine": engine,
        "confidence": round(max(0.0, min(1.0, float(confidence))), 3),
        "requested_time_signature": time_signature,
        "bpm": round(max(30.0, min(250.0, bpm)), 2),
        "pulse_quarters": pulse_quarters,
        "duration_seconds": round(duration, 6),
        "beats": [round(value, 6) for value in clean_beats if value <= duration + 0.02],
        "downbeats": [round(float(measure["start"]), 6) for measure in measures if int(measure["number"]) > 0],
        "anchors": anchors,
        "pickup": {
            "present": pickup_quarters > 0,
            "quarter_length": round(pickup_quarters, 3),
            "end_time": round(first_full_time, 6) if pickup_quarters > 0 else 0.0,
        },
        "first_full_measure_start": round(first_full_time if pickup_quarters > 0 else 0.0, 6),
        "measures": measures,
        "meter_changes": meter_changes,
        "tempo_changes": tempo_changes,
    }


def _interpolate_time_to_quarter(
    anchors: Sequence[dict[str, Any]], time_value: float, *, default_bpm: float = 120.0
) -> float:
    if not anchors:
        return max(0.0, time_value) * default_bpm / 60.0
    times = [float(item["time"]) for item in anchors]
    position = bisect_right(times, time_value)
    if position <= 0:
        first = anchors[0]
        return float(first["quarter"]) + (time_value - float(first["time"])) * default_bpm / 60.0
    if position >= len(anchors):
        left = anchors[-2] if len(anchors) >= 2 else anchors[-1]
        right = anchors[-1]
    else:
        left, right = anchors[position - 1], anchors[position]
    dt = float(right["time"]) - float(left["time"])
    if abs(dt) < 1e-9:
        return float(left["quarter"])
    portion = (time_value - float(left["time"])) / dt
    return float(left["quarter"]) + portion * (float(right["quarter"]) - float(left["quarter"]))


def time_to_quarter(rhythm_map: dict[str, Any] | None, time_value: float, bpm: float = 120.0) -> float:
    value = max(0.0, _finite(time_value, 0.0))
    if not rhythm_map:
        return value * max(30.0, min(250.0, bpm)) / 60.0
    anchors = rhythm_map.get("anchors") if isinstance(rhythm_map.get("anchors"), list) else []
    return max(0.0, _interpolate_time_to_quarter(anchors, value, default_bpm=float(rhythm_map.get("bpm") or bpm)))


def quarter_to_time(rhythm_map: dict[str, Any] | None, quarter_value: float, bpm: float = 120.0) -> float:
    value = max(0.0, _finite(quarter_value, 0.0))
    if not rhythm_map:
        return value * 60.0 / max(30.0, min(250.0, bpm))
    anchors = rhythm_map.get("anchors") if isinstance(rhythm_map.get("anchors"), list) else []
    if not anchors:
        return value * 60.0 / max(30.0, min(250.0, float(rhythm_map.get("bpm") or bpm)))
    quarters = [float(item["quarter"]) for item in anchors]
    position = bisect_right(quarters, value)
    if position <= 0:
        left = anchors[0]
        return max(0.0, float(left["time"]) + (value - float(left["quarter"])) * 60.0 / max(30.0, float(rhythm_map.get("bpm") or bpm)))
    if position >= len(anchors):
        left = anchors[-2] if len(anchors) >= 2 else anchors[-1]
        right = anchors[-1]
    else:
        left, right = anchors[position - 1], anchors[position]
    dq = float(right["quarter"]) - float(left["quarter"])
    if abs(dq) < 1e-9:
        return float(left["time"])
    portion = (value - float(left["quarter"])) / dq
    return max(0.0, float(left["time"]) + portion * (float(right["time"]) - float(left["time"])))


def _measure_for_quarter(rhythm_map: dict[str, Any] | None, quarter: float) -> dict[str, Any] | None:
    if not rhythm_map:
        return None
    measures = rhythm_map.get("measures") if isinstance(rhythm_map.get("measures"), list) else []
    for measure in measures:
        if float(measure.get("start_quarter", 0)) - 1e-6 <= quarter <= float(measure.get("end_quarter", 0)) + 1e-6:
            return measure
    return measures[-1] if measures else None


def _quantized_quarter(
    value: float,
    rhythm_map: dict[str, Any] | None,
    subdivision: int,
    allow_triplets: bool,
) -> float:
    measure = _measure_for_quarter(rhythm_map, value)
    origin = float(measure.get("start_quarter", 0)) if measure else 0.0
    local = value - origin
    candidates = [(round(local * subdivision) / subdivision, 0.0)]
    if allow_triplets:
        candidates.extend([
            (round(local * 3.0) / 3.0, 0.018),
            (round(local * 6.0) / 6.0, 0.026),
        ])
    best = min(candidates, key=lambda item: (abs(item[0] - local) + item[1], item[0]))[0]
    return max(0.0, origin + best)


def quantize_notes_to_rhythm(
    notes: Iterable[dict[str, Any]],
    rhythm_map: dict[str, Any] | None,
    *,
    bpm: float,
    quantization: int = 16,
    allow_triplets: bool = True,
    minimum_quarters: float = 0.25,
) -> list[dict[str, Any]]:
    subdivision = max(2, min(8, int(quantization) // 4))
    result: list[dict[str, Any]] = []
    for item in notes:
        if not isinstance(item, dict):
            continue
        try:
            start = float(item["start"]); end = float(item["end"])
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        start_q_raw = time_to_quarter(rhythm_map, start, bpm)
        end_q_raw = time_to_quarter(rhythm_map, end, bpm)
        start_q = _quantized_quarter(start_q_raw, rhythm_map, subdivision, allow_triplets)
        end_q = _quantized_quarter(end_q_raw, rhythm_map, subdivision, allow_triplets)
        min_q = minimum_quarters
        if item.get("role") == "fill":
            min_q = min(min_q, 1.0 / 6.0 if allow_triplets else 0.25)
        if end_q < start_q + min_q:
            candidates = [start_q + min_q]
            if allow_triplets:
                candidates.append(start_q + 1.0 / 3.0)
            end_q = min(candidates, key=lambda value: abs(value - end_q_raw))
        normalized = dict(item)
        normalized["score_start_q"] = round(start_q, 6)
        normalized["score_end_q"] = round(end_q, 6)
        normalized["start"] = round(quarter_to_time(rhythm_map, start_q, bpm), 5)
        normalized["end"] = round(max(normalized["start"] + 0.04, quarter_to_time(rhythm_map, end_q, bpm)), 5)
        result.append(normalized)

    # Merge exact duplicates created by snapping, retaining the strongest note.
    dedup: dict[tuple[float, float, int, str], dict[str, Any]] = {}
    for note in result:
        key = (
            float(note["score_start_q"]), float(note["score_end_q"]), int(note.get("pitch", 0)), str(note.get("staff") or "")
        )
        previous = dedup.get(key)
        if previous is None or int(note.get("velocity", 0)) > int(previous.get("velocity", 0)):
            dedup[key] = note
    output = list(dedup.values())
    output.sort(key=lambda note: (float(note["start"]), str(note.get("staff") or ""), -int(note.get("pitch", 0))))
    return output


def harmonic_windows(rhythm_map: dict[str, Any] | None) -> list[dict[str, float]]:
    if not rhythm_map:
        return []
    windows: list[dict[str, float]] = []
    for measure in rhythm_map.get("measures", []):
        start_q = float(measure.get("start_quarter", 0))
        end_q = float(measure.get("end_quarter", start_q))
        length = end_q - start_q
        if length <= 0.05:
            continue
        if bool(measure.get("implicit")) or length <= 2.1:
            points = [start_q, end_q]
        elif length >= 3.5:
            points = [start_q, start_q + length / 2.0, end_q]
        elif length >= 2.7:
            points = [start_q, start_q + length / 2.0, end_q]
        else:
            points = [start_q, end_q]
        for left, right in zip(points, points[1:]):
            windows.append({
                "start_quarter": round(left, 6),
                "end_quarter": round(right, 6),
                "start": round(quarter_to_time(rhythm_map, left, float(rhythm_map.get("bpm") or 120)), 6),
                "end": round(quarter_to_time(rhythm_map, right, float(rhythm_map.get("bpm") or 120)), 6),
                "measure": int(measure.get("number", 0)),
            })
    return windows


def constant_rhythm_map(
    duration_seconds: float,
    bpm: float,
    time_signature: str,
    *,
    engine: str = "constant_legacy",
) -> dict[str, Any]:
    _, _, pulses_per_measure, pulse_quarters = _signature_values(time_signature)
    beats = _constant_beats(duration_seconds, bpm, pulse_quarters)
    return build_rhythm_map(
        beats=beats,
        downbeats=beats[::pulses_per_measure],
        duration_seconds=duration_seconds,
        time_signature=time_signature,
        engine=engine,
        confidence=0.2,
        first_onset_time=0.0,
        bpm_hint=bpm,
    )


def analyze_rhythm(
    audio_path: Path,
    *,
    duration_seconds: float,
    time_signature: str,
    bpm_hint: float = 0.0,
) -> dict[str, Any]:
    """Analyze beat/downbeat and return a serializable rhythm map."""
    first_onset = _first_onset_time(audio_path)
    errors: list[str] = []
    try:
        beats, downbeats, metadata = _run_beat_this(audio_path)
        result = build_rhythm_map(
            beats=beats,
            downbeats=downbeats,
            duration_seconds=duration_seconds,
            time_signature=time_signature,
            engine=str(metadata.get("engine") or "beat_this"),
            confidence=float(metadata.get("confidence") or 0.8),
            first_onset_time=first_onset,
            bpm_hint=bpm_hint,
        )
        result["tracker"] = metadata
        return result
    except Exception as exc:
        errors.append(f"Beat This: {exc}")

    try:
        beats, downbeats, librosa_onset, metadata = _librosa_track(
            audio_path, bpm_hint=bpm_hint, time_signature=time_signature
        )
        result = build_rhythm_map(
            beats=beats,
            downbeats=downbeats,
            duration_seconds=duration_seconds,
            time_signature=time_signature,
            engine=str(metadata.get("engine") or "librosa_dynamic"),
            confidence=float(metadata.get("confidence") or 0.5),
            first_onset_time=librosa_onset if librosa_onset is not None else first_onset,
            bpm_hint=bpm_hint,
        )
        result["tracker"] = metadata
        result["warnings"] = errors
        return result
    except Exception as exc:
        errors.append(f"librosa: {exc}")

    result = constant_rhythm_map(duration_seconds, bpm_hint or 120.0, time_signature)
    result["warnings"] = errors
    return result
