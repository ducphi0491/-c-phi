# Hướng dẫn vận hành AudioSheet Studio 1.3.0

## Khởi động

Nhấp đúp `CHAY_WEBSITE.bat`. Ở lần đầu, chương trình cài hai môi trường riêng:

- `.venv`: FastAPI, Basic Pitch, TensorFlow, MusicXML và ReportLab dự phòng.
- `.demucs-venv`: PyTorch CPU và Demucs.

Không đóng cửa sổ CMD khi đang dùng website.

## Tạo bản nhạc

1. Chọn file âm thanh hoặc link YouTube được phép xử lý.
2. Giữ bật **Tự động tách giọng và nhạc cụ bằng Demucs** cho một bài hát đầy đủ.
3. Nhập BPM nếu biết; để `0` để ước lượng.
4. Xác nhận quyền sử dụng rồi nhấn **Tạo sheet nhạc**.

Tiến trình gồm: lấy nguồn, chuẩn hóa, tách stem, nhận dạng, phối A/B/C và xuất file.

## Ba kết quả

- **A - Giai điệu hát:** một khuông, ưu tiên tuyến vocal.
- **B - Piano dễ chơi:** hai khuông, melody và tay trái đơn giản.
- **C - Phiên âm đầy đủ:** hai khuông, giữ nhiều thông tin từ vocal/bass/other hơn.

Khi chọn A/B/C, sheet, piano playback, MIDI, MusicXML và PDF cùng chuyển theo.

## PDF giống giao diện web

PDF v1.3.0 được tạo từ chính OpenSheetMusicDisplay đang dựng khuông nhạc trên web:

1. Website thử Chrome/Edge headless để tải PDF tự động.
2. Nếu máy không cho chạy headless, một tab in sạch sẽ tự mở.
3. Chọn **Save as PDF / Lưu thành PDF**.

Không dùng lại luồng Verovio -> svglib từng làm phóng sai glyph nhạc.

## Khi Demucs lỗi hoặc chưa tải được model

Bỏ chọn **Tự động tách giọng và nhạc cụ bằng Demucs** để chạy pipeline dự phòng trên bản phối đầy đủ, hoặc chạy lại `CAI_DEMUCS_AI.bat` khi mạng ổn định.

## Kiểm tra hệ thống

Nhấp đúp `KIEM_TRA_HE_THONG.bat`. Trạng thái cần có:

- FFmpeg / FFprobe: OK
- Basic Pitch: OK
- OSMD local: OK
- Chrome hoặc Edge: OK hoặc cảnh báo có tab Print dự phòng
- ReportLab: OK
- Demucs isolated environment: OK

## Dữ liệu

Kết quả nằm trong `data/jobs/<job_id>/`. Các file quan trọng gồm:

- `arrangements.json`
- `pipeline_manifest.json`
- `sheet_A_melody.musicxml`
- `sheet_B_light.musicxml`
- `sheet_C_full.musicxml`
- `stem_vocals.wav`, `stem_bass.wav`, `stem_other.wav`, `stem_drums.wav`
