"""Install SheetSage2 CPU dependencies in a dedicated Windows virtualenv.

Runs from a separate .bat bootstrap. Does NOT download model weights and does
NOT alter the AudioSheet website, Demucs or Pop2Piano environments.
"""
from __future__ import annotations

import datetime
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
VENV = PROJECT / ".sheetsage2-venv"
PYTHON = VENV / "Scripts" / "python.exe"
MARKER = VENV / ".audiosheet-installed.json"
LOG = PROJECT / "logs" / "sheetsage2-install.log"
CHECKER = PROJECT / "scripts" / "check_sheetsage2_windows.py"
REQUIREMENTS = PROJECT / "scripts" / "requirements_sheetsage2_windows.txt"


def _run(argv: list[str], logfile) -> None:
    friendly = " ".join(argv)
    if " --index-url " in friendly:
        friendly = friendly.split(" --index-url ")[0] + " --index-url [official PyTorch CPU index]"
    print("\n[RUN]", friendly, flush=True)
    logfile.write("\n[RUN] " + friendly + "\n")
    logfile.flush()
    environment = os.environ.copy()
    environment["PYTHONUTF8"] = "1"
    environment["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    with subprocess.Popen(
        argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", bufsize=1, env=environment,
    ) as child:
        assert child.stdout is not None
        for line in child.stdout:
            print(line, end="", flush=True)
            logfile.write(line)
        return_code = child.wait()
    logfile.flush()
    if return_code != 0:
        raise RuntimeError(f"Command failed with exit code {return_code}; read {LOG}")


def main() -> int:
    if sys.platform != "win32":
        print("[ERROR] This installer requires Windows. Linux uses scripts/install_advanced_ai.sh")
        return 2
    if sys.version_info[:2] not in ((3, 10), (3, 11)) or sys.maxsize <= 2 ** 32:
        print("[ERROR] Install 64-bit Python 3.10/3.11; the website normally uses Python 3.11.")
        return 2
    if not shutil.which("ffmpeg"):
        print("[ERROR] ffmpeg.exe not in PATH. Set up FFmpeg first (already used by AudioSheet).")
        return 2
    space_gb = shutil.disk_usage(PROJECT).free / (1024 ** 3)
    print(f"Windows: {platform.platform()} | free disk: {space_gb:.1f} GB")
    print("Isolated Python:", PYTHON)
    print("No WSL2/Ubuntu. CPU PyTorch 2.8.0. Model checkpoint is NOT pre-downloaded.")
    if space_gb < 12:
        print("[WARN] Less than 12 GB free; first model download may fail.")

    LOG.parent.mkdir(exist_ok=True, parents=True)
    # Never leave a stale success marker after an interrupted upgrade.
    MARKER.unlink(missing_ok=True)
    try:
        with LOG.open("a", encoding="utf-8") as logfile:
            logfile.write("\n==== AudioSheet native SheetSage2 installer " + datetime.datetime.now().isoformat() + " ====\n")
            if not PYTHON.is_file():
                _run([sys.executable, "-m", "venv", str(VENV)], logfile)
            _run([str(PYTHON), "-m", "pip", "install", "--upgrade", "pip", "wheel", "setuptools==78.1.1"], logfile)
            _run([str(PYTHON), "-m", "pip", "install", "torch==2.8.0+cpu", "torchaudio==2.8.0+cpu",
                  "--index-url", "https://download.pytorch.org/whl/cpu"], logfile)
            _run([str(PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], logfile)
            _run([str(PYTHON), str(CHECKER)], logfile)
        payload = {
            "engine": "sheetsage2", "complete": True,
            "runtime": "native_windows_cpu", "python": str(PYTHON),
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "weights_downloaded": False,
        }
        MARKER.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print("\n[OK] SheetSage2 CPU libraries installed in:", VENV)
        print("[NEXT] Restart CHAY_WEBSITE.bat, choose SheetSage2, confirm non-commercial research.")
        print("[NOTE] The first inference downloads model weights and may be slow.")
        return 0
    except (OSError, RuntimeError) as exc:
        print("[ERROR]", exc)
        print("Install log:", LOG)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
