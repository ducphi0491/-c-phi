from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 5:
        print("Usage: beat_this_worker.py INPUT OUTPUT MODEL DEVICE", file=sys.stderr)
        return 2
    source = Path(sys.argv[1])
    output = Path(sys.argv[2])
    model = sys.argv[3] or "small0"
    device = sys.argv[4] or "cpu"
    if not source.is_file():
        raise FileNotFoundError(source)
    from beat_this.inference import File2Beats

    tracker = File2Beats(checkpoint_path=model, device=device, dbn=False)
    beats, downbeats = tracker(str(source))
    payload = {
        "model": model,
        "device": device,
        "beats": [round(float(value), 7) for value in beats],
        "downbeats": [round(float(value), 7) for value in downbeats],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"beats": len(payload["beats"]), "downbeats": len(payload["downbeats"]), "model": model}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
