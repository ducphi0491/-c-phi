#!/usr/bin/env bash
set -euo pipefail
project="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ "$#" -ne 3 ]]; then
  echo "Usage: run_advanced_ai.sh ENGINE AUDIO OUTPUT" >&2
  exit 2
fi
engine="$1"
case "$engine" in
  pop2piano) env_path="$project/.ai-pop2piano-venv" ;;
  sheetsage2) env_path="$project/.ai-sheetsage2-venv" ;;
  *) echo "Invalid engine" >&2; exit 2 ;;
esac
if [[ ! -f "$env_path/pyvenv.cfg" ]]; then
  echo "Missing isolated virtual environment: $env_path" >&2
  exit 3
fi
exec "$env_path/bin/python" "$project/scripts/ai_external_worker.py" "$@"
