from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.live_score import create_arrangement_xml
from app.pdf_export import export_musicxml_to_pdf, pdf_engine_status


def main() -> int:
    output_dir = ROOT / "data" / "pdf_test"
    output_dir.mkdir(parents=True, exist_ok=True)
    source = output_dir / "AudioSheet_PDF_TEST.musicxml"
    output = output_dir / "AudioSheet_PDF_TEST.pdf"
    notes = [
        {"start": 0.0, "end": 0.45, "pitch": 64, "velocity": 86, "staff": "upper"},
        {"start": 0.5, "end": 0.95, "pitch": 67, "velocity": 84, "staff": "upper"},
        {"start": 1.0, "end": 1.45, "pitch": 69, "velocity": 82, "staff": "upper"},
        {"start": 0.0, "end": 1.8, "pitch": 43, "velocity": 70, "staff": "lower"},
    ]
    source.write_bytes(create_arrangement_xml(
        notes,
        "light",
        "AudioSheet PDF TEST",
        100,
        "4/4",
        16,
        60,
        2.0,
        0,
        [{"start": 0.0, "root": 0, "quality": "major"}],
    ))
    engine = export_musicxml_to_pdf(source, output, require_web_fidelity=True)
    print("[OK] PDF engine:", engine)
    print("[OK] PDF file:", output)
    print("[OK] PDF size:", output.stat().st_size)
    print("[INFO] Engines:", pdf_engine_status())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
