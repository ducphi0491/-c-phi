from __future__ import annotations

import importlib
import importlib.metadata
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "installed"


def check_import(name: str, package_name: str | None = None, required: bool = True) -> bool:
    try:
        importlib.import_module(name)
        print(f"[OK] {name}: {package_version(package_name or name.split('.')[0])}")
        return True
    except Exception as exc:
        label = "THIEU/LOI" if required else "TUY CHON"
        print(f"[{label}] {name}: {exc}")
        return not required


def check_pdf_smoke() -> bool:
    try:
        from app.live_score import create_arrangement_xml
        from app.pdf_export import export_musicxml_to_pdf, pdf_engine_status

        notes = [
            {"start": 0.0, "end": 0.5, "pitch": 64, "velocity": 84, "staff": "upper"},
            {"start": 0.5, "end": 1.0, "pitch": 67, "velocity": 82, "staff": "upper"},
            {"start": 0.0, "end": 1.0, "pitch": 43, "velocity": 68, "staff": "lower"},
        ]
        xml = create_arrangement_xml(
            notes,
            "light",
            "AudioSheet PDF self-test",
            100,
            "4/4",
            16,
            60,
            2.0,
            0,
            [{"start": 0.0, "root": 0, "quality": "major"}],
        )
        with tempfile.TemporaryDirectory(prefix="audiosheet-pdf-") as temporary:
            folder = Path(temporary)
            source = folder / "test.musicxml"
            output = folder / "test.pdf"
            source.write_bytes(xml)
            engine = export_musicxml_to_pdf(source, output)
            data = output.read_bytes()
            if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-2048:]:
                raise RuntimeError("invalid PDF signature")
            print(f"[OK] PDF thuc te: {engine}, {output.stat().st_size} bytes")
            print(f"[OK] PDF engines: {pdf_engine_status()}")
        return True
    except Exception as exc:
        print(f"[LOI] PDF self-test: {exc}")
        return False


def check_demucs_optional() -> bool:
    candidates = [
        ROOT / ".demucs-venv" / "Scripts" / "python.exe",
        ROOT / ".demucs-venv" / "bin" / "python",
    ]
    python = next((item for item in candidates if item.is_file()), None)
    if not python:
        print("[TUY CHON] Demucs chua cai; CHAY_WEBSITE.bat se tu cai khi can")
        return False
    try:
        completed = subprocess.run(
            [str(python), str(ROOT / "scripts" / "check_demucs.py")],
            capture_output=True,
            text=True,
            timeout=30,
            check=True,
        )
        print("[OK] Demucs isolated environment")
        print(completed.stdout.strip())
        return True
    except Exception as exc:
        print(f"[CANH BAO] Demucs environment loi: {exc}")
        return False


def main() -> int:
    print(f"Python: {platform.python_version()} ({sys.executable})")
    py_ok = sys.version_info[:2] == (3, 11)
    print("[OK] Python 3.11" if py_ok else "[LOI] Can dung Python 3.11 cho Basic Pitch 0.4.0")

    ok = py_ok
    for command in ("ffmpeg", "ffprobe"):
        path = shutil.which(command)
        print(f"[OK] {command}: {path}" if path else f"[THIEU] {command}")
        ok = ok and bool(path)

    node = shutil.which("node")
    print(f"[OK] node: {node}" if node else "[TUY CHON] Node.js ho tro YouTube on dinh hon")

    required = (
        ("fastapi", "fastapi"),
        ("music21", "music21"),
        ("tensorflow", "tensorflow"),
        ("basic_pitch", "basic-pitch"),
        ("basic_pitch.inference", "basic-pitch"),
        ("yt_dlp", "yt-dlp"),
        ("resampy", "resampy"),
        ("pkg_resources", "setuptools"),
        ("pretty_midi", "pretty-midi"),
        ("reportlab", "reportlab"),
        ("pypdf", "pypdf"),
    )
    for module, package in required:
        ok = check_import(module, package, required=True) and ok

    from app.browser_pdf import find_browser
    browser = find_browser()
    print(f"[OK] Chrome/Edge PDF: {browser}" if browser else "[CANH BAO] Khong tim thay Chrome/Edge; nut PDF se mo cua so Print cua trinh duyet")

    osmd = ROOT / "web" / "vendor" / "opensheetmusicdisplay.min.js"
    print(f"[OK] local OSMD: {osmd}" if osmd.exists() else "[THIEU] OSMD local; chay lai scripts\\download_osmd.ps1")
    ok = ok and osmd.exists()
    ok = check_pdf_smoke() and ok
    check_demucs_optional()
    print("[OK] Thanh phan cot loi san sang" if ok else "[LOI] Con thanh phan cot loi bi thieu")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
