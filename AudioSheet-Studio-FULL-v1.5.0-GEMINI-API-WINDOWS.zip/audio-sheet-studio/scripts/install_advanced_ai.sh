#!/usr/bin/env bash
set -euo pipefail
project="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
choice="${1:-pop2piano}"
if [[ "$choice" != "sheetsage2" && "$choice" != "pop2piano" && "$choice" != "both" ]]; then
  echo "Choose pop2piano, sheetsage2 or both." >&2; exit 2
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "[LOI] FFmpeg trong WSL chua co. Ubuntu: sudo apt update && sudo apt install ffmpeg" >&2; exit 3
fi
py=""
for candidate in python3.11 python3.10; do
  if command -v "$candidate" >/dev/null 2>&1; then py="$candidate"; break; fi
done
if [[ -z "$py" ]]; then
  echo "[LOI] Can Python 3.10/3.11 va python3.x-venv trong Ubuntu WSL." >&2; exit 3
fi
install_one() {
  local engine="$1" env_path="$project/.ai-$1-venv"
  echo "[AI] Tao moi truong rieng cho $engine ..."
  "$py" -m venv "$env_path"
  "$env_path/bin/python" -m pip install --upgrade pip setuptools wheel
  # Avoid installing any AI framework in the website's TensorFlow .venv.
  "$env_path/bin/python" -m pip install 'torch==2.8.0' 'torchaudio==2.8.0' --index-url https://download.pytorch.org/whl/cpu
  if [[ "$engine" == "pop2piano" ]]; then
    "$env_path/bin/python" -m pip install 'transformers>=4.56,<5' 'huggingface-hub>=0.34,<1' 'pretty_midi>=0.2.10,<1' 'librosa>=0.10.2,<1' 'scipy>=1.11,<2' 'essentia==2.1b6.dev1438'
  else
    # Upstream SheetSage2 pins Transformers 4.45.2; do not share the
    # Pop2Piano environment because its Transformers requirements differ.
    "$env_path/bin/python" -m pip install \
      'transformers==4.45.2' 'huggingface-hub==0.36.0' 'safetensors==0.5.3' \
      'numpy==1.24.3' 'scipy==1.13.1' 'mir_eval==0.8.2' \
      'pretty_midi==0.2.10' 'mido==1.3.3' 'setuptools==78.1.1' \
      'soundfile>=0.12,<1'
    echo "[CHU Y] SheetSage2 model CC BY-NC 4.0; can quyen truy cap model va MERT-v2 tren Hugging Face."
    echo "[CHU Y] Neu model yeu cau thu vien rieng, cai theo requirements.txt chinh thuc cua model."
  fi
  "$env_path/bin/python" -c 'import torch, transformers, pretty_midi; print("[OK] Torch", torch.__version__, "Transformers", transformers.__version__)'
  echo "[OK] Da cai $engine (chua tai checkpoint, se tai khi chay lan dau)."
}
if [[ "$choice" == "both" ]]; then
  install_one pop2piano
  install_one sheetsage2
else
  install_one "$choice"
fi
