from __future__ import annotations

import importlib.metadata
import json
import platform
import sys


def version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "missing"


def main() -> int:
    result = {
        "python": platform.python_version(),
        "executable": sys.executable,
        "torch": version("torch"),
        "torchaudio": version("torchaudio"),
        "demucs": version("demucs"),
        "beat_this": version("beat-this"),
    }
    try:
        import torch
        import demucs  # noqa: F401
        import beat_this  # noqa: F401
        result["torch_cpu_available"] = True
        result["cuda_available"] = bool(torch.cuda.is_available())
        ok = (result["demucs"] != "missing" and result["beat_this"] != "missing"
              and result["torch"] != "missing")
    except Exception as exc:
        result["error"] = str(exc)
        ok = False
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
