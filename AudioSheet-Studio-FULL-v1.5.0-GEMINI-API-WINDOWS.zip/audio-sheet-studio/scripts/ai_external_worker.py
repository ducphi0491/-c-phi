"""Actual local inference entry point; run only in an isolated Linux/WSL Python venv.

No model weights are bundled. Download/access is handled by Hugging Face and
subject to each upstream license. SheetSage2 uses upstream trusted remote code.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def _pop2piano(audio: Path, output: Path) -> dict:
    import librosa
    import pretty_midi
    import torch
    from transformers import Pop2PianoForConditionalGeneration, Pop2PianoProcessor

    print("Loading Pop2Piano weights ...", flush=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = Pop2PianoForConditionalGeneration.from_pretrained("sweetcocoa/pop2piano").to(device).eval()
    processor = Pop2PianoProcessor.from_pretrained("sweetcocoa/pop2piano")
    waveform, sr = librosa.load(str(audio), sr=44100, mono=True)
    if waveform.size < 44100:
        raise RuntimeError("Audio must contain at least one second")
    print("Running Pop2Piano composer1 on", device, flush=True)
    inputs = processor(audio=waveform, sampling_rate=sr, return_tensors="pt").to(device)
    with torch.no_grad():
        tokens = model.generate(input_features=inputs["input_features"], composer="composer1")
    decoded = processor.batch_decode(token_ids=tokens, feature_extractor_output=inputs)
    piano_objects = decoded.get("pretty_midi_objects", [])
    if not piano_objects:
        raise RuntimeError("Pop2Piano generated no MIDI")
    midi: pretty_midi.PrettyMIDI = piano_objects[0]
    count = sum(len(inst.notes) for inst in midi.instruments)
    if not count:
        raise RuntimeError("Pop2Piano generated an empty MIDI")
    midi.write(str(output / "pop2piano.mid"))
    return {"engine": "pop2piano", "model": "sweetcocoa/pop2piano", "composer": "composer1", "notes": count, "midi_files": ["pop2piano.mid"], "device": device}


def _is_windows_native() -> bool:
    return sys.platform == "win32"


def _sheetsage2(audio: Path, output: Path) -> dict:
    import torch
    from transformers import AutoModel

    print("Loading SheetSage2 + parent MERT-v2-FullSong ...", flush=True)
    print("WARNING: trust_remote_code runs upstream Hugging Face Python code.", flush=True)
    # Windows Server 2019 / GTX 1060 6GB: prefer predictable CPU memory and
    # leave CUDA untouched. Linux/WSL retains its previous optional CUDA path.
    if _is_windows_native():
        device = "cpu"
        thread_value = os.environ.get("SHEETSAGE2_CPU_THREADS", "8")
        try:
            threads = min(32, max(1, int(thread_value)))
        except ValueError:
            threads = 8
        torch.set_num_threads(threads)
        print(f"SheetSage2 Windows native CPU, {threads} threads", flush=True)
    else:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    model = AutoModel.from_pretrained("m-a-p/SheetSage2", trust_remote_code=True).eval().to(device)
    print("Transcribing SheetSage2 on", device, flush=True)
    # Input normalized.wav is already FFmpeg-decoded by AudioSheet. The upstream
    # model uses the ffmpeg executable for its default decoding preset.
    model.transcribe(str(audio), output_dir=str(output))
    files = [name for name in ("melody_vocal.mid", "melody_instrumental.mid", "chords.mid", "transcription.mid")
             if (output / name).is_file()]
    if not files:
        raise RuntimeError("SheetSage2 did not generate MIDI files")
    return {"engine": "sheetsage2", "model": "m-a-p/SheetSage2", "device": device,
            "runtime": "native_windows_cpu" if _is_windows_native() else "linux", "midi_files": files,
            "license": "CC BY-NC 4.0, non-commercial research only"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("engine", choices=("sheetsage2", "pop2piano"))
    parser.add_argument("audio", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    audio = args.audio.resolve()
    output = args.output.resolve()
    if not audio.is_file():
        parser.error("Input audio does not exist")
    output.mkdir(parents=True, exist_ok=True)
    result = _sheetsage2(audio, output) if args.engine == "sheetsage2" else _pop2piano(audio, output)
    (output / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[OK]", result["engine"], result.get("notes", ""), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
