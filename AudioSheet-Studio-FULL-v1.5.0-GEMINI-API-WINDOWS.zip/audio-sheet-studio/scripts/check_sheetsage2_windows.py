"""Validate the separate SheetSage2 Windows CPU runtime, without downloading weights.

Optional --load-model explicitly downloads model weights and loads trusted
remote code in this separate environment; may consume many GB of RAM.
"""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import os
import platform
import shutil
import sys
from pathlib import Path


def check_runtime() -> bool:
    print("SheetSage2 native runtime diagnostics")
    print("OS:", platform.platform())
    print("Python:", sys.version.split()[0], sys.executable)
    print("Device: CPU-only (intentional for 32 GB RAM / GTX 1060 6GB)")
    ok = sys.version_info[:2] in ((3, 10), (3, 11)) and sys.maxsize > 2 ** 32
    if not ok:
        print("[ERROR] Requires 64-bit Python 3.10 or 3.11.")
    ffmpeg = shutil.which("ffmpeg")
    print("[OK] ffmpeg:", ffmpeg) if ffmpeg else print("[ERROR] ffmpeg.exe is missing from PATH")
    ok = ok and bool(ffmpeg)
    versions = {
        "torch": "2.8.0", "torchaudio": "2.8.0", "transformers": "4.45.2",
        "huggingface_hub": "0.36.0", "safetensors": "0.5.3", "numpy": "1.24.3",
        "scipy": "1.13.1", "pretty_midi": "0.2.10", "mido": "1.3.3",
        "mir_eval": "0.8.2", "soundfile": None,
    }
    for module, expected in versions.items():
        try:
            imported = importlib.import_module(module)
            package = "huggingface-hub" if module == "huggingface_hub" else module.replace("_", "-")
            version = importlib.metadata.version(package)
            if expected and version.split("+")[0] != expected:
                print(f"[ERROR] {module}: {version}; need {expected}")
                ok = False
            else:
                print(f"[OK] {module}: {version}")
            if module == "torch" and imported.cuda.is_available():
                print("[WARN] CUDA is available, but the SheetSage2 worker forces CPU.")
        except Exception as exc:
            print(f"[ERROR] Import {module}: {type(exc).__name__}: {exc}")
            ok = False
    print("Dependency check:", "PASS" if ok else "FAIL")
    return ok


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--load-model", action="store_true", help="Download and load real model weights (many GB)")
    args = parser.parse_args()
    if not check_runtime():
        return 1
    if args.load_model:
        print("[INFO] Loading real model, including MERT-v2-FullSong (non-commercial).")
        print("[WARNING] trust_remote_code=True executes Python from Hugging Face.")
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
        import torch
        from transformers import AutoModel
        model = AutoModel.from_pretrained("m-a-p/SheetSage2", trust_remote_code=True)
        model = model.eval().to("cpu")
        print("[OK] SheetSage2 model weights loaded on CPU:", type(model).__name__)
        del model
    else:
        print("[INFO] Model weights NOT checked. Use --load-model to test real checkpoint access.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("[ERROR]", type(exc).__name__, str(exc))
        raise SystemExit(2) from exc
