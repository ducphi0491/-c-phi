"""Offline diagnostic by default; --live sends a tiny billed/auth API request."""
from __future__ import annotations

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.gemini_harmony import gemini_status, api_key


def main() -> int:
    state = gemini_status()
    print('=== AUDIOSHEET GEMINI DIAGNOSTICS ===')
    print('SDK google-genai:', 'OK' if state['sdk_installed'] else 'MISSING')
    print('GEMINI_API_KEY:', 'CONFIGURED (hidden)' if state['configured'] else 'MISSING')
    print('Model:', state['model'])
    print('WSL2 required: NO')
    print('Audio upload: only when a job explicitly selects Gemini and consents')
    if not state['available']:
        print('ACTION: Run CAI_GEMINI_API.bat and edit .env in the project folder.')
        return 2
    if '--live' not in sys.argv:
        print('Local configuration OK. Real API authorization NOT tested. Use --live to test.')
        return 0
    print('Testing API authorization by sending a tiny text prompt (may consume quota)...')
    try:
        from google import genai
        with genai.Client(api_key=api_key()) as client:
            result = client.models.generate_content(model=state['model'], contents='Reply with OK.')
            if not result.text:
                raise RuntimeError('No text in API reply')
        print('API reply: OK (text response received)')
        return 0
    except Exception as exc:
        message = str(exc)
        key = api_key()
        if key:
            message = message.replace(key, '[REDACTED]')
        print('API failed:', message[:350])
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
