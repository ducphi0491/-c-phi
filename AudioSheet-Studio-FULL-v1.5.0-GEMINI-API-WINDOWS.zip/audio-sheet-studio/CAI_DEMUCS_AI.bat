@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DEMUCS_PYTHON=%CD%\.demucs-venv\Scripts\python.exe"

echo ==================================================
echo  AudioSheet Studio 1.3 - Cai Demucs + Beat This!
echo ==================================================
echo  PyTorch, Demucs va Beat This! duoc cai trong moi truong rieng.
echo  Lan dau can Internet; model se tu tai khi phan tich bai dau tien.
echo.

py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo [LOI] Khong tim thay Python 3.11.
  exit /b 1
)

if not exist "%DEMUCS_PYTHON%" (
  echo [1/4] Tao moi truong .demucs-venv...
  py -3.11 -m venv .demucs-venv
  if errorlevel 1 exit /b 1
)

echo [2/4] Cap nhat pip...
"%DEMUCS_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip wheel setuptools
if errorlevel 1 exit /b 1

echo [3/4] Cai PyTorch CPU chinh thuc...
"%DEMUCS_PYTHON%" -m pip install --disable-pip-version-check --index-url https://download.pytorch.org/whl/cpu torch torchaudio
if errorlevel 1 exit /b 1

echo [4/4] Cai Demucs va Beat This!...
"%DEMUCS_PYTHON%" -m pip install --disable-pip-version-check -r requirements_demucs.txt
if errorlevel 1 exit /b 1

echo.
"%DEMUCS_PYTHON%" scripts\check_demucs.py
if errorlevel 1 (
  echo [LOI] Demucs hoac Beat This! chua san sang.
  exit /b 1
)

echo.
echo [OK] Demucs va Beat This! da san sang.
echo Model htdemucs va small0 se tu tai o lan xu ly dau tien.
exit /b 0
