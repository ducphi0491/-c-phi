@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Chua cai website. Hay chay CHAY_WEBSITE.bat truoc.
  pause
  exit /b 1
)
.venv\Scripts\python.exe scripts\check_install.py
echo.
if exist ".demucs-venv\Scripts\python.exe" (
  .demucs-venv\Scripts\python.exe scripts\check_demucs.py
) else (
  echo [THIEU] Demucs chua duoc cai.
)
pause
