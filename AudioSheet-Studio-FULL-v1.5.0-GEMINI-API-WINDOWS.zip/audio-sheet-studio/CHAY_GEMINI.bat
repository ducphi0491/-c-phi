@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [1/2] Chua cai project. Dang cai cac thanh phan cot loi...
  call "%~dp0install_windows.bat"
  if errorlevel 1 (
    echo [LOI] Khong cai duoc AudioSheet. Vui long kiem tra Python 3.11.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" scripts\check_gemini.py
if errorlevel 1 (
  echo [THONG BAO] Chua co Gemini SDK hoac API key.
  call "%~dp0CAI_GEMINI_API.bat"
)
".venv\Scripts\python.exe" scripts\check_gemini.py
if errorlevel 1 (
  echo [LOI] Gemini chua san sang. Khong khoi dong nham sang local.
  pause
  exit /b 2
)
call "%~dp0CHAY_WEBSITE.bat"
exit /b %ERRORLEVEL%
