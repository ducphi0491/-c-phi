@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [LOI] Chua co .venv; chay CHAY_WEBSITE.bat truoc.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" scripts\check_gemini.py
if errorlevel 1 (
  echo [LOI] Chua cau hinh day du. Chay CAI_GEMINI_API.bat.
  pause
  exit /b 1
)
echo.
choice /C YN /M "Test API Gemini that (co the tinh phi/token)"
if errorlevel 2 goto :end
".venv\Scripts\python.exe" scripts\check_gemini.py --live
:end
pause
exit /b 0
