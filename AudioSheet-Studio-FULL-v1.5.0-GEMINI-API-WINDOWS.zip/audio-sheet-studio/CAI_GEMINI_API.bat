@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHON_BIN=%CD%\.venv\Scripts\python.exe"
echo ===================================================
echo  AudioSheet Studio - GEMINI API (Windows Server 2019)
echo ===================================================
echo  Khong can WSL2, Ubuntu, NVIDIA hay tai model AI.
echo.
if not exist "%PYTHON_BIN%" (
  echo [THONG TIN] Chua co moi truong website. Chay CHAY_WEBSITE.bat truoc.
  pause
  exit /b 2
)
echo [1/3] Cai thu vien Gemini vao moi truong website...
"%PYTHON_BIN%" -m pip install --disable-pip-version-check -r "%~dp0requirements_gemini.txt"
if errorlevel 1 goto :fail
echo.
if not exist ".env" (
  echo [2/3] Tao .env tu file mau. Ban can dien GEMINI_API_KEY.
  copy /y ".env.example" ".env" >nul
) else (
  echo [2/3] Giu nguyen .env dang su dung, khong ghi de.
)
echo [3/3] Kiem tra cau hinh khong tiet lo API key...
"%PYTHON_BIN%" scripts\check_gemini.py
if errorlevel 1 (
  echo.
  echo [CAN LAM] Mo file .env va dien dong GEMINI_API_KEY=...
  echo Lay key tai: https://aistudio.google.com/apikey
  echo File key se KHONG duoc gui len website; chi backend su dung.
  echo.
  choice /C YN /M "Mo .env bang Notepad bay gio"
  if not errorlevel 2 start /wait "" notepad.exe "%CD%\.env"
  echo Sau khi luu .env, chay lai KIEM_TRA_GEMINI.bat.
  pause
  exit /b 0
)
echo.
echo [OK] Gemini SDK va cau hinh tai may da san sang.
echo De kiem tra ket noi API that: chay KIEM_TRA_GEMINI.bat.
echo De tao sheet: chay CHAY_WEBSITE.bat, chon Gemini va dong y gui audio.
pause
exit /b 0
:fail
echo.
echo [LOI] Khong cai duoc google-genai. Kiem tra Internet/Python 3.11 va log pip.
pause
exit /b 1
