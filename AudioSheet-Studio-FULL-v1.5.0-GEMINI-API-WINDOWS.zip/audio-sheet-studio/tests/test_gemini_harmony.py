from __future__ import annotations

import copy
import json
import sys
import types
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import gemini_harmony as gemini
from app import main
from app.rhythm_grid import constant_rhythm_map


def _payload():
    melody = [dict(start=0.0, end=0.7, pitch=69, velocity=80, role='melody', source='vocals'),
              dict(start=2.0, end=2.7, pitch=71, velocity=80, role='melody', source='vocals')]
    full = []
    for start, pitches in [(0, (42, 57, 61)), (1, (42, 57, 61)),
                           (2, (47, 62, 66)), (3, (47, 62, 66))]:
        for pitch in pitches:
            full.append(dict(start=float(start), end=float(start) + .90, pitch=pitch,
                             velocity=96, role='bass' if pitch < 50 else 'other',
                             source='bass' if pitch < 50 else 'other'))
    return {'source': 'BasicPitch', 'analysis': {
        'key': {'tonic': 6, 'name': 'F# minor', 'mode': 'minor', 'fifths': 3},
        'chords': [dict(start=0.0, end=2.0, root=1, quality='sus4', bass_pc=1,
                        name='C#sus4', measure=1, confidence=.75),
                   dict(start=2.0, end=4.0, root=8, quality='dim', bass_pc=8,
                        name='G#dim', measure=2, confidence=.75)],
    }, 'modes': {'melody': {'notes': melody, 'count': 2},
                'full': {'notes': full, 'count': len(full)},
                'light_easy': {'notes': [], 'label': 'B easy'},
                'light_standard': {'notes': [], 'label': 'B standard'},
                'light_full': {'notes': [], 'label': 'B full'}}}


def _report():
    return {'model': 'gemini-test', 'key_name': 'F# minor', 'tempo_bpm_estimate': 120,
            'sections': [{'label': 'verse', 'start': 0., 'end': 4.}],
            'chords': [{'symbol': 'F#m', 'start': 0., 'end': 2.},
                       {'symbol': 'Bm', 'start': 2., 'end': 4.}]}


def test_chord_parser_supports_common_piano_chords_and_rejects_unknown():
    for symbol, expected in [('F#m','minor'), ('C#7','dominant7'), ('D/F#','major'),
                             ('G#m7(b5)','half-dim7'), ('Dmaj7','major7'),
                             ('Dsus4','sus4'), ('C#dim7','dim7')]:
        result = gemini.parse_chord(symbol)
        assert result and result['quality'] == expected, symbol
    assert gemini.parse_chord('N.C.') is None
    assert gemini.parse_chord('nonsense') is None
    assert gemini.parse_chord('D/xyz') is None
    assert gemini.parse_chord('C/G#') is None


def test_harmony_replaces_only_supported_chords_and_rebuilds_b():
    rhythm = constant_rhythm_map(5.0, 120., '4/4')
    before = _payload()
    after, summary = gemini.apply_harmony(copy.deepcopy(before), _report(), bpm=120,
                                           time_signature='4/4', quantization=16, rhythm=rhythm)
    assert summary['changed_windows'] == 2
    assert [c['name'] for c in after['analysis']['chords']] == ['F#m', 'Bm']
    assert after['modes']['melody']['notes'] == before['modes']['melody']['notes']
    assert after['modes']['full']['notes'] == before['modes']['full']['notes']
    assert all(after['modes'][m]['count'] > 0 for m in ['light_easy','light_standard','light_full'])
    assert any(n.get('chord') == 'Bm' for n in after['modes']['light_easy']['notes'])
    assert any(n['start'] >= 2.0 and n['pitch'] % 12 in (11,2,6) for n in after['modes']['light_standard']['notes'])
    assert after['analysis']['sections'][0]['label'] == 'verse'
    # A raw user-reported Gemini result cannot replace Pop2Piano B MIDI.
    pop_before = copy.deepcopy(before)
    pop_before['modes']['light_standard']['notes'] = [{'source':'pop2piano','pitch':72,'start':0.,'end':1.,'velocity':99}]
    with_pop, score = gemini.apply_harmony(pop_before, _report(), bpm=120, time_signature='4/4',
                                             quantization=16, rhythm=rhythm, replace_piano=False)
    assert score['changed_windows'] == 2
    assert with_pop['modes']['light_standard']['notes'][0]['source'] == 'pop2piano'
    assert with_pop['analysis']['chords'][0]['name'] == 'C#sus4'


def test_harmony_does_not_adopt_unsupported_predictions():
    payload = _payload()
    report = _report()
    report['chords'] = [{'start':0.,'end':2.,'symbol':'E7'},
                        {'start':2.,'end':4.,'symbol':'Cdim7'}]
    after, summary = gemini.apply_harmony(copy.deepcopy(payload), report, bpm=120,
                            time_signature='4/4', quantization=16,
                            rhythm=constant_rhythm_map(5.0, 120, '4/4'))
    assert summary['changed_windows'] == 0
    assert after['analysis']['chords'] == payload['analysis']['chords']


def test_json_sanitization_caps_and_rejects_bad_values():
    raw = {'key_name':'F# minor', 'tempo_bpm_estimate': float('nan'),
           'chords':[{'start':-1,'end':2.,'symbol':'F#m'},
                     {'start':1.,'end':9.,'symbol':'Bm'},
                     {'start':7.,'end':8.,'symbol':'E7'},
                     {'start':2.,'end':1.,'symbol':'X'}],
           'sections':[{'start':0.,'end':11.,'label':'verse'}], 'notes':'x'*999}
    result = gemini._clean_response(raw, 4.0)
    assert result['tempo_bpm_estimate'] is None
    assert len(result['chords']) == 2
    assert result['chords'][0]['start'] == 0.0
    assert result['chords'][1]['end'] == 4.0
    assert len(result['notes']) == 450


def test_fake_gemini_sdk_uploads_audio_requests_schema_deletes_cloud_file(monkeypatch, tmp_path):
    monkeypatch.setenv('GEMINI_API_KEY', 'FAKE_TEST_SECRET_DO_NOT_PRINT')
    monkeypatch.delenv('GOOGLE_API_KEY', raising=False)
    history = []
    class Uploaded:
        name = 'files/test-upload'
    class FakeFiles:
        def upload(self, **kwargs):
            history.append(('upload', kwargs))
            return Uploaded()
        def delete(self, **kwargs):
            history.append(('delete', kwargs))
    class FakeModels:
        def generate_content(self, **kwargs):
            history.append(('generate', kwargs))
            return types.SimpleNamespace(text=json.dumps(_report()))
    class FakeClient:
        def __init__(self, **kwargs):
            history.append(('client',kwargs))
            self.files, self.models = FakeFiles(), FakeModels()
        def close(self):
            history.append(('close', {}))
    class FakeTypes:
        class HttpOptions:
            def __init__(self, **kwargs): pass
        class GenerateContentConfig:
            def __init__(self, **kwargs): pass
    fakegenai = types.ModuleType('google.genai')
    fakegenai.Client = FakeClient
    fakegenai.types = FakeTypes
    monkeypatch.setitem(sys.modules,'google.genai',fakegenai)
    monkeypatch.setitem(sys.modules,'google.genai.types',FakeTypes)
    path = tmp_path/'part.mp3'
    path.write_bytes(b'mp3 bytes')
    assert json.loads(gemini._client_request(path))['chords'][0]['symbol'] == 'F#m'
    assert [event[0] for event in history] == ['client','upload','generate','delete','close']
    assert history[2][1]['model'] == gemini.settings.gemini_model
    assert 'FAKE_TEST_SECRET_DO_NOT_PRINT' not in str(history[2][1])


def test_gemini_no_key_or_consent_cannot_start_job(monkeypatch):
    monkeypatch.delenv('GEMINI_API_KEY', raising=False)
    monkeypatch.delenv('GOOGLE_API_KEY', raising=False)
    client = TestClient(main.app)
    params = {'youtube_url':'https://www.youtube.com/watch?v=abc12345678',
              'accepted_rights':'true','harmony_engine':'gemini'}
    result = client.post('/api/jobs',data=params)
    assert result.status_code == 400
    assert 'consent' in result.json()['detail'].lower()
    params['gemini_upload_consent'] = 'true'
    result = client.post('/api/jobs',data=params)
    assert result.status_code == 503
    health = client.get('/api/health').json()
    assert health['gemini']['configured'] is False
    assert 'key' not in health['gemini']


def test_audio_cleanup_even_on_request_error(monkeypatch, tmp_path):
    src = tmp_path / 'src.wav'; src.write_bytes(b'audio')
    def fake_prepare(source, dest, duration):
        dest.write_bytes(b'fake mp3')
        return dest
    def broken_api(path):
        assert path.is_file()
        raise gemini.GeminiAnalysisError('Quota exceeded')
    monkeypatch.setattr(gemini,'gemini_status',lambda:{'available':True})
    monkeypatch.setattr(gemini,'_prepare_audio',fake_prepare)
    monkeypatch.setattr(gemini,'_client_request',broken_api)
    with pytest.raises(gemini.GeminiAnalysisError,match='Quota'):
        gemini.analyze_audio(src,tmp_path/'output',duration=8.0)
    assert not (tmp_path/'output'/'gemini_input.mp3').exists()


def test_end_to_end_gemini_changes_musicxml_midi_and_pdf_pipeline(monkeypatch):
    from app import processor
    from app.job_store import job_store
    from reportlab.pdfgen import canvas

    payload = _payload()
    payload['pipeline'] = 'basic_pitch_test'
    payload['duration_seconds'] = 5.0
    payload['rhythm'] = constant_rhythm_map(5.0, 120, '4/4')
    job = job_store.create({
        'source_type': 'upload', 'source_filename': 'source.wav', 'source_name': 'Gemini Fixture',
        'title': 'Gemini Fixture', 'mode': 'piano', 'bpm_requested': 120,
        'time_signature': '4/4', 'quantization': 16, 'split_pitch': 60,
        'minimum_midi': 36, 'maximum_midi': 96, 'onset_threshold': .5,
        'frame_threshold': .3, 'minimum_note_length_ms': 120,
        'separate_stems': False, 'melody_engine': 'basic_pitch', 'piano_engine': 'heuristic',
        'harmony_engine': 'gemini', 'gemini_upload_consent': True,
    })
    directory = job_store.job_dir(job['id'])
    (directory/'source.wav').write_bytes(b'fixture')

    def mock_normalize(src, dest, limit):
        dest.write_bytes(b'fake WAV')
        return 5.0

    def mock_pdf(xml, target):
        pdf = canvas.Canvas(str(target))
        pdf.drawString(72, 760, 'Integration Test')
        pdf.save()
        return 'mock_pdf'

    def mock_gemini(source, output, duration):
        assert source.name == 'normalized.wav'
        assert source.is_file()
        assert duration == 5.0
        return _report()

    monkeypatch.setattr(processor, 'normalize_audio', mock_normalize)
    monkeypatch.setattr(processor, 'analyze_rhythm', lambda *a, **kw: constant_rhythm_map(5.0,120,'4/4'))
    monkeypatch.setattr(processor, '_transcribe_stem', lambda **kw: payload['modes']['full']['notes'])
    monkeypatch.setattr(processor, 'prepare_variants', lambda *args, **kwargs: copy.deepcopy(payload))
    monkeypatch.setattr(processor, 'analyze_audio', mock_gemini)
    monkeypatch.setattr(processor, 'export_musicxml_to_pdf', mock_pdf)
    monkeypatch.setattr(processor, 'pdf_engine_status', lambda: {'available':True,'preferred':'mock_pdf'})
    try:
        processor._process_job(job['id'])
        finished = job_store.get(job['id'])
        assert finished['status'] == 'done', finished.get('error')
        assert finished['ai_engines']['harmony']['used'] == 'gemini_validated'
        assert finished['ai_engines']['harmony']['changed_windows'] == 2
        resulting = json.loads((directory/'arrangements.json').read_text(encoding='utf8'))
        assert [c['name'] for c in resulting['analysis']['chords']] == ['F#m','Bm']
        assert resulting['modes']['melody']['notes'] == payload['modes']['melody']['notes']
        assert resulting['modes']['full']['notes'] == payload['modes']['full']['notes']
        assert (directory/'sheet_B_light_standard.mid').stat().st_size > 200
        assert (directory/'sheet_B_light_standard.musicxml').stat().st_size > 300
        assert (directory/'sheet_B_light_standard.pdf').stat().st_size > 200
        assert (directory/'gemini_analysis.json').is_file()
        report = json.loads((directory/'pipeline_manifest.json').read_text(encoding='utf8'))
        assert report['gemini']['summary']['changed_windows'] == 2
    finally:
        job_store.delete(job['id'])


def test_end_to_end_gemini_api_failure_falls_back_and_reports_warning(monkeypatch):
    from app import processor
    from app.job_store import job_store
    from reportlab.pdfgen import canvas

    payload = _payload()
    payload.update({'pipeline':'fallback_test','duration_seconds':5.0,
                    'rhythm':constant_rhythm_map(5.0,120,'4/4')})
    # The original local B exists, should be preserved when the API errors.
    payload['modes']['light_standard']['notes'] = list(payload['modes']['melody']['notes'])
    payload['modes']['light_standard']['count'] = len(payload['modes']['light_standard']['notes'])
    for tier in ('light_easy','light_full'):
        payload['modes'][tier]['notes'] = list(payload['modes']['melody']['notes'])
        payload['modes'][tier]['count'] = len(payload['modes'][tier]['notes'])
    job = job_store.create({
        'source_type':'upload','source_filename':'source.wav','title':'API failure',
        'mode':'piano','bpm_requested':120,'time_signature':'4/4','quantization':16,
        'split_pitch':60,'minimum_midi':36,'maximum_midi':96,'onset_threshold':.5,
        'frame_threshold':.3,'minimum_note_length_ms':120,'separate_stems':False,
        'melody_engine':'basic_pitch','piano_engine':'heuristic','harmony_engine':'gemini',
        'gemini_upload_consent':True,
    })
    folder = job_store.job_dir(job['id'])
    (folder/'source.wav').write_bytes(b'fixture')
    def fake_pdf(xml, target):
        pdf = canvas.Canvas(str(target));pdf.drawString(72,720,'OK');pdf.save();return 'mock'
    def fake_norm(src,dest,max_seconds):
        dest.write_bytes(b'audio');return 5.0
    def fail_api(*args, **kwargs):
        raise gemini.GeminiAnalysisError('Quota exceeded')
    monkeypatch.setattr(processor,'normalize_audio',fake_norm)
    monkeypatch.setattr(processor,'analyze_rhythm',lambda *a,**kw: constant_rhythm_map(5.0,120,'4/4'))
    monkeypatch.setattr(processor,'_transcribe_stem',lambda **kwargs:payload['modes']['full']['notes'])
    monkeypatch.setattr(processor,'prepare_variants',lambda *a,**kw:copy.deepcopy(payload))
    monkeypatch.setattr(processor,'analyze_audio',fail_api)
    monkeypatch.setattr(processor,'export_musicxml_to_pdf',fake_pdf)
    monkeypatch.setattr(processor,'pdf_engine_status',lambda: {'available':True})
    try:
        processor._process_job(job['id'])
        finished = job_store.get(job['id'])
        assert finished['status'] == 'done', finished['error']
        assert finished['ai_engines']['harmony']['used'] == 'local'
        assert 'Quota exceeded' in finished['ai_warnings'][0]
        data = json.loads((folder/'arrangements.json').read_text(encoding='utf8'))
        assert data['analysis']['chords'] == payload['analysis']['chords']
    finally:
        job_store.delete(job['id'])
