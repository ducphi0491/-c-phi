from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_health_endpoint() -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert "limits" in payload


def test_root_page() -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert "AudioSheet Studio" in response.text


def test_v110_ui_contains_stem_and_pdf_controls() -> None:
    response = client.get('/')
    assert response.status_code == 200
    html = response.text
    assert 'id="separateStems"' in html
    assert 'name="separate_stems"' in html
    assert 'id="activePdfDownload"' in html
    assert 'data-status="separating"' in html
    assert 'data-status="exporting"' in html
