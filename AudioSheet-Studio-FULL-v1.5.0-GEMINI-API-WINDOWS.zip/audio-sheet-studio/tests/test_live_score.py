import io
import json
import xml.etree.ElementTree as ET

import pretty_midi
from fastapi.testclient import TestClient

from app.job_store import job_store
from app.live_score import create_arrangement_xml
from app.main import app

client = TestClient(app)


def fixture_job():
    job = job_store.create({
        'source_type': 'upload', 'title': 'Piano sheet <demo>',
        'bpm_used': 100, 'time_signature': '4/4',
        'quantization': 16, 'split_pitch': 60,
    })
    notes = [
        {'start': 0.3, 'end': 0.9, 'pitch': 68, 'velocity': 78},
        {'start': 0.91, 'end': 1.5, 'pitch': 69, 'velocity': 75},
        {'start': 1.5, 'end': 2.2, 'pitch': 66, 'velocity': 87},
        {'start': 0.3, 'end': 1.3, 'pitch': 42, 'velocity': 77},
        {'start': 2.1, 'end': 3.4, 'pitch': 45, 'velocity': 78},
        {'start': 0.3, 'end': 1.4, 'pitch': 80, 'velocity': 40},
    ]
    (job_store.job_dir(job['id']) / 'note_events.json').write_text(json.dumps(notes), encoding='utf-8')
    job_store.update(job['id'], status='done', artifacts=[])
    return job['id']


def count_onsets(xml):
    root = ET.fromstring(xml)
    counts = []
    for part in root.findall('part'):
        counts.append(len([
            n for n in part.findall('measure/note')
            if n.find('pitch') is not None
            and not any(x.get('type') == 'stop' for x in n.findall('tie'))
        ]))
    return counts


def test_selected_a_b_c_scores_are_different_and_downloadable():
    job_id = fixture_job()
    try:
        playback = client.get(f'/api/jobs/{job_id}/playback').json()
        assert playback['modes']['melody']['count'] > 0
        assert playback['modes']['light_easy']['count'] >= playback['modes']['melody']['count']
        assert playback['modes']['light_standard']['count'] >= playback['modes']['light_easy']['count']
        assert playback['modes']['light_full']['count'] >= playback['modes']['light_standard']['count']
        expected_count = [playback['modes'][m]['count'] for m in ('melody','light_easy','light_standard','light_full','full')]
        xmls = []
        for mode in ('melody', 'light_easy', 'light_standard', 'light_full', 'full'):
            response = client.get(f'/api/jobs/{job_id}/playback-score/{mode}')
            assert response.status_code == 200, response.text[:400]
            assert b'score-partwise' in response.content
            root = ET.fromstring(response.content)
            assert len(root.findall('part')) == 1
            staves = root.find('.//attributes/staves')
            if mode == 'melody':
                assert staves is None
            else:
                assert staves is not None and staves.text == '2'
                assert any(n.findtext('staff') == '2' for n in root.findall('.//note'))
            assert 'Piano sheet &lt;demo&gt;' in response.text
            assert sum(count_onsets(response.content)) <= playback['modes'][mode]['count']
            xmls.append(response.content)
        assert len(set(xmls)) == 5
        assert client.get(f'/api/jobs/{job_id}/playback-score/wrong').status_code == 400
        assert client.get(f'/api/jobs/{job_id}/playback-score/light').content == xmls[2]
    finally:
        job_store.delete(job_id)


def test_reference_midi_changes_c_score_but_not_a_or_b():
    job_id = fixture_job()
    try:
        original = {m: client.get(f'/api/jobs/{job_id}/playback-score/{m}').content for m in ('melody','light_easy','light_standard','light_full','full')}
        midi = pretty_midi.PrettyMIDI()
        instrument = pretty_midi.Instrument(program=0)
        instrument.notes.append(pretty_midi.Note(pitch=75,velocity=88,start=0.2,end=1.2))
        midi.instruments.append(instrument)
        stream = io.BytesIO()
        midi.write(stream)
        response = client.post(f'/api/jobs/{job_id}/reference-midi', files={'midi_file':('other.mid',stream.getvalue(),'audio/midi')})
        assert response.status_code == 200, response.text
        assert client.get(f'/api/jobs/{job_id}/playback-score/full').content != original['full']
        assert client.get(f'/api/jobs/{job_id}/playback-score/melody').content == original['melody']
        assert client.get(f'/api/jobs/{job_id}/playback-score/light_easy').content == original['light_easy']
        assert client.get(f'/api/jobs/{job_id}/playback-score/light_standard').content == original['light_standard']
        assert client.get(f'/api/jobs/{job_id}/playback-score/light_full').content == original['light_full']
        assert client.delete(f'/api/jobs/{job_id}/reference-midi').status_code == 204
        assert client.get(f'/api/jobs/{job_id}/playback-score/full').content == original['full']
    finally:
        job_store.delete(job_id)


def test_no_new_installation_required_and_duration_within_bars():
    notes = [
        {'start': .4, 'end': 4.7, 'pitch': 73, 'velocity': 90},
        {'start': .4, 'end': .7, 'pitch': 52, 'velocity': 73, 'staff': 'lower'},
        {'start': 3.5, 'end': 4.2, 'pitch': 76, 'velocity': 70},
    ]
    xml = create_arrangement_xml(notes, 'light', 'Demo', 120, '3/4', 16, 60, 5.2)
    root = ET.fromstring(xml)
    assert len(root.findall('part')) == 1
    assert root.findtext('.//attributes/staves') == '2'
    assert len(root.findall('part')[0].findall('measure')) >= 4
    assert any(n.find('tie') is not None for n in root.findall('.//note'))
    for measure in root.findall('.//measure'):
        for element in measure.findall('note'):
            assert element.find('duration') is not None
    response = client.get('/api/health')
    assert response.status_code == 200
    assert response.json()['dynamic_musicxml'] is True
    assert response.json()['sampled_piano_expected'] == 30


def test_selected_pdf_endpoint(monkeypatch):
    job_id = fixture_job()
    try:
        def fake_export(xml_path, pdf_path):
            from reportlab.pdfgen import canvas
            doc = canvas.Canvas(str(pdf_path))
            doc.drawString(72, 760, xml_path.stem)
            doc.save()
            return 'test-renderer'

        monkeypatch.setattr('app.main.export_musicxml_to_pdf', fake_export)
        response = client.get(f'/api/jobs/{job_id}/playback-pdf/light')
        assert response.status_code == 200, response.text
        assert response.headers['content-type'].startswith('application/pdf')
        assert response.content.startswith(b'%PDF')
        assert client.get(f'/api/jobs/{job_id}/playback-pdf/wrong').status_code == 400
    finally:
        job_store.delete(job_id)


def test_extended_chords_slash_bass_triplets_and_system_breaks():
    notes = []
    # Create enough measures to verify the requested four-bars-per-system layout.
    for bar in range(9):
        start = bar * 2.4
        notes.extend([
            {'start': start, 'end': start + .5, 'pitch': 69, 'velocity': 90, 'staff': 'upper'},
            {'start': start, 'end': start + .4, 'pitch': 45, 'velocity': 60, 'staff': 'lower'},
        ])
    # 1/8-triplet duration at 120 BPM -> 160 MusicXML ticks.
    notes.append({'start': 0.0, 'end': 1/6, 'pitch': 73, 'velocity': 72, 'staff': 'upper'})
    xml = create_arrangement_xml(
        notes, 'light_full', 'Arrangement test', 120, '4/4', 16, 60, 22,
        key_fifths=3,
        chords=[{'start': 0, 'end': 2.4, 'root': 6, 'quality': 'minor7', 'bass_pc': 9, 'name': 'F#m7/A'}],
    )
    root = ET.fromstring(xml)
    kind = root.find('.//harmony/kind')
    assert kind is not None and kind.text == 'minor-seventh'
    assert root.findtext('.//harmony/bass/bass-step') == 'A'
    assert root.find('.//time-modification') is not None
    measures = root.findall('.//part/measure')
    assert measures[4].find('print').get('new-system') == 'yes'
    assert measures[8].find('print').get('new-system') == 'yes'
