"""Regression tests for the optional native Windows CPU SheetSage2 path.

These tests do not download model weights and do not imply real Windows
Server 2019 inference has been validated.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import sys

import pytest
from fastapi.testclient import TestClient

from app import ai_engines, main


def fake_windows_env(tmp_path: Path, monkeypatch, *, complete: bool = True) -> Path:
    monkeypatch.setattr(ai_engines, "ROOT_DIR", tmp_path)
    monkeypatch.setattr(ai_engines, "_is_windows", lambda: True)
    monkeypatch.setattr(ai_engines.shutil, "which", lambda cmd: None)
    env = tmp_path / ".sheetsage2-venv"
    python = env / "Scripts" / "python.exe"
    python.parent.mkdir(parents=True)
    python.write_bytes(b"fake executable")
    (env / "pyvenv.cfg").write_text("home=Python311", encoding="utf-8")
    if complete:
        (env / ai_engines.NATIVE_INSTALL_MARKER).write_text(
            json.dumps({"engine": "sheetsage2", "complete": True}), encoding="utf-8")
    return env


def test_server2019_native_ready_without_wsl2(tmp_path, monkeypatch):
    env = fake_windows_env(tmp_path, monkeypatch)
    status = ai_engines.available_engines()
    assert status["sheetsage2"]["installed"] is True
    assert status["sheetsage2"]["requires_wsl_on_windows"] is False
    assert status["sheetsage2"]["runtime"] == "native_windows_cpu"
    assert status["sheetsage2"]["model_downloaded"] == "unknown"
    assert status["pop2piano"]["installed"] is False
    audio = tmp_path / "source audio.wav"
    out = tmp_path / "output folder"
    cmd = ai_engines._execution_command("sheetsage2", audio, out)
    assert cmd[0] == str(env / "Scripts" / "python.exe")
    assert cmd[1] == "-I"
    assert "ai_external_worker.py" in cmd[2]
    assert cmd[3] == "sheetsage2"
    assert cmd[4] == str(audio.resolve())
    assert cmd[5] == str(out.resolve())
    assert not any("wsl" in token.lower() for token in cmd)


def test_windows_cannot_use_incomplete_venv(tmp_path, monkeypatch):
    fake_windows_env(tmp_path, monkeypatch, complete=False)
    assert ai_engines.available_engines()["sheetsage2"]["installed"] is False
    with pytest.raises(ai_engines.AIEngineError, match="CAI_SHEETSAGE2_WINDOWS"):
        ai_engines._execution_command("sheetsage2", tmp_path / "source.wav", tmp_path / "output")


def test_native_model_runner_validates_real_output_files(tmp_path, monkeypatch):
    env = fake_windows_env(tmp_path, monkeypatch)
    audio = tmp_path / "audio.wav"
    audio.write_bytes(b"RIFFstub")
    out = tmp_path / "job" / "sheetsage2"
    called = []

    def fake_run(command, **kwargs):
        called.append(command)
        out.mkdir(parents=True, exist_ok=True)
        (out / "melody_vocal.mid").write_bytes(b"MThd" + b"\0" * 14)
        (out / "result.json").write_text(json.dumps({
            "engine": "sheetsage2", "model": "m-a-p/SheetSage2",
            "midi_files": ["melody_vocal.mid"], "device": "cpu",
        }), encoding="utf-8")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(ai_engines.subprocess, "run", fake_run)
    metadata = ai_engines.run_advanced_engine("sheetsage2", audio, out)
    assert metadata["device"] == "cpu"
    assert called[0][0] == str(env / "Scripts" / "python.exe")
    assert (out / "model.log").is_file()


def test_missing_midi_is_rejected(tmp_path, monkeypatch):
    fake_windows_env(tmp_path, monkeypatch)
    audio = tmp_path / "audio.wav"
    audio.write_bytes(b"RIFFstub")
    out = tmp_path / "out"

    def fake_run(command, **kwargs):
        (out / "result.json").write_text(json.dumps({"engine": "sheetsage2", "midi_files": ["chords.mid"]}))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(ai_engines.subprocess, "run", fake_run)
    with pytest.raises(ai_engines.AIEngineError, match="missing expected MIDI"):
        ai_engines.run_advanced_engine("sheetsage2", audio, out)


def test_http_error_guides_windows_user_to_native_installer(monkeypatch):
    client = TestClient(main.app)
    monkeypatch.setattr(main, "available_engines", lambda: {
        "sheetsage2": {"installed": False}, "pop2piano": {"installed": False},
    })
    monkeypatch.setattr(main, "sys", SimpleNamespace(platform="win32"))
    response = client.post("/api/jobs", data={
        "youtube_url": "https://www.youtube.com/watch?v=abc12345678",
        "accepted_rights": "true", "melody_engine": "sheetsage2",
        "research_noncommercial": "true",
    })
    assert response.status_code == 503
    assert "CAI_SHEETSAGE2_WINDOWS.bat" in response.json()["detail"]
    assert "WSL2" in response.json()["detail"]


def test_worker_uses_cpu_and_exports_with_fake_model(tmp_path, monkeypatch):
    path = Path(__file__).resolve().parents[1] / "scripts" / "ai_external_worker.py"
    spec = importlib.util.spec_from_file_location("ai_external_worker_test", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    monkeypatch.setattr(module, "_is_windows_native", lambda: True)
    monkeypatch.setenv("SHEETSAGE2_CPU_THREADS", "6")
    calls = []

    class DummyModel:
        def eval(self):
            calls.append("eval")
            return self

        def to(self, device):
            calls.append(("to", device))
            return self

        def transcribe(self, audio, output_dir):
            calls.append(("transcribe", audio))
            Path(output_dir, "melody_vocal.mid").write_bytes(b"MThd")

    class DummyAutoModel:
        @staticmethod
        def from_pretrained(repo, trust_remote_code):
            calls.append(("load", repo, trust_remote_code))
            return DummyModel()

    dummy_torch = SimpleNamespace(set_num_threads=lambda n: calls.append(("threads", n)))
    dummy_transformers = SimpleNamespace(AutoModel=DummyAutoModel)
    monkeypatch.setitem(sys.modules, "torch", dummy_torch)
    monkeypatch.setitem(sys.modules, "transformers", dummy_transformers)
    audio = tmp_path / "audio.wav"
    audio.write_bytes(b"RIFFstub")
    meta = module._sheetsage2(audio, tmp_path)
    assert meta["runtime"] == "native_windows_cpu"
    assert meta["device"] == "cpu"
    assert ("threads", 6) in calls
    assert ("to", "cpu") in calls
    assert ("load", "m-a-p/SheetSage2", True) in calls
    assert ("transcribe", str(audio)) in calls


def test_bat_installer_and_cpu_pins_present():
    base = Path(__file__).resolve().parents[1]
    source = (base / "CAI_AI_NANG_CAO.bat").read_text(encoding="utf-8")
    assert "CAI_SHEETSAGE2_WINDOWS.bat" in source
    bat = (base / "CAI_SHEETSAGE2_WINDOWS.bat").read_text(encoding="utf-8")
    assert "install_sheetsage2_windows.py" in bat
    req = (base / "scripts" / "requirements_sheetsage2_windows.txt").read_text()
    assert "transformers==4.45.2" in req
    assert "huggingface-hub==0.36.0" in req
    assert "numpy==1.24.3" in req
    installer = (base / "scripts" / "install_sheetsage2_windows.py").read_text()
    assert "torch==2.8.0+cpu" in installer
    assert "torchaudio==2.8.0+cpu" in installer


def _load_native_installer():
    installer = Path(__file__).resolve().parents[1] / "scripts" / "install_sheetsage2_windows.py"
    spec = importlib.util.spec_from_file_location("sheetsage2_installer_test", installer)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_native_installer_stamps_success_only_after_diagnostics(tmp_path, monkeypatch):
    installer = _load_native_installer()
    venv = tmp_path / ".sheetsage2-venv"
    python = venv / "Scripts" / "python.exe"
    marker = venv / installer.MARKER.name
    monkeypatch.setattr(installer, "PROJECT", tmp_path)
    monkeypatch.setattr(installer, "VENV", venv)
    monkeypatch.setattr(installer, "PYTHON", python)
    monkeypatch.setattr(installer, "MARKER", marker)
    monkeypatch.setattr(installer, "LOG", tmp_path / "logs" / "install.log")
    monkeypatch.setattr(installer, "sys", SimpleNamespace(
        platform="win32", version_info=(3, 11), maxsize=2**63 - 1, executable="C:/Python311/python.exe"))
    monkeypatch.setattr(installer.shutil, "which", lambda app: "C:/ffmpeg/bin/ffmpeg.exe")
    recorded = []

    def fake_run(argv, logfile):
        recorded.append(list(argv))
        if argv[:3] == ["C:/Python311/python.exe", "-m", "venv"]:
            python.parent.mkdir(parents=True)
            python.write_bytes(b"mock")
        if len(argv) >= 2 and argv[1].endswith("check_sheetsage2_windows.py"):
            assert not marker.is_file()

    monkeypatch.setattr(installer, "_run", fake_run)
    assert installer.main() == 0
    assert marker.is_file()
    state = json.loads(marker.read_text())
    assert state["complete"] is True
    assert state["runtime"] == "native_windows_cpu"
    assert state["weights_downloaded"] is False
    assert any("torch==2.8.0+cpu" in cmd for cmd in recorded)
    assert any("torchaudio==2.8.0+cpu" in cmd for cmd in recorded)
    assert any("requirements_sheetsage2_windows.txt" in " ".join(cmd) for cmd in recorded)
    assert not (tmp_path / ".venv").exists()
    assert not (tmp_path / ".demucs-venv").exists()


def test_native_installer_failure_clears_stale_success_stamp(tmp_path, monkeypatch):
    installer = _load_native_installer()
    venv = tmp_path / ".sheetsage2-venv"
    python = venv / "Scripts" / "python.exe"
    python.parent.mkdir(parents=True)
    python.write_bytes(b"mock")
    marker = venv / installer.MARKER.name
    marker.write_text('{"engine":"sheetsage2","complete":true}')
    monkeypatch.setattr(installer, "PROJECT", tmp_path)
    monkeypatch.setattr(installer, "VENV", venv)
    monkeypatch.setattr(installer, "PYTHON", python)
    monkeypatch.setattr(installer, "MARKER", marker)
    monkeypatch.setattr(installer, "LOG", tmp_path / "logs" / "install.log")
    monkeypatch.setattr(installer, "sys", SimpleNamespace(
        platform="win32", version_info=(3, 11), maxsize=2**63 - 1, executable="C:/Python311/python.exe"))
    monkeypatch.setattr(installer.shutil, "which", lambda app: "C:/ffmpeg/bin/ffmpeg.exe")

    def failed_install(argv, logfile):
        assert not marker.is_file()
        raise RuntimeError("mock dependency failed")

    monkeypatch.setattr(installer, "_run", failed_install)
    assert installer.main() == 1
    assert not marker.exists()
