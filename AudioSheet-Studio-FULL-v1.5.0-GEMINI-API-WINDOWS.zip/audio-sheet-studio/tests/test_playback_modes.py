import json
from pathlib import Path

import pretty_midi

from app.playback_modes import clean_notes, merge_fragments, prepare_stem_variants, prepare_variants, write_mode_midi


def test_unsorted_notes_and_three_independent_modes() -> None:
    raw = [
        {"start": 2.0, "end": 2.4, "pitch": 69, "velocity": 88},
        {"start": 0.0, "end": 0.25, "pitch": 68, "velocity": 80},
        {"start": 0.25, "end": 0.5, "pitch": 68, "velocity": 83},
        {"start": 0.9, "end": 1.5, "pitch": 44, "velocity": 70},
        {"start": 1.1, "end": 1.35, "pitch": 69, "velocity": 90},
    ]
    result = prepare_variants(raw)
    assert {'melody', 'light_easy', 'light_standard', 'light_full', 'light', 'full'} <= set(result['modes'])
    assert result['raw_count'] == 5
    assert result['merged_count'] == 4
    assert result['reference_active'] is False
    assert result['modes']['full']['count'] == 5
    assert result['modes']['melody']['count'] <= result['modes']['light_easy']['count']
    assert result['modes']['light_easy']['count'] <= result['modes']['light_standard']['count']
    assert result['modes']['light_standard']['count'] <= result['modes']['light_full']['count']
    assert result['modes']['light']['notes'] == result['modes']['light_standard']['notes']
    assert result['modes']['light_full']['notes'] != result['modes']['full']['notes']
    assert [n['start'] for n in result['modes']['full']['notes']] == sorted(n['start'] for n in result['modes']['full']['notes'])
    assert all('score_start_q' in n and 'score_end_q' in n for n in result['modes']['full']['notes'])


def test_fragment_merge_preserves_distinct_repeated_hits() -> None:
    source = clean_notes([
        {'start': 0, 'end': .2, 'pitch': 68, 'velocity': 81},
        {'start': .2, 'end': .4, 'pitch': 68, 'velocity': 82},
        {'start': .52, 'end': .72, 'pitch': 68, 'velocity': 83},
        {'start': .72, 'end': .9, 'pitch': 68, 'velocity': 122},
    ])
    joined = merge_fragments(source)
    assert len(joined) == 3
    assert joined[0]['end'] == .4


def test_invalid_notes_cannot_crash_server() -> None:
    result = prepare_variants([
        {'start': 0, 'end': 1, 'pitch': 60, 'velocity': 80},
        {'start': -1, 'end': .2, 'pitch': 60, 'velocity': 80},
        {'start': 'NaN', 'end': 2, 'pitch': 60, 'velocity': 80},
        {'start': 0, 'end': 1, 'pitch': 300, 'velocity': 80},
        {'bad': 2},
    ])
    assert result['raw_count'] == 1
    assert result['modes']['full']['count'] == 1
    assert json.dumps(result, allow_nan=False)


def test_reference_changes_only_full_mode() -> None:
    original = [{'start': 1, 'end': 1.5, 'pitch': 68, 'velocity': 85},
                {'start': 2, 'end': 2.5, 'pitch': 45, 'velocity': 60}]
    reference = [{'start': 0.9, 'end': 2.1, 'pitch': 81, 'velocity': 70}]
    before = prepare_variants(original)
    after = prepare_variants(original, reference)
    assert after['reference_active'] is True
    assert after['modes']['full']['notes'][0]['pitch'] == 81
    assert before['modes']['melody'] == after['modes']['melody']
    assert before['modes']['light_standard'] == after['modes']['light_standard']
    assert before['modes']['light_full'] == after['modes']['light_full']


def test_export_each_midi(tmp_path: Path) -> None:
    raw = [
        {'start': .1, 'end': .6, 'pitch': 64, 'velocity': 70},
        {'start': .2, 'end': .7, 'pitch': 45, 'velocity': 60},
        {'start': 1.0, 'end': 1.8, 'pitch': 68, 'velocity': 99},
    ]
    variants = prepare_variants(raw)['modes']
    for mode, data in variants.items():
        path = tmp_path / f'{mode}.mid'
        write_mode_midi(data['notes'], str(path), bpm=100)
        midi = pretty_midi.PrettyMIDI(str(path))
        assert sum(len(instrument.notes) for instrument in midi.instruments) == data['count']


def test_real_stem_pipelines_keep_sources_separate() -> None:
    vocals = [
        {'start': 0.0, 'end': .45, 'pitch': 68, 'velocity': 90, 'confidence': .9},
        {'start': .5, 'end': 1.0, 'pitch': 69, 'velocity': 88, 'confidence': .88},
    ]
    bass = [
        {'start': 0.0, 'end': 1.0, 'pitch': 42, 'velocity': 76, 'confidence': .76},
    ]
    other = [
        {'start': 0.0, 'end': 1.0, 'pitch': 54, 'velocity': 72, 'confidence': .72},
        {'start': 0.0, 'end': 1.0, 'pitch': 61, 'velocity': 68, 'confidence': .68},
    ]
    result = prepare_stem_variants(
        vocals, bass, other, bpm=100, time_signature='4/4', duration_seconds=2.0
    )
    assert result['pipeline'] == 'stem_separated'
    assert all(note.get('source') == 'vocals' for note in result['modes']['melody']['notes'])
    assert any(note.get('staff') == 'lower' for note in result['modes']['light_standard']['notes'])
    assert any(note.get('role') == 'lh_arpeggio' for note in result['modes']['light_full']['notes'])
    assert result['modes']['light']['notes'] == result['modes']['light_standard']['notes']
    assert any(note.get('source') in {'bass', 'other'} for note in result['modes']['full']['notes'])
    assert result['analysis']['key']['name']


def test_chord_timeline_supports_sevenths_and_slash_bass() -> None:
    from app.playback_modes import infer_chord_timeline

    # F#-A-C#-E with A in the bass -> F#m7/A.
    harmony = [
        {'start': 0, 'end': 2.4, 'pitch': pitch, 'velocity': 82}
        for pitch in (54, 57, 61, 64)
    ]
    bass = [{'start': 0, 'end': 2.4, 'pitch': 45, 'velocity': 96}]
    result = infer_chord_timeline(
        harmony, bass, 100, '4/4', 2.4, {'tonic': 6, 'mode': 'minor'}
    )
    assert result
    assert result[0]['root'] == 6
    assert result[0]['quality'] == 'minor7'
    assert result[0]['bass_pc'] == 9
    assert result[0]['name'] == 'F#m7/A'


def test_three_b_arrangement_levels_increase_detail() -> None:
    vocals = [
        {'start': 0.0, 'end': .45, 'pitch': 68, 'velocity': 92},
        {'start': .55, 'end': 1.05, 'pitch': 69, 'velocity': 90},
        {'start': 1.2, 'end': 1.8, 'pitch': 73, 'velocity': 88},
    ]
    bass = [{'start': 0, 'end': 2.4, 'pitch': 42, 'velocity': 82}]
    other = [
        {'start': 0, 'end': 2.4, 'pitch': pitch, 'velocity': 72}
        for pitch in (54, 57, 61, 64)
    ]
    result = prepare_stem_variants(
        vocals, bass, other, bpm=100, time_signature='4/4', duration_seconds=2.4
    )
    easy = result['modes']['light_easy']['notes']
    standard = result['modes']['light_standard']['notes']
    rich = result['modes']['light_full']['notes']
    assert len(easy) < len(standard) < len(rich)
    assert any(note.get('role') == 'rh_voicing' for note in standard)
    assert any(note.get('role') == 'lh_arpeggio' for note in rich)
    assert result['modes']['light']['notes'] == standard
