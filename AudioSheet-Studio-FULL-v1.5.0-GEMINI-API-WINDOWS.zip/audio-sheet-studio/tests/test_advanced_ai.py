from __future__ import annotations

import copy
import json
from pathlib import Path

import pretty_midi
from fastapi.testclient import TestClient

from app import ai_arrangements, ai_engines, main, processor
from app.job_store import job_store
from app.rhythm_grid import constant_rhythm_map


def write_midi(path: Path, pitches: list[tuple[int, float, float]]) -> None:
    midi = pretty_midi.PrettyMIDI(initial_tempo=100)
    inst = pretty_midi.Instrument(program=0)
    for pitch, start, end in pitches:
        inst.notes.append(pretty_midi.Note(pitch=pitch, velocity=95, start=start, end=end))
    midi.instruments.append(inst)
    midi.write(str(path))


def example_midi(path: Path) -> None:
    pitches = []
    for i in range(8):
        t = 0.48 * i
        pitches.extend([(42, t, t + .39), (66, t, t + .39), (69, t, t + .39), (73, t, t + .39), (78, t, t + .39)])
    write_midi(path, pitches)


def test_pop2piano_midi_drives_three_distinct_b_tiers(tmp_path):
    mid = tmp_path / 'pop2piano.mid'
    example_midi(mid)
    payload = {'source': 'Classic', 'modes': {'melody': {'notes': []}, 'full': {'notes': []}}}
    result = ai_arrangements.apply_pop2piano(copy.deepcopy(payload), mid, duration=4.0)
    counts = [result['modes'][k]['count'] for k in ('light_easy', 'light_standard', 'light_full')]
    assert counts[0] < counts[1] < counts[2], counts
    assert all(n['source'] == 'pop2piano' for n in result['modes']['light_full']['notes'])
    assert result['modes']['light_standard']['notes'] == result['modes']['light']['notes']
    assert result['modes']['melody']['notes'] == []


def test_sheetsage2_midi_updates_a_and_chords_without_touching_c(tmp_path):
    vocal_notes = [(68 + (n % 3), n * .55, n * .55 + .40) for n in range(6)]
    write_midi(tmp_path / 'melody_vocal.mid', vocal_notes)
    write_midi(tmp_path / 'chords.mid', [(61, n * .55, n * .55 + .50) for n in range(6)])
    rhythm = constant_rhythm_map(4.0, 100, '4/4')
    full = [dict(start=.55 * i, end=.55 * i + .45, pitch=45 + i % 2, velocity=90,
                 source='bass', role='bass') for i in range(7)]
    payload = {'source': 'Classic', 'modes': {'melody': {'notes': []}, 'full': {'notes': full}}, 'analysis': {'chords': []}}
    result = ai_arrangements.apply_sheetsage2(copy.deepcopy(payload), tmp_path,
                                              duration=4, bpm=100, time_signature='4/4',
                                              quantization=16, rhythm=rhythm)
    assert result['modes']['melody']['count'] == 6
    assert result['modes']['melody']['notes'][0]['source'] == 'sheetsage2_vocal'
    assert result['modes']['full']['notes'] == full
    assert isinstance(result['analysis']['chords'], list)
    assert result['modes']['light_standard']['count'] > 0


def test_model_runner_requires_isolated_environment(tmp_path, monkeypatch):
    monkeypatch.setattr(ai_engines, '_venv_marker', lambda engine: tmp_path / 'absent.cfg')
    audio = tmp_path / 'input.wav'
    audio.write_bytes(b'fixture')
    try:
        ai_engines.run_advanced_engine('pop2piano', audio, tmp_path / 'output')
    except ai_engines.AIEngineError as exc:
        assert 'CAI_AI_NANG_CAO.bat' in str(exc)
    else:
        assert False, 'should reject missing model environment'


def test_invalid_ai_selection_is_rejected_without_starting_any_job(monkeypatch):
    client = TestClient(main.app)
    result = client.post('/api/jobs', data={'youtube_url': 'https://www.youtube.com/watch?v=abc12345678',
                                          'accepted_rights': 'true', 'melody_engine': 'sheetsage2'})
    assert result.status_code == 400
    assert 'non-commercial' in result.json()['detail']
    result = client.post('/api/jobs', data={'youtube_url': 'https://www.youtube.com/watch?v=abc12345678',
                                          'accepted_rights': 'true', 'piano_engine': 'injected'})
    assert result.status_code == 400
    result = client.get('/api/health')
    assert result.status_code == 200
    assert 'pop2piano' in result.json()['advanced_ai']


def test_models_really_replace_a_and_b_through_job_pipeline(tmp_path, monkeypatch):
    from reportlab.pdfgen import canvas

    job = job_store.create({
        'source_type': 'upload', 'source_filename': 'source.wav', 'source_name': 'Fixture',
        'title': 'Advanced test', 'mode': 'piano', 'bpm_requested': 100,
        'time_signature': '4/4', 'quantization': 16, 'split_pitch': 60,
        'minimum_midi': 36, 'maximum_midi': 96, 'onset_threshold': .5,
        'frame_threshold': .3, 'minimum_note_length_ms': 120,
        'separate_stems': False, 'melody_engine': 'sheetsage2', 'piano_engine': 'pop2piano',
    })
    directory = job_store.job_dir(job['id'])
    (directory / 'source.wav').write_bytes(b'fake')

    def fake_normalize(source, dest, limit):
        dest.write_bytes(b'normalized')
        return 4.0

    def fake_transcribe(**kwargs):
        return [dict(start=i * .55, end=i * .55 + .4, pitch=62 + i % 4,
                     velocity=85, source='full_mix') for i in range(7)]

    def fake_model(engine, audio_path, output_dir, timeout_seconds):
        output_dir.mkdir(parents=True, exist_ok=True)
        if engine == 'sheetsage2':
            write_midi(output_dir / 'melody_vocal.mid', [(70 + i % 2, i * .5, i * .5 + .4) for i in range(7)])
            write_midi(output_dir / 'chords.mid', [(61, i * .5, i * .5 + .4) for i in range(7)])
            return {'model': 'm-a-p/SheetSage2'}
        if engine == 'pop2piano':
            example_midi(output_dir / 'pop2piano.mid')
            return {'model': 'sweetcocoa/pop2piano', 'composer': 'composer1'}
        raise AssertionError(engine)

    def fake_pdf(xml, destination):
        pdf = canvas.Canvas(str(destination))
        pdf.drawString(72, 760, 'AI Integration Test')
        pdf.save()
        return 'mock'

    monkeypatch.setattr(processor, 'normalize_audio', fake_normalize)
    monkeypatch.setattr(processor, 'analyze_rhythm', lambda *args, **kwargs: constant_rhythm_map(4., 100, '4/4'))
    monkeypatch.setattr(processor, '_transcribe_stem', fake_transcribe)
    monkeypatch.setattr(processor, 'run_advanced_engine', fake_model)
    monkeypatch.setattr(processor, 'export_musicxml_to_pdf', fake_pdf)
    monkeypatch.setattr(processor, 'pdf_engine_status', lambda: {'available': True, 'preferred': 'mock'})
    try:
        processor._process_job(job['id'])
        finished = job_store.get(job['id'])
        assert finished['status'] == 'done', finished.get('error')
        assert finished['ai_engines']['melody']['used'] == 'sheetsage2'
        assert finished['ai_engines']['piano']['used'] == 'pop2piano'
        data = json.loads((directory / 'arrangements.json').read_text(encoding='utf8'))
        assert data['modes']['melody']['notes'][0]['source'] == 'sheetsage2_vocal'
        assert data['modes']['light_standard']['notes'][0]['source'] == 'pop2piano'
        assert data['modes']['full']['notes'][0]['source'] != 'pop2piano'
        assert (directory / 'sheet_B_light_full.pdf').is_file()
        assert (directory / 'sheet_B_light_full.mid').is_file()
        assert 'advanced_ai' in json.loads((directory / 'pipeline_manifest.json').read_text(encoding='utf8'))
    finally:
        job_store.delete(job['id'])
