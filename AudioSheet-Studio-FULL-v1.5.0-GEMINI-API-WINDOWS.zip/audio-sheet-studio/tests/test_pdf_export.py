from __future__ import annotations

from pathlib import Path

import pytest

from app import pdf_export
from app.live_score import create_arrangement_xml


def sample_xml() -> bytes:
    return create_arrangement_xml(
        [
            {"start": 0, "end": 0.8, "pitch": 60, "velocity": 80, "staff": "upper"},
            {"start": 0, "end": 1.2, "pitch": 43, "velocity": 68, "staff": "lower"},
        ],
        "light",
        "PDF demo",
        100,
        "4/4",
        16,
        60,
        2.0,
    )


def assert_pdf(path: Path) -> None:
    data = path.read_bytes()
    assert data.startswith(b"%PDF-")
    assert b"%%EOF" in data[-2048:]
    assert path.stat().st_size > 900


def _write_test_pdf(path: Path) -> None:
    from reportlab.pdfgen import canvas

    pdf = canvas.Canvas(str(path))
    pdf.drawString(72, 760, "OSMD browser PDF test")
    pdf.save()


def test_browser_osmd_is_preferred(monkeypatch, tmp_path: Path) -> None:
    def fake_browser(_source: Path, output: Path) -> bool:
        _write_test_pdf(output)
        return True

    monkeypatch.setattr(pdf_export, "export_with_browser_osmd", fake_browser)
    monkeypatch.setattr(pdf_export, "find_musescore", lambda: None)
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(sample_xml())
    pdf_path = tmp_path / "score.pdf"
    engine = pdf_export.export_musicxml_to_pdf(xml_path, pdf_path)
    assert engine == "browser_osmd"
    assert_pdf(pdf_path)


def test_reportlab_fallback_uses_real_musicxml(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(pdf_export, "export_with_browser_osmd", lambda *_args, **_kwargs: False)
    monkeypatch.setattr(pdf_export, "find_musescore", lambda: None)
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(sample_xml())
    pdf_path = tmp_path / "score.pdf"
    engine = pdf_export.export_musicxml_to_pdf(xml_path, pdf_path)
    assert engine == "reportlab"
    assert_pdf(pdf_path)


def test_exact_web_pdf_rejects_approximate_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(pdf_export, "export_with_browser_osmd", lambda *_args, **_kwargs: False)
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(sample_xml())
    with pytest.raises(pdf_export.PDFExportError, match="exact web-layout"):
        pdf_export.export_musicxml_to_pdf(
            xml_path,
            tmp_path / "score.pdf",
            require_web_fidelity=True,
        )
