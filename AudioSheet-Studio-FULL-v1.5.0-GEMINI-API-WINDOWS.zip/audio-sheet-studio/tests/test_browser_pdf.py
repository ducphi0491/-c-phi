from pathlib import Path

from app.browser_pdf import _build_print_html
from app.live_score import create_arrangement_xml


def test_print_html_uses_osmd_a4_and_embeds_musicxml(tmp_path: Path) -> None:
    xml_path = tmp_path / "score.musicxml"
    xml_path.write_bytes(
        create_arrangement_xml(
            [{"start": 0, "end": 1, "pitch": 60, "velocity": 80, "staff": "upper"}],
            "melody",
            "PDF web fidelity",
            100,
            "4/4",
            16,
            60,
            1.5,
        )
    )
    osmd = tmp_path / "opensheetmusicdisplay.min.js"
    osmd.write_text("window.opensheetmusicdisplay={};", encoding="utf-8")
    html_path = tmp_path / "score.html"
    _build_print_html(xml_path, html_path, osmd)
    output = html_path.read_text(encoding="utf-8")
    assert "pageFormat: 'A4_P'" in output
    assert "drawingParameters: 'compacttight'" in output
    assert osmd.resolve().as_uri() in output
    assert "score-partwise" not in output  # MusicXML is base64-embedded, not HTML-injected.
    assert "__AUDIOSHEET_PDF_READY__" in output
