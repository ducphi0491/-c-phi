from __future__ import annotations

import math

import mido

from app.live_score import create_arrangement_xml
from app.playback_modes import write_mode_midi
from app.rhythm_grid import (
    build_rhythm_map,
    quarter_to_time,
    quantize_notes_to_rhythm,
    time_to_quarter,
)


def reference_like_grid(duration: float = 283.05):
    # Pickup: pulse at .15, first full downbeat at .75, 100 BPM.
    beats = []
    value = .15
    while value <= duration + 3:
        beats.append(round(value, 6))
        value += .6
    downbeats = []
    # Full 4/4 bars from .75, then one 2/4 bar near the ending.
    value = .75
    while value < 276.75 - .01:
        downbeats.append(round(value, 6))
        value += 2.4
    # Align the synthetic ending to explicit downbeats for 2/4 -> 4/4.
    downbeats.extend([276.75, 277.95, 280.35, 282.75])
    return build_rhythm_map(
        beats=beats,
        downbeats=downbeats,
        duration_seconds=duration,
        time_signature="4/4",
        engine="test-reference",
        confidence=.99,
        first_onset_time=0.0,
        bpm_hint=100,
    )


def test_pickup_meter_map_and_roundtrip():
    rhythm = reference_like_grid()
    assert rhythm["pickup"]["present"] is True
    assert math.isclose(rhythm["pickup"]["quarter_length"], 1.25, abs_tol=.01)
    assert math.isclose(rhythm["first_full_measure_start"], .75, abs_tol=.01)
    meters = [(item["beats"], item["beat_type"]) for item in rhythm["meter_changes"]]
    assert (2, 4) in meters
    two_index = meters.index((2, 4))
    assert (4, 4) in meters[two_index + 1:]
    for time in (0, .15, .75, 15.2, 140.0, 277.2, 282.5):
        assert math.isclose(quarter_to_time(rhythm, time_to_quarter(rhythm, time), 100), time, abs_tol=.03)


def test_quantization_uses_local_grid_and_preserves_score_positions():
    rhythm = reference_like_grid(20)
    notes = [
        {"start": .77, "end": 1.34, "pitch": 66, "velocity": 80},
        {"start": 1.36, "end": 1.78, "pitch": 68, "velocity": 85},
    ]
    out = quantize_notes_to_rhythm(notes, rhythm, bpm=100, quantization=16)
    assert len(out) == 2
    assert out[0]["score_start_q"] == 1.25
    assert out[0]["score_end_q"] > out[0]["score_start_q"]
    assert out[0]["start"] == .75


def test_midi_and_musicxml_share_pickup_and_meter_map(tmp_path):
    rhythm = reference_like_grid()
    notes = [
        {"start": .15, "end": .7, "pitch": 68, "velocity": 85, "staff": "upper"},
        {"start": .75, "end": 1.35, "pitch": 66, "velocity": 86, "staff": "upper"},
        {"start": .75, "end": 1.95, "pitch": 42, "velocity": 60, "staff": "lower"},
        {"start": 277.95, "end": 278.55, "pitch": 69, "velocity": 82, "staff": "upper"},
    ]
    quantized = quantize_notes_to_rhythm(notes, rhythm, bpm=100, quantization=16)
    midi_path = tmp_path / "rhythm.mid"
    write_mode_midi(quantized, str(midi_path), bpm=100, rhythm_map=rhythm)
    midi = mido.MidiFile(midi_path)
    signatures = []
    for track in midi.tracks:
        tick = 0
        for message in track:
            tick += message.time
            if message.type == "time_signature":
                signatures.append((tick, message.numerator, message.denominator))
    assert any(num == 2 and den == 4 for _, num, den in signatures)
    assert any(num == 4 and den == 4 for _, num, den in signatures)

    xml = create_arrangement_xml(
        quantized, "light_standard", "Rhythm test", 100, "4/4", 16, 60,
        283.05, key_fifths=3, chords=[], rhythm_map=rhythm,
    ).decode("utf-8")
    assert '<measure number="0" implicit="yes">' in xml
    assert "<beats>2</beats>" in xml
    assert xml.count('new-system="yes"') < 70
