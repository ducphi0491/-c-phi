# AudioSheet Studio v1.5.0 – Gemini API Harmony Assistant – 2026-11-03

- Optional Google Gemini audio analysis for key, chord timeline and musical sections; no Windows WSL2 requirement.
- Hardened JSON parsing, chord symbol validator, overlap alignment against measured rhythm and local note-evidence gating.
- If accepted, rebuild B Easy/Standard/Full and export MIDI/MusicXML/PDF and piano audio from the same validated notes; preserve A and C.
- Store separate `gemini_analysis.json` (unverified API output) and `analysis.json` (effective harmonies).
- Server-side API key only; explicit consent before uploads; compressed MP3 and remote Files API deletion attempt.
- Honest status: Gemini used/validated vs local fallback, changed chord-window count, warnings on error and quota.
- `CAI_GEMINI_API.bat`, `KIEM_TRA_GEMINI.bat`, `CHAY_GEMINI.bat` and `.env` template; settings for model/timeouts.
- Compatible with Windows Server 2019; no new model weights included. Gemini calls not verified with real credentials.

# AudioSheet Studio v1.4.1 - 2026-11-03

Phase 1: Native Windows Server 2019 (Build 17763) support for optional SheetSage2 research engine.

- SheetSage2 now runs in its own **native Windows CPU** `.sheetsage2-venv` rather than WSL2.
- New BAT installer, pinned upstream dependencies, CPU-only Torch 2.8.0, optional diagnostics and install log.
- Installer requires user consent to the non-commercial model license; does not download weights automatically.
- API health and engine-selection errors identify native runtime correctly. No false claim that pip installation means checkpoints are downloaded.
- Model worker forces Windows CPU and limits threads; existing Linux model worker and Pop2Piano WSL2 path are preserved.
- If SheetSage2 exports an empty vocal or chord track, the adapter can use instrumental melody or the fallback chord timeline without discarding valid melody.
- A/B/C, Beat This!, Demucs, Basic Pitch, the sample piano player and PDF pipeline unchanged.
- Model inference with real weights on Windows Server 2019 is **not verified in this release**; synthetic and integration tests are reported separately.

Full instructions: `HUONG_DAN_V1.4.1_WINDOWS.txt`.
