-- Run in a dedicated MySQL/MariaDB database, e.g. meloware_premium.
-- MySQL 5.7+/MariaDB 10.3+. Do not expose these tables over a public API.
CREATE TABLE IF NOT EXISTS premium_accounts (
    google_sub VARCHAR(64) NOT NULL PRIMARY KEY,
    trial_started_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS premium_purchases (
    token_hash CHAR(64) NOT NULL PRIMARY KEY,
    google_sub VARCHAR(64) NOT NULL,
    encrypted_token TEXT NOT NULL,
    plan_id VARCHAR(32) NOT NULL,
    expires_at DATETIME NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'inactive',
    verified_at DATETIME NOT NULL,
    INDEX idx_account_expiry (google_sub, expires_at),
    CONSTRAINT fk_premium_user FOREIGN KEY (google_sub)
        REFERENCES premium_accounts(google_sub) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
