<?php
declare(strict_types=1);
/**
 * MeloWare Premium verification server (PHP 8.0+, PDO MySQL, curl, openssl).
 * PUBLIC ENDPOINT: https://tunertools.top/api/meloware_premium.php
 * NEVER place the Google Play service account JSON or private config in the web root.
 * NO client-provided price, duration, expiration, or status is trusted.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, private');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: none');

function fail_request(int $code, string $message): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
function b64url(string $value): string { return rtrim(strtr(base64_encode($value), '+/', '-_'), '='); }
function utc_datetime(int $timestamp): string { return gmdate('Y-m-d H:i:s', $timestamp); }
function millis(int $timestamp): int { return $timestamp * 1000; }
function unix_rfc3339(string $value): int {
    try { return (new DateTimeImmutable($value))->getTimestamp(); }
    catch (Throwable $e) { return 0; }
}

/** Requests to Google are made with TLS verification, no redirects, strict timeouts. */
function google_request(string $url, string $method = 'GET', ?array $form = null, ?string $bearer = null): array {
    $h = curl_init($url);
    if ($h === false) throw new RuntimeException('cURL init failed');
    $headers = ['Accept: application/json'];
    if ($bearer !== null) $headers[] = 'Authorization: Bearer ' . $bearer;
    curl_setopt_array($h, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_FOLLOWLOCATION => false, CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CUSTOMREQUEST => $method,
    ]);
    if ($form !== null) {
        curl_setopt($h, CURLOPT_POSTFIELDS, http_build_query($form));
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($h, CURLOPT_HTTPHEADER, $headers);
    }
    $body = curl_exec($h);
    $http = (int) curl_getinfo($h, CURLINFO_HTTP_CODE);
    if ($body === false) {
        $error = curl_error($h);
        curl_close($h);
        throw new RuntimeException('Google API connection failed: ' . $error);
    }
    curl_close($h);
    $data = json_decode((string) $body, true);
    if ($http < 200 || $http >= 300 || !is_array($data)) {
        throw new RuntimeException('Google API HTTP ' . $http);
    }
    return $data;
}

function oauth_user(string $idToken, array $cfg): string {
    if (strlen($idToken) < 80 || strlen($idToken) > 8000) fail_request(401, 'Google sign-in token invalid');
    // Tokeninfo checks Google-issued JWT signature, audience, and expiry.
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($idToken);
    $data = google_request($url);
    $issuer = (string) ($data['iss'] ?? '');
    $audience = (string) ($data['aud'] ?? '');
    $sub = (string) ($data['sub'] ?? '');
    if (!in_array($issuer, ['accounts.google.com', 'https://accounts.google.com'], true)
        || $audience !== $cfg['google_web_client_id']
        || ((int) ($data['exp'] ?? 0)) < time()
        || !preg_match('/^[0-9]{8,40}$/', $sub)) {
        fail_request(401, 'Invalid or expired MeloWare Google sign-in');
    }
    return $sub;
}

function android_access_token(array $cfg): string {
    $path = (string) ($cfg['service_account_json'] ?? '');
    if ($path === '' || !is_file($path)) throw new RuntimeException('Google Play server key not configured');
    $account = json_decode((string) file_get_contents($path), true);
    if (!is_array($account) || !isset($account['client_email'], $account['private_key'])) {
        throw new RuntimeException('Google Play service account JSON invalid');
    }
    $issued = time();
    $head = b64url(json_encode(['alg' => 'RS256', 'typ' => 'JWT'], JSON_THROW_ON_ERROR));
    $claims = b64url(json_encode([
        'iss' => $account['client_email'], 'scope' => 'https://www.googleapis.com/auth/androidpublisher',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $issued, 'exp' => $issued + 3300,
    ], JSON_THROW_ON_ERROR));
    $unsigned = $head . '.' . $claims;
    if (!openssl_sign($unsigned, $signature, $account['private_key'], OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('Could not sign Google Play OAuth request');
    }
    $result = google_request('https://oauth2.googleapis.com/token', 'POST', [
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $unsigned . '.' . b64url($signature),
    ]);
    $token = (string) ($result['access_token'] ?? '');
    if ($token === '') throw new RuntimeException('Google Play API access token unavailable');
    return $token;
}

function check_play_purchase(string $token, array $cfg, string $googleBearer): array {
    $package = rawurlencode((string) $cfg['package_name']);
    $url = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/' . $package
        . '/purchases/subscriptionsv2/tokens/' . rawurlencode($token);
    $purchase = google_request($url, 'GET', null, $googleBearer);
    $state = (string) ($purchase['subscriptionState'] ?? '');
    $expiry = 0; $plan = '';
    foreach (($purchase['lineItems'] ?? []) as $item) {
        if (!is_array($item) || ($item['productId'] ?? '') !== 'meloware_premium') continue;
        if (!isset($item['prepaidPlan']) || !is_array($item['prepaidPlan'])) continue;
        $candidatePlan = (string) ($item['offerDetails']['basePlanId'] ?? '');
        if (!in_array($candidatePlan, ['premium-6m', 'premium-12m'], true)) continue;
        $candidateExpiry = unix_rfc3339((string) ($item['expiryTime'] ?? ''));
        if ($candidateExpiry > $expiry) { $expiry = $candidateExpiry; $plan = $candidatePlan; }
    }
    return [
        'valid' => $state === 'SUBSCRIPTION_STATE_ACTIVE' && $expiry > time() && $plan !== '',
        'state' => $state, 'expires' => $expiry, 'plan' => $plan,
        'ackPending' => ($purchase['acknowledgementState'] ?? '') === 'ACKNOWLEDGEMENT_STATE_PENDING',
        'externalId' => (string) ($purchase['externalAccountIdentifiers']['obfuscatedExternalAccountId'] ?? ''),
    ];
}

function acknowledge_play(string $purchaseToken, array $cfg, string $bearer): void {
    $url = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'
        . rawurlencode((string) $cfg['package_name']) . '/purchases/subscriptions/'
        . rawurlencode('meloware_premium') . '/tokens/' . rawurlencode($purchaseToken) . ':acknowledge';
    $h = curl_init($url);
    if ($h === false) throw new RuntimeException('Could not initialize acknowledgement');
    curl_setopt_array($h, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => '{}',
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $bearer, 'Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($h);
    $http = (int) curl_getinfo($h, CURLINFO_HTTP_CODE);
    curl_close($h);
    if ($body === false || $http < 200 || $http >= 300) throw new RuntimeException('Google Play acknowledgement HTTP ' . $http);
}

function encrypt_token(string $token, array $cfg): string {
    $key = base64_decode((string) $cfg['aes_256_key_b64'], true);
    if ($key === false || strlen($key) !== 32) throw new RuntimeException('Encryption key must be 32 bytes');
    $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($token, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) throw new RuntimeException('Could not encrypt purchase token');
    return base64_encode($iv . $tag . $cipher);
}
function decrypt_token(string $encrypted, array $cfg): string {
    $raw = base64_decode($encrypted, true);
    $key = base64_decode((string) $cfg['aes_256_key_b64'], true);
    if ($raw === false || strlen($raw) < 29 || $key === false || strlen($key) !== 32) {
        throw new RuntimeException('Invalid encrypted purchase token');
    }
    $token = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    if ($token === false) throw new RuntimeException('Could not decrypt purchase token');
    return $token;
}

function account_row(PDO $db, string $sub, array $cfg): array {
    $stmt = $db->prepare('INSERT IGNORE INTO premium_accounts (google_sub) VALUES (?)');
    $stmt->execute([$sub]);
    if (!empty($cfg['trial_enabled'])) {
        // First successful server authentication starts trial; changing device does not reset it.
        $stmt = $db->prepare('UPDATE premium_accounts SET trial_started_at = UTC_TIMESTAMP() WHERE google_sub = ? AND trial_started_at IS NULL');
        $stmt->execute([$sub]);
    }
    $stmt = $db->prepare('SELECT trial_started_at FROM premium_accounts WHERE google_sub = ?');
    $stmt->execute([$sub]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}

function refresh_existing_receipts(PDO $db, string $sub, array $cfg): void {
    $stmt = $db->prepare('SELECT token_hash, encrypted_token, verified_at FROM premium_purchases WHERE google_sub = ? AND expires_at > UTC_TIMESTAMP()');
    $stmt->execute([$sub]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows) return;
    $playBearer = null;
    foreach ($rows as $row) {
        $last = strtotime((string) $row['verified_at'] . ' UTC') ?: 0;
        if (time() - $last < 900) continue; // Poll current Play state at most every 15 minutes per token.
        try {
            $playBearer ??= android_access_token($cfg);
            $decrypted = decrypt_token($row['encrypted_token'], $cfg);
            $verified = check_play_purchase($decrypted, $cfg, $playBearer);
            // Retry acknowledgement if Google Play had not confirmed it previously.
            if ($verified['valid'] && $verified['ackPending']) {
                try { acknowledge_play($decrypted, $cfg, $playBearer); }
                catch (Throwable $e) { error_log('MeloWare premium acknowledgement retry failed'); }
            }
            $stmt = $db->prepare('UPDATE premium_purchases SET plan_id = ?, expires_at = ?, status = ?, verified_at = UTC_TIMESTAMP() WHERE token_hash = ? AND google_sub = ?');
            $stmt->execute([
                $verified['plan'] ?: 'unknown', utc_datetime($verified['expires']),
                $verified['valid'] ? 'active' : 'inactive', $row['token_hash'], $sub,
            ]);
        } catch (Throwable $e) {
            // Keep most recently verified state until its known expiry; retry next refresh.
            error_log('MeloWare Premium refresh failed (details withheld)');
        }
    }
}

function status_response(PDO $db, string $sub, array $cfg): array {
    $acc = account_row($db, $sub, $cfg);
    refresh_existing_receipts($db, $sub, $cfg);
    $stmt = $db->prepare("SELECT plan_id, UNIX_TIMESTAMP(expires_at) AS expires FROM premium_purchases WHERE google_sub = ? AND status = 'active' AND expires_at > UTC_TIMESTAMP() ORDER BY expires_at DESC LIMIT 1");
    $stmt->execute([$sub]);
    $activePurchase = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    $trialStart = isset($acc['trial_started_at']) ? (strtotime((string) $acc['trial_started_at'] . ' UTC') ?: 0) : 0;
    $trialEnd = $trialStart > 0 ? $trialStart + 30 * 86400 : 0;
    $expiry = $activePurchase ? (int) $activePurchase['expires'] : 0;
    $kind = 'none';
    if ($expiry > time()) $kind = 'paid';
    elseif (!empty($cfg['trial_enabled']) && $trialEnd > time()) { $expiry = $trialEnd; $kind = 'trial'; }
    return [
        'ok' => true,
        'access' => $kind !== 'none', 'accessKind' => $kind,
        'expiresAtMillis' => millis($expiry),
        'trialEndMillis' => millis($trialEnd),
        'planId' => $activePurchase['plan_id'] ?? null,
        'checkoutEnabled' => !empty($cfg['checkout_enabled'])
            && !empty($cfg['service_account_json'])
            && is_file((string) $cfg['service_account_json'])
            && strlen((string) (base64_decode((string) ($cfg['aes_256_key_b64'] ?? ''), true) ?: '')) === 32,
        'enforceFeatures' => !empty($cfg['enforce_features']),
        'serverTimeMillis' => millis(time()),
    ];
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail_request(405, 'POST required');
if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 16000) fail_request(413, 'Body too large');
try {
    $cfg = require 'C:/ProgramData/MeloWare/premium_config.php'; // MUST stay outside IIS document root.
    if (!is_array($cfg)) throw new RuntimeException('Premium config is missing');
    $raw = file_get_contents('php://input', false, null, 0, 16000);
    $input = json_decode((string) $raw, true);
    if (!is_array($input)) fail_request(400, 'Invalid JSON');
    $action = (string) ($input['action'] ?? '');
    if (!in_array($action, ['status', 'verify'], true)) fail_request(400, 'Invalid action');
    $sub = oauth_user((string) ($input['idToken'] ?? ''), $cfg);
    $db = new PDO((string) $cfg['dsn'], (string) $cfg['db_user'], (string) $cfg['db_password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    // Set session timezone to UTC (DB / PHP timestamps must be consistent).
    $db->exec("SET time_zone = '+00:00'");
    if ($action === 'status') {
        echo json_encode(status_response($db, $sub, $cfg), JSON_UNESCAPED_UNICODE);
        exit;
    }
    $purchaseToken = (string) ($input['purchaseToken'] ?? '');
    if (strlen($purchaseToken) < 10 || strlen($purchaseToken) > 2048) fail_request(400, 'Invalid purchase token');
    $bearer = android_access_token($cfg);
    $verified = check_play_purchase($purchaseToken, $cfg, $bearer);
    if (!$verified['valid']) fail_request(409, 'Google Play has not confirmed an active prepaid Premium purchase');
    // Prevent receipts purchased for one signed-in MeloWare account from being reused by another.
    $expected = hash('sha256', 'meloware:' . $sub);
    if ($verified['externalId'] !== '' && !hash_equals($expected, $verified['externalId'])) {
        fail_request(409, 'This purchase belongs to another MeloWare Google account');
    }
    $digest = hash('sha256', $purchaseToken);
    $db->beginTransaction();
    $stmt = $db->prepare('SELECT google_sub FROM premium_purchases WHERE token_hash = ? FOR UPDATE');
    $stmt->execute([$digest]);
    $owner = $stmt->fetchColumn();
    if ($owner !== false && $owner !== $sub) { $db->rollBack(); fail_request(409, 'This purchase is linked to another account'); }
    account_row($db, $sub, $cfg);
    $stmt = $db->prepare("INSERT INTO premium_purchases (token_hash, google_sub, encrypted_token, plan_id, expires_at, status, verified_at) VALUES (?, ?, ?, ?, ?, 'active', UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE expires_at = VALUES(expires_at), plan_id = VALUES(plan_id), status = 'active', verified_at = UTC_TIMESTAMP()");
    $stmt->execute([$digest, $sub, encrypt_token($purchaseToken, $cfg), $verified['plan'], utc_datetime($verified['expires'])]);
    $db->commit();
    if ($verified['ackPending']) {
        try { acknowledge_play($purchaseToken, $cfg, $bearer); }
        catch (Throwable $e) { error_log('MeloWare premium acknowledgement failed; retry required'); }
    }
    echo json_encode(status_response($db, $sub, $cfg), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('MeloWare Premium internal error: ' . $e->getMessage()); // no credentials/tokens in logs
    fail_request(503, 'Máy chủ Premium đang thiết lập hoặc Google Play API tạm thời lỗi. Vui lòng thử lại.');
}
