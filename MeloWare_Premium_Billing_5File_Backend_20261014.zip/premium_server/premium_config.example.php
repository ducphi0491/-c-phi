<?php
/** Copy to C:\ProgramData\MeloWare\premium_config.php, outside the web root. */
return [
    'package_name' => 'duc_phi.music',
    'google_web_client_id' => '886650248212-iuvj3vueej3u8eu6jb0mpsbifmmq7dsk.apps.googleusercontent.com',
    'service_account_json' => 'C:/ProgramData/MeloWare/play-service-account.json',
    'dsn' => 'mysql:host=127.0.0.1;dbname=meloware_premium;charset=utf8mb4',
    'db_user' => 'REPLACE_WITH_LIMITED_DB_USER',
    'db_password' => 'REPLACE_WITH_DB_PASSWORD',
    // Generate: php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"
    'aes_256_key_b64' => 'REPLACE_WITH_32_BYTE_RANDOM_BASE64',
    // STAGING DEFAULTS: NO CHARGES, NO FEATURE LOCKS, NO TRIAL CLOCK.
    // Enable only after Play Developer API permissions, license testers and end-to-end verification.
    'checkout_enabled' => false,
    'trial_enabled' => false,
    'enforce_features' => false,
];
