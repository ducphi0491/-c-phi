# MeloWare Premium – tích hợp Google Play Billing (bản 15.10)

## Những gì đã thực hiện

Dùng đúng gốc `meloware15.10 (1).zip`. Các file Android thay đổi:

1. `MeloWarePremium.kt`: Google Play Billing 9.1.0, mở checkout bằng `launchBillingFlow`, nhận giao dịch (PURCHASED / PENDING / USER_CANCELED), đọc giá từng base plan, kiểm tra/kết nối lại, khôi phục mua bằng `queryPurchasesAsync`, gọi backend PHP để xác minh trạng thái và hạn sử dụng.
2. `MainActivity.kt`: BillingClient tồn tại suốt Activity, kiểm tra lại giao dịch khi app quay lại foreground, cập nhật quyền khi đăng nhập/đăng xuất Google; ẩn banner trên trang phát khi backend xác nhận đang Premium hoặc trong thời gian thử.
3. `NowPlayingScreen.kt`: khi chính sách Premium được bật và trial/gói trả phí hết hạn, phần **Equalizer nâng cao (5 băng tần)** hiển thị hộp thoại Premium; preset và BASS/MID/TREBLE cơ bản vẫn miễn phí. Truyền nút mở Premium từ màn hình phát, không tự ngắt nhạc. Không khóa các chế độ chia sẻ LAN/Internet trong giai đoạn thử nghiệm nhà mạng.
4. `meloware_languages.json`: thêm trạng thái thanh toán/trial và thông báo Equalizer bằng 15 ngôn ngữ.
5. `build.gradle.kts`: **không thay đổi thư viện**, giữ `com.android.billingclient:billing:9.1.0`, chỉ tăng `versionCode` 28→29 và `versionName` 2.1.0→2.1.1 để chuẩn bị kênh Internal testing. Nếu 29 đã được dùng, tăng lên cao hơn.

**Lưu ý:** Không có `.kt` mới. Trạng thái thanh toán **không được mở** chỉ bằng sửa boolean trên máy. Chỉ server xác minh được purchase token qua Google Play Developer API mới cấp quyền. Hai gói giữ ID `meloware_premium`, `premium-6m`, `premium-12m`.

## Đặt file Android

- Đặt tất cả `.kt` thuộc ZIP vào `app/src/main/java/duc_phi/music/`.
- Đặt `meloware_languages.json` vào `app/src/main/assets/`.
- Đặt `build.gradle.kts` vào `app/build.gradle.kts`.
- Sync/Rebuild và xuất `.aab` cho **Internal testing**. Không phát hành Production ngay.
- Google account được dùng để đăng nhập trong **MeloWare** phải tồn tại. Đây là tài khoản liên kết thử 30 ngày và quyền Premium, không nhất thiết trùng email Play Store, nhưng **khôi phục phải dùng cùng tài khoản Google trong MeloWare**.

## Cài backend xác minh trên tunertools.top

Backend chỉ xác minh hóa đơn và lưu hạn sử dụng: **không truyền nhạc hay làm TURN**. Máy chủ Windows Server 2019 chạy PHP và MySQL/MariaDB, không yêu cầu quyền cấu hình router nếu `https://tunertools.top` đã truy cập được.

**1. PHP & cơ sở dữ liệu**

- Cần PHP 8.0+, các extension `curl`, `openssl`, `pdo_mysql`.
- Tạo một database MySQL/MariaDB tên `meloware_premium`, chạy `server/schema.sql`.
- Tạo MySQL user riêng **chỉ có SELECT / INSERT / UPDATE** trên 2 bảng (đã tạo bảng bằng tài khoản quản trị). Không dùng tài khoản root trên web.
- Upload duy nhất `server/meloware_premium.php` vào webroot của `tunertools.top` theo đường dẫn `/api/meloware_premium.php`.
- Website phải có HTTPS hợp lệ. Kiểm tra `https://tunertools.top/api/meloware_premium.php` có phản hồi `POST required` khi truy cập bằng GET: điều này xác nhận file PHP tồn tại, không phải xác nhận đã cấu hình xong.

**2. Bảo mật cấu hình**

- Tạo thư mục `C:\ProgramData\MeloWare\`, ngoài IIS `wwwroot`, cấp quyền đọc cho tài khoản chạy PHP/IIS; không cho người dùng Internet đọc trực tiếp.
- Sao chép `server/premium_config.example.php` thành `C:\ProgramData\MeloWare\premium_config.php` rồi thay database/khóa.
- Sinh khóa AES-GCM duy nhất qua PowerShell: `php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"`.
- Tuyệt đối KHÔNG tải `premium_config.php` hay JSON service account vào `app/assets` hoặc GitHub công khai.

**3. Google Play Developer API**

- Trên Google Cloud Console, bật **Google Play Android Developer API** cho dự án phù hợp.
- Tạo service account với quyền tối thiểu cần dùng, cấp quyền cho email service account trong **Google Play Console → Users and permissions**, quyền liên quan đến xem giao dịch và quản lý đơn hàng/gói thuê bao (theo tài liệu Google Play).
- Lưu JSON service account vào `C:\ProgramData\MeloWare\play-service-account.json`, ngoài webroot.
- Cấu hình `google_web_client_id` giữ đúng Web OAuth client ID như `MainActivity.kt`, **không phải package ID hay App ID AdMob**.
- Server dùng Google Play API `purchases.subscriptionsv2.get` để lấy đúng `subscriptionState`, `lineItems`, `offerDetails.basePlanId`, `expiryTime`, và `purchases.subscriptions.acknowledge` để xác nhận giao dịch. Giá tiền từ Google Play Console, không nhận từ client.

**4. Bật theo giai đoạn trong `premium_config.php`**

Mặc định trong file mẫu:

```php
'checkout_enabled' => false,
'trial_enabled' => false,
'enforce_features' => false,
```

- Giữ như trên cho đến khi đã triển khai backend, chạy SQL và kiểm tra server đọc được Google Play API.
- Test license tester trong **Internal testing**; chỉ sau khi backend thực sự xác minh giao dịch thành công mới bật `'checkout_enabled' => true`.
- Khi muốn bắt đầu dùng thử chính thức 30 ngày, bật `'trial_enabled' => true`. Đồng hồ tính từ **lần đầu tài khoản Google đăng nhập dùng Premium trên server**; không có cách chống tạo tài khoản Google mới hoàn toàn nếu không có biện pháp chống lạm dụng bổ sung.
- Bật `'enforce_features' => true` **sau khi** thử 30 ngày hoạt động đúng, đồng thời đã công bố rõ chức năng nào là Premium. Chỉ Equalizer **nâng cao 5 băng tần** được khóa ở bản này, EQ cơ bản vẫn miễn phí; các chế độ chia sẻ Internet/LAN vẫn mở để thử mạng.
- Banner Now Playing sẽ tự ẩn khi server xác nhận trial còn hạn hoặc Premium trả phí còn hạn. Nút mua vẫn bị khóa nếu backend chưa trả `checkoutEnabled = true`.

**5. Kiểm tra**

1. Đăng nhập Google trong MeloWare → Cài đặt → Premium. Không đăng nhập sẽ không mở mua.
2. Đọc giá thực của gói 6/12 tháng từ Google Play.
3. Với tài khoản License tester, thử mua gói qua Google Play từ bản cài qua Internal testing; xác nhận không dùng thẻ thật và tài khoản đúng là License tester.
4. Kiểm tra backend trả `accessKind=paid`, thời gian hết hạn Google Play chính xác, server đã **acknowledge** giao dịch.
5. Đóng app / mở lại / đổi điện thoại, đăng nhập **cùng Google account trong MeloWare**, bấm **Khôi phục giao dịch**; kiểm tra quyền được cấp lại.
6. Mô phỏng trạng thái đang chờ thanh toán: app **không** cấp quyền khi `PENDING`.
7. Kiểm tra tài khoản chưa mua/không có trial: banner vẫn xuất hiện, sau khi enforce thì Equalizer bị khóa; nghe nhạc cơ bản và 4 phương thức chia sẻ vẫn hoạt động.
8. Test hoàn tiền/thu hồi (refund/revoke) – backend làm mới trạng thái gói tối đa mỗi 15 phút khi ứng dụng yêu cầu quyền. Trước khi phát hành rộng rãi, nên bổ sung Real-time Developer Notifications (RTDN) để nhận trạng thái hoàn tiền/hết hạn kịp thời, thay vì chỉ chờ app truy vấn.

## Điểm quan trọng chưa thể hoàn tất trong bản ZIP offline

- Chưa thể chạy Google Play thanh toán thật: phải có service account **riêng của bạn**, thông tin database và server `tunertools.top` thực tế. Không gửi bí mật cho ChatGPT.
- Không build thử AAB được trong môi trường hiện tại (ZIP chỉ có các file trích từ module Android, không có Gradle wrapper / top-level project / Android SDK); đã kiểm tra cú pháp PHP, JSON và đối chiếu mã Kotlin nhưng bạn cần build Android Studio.
- Google Drive & chia sẻ **nâng cao** mới ở giai đoạn phát triển, hiện KHÔNG bán như một quyền lợi đã triển khai. Các tính năng chia sẻ đang có không bị khóa.
- Chưa có kiểm thử hiệu năng và thanh toán thật trên Play Store; không phát hành bản này lên Production trước khi hoàn thành backend và mọi bài test.
- Backend dùng Google OAuth ID token của luồng GoogleSignIn sẵn có. Nếu phiên đăng nhập quá hạn, người dùng cần đăng nhập Google lại khi ứng dụng không thể làm mới im lặng.
- Hiện chính sách khóa Equalizer được nhận từ backend khi có kết nối. Để có chống gian lận khi offline ở mức phát hành rộng, nên thêm chứng thực entitlement bằng token ký và chính sách cache hạn chế thời gian trong phiên bản tiếp theo.
