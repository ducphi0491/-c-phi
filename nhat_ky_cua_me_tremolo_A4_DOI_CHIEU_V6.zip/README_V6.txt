V6 PDF vector: Can chinh dong TAB khi 1 trong 6 duong khong co net vector.
Moi so ngan tim them la UNVERIFIED; GP5 / MIDI van la ban nhap.
Mo alignment_audit.csv de xem he nao thay doi, recognition_diagnostics.json de xem toa do.
GP5 khong la chung cu ban nhac da nhan dien dung truong do, ky thuat guitar.
