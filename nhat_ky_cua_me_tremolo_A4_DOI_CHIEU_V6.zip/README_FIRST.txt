TUNERTOOLS V6 - COMPARISON PACKAGE

1) Keep the original PDF/PNG in this ZIP when sharing for a true comparison.
2) Open OPEN_REVIEW.html to inspect page overlays and mapped GP measures.
3) measures.csv maps GP bars to source page, PDF measure label and source x range.
4) source_notes.csv holds original PDF fret locations and ASSUMED rhythm.
5) output_notes.csv holds notes ACTUALLY saved in GP after your edits.
6) GP_output/result.mid lets you audition timing outside TunerTools.
7) recognition_diagnostics.json includes possible overlapping numbers.

IMPORTANT: rhythm, tremolo, ornament and lyrics are NOT automatically verified.
If numbers overlap on a PDF, a missing label is not proof that a
recoverable, independent bar exists in the original drawing.
