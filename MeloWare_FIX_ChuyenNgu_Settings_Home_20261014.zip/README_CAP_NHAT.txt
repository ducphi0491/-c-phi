MeloWare – Sua giao dien con tieng Viet sau khi doi ngon ngu (14/10/2026)

NGUYEN NHAN
- JSON da duoc doc va ngon ngu da doi dung: anh test hien Настройки, Язык, Режим интерфейса.
- Nhieu noi van hardcode tieng Viet trong MainActivity, HomeScreen va thanh dieu huong.
- Cho nay KHONG PHAI loi uu tien ngon ngu thiet bi.

4 FILE CAN THAY (khong can sua Gradle):
1. app/src/main/java/duc_phi/music/MainActivity.kt
2. app/src/main/java/duc_phi/music/HomeScreen.kt
3. app/src/main/java/duc_phi/music/MusicUiComponents.kt
4. app/src/main/assets/meloware_languages.json

NOI DUNG
- Doi mau giao dien, logout/login, xoa cache, ngat Drive, thong tin thong ke, hop mau va theme duoc truyen qua mwString.
- Trang chu: title, o tim kiem, card nguon nhac, the chia se, danh sach gan day, chu thich, trang thai rong.
- Thanh menu duoi: Trang chu / Thu vien va accessibility labels.
- 51 key moi da co ban dich cho 15 ngon ngu; giu tat ca 111 key truoc.
- Giu logic theo ngon ngu dien thoai / chon thu cong / luu lua chon.
- Giu logic nhac, Firebase, WebRTC, Drive, Ads, update, Gradle.

LUU Y PHAM VI
- Ban nay sua cac vi tri con tieng Viet o Settings, Home va bottom dock.
- Nhung man hinh nhu LibraryScreen, NowPlayingScreen, OnlineSearch, thong bao phat sinh va admin van co chuoi viet truc tiep; CHUA dich het app.
- Can chuyen tiep cac man hinh do sang mwString va bo sung JSON o dot sau; khong nen hieu ban nay la 100% da ngon ngu.

KIEM TRA
- Thay 4 file, Build > Rebuild Project, mo app, vao Cai dat > Ngon ngu > Russian.
- Kiểm tra Xoa cache, Dang xuat, Xanh duong, Trang chu/Thu vien va tieu de trang chu nay hien tieng Nga.
- Sau do chon tieng Viet va tieng Nhat; thu dong/mo app de xac nhan giu lua chon.
- Chua build Android APK trong moi truong nay; neu loi hay gui dong Build Output dau tien.
