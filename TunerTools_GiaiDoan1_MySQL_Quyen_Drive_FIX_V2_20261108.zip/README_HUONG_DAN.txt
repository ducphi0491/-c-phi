TUNERTOOLS - GIAI DOAN 1 - V2: MYSQL -> JSON -> GOOGLE DRIVE
==============================================================
CHUA SUA admin.kt. CHUA SUA api_documents.php. KHONG TAO TASK CHAY NEN.
V2 FIX: Khong su dung python -c (loi quote tren Windows PowerShell 5.1).
Thay bang CHECK_PYTHON_VERSION.py de kiem tra phien ban.

NGUON DU LIEU:
  C:\TunerTools\Web\API\api_documents.php (chi doc cau hinh DB, KHONG thuc thi API)
  Bang MySQL: document_permissions (SELECT * only, khong UPDATE/DELETE)
GOOGLE DRIVE:
  My Drive/TunerTools_AppBackup/config/document_permissions.json
  File PRIVATE, chi upload bang Google Drive OAuth token tren SERVER:
  C:\TunerTools\Tools\AI_Drive_AutoSync\drive_token.json

HUONG DAN:
1. Giai nen bo ZIP vao C:\TunerTools\Tools\Document_Permissions_Export\
2. Right click 01_CHAY_XUAT_UPLOAD_QUYEN.cmd -> Run as administrator.
3. Xu ly theo thu tu:
    - doc MySQL truc tiep; xuat JSON vao _private\document_permissions.json
    - refresh Drive token cua server
    - tao config folder neu chua co; tao file JSON neu chua co
    - tai file JSON ve tu Drive, so sanh SHA256 de xac minh
4. Can thay ket qua:
    EXPORT_OK
    DRIVE_UPLOAD_CREATED: OK (hoac DRIVE_FILE_PRESENT: identical)
    DRIVE_VERIFY_OK
    STAGE_1_OK
5. Chi gui ket qua log (KHONG gui file JSON chua Gmail, KHONG gui token).

NEU FILE JSON DA TON TAI NHUNG KHAC NHAU:
  De an toan, script dung va KHONG ghi de.
  Sau khi da xac nhan MySQL la nguon dung, chay trong PowerShell Admin:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\Document_Permissions_Export\RUN_DOCUMENT_PERMISSIONS.ps1" -UpdateExisting

DE XEM TRUOC (KHONG GHI DRIVE):
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\Document_Permissions_Export\RUN_DOCUMENT_PERMISSIONS.ps1" -Preview

NEU KHONG TIM THAY PHP CLI:
   Chay PowerShell Admin voi -PhpExe "C:\duong_dan\php.exe"
   PHP can co extension mysqli. Khong dung php-cgi.exe.
NEU KHONG TIM THAY PYTHON:
   Chay PowerShell Admin voi -PythonExe "C:\duong_dan\python.exe"

BAO MAT:
- JSON chua danh sach Gmail va quyen. Luon private, KHONG share Google Drive link.
- Script khong ghi OAuth token hay MySQL password vao JSON hoac log.
- Chi thu muc _private duoc ACL restricted: Administrators va SYSTEM.
- Khong upload JSON ve client Android, chua co co che xac thuc failover.
- Sau giai doan 1 nay, IIS sap thi Android HIEN TAI VAN CHUA TU DONG DOC DUOC.
  Can sua backend Alwaysdata va xac thuc Google DOC LAP truoc, roi moi sua admin.kt.
- Khong xoa token cu / file PHP backup neu cac chuc nang Documents/Guides cu con dung.
