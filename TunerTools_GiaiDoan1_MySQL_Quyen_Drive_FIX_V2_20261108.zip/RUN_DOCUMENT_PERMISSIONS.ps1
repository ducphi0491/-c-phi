# TunerTools document permissions: stage 1 only (MySQL -> private JSON -> Google Drive).
# No modifications to admin.kt, api_documents.php, MySQL or Windows Scheduled Tasks.
[CmdletBinding()]
param(
    [switch]$Preview,
    [switch]$UpdateExisting,
    [string]$PhpExe = '',
    [string]$PythonExe = ''
)
$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
$apiFile = 'C:\TunerTools\Web\API\api_documents.php'
$tokenFile = 'C:\TunerTools\Tools\AI_Drive_AutoSync\drive_token.json'
$exporter = Join-Path $base 'EXPORT_DOCUMENT_PERMISSIONS.php'
$uploader = Join-Path $base 'UPLOAD_DOCUMENT_PERMISSIONS.py'
$checker = Join-Path $base 'CHECK_PYTHON_VERSION.py'
$private = Join-Path $base '_private'
$jsonFile = Join-Path $private 'document_permissions.json'

function Abort([string]$message) { throw $message }
function Find-Php {
    param([string]$hint)
    if ($hint) { if (Test-Path -LiteralPath $hint -PathType Leaf) { return $hint }; Abort 'PHP exe path not found.' }
    $candidate = Get-Command php.exe -ErrorAction SilentlyContinue
    if ($candidate -and $candidate.Source -and (Test-Path -LiteralPath $candidate.Source)) { return $candidate.Source }
    $names = @(
        'C:\PHP\php.exe', 'C:\php\php.exe',
        'C:\Program Files\PHP\php.exe',
        'C:\Program Files (x86)\PHP\php.exe',
        'C:\TunerTools\PHP\php.exe', 'C:\TunerTools\Web\PHP\php.exe',
        'C:\inetpub\php\php.exe'
    )
    foreach ($item in $names) { if (Test-Path -LiteralPath $item -PathType Leaf) { return $item } }
    foreach ($folder in @('C:\PHP','C:\Program Files\PHP','C:\Program Files (x86)\PHP','C:\inetpub\php')) {
        if (Test-Path -LiteralPath $folder) {
            $found = Get-ChildItem -LiteralPath $folder -Filter php.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($found) { return $found.FullName }
        }
    }
    # FastCGI often uses php-cgi.exe; php.exe is usually in the same directory.
    $appcmd = Join-Path $env:WINDIR 'System32\inetsrv\appcmd.exe'
    if (Test-Path -LiteralPath $appcmd) {
        $result = & $appcmd list config '-section:system.webServer/fastCgi' 2>$null
        if ($result) {
            $text = $result -join "`n"
            $matches = [regex]::Matches($text, '[A-Za-z]:\\[^"\r\n]*?php-cgi\.exe', 'IgnoreCase')
            foreach ($match in $matches) {
                $php = Join-Path (Split-Path -Path $match.Value -Parent) 'php.exe'
                if (Test-Path -LiteralPath $php -PathType Leaf) { return $php }
            }
        }
    }
    Abort 'Cannot locate PHP CLI. Pass -PhpExe "C:\path\php.exe" (do not use php-cgi.exe).'
}
function Find-Python {
    param([string]$hint)
    if ($hint) { if (Test-Path -LiteralPath $hint -PathType Leaf) { return @($hint) }; Abort 'Python exe path not found.' }
    $c = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($c -and $c.Source -and (Test-Path -LiteralPath $c.Source)) { return @($c.Source) }
    $c = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($c -and $c.Source -and (Test-Path -LiteralPath $c.Source)) { return @($c.Source, '-3') }
    foreach ($name in @('C:\Python311\python.exe','C:\Python310\python.exe','C:\Python312\python.exe')) {
        if (Test-Path -LiteralPath $name -PathType Leaf) { return @($name) }
    }
    Abort 'Cannot locate Python >=3.9; pass -PythonExe "C:\path\python.exe".'
}

try {
    Write-Host '===================================================='
    Write-Host ' TUNERTOOLS - MYSQL DOCUMENT RIGHTS -> GOOGLE DRIVE'
    Write-Host ' STAGE 1: NO ANDROID CHANGES, NO MYSQL WRITES'
    Write-Host '===================================================='
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Abort 'Run this script from Administrator PowerShell (or Run as administrator CMD).'
    }
    foreach ($file in @($apiFile, $tokenFile, $exporter, $uploader, $checker)) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { Abort "Required file missing: $file" }
    }
    $php = Find-Php $PhpExe
    $python = @(Find-Python $PythonExe)
    if ($python.Count -eq 0) { Abort 'No Python interpreter.' }
    & $php -v
    if ($LASTEXITCODE -ne 0) { Abort 'PHP CLI cannot start.' }
    # Invoke a real .py file: Windows PowerShell 5.1 can strip nested quotes from python -c.
    if ($python.Count -eq 1) { & $python[0] $checker }
    else { & $python[0] $python[1] $checker }
    if ($LASTEXITCODE -ne 0) { Abort 'Python 3.9+ is required.' }

    if (-not (Test-Path -LiteralPath $private)) {
        New-Item -ItemType Directory -Path $private -Force | Out-Null
    }
    $icacls = Join-Path $env:WINDIR 'System32\icacls.exe'
    if (-not (Test-Path -LiteralPath $icacls)) { Abort 'Cannot find Windows icacls.exe; refusing to write private permissions.' }
    & $icacls $private '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' | Out-Null
    if ($LASTEXITCODE -ne 0) { Abort 'Cannot restrict the private JSON folder ACL; refusing to export.' }
    Write-Host 'PRIVATE_FOLDER_ACL: Administrators + SYSTEM only'

    Write-Host 'STEP 1/2: SELECT ONLY live MySQL.document_permissions ...'
    & $php $exporter '--api' $apiFile '--out' $jsonFile
    if ($LASTEXITCODE -ne 0) { Abort 'MySQL export failed. No Drive upload attempted.' }
    if (-not (Test-Path -LiteralPath $jsonFile -PathType Leaf)) { Abort 'JSON not written. No Drive upload attempted.' }
    & $icacls $jsonFile '/reset' | Out-Null
    if ($LASTEXITCODE -ne 0) { Abort 'Cannot apply inherited private ACL to JSON. No upload attempted.' }
    Write-Host 'STEP 2/2: Google Drive private config/document_permissions.json ...'
    $argsPython = @($uploader, '--json', $jsonFile, '--token', $tokenFile)
    if ($Preview) { $argsPython += '--preview' }
    if ($UpdateExisting) { $argsPython += '--update-existing' }
    if ($python.Count -eq 1) { & $python[0] @argsPython }
    else { & $python[0] $python[1] @argsPython }
    if ($LASTEXITCODE -ne 0) { Abort 'Drive upload/verification failed. MySQL unchanged; Android unchanged.' }
    Write-Host '===================================================='
    Write-Host 'STAGE_1_OK: MySQL export + Drive SHA256 verification.'
    Write-Host 'NEXT_STAGE_NOT_STARTED: Do not edit admin.kt yet.'
    Write-Host 'DO_NOT_SHARE: _private/document_permissions.json or drive_token.json'
    Write-Host '===================================================='
    exit 0
} catch {
    Write-Host ('STAGE_1_ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'No database records or Android files were modified.'
    exit 1
}
