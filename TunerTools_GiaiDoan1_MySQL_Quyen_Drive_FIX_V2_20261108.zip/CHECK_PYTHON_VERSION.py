#!/usr/bin/env python3
"""No -c / nested quotes: compatible with Windows PowerShell 5.1."""
import sys

version = sys.version_info
print("PYTHON_VERSION: {}.{}.{}".format(version.major, version.minor, version.micro))
if version.major < 3 or (version.major == 3 and version.minor < 9):
    print("PYTHON_VERSION_ERROR: Python 3.9+ is required")
    raise SystemExit(1)
print("PYTHON_RUNTIME_OK")
