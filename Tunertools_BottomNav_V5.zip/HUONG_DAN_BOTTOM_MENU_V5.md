# Tunertools V5 - Thanh menu duoi theo hinh mau

## Cau truc file

```text
app/src/main/
├── java/duc_phi/music/
│   ├── MainActivity.kt             <- V5, thay file cu
│   └── PublicDriveBrowser.kt      <- Giu nguyen V4
└── res/values/
    └── public_drive_api_key.xml   <- Giu nguyen V4
```

## Cac thay doi trong MainActivity.kt

- Them thanh menu nen toi, bo tron o phia duoi, duong vien tim, nut Play noi o giua co nen gradient tim/hong.
- **Trang chu**: Hien giao dien nghe nhac/Equalizer.
- **Tim kiem**: Mo danh sach, tu dong focus vao thanh tim kiem hien co. Tim kiem van dung luong logic tim nhac cua app.
- **Nut Play/Pause giua**: Thao tac tren cung `togglePlayback` va ExoPlayer cua app; khong khoi tao player thu hai.
- **Thu vien**: Mo danh sach phat hien tai, hien so bai va nut Them nhac. Nut Them nhac mo trinh chon nguon (bo nho, Drive ca nhan, link Drive public) hien co.
- **Ca nhan**: Mo SettingsDialog hien co (tai khoan dang nhap, ngon ngu, theme, thong tin khac).
- Menu duoc dat **ngay tren banner quang cao**. Chieu cao menu co dinh 96dp; chia icon responsive theo do rong man hinh.
- Giu nguyen chuc nang auto lay anh album tu V4, cache nhac Drive, trinh duyet link Drive public va quyen SAF.

## Cai dat

1. Sao luu MainActivity.kt cu.
2. Copy `MainActivity.kt` V5 vao `app/src/main/java/duc_phi/music/`.
3. Neu da co V4 cho Drive va API key, **khong can thay 2 file con lai**. Ban ZIP kem chung chi de co bo 3 file dong nhat.
4. Sync Project with Gradle Files -> Rebuild Project -> chay tren may Android.

## Kiem thu

1. Phat mot bai Drive public FLAC/MP3. Bam nut Play/Pause o giua thanh menu, kiem tra khong bi tao player moi.
2. Bam Tim kiem: con tro nam trong o search, nhap va gui truy van nhu truoc.
3. Bam Thu vien: hien playlist hien tai va nut Them nhac.
4. Bam Trang chu: tro ve Equalizer/khung dang phat, nhac khong bi dung.
5. Bam Ca nhan: mo dialog cai dat, dong dialog tro ve tab truoc.
6. Thu tren may man hinh nho: banner AdMob van nam duoi thanh menu, khong bi de len.

## Pham vi kiem chung

Da kiem tra cu phap Kotlin bang Kotlin PSI parser (MainActivity + PublicDriveBrowser: 0 loi), kiem tra XML co the phan tich va doi chieu checksum hai file khong sua. Chua the xac nhan Gradle build / screenshot thuc te do khong co toan bo project Android va thiet bi.

## Bao mat

File XML di kem la file V4 goc, giu nguyen key neu ban da cau hinh. Key khi dong trong APK co the bi trich xuat; su dung Application restrictions va API restrictions, va xoay key neu da chia se cong khai.
