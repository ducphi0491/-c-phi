-- ============================================================
-- TunerTools - Delta Sync V2
-- Chạy MỘT LẦN trên database MySQL "tuner" trước khi phát hành app mới.
--
-- Mục tiêu:
--   1) Chỉ ghi nhận bài mới / bài sửa / bài bị xóa.
--   2) Không coi lượt xem, lượt thích và các số liệu thống kê là cập nhật nội dung.
--   3) Cho Android đồng bộ theo change_id, không xóa file SQLite hiện tại.
--
-- Lưu ý quan trọng:
--   - Không dùng TRUNCATE TABLE songs khi cập nhật dữ liệu vì MySQL không chạy
--     DELETE trigger cho TRUNCATE. Hãy dùng INSERT ... ON DUPLICATE KEY UPDATE
--     và DELETE theo ID để trigger ghi nhận đúng các thay đổi.
-- ============================================================

CREATE TABLE IF NOT EXISTS song_sync_changes (
    change_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    song_id VARCHAR(255) NOT NULL,
    operation ENUM('upsert', 'delete') NOT NULL,
    changed_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (change_id),
    KEY idx_song_sync_song_id (song_id),
    KEY idx_song_sync_changed_at (changed_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

-- Index hỗ trợ bootstrap theo (status, updatedAt, id).
-- Đoạn này chỉ tạo index nếu máy chủ chưa có index cùng tên.
SET @tt_has_sync_index := (
    SELECT COUNT(*)
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'songs'
      AND index_name = 'idx_songs_sync_bootstrap'
);
SET @tt_sync_index_sql := IF(
    @tt_has_sync_index = 0,
    'ALTER TABLE songs ADD INDEX idx_songs_sync_bootstrap (status, updatedAt, id)',
    'SELECT 1'
);
PREPARE tt_sync_index_stmt FROM @tt_sync_index_sql;
EXECUTE tt_sync_index_stmt;
DEALLOCATE PREPARE tt_sync_index_stmt;

DROP TRIGGER IF EXISTS trg_songs_sync_after_insert;
DROP TRIGGER IF EXISTS trg_songs_sync_after_update;
DROP TRIGGER IF EXISTS trg_songs_sync_after_delete;

DELIMITER $$

CREATE TRIGGER trg_songs_sync_after_insert
AFTER INSERT ON songs
FOR EACH ROW
BEGIN
    IF COALESCE(NEW.status, 0) = 1 THEN
        INSERT INTO song_sync_changes (song_id, operation)
        VALUES (NEW.id, 'upsert');
    END IF;
END$$

CREATE TRIGGER trg_songs_sync_after_update
AFTER UPDATE ON songs
FOR EACH ROW
BEGIN
    -- Trường hợp hiếm khi ID bị đổi: xóa ID cũ và cập nhật ID mới.
    IF NOT (OLD.id <=> NEW.id) THEN
        IF COALESCE(OLD.status, 0) = 1 THEN
            INSERT INTO song_sync_changes (song_id, operation)
            VALUES (OLD.id, 'delete');
        END IF;
        IF COALESCE(NEW.status, 0) = 1 THEN
            INSERT INTO song_sync_changes (song_id, operation)
            VALUES (NEW.id, 'upsert');
        END IF;

    -- Bài đang hiển thị bị chuyển về chờ duyệt/ẩn.
    ELSEIF COALESCE(OLD.status, 0) = 1 AND COALESCE(NEW.status, 0) <> 1 THEN
        INSERT INTO song_sync_changes (song_id, operation)
        VALUES (OLD.id, 'delete');

    -- Bài vừa được duyệt hoặc nội dung thực sự thay đổi.
    ELSEIF COALESCE(NEW.status, 0) = 1 AND (
        COALESCE(OLD.status, 0) <> COALESCE(NEW.status, 0)
        OR NOT (OLD.title <=> NEW.title)
        OR NOT (OLD.singerNames <=> NEW.singerNames)
        OR NOT (OLD.authorName <=> NEW.authorName)
        OR NOT (OLD.originalKey <=> NEW.originalKey)
        OR NOT (OLD.rhythm <=> NEW.rhythm)
        OR NOT (OLD.bpm <=> NEW.bpm)
        OR NOT (OLD.youtubeUrl <=> NEW.youtubeUrl)
        OR NOT (OLD.lyrics <=> NEW.lyrics)
        OR NOT (OLD.chordList <=> NEW.chordList)
        OR NOT (OLD.slug <=> NEW.slug)
        OR NOT (OLD.image_count <=> NEW.image_count)
        OR NOT (OLD.id_zing_mp3 <=> NEW.id_zing_mp3)
    ) THEN
        INSERT INTO song_sync_changes (song_id, operation)
        VALUES (NEW.id, 'upsert');
    END IF;
END$$

CREATE TRIGGER trg_songs_sync_after_delete
AFTER DELETE ON songs
FOR EACH ROW
BEGIN
    IF COALESCE(OLD.status, 0) = 1 THEN
        INSERT INTO song_sync_changes (song_id, operation)
        VALUES (OLD.id, 'delete');
    END IF;
END$$

DELIMITER ;

-- Kiểm tra nhanh sau khi chạy:
SELECT
    (SELECT COUNT(*) FROM song_sync_changes) AS current_change_count,
    (SELECT COALESCE(MAX(change_id), 0) FROM song_sync_changes) AS current_cursor;
