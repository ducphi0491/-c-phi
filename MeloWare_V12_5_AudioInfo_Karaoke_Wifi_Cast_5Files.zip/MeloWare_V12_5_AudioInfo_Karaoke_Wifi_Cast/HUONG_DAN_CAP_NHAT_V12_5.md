# MeloWare V12.5 - Thông tin âm thanh, Karaoke, Wi-Fi host và Google Cast

## File cần thay

1. `app/src/main/java/duc_phi/music/MainActivity.kt`
2. `app/src/main/java/duc_phi/music/MusicController.kt`
3. `app/src/main/java/duc_phi/music/NowPlayingScreen.kt`
4. `app/build.gradle.kts`
5. `app/src/main/AndroidManifest.xml`

Sau khi ghi đè file:

1. Chọn **File > Sync Project with Gradle Files**.
2. Chọn **Build > Clean Project**.
3. Chọn **Build > Rebuild Project**.

## Nội dung đã sửa

### Thông tin file âm thanh
Ba nhãn cũ được thay bằng:

- Chất lượng: bitrate, sample rate, Lossless hoặc Hi-Res khi đọc được metadata.
- Đuôi file: MP3, M4A, FLAC, WAV, AAC...
- Dung lượng file: KB, MB hoặc GB.

Với file Drive chưa tải cache, thông tin dung lượng có thể hiển thị `Đang đọc...` hoặc `Không rõ dung lượng`; sau lần phát đầu ứng dụng đọc lại metadata từ cache.

### Karaoke

- Icon micro karaoke giữ màu trung tính khi tắt, màu tím khi bật.
- Khi bật, ảnh bìa được chuyển thành nền mờ/tối cho khu vực lời bài hát.
- Hiện tại hiển thị nội dung chờ nguồn lời; khi có URL/API lời bài hát sẽ gắn vào `KaraokeBackdrop()` trong `NowPlayingScreen.kt`.

### Wi-Fi nội bộ

- Điện thoại tạo một máy chủ HTTP cục bộ có hỗ trợ `GET`, `HEAD`, `OPTIONS` và HTTP Range.
- Thiết bị nhận phải ở cùng mạng Wi-Fi.
- Có thể sao chép/chia sẻ URL cho trình duyệt, VLC hoặc thiết bị hỗ trợ URL mạng.
- Máy chủ hoạt động khi tiến trình MeloWare còn chạy. Không phải DLNA/UPnP tự dò thiết bị.

### Google Cast

- Icon Cast dùng Google Cast Framework.
- Icon trung tính khi chưa kết nối, đổi màu khi đang kết nối hoặc đã kết nối.
- Khi chọn thiết bị Cast, MeloWare phát URL HTTP nội bộ của bài hiện tại bằng Default Media Receiver.
- Play/Pause, tua, Next/Previous được đồng bộ với RemoteMediaClient.
- Thiết bị nhận phải hỗ trợ Google Cast và codec của file nhạc.

## Dependency được thêm

```kotlin
implementation("com.google.android.gms:play-services-cast-framework:22.0.0")
implementation("androidx.fragment:fragment-ktx:1.7.1")
implementation("androidx.mediarouter:mediarouter:1.7.0")
```

`MainActivity` được đổi từ `ComponentActivity` sang `FragmentActivity` để hộp chọn Cast có thể hiển thị đúng.

## Quyền và cấu hình Manifest

Đã thêm:

```xml
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />
```

Trong `<application>` đã có:

```xml
android:usesCleartextTraffic="true"

<meta-data
    android:name="com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME"
    android:value="duc_phi.music.MeloWareCastOptionsProvider" />
```

## Kiểm tra trước khi phát hành

- Thử MP3, M4A và FLAC cục bộ.
- Thử bài Google Drive sau khi đã tải cache.
- Thử Wi-Fi host với một thiết bị khác cùng mạng.
- Thử Cast với Chromecast/Google TV hoặc loa hỗ trợ Cast.
- Kiểm tra mạng có bật AP isolation/client isolation hay không nếu thiết bị không mở được URL nội bộ.
