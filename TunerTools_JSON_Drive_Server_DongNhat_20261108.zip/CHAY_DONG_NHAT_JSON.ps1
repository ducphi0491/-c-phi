param(
    [switch]$Apply,
    [string]$SourceDir = 'C:\TunerTools\Audio\AI_Music',
    [string]$TokenFile = ''
)
$ErrorActionPreference = 'Stop'
$pyScript = Join-Path $PSScriptRoot 'SUA_DONG_BO_JSON_DRIVE.py'
if (!(Test-Path -LiteralPath $pyScript)) { throw 'Cannot find JSON reconcile Python script' }
$pythonExe = (Get-Command python -ErrorAction SilentlyContinue)
if (!$pythonExe) { throw 'Cannot find Python on PATH. Python 3.11+ is required.' }
$argsPy = @($pyScript, '--source', $SourceDir)
if ($TokenFile -ne '') { $argsPy += @('--token', $TokenFile) }
if ($Apply) { $argsPy += '--apply' }
Write-Host '==== GOOGLE DRIVE <-> WINDOWS JSON RECONCILE ====' -ForegroundColor Cyan
if ($Apply) {
    Write-Host 'MODE: APPLY exact 3 JSON fixes (no deletes)' -ForegroundColor Yellow
} else {
    Write-Host 'MODE: PREVIEW ONLY (read-only)' -ForegroundColor Green
}
& python @argsPy
if ($LASTEXITCODE -ne 0) { throw "JSON reconciliation failed (exit code $LASTEXITCODE)" }
