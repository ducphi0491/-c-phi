#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Exact, narrowly-scoped TunerTools AI JSON Drive reconciliation.

Preview by default. --apply requires deliberate approval by the owner.
Does not touch audio or the PHP/Python API source. No deletions. Only:
* Rename a single known Drive JSON by metadata PATCH (preserve file ID)
* Create exactly one missing new JSON from Windows
* Move malformed duplicate to a named quarantine folder, no deletion
* Verify the entire valid JSON filename set afterwards
The OAuth token is read from the same token file as the user's existing audit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
from urllib import error, parse, request
import uuid

from DOI_CHIEU_AI_DRIVE import (
    GoogleReader, SOURCE_DEFAULT, TOKEN_DEFAULTS, GOOGLE_FILES, FOLDER_MIME,
    find_local_files,
)

OLD_WORLD = 'BENRL6H8Y8KW__WORLD_SEVENTEEN.json'
NEW_WORLD = 'BENRL6H8Y8KW_WORLD_SEVENTEEN.json'
NEW_SONG = 'QGQK47AO9MIR_Một Đêm Say_Thịnh Suy.json'
ORPHAN = '_Phố Hoa_Cẩm Ly.json'
VALID_PHO_HOA = 'RLCRTT2RFR3M_Phố Hoa_Cẩm Ly.json'
QUARANTINE = 'lyrics_quarantine'


def names_index(files: list[dict]) -> dict[str, list[dict]]:
    by_name: dict[str, list[dict]] = {}
    for f in files:
        if f.get('mimeType') != FOLDER_MIME:
            by_name.setdefault(str(f.get('name')), []).append(f)
    return by_name


def unique(mapping: dict[str, list[dict]], name: str):
    result = mapping.get(name, [])
    if len(result) > 1:
        raise RuntimeError('STOP: Duplicate Drive JSON with same name: ' + name)
    return result[0] if result else None


def http_json(drive: GoogleReader, method: str, url: str, body: dict) -> dict:
    data = json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    # A write is performed at most once per call. An ambiguous failure is
    # never blindly retried; calling code re-lists the Drive state.
    for ix in range(2):
        req = request.Request(url, data=data, method=method, headers={
            'Authorization': 'Bearer ' + drive.token,
            'Content-Type': 'application/json; charset=UTF-8',
            'Accept': 'application/json',
        })
        try:
            with request.urlopen(req, timeout=65) as r:
                result = json.load(r)
            if not isinstance(result, dict):
                raise RuntimeError('Google API returned unexpected JSON')
            return result
        except error.HTTPError as exc:
            if exc.code == 401 and ix == 0:
                drive.refresh()
                continue
            raise RuntimeError('Drive API HTTP ' + str(exc.code)) from exc
    raise RuntimeError('Drive write authorization failed')


def detail(drive: GoogleReader, file_id: str) -> dict:
    url = GOOGLE_FILES + '/' + parse.quote(file_id, safe='') + '?' + parse.urlencode({
        'fields': 'id,name,size,md5Checksum,mimeType,parents',
    })
    return drive.get(url)


def md5file(path: Path) -> str:
    h = hashlib.md5()
    with path.open('rb') as f:
        while True:
            b = f.read(1024 * 128)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def remote_equals_local(drive: GoogleReader, remote: dict, local: Path) -> tuple[bool, str]:
    if not local.is_file():
        return False, 'Missing local source'
    metadata = detail(drive, str(remote['id']))
    remote_size = int(metadata.get('size', -1))
    if local.stat().st_size != remote_size:
        return False, f'Size differs (local={local.stat().st_size}, Drive={remote_size})'
    remote_md5 = metadata.get('md5Checksum')
    if not remote_md5:
        return False, 'Drive did not supply MD5 checksum for binary JSON, refuse unverified rename'
    mine = md5file(local)
    if mine.lower() != str(remote_md5).lower():
        return False, 'MD5 differs; refuse to relabel non-identical JSON data'
    return True, 'Size and MD5 match'


def upload_json_once(drive: GoogleReader, folder_id: str, local: Path) -> dict:
    # Single multipart create, preserving UTF-8 filenames.
    boundary = 'TTAJson' + uuid.uuid4().hex
    metadata = json.dumps({
        'name': local.name, 'mimeType': 'application/json', 'parents': [folder_id]
    }, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    contents = local.read_bytes()
    body = (
        b'--' + boundary.encode() + b'\r\n'
        b'Content-Type: application/json; charset=UTF-8\r\n\r\n' + metadata + b'\r\n'
        b'--' + boundary.encode() + b'\r\n'
        b'Content-Type: application/json; charset=UTF-8\r\n\r\n' + contents + b'\r\n'
        b'--' + boundary.encode() + b'--\r\n'
    )
    url = 'https://www.googleapis.com/upload/drive/v3/files?' + parse.urlencode({
        'uploadType': 'multipart', 'fields': 'id,name,size,md5Checksum',
    })
    req = request.Request(url, data=body, method='POST', headers={
        'Authorization': 'Bearer ' + drive.token,
        'Accept': 'application/json',
        'Content-Type': 'multipart/related; boundary=' + boundary,
    })
    with request.urlopen(req, timeout=100) as resp:
        return json.load(resp)


def snapshot(drive: GoogleReader, lyrics_id: str, root: Path):
    local, diagnostics = find_local_files(root)
    # This program only cares about JSON, not the 8 legacy audio names.
    if any(not (root / x).is_dir() for x in ('ZING_JSON', 'YOUTUBE_CACHE')):
        raise RuntimeError('STOP: ZING_JSON or YOUTUBE_CACHE missing')
    if diagnostics['invalid_json']:
        raise RuntimeError('STOP: Invalid local JSON detected: ' + str(diagnostics['invalid_json'][:2]))
    local_json = local['lyrics']
    duplicated_local = [name for name, xs in local_json.items() if len(xs) != 1]
    if duplicated_local:
        raise RuntimeError('STOP: Duplicate local JSON name: ' + str(duplicated_local[:4]))
    remote_json = names_index(drive.list_files(lyrics_id))
    remote_dup = [name for name, xs in remote_json.items() if len(xs) != 1]
    if remote_dup:
        raise RuntimeError('STOP: Duplicate Drive JSON name: ' + str(remote_dup[:4]))
    missing = set(local_json) - set(remote_json)
    extra = set(remote_json) - set(local_json)
    return local_json, remote_json, missing, extra


def display(local_json, remote_json, missing, extra, msg):
    same = set(local_json) & set(remote_json)
    changed_size = []
    for name in same:
        local_bytes = int(local_json[name][0][1])
        remote_bytes = int(remote_json[name][0].get('size') or -1)
        if local_bytes != remote_bytes:
            changed_size.append(name)
    print('\n==== ' + msg + ' ====')
    print(f'LOCAL JSON: {len(local_json)} | DRIVE JSON: {len(remote_json)} | SAME NAME: {len(same)}')
    print(f'MISSING_ON_DRIVE: {len(missing)} | ONLY_ON_DRIVE: {len(extra)} | SIZE_DIFFERENT: {len(changed_size)}')
    for name in sorted(missing):
        print('  MISSING:', name)
    for name in sorted(extra):
        print('  EXTRA:', name)
    for name in sorted(changed_size):
        print('  SIZE_DIFF:', name)
    return changed_size


def main():
    p = argparse.ArgumentParser(description='Exact TunerTools JSON reconciliation; default READ ONLY')
    p.add_argument('--source', default=SOURCE_DEFAULT)
    p.add_argument('--token', default='')
    p.add_argument('--apply', action='store_true')
    args = p.parse_args()
    sys.stdout.reconfigure(errors='replace')
    root = Path(args.source)
    if not root.is_dir():
        raise RuntimeError('STOP: Local source root missing ' + str(root))
    token = Path(args.token) if args.token else next((Path(x) for x in TOKEN_DEFAULTS if Path(x).is_file()), None)
    if token is None or not token.is_file():
        raise RuntimeError('STOP: Drive OAuth file not found; use --token <path>')
    drive = GoogleReader(token)
    ai_parent = drive.folder(drive.folder('root', 'TunerTools_AppBackup'), 'AI_Music')
    lyrics_id = drive.folder(ai_parent, 'lyrics')
    local, remote, missing, extra = snapshot(drive, lyrics_id, root)
    changed_size = display(local, remote, missing, extra, 'BEFORE LIVE AUDIT')
    if changed_size:
        raise RuntimeError('STOP: Existing JSON with different size; reconcile manually before proceeding')
    if missing - {NEW_WORLD, NEW_SONG} or extra - {OLD_WORLD, ORPHAN}:
        raise RuntimeError('STOP: Unexpected JSON filename differences, no modifications made')
    if NEW_WORLD not in local or NEW_SONG not in local:
        raise RuntimeError('STOP: Expected source JSON files not found')
    if VALID_PHO_HOA not in local or not unique(remote, VALID_PHO_HOA):
        raise RuntimeError('STOP: Valid Phố Hoa JSON not present in both places')
    # Critical safety preflight: Do not rename a Drive file to a different payload.
    original = unique(remote, OLD_WORLD)
    if original and unique(remote, NEW_WORLD):
        raise RuntimeError('STOP: Both old and new WORLD JSON exist on Drive; manual review required')
    if original:
        good, message = remote_equals_local(drive, original, Path(local[NEW_WORLD][0][0]))
        print('WORLD payload check:', message)
        if not good:
            raise RuntimeError('STOP: Cannot safely rename WORLD JSON')

    if unique(remote, ORPHAN) and unique(remote, VALID_PHO_HOA):
        print('PHO HOA malformed duplicate found; it will be moved to archive, not deleted.')
    print('\n==== 3 EXACT ACTIONS (NO AUDIO, NO DELETE) ====')
    print('1. Rename JSON on Drive:', OLD_WORLD, '->', NEW_WORLD)
    print('2. Upload missing JSON:', NEW_SONG)
    print('3. Move orphan JSON to AI_Music/' + QUARANTINE + ':', ORPHAN)
    print('MODE:', 'APPLY' if args.apply else 'PREVIEW / READ ONLY')
    if not args.apply:
        print('\nNo changes made. Run with --apply after reviewing the 3 exact actions.')
        return 0

    # Step 1: metadata rename only. This preserves same content and file ID.
    if original:
        print('\n[1/3] Rename WORLD JSON on Drive...')
        try:
            http_json(drive, 'PATCH', GOOGLE_FILES + '/' + parse.quote(original['id'], safe='') +
                      '?fields=id,name,size', {'name': NEW_WORLD})
        except Exception as exc:
            print('  Write connection uncertainty:', type(exc).__name__ + ': ' + str(exc)[:140])
        now = names_index(drive.list_files(lyrics_id))
        if unique(now, OLD_WORLD) or not unique(now, NEW_WORLD):
            raise RuntimeError('STOP: Rename not confirmed on Drive. Rerun preview; never blindly repeat writes')
        renamed = unique(now, NEW_WORLD)
        same, check = remote_equals_local(drive, renamed, Path(local[NEW_WORLD][0][0]))
        if not same:
            raise RuntimeError('STOP: Renamed file payload verification failed: ' + check)
        print('  OK: WORLD filename and MD5 are correct.')
    else:
        print('\n[1/3] WORLD already has intended filename; no rename.')

    # Step 2: create-only upload for the ONE new JSON. Network error is
    # ambiguous; after any exception we re-list instead of retrying POST.
    now = names_index(drive.list_files(lyrics_id))
    target = Path(local[NEW_SONG][0][0])
    if not unique(now, NEW_SONG):
        print('\n[2/3] Uploading ONE missing JSON:', NEW_SONG)
        try:
            upload_json_once(drive, lyrics_id, target)
        except Exception as exc:
            print('  Write connection uncertainty:', type(exc).__name__ + ': ' + str(exc)[:140])
        for i in range(4):
            now = names_index(drive.list_files(lyrics_id))
            if unique(now, NEW_SONG):
                break
            time.sleep(2 * (i + 1))
    else:
        print('\n[2/3] Song already on Drive; skipped upload.')
    present = unique(now, NEW_SONG)
    if not present:
        raise RuntimeError('STOP: Upload not confirmed; rerun preview, do not create a duplicate')
    same, check = remote_equals_local(drive, present, target)
    if not same:
        raise RuntimeError('STOP: Uploaded JSON payload verification failed: ' + check)
    print('  OK: new JSON has same size and MD5 on Drive.')

    # Step 3: quarantine malformed orphan in a different Drive folder.
    now = names_index(drive.list_files(lyrics_id))
    orphan = unique(now, ORPHAN)
    if orphan:
        print('\n[3/3] Archiving orphan Phố Hoa JSON (NOT deleting)...')
        qfound = [f for f in drive.list_files(ai_parent, QUARANTINE)
                  if f.get('mimeType') == FOLDER_MIME]
        if len(qfound) > 1:
            raise RuntimeError('STOP: Duplicate quarantine folders')
        if qfound:
            quarantine_id = str(qfound[0]['id'])
        else:
            try:
                made = http_json(drive, 'POST', GOOGLE_FILES + '?fields=id,name,mimeType', {
                    'name': QUARANTINE, 'mimeType': FOLDER_MIME, 'parents': [ai_parent],
                })
                quarantine_id = str(made['id'])
            except Exception:
                qfound = [f for f in drive.list_files(ai_parent, QUARANTINE)
                          if f.get('mimeType') == FOLDER_MIME]
                if len(qfound) != 1:
                    raise RuntimeError('STOP: Quarantine folder could not be verified')
                quarantine_id = str(qfound[0]['id'])
        qitems = names_index(drive.list_files(quarantine_id))
        if unique(qitems, ORPHAN):
            raise RuntimeError('STOP: File already in quarantine, refuse to create another same-named file')
        qs = parse.urlencode({'addParents': quarantine_id, 'removeParents': lyrics_id,
                              'fields': 'id,name,parents'})
        try:
            http_json(drive, 'PATCH', GOOGLE_FILES + '/' + parse.quote(orphan['id'], safe='') + '?' + qs, {})
        except Exception as exc:
            print('  Move connection uncertainty:', type(exc).__name__ + ': ' + str(exc)[:140])
        in_lyrics = unique(names_index(drive.list_files(lyrics_id)), ORPHAN)
        in_quarantine = unique(names_index(drive.list_files(quarantine_id)), ORPHAN)
        if in_lyrics or not in_quarantine or in_quarantine.get('id') != orphan.get('id'):
            raise RuntimeError('STOP: Orphan move not confirmed; rerun preview')
        print('  OK: archived in AI_Music/' + QUARANTINE + '/' + ORPHAN)
    else:
        print('\n[3/3] Orphan already absent; no move.')

    local_after, remote_after, miss_after, extra_after = snapshot(drive, lyrics_id, root)
    changed_after = display(local_after, remote_after, miss_after, extra_after, 'FINAL LIVE DRIVE AUDIT')
    if miss_after or extra_after or changed_after:
        print('WARNING: Remaining JSON difference. Do not delete anything; inspect differences.')
        return 1
    print('SUCCESS: JSON filename sets and byte sizes now match. No Drive files deleted.')
    print('NOTE: The Alwaysdata PHP catalog may need up to 600 seconds to refresh.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('Interrupted. Run preview again to view current state.')
        sys.exit(130)
    except Exception as exc:
        print('ERROR:', type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(2)
