TUNERTOOLS - DONG NHAT CHINH XAC FILE JSON WINDOWS vs GOOGLE DRIVE

Chi xu ly folder JSON 'lyrics'. KHONG xu ly audio, KHONG sua PHP, KHONG xoa file.

Tinh trang tai thoi diem kiem tra (2026-11-08):
 Windows ZING_JSON + YOUTUBE_CACHE: 1820 JSON
 Google Drive: 1820 JSON
 SAME NAMES: 1818; MISSING ON DRIVE: 2; ONLY ON DRIVE: 2.

3 buoc du kien:
 1. DOI TEN (Drive metadata, giu nguyen file ID/noi dung):
    BENRL6H8Y8KW__WORLD_SEVENTEEN.json
 -> BENRL6H8Y8KW_WORLD_SEVENTEEN.json
 2. UPLOAD CHI 1 JSON MOI:
    QGQK47AO9MIR_Mot Dem Say_Thinh Suy.json
    (chu y filename thuc te dung tieng Viet: QGQK47AO9MIR_Một Đêm Say_Thịnh Suy.json)
 3. DI CHUYEN FILE JSON PHO HOA THIEU MA (khong xoa):
    lyrics/_Phố Hoa_Cẩm Ly.json
 -> AI_Music/lyrics_quarantine/_Phố Hoa_Cẩm Ly.json
    Va chi thuc hien khi file RLCRTT2RFR3M_Phố Hoa_Cẩm Ly.json hop le van co.

CHAY:
 1. Giai nen vao C:\TunerTools\Tools\AI_JSON_Exact_Sync
 2. PowerShell - preview KHONG thay doi:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Exact_Sync\CHAY_DONG_NHAT_JSON.ps1"
 3. Sau khi kiem tra ky 3 thao tac, chap nhan thay doi Drive:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TunerTools\Tools\AI_JSON_Exact_Sync\CHAY_DONG_NHAT_JSON.ps1" -Apply

Hoac dung source/token rieng:
    -SourceDir "C:\TunerTools\Audio\AI_Music" -TokenFile "C:\...\drive_token.json"

BAO VE:
 - Tu dong tim token OAuth dang duoc su dung boi script audit truoc do.
 - Khong in token.
 - Khong upload lai 1820 JSON.
 - Neu co chenhlech khac dung 2 cap tren, DUNG de tranh sua nham.
 - Kiem tra MD5 cua file WORLD truoc khi doi ten, va file moi sau upload.
 - Neu loi mang sau khi gui len Drive, kiem tra trang thai truoc khi thu lai.
 - Doi ten, upload va chuyen thu muc, KHONG xoa hay ghi de file.
 - CHI SO SANH filename/size cho 1818 file trung con lai; khong hash tat ca 1818 file.
 - Folder quarantine duoc tao neu chua co, va luu giu JSON Phố Hoa de phuc hoi khi can.
 - PHP cached_songs co the cache khoang 600 giay; kiem tra app sau khi cache moi.

MUC TIEU:
 LOCAL JSON 1820, DRIVE JSON 1820,
 SAME=1820, MISSING_ON_DRIVE=0, ONLY_ON_DRIVE=0, SIZE_DIFFERENT=0.

Canh bao: Day la thuc thi Drive API. Xem preview truoc khi -Apply.
